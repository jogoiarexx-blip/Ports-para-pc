#include "generated.hpp"
void sub_00816A_E0M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0082EEu: goto L_0082EE;
    case 0x0082F1u: goto L_0082F1;
    case 0x0082F4u: goto L_0082F4;
    case 0x0082F7u: goto L_0082F7;
    case 0x0082F9u: goto L_0082F9;
    case 0x0082FCu: goto L_0082FC;
    case 0x0082FEu: goto L_0082FE;
    case 0x0082FFu: goto L_0082FF;
    case 0x008301u: goto L_008301;
    case 0x008304u: goto L_008304;
    case 0x008306u: goto L_008306;
    case 0x008308u: goto L_008308;
    case 0x00830Bu: goto L_00830B;
    case 0x00830Du: goto L_00830D;
    case 0x00830Eu: goto L_00830E;
    case 0x008310u: goto L_008310;
    case 0x008313u: goto L_008313;
    case 0x008315u: goto L_008315;
    case 0x008317u: goto L_008317;
    case 0x00831Au: goto L_00831A;
    case 0x00831Cu: goto L_00831C;
    case 0x00831Fu: goto L_00831F;
    case 0x008321u: goto L_008321;
    case 0x008324u: goto L_008324;
    case 0x008326u: goto L_008326;
    case 0x008329u: goto L_008329;
    case 0x00832Bu: goto L_00832B;
    case 0x00832Eu: goto L_00832E;
    case 0x008330u: goto L_008330;
    case 0x008333u: goto L_008333;
    case 0x008335u: goto L_008335;
    case 0x008338u: goto L_008338;
    case 0x00833Au: goto L_00833A;
    case 0x00833Du: goto L_00833D;
    case 0x00833Fu: goto L_00833F;
    case 0x008342u: goto L_008342;
    case 0x008345u: goto L_008345;
    case 0x008348u: goto L_008348;
    case 0x008349u: goto L_008349;
    case 0x00834Bu: goto L_00834B;
    case 0x00834Eu: goto L_00834E;
    case 0x008351u: goto L_008351;
    case 0x008354u: goto L_008354;
    case 0x008357u: goto L_008357;
    case 0x008359u: goto L_008359;
    case 0x00835Cu: goto L_00835C;
    case 0x00835Eu: goto L_00835E;
    case 0x008361u: goto L_008361;
    case 0x008363u: goto L_008363;
    case 0x008366u: goto L_008366;
    case 0x008367u: goto L_008367;
    case 0x008368u: goto L_008368;
    case 0x00836Bu: goto L_00836B;
    case 0x00836Du: goto L_00836D;
    case 0x00836Fu: goto L_00836F;
    case 0x008371u: goto L_008371;
    case 0x00838Cu: goto L_00838C;
    case 0x00838Fu: goto L_00838F;
    case 0x008391u: goto L_008391;
    case 0x008394u: goto L_008394;
    case 0x008396u: goto L_008396;
    case 0x008399u: goto L_008399;
    case 0x00839Bu: goto L_00839B;
    case 0x00839Eu: goto L_00839E;
    case 0x0083A0u: goto L_0083A0;
    case 0x0083A3u: goto L_0083A3;
    case 0x0083A5u: goto L_0083A5;
    case 0x0083A8u: goto L_0083A8;
    case 0x0083AAu: goto L_0083AA;
    case 0x0083ADu: goto L_0083AD;
    case 0x0083AFu: goto L_0083AF;
    case 0x0083B2u: goto L_0083B2;
    case 0x0083B4u: goto L_0083B4;
    case 0x0083B5u: goto L_0083B5;
    case 0x0083B6u: goto L_0083B6;
    case 0x0083B7u: goto L_0083B7;
    case 0x0083B8u: goto L_0083B8;
    case 0x0083B9u: goto L_0083B9;
    case 0x0083F3u: goto L_0083F3;
    case 0x0083F6u: goto L_0083F6;
    case 0x0083F9u: goto L_0083F9;
    case 0x0083FAu: goto L_0083FA;
    case 0x0083FBu: goto L_0083FB;
    case 0x0083FDu: goto L_0083FD;
    case 0x008400u: goto L_008400;
    case 0x008402u: goto L_008402;
    case 0x008405u: goto L_008405;
    case 0x008407u: goto L_008407;
    case 0x00840Au: goto L_00840A;
    case 0x00840Cu: goto L_00840C;
    case 0x00840Fu: goto L_00840F;
    case 0x008411u: goto L_008411;
    case 0x008414u: goto L_008414;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0082EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82EEu,0x0082EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EEu, 6u, 3u, cpu.address("abs", 0x85D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082EE JSR -> $0085D2 stack real
    { cpu.push16Value(hw,0x82F0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82F1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85D2u), 0x0082EEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082F1;
L_0082F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82F1u,0x0082F1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F1u, 6u, 3u, cpu.address("abs", 0x8449u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082F1 JSR -> $008449 stack real
    { cpu.push16Value(hw,0x82F3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82F4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8449u), 0x0082F1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082F4;
L_0082F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82F4u,0x0082F4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F4u, 6u, 3u, cpu.address("abs", 0x8650u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082F4 JSR -> $008650 stack real
    { cpu.push16Value(hw,0x82F6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82F7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8650u), 0x0082F4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082F7;
L_0082F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82F7u,0x0082F7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082F7 LDA
    cpu.setA(0x9u, 8);
    goto L_0082F9;
L_0082F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F9u, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082F9 STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_0082FC;
L_0082FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082FC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0082FE;
L_0082FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082FE CLC
    cpu.setFlag('C', false);
    goto L_0082FF;
L_0082FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082FF ADC
    cpu.adc(0x80u);
    goto L_008301;
L_008301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8301u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8301u, 4u, 3u, cpu.address("abs", 0x211Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008301 STA
    hw.write(cpu.address("abs", 0x211Fu), cpu.a, cpu.m8?8:16);
    goto L_008304;
L_008304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8304u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8304u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8304u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008304 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008306;
L_008306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8306u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8306u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008306 ADC
    cpu.adc(0x0u);
    goto L_008308;
L_008308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8308u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8308u, 4u, 3u, cpu.address("abs", 0x211Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008308 STA
    hw.write(cpu.address("abs", 0x211Fu), cpu.a, cpu.m8?8:16);
    goto L_00830B;
L_00830B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00830B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00830D;
L_00830D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00830D CLC
    cpu.setFlag('C', false);
    goto L_00830E;
L_00830E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00830E ADC
    cpu.adc(0x80u);
    goto L_008310;
L_008310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8310u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8310u, 4u, 3u, cpu.address("abs", 0x2120u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008310 STA
    hw.write(cpu.address("abs", 0x2120u), cpu.a, cpu.m8?8:16);
    goto L_008313;
L_008313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8313u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8313u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008313 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008315;
L_008315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8315u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8315u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008315 ADC
    cpu.adc(0x0u);
    goto L_008317;
L_008317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8317u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8317u, 4u, 3u, cpu.address("abs", 0x2120u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008317 STA
    hw.write(cpu.address("abs", 0x2120u), cpu.a, cpu.m8?8:16);
    goto L_00831A;
L_00831A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00831A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00831C;
L_00831C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Cu, 4u, 3u, cpu.address("abs", 0x211Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00831C STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_00831F;
L_00831F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00831F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008321;
L_008321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8321u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8321u, 4u, 3u, cpu.address("abs", 0x211Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008321 STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_008324;
L_008324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8324u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8324u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x30u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008324 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008326;
L_008326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8326u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8326u, 4u, 3u, cpu.address("abs", 0x211Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008326 STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_008329;
L_008329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8329u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8329u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x31u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008329 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x31u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00832B;
L_00832B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x832Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x832Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x832Bu, 4u, 3u, cpu.address("abs", 0x211Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00832B STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_00832E;
L_00832E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x832Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x832Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x832Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00832E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x32u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008330;
L_008330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8330u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8330u, 4u, 3u, cpu.address("abs", 0x211Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008330 STA
    hw.write(cpu.address("abs", 0x211Du), cpu.a, cpu.m8?8:16);
    goto L_008333;
L_008333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8333u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8333u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x33u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008333 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x33u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008335;
L_008335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8335u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8335u, 4u, 3u, cpu.address("abs", 0x211Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008335 STA
    hw.write(cpu.address("abs", 0x211Du), cpu.a, cpu.m8?8:16);
    goto L_008338;
L_008338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8338u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8338u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x34u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008338 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x34u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00833A;
L_00833A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Au, 4u, 3u, cpu.address("abs", 0x211Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00833A STA
    hw.write(cpu.address("abs", 0x211Eu), cpu.a, cpu.m8?8:16);
    goto L_00833D;
L_00833D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00833D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x35u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00833F;
L_00833F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Fu, 4u, 3u, cpu.address("abs", 0x211Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00833F STA
    hw.write(cpu.address("abs", 0x211Eu), cpu.a, cpu.m8?8:16);
    goto L_008342;
L_008342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8342u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8342u, 6u, 3u, cpu.address("abs", 0x8416u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008342 JSR -> $008416 stack real
    { cpu.push16Value(hw,0x8344u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8345u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8416u), 0x008342u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008345;
L_008345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8345u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8345u,0x008345u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008345 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008348;
L_008348:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8348u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8348u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8348u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008348 LSR
    cpu.lsrA();
    goto L_008349;
L_008349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8349u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8349u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008349 BCC -> $00835C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00835C; }
    goto L_00834B;
L_00834B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Bu, 4u, 3u, cpu.address("abs", 0x0DAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00834B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDAEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00834E;
L_00834E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Eu, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00834E STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_008351;
L_008351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8351u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8351u, 4u, 3u, cpu.address("abs", 0x0D9Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008351 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008354;
L_008354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8354u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8354u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008354 STA
    hw.write(cpu.address("abs", 0x420Cu), cpu.a, cpu.m8?8:16);
    goto L_008357;
L_008357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8357u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8357u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008357 LDA
    cpu.setA(0x81u, 8);
    goto L_008359;
L_008359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8359u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8359u, 3u, 3u, cpu.address("abs", 0x83F3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008359 JMP -> $0083F3
    goto L_0083F3;
L_00835C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00835C LDY
    cpu.setY(0x24u, 8);
    goto L_00835E;
L_00835E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Eu,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Eu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00835E BIT
    cpu.bit(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), false);
    goto L_008361;
L_008361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8361u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8361u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008361 BVC -> $008371
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_008371; }
    goto L_008363;
L_008363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8363u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8363u, 4u, 3u, cpu.address("abs", 0x13FCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008363 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13FCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008366;
L_008366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8366u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8366u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008366 ASL
    cpu.aslA();
    goto L_008367;
L_008367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8367u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8367u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008367 TAX
    cpu.transfer("TAX");
    goto L_008368;
L_008368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8368u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8368u, 4u + ((((0xF8E8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF8E8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008368 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF8E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00836B;
L_00836B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00836B CMP
    cpu.compareA(0x2Au);
    goto L_00836D;
L_00836D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00836D BNE -> $008371
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008371; }
    goto L_00836F;
L_00836F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00836F LDY
    cpu.setY(0x2Du, 8);
    goto L_008371;
L_008371:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8371u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8371u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8371u, 3u, 3u, cpu.address("abs", 0x8294u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008371 JMP -> $008294
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8294u),0x008371u); return;
L_00838C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Cu, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00838C STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_00838F;
L_00838F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00838F LDY
    cpu.setY(0x1Fu, 8);
    goto L_008391;
L_008391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8391u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8391u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8391u, 6u, 3u, cpu.address("abs", 0x843Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008391 JSR -> $00843B stack real
    { cpu.push16Value(hw,0x8393u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8394u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x843Bu), 0x008391u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008394;
L_008394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8394u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8394u,0x008394u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8394u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8394u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008394 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008396;
L_008396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8396u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8396u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8396u, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008396 STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_008399;
L_008399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8399u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8399u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x23u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008399 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x23u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00839B;
L_00839B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Bu, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00839B STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_00839E;
L_00839E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00839E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0083A0;
L_0083A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A0u, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083A0 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_0083A3;
L_0083A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083A3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x25u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0083A5;
L_0083A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083A5 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_0083A8;
L_0083A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083A8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0083AA;
L_0083AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AAu, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083AA STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_0083AD;
L_0083AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x40u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083AD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x40u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0083AF;
L_0083AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083AF STA
    hw.write(cpu.address("abs", 0x2131u), cpu.a, cpu.m8?8:16);
    goto L_0083B2;
L_0083B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083B2 REP
    cpu.rep(0x30u);
    goto L_0083B4;
L_0083B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B4u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0083B4 PLB
    cpu.pop("PLB", hw);
    goto L_0083B5;
L_0083B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B5u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0083B5 PLY
    cpu.pop("PLY", hw);
    goto L_0083B6;
L_0083B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0083B6 PLX
    cpu.pop("PLX", hw);
    goto L_0083B7;
L_0083B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0083B7 PLA
    cpu.pop("PLA", hw);
    goto L_0083B8;
L_0083B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B8u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0083B8 PLP
    cpu.pop("PLP", hw);
    goto L_0083B9;
L_0083B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83B9u,0x0083B9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0083B9 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x0083B9u);return;}
L_0083F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F3u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083F3 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_0083F6;
L_0083F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F6u, 6u, 3u, cpu.address("abs", 0x8439u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0083F6 JSR -> $008439 stack real
    { cpu.push16Value(hw,0x83F8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83F9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8439u), 0x0083F6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0083F9;
L_0083F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83F9u,0x0083F9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F9u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083F9 NOP
    ;
    goto L_0083FA;
L_0083FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FAu,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083FA NOP
    ;
    goto L_0083FB;
L_0083FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083FB LDA
    cpu.setA(0x7u, 8);
    goto L_0083FD;
L_0083FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FDu, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0083FD STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_008400;
L_008400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8400u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8400u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8400u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008400 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008402;
L_008402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8402u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8402u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8402u, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008402 STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_008405;
L_008405:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8405u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8405u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8405u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008405 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008407;
L_008407:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8407u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8407u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8407u, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008407 STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_00840A;
L_00840A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00840A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00840C;
L_00840C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Cu, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00840C STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_00840F;
L_00840F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00840F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008411;
L_008411:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8411u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8411u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8411u, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008411 STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_008414;
L_008414:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8414u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8414u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8414u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008414 BRA -> $0083B2
    goto L_0083B2;
}

void sub_008475_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008475u: goto L_008475;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008475:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8475u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8475u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8475u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $008475 BRK
    hw.partial(0x008475u, "BRK"); return;
}

void sub_0087AD_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0087ADu: goto L_0087AD;
    case 0x0087AFu: goto L_0087AF;
    case 0x0087B2u: goto L_0087B2;
    case 0x0087B4u: goto L_0087B4;
    case 0x0087B7u: goto L_0087B7;
    case 0x0087B9u: goto L_0087B9;
    case 0x0087BBu: goto L_0087BB;
    case 0x0087BDu: goto L_0087BD;
    case 0x0087C0u: goto L_0087C0;
    case 0x0087C2u: goto L_0087C2;
    case 0x0087C5u: goto L_0087C5;
    case 0x0087C8u: goto L_0087C8;
    case 0x0087CBu: goto L_0087CB;
    case 0x0087CEu: goto L_0087CE;
    case 0x0087D1u: goto L_0087D1;
    case 0x0087D3u: goto L_0087D3;
    case 0x0087D6u: goto L_0087D6;
    case 0x0087D9u: goto L_0087D9;
    case 0x0087DAu: goto L_0087DA;
    case 0x0087DCu: goto L_0087DC;
    case 0x0087DEu: goto L_0087DE;
    case 0x0087E1u: goto L_0087E1;
    case 0x0087E4u: goto L_0087E4;
    case 0x0087E7u: goto L_0087E7;
    case 0x0087EAu: goto L_0087EA;
    case 0x0087EDu: goto L_0087ED;
    case 0x008849u: goto L_008849;
    case 0x00884Bu: goto L_00884B;
    case 0x00884Eu: goto L_00884E;
    case 0x008851u: goto L_008851;
    case 0x008854u: goto L_008854;
    case 0x008857u: goto L_008857;
    case 0x00885Au: goto L_00885A;
    case 0x00885Cu: goto L_00885C;
    case 0x00885Fu: goto L_00885F;
    case 0x008862u: goto L_008862;
    case 0x008863u: goto L_008863;
    case 0x008865u: goto L_008865;
    case 0x008867u: goto L_008867;
    case 0x00886Au: goto L_00886A;
    case 0x00886Du: goto L_00886D;
    case 0x008870u: goto L_008870;
    case 0x008873u: goto L_008873;
    case 0x008876u: goto L_008876;
    case 0x0088DDu: goto L_0088DD;
    case 0x0088DFu: goto L_0088DF;
    case 0x0088E2u: goto L_0088E2;
    case 0x0088E5u: goto L_0088E5;
    case 0x0088E7u: goto L_0088E7;
    case 0x0088EAu: goto L_0088EA;
    case 0x0088ECu: goto L_0088EC;
    case 0x0088EEu: goto L_0088EE;
    case 0x0088F0u: goto L_0088F0;
    case 0x0088F3u: goto L_0088F3;
    case 0x0088F5u: goto L_0088F5;
    case 0x0088F8u: goto L_0088F8;
    case 0x0088FBu: goto L_0088FB;
    case 0x0088FEu: goto L_0088FE;
    case 0x008901u: goto L_008901;
    case 0x008904u: goto L_008904;
    case 0x008906u: goto L_008906;
    case 0x008909u: goto L_008909;
    case 0x00890Cu: goto L_00890C;
    case 0x00890Du: goto L_00890D;
    case 0x00890Fu: goto L_00890F;
    case 0x008911u: goto L_008911;
    case 0x008914u: goto L_008914;
    case 0x008917u: goto L_008917;
    case 0x00891Au: goto L_00891A;
    case 0x00891Du: goto L_00891D;
    case 0x008920u: goto L_008920;
    case 0x00897Cu: goto L_00897C;
    case 0x00897Eu: goto L_00897E;
    case 0x008981u: goto L_008981;
    case 0x008984u: goto L_008984;
    case 0x008987u: goto L_008987;
    case 0x00898Au: goto L_00898A;
    case 0x00898Du: goto L_00898D;
    case 0x00898Fu: goto L_00898F;
    case 0x008992u: goto L_008992;
    case 0x008995u: goto L_008995;
    case 0x008996u: goto L_008996;
    case 0x008998u: goto L_008998;
    case 0x00899Au: goto L_00899A;
    case 0x00899Du: goto L_00899D;
    case 0x0089A0u: goto L_0089A0;
    case 0x0089A3u: goto L_0089A3;
    case 0x0089A6u: goto L_0089A6;
    case 0x0089A9u: goto L_0089A9;
    case 0x008A10u: goto L_008A10;
    case 0x008A12u: goto L_008A12;
    case 0x008A15u: goto L_008A15;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0087AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087AD SEP
    cpu.sep(0x30u);
    goto L_0087AF;
L_0087AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087AF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087B2;
L_0087B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087B2 BNE -> $0087B7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0087B7; }
    goto L_0087B4;
L_0087B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u, 3u, 3u, cpu.address("abs", 0x88DDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087B4 JMP -> $0088DD
    goto L_0088DD;
L_0087B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087B7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087B9;
L_0087B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087B9 AND
    cpu.logicAnd(0x1u);
    goto L_0087BB;
L_0087BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087BB BEQ -> $0087C0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0087C0; }
    goto L_0087BD;
L_0087BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu, 3u, 3u, cpu.address("abs", 0x8849u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087BD JMP -> $008849
    goto L_008849;
L_0087C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087C0 LDY
    cpu.setY(0x81u, 8);
    goto L_0087C2;
L_0087C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C2u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C2u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087C2 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_0087C5;
L_0087C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C5u, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087C5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087C8;
L_0087C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087C8 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_0087CB;
L_0087CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087CB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087CE;
L_0087CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CEu, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087CE STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_0087D1;
L_0087D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087D1 LDX
    cpu.setX(0x6u, 8);
    goto L_0087D3;
L_0087D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u, 4u + ((((0x8A16u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087D3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087D6;
L_0087D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087D6 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_0087D9;
L_0087D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D9u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087D9 DEX
    cpu.decReg('X');
    goto L_0087DA;
L_0087DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087DA BPL -> $0087D3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0087D3; }
    goto L_0087DC;
L_0087DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087DC LDA
    cpu.setA(0x2u, 8);
    goto L_0087DE;
L_0087DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DEu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087DE STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_0087E1;
L_0087E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E1u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E1u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087E1 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_0087E4;
L_0087E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E4u, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087E4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087E7;
L_0087E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087E7 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_0087EA;
L_0087EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EAu, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087EA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087ED;
L_0087ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087ED CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87EEu,0x0087EDu); return;
L_008849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8849u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8849u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8849u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008849 LDY
    cpu.setY(0x80u, 8);
    goto L_00884B;
L_00884B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Bu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Bu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00884B STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_00884E;
L_00884E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00884E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008851;
L_008851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8851u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8851u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008851 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008854;
L_008854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008854 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008857;
L_008857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008857 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_00885A;
L_00885A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00885A LDX
    cpu.setX(0x6u, 8);
    goto L_00885C;
L_00885C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Cu, 4u + ((((0x8A16u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00885C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00885F;
L_00885F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Fu, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00885F STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008862;
L_008862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8862u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8862u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008862 DEX
    cpu.decReg('X');
    goto L_008863;
L_008863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8863u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8863u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008863 BPL -> $00885C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00885C; }
    goto L_008865;
L_008865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8865u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8865u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008865 LDA
    cpu.setA(0x2u, 8);
    goto L_008867;
L_008867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8867u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8867u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008867 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_00886A;
L_00886A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Au,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Au, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00886A STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_00886D;
L_00886D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Du, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00886D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008870;
L_008870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8870u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8870u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008870 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008873;
L_008873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8873u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8873u, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008873 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008876;
L_008876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8876u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8876u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008876 CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8877u,0x008876u); return;
L_0088DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088DD LDA
    cpu.setA(0x0u, 8);
    goto L_0088DF;
L_0088DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088DF STA
    hw.write(cpu.address("abs", 0x1BE4u), cpu.a, cpu.m8?8:16);
    goto L_0088E2;
L_0088E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E2u, 4u, 3u, cpu.address("abs", 0x1CE6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088E2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088E5;
L_0088E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088E5 BNE -> $0088EA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0088EA; }
    goto L_0088E7;
L_0088E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E7u, 3u, 3u, cpu.address("abs", 0x8A10u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088E7 JMP -> $008A10
    goto L_008A10;
L_0088EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088EA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088EC;
L_0088EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ECu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088EC AND
    cpu.logicAnd(0x2u);
    goto L_0088EE;
L_0088EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088EE BEQ -> $0088F3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0088F3; }
    goto L_0088F0;
L_0088F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F0u, 3u, 3u, cpu.address("abs", 0x897Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088F0 JMP -> $00897C
    goto L_00897C;
L_0088F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088F3 LDY
    cpu.setY(0x81u, 8);
    goto L_0088F5;
L_0088F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F5u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F5u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088F5 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_0088F8;
L_0088F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F8u, 4u, 3u, cpu.address("abs", 0x1CE7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088F8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088FB;
L_0088FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088FB STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_0088FE;
L_0088FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FEu, 4u, 3u, cpu.address("abs", 0x1CE6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008901;
L_008901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8901u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8901u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008901 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008904;
L_008904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8904u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8904u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008904 LDX
    cpu.setX(0x6u, 8);
    goto L_008906;
L_008906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8906u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8906u, 4u + ((((0x8A32u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008906 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A32u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008909;
L_008909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8909u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8909u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008909 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_00890C;
L_00890C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00890C DEX
    cpu.decReg('X');
    goto L_00890D;
L_00890D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00890D BPL -> $008906
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008906; }
    goto L_00890F;
L_00890F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00890F LDA
    cpu.setA(0x2u, 8);
    goto L_008911;
L_008911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8911u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8911u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008911 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008914;
L_008914:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8914u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8914u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8914u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008914 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_008917;
L_008917:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8917u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8917u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8917u, 4u, 3u, cpu.address("abs", 0x1CE7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008917 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00891A;
L_00891A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x891Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x891Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x891Au, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00891A STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_00891D;
L_00891D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x891Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x891Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x891Du, 4u, 3u, cpu.address("abs", 0x1CE6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00891D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008920;
L_008920:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8920u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8920u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8920u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008920 CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8921u,0x008920u); return;
L_00897C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x897Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x897Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x897Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00897C LDY
    cpu.setY(0x80u, 8);
    goto L_00897E;
L_00897E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x897Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x897Eu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x897Eu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00897E STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_008981;
L_008981:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8981u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8981u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8981u, 4u, 3u, cpu.address("abs", 0x1CE7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008981 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008984;
L_008984:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8984u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8984u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8984u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008984 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008987;
L_008987:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8987u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8987u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8987u, 4u, 3u, cpu.address("abs", 0x1CE6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008987 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00898A;
L_00898A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x898Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x898Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x898Au, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00898A STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_00898D;
L_00898D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x898Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x898Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x898Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00898D LDX
    cpu.setX(0x6u, 8);
    goto L_00898F;
L_00898F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x898Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x898Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x898Fu, 4u + ((((0x8A32u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00898F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A32u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008992;
L_008992:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8992u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8992u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8992u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008992 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008995;
L_008995:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8995u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8995u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8995u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008995 DEX
    cpu.decReg('X');
    goto L_008996;
L_008996:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8996u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8996u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8996u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008996 BPL -> $00898F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00898F; }
    goto L_008998;
L_008998:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8998u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8998u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8998u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008998 LDA
    cpu.setA(0x2u, 8);
    goto L_00899A;
L_00899A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x899Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x899Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x899Au, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00899A STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_00899D;
L_00899D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x899Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x899Du,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x899Du, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00899D STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_0089A0;
L_0089A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A0u, 4u, 3u, cpu.address("abs", 0x1CE7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0089A0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0089A3;
L_0089A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A3u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0089A3 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_0089A6;
L_0089A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A6u, 4u, 3u, cpu.address("abs", 0x1CE6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0089A6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0089A9;
L_0089A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0089A9 CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x89AAu,0x0089A9u); return;
L_008A10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A10u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A10u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A10 LDA
    cpu.setA(0x0u, 8);
    goto L_008A12;
L_008A12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A12u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A12u, 4u, 3u, cpu.address("abs", 0x1CE6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A12 STA
    hw.write(cpu.address("abs", 0x1CE6u), cpu.a, cpu.m8?8:16);
    goto L_008A15;
L_008A15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A15u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A15u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $008A15 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x008A15u);return;} hw.unresolvedReturn(0x008A15u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0087AD_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0087ADu: goto L_0087AD;
    case 0x0087AFu: goto L_0087AF;
    case 0x0087B2u: goto L_0087B2;
    case 0x0087B4u: goto L_0087B4;
    case 0x0087B7u: goto L_0087B7;
    case 0x0087B9u: goto L_0087B9;
    case 0x0087BBu: goto L_0087BB;
    case 0x0087BDu: goto L_0087BD;
    case 0x0087C0u: goto L_0087C0;
    case 0x0087C2u: goto L_0087C2;
    case 0x0087C5u: goto L_0087C5;
    case 0x0087C8u: goto L_0087C8;
    case 0x0087CBu: goto L_0087CB;
    case 0x0087CEu: goto L_0087CE;
    case 0x0087D1u: goto L_0087D1;
    case 0x0087D3u: goto L_0087D3;
    case 0x0087D6u: goto L_0087D6;
    case 0x0087D9u: goto L_0087D9;
    case 0x0087DAu: goto L_0087DA;
    case 0x0087DCu: goto L_0087DC;
    case 0x0087DEu: goto L_0087DE;
    case 0x0087E1u: goto L_0087E1;
    case 0x0087E4u: goto L_0087E4;
    case 0x0087E7u: goto L_0087E7;
    case 0x0087EAu: goto L_0087EA;
    case 0x0087EDu: goto L_0087ED;
    case 0x0087EEu: goto L_0087EE;
    case 0x0087F0u: goto L_0087F0;
    case 0x0087F3u: goto L_0087F3;
    case 0x0087F5u: goto L_0087F5;
    case 0x0087F8u: goto L_0087F8;
    case 0x0087FBu: goto L_0087FB;
    case 0x0087FCu: goto L_0087FC;
    case 0x0087FEu: goto L_0087FE;
    case 0x008800u: goto L_008800;
    case 0x008803u: goto L_008803;
    case 0x008806u: goto L_008806;
    case 0x008809u: goto L_008809;
    case 0x00880Au: goto L_00880A;
    case 0x00880Du: goto L_00880D;
    case 0x008810u: goto L_008810;
    case 0x008813u: goto L_008813;
    case 0x008815u: goto L_008815;
    case 0x008818u: goto L_008818;
    case 0x00881Bu: goto L_00881B;
    case 0x00881Cu: goto L_00881C;
    case 0x00881Eu: goto L_00881E;
    case 0x008820u: goto L_008820;
    case 0x008823u: goto L_008823;
    case 0x008826u: goto L_008826;
    case 0x008829u: goto L_008829;
    case 0x00882Au: goto L_00882A;
    case 0x00882Du: goto L_00882D;
    case 0x008830u: goto L_008830;
    case 0x008831u: goto L_008831;
    case 0x008833u: goto L_008833;
    case 0x008836u: goto L_008836;
    case 0x008838u: goto L_008838;
    case 0x00883Bu: goto L_00883B;
    case 0x00883Eu: goto L_00883E;
    case 0x00883Fu: goto L_00883F;
    case 0x008841u: goto L_008841;
    case 0x008843u: goto L_008843;
    case 0x008846u: goto L_008846;
    case 0x008849u: goto L_008849;
    case 0x00884Bu: goto L_00884B;
    case 0x00884Eu: goto L_00884E;
    case 0x008851u: goto L_008851;
    case 0x008854u: goto L_008854;
    case 0x008857u: goto L_008857;
    case 0x00885Au: goto L_00885A;
    case 0x00885Cu: goto L_00885C;
    case 0x00885Fu: goto L_00885F;
    case 0x008862u: goto L_008862;
    case 0x008863u: goto L_008863;
    case 0x008865u: goto L_008865;
    case 0x008867u: goto L_008867;
    case 0x00886Au: goto L_00886A;
    case 0x00886Du: goto L_00886D;
    case 0x008870u: goto L_008870;
    case 0x008873u: goto L_008873;
    case 0x008876u: goto L_008876;
    case 0x008877u: goto L_008877;
    case 0x008879u: goto L_008879;
    case 0x00887Cu: goto L_00887C;
    case 0x00887Eu: goto L_00887E;
    case 0x008881u: goto L_008881;
    case 0x008884u: goto L_008884;
    case 0x008885u: goto L_008885;
    case 0x008887u: goto L_008887;
    case 0x008889u: goto L_008889;
    case 0x00888Cu: goto L_00888C;
    case 0x00888Eu: goto L_00888E;
    case 0x008891u: goto L_008891;
    case 0x008894u: goto L_008894;
    case 0x008897u: goto L_008897;
    case 0x008898u: goto L_008898;
    case 0x00889Au: goto L_00889A;
    case 0x00889Du: goto L_00889D;
    case 0x0088A0u: goto L_0088A0;
    case 0x0088A3u: goto L_0088A3;
    case 0x0088A5u: goto L_0088A5;
    case 0x0088A8u: goto L_0088A8;
    case 0x0088ABu: goto L_0088AB;
    case 0x0088ACu: goto L_0088AC;
    case 0x0088AEu: goto L_0088AE;
    case 0x0088B0u: goto L_0088B0;
    case 0x0088B3u: goto L_0088B3;
    case 0x0088B6u: goto L_0088B6;
    case 0x0088B9u: goto L_0088B9;
    case 0x0088BAu: goto L_0088BA;
    case 0x0088BCu: goto L_0088BC;
    case 0x0088BFu: goto L_0088BF;
    case 0x0088C2u: goto L_0088C2;
    case 0x0088C3u: goto L_0088C3;
    case 0x0088C5u: goto L_0088C5;
    case 0x0088C8u: goto L_0088C8;
    case 0x0088CAu: goto L_0088CA;
    case 0x0088CDu: goto L_0088CD;
    case 0x0088D0u: goto L_0088D0;
    case 0x0088D1u: goto L_0088D1;
    case 0x0088D3u: goto L_0088D3;
    case 0x0088D5u: goto L_0088D5;
    case 0x0088D8u: goto L_0088D8;
    case 0x0088DAu: goto L_0088DA;
    case 0x0088DDu: goto L_0088DD;
    case 0x0088DFu: goto L_0088DF;
    case 0x0088E2u: goto L_0088E2;
    case 0x0088E5u: goto L_0088E5;
    case 0x0088E7u: goto L_0088E7;
    case 0x0088EAu: goto L_0088EA;
    case 0x0088ECu: goto L_0088EC;
    case 0x0088EEu: goto L_0088EE;
    case 0x0088F0u: goto L_0088F0;
    case 0x0088F3u: goto L_0088F3;
    case 0x0088F5u: goto L_0088F5;
    case 0x0088F8u: goto L_0088F8;
    case 0x0088FBu: goto L_0088FB;
    case 0x0088FEu: goto L_0088FE;
    case 0x008901u: goto L_008901;
    case 0x008904u: goto L_008904;
    case 0x008906u: goto L_008906;
    case 0x008909u: goto L_008909;
    case 0x00890Cu: goto L_00890C;
    case 0x00890Du: goto L_00890D;
    case 0x00890Fu: goto L_00890F;
    case 0x008911u: goto L_008911;
    case 0x008914u: goto L_008914;
    case 0x008917u: goto L_008917;
    case 0x00891Au: goto L_00891A;
    case 0x00891Du: goto L_00891D;
    case 0x008920u: goto L_008920;
    case 0x008921u: goto L_008921;
    case 0x008923u: goto L_008923;
    case 0x008926u: goto L_008926;
    case 0x008928u: goto L_008928;
    case 0x00892Bu: goto L_00892B;
    case 0x00892Eu: goto L_00892E;
    case 0x00892Fu: goto L_00892F;
    case 0x008931u: goto L_008931;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0087AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087AD SEP
    cpu.sep(0x30u);
    goto L_0087AF;
L_0087AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087AF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087B2;
L_0087B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087B2 BNE -> $0087B7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0087B7; }
    goto L_0087B4;
L_0087B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u, 3u, 3u, cpu.address("abs", 0x88DDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087B4 JMP -> $0088DD
    goto L_0088DD;
L_0087B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087B7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087B9;
L_0087B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087B9 AND
    cpu.logicAnd(0x1u);
    goto L_0087BB;
L_0087BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087BB BEQ -> $0087C0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0087C0; }
    goto L_0087BD;
L_0087BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu, 3u, 3u, cpu.address("abs", 0x8849u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087BD JMP -> $008849
    goto L_008849;
L_0087C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087C0 LDY
    cpu.setY(0x81u, 8);
    goto L_0087C2;
L_0087C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C2u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C2u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087C2 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_0087C5;
L_0087C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C5u, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087C5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087C8;
L_0087C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087C8 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_0087CB;
L_0087CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087CB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087CE;
L_0087CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CEu, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087CE STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_0087D1;
L_0087D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087D1 LDX
    cpu.setX(0x6u, 8);
    goto L_0087D3;
L_0087D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u, 4u + ((((0x8A16u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087D3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087D6;
L_0087D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087D6 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_0087D9;
L_0087D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D9u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087D9 DEX
    cpu.decReg('X');
    goto L_0087DA;
L_0087DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087DA BPL -> $0087D3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0087D3; }
    goto L_0087DC;
L_0087DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087DC LDA
    cpu.setA(0x2u, 8);
    goto L_0087DE;
L_0087DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DEu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087DE STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_0087E1;
L_0087E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E1u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E1u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087E1 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_0087E4;
L_0087E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E4u, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087E4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087E7;
L_0087E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087E7 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_0087EA;
L_0087EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EAu, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087EA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087ED;
L_0087ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087ED CLC
    cpu.setFlag('C', false);
    goto L_0087EE;
L_0087EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EEu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087EE ADC
    cpu.adc(0x8u);
    goto L_0087F0;
L_0087F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F0u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087F0 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_0087F3;
L_0087F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087F3 LDX
    cpu.setX(0x6u, 8);
    goto L_0087F5;
L_0087F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F5u, 4u + ((((0x8A1Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087F5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A1Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087F8;
L_0087F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F8u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087F8 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_0087FB;
L_0087FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087FB DEX
    cpu.decReg('X');
    goto L_0087FC;
L_0087FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087FC BPL -> $0087F5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0087F5; }
    goto L_0087FE;
L_0087FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087FE LDA
    cpu.setA(0x2u, 8);
    goto L_008800;
L_008800:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8800u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8800u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8800u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008800 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008803;
L_008803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8803u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8803u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8803u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008803 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_008806;
L_008806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8806u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8806u, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008806 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008809;
L_008809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8809u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8809u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008809 INC
    cpu.inc('A');
    goto L_00880A;
L_00880A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Au, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00880A STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_00880D;
L_00880D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Du, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00880D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008810;
L_008810:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8810u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8810u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8810u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008810 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008813;
L_008813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8813u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8813u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008813 LDX
    cpu.setX(0x6u, 8);
    goto L_008815;
L_008815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8815u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8815u, 4u + ((((0x8A24u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008815 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008818;
L_008818:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8818u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8818u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8818u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008818 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_00881B;
L_00881B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00881B DEX
    cpu.decReg('X');
    goto L_00881C;
L_00881C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00881C BPL -> $008815
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008815; }
    goto L_00881E;
L_00881E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00881E LDA
    cpu.setA(0x2u, 8);
    goto L_008820;
L_008820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8820u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8820u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008820 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008823;
L_008823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8823u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8823u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008823 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_008826;
L_008826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8826u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8826u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8826u, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008826 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008829;
L_008829:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8829u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8829u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8829u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008829 INC
    cpu.inc('A');
    goto L_00882A;
L_00882A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Au, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00882A STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_00882D;
L_00882D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Du, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00882D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008830;
L_008830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008830 CLC
    cpu.setFlag('C', false);
    goto L_008831;
L_008831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8831u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8831u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008831 ADC
    cpu.adc(0x8u);
    goto L_008833;
L_008833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8833u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8833u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008833 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008836;
L_008836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8836u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8836u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008836 LDX
    cpu.setX(0x6u, 8);
    goto L_008838;
L_008838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8838u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8838u, 4u + ((((0x8A2Bu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A2Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008838 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A2Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00883B;
L_00883B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Bu, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00883B STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_00883E;
L_00883E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00883E DEX
    cpu.decReg('X');
    goto L_00883F;
L_00883F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00883F BPL -> $008838
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008838; }
    goto L_008841;
L_008841:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8841u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8841u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8841u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008841 LDA
    cpu.setA(0x2u, 8);
    goto L_008843;
L_008843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008843 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008846;
L_008846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8846u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8846u, 3u, 3u, cpu.address("abs", 0x88DDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008846 JMP -> $0088DD
    goto L_0088DD;
L_008849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8849u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8849u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8849u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008849 LDY
    cpu.setY(0x80u, 8);
    goto L_00884B;
L_00884B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Bu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Bu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00884B STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_00884E;
L_00884E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00884E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008851;
L_008851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8851u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8851u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008851 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008854;
L_008854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8854u, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008854 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008857;
L_008857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8857u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008857 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_00885A;
L_00885A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00885A LDX
    cpu.setX(0x6u, 8);
    goto L_00885C;
L_00885C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Cu, 4u + ((((0x8A16u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00885C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00885F;
L_00885F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Fu, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00885F STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008862;
L_008862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8862u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8862u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008862 DEX
    cpu.decReg('X');
    goto L_008863;
L_008863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8863u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8863u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008863 BPL -> $00885C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00885C; }
    goto L_008865;
L_008865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8865u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8865u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008865 LDA
    cpu.setA(0x2u, 8);
    goto L_008867;
L_008867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8867u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8867u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008867 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_00886A;
L_00886A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Au,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Au, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00886A STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_00886D;
L_00886D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x886Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x886Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x886Du, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00886D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008870;
L_008870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8870u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8870u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008870 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008873;
L_008873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8873u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8873u, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008873 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008876;
L_008876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8876u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8876u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008876 CLC
    cpu.setFlag('C', false);
    goto L_008877;
L_008877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8877u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8877u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8877u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008877 ADC
    cpu.adc(0x4u);
    goto L_008879;
L_008879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8879u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8879u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008879 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_00887C;
L_00887C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00887C LDX
    cpu.setX(0x6u, 8);
    goto L_00887E;
L_00887E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Eu, 4u + ((((0x8A1Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00887E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A1Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008881;
L_008881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8881u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8881u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008881 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008884;
L_008884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8884u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8884u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008884 DEX
    cpu.decReg('X');
    goto L_008885;
L_008885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8885u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8885u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008885 BPL -> $00887E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00887E; }
    goto L_008887;
L_008887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8887u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8887u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008887 LDA
    cpu.setA(0x40u, 8);
    goto L_008889;
L_008889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8889u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8889u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8889u, 4u, 3u, cpu.address("abs", 0x4315u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008889 STA
    hw.write(cpu.address("abs", 0x4315u), cpu.a, cpu.m8?8:16);
    goto L_00888C;
L_00888C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00888C LDA
    cpu.setA(0x2u, 8);
    goto L_00888E;
L_00888E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00888E STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008891;
L_008891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008891 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_008894;
L_008894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8894u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8894u, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008894 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008897;
L_008897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8897u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8897u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008897 CLC
    cpu.setFlag('C', false);
    goto L_008898;
L_008898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8898u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008898 ADC
    cpu.adc(0x20u);
    goto L_00889A;
L_00889A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Au, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00889A STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_00889D;
L_00889D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00889D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088A0;
L_0088A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A0u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088A0 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_0088A3;
L_0088A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088A3 LDX
    cpu.setX(0x6u, 8);
    goto L_0088A5;
L_0088A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A5u, 4u + ((((0x8A24u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088A5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088A8;
L_0088A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A8u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088A8 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_0088AB;
L_0088AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ABu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088AB DEX
    cpu.decReg('X');
    goto L_0088AC;
L_0088AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088AC BPL -> $0088A5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0088A5; }
    goto L_0088AE;
L_0088AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88AEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088AE LDA
    cpu.setA(0x2u, 8);
    goto L_0088B0;
L_0088B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B0u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088B0 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_0088B3;
L_0088B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B3u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B3u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088B3 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_0088B6;
L_0088B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B6u, 4u, 3u, cpu.address("abs", 0x1BE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088B6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088B9;
L_0088B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088B9 CLC
    cpu.setFlag('C', false);
    goto L_0088BA;
L_0088BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088BA ADC
    cpu.adc(0x20u);
    goto L_0088BC;
L_0088BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BCu, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088BC STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_0088BF;
L_0088BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BFu, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088BF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088C2;
L_0088C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088C2 CLC
    cpu.setFlag('C', false);
    goto L_0088C3;
L_0088C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088C3 ADC
    cpu.adc(0x4u);
    goto L_0088C5;
L_0088C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C5u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088C5 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_0088C8;
L_0088C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088C8 LDX
    cpu.setX(0x6u, 8);
    goto L_0088CA;
L_0088CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CAu, 4u + ((((0x8A2Bu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A2Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088CA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A2Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088CD;
L_0088CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CDu, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088CD STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_0088D0;
L_0088D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088D0 DEX
    cpu.decReg('X');
    goto L_0088D1;
L_0088D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088D1 BPL -> $0088CA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0088CA; }
    goto L_0088D3;
L_0088D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088D3 LDA
    cpu.setA(0x40u, 8);
    goto L_0088D5;
L_0088D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D5u, 4u, 3u, cpu.address("abs", 0x4315u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088D5 STA
    hw.write(cpu.address("abs", 0x4315u), cpu.a, cpu.m8?8:16);
    goto L_0088D8;
L_0088D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088D8 LDA
    cpu.setA(0x2u, 8);
    goto L_0088DA;
L_0088DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DAu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088DA STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_0088DD;
L_0088DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088DD LDA
    cpu.setA(0x0u, 8);
    goto L_0088DF;
L_0088DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu, 4u, 3u, cpu.address("abs", 0x1BE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088DF STA
    hw.write(cpu.address("abs", 0x1BE4u), cpu.a, cpu.m8?8:16);
    goto L_0088E2;
L_0088E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E2u, 4u, 3u, cpu.address("abs", 0x1CE6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088E2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088E5;
L_0088E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088E5 BNE -> $0088EA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0088EA; }
    goto L_0088E7;
L_0088E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E7u, 3u, 3u, cpu.address("abs", 0x8A10u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088E7 JMP -> $008A10
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8A10u),0x0088E7u); return;
L_0088EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088EA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088EC;
L_0088EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ECu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088EC AND
    cpu.logicAnd(0x2u);
    goto L_0088EE;
L_0088EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088EE BEQ -> $0088F3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0088F3; }
    goto L_0088F0;
L_0088F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F0u, 3u, 3u, cpu.address("abs", 0x897Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088F0 JMP -> $00897C
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x897Cu),0x0088F0u); return;
L_0088F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088F3 LDY
    cpu.setY(0x81u, 8);
    goto L_0088F5;
L_0088F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F5u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F5u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088F5 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_0088F8;
L_0088F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F8u, 4u, 3u, cpu.address("abs", 0x1CE7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088F8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0088FB;
L_0088FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088FB STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_0088FE;
L_0088FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FEu, 4u, 3u, cpu.address("abs", 0x1CE6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0088FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008901;
L_008901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8901u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8901u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008901 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008904;
L_008904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8904u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8904u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008904 LDX
    cpu.setX(0x6u, 8);
    goto L_008906;
L_008906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8906u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8906u, 4u + ((((0x8A32u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008906 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A32u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008909;
L_008909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8909u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8909u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008909 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_00890C;
L_00890C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00890C DEX
    cpu.decReg('X');
    goto L_00890D;
L_00890D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00890D BPL -> $008906
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008906; }
    goto L_00890F;
L_00890F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00890F LDA
    cpu.setA(0x2u, 8);
    goto L_008911;
L_008911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8911u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8911u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008911 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008914;
L_008914:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8914u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8914u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8914u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008914 STY
    hw.write(cpu.address("abs", 0x2115u), cpu.y, cpu.x8?8:16);
    goto L_008917;
L_008917:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8917u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8917u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8917u, 4u, 3u, cpu.address("abs", 0x1CE7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008917 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00891A;
L_00891A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x891Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x891Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x891Au, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00891A STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_00891D;
L_00891D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x891Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x891Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x891Du, 4u, 3u, cpu.address("abs", 0x1CE6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00891D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1CE6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008920;
L_008920:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8920u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8920u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8920u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008920 CLC
    cpu.setFlag('C', false);
    goto L_008921;
L_008921:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8921u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8921u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8921u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008921 ADC
    cpu.adc(0x8u);
    goto L_008923;
L_008923:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8923u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8923u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8923u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008923 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008926;
L_008926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8926u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8926u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008926 LDX
    cpu.setX(0x6u, 8);
    goto L_008928;
L_008928:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8928u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8928u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8928u, 4u + ((((0x8A39u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8A39u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008928 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8A39u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00892B;
L_00892B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x892Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x892Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x892Bu, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00892B STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_00892E;
L_00892E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x892Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x892Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x892Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00892E DEX
    cpu.decReg('X');
    goto L_00892F;
L_00892F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x892Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x892Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x892Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00892F BPL -> $008928
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008928; }
    goto L_008931;
L_008931:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8931u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8931u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8931u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008931 LDA
    cpu.setA(0x2u, 8);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8933u,0x008931u); return;
}

void sub_008D90_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008D90u: goto L_008D90;
    case 0x008D92u: goto L_008D92;
    case 0x008D94u: goto L_008D94;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008D90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D90u,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D90u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x18u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $008D90 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0x18u), cpu.m8?8:16));
    goto L_008D92;
L_008D92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D92u,cpu,0x81u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D92u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Cu + cpu.x) & 0xFFFFu), 2u, 0u);
    // $008D92 STA
    hw.write(cpu.addressDpIndirectX(hw, 0x8Cu), cpu.a, cpu.m8?8:16);
    goto L_008D94;
L_008D94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D94u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D94u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $008D94 BRK
    hw.partial(0x008D94u, "BRK"); return;
}

void sub_009391_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x009391u: goto L_009391;
    case 0x009394u: goto L_009394;
    case 0x009397u: goto L_009397;
    case 0x00939Au: goto L_00939A;
    case 0x00939Cu: goto L_00939C;
    case 0x00939Eu: goto L_00939E;
    case 0x0093A1u: goto L_0093A1;
    case 0x0093A4u: goto L_0093A4;
    case 0x0093A6u: goto L_0093A6;
    case 0x0093A9u: goto L_0093A9;
    case 0x0093ACu: goto L_0093AC;
    case 0x0093AFu: goto L_0093AF;
    case 0x0093B1u: goto L_0093B1;
    case 0x0093B4u: goto L_0093B4;
    case 0x0093B5u: goto L_0093B5;
    case 0x0093B6u: goto L_0093B6;
    case 0x0093B7u: goto L_0093B7;
    case 0x0093B8u: goto L_0093B8;
    case 0x0093B9u: goto L_0093B9;
    case 0x0093BBu: goto L_0093BB;
    case 0x0093BDu: goto L_0093BD;
    case 0x0093C0u: goto L_0093C0;
    case 0x0093C2u: goto L_0093C2;
    case 0x0093C5u: goto L_0093C5;
    case 0x0093C7u: goto L_0093C7;
    case 0x0093CAu: goto L_0093CA;
    case 0x0093CCu: goto L_0093CC;
    case 0x0093CFu: goto L_0093CF;
    case 0x0093D1u: goto L_0093D1;
    case 0x0093D4u: goto L_0093D4;
    case 0x0093D7u: goto L_0093D7;
    case 0x0093DAu: goto L_0093DA;
    case 0x0093DDu: goto L_0093DD;
    case 0x0093E0u: goto L_0093E0;
    case 0x0093E3u: goto L_0093E3;
    case 0x0093E6u: goto L_0093E6;
    case 0x0093E8u: goto L_0093E8;
    case 0x0093EAu: goto L_0093EA;
    case 0x0093ECu: goto L_0093EC;
    case 0x0093EFu: goto L_0093EF;
    case 0x0093F1u: goto L_0093F1;
    case 0x0093F4u: goto L_0093F4;
    case 0x0093F7u: goto L_0093F7;
    case 0x0093F9u: goto L_0093F9;
    case 0x0093FCu: goto L_0093FC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_009391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9391u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9391u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9391u, 6u, 3u, cpu.address("abs", 0x85FAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009391 JSR -> $0085FA stack real
    { cpu.push16Value(hw,0x9393u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9394u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85FAu), 0x009391u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009394;
L_009394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9394u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9394u,0x009394u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9394u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9394u, 6u, 3u, cpu.address("abs", 0x8A79u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009394 JSR -> $008A79 stack real
    { cpu.push16Value(hw,0x9396u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9397u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8A79u), 0x009394u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009397;
L_009397:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9397u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9397u,0x009397u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9397u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9397u, 6u, 3u, cpu.address("abs", 0xA993u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009397 JSR -> $00A993 stack real
    { cpu.push16Value(hw,0x9399u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x939Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA993u), 0x009397u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00939A;
L_00939A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x939Au))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x939Au,0x00939Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x939Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x939Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00939A LDY
    cpu.setY(0xCu, 8);
    goto L_00939C;
L_00939C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x939Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x939Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x939Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00939C LDX
    cpu.setX(0x3u, 8);
    goto L_00939E;
L_00939E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x939Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x939Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x939Eu, 4u + ((((0x9389u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9389u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00939E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9389u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0093A1;
L_0093A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A1u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A1u, 5u, 3u, cpu.address("absy", 0x0200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093A1 STA
    hw.write(cpu.address("absy", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_0093A4;
L_0093A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093A4 LDA
    cpu.setA(0x70u, 8);
    goto L_0093A6;
L_0093A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A6u, 5u, 3u, cpu.address("absy", 0x0201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093A6 STA
    hw.write(cpu.address("absy", 0x201u), cpu.a, cpu.m8?8:16);
    goto L_0093A9;
L_0093A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A9u, 4u + ((((0x938Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x938Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093A9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x938Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0093AC;
L_0093AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ACu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ACu, 5u, 3u, cpu.address("absy", 0x0202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093AC STA
    hw.write(cpu.address("absy", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_0093AF;
L_0093AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93AFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093AF LDA
    cpu.setA(0x30u, 8);
    goto L_0093B1;
L_0093B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B1u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B1u, 5u, 3u, cpu.address("absy", 0x0203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093B1 STA
    hw.write(cpu.address("absy", 0x203u), cpu.a, cpu.m8?8:16);
    goto L_0093B4;
L_0093B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B4u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093B4 DEY
    cpu.decReg('Y');
    goto L_0093B5;
L_0093B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B5u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093B5 DEY
    cpu.decReg('Y');
    goto L_0093B6;
L_0093B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B6u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093B6 DEY
    cpu.decReg('Y');
    goto L_0093B7;
L_0093B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B7u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093B7 DEY
    cpu.decReg('Y');
    goto L_0093B8;
L_0093B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B8u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093B8 DEX
    cpu.decReg('X');
    goto L_0093B9;
L_0093B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093B9 BPL -> $00939E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00939E; }
    goto L_0093BB;
L_0093BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093BB LDA
    cpu.setA(0xAAu, 8);
    goto L_0093BD;
L_0093BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93BDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93BDu, 4u, 3u, cpu.address("abs", 0x0400u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093BD STA
    hw.write(cpu.address("abs", 0x400u), cpu.a, cpu.m8?8:16);
    goto L_0093C0;
L_0093C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093C0 LDA
    cpu.setA(0x1u, 8);
    goto L_0093C2;
L_0093C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C2u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093C2 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_0093C5;
L_0093C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093C5 LDA
    cpu.setA(0x40u, 8);
    goto L_0093C7;
L_0093C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C7u, 4u, 3u, cpu.address("abs", 0x1DF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093C7 STA
    hw.write(cpu.address("abs", 0x1DF5u), cpu.a, cpu.m8?8:16);
    goto L_0093CA;
L_0093CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093CA LDA
    cpu.setA(0xFu, 8);
    goto L_0093CC;
L_0093CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CCu, 4u, 3u, cpu.address("abs", 0x0DAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093CC STA
    hw.write(cpu.address("abs", 0xDAEu), cpu.a, cpu.m8?8:16);
    goto L_0093CF;
L_0093CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093CF LDA
    cpu.setA(0x1u, 8);
    goto L_0093D1;
L_0093D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D1u, 4u, 3u, cpu.address("abs", 0x0DAFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093D1 STA
    hw.write(cpu.address("abs", 0xDAFu), cpu.a, cpu.m8?8:16);
    goto L_0093D4;
L_0093D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D4u, 4u, 3u, cpu.address("abs", 0x192Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093D4 STZ
    hw.write(cpu.address("abs", 0x192Eu), 0, cpu.m8?8:16);
    goto L_0093D7;
L_0093D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D7u, 6u, 3u, cpu.address("abs", 0xABEDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093D7 JSR -> $00ABED stack real
    { cpu.push16Value(hw,0x93D9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93DAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABEDu), 0x0093D7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0093DA;
L_0093DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DAu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93DAu,0x0093DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DAu, 4u, 3u, cpu.address("abs", 0x0701u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093DA STZ
    hw.write(cpu.address("abs", 0x701u), 0, cpu.m8?8:16);
    goto L_0093DD;
L_0093DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DDu, 4u, 3u, cpu.address("abs", 0x0702u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093DD STZ
    hw.write(cpu.address("abs", 0x702u), 0, cpu.m8?8:16);
    goto L_0093E0;
L_0093E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E0u, 6u, 3u, cpu.address("abs", 0x922Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093E0 JSR -> $00922F stack real
    { cpu.push16Value(hw,0x93E2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93E3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x922Fu), 0x0093E0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0093E3;
L_0093E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E3u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93E3u,0x0093E3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E3u, 4u, 3u, cpu.address("abs", 0x1B92u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093E3 STZ
    hw.write(cpu.address("abs", 0x1B92u), 0, cpu.m8?8:16);
    goto L_0093E6;
L_0093E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093E6 LDX
    cpu.setX(0x10u, 8);
    goto L_0093E8;
L_0093E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093E8 LDY
    cpu.setY(0x4u, 8);
    goto L_0093EA;
L_0093EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EA LDA
    cpu.setA(0x1u, 8);
    goto L_0093EC;
L_0093EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ECu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ECu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EC STA
    hw.write(cpu.address("abs", 0xD9Bu), cpu.a, cpu.m8?8:16);
    goto L_0093EF;
L_0093EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EF LDA
    cpu.setA(0x20u, 8);
    goto L_0093F1;
L_0093F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F1u, 6u, 3u, cpu.address("abs", 0x93FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093F1 JSR -> $0093FD stack real
    { cpu.push16Value(hw,0x93F3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93F4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x93FDu), 0x0093F1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0093F4;
L_0093F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F4u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93F4u,0x0093F4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u, 6u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F4 INC
    cpu.incMem(hw, cpu.address("abs", 0x100u), cpu.m8?8:16);
    goto L_0093F7;
L_0093F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F7 LDA
    cpu.setA(0x81u, 8);
    goto L_0093F9;
L_0093F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F9 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_0093FC;
L_0093FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093FC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0093FCu);return;} hw.unresolvedReturn(0x0093FCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00CEB1_E1M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CFF7u: goto L_00CFF7;
    case 0x00CFF8u: goto L_00CFF8;
    case 0x00CFFBu: goto L_00CFFB;
    case 0x00CFFCu: goto L_00CFFC;
    case 0x00CFFFu: goto L_00CFFF;
    case 0x00D002u: goto L_00D002;
    case 0x00D003u: goto L_00D003;
    case 0x00D006u: goto L_00D006;
    case 0x00D007u: goto L_00D007;
    case 0x00D00Au: goto L_00D00A;
    case 0x00D00Du: goto L_00D00D;
    case 0x00D00Fu: goto L_00D00F;
    case 0x00D010u: goto L_00D010;
    case 0x00D012u: goto L_00D012;
    case 0x00D014u: goto L_00D014;
    case 0x00D016u: goto L_00D016;
    case 0x00D018u: goto L_00D018;
    case 0x00D01Au: goto L_00D01A;
    case 0x00D01Du: goto L_00D01D;
    case 0x00D01Fu: goto L_00D01F;
    case 0x00D020u: goto L_00D020;
    case 0x00D022u: goto L_00D022;
    case 0x00D024u: goto L_00D024;
    case 0x00D026u: goto L_00D026;
    case 0x00D028u: goto L_00D028;
    case 0x00D02Au: goto L_00D02A;
    case 0x00D02Du: goto L_00D02D;
    case 0x00D02Eu: goto L_00D02E;
    case 0x00D030u: goto L_00D030;
    case 0x00D033u: goto L_00D033;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CFF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFF7 LSR
    cpu.lsrA();
    goto L_00CFF8;
L_00CFF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF8u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF8u, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFF8 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13E5u), cpu.m8?8:16));
    goto L_00CFFB;
L_00CFFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFFB TAY
    cpu.transfer("TAY");
    goto L_00CFFC;
L_00CFFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFCu, 4u + ((((0xDC7Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDC7Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFFC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDC7Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFFF;
L_00CFFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFFu, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFFF STA
    hw.write(cpu.address("abs", 0x1496u), cpu.a, cpu.m8?8:16);
    goto L_00D002;
L_00D002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD002u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD002u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D002 XBA
    cpu.xba();
    goto L_00D003;
L_00D003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD003u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD003u, 4u, 3u, cpu.address("abs", 0x13DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D003 STA
    hw.write(cpu.address("abs", 0x13DBu), cpu.a, cpu.m8?8:16);
    goto L_00D006;
L_00D006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD006u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD006u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D006 CLC
    cpu.setFlag('C', false);
    goto L_00D007;
L_00D007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD007u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD007u, 4u, 3u, cpu.address("abs", 0x13DEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D007 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x13DEu), cpu.m8?8:16));
    goto L_00D00A;
L_00D00A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD00Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Au,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Au, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D00A LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x148Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00D00D;
L_00D00D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD00Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D00D BEQ -> $00D014
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D014; }
    goto L_00D00F;
L_00D00F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD00Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D00F CLC
    cpu.setFlag('C', false);
    goto L_00D010;
L_00D010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD010u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD010u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D010 ADC
    cpu.adc(0x7u);
    goto L_00D012;
L_00D012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD012u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD012u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D012 BRA -> $00D01A
    goto L_00D01A;
L_00D014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD014u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD014u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D014 CPX
    cpu.compareX(0x2Fu);
    goto L_00D016;
L_00D016:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD016u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD016u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD016u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D016 BCC -> $00D01A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00D01A; }
    goto L_00D018;
L_00D018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD018u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD018u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D018 ADC
    cpu.adc(0x3u);
    goto L_00D01A;
L_00D01A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Au,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Au, 4u, 3u, cpu.address("abs", 0x13E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D01A LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x13E3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00D01D;
L_00D01D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D01D BEQ -> $00D030
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D030; }
    goto L_00D01F;
L_00D01F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Fu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D01F TYA
    cpu.transfer("TYA");
    goto L_00D020;
L_00D020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD020u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD020u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D020 AND
    cpu.logicAnd(0x1u);
    goto L_00D022;
L_00D022:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD022u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD022u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD022u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D022 STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_00D024;
L_00D024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD024u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD024u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D024 LDA
    cpu.setA(0x10u, 8);
    goto L_00D026;
L_00D026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD026u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD026u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D026 CPY
    cpu.compareY(0x6u);
    goto L_00D028;
L_00D028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD028u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD028u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D028 BCC -> $00D030
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00D030; }
    goto L_00D02A;
L_00D02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Au, 4u, 3u, cpu.address("abs", 0x13DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D02A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13DBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D02D;
L_00D02D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D02D CLC
    cpu.setFlag('C', false);
    goto L_00D02E;
L_00D02E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D02E ADC
    cpu.adc(0x11u);
    goto L_00D030;
L_00D030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD030u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD030u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D030 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00D033;
L_00D033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD033u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD033u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00D033 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00D033u);return;} hw.unresolvedReturn(0x00D033u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_00CC68_E0M1X1CQ_part7(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00DBDEu: goto L_00DBDE;
    case 0x00DBE0u: goto L_00DBE0;
    case 0x00DBE2u: goto L_00DBE2;
    case 0x00DBE4u: goto L_00DBE4;
    case 0x00DBE6u: goto L_00DBE6;
    case 0x00DBE8u: goto L_00DBE8;
    case 0x00DBE9u: goto L_00DBE9;
    case 0x00DBEAu: goto L_00DBEA;
    case 0x00DBECu: goto L_00DBEC;
    case 0x00DBEDu: goto L_00DBED;
    case 0x00DBF0u: goto L_00DBF0;
    case 0x00DBF2u: goto L_00DBF2;
    case 0x00DBF4u: goto L_00DBF4;
    case 0x00DBF6u: goto L_00DBF6;
    case 0x00DBF7u: goto L_00DBF7;
    case 0x00DBF8u: goto L_00DBF8;
    case 0x00DBFAu: goto L_00DBFA;
    case 0x00DBFCu: goto L_00DBFC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00DBDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBDEu))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBDE BEQ -> $00DBE8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DBE8; }
    goto L_00DBE0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBDE BEQ -> $00DBE8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DBE8; }
    goto L_00DBE0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBDE BEQ -> $00DBE8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DBE8; }
    goto L_00DBE0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBDE BEQ -> $00DBE8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DBE8; }
    goto L_00DBE0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBDEu,0x00DBDEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE0u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBE2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBE2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBE2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBE2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBE0u,0x00DBE0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE2u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE2 BPL -> $00DC00
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC00u,0x00DBE2u); return; }
    goto L_00DBE4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE2 BPL -> $00DC00
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC00u,0x00DBE2u); return; }
    goto L_00DBE4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE2 BPL -> $00DC00
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC00u,0x00DBE2u); return; }
    goto L_00DBE4;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE2 BPL -> $00DC00
    if (!cpu.n) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00DC00u,0x00DBE2u); return; }
    goto L_00DBE4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBE2u,0x00DBE2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE4u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE4u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE4 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x8Cu), cpu.x8?8:16));
    goto L_00DBE6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE4u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE4 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x8Cu), cpu.x8?8:16));
    goto L_00DBE6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE4u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE4 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x8Cu), cpu.x8?8:16));
    goto L_00DBE6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE4u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE4 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x8Cu), cpu.x8?8:16));
    goto L_00DBE6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBE4u,0x00DBE4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE6u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE6 BEQ -> $00DBF2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DBF2; }
    goto L_00DBE8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE6 BEQ -> $00DBF2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DBF2; }
    goto L_00DBE8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE6 BEQ -> $00DBF2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DBF2; }
    goto L_00DBE8;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE6 BEQ -> $00DBF2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DBF2; }
    goto L_00DBE8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBE6u,0x00DBE6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE8u))return;
  // 15 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE8 TXA
    cpu.transfer("TXA");
    goto L_00DBE9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE8 TXA
    cpu.transfer("TXA");
    goto L_00DBE9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE8 TXA
    cpu.transfer("TXA");
    goto L_00DBE9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE8 TXA
    cpu.transfer("TXA");
    goto L_00DBE9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE8 TXA
    cpu.transfer("TXA");
    goto L_00DBE9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBE8u,0x00DBE8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE9u))return;
  // 15 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE9 ASL
    cpu.aslA();
    goto L_00DBEA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE9 ASL
    cpu.aslA();
    goto L_00DBEA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE9 ASL
    cpu.aslA();
    goto L_00DBEA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE9 ASL
    cpu.aslA();
    goto L_00DBEA;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE9 ASL
    cpu.aslA();
    goto L_00DBEA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBE9u,0x00DBE9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBEAu))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEAu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBEA ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16));
    goto L_00DBEC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEAu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBEA ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16));
    goto L_00DBEC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEAu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBEA ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16));
    goto L_00DBEC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEAu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBEA ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16));
    goto L_00DBEC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBEAu,0x00DBEAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBECu))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBEC TAX
    cpu.transfer("TAX");
    goto L_00DBED;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBEC TAX
    cpu.transfer("TAX");
    goto L_00DBED;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBEC TAX
    cpu.transfer("TAX");
    goto L_00DBED;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBEC TAX
    cpu.transfer("TAX");
    goto L_00DBED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBECu,0x00DBECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBEDu))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEDu, 5u + ((((0xDAB7u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDAB7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBED LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDAB7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEDu, 4u + 1u, 3u, cpu.address("absx", 0xDAB7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBED LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDAB7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEDu, 4u + ((((0xDAB7u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDAB7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBED LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDAB7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEDu, 4u + ((((0xDAB7u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDAB7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBED LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDAB7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBEDu,0x00DBEDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF0u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF0 STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00DBF2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF0 STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00DBF2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF0 STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00DBF2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF0 STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00DBF2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF0u,0x00DBF0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF2u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF4;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF2u,0x00DBF2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF4u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF4 AND
    cpu.logicAnd(0xF00Cu);
    goto L_00DBF7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF4 AND
    cpu.logicAnd(0xCu);
    goto L_00DBF6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF4 AND
    cpu.logicAnd(0xCu);
    goto L_00DBF6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF4 AND
    cpu.logicAnd(0xCu);
    goto L_00DBF6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF4u,0x00DBF4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF6u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF6 BEQ -> $00DC16
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC16u,0x00DBF6u); return; }
    goto L_00DBF8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF6 BEQ -> $00DC16
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC16u,0x00DBF6u); return; }
    goto L_00DBF8;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF6 BEQ -> $00DC16
    if (cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00DC16u,0x00DBF6u); return; }
    goto L_00DBF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF6u,0x00DBF6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF7u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF7u,cpu,0x1Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF7u, 9u, 3u, cpu.address("absx", 0x0829u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF7 ASL
    cpu.aslMem(hw, cpu.address("absx", 0x829u), cpu.m8?8:16);
    goto L_00DBFA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF7u,0x00DBF7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF8 AND
    cpu.logicAnd(0x8u);
    goto L_00DBFA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF8 AND
    cpu.logicAnd(0x8u);
    goto L_00DBFA;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF8 AND
    cpu.logicAnd(0x8u);
    goto L_00DBFA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF8u,0x00DBF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBFAu))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFA BNE -> $00DC03
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC03u,0x00DBFAu); return; }
    goto L_00DBFC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFA BNE -> $00DC03
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC03u,0x00DBFAu); return; }
    goto L_00DBFC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFA BNE -> $00DC03
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC03u,0x00DBFAu); return; }
    goto L_00DBFC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFA BNE -> $00DC03
    if (!cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00DC03u,0x00DBFAu); return; }
    goto L_00DBFC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBFAu,0x00DBFAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBFCu))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFC LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Bu), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBFEu,0x00DBFCu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFC LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Bu), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBFEu,0x00DBFCu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFC LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Bu), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBFEu,0x00DBFCu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFC LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Bu), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBFEu,0x00DBFCu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBFCu,0x00DBFCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00CC68_E0M1X1C0_part8(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00DBE4u: goto L_00DBE4;
    case 0x00DBE6u: goto L_00DBE6;
    case 0x00DBE8u: goto L_00DBE8;
    case 0x00DBE9u: goto L_00DBE9;
    case 0x00DBEAu: goto L_00DBEA;
    case 0x00DBECu: goto L_00DBEC;
    case 0x00DBEDu: goto L_00DBED;
    case 0x00DBF0u: goto L_00DBF0;
    case 0x00DBF2u: goto L_00DBF2;
    case 0x00DBF4u: goto L_00DBF4;
    case 0x00DBF6u: goto L_00DBF6;
    case 0x00DBF7u: goto L_00DBF7;
    case 0x00DBF8u: goto L_00DBF8;
    case 0x00DBFAu: goto L_00DBFA;
    case 0x00DBFCu: goto L_00DBFC;
    case 0x00DBFEu: goto L_00DBFE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00DBE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE4u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE4u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE4 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x8Cu), cpu.x8?8:16));
    goto L_00DBE6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE4u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE4 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x8Cu), cpu.x8?8:16));
    goto L_00DBE6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE4u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE4 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x8Cu), cpu.x8?8:16));
    goto L_00DBE6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE4u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE4 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x8Cu), cpu.x8?8:16));
    goto L_00DBE6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBE4u,0x00DBE4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE6u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE6 BEQ -> $00DBF2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DBF2; }
    goto L_00DBE8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE6 BEQ -> $00DBF2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DBF2; }
    goto L_00DBE8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE6 BEQ -> $00DBF2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DBF2; }
    goto L_00DBE8;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE6 BEQ -> $00DBF2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DBF2; }
    goto L_00DBE8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBE6u,0x00DBE6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE8u))return;
  // 15 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE8 TXA
    cpu.transfer("TXA");
    goto L_00DBE9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE8 TXA
    cpu.transfer("TXA");
    goto L_00DBE9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE8 TXA
    cpu.transfer("TXA");
    goto L_00DBE9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE8 TXA
    cpu.transfer("TXA");
    goto L_00DBE9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE8 TXA
    cpu.transfer("TXA");
    goto L_00DBE9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBE8u,0x00DBE8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE9u))return;
  // 15 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE9 ASL
    cpu.aslA();
    goto L_00DBEA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE9 ASL
    cpu.aslA();
    goto L_00DBEA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE9 ASL
    cpu.aslA();
    goto L_00DBEA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE9 ASL
    cpu.aslA();
    goto L_00DBEA;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBE9 ASL
    cpu.aslA();
    goto L_00DBEA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBE9u,0x00DBE9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBEAu))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEAu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBEA ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16));
    goto L_00DBEC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEAu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBEA ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16));
    goto L_00DBEC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEAu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBEA ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16));
    goto L_00DBEC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEAu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBEA ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16));
    goto L_00DBEC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBEAu,0x00DBEAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBECu))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBEC TAX
    cpu.transfer("TAX");
    goto L_00DBED;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBEC TAX
    cpu.transfer("TAX");
    goto L_00DBED;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBEC TAX
    cpu.transfer("TAX");
    goto L_00DBED;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBEC TAX
    cpu.transfer("TAX");
    goto L_00DBED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBECu,0x00DBECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBEDu))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEDu, 5u + ((((0xDAB7u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDAB7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBED LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDAB7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEDu, 4u + 1u, 3u, cpu.address("absx", 0xDAB7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBED LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDAB7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEDu, 4u + ((((0xDAB7u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDAB7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBED LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDAB7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEDu, 4u + ((((0xDAB7u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDAB7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBED LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDAB7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBEDu,0x00DBEDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF0u))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF0 STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00DBF2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF0 STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00DBF2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF0 STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00DBF2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF0 STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00DBF2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF0u,0x00DBF0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF2u))return;
  // 10 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF4;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DBF4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF2u,0x00DBF2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF4u))return;
  // 10 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF4 AND
    cpu.logicAnd(0xCu);
    goto L_00DBF6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF4 AND
    cpu.logicAnd(0xF00Cu);
    goto L_00DBF7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF4 AND
    cpu.logicAnd(0xCu);
    goto L_00DBF6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF4 AND
    cpu.logicAnd(0xCu);
    goto L_00DBF6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF4 AND
    cpu.logicAnd(0xCu);
    goto L_00DBF6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF4u,0x00DBF4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF6u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF6 BEQ -> $00DC16
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC16u,0x00DBF6u); return; }
    goto L_00DBF8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF6 BEQ -> $00DC16
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC16u,0x00DBF6u); return; }
    goto L_00DBF8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF6 BEQ -> $00DC16
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC16u,0x00DBF6u); return; }
    goto L_00DBF8;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF6 BEQ -> $00DC16
    if (cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00DC16u,0x00DBF6u); return; }
    goto L_00DBF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF6u,0x00DBF6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF7u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF7u,cpu,0x1Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF7u, 9u, 3u, cpu.address("absx", 0x0829u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF7 ASL
    cpu.aslMem(hw, cpu.address("absx", 0x829u), cpu.m8?8:16);
    goto L_00DBFA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF7u,0x00DBF7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF8u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF8 AND
    cpu.logicAnd(0x8u);
    goto L_00DBFA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF8 AND
    cpu.logicAnd(0x8u);
    goto L_00DBFA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF8 AND
    cpu.logicAnd(0x8u);
    goto L_00DBFA;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBF8 AND
    cpu.logicAnd(0x8u);
    goto L_00DBFA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF8u,0x00DBF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBFAu))return;
  // 10 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFA BNE -> $00DC03
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC03u,0x00DBFAu); return; }
    goto L_00DBFC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFA BNE -> $00DC03
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC03u,0x00DBFAu); return; }
    goto L_00DBFC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFA BNE -> $00DC03
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC03u,0x00DBFAu); return; }
    goto L_00DBFC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFA BNE -> $00DC03
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC03u,0x00DBFAu); return; }
    goto L_00DBFC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFA BNE -> $00DC03
    if (!cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00DC03u,0x00DBFAu); return; }
    goto L_00DBFC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBFAu,0x00DBFAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBFCu))return;
  // 10 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFC LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Bu), cpu.m8?8:16);
    goto L_00DBFE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFC LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Bu), cpu.m8?8:16);
    goto L_00DBFE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFC LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Bu), cpu.m8?8:16);
    goto L_00DBFE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFC LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Bu), cpu.m8?8:16);
    goto L_00DBFE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFC LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Bu), cpu.m8?8:16);
    goto L_00DBFE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBFCu,0x00DBFCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DBFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBFEu))return;
  // 9 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFEu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFE BCS -> $00DC0B
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC0Bu,0x00DBFEu); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC00u,0x00DBFEu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFEu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFE BCS -> $00DC0B
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC0Bu,0x00DBFEu); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC00u,0x00DBFEu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFEu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFE BCS -> $00DC0B
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC0Bu,0x00DBFEu); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC00u,0x00DBFEu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFEu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DBFE BCS -> $00DC0B
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC0Bu,0x00DBFEu); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC00u,0x00DBFEu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBFEu,0x00DBFEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00E92B_E0M1X1CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EA13u: goto L_00EA13;
    case 0x00EA15u: goto L_00EA15;
    case 0x00EA16u: goto L_00EA16;
    case 0x00EA18u: goto L_00EA18;
    case 0x00EA1Au: goto L_00EA1A;
    case 0x00EA1Bu: goto L_00EA1B;
    case 0x00EA1Eu: goto L_00EA1E;
    case 0x00EA20u: goto L_00EA20;
    case 0x00EA22u: goto L_00EA22;
    case 0x00EA24u: goto L_00EA24;
    case 0x00EA26u: goto L_00EA26;
    case 0x00EA28u: goto L_00EA28;
    case 0x00EA2Bu: goto L_00EA2B;
    case 0x00EA2Du: goto L_00EA2D;
    case 0x00EA30u: goto L_00EA30;
    case 0x00EA32u: goto L_00EA32;
    case 0x00EA34u: goto L_00EA34;
    case 0x00EA37u: goto L_00EA37;
    case 0x00EA39u: goto L_00EA39;
    case 0x00EA3Bu: goto L_00EA3B;
    case 0x00EA3Du: goto L_00EA3D;
    case 0x00EA3Fu: goto L_00EA3F;
    case 0x00EA42u: goto L_00EA42;
    case 0x00EA45u: goto L_00EA45;
    case 0x00EA47u: goto L_00EA47;
    case 0x00EA49u: goto L_00EA49;
    case 0x00EA4Bu: goto L_00EA4B;
    case 0x00EA4Du: goto L_00EA4D;
    case 0x00EA4Fu: goto L_00EA4F;
    case 0x00EA51u: goto L_00EA51;
    case 0x00EA53u: goto L_00EA53;
    case 0x00EA55u: goto L_00EA55;
    case 0x00EA57u: goto L_00EA57;
    case 0x00EA59u: goto L_00EA59;
    case 0x00EA5Cu: goto L_00EA5C;
    case 0x00EA5Eu: goto L_00EA5E;
    case 0x00EA60u: goto L_00EA60;
    case 0x00EA62u: goto L_00EA62;
    case 0x00EA65u: goto L_00EA65;
    case 0x00EA67u: goto L_00EA67;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EA13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA13u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA13u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA13 AND
    cpu.logicAnd(0x2u);
    goto L_00EA15;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA13u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA13 AND
    cpu.logicAnd(0x2u);
    goto L_00EA15;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA13u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA13 AND
    cpu.logicAnd(0x2u);
    goto L_00EA15;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA13u,0x00EA13u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA15u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA15u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA15 TAY
    cpu.transfer("TAY");
    goto L_00EA16;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA15u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA15 TAY
    cpu.transfer("TAY");
    goto L_00EA16;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA15u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA15 TAY
    cpu.transfer("TAY");
    goto L_00EA16;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA15u,0x00EA15u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA16u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA16u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA16u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA16 REP
    cpu.rep(0x20u);
    goto L_00EA18;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA16u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA16u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA16 REP
    cpu.rep(0x20u);
    goto L_00EA18;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA16u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA16u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA16 REP
    cpu.rep(0x20u);
    goto L_00EA18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA16u,0x00EA16u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA18u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA18u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA18 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA1A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA18u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA18 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA1A;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA18u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA18 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA1A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA18u,0x00EA18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA1Au))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1A CLC
    cpu.setFlag('C', false);
    goto L_00EA1B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1A CLC
    cpu.setFlag('C', false);
    goto L_00EA1B;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1A CLC
    cpu.setFlag('C', false);
    goto L_00EA1B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA1Au,0x00EA1Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA1Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Bu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Bu, 5u + 1u, 3u, cpu.address("absy", 0xE90Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1B ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xE90Du), cpu.m8?8:16));
    goto L_00EA1E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Bu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Bu, 5u + ((((0xE90Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE90Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1B ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xE90Du), cpu.m8?8:16));
    goto L_00EA1E;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Bu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Bu, 5u + ((((0xE90Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE90Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1B ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xE90Du), cpu.m8?8:16));
    goto L_00EA1E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA1Bu,0x00EA1Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA1Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1E STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00EA20;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1E STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00EA20;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA1E STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00EA20;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA1Eu,0x00EA1Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA20u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA20u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA20u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA20 SEP
    cpu.sep(0x20u);
    goto L_00EA22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA20u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA20u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA20 SEP
    cpu.sep(0x20u);
    goto L_00EA22;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA20u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA20u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA20 SEP
    cpu.sep(0x20u);
    goto L_00EA22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA20u,0x00EA20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA22u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA22u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA24;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA22u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA24;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA22u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA24;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA22u,0x00EA22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA24u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA24u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA24 BMI -> $00EA34
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA34; }
    goto L_00EA26;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA24u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA24 BMI -> $00EA34
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA34; }
    goto L_00EA26;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA24u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA24 BMI -> $00EA34
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA34; }
    goto L_00EA26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA24u,0x00EA24u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA26u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA26 LDA
    cpu.setA(0x3u, 8);
    goto L_00EA28;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA26 LDA
    cpu.setA(0x3u, 8);
    goto L_00EA28;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA26 LDA
    cpu.setA(0x3u, 8);
    goto L_00EA28;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA26u,0x00EA26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA28u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA28u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA28u, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA28 STA
    hw.write(cpu.address("abs", 0x13E5u), cpu.a, cpu.m8?8:16);
    goto L_00EA2B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA28u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA28u, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA28 STA
    hw.write(cpu.address("abs", 0x13E5u), cpu.a, cpu.m8?8:16);
    goto L_00EA2B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA28u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA28u, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA28 STA
    hw.write(cpu.address("abs", 0x13E5u), cpu.a, cpu.m8?8:16);
    goto L_00EA2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA28u,0x00EA28u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA2Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA2B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA2D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA2B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA2D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA2B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA2D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA2Bu,0x00EA2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA2Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Du,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Du, 4u + 1u, 3u, cpu.address("absy", 0xE90Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA2D EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xE90Du), cpu.m8?8:16));
    goto L_00EA30;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Du,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Du, 4u + ((((0xE90Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE90Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA2D EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xE90Du), cpu.m8?8:16));
    goto L_00EA30;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Du,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA2Du, 4u + ((((0xE90Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE90Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA2D EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xE90Du), cpu.m8?8:16));
    goto L_00EA30;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA2Du,0x00EA2Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA30u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA30u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA30u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA30 BPL -> $00EA34
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA34; }
    goto L_00EA32;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA30u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA30u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA30 BPL -> $00EA34
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA34; }
    goto L_00EA32;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA30u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA30u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA30 BPL -> $00EA34
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA34; }
    goto L_00EA32;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA30u,0x00EA30u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA32u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA32u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA32u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA32 STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00EA34;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA32u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA32u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA32 STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00EA34;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA32u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA32u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA32 STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00EA34;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA32u,0x00EA32u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA34u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA34u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA34u, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA34 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13F9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA37;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA34u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA34u, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA34 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13F9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA37;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA34u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA34u, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA34 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13F9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA37;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA34u,0x00EA34u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA37u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA37u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA37 CMP
    cpu.compareA(0x1u);
    goto L_00EA39;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA37u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA37 CMP
    cpu.compareA(0x1u);
    goto L_00EA39;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA37u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA37 CMP
    cpu.compareA(0x1u);
    goto L_00EA39;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA37u,0x00EA37u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA39u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA39u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA39 BNE -> $00EA42
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA42; }
    goto L_00EA3B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA39u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA39 BNE -> $00EA42
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA42; }
    goto L_00EA3B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA39u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA39 BNE -> $00EA42
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA42; }
    goto L_00EA3B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA39u,0x00EA39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA3Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA3D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA3D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA3D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA3Bu,0x00EA3Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA3Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3D BNE -> $00EA42
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA42; }
    goto L_00EA3F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3D BNE -> $00EA42
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA42; }
    goto L_00EA3F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3D BNE -> $00EA42
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA42; }
    goto L_00EA3F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA3Du,0x00EA3Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA3Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Fu, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3F STZ
    hw.write(cpu.address("abs", 0x13F9u), 0, cpu.m8?8:16);
    goto L_00EA42;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Fu, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3F STZ
    hw.write(cpu.address("abs", 0x13F9u), 0, cpu.m8?8:16);
    goto L_00EA42;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA3Fu, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA3F STZ
    hw.write(cpu.address("abs", 0x13F9u), 0, cpu.m8?8:16);
    goto L_00EA42;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA3Fu,0x00EA3Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA42u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA42u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA42u, 4u, 3u, cpu.address("abs", 0x13FAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA42 STZ
    hw.write(cpu.address("abs", 0x13FAu), 0, cpu.m8?8:16);
    goto L_00EA45;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA42u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA42u, 4u, 3u, cpu.address("abs", 0x13FAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA42 STZ
    hw.write(cpu.address("abs", 0x13FAu), 0, cpu.m8?8:16);
    goto L_00EA45;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA42u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA42u, 4u, 3u, cpu.address("abs", 0x13FAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA42 STZ
    hw.write(cpu.address("abs", 0x13FAu), 0, cpu.m8?8:16);
    goto L_00EA45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA42u,0x00EA42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA45u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA45u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA45u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA45 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA47;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA45u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA45u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA45 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA47;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA45u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA45u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA45 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA47;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA45u,0x00EA45u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA47u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA47u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA47 BNE -> $00EA5E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA5E; }
    goto L_00EA49;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA47u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA47 BNE -> $00EA5E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA5E; }
    goto L_00EA49;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA47u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA47 BNE -> $00EA5E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA5E; }
    goto L_00EA49;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA47u,0x00EA47u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA49u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA49u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA49u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA49 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA4B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA49u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA49u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA49 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA4B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA49u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA49u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA49 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA4B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA49u,0x00EA49u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA4Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4B BCC -> $00EAA3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA3u,0x00EA4Bu); return; }
    goto L_00EA4D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4B BCC -> $00EAA3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA3u,0x00EA4Bu); return; }
    goto L_00EA4D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4B BCC -> $00EAA3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA3u,0x00EA4Bu); return; }
    goto L_00EA4D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA4Bu,0x00EA4Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA4Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA4F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA4F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA4F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA4Du,0x00EA4Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA4Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4F BNE -> $00EA65
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA65; }
    goto L_00EA51;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4F BNE -> $00EA65
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA65; }
    goto L_00EA51;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA4F BNE -> $00EA65
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EA65; }
    goto L_00EA51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA4Fu,0x00EA4Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA51u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA51u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA51u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA51 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA53;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA51u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA51u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA51 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA53;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA51u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA51u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA51 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EA53;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA51u,0x00EA51u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA53u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA53u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA53 BMI -> $00EA65
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA65; }
    goto L_00EA55;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA53u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA53 BMI -> $00EA65
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA65; }
    goto L_00EA55;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA53u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA53 BMI -> $00EA65
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EA65; }
    goto L_00EA55;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA53u,0x00EA53u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA55u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA55u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA55u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA55 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA57;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA55u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA55u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA55 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA57;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA55u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA55u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA55 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA57;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA55u,0x00EA55u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA57u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA57u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA57 BCC -> $00EAA5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA5u,0x00EA57u); return; }
    goto L_00EA59;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA57u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA57 BCC -> $00EAA5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA5u,0x00EA57u); return; }
    goto L_00EA59;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA57u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA57 BCC -> $00EAA5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EAA5u,0x00EA57u); return; }
    goto L_00EA59;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA57u,0x00EA57u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA59u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA59u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA59u, 6u, 3u, cpu.address("abs", 0xFDA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA59 JSR -> $00FDA5 stack real
    { cpu.push16Value(hw,0xEA5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA5u), 0x00EA59u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA5C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA59u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA59u, 6u, 3u, cpu.address("abs", 0xFDA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA59 JSR -> $00FDA5 stack real
    { cpu.push16Value(hw,0xEA5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA5u), 0x00EA59u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA5C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA59u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA59u, 6u, 3u, cpu.address("abs", 0xFDA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EA59 JSR -> $00FDA5 stack real
    { cpu.push16Value(hw,0xEA5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA5u), 0x00EA59u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EA5C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA59u,0x00EA59u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA5Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA5C STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    goto L_00EA5E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA5C STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    goto L_00EA5E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA5C STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    goto L_00EA5E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA5Cu,0x00EA5Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA5Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA5E LDA
    cpu.setA(0x1u, 8);
    goto L_00EA60;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA5E LDA
    cpu.setA(0x1u, 8);
    goto L_00EA60;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA5E LDA
    cpu.setA(0x1u, 8);
    goto L_00EA60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA5Eu,0x00EA5Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA60u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA60 STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_00EA62;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA60 STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_00EA62;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA60 STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_00EA62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA60u,0x00EA60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA62u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA62u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA62u, 3u, 3u, cpu.address("abs", 0xFD08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA62 JMP -> $00FD08
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xFD08u),0x00EA62u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA62u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA62u, 3u, 3u, cpu.address("abs", 0xFD08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA62 JMP -> $00FD08
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xFD08u),0x00EA62u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA62u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA62u, 3u, 3u, cpu.address("abs", 0xFD08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA62 JMP -> $00FD08
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xFD08u),0x00EA62u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA62u,0x00EA62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA65u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA65u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA65u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA65 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA67;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA65u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA65u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA65 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA67;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA65u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA65u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA65 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8Au), cpu.m8?8:16);
    goto L_00EA67;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA65u,0x00EA65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EA67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEA67u))return;
  // 4 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA67u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA67 BCS -> $00EA5E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EA5E; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA69u,0x00EA67u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA67u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA67 BCS -> $00EA5E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EA5E; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA69u,0x00EA67u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEA67u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEA67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EA67 BCS -> $00EA5E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EA5E; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA69u,0x00EA67u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEA67u,0x00EA67u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1C1_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE09u: goto L_00EE09;
    case 0x00EE0Bu: goto L_00EE0B;
    case 0x00EE0Cu: goto L_00EE0C;
    case 0x00EE0Du: goto L_00EE0D;
    case 0x00EE0Eu: goto L_00EE0E;
    case 0x00EE0Fu: goto L_00EE0F;
    case 0x00EE11u: goto L_00EE11;
    case 0x00EE13u: goto L_00EE13;
    case 0x00EE15u: goto L_00EE15;
    case 0x00EE16u: goto L_00EE16;
    case 0x00EE17u: goto L_00EE17;
    case 0x00EE18u: goto L_00EE18;
    case 0x00EE19u: goto L_00EE19;
    case 0x00EE1Bu: goto L_00EE1B;
    case 0x00EE1Du: goto L_00EE1D;
    case 0x00EE20u: goto L_00EE20;
    case 0x00EE22u: goto L_00EE22;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE09u))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE09u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE09u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE09 CPY
    cpu.compareY(0x9059u);
    goto L_00EE0C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE09u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE09 CPY
    cpu.compareY(0x59u);
    goto L_00EE0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE09u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE09 CPY
    cpu.compareY(0x59u);
    goto L_00EE0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE09u,0x00EE09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE0Bu))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE0B BCC -> $00EE11
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EE11; }
    goto L_00EE0D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE0B BCC -> $00EE11
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EE11; }
    goto L_00EE0D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE0Bu,0x00EE0Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE0Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Cu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE0C TSB
    cpu.tsb(hw, cpu.address("dp", 0xC0u), cpu.m8?8:16);
    goto L_00EE0E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE0Cu,0x00EE0Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE0Du))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Du,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE0D CPY
    cpu.compareY(0x5Cu);
    goto L_00EE0F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Du,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE0D CPY
    cpu.compareY(0x5Cu);
    goto L_00EE0F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE0Du,0x00EE0Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE0Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Eu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Eu, 4u, 4u, 0xA50C90u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE0E JML -> $A50C90
    hw.requestDispatch(0xA50C90u,0x00EE0Eu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE0Eu,0x00EE0Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE0Fu))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE0F BCC -> $00EE1D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EE1D; }
    goto L_00EE11;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE0F BCC -> $00EE1D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EE1D; }
    goto L_00EE11;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE0Fu,0x00EE0Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE11u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE11u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE11 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE13;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE11u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE11u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE11 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE13;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE11u,0x00EE11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE13u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE13u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE13u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE13 AND
    cpu.logicAnd(0x640Fu);
    goto L_00EE16;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE13u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE13 AND
    cpu.logicAnd(0xFu);
    goto L_00EE15;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE13u,0x00EE13u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE15u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE15u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE15 STZ
    hw.write(cpu.address("dp", 0x90u), 0, cpu.m8?8:16);
    goto L_00EE17;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE15u,0x00EE15u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE16u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE16u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE16 BCC -> $00EDE1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE1u,0x00EE16u); return; }
    goto L_00EE18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE16u,0x00EE16u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE17u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE17u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE17 CMP
    cpu.compareA(0x8u);
    goto L_00EE19;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE17u,0x00EE17u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE18u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE18u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE18u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EE18 PHP
    cpu.push("PHP", hw);
    goto L_00EE19;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE18u,0x00EE18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE19u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE19 STA
    hw.write(cpu.address("dp", 0x91u), cpu.a, cpu.m8?8:16);
    goto L_00EE1B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE19 STA
    hw.write(cpu.address("dp", 0x91u), cpu.a, cpu.m8?8:16);
    goto L_00EE1B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE19u,0x00EE19u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE1Bu))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1B BCC -> $00EE3A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE3Au,0x00EE1Bu); return; }
    goto L_00EE1D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1B BCC -> $00EE3A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE3Au,0x00EE1Bu); return; }
    goto L_00EE1D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE1Bu,0x00EE1Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE1Du))return;
  // 15 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du, 5u, 3u, cpu.address("abs", 0x1471u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE20;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du, 5u, 3u, cpu.address("abs", 0x1471u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE20;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE20;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE1Du,0x00EE1Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE20u))return;
  // 15 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE20 BEQ -> $00EE2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE2Du,0x00EE20u); return; }
    goto L_00EE22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE20 BEQ -> $00EE2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE2Du,0x00EE20u); return; }
    goto L_00EE22;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE20 BEQ -> $00EE2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE2Du,0x00EE20u); return; }
    goto L_00EE22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE20u,0x00EE20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE22u))return;
  // 15 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE24u,0x00EE22u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE24u,0x00EE22u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE24u,0x00EE22u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE22u,0x00EE22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE09u: goto L_00EE09;
    case 0x00EE0Bu: goto L_00EE0B;
    case 0x00EE0Cu: goto L_00EE0C;
    case 0x00EE0Du: goto L_00EE0D;
    case 0x00EE0Eu: goto L_00EE0E;
    case 0x00EE0Fu: goto L_00EE0F;
    case 0x00EE11u: goto L_00EE11;
    case 0x00EE13u: goto L_00EE13;
    case 0x00EE15u: goto L_00EE15;
    case 0x00EE16u: goto L_00EE16;
    case 0x00EE17u: goto L_00EE17;
    case 0x00EE18u: goto L_00EE18;
    case 0x00EE19u: goto L_00EE19;
    case 0x00EE1Bu: goto L_00EE1B;
    case 0x00EE1Du: goto L_00EE1D;
    case 0x00EE20u: goto L_00EE20;
    case 0x00EE22u: goto L_00EE22;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE09u))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE09u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE09u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE09 CPY
    cpu.compareY(0x9059u);
    goto L_00EE0C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE09u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE09 CPY
    cpu.compareY(0x59u);
    goto L_00EE0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE09u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE09 CPY
    cpu.compareY(0x59u);
    goto L_00EE0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE09u,0x00EE09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE0Bu))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE0B BCC -> $00EE11
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EE11; }
    goto L_00EE0D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE0B BCC -> $00EE11
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EE11; }
    goto L_00EE0D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE0Bu,0x00EE0Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE0Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Cu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE0C TSB
    cpu.tsb(hw, cpu.address("dp", 0xC0u), cpu.m8?8:16);
    goto L_00EE0E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE0Cu,0x00EE0Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE0Du))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Du,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE0D CPY
    cpu.compareY(0x5Cu);
    goto L_00EE0F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Du,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE0D CPY
    cpu.compareY(0x5Cu);
    goto L_00EE0F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE0Du,0x00EE0Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE0Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Eu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Eu, 4u, 4u, 0xA50C90u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE0E JML -> $A50C90
    hw.requestDispatch(0xA50C90u,0x00EE0Eu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE0Eu,0x00EE0Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE0Fu))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE0F BCC -> $00EE1D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EE1D; }
    goto L_00EE11;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE0F BCC -> $00EE1D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EE1D; }
    goto L_00EE11;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE0Fu,0x00EE0Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE11u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE11u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE11 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE13;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE11u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE11u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE11 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE13;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE11u,0x00EE11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE13u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE13u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE13u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE13 AND
    cpu.logicAnd(0x640Fu);
    goto L_00EE16;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE13u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE13 AND
    cpu.logicAnd(0xFu);
    goto L_00EE15;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE13u,0x00EE13u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE15u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE15u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE15 STZ
    hw.write(cpu.address("dp", 0x90u), 0, cpu.m8?8:16);
    goto L_00EE17;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE15u,0x00EE15u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE16u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE16u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE16 BCC -> $00EDE1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE1u,0x00EE16u); return; }
    goto L_00EE18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE16u,0x00EE16u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE17u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE17u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE17 CMP
    cpu.compareA(0x8u);
    goto L_00EE19;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE17u,0x00EE17u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE18u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE18u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE18u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EE18 PHP
    cpu.push("PHP", hw);
    goto L_00EE19;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE18u,0x00EE18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE19u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE19 STA
    hw.write(cpu.address("dp", 0x91u), cpu.a, cpu.m8?8:16);
    goto L_00EE1B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE19u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE19 STA
    hw.write(cpu.address("dp", 0x91u), cpu.a, cpu.m8?8:16);
    goto L_00EE1B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE19u,0x00EE19u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE1Bu))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1B BCC -> $00EE3A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE3Au,0x00EE1Bu); return; }
    goto L_00EE1D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1B BCC -> $00EE3A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE3Au,0x00EE1Bu); return; }
    goto L_00EE1D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE1Bu,0x00EE1Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE1Du))return;
  // 15 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du, 5u, 3u, cpu.address("abs", 0x1471u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE20;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du, 5u, 3u, cpu.address("abs", 0x1471u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE20;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE20;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE1Du,0x00EE1Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE20u))return;
  // 15 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE20 BEQ -> $00EE2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE2Du,0x00EE20u); return; }
    goto L_00EE22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE20 BEQ -> $00EE2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE2Du,0x00EE20u); return; }
    goto L_00EE22;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE20 BEQ -> $00EE2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE2Du,0x00EE20u); return; }
    goto L_00EE22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE20u,0x00EE20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE22u))return;
  // 15 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE24u,0x00EE22u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE24u,0x00EE22u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE24u,0x00EE22u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE22u,0x00EE22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1C1_part10(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE96u: goto L_00EE96;
    case 0x00EE98u: goto L_00EE98;
    case 0x00EE99u: goto L_00EE99;
    case 0x00EE9Au: goto L_00EE9A;
    case 0x00EE9Bu: goto L_00EE9B;
    case 0x00EE9Cu: goto L_00EE9C;
    case 0x00EE9Du: goto L_00EE9D;
    case 0x00EE9Eu: goto L_00EE9E;
    case 0x00EE9Fu: goto L_00EE9F;
    case 0x00EEA0u: goto L_00EEA0;
    case 0x00EEA2u: goto L_00EEA2;
    case 0x00EEA3u: goto L_00EEA3;
    case 0x00EEA6u: goto L_00EEA6;
    case 0x00EEA8u: goto L_00EEA8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE96u))return;
  // 16 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0xF003u);
    goto L_00EE99;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0xF003u);
    goto L_00EE99;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0x3u);
    goto L_00EE98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE96u,0x00EE96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE98u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE98 BEQ -> $00EEAA
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EEAAu,0x00EE98u); return; }
    goto L_00EE9A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE98u,0x00EE98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE99u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE99 BPL -> $00EE64
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE64u,0x00EE99u); return; }
    goto L_00EE9B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE99 BPL -> $00EE64
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE64u,0x00EE99u); return; }
    goto L_00EE9B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE99u,0x00EE99u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Au))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9A CMP
    cpu.compareA(0x2u);
    goto L_00EE9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Au,0x00EE9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Bu))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEE9Du,true);
    hw.requestDispatch(0x0082C3u,0x00EE9Bu);return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEE9Du,true);
    hw.requestDispatch(0x0082C3u,0x00EE9Bu);return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,0x00EE9Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Cu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9C BCS -> $00EED1
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EED1u,0x00EE9Cu); return; }
    goto L_00EE9E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,0x00EE9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Du))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xC2u) & 0xFFFFu), 2u, 0u);
    // $00EE9D AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0xC2u), cpu.m8?8:16));
    goto L_00EE9F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xC2u) & 0xFFFFu), 2u, 0u);
    // $00EE9D AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0xC2u), cpu.m8?8:16));
    goto L_00EE9F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Du,0x00EE9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Eu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9E REP
    cpu.rep(0x20u);
    goto L_00EEA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Eu,0x00EE9Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Fu))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu, 6u, 3u, cpu.address("abs", 0x9AA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE9F JSR -> $009AA5 stack real
    { cpu.push16Value(hw,0xEEA1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEA2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9AA5u), 0x00EE9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEA2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu, 6u, 3u, cpu.address("abs", 0x9AA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE9F JSR -> $009AA5 stack real
    { cpu.push16Value(hw,0xEEA1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEA2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9AA5u), 0x00EE9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,0x00EE9Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA0u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA0u,0x00EEA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA2u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA2 SEC
    cpu.setFlag('C', true);
    goto L_00EEA3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA2 SEC
    cpu.setFlag('C', true);
    goto L_00EEA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA2u,0x00EEA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA3u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA3 SBC
    cpu.sbc(0x10u);
    goto L_00EEA6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA3 SBC
    cpu.sbc(0x10u);
    goto L_00EEA6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA3u,0x00EEA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA6u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA6 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_00EEA8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA6 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_00EEA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA6u,0x00EEA6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA8u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA8 SEP
    cpu.sep(0x20u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEAAu,0x00EEA8u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA8 SEP
    cpu.sep(0x20u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEAAu,0x00EEA8u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA8u,0x00EEA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part10(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE96u: goto L_00EE96;
    case 0x00EE98u: goto L_00EE98;
    case 0x00EE99u: goto L_00EE99;
    case 0x00EE9Au: goto L_00EE9A;
    case 0x00EE9Bu: goto L_00EE9B;
    case 0x00EE9Cu: goto L_00EE9C;
    case 0x00EE9Du: goto L_00EE9D;
    case 0x00EE9Eu: goto L_00EE9E;
    case 0x00EE9Fu: goto L_00EE9F;
    case 0x00EEA0u: goto L_00EEA0;
    case 0x00EEA2u: goto L_00EEA2;
    case 0x00EEA3u: goto L_00EEA3;
    case 0x00EEA6u: goto L_00EEA6;
    case 0x00EEA8u: goto L_00EEA8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE96u))return;
  // 16 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0xF003u);
    goto L_00EE99;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0xF003u);
    goto L_00EE99;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0x3u);
    goto L_00EE98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE96u,0x00EE96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE98u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE98 BEQ -> $00EEAA
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EEAAu,0x00EE98u); return; }
    goto L_00EE9A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE98u,0x00EE98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE99u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE99 BPL -> $00EE64
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE64u,0x00EE99u); return; }
    goto L_00EE9B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE99 BPL -> $00EE64
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EE64u,0x00EE99u); return; }
    goto L_00EE9B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE99u,0x00EE99u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Au))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9A CMP
    cpu.compareA(0x2u);
    goto L_00EE9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Au,0x00EE9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Bu))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEE9Du,true);
    hw.requestDispatch(0x0082C3u,0x00EE9Bu);return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEE9Du,true);
    hw.requestDispatch(0x0082C3u,0x00EE9Bu);return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,0x00EE9Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Cu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9C BCS -> $00EED1
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EED1u,0x00EE9Cu); return; }
    goto L_00EE9E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,0x00EE9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Du))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xC2u) & 0xFFFFu), 2u, 0u);
    // $00EE9D AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0xC2u), cpu.m8?8:16));
    goto L_00EE9F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xC2u) & 0xFFFFu), 2u, 0u);
    // $00EE9D AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0xC2u), cpu.m8?8:16));
    goto L_00EE9F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Du,0x00EE9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Eu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9E REP
    cpu.rep(0x20u);
    goto L_00EEA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Eu,0x00EE9Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Fu))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu, 6u, 3u, cpu.address("abs", 0x9AA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE9F JSR -> $009AA5 stack real
    { cpu.push16Value(hw,0xEEA1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEA2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9AA5u), 0x00EE9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEA2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu, 6u, 3u, cpu.address("abs", 0x9AA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE9F JSR -> $009AA5 stack real
    { cpu.push16Value(hw,0xEEA1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEA2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9AA5u), 0x00EE9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,0x00EE9Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA0u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA0u,0x00EEA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA2u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA2 SEC
    cpu.setFlag('C', true);
    goto L_00EEA3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA2 SEC
    cpu.setFlag('C', true);
    goto L_00EEA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA2u,0x00EEA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA3u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA3 SBC
    cpu.sbc(0x10u);
    goto L_00EEA6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA3 SBC
    cpu.sbc(0x10u);
    goto L_00EEA6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA3u,0x00EEA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA6u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA6 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_00EEA8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA6 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_00EEA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA6u,0x00EEA6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA8u))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA8 SEP
    cpu.sep(0x20u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEAAu,0x00EEA8u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA8 SEP
    cpu.sep(0x20u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEAAu,0x00EEA8u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA8u,0x00EEA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E1M1X1CQ_part9(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE9Au: goto L_00EE9A;
    case 0x00EE9Bu: goto L_00EE9B;
    case 0x00EE9Cu: goto L_00EE9C;
    case 0x00EE9Du: goto L_00EE9D;
    case 0x00EE9Eu: goto L_00EE9E;
    case 0x00EE9Fu: goto L_00EE9F;
    case 0x00EEA0u: goto L_00EEA0;
    case 0x00EEA2u: goto L_00EEA2;
    case 0x00EEA3u: goto L_00EEA3;
    case 0x00EEA6u: goto L_00EEA6;
    case 0x00EEA8u: goto L_00EEA8;
    case 0x00EEAAu: goto L_00EEAA;
    case 0x00EEABu: goto L_00EEAB;
    case 0x00EEACu: goto L_00EEAC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Au))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9A CMP
    cpu.compareA(0x2u);
    goto L_00EE9C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9A CMP
    cpu.compareA(0x2u);
    goto L_00EE9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Au,0x00EE9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Bu))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEE9Du,true);
    hw.requestDispatch(0x0082C3u,0x00EE9Bu);return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEE9Du,true);
    hw.requestDispatch(0x0082C3u,0x00EE9Bu);return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,0x00EE9Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Cu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9C BCS -> $00EED1
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EED1u,0x00EE9Cu); return; }
    goto L_00EE9E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9C BCS -> $00EED1
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EED1u,0x00EE9Cu); return; }
    goto L_00EE9E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,0x00EE9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Du))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xC2u) & 0xFFFFu), 2u, 0u);
    // $00EE9D AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0xC2u), cpu.m8?8:16));
    goto L_00EE9F;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xC2u) & 0xFFFFu), 2u, 0u);
    // $00EE9D AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0xC2u), cpu.m8?8:16));
    goto L_00EE9F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Du,0x00EE9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Eu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9E REP
    cpu.rep(0x20u);
    goto L_00EEA0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9E REP
    cpu.rep(0x20u);
    goto L_00EEA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Eu,0x00EE9Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EE9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Fu))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu, 6u, 3u, cpu.address("abs", 0x9AA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE9F JSR -> $009AA5 stack real
    { cpu.push16Value(hw,0xEEA1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEA2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9AA5u), 0x00EE9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEA2;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu, 6u, 3u, cpu.address("abs", 0x9AA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE9F JSR -> $009AA5 stack real
    { cpu.push16Value(hw,0xEEA1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEA2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9AA5u), 0x00EE9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EEA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,0x00EE9Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA0u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEA2;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA0u,0x00EEA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA2u))return;
  // 14 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA2 SEC
    cpu.setFlag('C', true);
    goto L_00EEA3;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA2 SEC
    cpu.setFlag('C', true);
    goto L_00EEA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA2u,0x00EEA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA3u))return;
  // 14 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA3 SBC
    cpu.sbc(0x10u);
    goto L_00EEA6;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA3 SBC
    cpu.sbc(0x10u);
    goto L_00EEA6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA3u,0x00EEA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA6u))return;
  // 14 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA6 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_00EEA8;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA6 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_00EEA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA6u,0x00EEA6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA8u))return;
  // 14 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA8 SEP
    cpu.sep(0x20u);
    goto L_00EEAA;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEA8 SEP
    cpu.sep(0x20u);
    goto L_00EEAA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA8u,0x00EEA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEAAu))return;
  // 14 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAA TXA
    cpu.transfer("TXA");
    goto L_00EEAB;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAA TXA
    cpu.transfer("TXA");
    goto L_00EEAB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEAAu,0x00EEAAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEABu))return;
  // 14 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAB LSR
    cpu.lsrA();
    goto L_00EEAC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAB LSR
    cpu.lsrA();
    goto L_00EEAC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEABu,0x00EEABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEACu))return;
  // 14 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAC LSR
    cpu.lsrA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEADu,0x00EEACu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAC LSR
    cpu.lsrA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEADu,0x00EEACu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEACu,0x00EEACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1C1_part23(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF42u: goto L_00EF42;
    case 0x00EF43u: goto L_00EF43;
    case 0x00EF45u: goto L_00EF45;
    case 0x00EF48u: goto L_00EF48;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF42u))return;
  // 42 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF42 PHA
    cpu.push("PHA", hw);
    goto L_00EF43;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF42 PHA
    cpu.push("PHA", hw);
    goto L_00EF43;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EF42 PHA
    cpu.push("PHA", hw);
    goto L_00EF43;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EF42 PHA
    cpu.push("PHA", hw);
    goto L_00EF43;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EF42 PHA
    cpu.push("PHA", hw);
    goto L_00EF43;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF42u,0x00EF42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF43u))return;
  // 42 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF43u,0x00EF43u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF45u))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u, 5u, 3u, cpu.address("abs", 0x17BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF45 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF48;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u, 5u, 3u, cpu.address("abs", 0x17BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF45 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF48;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u, 5u, 3u, cpu.address("abs", 0x17BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF45 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF48;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF45u,0x00EF45u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF48u))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF48 AND
    cpu.logicAnd(0xFF00u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF4Bu,0x00EF48u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF48 AND
    cpu.logicAnd(0xFF00u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF4Bu,0x00EF48u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF48 AND
    cpu.logicAnd(0xFF00u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF4Bu,0x00EF48u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF48u,0x00EF48u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part23(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF42u: goto L_00EF42;
    case 0x00EF43u: goto L_00EF43;
    case 0x00EF45u: goto L_00EF45;
    case 0x00EF48u: goto L_00EF48;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF42u))return;
  // 42 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF42 PHA
    cpu.push("PHA", hw);
    goto L_00EF43;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF42 PHA
    cpu.push("PHA", hw);
    goto L_00EF43;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EF42 PHA
    cpu.push("PHA", hw);
    goto L_00EF43;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EF42 PHA
    cpu.push("PHA", hw);
    goto L_00EF43;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EF42 PHA
    cpu.push("PHA", hw);
    goto L_00EF43;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF42u,0x00EF42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF43u))return;
  // 42 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF43u,0x00EF43u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF45u))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u, 5u, 3u, cpu.address("abs", 0x17BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF45 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF48;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u, 5u, 3u, cpu.address("abs", 0x17BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF45 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF48;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u, 5u, 3u, cpu.address("abs", 0x17BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF45 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF48;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF45u,0x00EF45u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF48u))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF48 AND
    cpu.logicAnd(0xFF00u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF4Bu,0x00EF48u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF48 AND
    cpu.logicAnd(0xFF00u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF4Bu,0x00EF48u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF48 AND
    cpu.logicAnd(0xFF00u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF4Bu,0x00EF48u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF48u,0x00EF48u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1C1_part31(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF7Cu: goto L_00EF7C;
    case 0x00EF7Eu: goto L_00EF7E;
    case 0x00EF81u: goto L_00EF81;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF7Cu))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7C BNE -> $00EF99
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF99u,0x00EF7Cu); return; }
    goto L_00EF7E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7C BNE -> $00EF99
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF99u,0x00EF7Cu); return; }
    goto L_00EF7E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7C BNE -> $00EF99
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF99u,0x00EF7Cu); return; }
    goto L_00EF7E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7C BNE -> $00EF99
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF99u,0x00EF7Cu); return; }
    goto L_00EF7E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7C BNE -> $00EF99
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF99u,0x00EF7Cu); return; }
    goto L_00EF7E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,0x00EF7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF7Eu))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu, 5u, 3u, cpu.address("abs", 0x187Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF81;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu, 5u, 3u, cpu.address("abs", 0x187Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF81;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF81;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF81;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF81;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF7Eu,0x00EF7Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF81u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF81 BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF81u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF83u,0x00EF81u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF81 BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF81u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF83u,0x00EF81u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF81 BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF81u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF83u,0x00EF81u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF81 BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF81u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF83u,0x00EF81u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF81 BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF81u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF83u,0x00EF81u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF81u,0x00EF81u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part31(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF7Cu: goto L_00EF7C;
    case 0x00EF7Eu: goto L_00EF7E;
    case 0x00EF81u: goto L_00EF81;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF7Cu))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7C BNE -> $00EF99
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF99u,0x00EF7Cu); return; }
    goto L_00EF7E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7C BNE -> $00EF99
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF99u,0x00EF7Cu); return; }
    goto L_00EF7E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7C BNE -> $00EF99
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF99u,0x00EF7Cu); return; }
    goto L_00EF7E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7C BNE -> $00EF99
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF99u,0x00EF7Cu); return; }
    goto L_00EF7E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7C BNE -> $00EF99
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF99u,0x00EF7Cu); return; }
    goto L_00EF7E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,0x00EF7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF7Eu))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu, 5u, 3u, cpu.address("abs", 0x187Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF81;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu, 5u, 3u, cpu.address("abs", 0x187Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF81;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF81;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF81;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF81;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF7Eu,0x00EF7Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF81u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF81 BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF81u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF83u,0x00EF81u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF81 BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF81u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF83u,0x00EF81u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF81 BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF81u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF83u,0x00EF81u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF81 BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF81u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF83u,0x00EF81u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF81 BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF81u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF83u,0x00EF81u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF81u,0x00EF81u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E1M1X1CQ_part40(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EFADu: goto L_00EFAD;
    case 0x00EFAEu: goto L_00EFAE;
    case 0x00EFB0u: goto L_00EFB0;
    case 0x00EFB2u: goto L_00EFB2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EFAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFADu))return;
  // 57 variantes de decodificacao M/X para este endereco; 8 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFAD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFADu);return;} hw.unresolvedReturn(0x00EFADu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFAD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFADu);return;} hw.unresolvedReturn(0x00EFADu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFAD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFADu);return;} hw.unresolvedReturn(0x00EFADu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFAD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFADu);return;} hw.unresolvedReturn(0x00EFADu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFAD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFADu);return;} hw.unresolvedReturn(0x00EFADu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFAD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFADu);return;} hw.unresolvedReturn(0x00EFADu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFAD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFADu);return;} hw.unresolvedReturn(0x00EFADu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFAD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFADu);return;} hw.unresolvedReturn(0x00EFADu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFADu,0x00EFADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFAEu))return;
  // 33 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EFB0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EFB0;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EFB0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EFB0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFAEu,0x00EFAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB0u))return;
  // 33 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB0 BEQ -> $00EFBB
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EFBBu,0x00EFB0u); return; }
    goto L_00EFB2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB0 BEQ -> $00EFBB
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EFBBu,0x00EFB0u); return; }
    goto L_00EFB2;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB0 BEQ -> $00EFBB
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EFBBu,0x00EFB0u); return; }
    goto L_00EFB2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB0 BEQ -> $00EFBB
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EFBBu,0x00EFB0u); return; }
    goto L_00EFB2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB0u,0x00EFB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB2u))return;
  // 33 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u, 8u, 4u, 0x0294C1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EFB2 JSL -> $0294C1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEFB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFB6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0294C1u, 0x00EFB2u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB6u,0x00EFB2u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u, 8u, 4u, 0x0294C1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EFB2 JSL -> $0294C1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEFB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFB6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0294C1u, 0x00EFB2u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB6u,0x00EFB2u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u, 8u, 4u, 0x0294C1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EFB2 JSL -> $0294C1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEFB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFB6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0294C1u, 0x00EFB2u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB6u,0x00EFB2u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u, 8u, 4u, 0x0294C1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EFB2 JSL -> $0294C1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEFB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFB6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0294C1u, 0x00EFB2u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB6u,0x00EFB2u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB2u,0x00EFB2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1C1_part40(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EFD4u: goto L_00EFD4;
    case 0x00EFD7u: goto L_00EFD7;
    case 0x00EFD8u: goto L_00EFD8;
    case 0x00EFDBu: goto L_00EFDB;
    case 0x00EFDDu: goto L_00EFDD;
    case 0x00EFDFu: goto L_00EFDF;
    case 0x00EFE0u: goto L_00EFE0;
    case 0x00EFE3u: goto L_00EFE3;
    case 0x00EFE5u: goto L_00EFE5;
    case 0x00EFE7u: goto L_00EFE7;
    case 0x00F629u: goto L_00F629;
    case 0x00F62Du: goto L_00F62D;
    case 0x00F62Fu: goto L_00F62F;
    case 0x00F631u: goto L_00F631;
    case 0x00F633u: goto L_00F633;
    case 0x00F635u: goto L_00F635;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EFD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFD4u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD4u, 6u, 3u, cpu.address("abs", 0x94A5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFD4 JSR -> $0094A5 stack real
    { cpu.push16Value(hw,0xEFD6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFD7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x94A5u), 0x00EFD4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EFD7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFD4u,0x00EFD4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFD7u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFD7 CLC
    cpu.setFlag('C', false);
    goto L_00EFD8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFD7u,0x00EFD7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFD8u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD8u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD8u, 5u + ((((0xE913u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE913u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFD8 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xE913u), cpu.m8?8:16));
    goto L_00EFDB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFD8u,0x00EFD8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFDBu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFDB STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00EFDD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFDBu,0x00EFDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFDDu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFDD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EFDF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFDDu,0x00EFDDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFDFu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFDF CLC
    cpu.setFlag('C', false);
    goto L_00EFE0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFDFu,0x00EFDFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE0u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE0u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE0u, 5u + ((((0xE91Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE91Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFE0 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xE91Fu), cpu.m8?8:16));
    goto L_00EFE3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFE0u,0x00EFE0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE3u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFE3 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EFE5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFE3u,0x00EFE3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE5u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFE5 SEP
    cpu.sep(0x20u);
    goto L_00EFE7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFE5u,0x00EFE5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE7u))return;
  // 12 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFE7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFE7u);return;} hw.unresolvedReturn(0x00EFE7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFE7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFE7u);return;} hw.unresolvedReturn(0x00EFE7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFE7u,0x00EFE7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00F629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF629u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF629u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF629u, 8u, 4u, 0x00F606u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F629 JSL -> $00F606 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF62Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF62Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F606u, 0x00F629u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F62D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF629u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF629u, 8u, 4u, 0x00F606u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F629 JSL -> $00F606 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF62Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF62Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F606u, 0x00F629u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F62D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF629u,0x00F629u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00F62D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF62Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62D STZ
    hw.write(cpu.address("dp", 0x15u), 0, cpu.m8?8:16);
    goto L_00F62F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62D STZ
    hw.write(cpu.address("dp", 0x15u), 0, cpu.m8?8:16);
    goto L_00F62F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF62Du,0x00F62Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00F62F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF62Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62F STZ
    hw.write(cpu.address("dp", 0x16u), 0, cpu.m8?8:16);
    goto L_00F631;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62F STZ
    hw.write(cpu.address("dp", 0x16u), 0, cpu.m8?8:16);
    goto L_00F631;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF62Fu,0x00F62Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00F631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF631u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F631 STZ
    hw.write(cpu.address("dp", 0x17u), 0, cpu.m8?8:16);
    goto L_00F633;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F631 STZ
    hw.write(cpu.address("dp", 0x17u), 0, cpu.m8?8:16);
    goto L_00F633;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF631u,0x00F631u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00F633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF633u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F633 STZ
    hw.write(cpu.address("dp", 0x18u), 0, cpu.m8?8:16);
    goto L_00F635;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F633 STZ
    hw.write(cpu.address("dp", 0x18u), 0, cpu.m8?8:16);
    goto L_00F635;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF633u,0x00F633u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00F635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF635u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F635 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F635u);return;} hw.unresolvedReturn(0x00F635u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F635 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F635u);return;} hw.unresolvedReturn(0x00F635u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF635u,0x00F635u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part40(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EFD4u: goto L_00EFD4;
    case 0x00EFD7u: goto L_00EFD7;
    case 0x00EFD8u: goto L_00EFD8;
    case 0x00EFDBu: goto L_00EFDB;
    case 0x00EFDDu: goto L_00EFDD;
    case 0x00EFDFu: goto L_00EFDF;
    case 0x00EFE0u: goto L_00EFE0;
    case 0x00EFE3u: goto L_00EFE3;
    case 0x00EFE5u: goto L_00EFE5;
    case 0x00EFE7u: goto L_00EFE7;
    case 0x00F629u: goto L_00F629;
    case 0x00F62Du: goto L_00F62D;
    case 0x00F62Fu: goto L_00F62F;
    case 0x00F631u: goto L_00F631;
    case 0x00F633u: goto L_00F633;
    case 0x00F635u: goto L_00F635;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EFD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFD4u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD4u, 6u, 3u, cpu.address("abs", 0x94A5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFD4 JSR -> $0094A5 stack real
    { cpu.push16Value(hw,0xEFD6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFD7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x94A5u), 0x00EFD4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EFD7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFD4u,0x00EFD4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFD7u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFD7 CLC
    cpu.setFlag('C', false);
    goto L_00EFD8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFD7u,0x00EFD7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFD8u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD8u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD8u, 5u + ((((0xE913u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE913u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFD8 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xE913u), cpu.m8?8:16));
    goto L_00EFDB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFD8u,0x00EFD8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFDBu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFDB STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00EFDD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFDBu,0x00EFDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFDDu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFDD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EFDF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFDDu,0x00EFDDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFDFu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFDF CLC
    cpu.setFlag('C', false);
    goto L_00EFE0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFDFu,0x00EFDFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE0u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE0u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE0u, 5u + ((((0xE91Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xE91Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFE0 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xE91Fu), cpu.m8?8:16));
    goto L_00EFE3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFE0u,0x00EFE0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE3u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFE3 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EFE5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFE3u,0x00EFE3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE5u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFE5 SEP
    cpu.sep(0x20u);
    goto L_00EFE7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFE5u,0x00EFE5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE7u))return;
  // 12 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFE7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFE7u);return;} hw.unresolvedReturn(0x00EFE7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFE7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFE7u);return;} hw.unresolvedReturn(0x00EFE7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFE7u,0x00EFE7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00F629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF629u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF629u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF629u, 8u, 4u, 0x00F606u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F629 JSL -> $00F606 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF62Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF62Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F606u, 0x00F629u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F62D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF629u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF629u, 8u, 4u, 0x00F606u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F629 JSL -> $00F606 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF62Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF62Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F606u, 0x00F629u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F62D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF629u,0x00F629u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00F62D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF62Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62D STZ
    hw.write(cpu.address("dp", 0x15u), 0, cpu.m8?8:16);
    goto L_00F62F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62D STZ
    hw.write(cpu.address("dp", 0x15u), 0, cpu.m8?8:16);
    goto L_00F62F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF62Du,0x00F62Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00F62F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF62Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62F STZ
    hw.write(cpu.address("dp", 0x16u), 0, cpu.m8?8:16);
    goto L_00F631;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62F STZ
    hw.write(cpu.address("dp", 0x16u), 0, cpu.m8?8:16);
    goto L_00F631;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF62Fu,0x00F62Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00F631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF631u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F631 STZ
    hw.write(cpu.address("dp", 0x17u), 0, cpu.m8?8:16);
    goto L_00F633;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F631 STZ
    hw.write(cpu.address("dp", 0x17u), 0, cpu.m8?8:16);
    goto L_00F633;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF631u,0x00F631u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00F633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF633u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F633 STZ
    hw.write(cpu.address("dp", 0x18u), 0, cpu.m8?8:16);
    goto L_00F635;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F633 STZ
    hw.write(cpu.address("dp", 0x18u), 0, cpu.m8?8:16);
    goto L_00F635;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF633u,0x00F633u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00F635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF635u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F635 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F635u);return;} hw.unresolvedReturn(0x00F635u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F635 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F635u);return;} hw.unresolvedReturn(0x00F635u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF635u,0x00F635u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_018127_E0M1X1CQ_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0186F2u: goto L_0186F2;
    case 0x0186F3u: goto L_0186F3;
    case 0x0186F4u: goto L_0186F4;
    case 0x0186F5u: goto L_0186F5;
    case 0x0186F6u: goto L_0186F6;
    case 0x0186F7u: goto L_0186F7;
    case 0x0186F8u: goto L_0186F8;
    case 0x0186F9u: goto L_0186F9;
    case 0x0186FAu: goto L_0186FA;
    case 0x0186FBu: goto L_0186FB;
    case 0x0186FCu: goto L_0186FC;
    case 0x0186FDu: goto L_0186FD;
    case 0x0186FEu: goto L_0186FE;
    case 0x018701u: goto L_018701;
    case 0x018703u: goto L_018703;
    case 0x018705u: goto L_018705;
    case 0x018707u: goto L_018707;
    case 0x018709u: goto L_018709;
    case 0x01870Bu: goto L_01870B;
    case 0x01870Du: goto L_01870D;
    case 0x01870Fu: goto L_01870F;
    case 0x018711u: goto L_018711;
    case 0x018713u: goto L_018713;
    case 0x018715u: goto L_018715;
    case 0x018717u: goto L_018717;
    case 0x018718u: goto L_018718;
    case 0x01871Bu: goto L_01871B;
    case 0x01871Cu: goto L_01871C;
    case 0x01871Fu: goto L_01871F;
    case 0x018721u: goto L_018721;
    case 0x018723u: goto L_018723;
    case 0x018725u: goto L_018725;
    case 0x018727u: goto L_018727;
    case 0x018729u: goto L_018729;
    case 0x01872Bu: goto L_01872B;
    case 0x01872Cu: goto L_01872C;
    case 0x01872Fu: goto L_01872F;
    case 0x018731u: goto L_018731;
    case 0x018733u: goto L_018733;
    case 0x018735u: goto L_018735;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0186F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F2u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F2u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0186F2 ROR
    cpu.rorA();
    goto L_0186F3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86F2u,0x0186F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0186F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F3u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0186F3 DEY
    cpu.decReg('Y');
    goto L_0186F4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86F3u,0x0186F3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0186F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F4u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F4u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0186F4 ROR
    cpu.rorA();
    goto L_0186F5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86F4u,0x0186F4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0186F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F5u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F5u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0186F5 DEY
    cpu.decReg('Y');
    goto L_0186F6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86F5u,0x0186F5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0186F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F6u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F6u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0186F6 ROR
    cpu.rorA();
    goto L_0186F7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86F6u,0x0186F6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0186F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F7u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F7u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0186F7 DEY
    cpu.decReg('Y');
    goto L_0186F8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86F7u,0x0186F7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0186F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F8u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F8u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0186F8 ROR
    cpu.rorA();
    goto L_0186F9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86F8u,0x0186F8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0186F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F9u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F9u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0186F9 DEY
    cpu.decReg('Y');
    goto L_0186FA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86F9u,0x0186F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0186FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FAu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FAu,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0186FA ROR
    cpu.rorA();
    goto L_0186FB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86FAu,0x0186FAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0186FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FBu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FBu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0186FB DEY
    cpu.decReg('Y');
    goto L_0186FC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86FBu,0x0186FBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0186FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FCu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FCu,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0186FC ROR
    cpu.rorA();
    goto L_0186FD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86FCu,0x0186FCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0186FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FDu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FDu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0186FD DEY
    cpu.decReg('Y');
    goto L_0186FE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86FDu,0x0186FDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0186FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FEu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FEu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FEu, 4u, 3u, cpu.address("abs", 0xB187u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0186FE LDY
    cpu.setY(hw.readW(cpu.address("abs", 0xB187u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018701;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86FEu,0x0186FEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8701u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8701u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8701u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x9Du) & 0xFFFFu), 3u, 0u);
    // $018701 STA
    hw.write(cpu.addressDpLong(hw, 0x9Du), cpu.a, cpu.m8?8:16);
    goto L_018703;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8701u,0x018701u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8703u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8703u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8703u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xA2u) & 0xFFFFu), 3u, 0u);
    // $018703 STA
    hw.write(cpu.addressDpLong(hw, 0xA2u), cpu.a, cpu.m8?8:16);
    goto L_018705;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8703u,0x018703u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8705u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8705u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8705u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x98u) & 0xFFFFu), 3u, 0u);
    // $018705 STA
    hw.write(cpu.addressDpLong(hw, 0x98u), cpu.a, cpu.m8?8:16);
    goto L_018707;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8705u,0x018705u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8707u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x93u) & 0xFFFFu), 3u, 0u);
    // $018707 STA
    hw.write(cpu.addressDpLong(hw, 0x93u), cpu.a, cpu.m8?8:16);
    goto L_018709;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8707u,0x018707u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8709u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8709u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8709u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x93u) & 0xFFFFu), 3u, 0u);
    // $018709 STA
    hw.write(cpu.addressDpLong(hw, 0x93u), cpu.a, cpu.m8?8:16);
    goto L_01870B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8709u,0x018709u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01870B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Bu,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Eu) & 0xFFFFu), 3u, 0u);
    // $01870B STA
    hw.write(cpu.addressDpLong(hw, 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_01870D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x870Bu,0x01870Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01870D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Du,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Eu) & 0xFFFFu), 3u, 0u);
    // $01870D STA
    hw.write(cpu.addressDpLong(hw, 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_01870F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x870Du,0x01870Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01870F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Fu,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Eu) & 0xFFFFu), 3u, 0u);
    // $01870F STA
    hw.write(cpu.addressDpLong(hw, 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_018711;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x870Fu,0x01870Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8711u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8711u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8711u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x93u) & 0xFFFFu), 3u, 0u);
    // $018711 STA
    hw.write(cpu.addressDpLong(hw, 0x93u), cpu.a, cpu.m8?8:16);
    goto L_018713;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8711u,0x018711u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8713u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8713u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8713u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x59u) & 0xFFFFu), 3u, 0u);
    // $018713 STA
    hw.write(cpu.addressDpLong(hw, 0x59u), cpu.a, cpu.m8?8:16);
    goto L_018715;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8713u,0x018713u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8715u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8715u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8715u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x5Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018715 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x5Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018717;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8715u,0x018715u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8717u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8717u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8717u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018717 DEY
    cpu.decReg('Y');
    goto L_018718;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8717u,0x018717u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8718u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8718u,cpu,0x5Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8718u, 7u, 3u, cpu.address("absx", 0x5888u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018718 LSR
    cpu.lsrMem(hw, cpu.address("absx", 0x5888u), cpu.m8?8:16);
    goto L_01871B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8718u,0x018718u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01871B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01871B PLX
    cpu.pop("PLX", hw);
    goto L_01871C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x871Bu,0x01871Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01871C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Cu, 4u, 3u, cpu.address("abs", 0x8E87u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01871C STX
    hw.write(cpu.address("abs", 0x8E87u), cpu.x, cpu.x8?8:16);
    goto L_01871F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x871Cu,0x01871Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01871F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Fu,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Eu) & 0xFFFFu), 3u, 0u);
    // $01871F STA
    hw.write(cpu.addressDpLong(hw, 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_018721;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x871Fu,0x01871Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8721u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8721u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8721u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Eu) & 0xFFFFu), 3u, 0u);
    // $018721 STA
    hw.write(cpu.addressDpLong(hw, 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_018723;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8721u,0x018721u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8723u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8723u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8723u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Eu) & 0xFFFFu), 3u, 0u);
    // $018723 STA
    hw.write(cpu.addressDpLong(hw, 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_018725;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8723u,0x018723u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8725u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8725u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8725u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Eu) & 0xFFFFu), 3u, 0u);
    // $018725 STA
    hw.write(cpu.addressDpLong(hw, 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_018727;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8725u,0x018725u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018727:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8727u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8727u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8727u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Eu) & 0xFFFFu), 3u, 0u);
    // $018727 STA
    hw.write(cpu.addressDpLong(hw, 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_018729;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8727u,0x018727u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018729:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8729u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8729u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8729u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xDCu) & 0xFFFFu), 3u, 0u);
    // $018729 STA
    hw.write(cpu.addressDpLong(hw, 0xDCu), cpu.a, cpu.m8?8:16);
    goto L_01872B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8729u,0x018729u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01872B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Bu,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01872B SED
    cpu.setFlag('D', true);
    goto L_01872C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x872Bu,0x01872Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01872C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu, 4u, 3u, cpu.address("abs", 0x8E87u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01872C STX
    hw.write(cpu.address("abs", 0x8E87u), cpu.x, cpu.x8?8:16);
    goto L_01872F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x872Cu,0x01872Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01872F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Fu,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Eu) & 0xFFFFu), 3u, 0u);
    // $01872F STA
    hw.write(cpu.addressDpLong(hw, 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_018731;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x872Fu,0x01872Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8731u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8731u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8731u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Eu) & 0xFFFFu), 3u, 0u);
    // $018731 STA
    hw.write(cpu.addressDpLong(hw, 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_018733;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8731u,0x018731u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8733u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8733u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8733u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x5Cu) & 0xFFFFu), 3u, 0u);
    // $018733 STA
    hw.write(cpu.addressDpLong(hw, 0x5Cu), cpu.a, cpu.m8?8:16);
    goto L_018735;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8733u,0x018733u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8735u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8735u,cpu,0xDBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8735u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018735 STP
    hw.stopped=true; return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8735u,0x018735u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_028528_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0284E7u: goto L_0284E7;
    case 0x028528u: goto L_028528;
    case 0x02852Bu: goto L_02852B;
    case 0x02852Eu: goto L_02852E;
    case 0x028530u: goto L_028530;
    case 0x028532u: goto L_028532;
    case 0x028534u: goto L_028534;
    case 0x028536u: goto L_028536;
    case 0x028539u: goto L_028539;
    case 0x02853Bu: goto L_02853B;
    case 0x02853Cu: goto L_02853C;
    case 0x02853Eu: goto L_02853E;
    case 0x02853Fu: goto L_02853F;
    case 0x028541u: goto L_028541;
    case 0x028544u: goto L_028544;
    case 0x028546u: goto L_028546;
    case 0x028549u: goto L_028549;
    case 0x02854Cu: goto L_02854C;
    case 0x02854Fu: goto L_02854F;
    case 0x028551u: goto L_028551;
    case 0x028552u: goto L_028552;
    case 0x028554u: goto L_028554;
    case 0x028557u: goto L_028557;
    case 0x02855Au: goto L_02855A;
    case 0x02855Cu: goto L_02855C;
    case 0x02855Fu: goto L_02855F;
    case 0x028563u: goto L_028563;
    case 0x028564u: goto L_028564;
    case 0x028566u: goto L_028566;
    case 0x028567u: goto L_028567;
    case 0x02856Bu: goto L_02856B;
    case 0x02856Eu: goto L_02856E;
    case 0x028571u: goto L_028571;
    case 0x028573u: goto L_028573;
    case 0x028574u: goto L_028574;
    case 0x028578u: goto L_028578;
    case 0x02857Bu: goto L_02857B;
    case 0x02857Fu: goto L_02857F;
    case 0x028581u: goto L_028581;
    case 0x028582u: goto L_028582;
    case 0x028586u: goto L_028586;
    case 0x028589u: goto L_028589;
    case 0x02858Au: goto L_02858A;
    case 0x02858Cu: goto L_02858C;
    case 0x02858Eu: goto L_02858E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0284E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0284E7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x0284E7u);return;} hw.unresolvedReturn(0x0284E7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_028528:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8528u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8528u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8528u, 6u, 3u, cpu.address("abs", 0x849Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $028528 JSR -> $02849F stack real
    { cpu.push16Value(hw,0x852Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x852Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x849Fu), 0x028528u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02852B;
L_02852B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x852Bu,0x02852Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Bu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02852B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02852E;
L_02852E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02852E BNE -> $0284E7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0284E7; }
    goto L_028530;
L_028530:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8530u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8530u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8530u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028530 LDA
    cpu.setA(0x4u, 8);
    goto L_028532;
L_028532:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8532u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8532u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8532u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028532 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_028534;
L_028534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8534u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8534u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8534u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028534 LDY
    cpu.setY(0x7u, 8);
    goto L_028536;
L_028536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8536u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8536u, 4u + ((((0x170Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028536 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x170Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028539;
L_028539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8539u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8539u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8539u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028539 BEQ -> $02853F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02853F; }
    goto L_02853B;
L_02853B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x853Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x853Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x853Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02853B DEY
    cpu.decReg('Y');
    goto L_02853C;
L_02853C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x853Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x853Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x853Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02853C BPL -> $028536
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_028536; }
    goto L_02853E;
L_02853E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x853Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x853Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x853Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02853E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02853Eu);return;} hw.unresolvedReturn(0x02853Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_02853F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x853Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x853Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x853Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02853F LDA
    cpu.setA(0x7u, 8);
    goto L_028541;
L_028541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8541u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8541u, 5u, 3u, cpu.address("absy", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028541 STA
    hw.write(cpu.address("absy", 0x170Bu), cpu.a, cpu.m8?8:16);
    goto L_028544;
L_028544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8544u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8544u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028544 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028546;
L_028546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8546u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8546u, 5u, 3u, cpu.address("absy", 0x1715u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028546 STA
    hw.write(cpu.address("absy", 0x1715u), cpu.a, cpu.m8?8:16);
    goto L_028549;
L_028549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8549u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8549u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028549 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02854C;
L_02854C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Cu, 5u, 3u, cpu.address("absy", 0x1729u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02854C STA
    hw.write(cpu.address("absy", 0x1729u), cpu.a, cpu.m8?8:16);
    goto L_02854F;
L_02854F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02854F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028551;
L_028551:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8551u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8551u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8551u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028551 CLC
    cpu.setFlag('C', false);
    goto L_028552;
L_028552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8552u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8552u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028552 ADC
    cpu.adc(0x4u);
    goto L_028554;
L_028554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8554u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8554u, 5u, 3u, cpu.address("absy", 0x171Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028554 STA
    hw.write(cpu.address("absy", 0x171Fu), cpu.a, cpu.m8?8:16);
    goto L_028557;
L_028557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8557u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8557u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028557 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02855A;
L_02855A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x855Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x855Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x855Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02855A ADC
    cpu.adc(0x0u);
    goto L_02855C;
L_02855C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x855Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x855Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x855Cu, 5u, 3u, cpu.address("absy", 0x1733u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02855C STA
    hw.write(cpu.address("absy", 0x1733u), cpu.a, cpu.m8?8:16);
    goto L_02855F;
L_02855F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x855Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x855Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x855Fu, 8u, 4u, 0x01ACF9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02855F JSL -> $01ACF9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8562u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8563u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01ACF9u, 0x02855Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_028563;
L_028563:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8563u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8563u,0x028563u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8563u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8563u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $028563 PHX
    cpu.push("PHX", hw);
    goto L_028564;
L_028564:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8564u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8564u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8564u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028564 AND
    cpu.logicAnd(0x7u);
    goto L_028566;
L_028566:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8566u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8566u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8566u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028566 TAX
    cpu.transfer("TAX");
    goto L_028567;
L_028567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8567u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8567u, 5u, 4u, ((0x028510u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028567 LDA
    cpu.loadA(hw.readW(((0x28510u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02856B;
L_02856B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x856Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x856Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x856Bu, 5u, 3u, cpu.address("absy", 0x1747u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02856B STA
    hw.write(cpu.address("absy", 0x1747u), cpu.a, cpu.m8?8:16);
    goto L_02856E;
L_02856E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x856Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x856Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x856Eu, 4u, 3u, cpu.address("abs", 0x148Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02856E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028571;
L_028571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8571u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8571u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8571u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028571 AND
    cpu.logicAnd(0x7u);
    goto L_028573;
L_028573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8573u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8573u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028573 TAX
    cpu.transfer("TAX");
    goto L_028574;
L_028574:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8574u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8574u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8574u, 5u, 4u, ((0x028518u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028574 LDA
    cpu.loadA(hw.readW(((0x28518u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028578;
L_028578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8578u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8578u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8578u, 5u, 3u, cpu.address("absy", 0x173Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028578 STA
    hw.write(cpu.address("absy", 0x173Du), cpu.a, cpu.m8?8:16);
    goto L_02857B;
L_02857B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Bu, 8u, 4u, 0x01ACF9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02857B JSL -> $01ACF9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x857Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x857Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01ACF9u, 0x02857Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02857F;
L_02857F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x857Fu,0x02857Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02857F AND
    cpu.logicAnd(0x7u);
    goto L_028581;
L_028581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8581u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8581u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028581 TAX
    cpu.transfer("TAX");
    goto L_028582;
L_028582:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8582u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8582u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8582u, 5u, 4u, ((0x028520u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028582 LDA
    cpu.loadA(hw.readW(((0x28520u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028586;
L_028586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8586u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8586u, 5u, 3u, cpu.address("absy", 0x176Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028586 STA
    hw.write(cpu.address("absy", 0x176Fu), cpu.a, cpu.m8?8:16);
    goto L_028589;
L_028589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8589u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8589u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8589u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $028589 PLX
    cpu.pop("PLX", hw);
    goto L_02858A;
L_02858A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Au,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02858A DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_02858C;
L_02858C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02858C BPL -> $028536
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_028536; }
    goto L_02858E;
L_02858E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02858E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02858Eu);return;} hw.unresolvedReturn(0x02858Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_04DC09_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04DC09u: goto L_04DC09;
    case 0x04DC0Bu: goto L_04DC0B;
    case 0x04DC0Eu: goto L_04DC0E;
    case 0x04DC0Fu: goto L_04DC0F;
    case 0x04DC10u: goto L_04DC10;
    case 0x04DC11u: goto L_04DC11;
    case 0x04DC14u: goto L_04DC14;
    case 0x04DC15u: goto L_04DC15;
    case 0x04DC19u: goto L_04DC19;
    case 0x04DC1Cu: goto L_04DC1C;
    case 0x04DC1Eu: goto L_04DC1E;
    case 0x04DC21u: goto L_04DC21;
    case 0x04DC23u: goto L_04DC23;
    case 0x04DC26u: goto L_04DC26;
    case 0x04DC28u: goto L_04DC28;
    case 0x04DC2Au: goto L_04DC2A;
    case 0x04DC2Cu: goto L_04DC2C;
    case 0x04DC2Fu: goto L_04DC2F;
    case 0x04DC30u: goto L_04DC30;
    case 0x04DC33u: goto L_04DC33;
    case 0x04DC36u: goto L_04DC36;
    case 0x04DC38u: goto L_04DC38;
    case 0x04DC3Au: goto L_04DC3A;
    case 0x04DC3Du: goto L_04DC3D;
    case 0x04DC3Fu: goto L_04DC3F;
    case 0x04DC42u: goto L_04DC42;
    case 0x04DC44u: goto L_04DC44;
    case 0x04DC47u: goto L_04DC47;
    case 0x04DC49u: goto L_04DC49;
    case 0x04DC4Au: goto L_04DC4A;
    case 0x04DC4Du: goto L_04DC4D;
    case 0x04DC4Fu: goto L_04DC4F;
    case 0x04DC50u: goto L_04DC50;
    case 0x04DC51u: goto L_04DC51;
    case 0x04DC54u: goto L_04DC54;
    case 0x04DC56u: goto L_04DC56;
    case 0x04DC57u: goto L_04DC57;
    case 0x04DC5Au: goto L_04DC5A;
    case 0x04DC5Du: goto L_04DC5D;
    case 0x04DC60u: goto L_04DC60;
    case 0x04DC63u: goto L_04DC63;
    case 0x04DC64u: goto L_04DC64;
    case 0x04DC67u: goto L_04DC67;
    case 0x04DC69u: goto L_04DC69;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04DC09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC09u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC09u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC09 SEP
    cpu.sep(0x30u);
    goto L_04DC0B;
L_04DC0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Bu, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC0B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04DC0E;
L_04DC0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC0E LSR
    cpu.lsrA();
    goto L_04DC0F;
L_04DC0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC0F LSR
    cpu.lsrA();
    goto L_04DC10;
L_04DC10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC10u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC10u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC10 TAX
    cpu.transfer("TAX");
    goto L_04DC11;
L_04DC11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u, 4u + ((((0x1F11u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC11 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04DC14;
L_04DC14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC14u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC14u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC14 TAX
    cpu.transfer("TAX");
    goto L_04DC15;
L_04DC15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC15u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC15u, 5u, 4u, ((0x04DC02u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC15 LDA
    cpu.loadA(hw.readW(((0x4DC02u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04DC19;
L_04DC19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC19u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC19u, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC19 STA
    hw.write(cpu.address("abs", 0x1931u), cpu.a, cpu.m8?8:16);
    goto L_04DC1C;
L_04DC1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC1C LDA
    cpu.setA(0x11u, 8);
    goto L_04DC1E;
L_04DC1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Eu, 4u, 3u, cpu.address("abs", 0x192Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC1E STA
    hw.write(cpu.address("abs", 0x192Bu), cpu.a, cpu.m8?8:16);
    goto L_04DC21;
L_04DC21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC21u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC21 LDA
    cpu.setA(0x7u, 8);
    goto L_04DC23;
L_04DC23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC23u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC23u, 4u, 3u, cpu.address("abs", 0x1925u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC23 STA
    hw.write(cpu.address("abs", 0x1925u), cpu.a, cpu.m8?8:16);
    goto L_04DC26;
L_04DC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC26 LDA
    cpu.setA(0x3u, 8);
    goto L_04DC28;
L_04DC28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC28u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC28u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC28 STA
    hw.write(cpu.address("dp", 0x5Bu), cpu.a, cpu.m8?8:16);
    goto L_04DC2A;
L_04DC2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC2A REP
    cpu.rep(0x10u);
    goto L_04DC2C;
L_04DC2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC2C LDX
    cpu.setX(0x0u, 16);
    goto L_04DC2F;
L_04DC2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC2F TXA
    cpu.transfer("TXA");
    goto L_04DC30;
L_04DC30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC30u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC30u, 6u, 3u, cpu.address("abs", 0xD770u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04DC30 JSR -> $04D770 stack real
    { cpu.push16Value(hw,0xDC32u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC33u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD770u), 0x04DC30u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04DC33;
L_04DC33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC33u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC33u,0x04DC33u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC33u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC33u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC33 CPX
    cpu.compareX(0x1B0u);
    goto L_04DC36;
L_04DC36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC36u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC36 BNE -> $04DC30
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04DC30; }
    goto L_04DC38;
L_04DC38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC38u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC38u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC38 REP
    cpu.rep(0x30u);
    goto L_04DC3A;
L_04DC3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC3A LDA
    cpu.setA(0xD000u, 16);
    goto L_04DC3D;
L_04DC3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC3D STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04DC3F;
L_04DC3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC3F LDX
    cpu.setX(0x0u, 16);
    goto L_04DC42;
L_04DC42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC42u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC42u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC42 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04DC44;
L_04DC44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC44u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC44u, 6u, 3u, cpu.address("absx", 0x0FBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC44 STA
    hw.write(cpu.address("absx", 0xFBEu), cpu.a, cpu.m8?8:16);
    goto L_04DC47;
L_04DC47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC47u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC47u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC47 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04DC49;
L_04DC49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC49u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC49 CLC
    cpu.setFlag('C', false);
    goto L_04DC4A;
L_04DC4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC4A ADC
    cpu.adc(0x8u);
    goto L_04DC4D;
L_04DC4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC4D STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04DC4F;
L_04DC4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC4F INX
    cpu.inc('X');
    goto L_04DC50;
L_04DC50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC50u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC50 INX
    cpu.inc('X');
    goto L_04DC51;
L_04DC51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC51u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC51u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC51 CPX
    cpu.compareX(0x400u);
    goto L_04DC54;
L_04DC54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC54u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC54 BNE -> $04DC42
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04DC42; }
    goto L_04DC56;
L_04DC56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC56u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC56u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04DC56 PHB
    cpu.push("PHB", hw);
    goto L_04DC57;
L_04DC57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC57u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC57u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC57 LDA
    cpu.setA(0x7FFu, 16);
    goto L_04DC5A;
L_04DC5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC5A LDX
    cpu.setX(0xF7DFu, 16);
    goto L_04DC5D;
L_04DC5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC5D LDY
    cpu.setY(0xC800u, 16);
    goto L_04DC60;
L_04DC60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC60u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xDC60u, (std::uint32_t(cpu.a)+1u), 0x0Cu, 0x7Eu);
    // $04DC60 MVN
    cpu.blockMove(hw, 0x7Eu, 0x0Cu, false);
    goto L_04DC63;
L_04DC63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC63u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC63u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04DC63 PLB
    cpu.pop("PLB", hw);
    goto L_04DC64;
L_04DC64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC64u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC64u, 6u, 3u, cpu.address("abs", 0xD7F2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04DC64 JSR -> $04D7F2 stack real
    { cpu.push16Value(hw,0xDC66u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC67u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD7F2u), 0x04DC64u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04DC67;
L_04DC67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC67u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC67u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC67u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC67 SEP
    cpu.sep(0x30u);
    goto L_04DC69;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC67u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC67u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DC67 SEP
    cpu.sep(0x30u);
    goto L_04DC69;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC67u,0x04DC67u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04DC69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC69u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC69u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $04DC69 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x04DC69u);return;} hw.unresolvedReturn(0x04DC69u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_05BC76_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05BC49u: goto L_05BC49;
    case 0x05BC76u: goto L_05BC76;
    case 0x05BC79u: goto L_05BC79;
    case 0x05BC7Cu: goto L_05BC7C;
    case 0x05BC7Eu: goto L_05BC7E;
    case 0x05BC81u: goto L_05BC81;
    case 0x05BC83u: goto L_05BC83;
    case 0x05BC87u: goto L_05BC87;
    case 0x05BC8Au: goto L_05BC8A;
    case 0x05BC8Cu: goto L_05BC8C;
    case 0x05BC8Fu: goto L_05BC8F;
    case 0x05BC91u: goto L_05BC91;
    case 0x05BC94u: goto L_05BC94;
    case 0x05BC97u: goto L_05BC97;
    case 0x05BC9Bu: goto L_05BC9B;
    case 0x05BC9Eu: goto L_05BC9E;
    case 0x05BCA0u: goto L_05BCA0;
    case 0x05BCA2u: goto L_05BCA2;
    case 0x05BCA5u: goto L_05BCA5;
    case 0x05BCA7u: goto L_05BCA7;
    case 0x05BCAAu: goto L_05BCAA;
    case 0x05BCADu: goto L_05BCAD;
    case 0x05BCAFu: goto L_05BCAF;
    case 0x05BCB2u: goto L_05BCB2;
    case 0x05BCB4u: goto L_05BCB4;
    case 0x05BCB8u: goto L_05BCB8;
    case 0x05BCBBu: goto L_05BCBB;
    case 0x05BCBDu: goto L_05BCBD;
    case 0x05BCBFu: goto L_05BCBF;
    case 0x05BCC1u: goto L_05BCC1;
    case 0x05BCC3u: goto L_05BCC3;
    case 0x05BCC6u: goto L_05BCC6;
    case 0x05BCC8u: goto L_05BCC8;
    case 0x05BCCCu: goto L_05BCCC;
    case 0x05BCCFu: goto L_05BCCF;
    case 0x05BCD1u: goto L_05BCD1;
    case 0x05BCD3u: goto L_05BCD3;
    case 0x05BCD5u: goto L_05BCD5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05BC49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC49u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC49u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC49u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05BC49 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x05BC49u);return;} hw.unresolvedReturn(0x05BC49u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC49u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC49u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05BC49 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x05BC49u);return;} hw.unresolvedReturn(0x05BC49u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC49u,0x05BC49u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05BC76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC76u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC76u, 4u, 3u, cpu.address("abs", 0x1456u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC76 STZ
    hw.write(cpu.address("abs", 0x1456u), 0, cpu.m8?8:16);
    goto L_05BC79;
L_05BC79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC79u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC79u, 4u, 3u, cpu.address("abs", 0x009Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC79 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05BC7C;
L_05BC7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC7C BNE -> $05BC49
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05BC49; }
    goto L_05BC7E;
L_05BC7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Eu, 4u, 3u, cpu.address("abs", 0x143Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x143Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05BC81;
L_05BC81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC81u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC81 BEQ -> $05BC49
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05BC49; }
    goto L_05BC83;
L_05BC83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC83u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC83u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05BC83 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC86u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC87u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x05BC83u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05BC87;
L_05BC87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC87u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC87u,0x05BC87u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC87u,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC87u, 4u, 3u, cpu.address("abs", 0x4DC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC87 EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0x4DC0u), cpu.m8?8:16));
    goto L_05BC8A;
L_05BC8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Au,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC8A CPY
    cpu.compareY(0x49u);
    goto L_05BC8C;
L_05BC8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Cu, 4u + ((((0xBC49u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xBC49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC8C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xBC49u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05BC8F;
L_05BC8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Fu,cpu,0x83u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Fu, 4u, 2u, cpu.addressStack(0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC8F STA
    hw.write(cpu.addressStack(0xC2u), cpu.a, cpu.m8?8:16);
    goto L_05BC91;
L_05BC91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC91u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC91u, 5u, 3u, cpu.address("absx", 0x49C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC91 STZ
    hw.write(cpu.address("absx", 0x49C6u), 0, cpu.m8?8:16);
    goto L_05BC94;
L_05BC94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u, 4u + ((((0xBFF5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xBFF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC94 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xBFF5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05BC97;
L_05BC97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u, 5u, 4u, ((0xBC49C5u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC97 ORA
    cpu.logicOr(hw.readW(((0xBC49C5u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_05BC9B;
L_05BC9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Bu,cpu,0x2Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Bu, 6u, 3u, cpu.address("abs", 0x27C3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC9B ROL
    cpu.rolMem(hw, cpu.address("abs", 0x27C3u), cpu.m8?8:16);
    goto L_05BC9E;
L_05BC9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu,cpu,0xC7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x87u) & 0xFFFFu), 3u, 0u);
    // $05BC9E CMP
    cpu.compareA(hw.readW(cpu.addressDpLong(hw, 0x87u), cpu.m8?8:16));
    goto L_05BCA0;
L_05BCA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u,cpu,0xC7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x49u) & 0xFFFFu), 3u, 0u);
    // $05BCA0 CMP
    cpu.compareA(hw.readW(cpu.addressDpLong(hw, 0x49u), cpu.m8?8:16));
    goto L_05BCA2;
L_05BCA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u, 4u + ((((0xBC49u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xBC49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCA2 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xBC49u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05BCA5;
L_05BCA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCA5 LDA
    cpu.setA(0x4u, 8);
    goto L_05BCA7;
L_05BCA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA7u, 4u, 3u, cpu.address("abs", 0x1456u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCA7 STA
    hw.write(cpu.address("abs", 0x1456u), cpu.a, cpu.m8?8:16);
    goto L_05BCAA;
L_05BCAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu, 4u, 3u, cpu.address("abs", 0x143Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCAA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x143Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05BCAD;
L_05BCAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCADu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCAD BEQ -> $05BC49
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05BC49; }
    goto L_05BCAF;
L_05BCAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAFu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAFu, 4u, 3u, cpu.address("abs", 0x009Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCAF LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x9Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05BCB2;
L_05BCB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCB2 BNE -> $05BC49
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05BC49; }
    goto L_05BCB4;
L_05BCB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB4u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05BCB4 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBCB7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBCB8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x05BCB4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05BCB8;
L_05BCB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCB8u,0x05BCB8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB8u,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB8u, 4u, 3u, cpu.address("abs", 0x98C0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCB8 EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0x98C0u), cpu.m8?8:16));
    goto L_05BCBB;
L_05BCBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBBu,cpu,0xC1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBBu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x55u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $05BCBB CMP
    cpu.compareA(hw.readW(cpu.addressDpIndirectX(hw, 0x55u), cpu.m8?8:16));
    goto L_05BCBD;
L_05BCBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCBD CMP
    cpu.compareA(0xBBu);
    goto L_05BCBF;
L_05BCBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBFu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x83u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCBF CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x83u), cpu.m8?8:16));
    goto L_05BCC1;
L_05BCC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCC1 REP
    cpu.rep(0x49u);
    goto L_05BCC3;
L_05BCC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC3u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC3u, 4u + ((((0xC659u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xC659u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCC3 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xC659u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05BCC6;
L_05BCC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC6u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCC6 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0xBFu), cpu.m8?8:16));
    goto L_05BCC8;
L_05BCC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC8u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC8u, 5u, 4u, ((0xC7C1C5u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCC8 ORA
    cpu.logicOr(hw.readW(((0xC7C1C5u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_05BCCC;
L_05BCCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCCu,cpu,0x2Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCCu, 6u, 3u, cpu.address("abs", 0x27C3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCCC ROL
    cpu.rolMem(hw, cpu.address("abs", 0x27C3u), cpu.m8?8:16);
    goto L_05BCCF;
L_05BCCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCFu,cpu,0xC7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCFu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x87u) & 0xFFFFu), 3u, 0u);
    // $05BCCF CMP
    cpu.compareA(hw.readW(cpu.addressDpLong(hw, 0x87u), cpu.m8?8:16));
    goto L_05BCD1;
L_05BCD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD1u,cpu,0xC7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD1u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xBCu) & 0xFFFFu), 3u, 0u);
    // $05BCD1 CMP
    cpu.compareA(hw.readW(cpu.addressDpLong(hw, 0xBCu), cpu.m8?8:16));
    goto L_05BCD3;
L_05BCD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD3u,cpu,0xC7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD3u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Cu) & 0xFFFFu), 3u, 0u);
    // $05BCD3 CMP
    cpu.compareA(hw.readW(cpu.addressDpLong(hw, 0x1Cu), cpu.m8?8:16));
    goto L_05BCD5;
L_05BCD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCD5 INY
    cpu.inc('Y');
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCD6u,0x05BCD5u); return;
}

void sub_05BC76_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05BC49u: goto L_05BC49;
    case 0x05BC76u: goto L_05BC76;
    case 0x05BC79u: goto L_05BC79;
    case 0x05BC7Cu: goto L_05BC7C;
    case 0x05BC7Eu: goto L_05BC7E;
    case 0x05BC81u: goto L_05BC81;
    case 0x05BC83u: goto L_05BC83;
    case 0x05BC87u: goto L_05BC87;
    case 0x05BC8Au: goto L_05BC8A;
    case 0x05BC8Cu: goto L_05BC8C;
    case 0x05BC8Fu: goto L_05BC8F;
    case 0x05BC91u: goto L_05BC91;
    case 0x05BC94u: goto L_05BC94;
    case 0x05BC97u: goto L_05BC97;
    case 0x05BC9Bu: goto L_05BC9B;
    case 0x05BC9Eu: goto L_05BC9E;
    case 0x05BCA0u: goto L_05BCA0;
    case 0x05BCA2u: goto L_05BCA2;
    case 0x05BCA5u: goto L_05BCA5;
    case 0x05BCA7u: goto L_05BCA7;
    case 0x05BCAAu: goto L_05BCAA;
    case 0x05BCADu: goto L_05BCAD;
    case 0x05BCAFu: goto L_05BCAF;
    case 0x05BCB2u: goto L_05BCB2;
    case 0x05BCB4u: goto L_05BCB4;
    case 0x05BCB8u: goto L_05BCB8;
    case 0x05BCBBu: goto L_05BCBB;
    case 0x05BCBDu: goto L_05BCBD;
    case 0x05BCBFu: goto L_05BCBF;
    case 0x05BCC1u: goto L_05BCC1;
    case 0x05BCC3u: goto L_05BCC3;
    case 0x05BCC6u: goto L_05BCC6;
    case 0x05BCC8u: goto L_05BCC8;
    case 0x05BCCCu: goto L_05BCCC;
    case 0x05BCCFu: goto L_05BCCF;
    case 0x05BCD1u: goto L_05BCD1;
    case 0x05BCD3u: goto L_05BCD3;
    case 0x05BCD5u: goto L_05BCD5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05BC49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC49u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC49u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05BC49 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x05BC49u);return;} hw.unresolvedReturn(0x05BC49u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_05BC76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC76u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC76u, 4u, 3u, cpu.address("abs", 0x1456u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC76 STZ
    hw.write(cpu.address("abs", 0x1456u), 0, cpu.m8?8:16);
    goto L_05BC79;
L_05BC79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC79u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC79u, 4u, 3u, cpu.address("abs", 0x009Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC79 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05BC7C;
L_05BC7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC7C BNE -> $05BC49
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05BC49; }
    goto L_05BC7E;
L_05BC7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Eu, 4u, 3u, cpu.address("abs", 0x143Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x143Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05BC81;
L_05BC81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC81u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC81 BEQ -> $05BC49
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05BC49; }
    goto L_05BC83;
L_05BC83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC83u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC83u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05BC83 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC86u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC87u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x05BC83u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05BC87;
L_05BC87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC87u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC87u,0x05BC87u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC87u,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC87u, 4u, 3u, cpu.address("abs", 0x4DC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC87 EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0x4DC0u), cpu.m8?8:16));
    goto L_05BC8A;
L_05BC8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Au,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC8A CPY
    cpu.compareY(0x49u);
    goto L_05BC8C;
L_05BC8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Cu, 4u + ((((0xBC49u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xBC49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC8C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xBC49u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05BC8F;
L_05BC8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Fu,cpu,0x83u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Fu, 4u, 2u, cpu.addressStack(0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC8F STA
    hw.write(cpu.addressStack(0xC2u), cpu.a, cpu.m8?8:16);
    goto L_05BC91;
L_05BC91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC91u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC91u, 5u, 3u, cpu.address("absx", 0x49C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC91 STZ
    hw.write(cpu.address("absx", 0x49C6u), 0, cpu.m8?8:16);
    goto L_05BC94;
L_05BC94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC94u, 4u + ((((0xBFF5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xBFF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC94 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xBFF5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05BC97;
L_05BC97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC97u, 5u, 4u, ((0xBC49C5u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC97 ORA
    cpu.logicOr(hw.readW(((0xBC49C5u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_05BC9B;
L_05BC9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Bu,cpu,0x2Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Bu, 6u, 3u, cpu.address("abs", 0x27C3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BC9B ROL
    cpu.rolMem(hw, cpu.address("abs", 0x27C3u), cpu.m8?8:16);
    goto L_05BC9E;
L_05BC9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu,cpu,0xC7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x87u) & 0xFFFFu), 3u, 0u);
    // $05BC9E CMP
    cpu.compareA(hw.readW(cpu.addressDpLong(hw, 0x87u), cpu.m8?8:16));
    goto L_05BCA0;
L_05BCA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u,cpu,0xC7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA0u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x49u) & 0xFFFFu), 3u, 0u);
    // $05BCA0 CMP
    cpu.compareA(hw.readW(cpu.addressDpLong(hw, 0x49u), cpu.m8?8:16));
    goto L_05BCA2;
L_05BCA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA2u, 4u + ((((0xBC49u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xBC49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCA2 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xBC49u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05BCA5;
L_05BCA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCA5 LDA
    cpu.setA(0x4u, 8);
    goto L_05BCA7;
L_05BCA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA7u, 4u, 3u, cpu.address("abs", 0x1456u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCA7 STA
    hw.write(cpu.address("abs", 0x1456u), cpu.a, cpu.m8?8:16);
    goto L_05BCAA;
L_05BCAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu, 4u, 3u, cpu.address("abs", 0x143Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCAA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x143Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05BCAD;
L_05BCAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCADu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCAD BEQ -> $05BC49
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05BC49; }
    goto L_05BCAF;
L_05BCAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAFu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAFu, 4u, 3u, cpu.address("abs", 0x009Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCAF LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x9Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05BCB2;
L_05BCB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCB2 BNE -> $05BC49
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05BC49; }
    goto L_05BCB4;
L_05BCB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB4u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05BCB4 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBCB7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBCB8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x05BCB4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05BCB8;
L_05BCB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCB8u,0x05BCB8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB8u,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB8u, 4u, 3u, cpu.address("abs", 0x98C0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCB8 EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0x98C0u), cpu.m8?8:16));
    goto L_05BCBB;
L_05BCBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBBu,cpu,0xC1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBBu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x55u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $05BCBB CMP
    cpu.compareA(hw.readW(cpu.addressDpIndirectX(hw, 0x55u), cpu.m8?8:16));
    goto L_05BCBD;
L_05BCBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCBD CMP
    cpu.compareA(0xBBu);
    goto L_05BCBF;
L_05BCBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBFu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x83u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCBF CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x83u), cpu.m8?8:16));
    goto L_05BCC1;
L_05BCC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCC1 REP
    cpu.rep(0x49u);
    goto L_05BCC3;
L_05BCC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC3u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC3u, 4u + ((((0xC659u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xC659u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCC3 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xC659u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05BCC6;
L_05BCC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC6u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCC6 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0xBFu), cpu.m8?8:16));
    goto L_05BCC8;
L_05BCC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC8u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC8u, 5u, 4u, ((0xC7C1C5u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCC8 ORA
    cpu.logicOr(hw.readW(((0xC7C1C5u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_05BCCC;
L_05BCCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCCu,cpu,0x2Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCCu, 6u, 3u, cpu.address("abs", 0x27C3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCCC ROL
    cpu.rolMem(hw, cpu.address("abs", 0x27C3u), cpu.m8?8:16);
    goto L_05BCCF;
L_05BCCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCFu,cpu,0xC7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCFu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x87u) & 0xFFFFu), 3u, 0u);
    // $05BCCF CMP
    cpu.compareA(hw.readW(cpu.addressDpLong(hw, 0x87u), cpu.m8?8:16));
    goto L_05BCD1;
L_05BCD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD1u,cpu,0xC7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD1u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xBCu) & 0xFFFFu), 3u, 0u);
    // $05BCD1 CMP
    cpu.compareA(hw.readW(cpu.addressDpLong(hw, 0xBCu), cpu.m8?8:16));
    goto L_05BCD3;
L_05BCD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD3u,cpu,0xC7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD3u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Cu) & 0xFFFFu), 3u, 0u);
    // $05BCD3 CMP
    cpu.compareA(hw.readW(cpu.addressDpLong(hw, 0x1Cu), cpu.m8?8:16));
    goto L_05BCD5;
L_05BCD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BCD5 INY
    cpu.inc('Y');
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCD6u,0x05BCD5u); return;
}

void sub_05CC66_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05CC66u: goto L_05CC66;
    case 0x05CC68u: goto L_05CC68;
    case 0x05CC6Bu: goto L_05CC6B;
    case 0x05CC6Eu: goto L_05CC6E;
    case 0x05CC70u: goto L_05CC70;
    case 0x05CC72u: goto L_05CC72;
    case 0x05CC74u: goto L_05CC74;
    case 0x05CC75u: goto L_05CC75;
    case 0x05CC77u: goto L_05CC77;
    case 0x05CC7Au: goto L_05CC7A;
    case 0x05CC7Cu: goto L_05CC7C;
    case 0x05CC7Fu: goto L_05CC7F;
    case 0x05CC81u: goto L_05CC81;
    case 0x05CC84u: goto L_05CC84;
    case 0x05CC86u: goto L_05CC86;
    case 0x05CC89u: goto L_05CC89;
    case 0x05CC8Bu: goto L_05CC8B;
    case 0x05CC8Du: goto L_05CC8D;
    case 0x05CC8Fu: goto L_05CC8F;
    case 0x05CC91u: goto L_05CC91;
    case 0x05CC93u: goto L_05CC93;
    case 0x05CC96u: goto L_05CC96;
    case 0x05CC97u: goto L_05CC97;
    case 0x05CC98u: goto L_05CC98;
    case 0x05CC9Cu: goto L_05CC9C;
    case 0x05CC9Du: goto L_05CC9D;
    case 0x05CCA0u: goto L_05CCA0;
    case 0x05CCA4u: goto L_05CCA4;
    case 0x05CCA5u: goto L_05CCA5;
    case 0x05CCA6u: goto L_05CCA6;
    case 0x05CCA7u: goto L_05CCA7;
    case 0x05CCA8u: goto L_05CCA8;
    case 0x05CCAAu: goto L_05CCAA;
    case 0x05CCAEu: goto L_05CCAE;
    case 0x05CCAFu: goto L_05CCAF;
    case 0x05CCB1u: goto L_05CCB1;
    case 0x05CCB4u: goto L_05CCB4;
    case 0x05CCB6u: goto L_05CCB6;
    case 0x05CCB9u: goto L_05CCB9;
    case 0x05CCBCu: goto L_05CCBC;
    case 0x05CCC0u: goto L_05CCC0;
    case 0x05CCC1u: goto L_05CCC1;
    case 0x05CCC2u: goto L_05CCC2;
    case 0x05CCC3u: goto L_05CCC3;
    case 0x05CCC6u: goto L_05CCC6;
    case 0x05CCC8u: goto L_05CCC8;
    case 0x05CCCBu: goto L_05CCCB;
    case 0x05CCCDu: goto L_05CCCD;
    case 0x05CCCEu: goto L_05CCCE;
    case 0x05CCD2u: goto L_05CCD2;
    case 0x05CCD3u: goto L_05CCD3;
    case 0x05CCD6u: goto L_05CCD6;
    case 0x05CCDAu: goto L_05CCDA;
    case 0x05CCDBu: goto L_05CCDB;
    case 0x05CCDCu: goto L_05CCDC;
    case 0x05CCDDu: goto L_05CCDD;
    case 0x05CCDFu: goto L_05CCDF;
    case 0x05CCE3u: goto L_05CCE3;
    case 0x05CCE4u: goto L_05CCE4;
    case 0x05CCE8u: goto L_05CCE8;
    case 0x05CCEAu: goto L_05CCEA;
    case 0x05CCECu: goto L_05CCEC;
    case 0x05CCEEu: goto L_05CCEE;
    case 0x05CCF2u: goto L_05CCF2;
    case 0x05CCF3u: goto L_05CCF3;
    case 0x05CCF4u: goto L_05CCF4;
    case 0x05CCF7u: goto L_05CCF7;
    case 0x05CCF9u: goto L_05CCF9;
    case 0x05CCFBu: goto L_05CCFB;
    case 0x05CCFEu: goto L_05CCFE;
    case 0x05CD00u: goto L_05CD00;
    case 0x05CD02u: goto L_05CD02;
    case 0x05CD04u: goto L_05CD04;
    case 0x05CD07u: goto L_05CD07;
    case 0x05CD09u: goto L_05CD09;
    case 0x05CD0Bu: goto L_05CD0B;
    case 0x05CD0Eu: goto L_05CD0E;
    case 0x05CD10u: goto L_05CD10;
    case 0x05CD14u: goto L_05CD14;
    case 0x05CD17u: goto L_05CD17;
    case 0x05CD19u: goto L_05CD19;
    case 0x05CD1Cu: goto L_05CD1C;
    case 0x05CD20u: goto L_05CD20;
    case 0x05CD21u: goto L_05CD21;
    case 0x05CD22u: goto L_05CD22;
    case 0x05CD24u: goto L_05CD24;
    case 0x05CD26u: goto L_05CD26;
    case 0x05CD28u: goto L_05CD28;
    case 0x05CD2Bu: goto L_05CD2B;
    case 0x05CD2Du: goto L_05CD2D;
    case 0x05CD30u: goto L_05CD30;
    case 0x05CD32u: goto L_05CD32;
    case 0x05CD33u: goto L_05CD33;
    case 0x05CD37u: goto L_05CD37;
    case 0x05CD38u: goto L_05CD38;
    case 0x05CD3Cu: goto L_05CD3C;
    case 0x05CD3Eu: goto L_05CD3E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05CC66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC66u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC66 LDY
    cpu.setY(0x0u, 8);
    goto L_05CC68;
L_05CC68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC68u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC68u, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC68 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDB3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05CC6B;
L_05CC6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC6Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC6Bu, 4u + ((((0x0F48u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC6B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CC6E;
L_05CC6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC6Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC6Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC6E CMP
    cpu.compareA(0xAu);
    goto L_05CC70;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC6Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC6E CMP
    cpu.compareA(0xAu);
    goto L_05CC70;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCC6Eu,0x05CC6Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05CC70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC70u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC70 BCC -> $05CC77
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_05CC77; }
    goto L_05CC72;
L_05CC72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC72u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC72 SBC
    cpu.sbc(0xAu);
    goto L_05CC74;
L_05CC74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC74u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC74u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC74 INY
    cpu.inc('Y');
    goto L_05CC75;
L_05CC75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC75u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC75u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC75 BRA -> $05CC6E
    goto L_05CC6E;
L_05CC77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC77u,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC77u, 4u, 3u, cpu.address("abs", 0x0F32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC77 CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0xF32u), cpu.x8?8:16));
    goto L_05CC7A;
L_05CC7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC7Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC7A BNE -> $05CC84
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05CC84; }
    goto L_05CC7C;
L_05CC7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC7Cu,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC7Cu, 4u, 3u, cpu.address("abs", 0x0F33u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC7C CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0xF33u), cpu.x8?8:16));
    goto L_05CC7F;
L_05CC7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC7Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC7F BNE -> $05CC84
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05CC84; }
    goto L_05CC81;
L_05CC81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC81u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC81u, 6u, 3u, cpu.address("abs", 0x18E4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC81 INC
    cpu.incMem(hw, cpu.address("abs", 0x18E4u), cpu.m8?8:16);
    goto L_05CC84;
L_05CC84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC84u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC84 LDA
    cpu.setA(0x1u, 8);
    goto L_05CC86;
L_05CC86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC86u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC86u, 4u, 3u, cpu.address("abs", 0x13D5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC86 STA
    hw.write(cpu.address("abs", 0x13D5u), cpu.a, cpu.m8?8:16);
    goto L_05CC89;
L_05CC89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC89 LDA
    cpu.setA(0x8u, 8);
    goto L_05CC8B;
L_05CC8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC8Bu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC8Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC8B TSB
    cpu.tsb(hw, cpu.address("dp", 0x3Eu), cpu.m8?8:16);
    goto L_05CC8D;
L_05CC8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC8Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC8Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC8D REP
    cpu.rep(0x30u);
    goto L_05CC8F;
L_05CC8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC8Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC8Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC8F STZ
    hw.write(cpu.address("dp", 0x22u), 0, cpu.m8?8:16);
    goto L_05CC91;
L_05CC91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC91u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC91u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC91 STZ
    hw.write(cpu.address("dp", 0x24u), 0, cpu.m8?8:16);
    goto L_05CC93;
L_05CC93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC93u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC93u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC93 LDY
    cpu.setY(0x4Au, 16);
    goto L_05CC96;
L_05CC96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC96u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC96 TYA
    cpu.transfer("TYA");
    goto L_05CC97;
L_05CC97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC97u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC97u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC97 CLC
    cpu.setFlag('C', false);
    goto L_05CC98;
L_05CC98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC98u,cpu,0x6Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC98u, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC98 ADC
    cpu.adc(hw.readW(0x7F837Bu, cpu.m8?8:16));
    goto L_05CC9C;
L_05CC9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC9Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC9C TAX
    cpu.transfer("TAX");
    goto L_05CC9D;
L_05CC9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC9Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC9Du, 5u + 1u, 3u, cpu.address("absy", 0xCC16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC9D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCC16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CCA0;
L_05CCA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA0u, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCA0 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05CCA4;
L_05CCA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA4u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCA4 DEX
    cpu.decReg('X');
    goto L_05CCA5;
L_05CCA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA5u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCA5 DEX
    cpu.decReg('X');
    goto L_05CCA6;
L_05CCA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA6u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCA6 DEY
    cpu.decReg('Y');
    goto L_05CCA7;
L_05CCA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA7u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCA7 DEY
    cpu.decReg('Y');
    goto L_05CCA8;
L_05CCA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCA8 BPL -> $05CC9D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_05CC9D; }
    goto L_05CCAA;
L_05CCAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCAAu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCAAu, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCAA LDA
    cpu.loadA(hw.readW(0x7F837Bu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CCAE;
L_05CCAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCAEu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCAE TAX
    cpu.transfer("TAX");
    goto L_05CCAF;
L_05CCAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCAFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCAFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCAF SEP
    cpu.sep(0x20u);
    goto L_05CCB1;
L_05CCB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB1u, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCB1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDB3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CCB4;
L_05CCB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCB4 BEQ -> $05CCC8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05CCC8; }
    goto L_05CCB6;
L_05CCB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCB6 LDY
    cpu.setY(0x0u, 16);
    goto L_05CCB9;
L_05CCB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB9u, 4u + 1u, 3u, cpu.address("absy", 0xCC61u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCB9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCC61u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CCBC;
L_05CCBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCBCu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCBCu, 5u, 4u, ((0x7F8381u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCBC STA
    hw.write(((0x7F8381u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05CCC0;
L_05CCC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCC0 INX
    cpu.inc('X');
    goto L_05CCC1;
L_05CCC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCC1 INX
    cpu.inc('X');
    goto L_05CCC2;
L_05CCC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC2u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCC2 INY
    cpu.inc('Y');
    goto L_05CCC3;
L_05CCC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC3u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCC3 CPY
    cpu.compareY(0x5u);
    goto L_05CCC6;
L_05CCC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCC6 BNE -> $05CCB9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05CCB9; }
    goto L_05CCC8;
L_05CCC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCC8 LDY
    cpu.setY(0x2u, 16);
    goto L_05CCCB;
L_05CCCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCCB LDA
    cpu.setA(0x4u, 8);
    goto L_05CCCD;
L_05CCCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCCD CLC
    cpu.setFlag('C', false);
    goto L_05CCCE;
L_05CCCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCEu,cpu,0x6Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCEu, 5u, 4u, 0x7F837Bu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCCE ADC
    cpu.adc(hw.readW(0x7F837Bu, cpu.m8?8:16));
    goto L_05CCD2;
L_05CCD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCD2 TAX
    cpu.transfer("TAX");
    goto L_05CCD3;
L_05CCD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD3u, 4u + 1u, 3u, cpu.address("absy", 0x0F31u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCD3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF31u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CCD6;
L_05CCD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD6u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD6u, 5u, 4u, ((0x7F83AFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCD6 STA
    hw.write(((0x7F83AFu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05CCDA;
L_05CCDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDAu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCDA DEY
    cpu.decReg('Y');
    goto L_05CCDB;
L_05CCDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCDB DEX
    cpu.decReg('X');
    goto L_05CCDC;
L_05CCDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDCu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCDC DEX
    cpu.decReg('X');
    goto L_05CCDD;
L_05CCDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDDu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCDD BPL -> $05CCD3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_05CCD3; }
    goto L_05CCDF;
L_05CCDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDFu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDFu, 5u, 4u, 0x7F837Bu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCDF LDA
    cpu.loadA(hw.readW(0x7F837Bu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CCE3;
L_05CCE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCE3 TAX
    cpu.transfer("TAX");
    goto L_05CCE4;
L_05CCE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE4u, 5u, 4u, ((0x7F83AFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCE4 LDA
    cpu.loadA(hw.readW(((0x7F83AFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CCE8;
L_05CCE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCE8 AND
    cpu.logicAnd(0xFu);
    goto L_05CCEA;
L_05CCEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCEAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCEA BNE -> $05CCF9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05CCF9; }
    goto L_05CCEC;
L_05CCEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCEC LDA
    cpu.setA(0xFCu, 8);
    goto L_05CCEE;
L_05CCEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCEEu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCEEu, 5u, 4u, ((0x7F83AFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCEE STA
    hw.write(((0x7F83AFu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05CCF2;
L_05CCF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCF2 INX
    cpu.inc('X');
    goto L_05CCF3;
L_05CCF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCF3 INX
    cpu.inc('X');
    goto L_05CCF4;
L_05CCF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF4u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCF4 CPX
    cpu.compareX(0x4u);
    goto L_05CCF7;
L_05CCF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCF7 BNE -> $05CCE4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05CCE4; }
    goto L_05CCF9;
L_05CCF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCF9 SEP
    cpu.sep(0x10u);
    goto L_05CCFB;
L_05CCFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFBu, 6u, 3u, cpu.address("abs", 0xCE4Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05CCFB JSR -> $05CE4C stack real
    { cpu.push16Value(hw,0xCCFDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCCFEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCE4Cu), 0x05CCFBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05CCFE;
L_05CCFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCFEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCCFEu,0x05CCFEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCFE REP
    cpu.rep(0x20u);
    goto L_05CD00;
L_05CD00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD00u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD00u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD00 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_05CD02;
L_05CD02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD02u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD02u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD02 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CD04;
L_05CD04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD04u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD04u, 5u, 3u, cpu.address("abs", 0x0F40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD04 STA
    hw.write(cpu.address("abs", 0xF40u), cpu.a, cpu.m8?8:16);
    goto L_05CD07;
L_05CD07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD07u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD07 LDX
    cpu.setX(0x42u, 8);
    goto L_05CD09;
L_05CD09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD09u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD09 LDY
    cpu.setY(0x0u, 8);
    goto L_05CD0B;
L_05CD0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Bu, 6u, 3u, cpu.address("abs", 0xCDFDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05CD0B JSR -> $05CDFD stack real
    { cpu.push16Value(hw,0xCD0Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD0Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCDFDu), 0x05CD0Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05CD0E;
L_05CD0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD0Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD0Eu,0x05CD0Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD0E LDX
    cpu.setX(0x0u, 8);
    goto L_05CD10;
L_05CD10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD10u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD10u, 6u, 4u, ((0x7F83BDu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD10 LDA
    cpu.loadA(hw.readW(((0x7F83BDu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CD14;
L_05CD14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD14u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD14u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD14 AND
    cpu.logicAnd(0xFu);
    goto L_05CD17;
L_05CD17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD17u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD17 BNE -> $05CD26
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05CD26; }
    goto L_05CD19;
L_05CD19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD19 LDA
    cpu.setA(0x38FCu, 16);
    goto L_05CD1C;
L_05CD1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD1Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD1Cu, 6u, 4u, ((0x7F83BDu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD1C STA
    hw.write(((0x7F83BDu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05CD20;
L_05CD20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD20u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD20u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD20 INX
    cpu.inc('X');
    goto L_05CD21;
L_05CD21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD21u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD21 INX
    cpu.inc('X');
    goto L_05CD22;
L_05CD22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD22u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD22 CPX
    cpu.compareX(0x8u);
    goto L_05CD24;
L_05CD24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD24u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD24 BNE -> $05CD10
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05CD10; }
    goto L_05CD26;
L_05CD26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD26u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD26u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD26 SEP
    cpu.sep(0x20u);
    goto L_05CD28;
L_05CD28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD28u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD28u, 6u, 3u, cpu.address("abs", 0x13D9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD28 INC
    cpu.incMem(hw, cpu.address("abs", 0x13D9u), cpu.m8?8:16);
    goto L_05CD2B;
L_05CD2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD2B LDA
    cpu.setA(0x28u, 8);
    goto L_05CD2D;
L_05CD2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Du, 4u, 3u, cpu.address("abs", 0x1424u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD2D STA
    hw.write(cpu.address("abs", 0x1424u), cpu.a, cpu.m8?8:16);
    goto L_05CD30;
L_05CD30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD30u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD30u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD30 LDA
    cpu.setA(0x4Au, 8);
    goto L_05CD32;
L_05CD32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD32u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD32 CLC
    cpu.setFlag('C', false);
    goto L_05CD33;
L_05CD33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD33u,cpu,0x6Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD33u, 5u, 4u, 0x7F837Bu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD33 ADC
    cpu.adc(hw.readW(0x7F837Bu, cpu.m8?8:16));
    goto L_05CD37;
L_05CD37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD37u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD37u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD37 INC
    cpu.inc('A');
    goto L_05CD38;
L_05CD38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD38u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD38u, 5u, 4u, 0x7F837Bu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD38 STA
    hw.write(0x7F837Bu, cpu.a, cpu.m8?8:16);
    goto L_05CD3C;
L_05CD3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD3C SEP
    cpu.sep(0x30u);
    goto L_05CD3E;
L_05CD3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05CD3E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x05CD3Eu);return;} hw.unresolvedReturn(0x05CD3Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_05CC66_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05CC66u: goto L_05CC66;
    case 0x05CC68u: goto L_05CC68;
    case 0x05CC6Bu: goto L_05CC6B;
    case 0x05CC6Eu: goto L_05CC6E;
    case 0x05CC70u: goto L_05CC70;
    case 0x05CC72u: goto L_05CC72;
    case 0x05CC74u: goto L_05CC74;
    case 0x05CC75u: goto L_05CC75;
    case 0x05CC77u: goto L_05CC77;
    case 0x05CC7Au: goto L_05CC7A;
    case 0x05CC7Cu: goto L_05CC7C;
    case 0x05CC7Fu: goto L_05CC7F;
    case 0x05CC81u: goto L_05CC81;
    case 0x05CC84u: goto L_05CC84;
    case 0x05CC86u: goto L_05CC86;
    case 0x05CC89u: goto L_05CC89;
    case 0x05CC8Bu: goto L_05CC8B;
    case 0x05CC8Du: goto L_05CC8D;
    case 0x05CC8Fu: goto L_05CC8F;
    case 0x05CC91u: goto L_05CC91;
    case 0x05CC93u: goto L_05CC93;
    case 0x05CC96u: goto L_05CC96;
    case 0x05CC97u: goto L_05CC97;
    case 0x05CC98u: goto L_05CC98;
    case 0x05CC9Cu: goto L_05CC9C;
    case 0x05CC9Du: goto L_05CC9D;
    case 0x05CCA0u: goto L_05CCA0;
    case 0x05CCA4u: goto L_05CCA4;
    case 0x05CCA5u: goto L_05CCA5;
    case 0x05CCA6u: goto L_05CCA6;
    case 0x05CCA7u: goto L_05CCA7;
    case 0x05CCA8u: goto L_05CCA8;
    case 0x05CCAAu: goto L_05CCAA;
    case 0x05CCAEu: goto L_05CCAE;
    case 0x05CCAFu: goto L_05CCAF;
    case 0x05CCB1u: goto L_05CCB1;
    case 0x05CCB4u: goto L_05CCB4;
    case 0x05CCB6u: goto L_05CCB6;
    case 0x05CCB9u: goto L_05CCB9;
    case 0x05CCBCu: goto L_05CCBC;
    case 0x05CCC0u: goto L_05CCC0;
    case 0x05CCC1u: goto L_05CCC1;
    case 0x05CCC2u: goto L_05CCC2;
    case 0x05CCC3u: goto L_05CCC3;
    case 0x05CCC6u: goto L_05CCC6;
    case 0x05CCC8u: goto L_05CCC8;
    case 0x05CCCBu: goto L_05CCCB;
    case 0x05CCCDu: goto L_05CCCD;
    case 0x05CCCEu: goto L_05CCCE;
    case 0x05CCD2u: goto L_05CCD2;
    case 0x05CCD3u: goto L_05CCD3;
    case 0x05CCD6u: goto L_05CCD6;
    case 0x05CCDAu: goto L_05CCDA;
    case 0x05CCDBu: goto L_05CCDB;
    case 0x05CCDCu: goto L_05CCDC;
    case 0x05CCDDu: goto L_05CCDD;
    case 0x05CCDFu: goto L_05CCDF;
    case 0x05CCE3u: goto L_05CCE3;
    case 0x05CCE4u: goto L_05CCE4;
    case 0x05CCE8u: goto L_05CCE8;
    case 0x05CCEAu: goto L_05CCEA;
    case 0x05CCECu: goto L_05CCEC;
    case 0x05CCEEu: goto L_05CCEE;
    case 0x05CCF2u: goto L_05CCF2;
    case 0x05CCF3u: goto L_05CCF3;
    case 0x05CCF4u: goto L_05CCF4;
    case 0x05CCF7u: goto L_05CCF7;
    case 0x05CCF9u: goto L_05CCF9;
    case 0x05CCFBu: goto L_05CCFB;
    case 0x05CCFEu: goto L_05CCFE;
    case 0x05CD00u: goto L_05CD00;
    case 0x05CD02u: goto L_05CD02;
    case 0x05CD04u: goto L_05CD04;
    case 0x05CD07u: goto L_05CD07;
    case 0x05CD09u: goto L_05CD09;
    case 0x05CD0Bu: goto L_05CD0B;
    case 0x05CD0Eu: goto L_05CD0E;
    case 0x05CD10u: goto L_05CD10;
    case 0x05CD14u: goto L_05CD14;
    case 0x05CD17u: goto L_05CD17;
    case 0x05CD19u: goto L_05CD19;
    case 0x05CD1Cu: goto L_05CD1C;
    case 0x05CD20u: goto L_05CD20;
    case 0x05CD21u: goto L_05CD21;
    case 0x05CD22u: goto L_05CD22;
    case 0x05CD24u: goto L_05CD24;
    case 0x05CD26u: goto L_05CD26;
    case 0x05CD28u: goto L_05CD28;
    case 0x05CD2Bu: goto L_05CD2B;
    case 0x05CD2Du: goto L_05CD2D;
    case 0x05CD30u: goto L_05CD30;
    case 0x05CD32u: goto L_05CD32;
    case 0x05CD33u: goto L_05CD33;
    case 0x05CD37u: goto L_05CD37;
    case 0x05CD38u: goto L_05CD38;
    case 0x05CD3Cu: goto L_05CD3C;
    case 0x05CD3Eu: goto L_05CD3E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05CC66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC66u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC66 LDY
    cpu.setY(0x0u, 8);
    goto L_05CC68;
L_05CC68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC68u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC68u, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC68 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDB3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05CC6B;
L_05CC6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC6Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC6Bu, 4u + ((((0x0F48u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC6B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CC6E;
L_05CC6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC6Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC6E CMP
    cpu.compareA(0xAu);
    goto L_05CC70;
L_05CC70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC70u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC70 BCC -> $05CC77
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_05CC77; }
    goto L_05CC72;
L_05CC72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC72u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC72 SBC
    cpu.sbc(0xAu);
    goto L_05CC74;
L_05CC74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC74u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC74u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC74 INY
    cpu.inc('Y');
    goto L_05CC75;
L_05CC75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC75u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC75u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC75 BRA -> $05CC6E
    goto L_05CC6E;
L_05CC77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC77u,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC77u, 4u, 3u, cpu.address("abs", 0x0F32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC77 CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0xF32u), cpu.x8?8:16));
    goto L_05CC7A;
L_05CC7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC7Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC7A BNE -> $05CC84
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05CC84; }
    goto L_05CC7C;
L_05CC7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC7Cu,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC7Cu, 4u, 3u, cpu.address("abs", 0x0F33u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC7C CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0xF33u), cpu.x8?8:16));
    goto L_05CC7F;
L_05CC7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC7Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC7F BNE -> $05CC84
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05CC84; }
    goto L_05CC81;
L_05CC81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC81u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC81u, 6u, 3u, cpu.address("abs", 0x18E4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC81 INC
    cpu.incMem(hw, cpu.address("abs", 0x18E4u), cpu.m8?8:16);
    goto L_05CC84;
L_05CC84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC84u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC84 LDA
    cpu.setA(0x1u, 8);
    goto L_05CC86;
L_05CC86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC86u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC86u, 4u, 3u, cpu.address("abs", 0x13D5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC86 STA
    hw.write(cpu.address("abs", 0x13D5u), cpu.a, cpu.m8?8:16);
    goto L_05CC89;
L_05CC89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC89 LDA
    cpu.setA(0x8u, 8);
    goto L_05CC8B;
L_05CC8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC8Bu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC8Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC8B TSB
    cpu.tsb(hw, cpu.address("dp", 0x3Eu), cpu.m8?8:16);
    goto L_05CC8D;
L_05CC8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC8Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC8Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC8D REP
    cpu.rep(0x30u);
    goto L_05CC8F;
L_05CC8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC8Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC8Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC8F STZ
    hw.write(cpu.address("dp", 0x22u), 0, cpu.m8?8:16);
    goto L_05CC91;
L_05CC91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC91u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC91u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC91 STZ
    hw.write(cpu.address("dp", 0x24u), 0, cpu.m8?8:16);
    goto L_05CC93;
L_05CC93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC93u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC93u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC93 LDY
    cpu.setY(0x4Au, 16);
    goto L_05CC96;
L_05CC96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC96u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC96 TYA
    cpu.transfer("TYA");
    goto L_05CC97;
L_05CC97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC97u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC97u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC97 CLC
    cpu.setFlag('C', false);
    goto L_05CC98;
L_05CC98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC98u,cpu,0x6Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC98u, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC98 ADC
    cpu.adc(hw.readW(0x7F837Bu, cpu.m8?8:16));
    goto L_05CC9C;
L_05CC9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC9Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC9C TAX
    cpu.transfer("TAX");
    goto L_05CC9D;
L_05CC9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC9Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC9Du, 5u + 1u, 3u, cpu.address("absy", 0xCC16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CC9D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCC16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CCA0;
L_05CCA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA0u, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCA0 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05CCA4;
L_05CCA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA4u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCA4 DEX
    cpu.decReg('X');
    goto L_05CCA5;
L_05CCA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA5u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCA5 DEX
    cpu.decReg('X');
    goto L_05CCA6;
L_05CCA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA6u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCA6 DEY
    cpu.decReg('Y');
    goto L_05CCA7;
L_05CCA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA7u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCA7 DEY
    cpu.decReg('Y');
    goto L_05CCA8;
L_05CCA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCA8 BPL -> $05CC9D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_05CC9D; }
    goto L_05CCAA;
L_05CCAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCAAu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCAAu, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCAA LDA
    cpu.loadA(hw.readW(0x7F837Bu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CCAE;
L_05CCAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCAEu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCAE TAX
    cpu.transfer("TAX");
    goto L_05CCAF;
L_05CCAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCAFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCAFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCAF SEP
    cpu.sep(0x20u);
    goto L_05CCB1;
L_05CCB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB1u, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCB1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDB3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CCB4;
L_05CCB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCB4 BEQ -> $05CCC8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05CCC8; }
    goto L_05CCB6;
L_05CCB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCB6 LDY
    cpu.setY(0x0u, 16);
    goto L_05CCB9;
L_05CCB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB9u, 4u + 1u, 3u, cpu.address("absy", 0xCC61u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCB9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCC61u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CCBC;
L_05CCBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCBCu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCBCu, 5u, 4u, ((0x7F8381u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCBC STA
    hw.write(((0x7F8381u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05CCC0;
L_05CCC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCC0 INX
    cpu.inc('X');
    goto L_05CCC1;
L_05CCC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCC1 INX
    cpu.inc('X');
    goto L_05CCC2;
L_05CCC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC2u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCC2 INY
    cpu.inc('Y');
    goto L_05CCC3;
L_05CCC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC3u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCC3 CPY
    cpu.compareY(0x5u);
    goto L_05CCC6;
L_05CCC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCC6 BNE -> $05CCB9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05CCB9; }
    goto L_05CCC8;
L_05CCC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCC8 LDY
    cpu.setY(0x2u, 16);
    goto L_05CCCB;
L_05CCCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCCB LDA
    cpu.setA(0x4u, 8);
    goto L_05CCCD;
L_05CCCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCCD CLC
    cpu.setFlag('C', false);
    goto L_05CCCE;
L_05CCCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCEu,cpu,0x6Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCEu, 5u, 4u, 0x7F837Bu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCCE ADC
    cpu.adc(hw.readW(0x7F837Bu, cpu.m8?8:16));
    goto L_05CCD2;
L_05CCD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCD2 TAX
    cpu.transfer("TAX");
    goto L_05CCD3;
L_05CCD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD3u, 4u + 1u, 3u, cpu.address("absy", 0x0F31u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCD3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF31u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CCD6;
L_05CCD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD6u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD6u, 5u, 4u, ((0x7F83AFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCD6 STA
    hw.write(((0x7F83AFu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05CCDA;
L_05CCDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDAu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCDA DEY
    cpu.decReg('Y');
    goto L_05CCDB;
L_05CCDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCDB DEX
    cpu.decReg('X');
    goto L_05CCDC;
L_05CCDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDCu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCDC DEX
    cpu.decReg('X');
    goto L_05CCDD;
L_05CCDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDDu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCDD BPL -> $05CCD3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_05CCD3; }
    goto L_05CCDF;
L_05CCDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDFu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDFu, 5u, 4u, 0x7F837Bu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCDF LDA
    cpu.loadA(hw.readW(0x7F837Bu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CCE3;
L_05CCE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCE3 TAX
    cpu.transfer("TAX");
    goto L_05CCE4;
L_05CCE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE4u, 5u, 4u, ((0x7F83AFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCE4 LDA
    cpu.loadA(hw.readW(((0x7F83AFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CCE8;
L_05CCE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCE8 AND
    cpu.logicAnd(0xFu);
    goto L_05CCEA;
L_05CCEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCEAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCEA BNE -> $05CCF9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05CCF9; }
    goto L_05CCEC;
L_05CCEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCEC LDA
    cpu.setA(0xFCu, 8);
    goto L_05CCEE;
L_05CCEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCEEu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCEEu, 5u, 4u, ((0x7F83AFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCEE STA
    hw.write(((0x7F83AFu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05CCF2;
L_05CCF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCF2 INX
    cpu.inc('X');
    goto L_05CCF3;
L_05CCF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCF3 INX
    cpu.inc('X');
    goto L_05CCF4;
L_05CCF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF4u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCF4 CPX
    cpu.compareX(0x4u);
    goto L_05CCF7;
L_05CCF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCF7 BNE -> $05CCE4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05CCE4; }
    goto L_05CCF9;
L_05CCF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCF9 SEP
    cpu.sep(0x10u);
    goto L_05CCFB;
L_05CCFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFBu, 6u, 3u, cpu.address("abs", 0xCE4Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05CCFB JSR -> $05CE4C stack real
    { cpu.push16Value(hw,0xCCFDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCCFEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCE4Cu), 0x05CCFBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05CCFE;
L_05CCFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCFEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCCFEu,0x05CCFEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CCFE REP
    cpu.rep(0x20u);
    goto L_05CD00;
L_05CD00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD00u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD00u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD00 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_05CD02;
L_05CD02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD02u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD02u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD02 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CD04;
L_05CD04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD04u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD04u, 5u, 3u, cpu.address("abs", 0x0F40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD04 STA
    hw.write(cpu.address("abs", 0xF40u), cpu.a, cpu.m8?8:16);
    goto L_05CD07;
L_05CD07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD07u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD07 LDX
    cpu.setX(0x42u, 8);
    goto L_05CD09;
L_05CD09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD09u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD09 LDY
    cpu.setY(0x0u, 8);
    goto L_05CD0B;
L_05CD0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Bu, 6u, 3u, cpu.address("abs", 0xCDFDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05CD0B JSR -> $05CDFD stack real
    { cpu.push16Value(hw,0xCD0Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD0Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCDFDu), 0x05CD0Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05CD0E;
L_05CD0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD0Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD0Eu,0x05CD0Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD0E LDX
    cpu.setX(0x0u, 8);
    goto L_05CD10;
L_05CD10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD10u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD10u, 6u, 4u, ((0x7F83BDu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD10 LDA
    cpu.loadA(hw.readW(((0x7F83BDu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05CD14;
L_05CD14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD14u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD14u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD14 AND
    cpu.logicAnd(0xFu);
    goto L_05CD17;
L_05CD17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD17u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD17 BNE -> $05CD26
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05CD26; }
    goto L_05CD19;
L_05CD19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD19 LDA
    cpu.setA(0x38FCu, 16);
    goto L_05CD1C;
L_05CD1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD1Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD1Cu, 6u, 4u, ((0x7F83BDu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD1C STA
    hw.write(((0x7F83BDu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_05CD20;
L_05CD20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD20u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD20u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD20 INX
    cpu.inc('X');
    goto L_05CD21;
L_05CD21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD21u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD21 INX
    cpu.inc('X');
    goto L_05CD22;
L_05CD22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD22u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD22 CPX
    cpu.compareX(0x8u);
    goto L_05CD24;
L_05CD24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD24u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD24 BNE -> $05CD10
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05CD10; }
    goto L_05CD26;
L_05CD26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD26u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD26u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD26 SEP
    cpu.sep(0x20u);
    goto L_05CD28;
L_05CD28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD28u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD28u, 6u, 3u, cpu.address("abs", 0x13D9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD28 INC
    cpu.incMem(hw, cpu.address("abs", 0x13D9u), cpu.m8?8:16);
    goto L_05CD2B;
L_05CD2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD2B LDA
    cpu.setA(0x28u, 8);
    goto L_05CD2D;
L_05CD2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Du, 4u, 3u, cpu.address("abs", 0x1424u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD2D STA
    hw.write(cpu.address("abs", 0x1424u), cpu.a, cpu.m8?8:16);
    goto L_05CD30;
L_05CD30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD30u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD30u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD30 LDA
    cpu.setA(0x4Au, 8);
    goto L_05CD32;
L_05CD32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD32u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD32 CLC
    cpu.setFlag('C', false);
    goto L_05CD33;
L_05CD33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD33u,cpu,0x6Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD33u, 5u, 4u, 0x7F837Bu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD33 ADC
    cpu.adc(hw.readW(0x7F837Bu, cpu.m8?8:16));
    goto L_05CD37;
L_05CD37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD37u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD37u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD37 INC
    cpu.inc('A');
    goto L_05CD38;
L_05CD38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD38u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD38u, 5u, 4u, 0x7F837Bu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD38 STA
    hw.write(0x7F837Bu, cpu.a, cpu.m8?8:16);
    goto L_05CD3C;
L_05CD3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05CD3C SEP
    cpu.sep(0x30u);
    goto L_05CD3E;
L_05CD3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05CD3E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x05CD3Eu);return;} hw.unresolvedReturn(0x05CD3Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DAA0D_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DAA0Du: goto L_0DAA0D;
    case 0x0DAA0Fu: goto L_0DAA0F;
    case 0x0DAA11u: goto L_0DAA11;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DAA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAA0D LDA
    cpu.setA(0x0u, 8);
    goto L_0DAA0F;
L_0DAA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Eu) & 0xFFFFu), 3u, 0u);
    // $0DAA0F STA
    hw.write(cpu.addressDpLongY(hw, 0x6Eu), cpu.a, cpu.m8?8:16);
    goto L_0DAA11;
L_0DAA11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA11u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA11u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAA11 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DAA11u);return;} hw.unresolvedReturn(0x0DAA11u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DAA0D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DAA0Du: goto L_0DAA0D;
    case 0x0DAA0Fu: goto L_0DAA0F;
    case 0x0DAA11u: goto L_0DAA11;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DAA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DAA0D LDA
    cpu.setA(0x0u, 8);
    goto L_0DAA0F;
L_0DAA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Eu) & 0xFFFFu), 3u, 0u);
    // $0DAA0F STA
    hw.write(cpu.addressDpLongY(hw, 0x6Eu), cpu.a, cpu.m8?8:16);
    goto L_0DAA11;
L_0DAA11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA11u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA11u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DAA11 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DAA11u);return;} hw.unresolvedReturn(0x0DAA11u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DD034_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DD034u: goto L_0DD034;
    case 0x0DD036u: goto L_0DD036;
    case 0x0DD038u: goto L_0DD038;
    case 0x0DD03Au: goto L_0DD03A;
    case 0x0DD03Cu: goto L_0DD03C;
    case 0x0DD03Eu: goto L_0DD03E;
    case 0x0DD040u: goto L_0DD040;
    case 0x0DD042u: goto L_0DD042;
    case 0x0DD043u: goto L_0DD043;
    case 0x0DD044u: goto L_0DD044;
    case 0x0DD045u: goto L_0DD045;
    case 0x0DD046u: goto L_0DD046;
    case 0x0DD047u: goto L_0DD047;
    case 0x0DD04Au: goto L_0DD04A;
    case 0x0DD04Cu: goto L_0DD04C;
    case 0x0DD04Eu: goto L_0DD04E;
    case 0x0DD050u: goto L_0DD050;
    case 0x0DD051u: goto L_0DD051;
    case 0x0DD053u: goto L_0DD053;
    case 0x0DD054u: goto L_0DD054;
    case 0x0DD056u: goto L_0DD056;
    case 0x0DD059u: goto L_0DD059;
    case 0x0DD05Au: goto L_0DD05A;
    case 0x0DD05Bu: goto L_0DD05B;
    case 0x0DD05Du: goto L_0DD05D;
    case 0x0DD05Eu: goto L_0DD05E;
    case 0x0DD060u: goto L_0DD060;
    case 0x0DD062u: goto L_0DD062;
    case 0x0DD063u: goto L_0DD063;
    case 0x0DD064u: goto L_0DD064;
    case 0x0DD066u: goto L_0DD066;
    case 0x0DD067u: goto L_0DD067;
    case 0x0DD06Au: goto L_0DD06A;
    case 0x0DD06Cu: goto L_0DD06C;
    case 0x0DD06Du: goto L_0DD06D;
    case 0x0DD06Fu: goto L_0DD06F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DD034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD034u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD034u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD034u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD034 LDA
    cpu.setA(0x87u, 8);
    goto L_0DD036;
L_0DD036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD036u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD036u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD036 CPX
    cpu.compareX(0x5u);
    goto L_0DD038;
L_0DD038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD038u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD038u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD038 BNE -> $0DD03C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DD03C; }
    goto L_0DD03A;
L_0DD03A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD03Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD03A LDA
    cpu.setA(0x95u, 8);
    goto L_0DD03C;
L_0DD03C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD03Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD03C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DD03E;
L_0DD03E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD03Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD03E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DD040;
L_0DD040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD040u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD040u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD040 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DD042;
L_0DD042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD042u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD042u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD042 LSR
    cpu.lsrA();
    goto L_0DD043;
L_0DD043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD043u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD043u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD043 LSR
    cpu.lsrA();
    goto L_0DD044;
L_0DD044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD044u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD044u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD044u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD044 LSR
    cpu.lsrA();
    goto L_0DD045;
L_0DD045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD045u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD045u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD045 LSR
    cpu.lsrA();
    goto L_0DD046;
L_0DD046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD046u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD046u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD046 TAX
    cpu.transfer("TAX");
    goto L_0DD047;
L_0DD047:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD047u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD047u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD047u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD047 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xD049u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD04Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DD047u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD04A;
L_0DD04A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD04Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD04Au,0x0DD04Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD04A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DD04C;
L_0DD04C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD04Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Cu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Cu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DD04C STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DD04E;
L_0DD04E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD04Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD04Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD04E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x57u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DD050;
L_0DD050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD050u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD050u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD050 CLC
    cpu.setFlag('C', false);
    goto L_0DD051;
L_0DD051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD051u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD051u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD051 ADC
    cpu.adc(0x10u);
    goto L_0DD053;
L_0DD053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD053u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD053u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD053 TAY
    cpu.transfer("TAY");
    goto L_0DD054;
L_0DD054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD054u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD054u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD054 BCC -> $0DD059
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DD059; }
    goto L_0DD056;
L_0DD056:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD056u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD056u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD056u, 6u, 3u, cpu.address("abs", 0xA987u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD056 JSR -> $0DA987 stack real
    { cpu.push16Value(hw,0xD058u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD059u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA987u), 0x0DD056u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD059;
L_0DD059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD059u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD059u,0x0DD059u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD059u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD059u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD059 TYA
    cpu.transfer("TYA");
    goto L_0DD05A;
L_0DD05A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD05Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD05Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD05Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD05A CLC
    cpu.setFlag('C', false);
    goto L_0DD05B;
L_0DD05B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD05Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD05Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD05Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD05B ADC
    cpu.adc(0x1u);
    goto L_0DD05D;
L_0DD05D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD05Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD05Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD05Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD05D TAY
    cpu.transfer("TAY");
    goto L_0DD05E;
L_0DD05E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD05Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD05Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD05Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD05E AND
    cpu.logicAnd(0xFu);
    goto L_0DD060;
L_0DD060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD060u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD060u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD060u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD060 BNE -> $0DD06A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DD06A; }
    goto L_0DD062;
L_0DD062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD062u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD062u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD062 DEY
    cpu.decReg('Y');
    goto L_0DD063;
L_0DD063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD063u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD063u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD063u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD063 TYA
    cpu.transfer("TYA");
    goto L_0DD064;
L_0DD064:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD064u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD064u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD064u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD064 AND
    cpu.logicAnd(0xF0u);
    goto L_0DD066;
L_0DD066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD066u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD066u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD066u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD066 TAY
    cpu.transfer("TAY");
    goto L_0DD067;
L_0DD067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD067u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD067u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD067u, 6u, 3u, cpu.address("abs", 0xA9EFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD067 JSR -> $0DA9EF stack real
    { cpu.push16Value(hw,0xD069u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD06Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA9EFu), 0x0DD067u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD06A;
L_0DD06A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD06Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD06Au,0x0DD06Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Au,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD06A STY
    hw.write(cpu.address("dp", 0x57u), cpu.y, cpu.x8?8:16);
    goto L_0DD06C;
L_0DD06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD06Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD06C DEX
    cpu.decReg('X');
    goto L_0DD06D;
L_0DD06D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD06Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD06D BPL -> $0DD047
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DD047; }
    goto L_0DD06F;
L_0DD06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD06Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD06Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD06F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DD06Fu);return;} hw.unresolvedReturn(0x0DD06Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DD182_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DD182u: goto L_0DD182;
    case 0x0DD184u: goto L_0DD184;
    case 0x0DD186u: goto L_0DD186;
    case 0x0DD188u: goto L_0DD188;
    case 0x0DD189u: goto L_0DD189;
    case 0x0DD18Cu: goto L_0DD18C;
    case 0x0DD18Eu: goto L_0DD18E;
    case 0x0DD191u: goto L_0DD191;
    case 0x0DD194u: goto L_0DD194;
    case 0x0DD196u: goto L_0DD196;
    case 0x0DD199u: goto L_0DD199;
    case 0x0DD19Au: goto L_0DD19A;
    case 0x0DD19Cu: goto L_0DD19C;
    case 0x0DD19Fu: goto L_0DD19F;
    case 0x0DD1A1u: goto L_0DD1A1;
    case 0x0DD1A4u: goto L_0DD1A4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DD182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD182u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD182u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD182 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DD184;
L_0DD184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD184u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD184u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD184 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DD186;
L_0DD186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD186u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD186u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD186 AND
    cpu.logicAnd(0xFu);
    goto L_0DD188;
L_0DD188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD188u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD188u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD188 TAX
    cpu.transfer("TAX");
    goto L_0DD189;
L_0DD189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD189u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD189u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD189 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xD18Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD18Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DD189u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD18C;
L_0DD18C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD18Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD18Cu,0x0DD18Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD18Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD18Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD18C LDA
    cpu.setA(0x59u, 8);
    goto L_0DD18E;
L_0DD18E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD18Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD18Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD18Eu, 3u, 3u, cpu.address("abs", 0xD196u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD18E JMP -> $0DD196
    goto L_0DD196;
L_0DD191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD191u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD191u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD191u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD191 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xD193u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD194u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DD191u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD194;
L_0DD194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD194u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD194u,0x0DD194u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD194u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD194u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD194 LDA
    cpu.setA(0x5Au, 8);
    goto L_0DD196;
L_0DD196:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD196u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD196u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD196u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD196 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xD198u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD199u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DD196u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD199;
L_0DD199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD199u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD199u,0x0DD199u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD199u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD199u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD199 DEX
    cpu.decReg('X');
    goto L_0DD19A;
L_0DD19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD19Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD19A BNE -> $0DD191
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DD191; }
    goto L_0DD19C;
L_0DD19C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD19Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Cu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD19C JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xD19Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD19Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DD19Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD19F;
L_0DD19F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD19Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD19Fu,0x0DD19Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD19F LDA
    cpu.setA(0x5Bu, 8);
    goto L_0DD1A1;
L_0DD1A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A1u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD1A1 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xD1A3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1A4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DD1A1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD1A4;
L_0DD1A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1A4u,0x0DD1A4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD1A4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DD1A4u);return;} hw.unresolvedReturn(0x0DD1A4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DEC33_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DEC33u: goto L_0DEC33;
    case 0x0DEC35u: goto L_0DEC35;
    case 0x0DEC37u: goto L_0DEC37;
    case 0x0DEC39u: goto L_0DEC39;
    case 0x0DEC3Bu: goto L_0DEC3B;
    case 0x0DEC3Eu: goto L_0DEC3E;
    case 0x0DEC42u: goto L_0DEC42;
    case 0x0DEC45u: goto L_0DEC45;
    case 0x0DEC46u: goto L_0DEC46;
    case 0x0DEC48u: goto L_0DEC48;
    case 0x0DEC4Au: goto L_0DEC4A;
    case 0x0DEC4Du: goto L_0DEC4D;
    case 0x0DEC51u: goto L_0DEC51;
    case 0x0DEC53u: goto L_0DEC53;
    case 0x0DEC54u: goto L_0DEC54;
    case 0x0DEC57u: goto L_0DEC57;
    case 0x0DEC59u: goto L_0DEC59;
    case 0x0DEC5Bu: goto L_0DEC5B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DEC33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC33u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC33u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEC33 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DEC35;
L_0DEC35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC35u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEC35 LDX
    cpu.setX(0x0u, 8);
    goto L_0DEC37;
L_0DEC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC37u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEC37 LDA
    cpu.setA(0xFu, 8);
    goto L_0DEC39;
L_0DEC39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC39u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC39u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEC39 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DEC3B;
L_0DEC3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC3Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC3Bu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEC3B JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xEC3Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEC3Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DEC3Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEC3E;
L_0DEC3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC3Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC3Eu,0x0DEC3Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC3Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC3Eu, 5u, 4u, ((0x0DEB93u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEC3E LDA
    cpu.loadA(hw.readW(((0xDEB93u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DEC42;
L_0DEC42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC42u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC42u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEC42 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xEC44u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEC45u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DEC42u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEC45;
L_0DEC45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC45u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC45u,0x0DEC45u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC45u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEC45 INX
    cpu.inc('X');
    goto L_0DEC46;
L_0DEC46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC46u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC46u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEC46 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DEC48;
L_0DEC48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC48u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC48u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEC48 BNE -> $0DEC3B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DEC3B; }
    goto L_0DEC4A;
L_0DEC4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Au, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEC4A JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xEC4Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEC4Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DEC4Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEC4D;
L_0DEC4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC4Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC4Du,0x0DEC4Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Du, 5u, 4u, ((0x0DEB93u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEC4D LDA
    cpu.loadA(hw.readW(((0xDEB93u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DEC51;
L_0DEC51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC51u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC51u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DEC51 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DEC53;
L_0DEC53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC53u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC53u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEC53 INX
    cpu.inc('X');
    goto L_0DEC54;
L_0DEC54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC54u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC54u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEC54 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xEC56u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEC57u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DEC54u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEC57;
L_0DEC57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC57u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC57u,0x0DEC57u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC57u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEC57 CPX
    cpu.compareX(0xA0u);
    goto L_0DEC59;
L_0DEC59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC59u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEC59 BNE -> $0DEC37
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DEC37; }
    goto L_0DEC5B;
L_0DEC5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC5Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC5Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEC5B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DEC5Bu);return;} hw.unresolvedReturn(0x0DEC5Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DED99_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DED99u: goto L_0DED99;
    case 0x0DED9Bu: goto L_0DED9B;
    case 0x0DED9Du: goto L_0DED9D;
    case 0x0DED9Eu: goto L_0DED9E;
    case 0x0DEDA0u: goto L_0DEDA0;
    case 0x0DEDA2u: goto L_0DEDA2;
    case 0x0DEDA3u: goto L_0DEDA3;
    case 0x0DEDA4u: goto L_0DEDA4;
    case 0x0DEDA5u: goto L_0DEDA5;
    case 0x0DEDA6u: goto L_0DEDA6;
    case 0x0DEDA8u: goto L_0DEDA8;
    case 0x0DEDABu: goto L_0DEDAB;
    case 0x0DEDAFu: goto L_0DEDAF;
    case 0x0DEDB1u: goto L_0DEDB1;
    case 0x0DEDB4u: goto L_0DEDB4;
    case 0x0DEDB6u: goto L_0DEDB6;
    case 0x0DEDB8u: goto L_0DEDB8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DED99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED99u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED99u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED99 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DED9B;
L_0DED9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED9B AND
    cpu.logicAnd(0xFu);
    goto L_0DED9D;
L_0DED9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED9D TAX
    cpu.transfer("TAX");
    goto L_0DED9E;
L_0DED9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED9E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DEDA0;
L_0DEDA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEDA0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DEDA2;
L_0DEDA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEDA2 LSR
    cpu.lsrA();
    goto L_0DEDA3;
L_0DEDA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEDA3 LSR
    cpu.lsrA();
    goto L_0DEDA4;
L_0DEDA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEDA4 LSR
    cpu.lsrA();
    goto L_0DEDA5;
L_0DEDA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEDA5 LSR
    cpu.lsrA();
    goto L_0DEDA6;
L_0DEDA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEDA6 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DEDA8;
L_0DEDA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA8u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEDA8 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xEDAAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DEDA8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEDAB;
L_0DEDAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDABu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDABu,0x0DEDABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDABu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDABu, 5u, 4u, ((0x0DED95u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEDAB LDA
    cpu.loadA(hw.readW(((0xDED95u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DEDAF;
L_0DEDAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAFu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAFu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DEDAF STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DEDB1;
L_0DEDB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB1u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEDB1 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xEDB3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDB4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DEDB1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEDB4;
L_0DEDB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDB4u,0x0DEDB4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB4u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEDB4 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DEDB6;
L_0DEDB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEDB6 BPL -> $0DEDA8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DEDA8; }
    goto L_0DEDB8;
L_0DEDB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEDB8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DEDB8u);return;} hw.unresolvedReturn(0x0DEDB8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0E8D0E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0E8D0Eu: goto L_0E8D0E;
    case 0x0E8D0Fu: goto L_0E8D0F;
    case 0x0E8D11u: goto L_0E8D11;
    case 0x0E8D13u: goto L_0E8D13;
    case 0x0E8D15u: goto L_0E8D15;
    case 0x0E8D17u: goto L_0E8D17;
    case 0x0E8D18u: goto L_0E8D18;
    case 0x0E8D1Au: goto L_0E8D1A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0E8D0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Eu,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8D0E TXS
    cpu.transfer("TXS");
    goto L_0E8D0F;
L_0E8D0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu,cpu,0x16u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8D0F ASL
    cpu.aslMem(hw, cpu.address("dpx", 0xDAu), cpu.m8?8:16);
    goto L_0E8D11;
L_0E8D11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D11u,cpu,0x16u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D11u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xEBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8D11 ASL
    cpu.aslMem(hw, cpu.address("dpx", 0xEBu), cpu.m8?8:16);
    goto L_0E8D13;
L_0E8D13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8D13 EOR
    cpu.logicXor(0xE4u);
    goto L_0E8D15;
L_0E8D15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D15u,cpu,0x16u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D15u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xCFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8D15 ASL
    cpu.aslMem(hw, cpu.address("dpx", 0xCFu), cpu.m8?8:16);
    goto L_0E8D17;
L_0E8D17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D17u,cpu,0xCBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D17u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8D17 WAI
    forja65_wait(cpu, hw, (std::uint32_t(cpu.pb)<<16)|0x8D18u); if(hw.stopped||hw.dispatchPending) return;
    goto L_0E8D18;
L_0E8D18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0E8D18 TRB
    cpu.trb(hw, cpu.address("dp", 0x8Fu), cpu.m8?8:16);
    goto L_0E8D1A;
L_0E8D1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0E8D1A BRK
    hw.partial(0x0E8D1Au, "BRK"); return;
}

void sub_B18008_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB18008u: goto L_B18008;
    case 0xB1800Bu: goto L_B1800B;
    case 0xB1800Du: goto L_B1800D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B18008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8008u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8008u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18008 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1800B;
L_B1800B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1800B AND
    cpu.logicAnd(0x3u);
    goto L_B1800D;
L_B1800D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1800D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1800Du);return;} hw.unresolvedReturn(0xB1800Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1A506_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A506u: goto L_B1A506;
    case 0xB1A509u: goto L_B1A509;
    case 0xB1A50Bu: goto L_B1A50B;
    case 0xB1A50Du: goto L_B1A50D;
    case 0xB1A50Fu: goto L_B1A50F;
    case 0xB1A511u: goto L_B1A511;
    case 0xB1A513u: goto L_B1A513;
    case 0xB1A515u: goto L_B1A515;
    case 0xB1A517u: goto L_B1A517;
    case 0xB1A519u: goto L_B1A519;
    case 0xB1A52Eu: goto L_B1A52E;
    case 0xB1A531u: goto L_B1A531;
    case 0xB1A534u: goto L_B1A534;
    case 0xB1A625u: goto L_B1A625;
    case 0xB1A627u: goto L_B1A627;
    case 0xB1A628u: goto L_B1A628;
    case 0xB1A62Au: goto L_B1A62A;
    case 0xB1A62Cu: goto L_B1A62C;
    case 0xB1A62Eu: goto L_B1A62E;
    case 0xB1A62Fu: goto L_B1A62F;
    case 0xB1A630u: goto L_B1A630;
    case 0xB1A633u: goto L_B1A633;
    case 0xB1A634u: goto L_B1A634;
    case 0xB1A636u: goto L_B1A636;
    case 0xB1A639u: goto L_B1A639;
    case 0xB1A63Cu: goto L_B1A63C;
    case 0xB1A63Du: goto L_B1A63D;
    case 0xB1A640u: goto L_B1A640;
    case 0xB1A642u: goto L_B1A642;
    case 0xB1A645u: goto L_B1A645;
    case 0xB1A647u: goto L_B1A647;
    case 0xB1A64Au: goto L_B1A64A;
    case 0xB1A64Bu: goto L_B1A64B;
    case 0xB1A64Eu: goto L_B1A64E;
    case 0xB1A64Fu: goto L_B1A64F;
    case 0xB1A652u: goto L_B1A652;
    case 0xB1A655u: goto L_B1A655;
    case 0xB1A657u: goto L_B1A657;
    case 0xB1A659u: goto L_B1A659;
    case 0xB1A65Cu: goto L_B1A65C;
    case 0xB1A65Fu: goto L_B1A65F;
    case 0xB1A660u: goto L_B1A660;
    case 0xB1A662u: goto L_B1A662;
    case 0xB1A664u: goto L_B1A664;
    case 0xB1A666u: goto L_B1A666;
    case 0xB1A667u: goto L_B1A667;
    case 0xB1A66Bu: goto L_B1A66B;
    case 0xB1A66Du: goto L_B1A66D;
    case 0xB1A670u: goto L_B1A670;
    case 0xB1A674u: goto L_B1A674;
    case 0xB1A677u: goto L_B1A677;
    case 0xB1A678u: goto L_B1A678;
    case 0xB1A67Au: goto L_B1A67A;
    case 0xB1A67Cu: goto L_B1A67C;
    case 0xB1A67Eu: goto L_B1A67E;
    case 0xB1A680u: goto L_B1A680;
    case 0xB1A682u: goto L_B1A682;
    case 0xB1A684u: goto L_B1A684;
    case 0xB1A685u: goto L_B1A685;
    case 0xB1A687u: goto L_B1A687;
    case 0xB1A689u: goto L_B1A689;
    case 0xB1A68Bu: goto L_B1A68B;
    case 0xB1A68Du: goto L_B1A68D;
    case 0xB1A68Fu: goto L_B1A68F;
    case 0xB1A691u: goto L_B1A691;
    case 0xB1A694u: goto L_B1A694;
    case 0xB1A696u: goto L_B1A696;
    case 0xB1A698u: goto L_B1A698;
    case 0xB1A69Au: goto L_B1A69A;
    case 0xB1A69Du: goto L_B1A69D;
    case 0xB1A6A0u: goto L_B1A6A0;
    case 0xB1A6A2u: goto L_B1A6A2;
    case 0xB1A6A4u: goto L_B1A6A4;
    case 0xB1A6A6u: goto L_B1A6A6;
    case 0xB1A6A8u: goto L_B1A6A8;
    case 0xB1A6AAu: goto L_B1A6AA;
    case 0xB1A6ACu: goto L_B1A6AC;
    case 0xB1A6AEu: goto L_B1A6AE;
    case 0xB1A6B1u: goto L_B1A6B1;
    case 0xB1A6B3u: goto L_B1A6B3;
    case 0xB1A6B6u: goto L_B1A6B6;
    case 0xB1A6B8u: goto L_B1A6B8;
    case 0xB1A6BBu: goto L_B1A6BB;
    case 0xB1A6BFu: goto L_B1A6BF;
    case 0xB1A6C1u: goto L_B1A6C1;
    case 0xB1A6C5u: goto L_B1A6C5;
    case 0xB1A6C7u: goto L_B1A6C7;
    case 0xB1A6C8u: goto L_B1A6C8;
    case 0xB1A6CAu: goto L_B1A6CA;
    case 0xB1A6CCu: goto L_B1A6CC;
    case 0xB1A6CEu: goto L_B1A6CE;
    case 0xB1A6D0u: goto L_B1A6D0;
    case 0xB1A6D2u: goto L_B1A6D2;
    case 0xB1A6D3u: goto L_B1A6D3;
    case 0xB1A6D6u: goto L_B1A6D6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA506u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA506u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A506 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A509;
L_B1A509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA509u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA509u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A509 CMP
    cpu.compareA(0x8u);
    goto L_B1A50B;
L_B1A50B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A50B BEQ -> $B1A52E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A52E; }
    goto L_B1A50D;
L_B1A50D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A50D CMP
    cpu.compareA(0x9u);
    goto L_B1A50F;
L_B1A50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A50F BEQ -> $B1A531
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A531; }
    goto L_B1A511;
L_B1A511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA511u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA511u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A511 CMP
    cpu.compareA(0xAu);
    goto L_B1A513;
L_B1A513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA513u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA513u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A513 BEQ -> $B1A534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A534; }
    goto L_B1A515;
L_B1A515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA515u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA515u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA515u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A515 CMP
    cpu.compareA(0xBu);
    goto L_B1A517;
L_B1A517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA517u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA517u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A517 BEQ -> $B1A534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A534; }
    goto L_B1A519;
L_B1A519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA519u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA519u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A519 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A519u);return;} hw.unresolvedReturn(0xB1A519u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A52E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA52Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Eu, 3u, 3u, cpu.address("abs", 0xA625u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A52E JMP -> $B1A625
    goto L_B1A625;
L_B1A531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA531u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u, 3u, 3u, cpu.address("abs", 0xA642u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A531 JMP -> $B1A642
    goto L_B1A642;
L_B1A534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA534u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u, 3u, 3u, cpu.address("abs", 0xA685u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A534 JMP -> $B1A685
    goto L_B1A685;
L_B1A625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A625 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A627;
L_B1A627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA627u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA627u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A627 SEC
    cpu.setFlag('C', true);
    goto L_B1A628;
L_B1A628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA628u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA628u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA628u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A628 SBC
    cpu.sbc(0x83u);
    goto L_B1A62A;
L_B1A62A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A62A CMP
    cpu.compareA(0x2u);
    goto L_B1A62C;
L_B1A62C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A62C BCS -> $B1A63D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A63D; }
    goto L_B1A62E;
L_B1A62E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Eu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A62E PHX
    cpu.push("PHX", hw);
    goto L_B1A62F;
L_B1A62F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Fu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A62F TYX
    cpu.transfer("TYX");
    goto L_B1A630;
L_B1A630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA630u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA630u, 6u, 3u, cpu.address("abs", 0x9098u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A630 JSR -> $B19098 stack real
    { cpu.push16Value(hw,0xA632u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA633u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9098u), 0xB1A630u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A633;
L_B1A633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA633u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA633u,0xB1A633u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA633u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA633u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A633 PLX
    cpu.pop("PLX", hw);
    goto L_B1A634;
L_B1A634:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA634u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA634u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA634u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A634 LDA
    cpu.setA(0x0u, 8);
    goto L_B1A636;
L_B1A636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA636u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA636u, 5u, 3u, cpu.address("absy", 0x00AAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A636 STA
    hw.write(cpu.address("absy", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B1A639;
L_B1A639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA639u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA639u, 6u, 3u, cpu.address("abs", 0xB4E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A639 JSR -> $B1B4E2 stack real
    { cpu.push16Value(hw,0xA63Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA63Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB4E2u), 0xB1A639u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A63C;
L_B1A63C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA63Cu,0xB1A63Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A63C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A63Cu);return;} hw.unresolvedReturn(0xB1A63Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A63D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Du, 6u, 3u, cpu.address("abs", 0xA77Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A63D JSR -> $B1A77C stack real
    { cpu.push16Value(hw,0xA63Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA640u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA77Cu), 0xB1A63Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A640;
L_B1A640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA640u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA640u,0xB1A640u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA640u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA640u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A640 BRA -> $B1A64A
    goto L_B1A64A;
L_B1A642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA642u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA642u, 6u, 3u, cpu.address("abs", 0x800Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A642 JSR -> $B1800E stack real
    { cpu.push16Value(hw,0xA644u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA645u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x800Eu), 0xB1A642u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A645;
L_B1A645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA645u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA645u,0xB1A645u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA645u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA645u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A645 BNE -> $B1A64A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A64A; }
    goto L_B1A647;
L_B1A647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA647u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA647u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA647u, 3u, 3u, cpu.address("abs", 0xA685u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A647 JMP -> $B1A685
    goto L_B1A685;
L_B1A64A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Au,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A64A PHX
    cpu.push("PHX", hw);
    goto L_B1A64B;
L_B1A64B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Bu, 4u + ((((0x1626u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A64B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1626u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A64E;
L_B1A64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A64E INC
    cpu.inc('A');
    goto L_B1A64F;
L_B1A64F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Fu, 5u, 3u, cpu.address("absy", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A64F STA
    hw.write(cpu.address("absy", 0x1626u), cpu.a, cpu.m8?8:16);
    goto L_B1A652;
L_B1A652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u, 4u + ((((0x1626u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A652 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x1626u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A655;
L_B1A655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA655u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA655u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A655 CPX
    cpu.compareX(0x8u);
    goto L_B1A657;
L_B1A657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA657u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA657u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA657u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A657 BCS -> $B1A65F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A65F; }
    goto L_B1A659;
L_B1A659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA659u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA659u, 4u + ((((0xA61Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA61Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A659 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA61Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A65C;
L_B1A65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Cu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A65C STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_B1A65F;
L_B1A65F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A65F TXA
    cpu.transfer("TXA");
    goto L_B1A660;
L_B1A660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A660 CMP
    cpu.compareA(0x8u);
    goto L_B1A662;
L_B1A662:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA662u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA662u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA662u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A662 BCC -> $B1A666
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A666; }
    goto L_B1A664;
L_B1A664:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA664u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA664u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA664u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A664 LDA
    cpu.setA(0x8u, 8);
    goto L_B1A666;
L_B1A666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA666u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA666u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A666 PLX
    cpu.pop("PLX", hw);
    goto L_B1A667;
L_B1A667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA667u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u, 8u, 4u, 0x02ACE5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A667 JSL -> $02ACE5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA66Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA66Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACE5u, 0xB1A667u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A66B;
L_B1A66B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA66Bu,0xB1A66Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A66B LDA
    cpu.setA(0x2u, 8);
    goto L_B1A66D;
L_B1A66D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Du, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A66D STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1A670;
L_B1A670:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA670u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA670u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA670u, 8u, 4u, 0x01AB72u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A670 JSL -> $01AB72 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA673u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA674u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB72u, 0xB1A670u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A674;
L_B1A674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA674u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA674u,0xB1A674u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA674u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA674u, 4u + ((((0x00B6u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x00B6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A674 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A677;
L_B1A677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA677u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA677u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA677u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A677 ASL
    cpu.aslA();
    goto L_B1A678;
L_B1A678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A678 LDA
    cpu.setA(0x10u, 8);
    goto L_B1A67A;
L_B1A67A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A67A BCC -> $B1A67E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A67E; }
    goto L_B1A67C;
L_B1A67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A67C LDA
    cpu.setA(0xF0u, 8);
    goto L_B1A67E;
L_B1A67E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A67E STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_B1A680;
L_B1A680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA680u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA680u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA680u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A680 LDA
    cpu.setA(0xD0u, 8);
    goto L_B1A682;
L_B1A682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA682u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA682u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A682 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B1A684;
L_B1A684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A684 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A684u);return;} hw.unresolvedReturn(0xB1A684u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA685u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA685u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA685u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A685 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A687;
L_B1A687:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA687u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA687u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA687u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A687 CMP
    cpu.compareA(0x83u);
    goto L_B1A689;
L_B1A689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A689 BEQ -> $B1A69A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A69A; }
    goto L_B1A68B;
L_B1A68B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A68B CMP
    cpu.compareA(0x84u);
    goto L_B1A68D;
L_B1A68D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A68D BEQ -> $B1A69A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A69A; }
    goto L_B1A68F;
L_B1A68F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A68F LDA
    cpu.setA(0x2u, 8);
    goto L_B1A691;
L_B1A691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA691u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA691u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA691u, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A691 STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1A694;
L_B1A694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA694u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA694u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A694 LDA
    cpu.setA(0xD0u, 8);
    goto L_B1A696;
L_B1A696:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA696u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA696u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA696u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A696 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B1A698;
L_B1A698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA698u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA698u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA698u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A698 BRA -> $B1A69D
    goto L_B1A69D;
L_B1A69A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Au, 6u, 3u, cpu.address("abs", 0xB4E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A69A JSR -> $B1B4E2 stack real
    { cpu.push16Value(hw,0xA69Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA69Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB4E2u), 0xB1A69Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A69D;
L_B1A69D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Du, 4u + ((((0x009Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x009Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A69D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A6A0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Du, 4u + ((((0x009Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x009Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A69D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A6A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA69Du,0xB1A69Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A6A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6A0 CMP
    cpu.compareA(0x80u);
    goto L_B1A6A2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6A0 CMP
    cpu.compareA(0x80u);
    goto L_B1A6A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6A0u,0xB1A6A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A6A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6A2 BEQ -> $B1A6BB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A6BB; }
    goto L_B1A6A4;
L_B1A6A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6A4 CMP
    cpu.compareA(0x83u);
    goto L_B1A6A6;
L_B1A6A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6A6 BEQ -> $B1A6B8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A6B8; }
    goto L_B1A6A8;
L_B1A6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6A8 CMP
    cpu.compareA(0x84u);
    goto L_B1A6AA;
L_B1A6AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6AA BEQ -> $B1A6B8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A6B8; }
    goto L_B1A6AC;
L_B1A6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6AC LDA
    cpu.setA(0x2u, 8);
    goto L_B1A6AE;
L_B1A6AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu, 5u, 3u, cpu.address("absy", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6AE STA
    hw.write(cpu.address("absy", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1A6B1;
L_B1A6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6B1 LDA
    cpu.setA(0xD0u, 8);
    goto L_B1A6B3;
L_B1A6B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B3u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B3u, 5u, 3u, cpu.address("absy", 0x00AAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6B3 STA
    hw.write(cpu.address("absy", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B1A6B6;
L_B1A6B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6B6 BRA -> $B1A6BB
    goto L_B1A6BB;
L_B1A6B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B8u, 6u, 3u, cpu.address("abs", 0xA5D3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A6B8 JSR -> $B1A5D3 stack real
    { cpu.push16Value(hw,0xA6BAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6BBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5D3u), 0xB1A6B8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A6BB;
L_B1A6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BBu, 8u, 4u, 0x01AB6Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A6BB JSL -> $01AB6F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA6BEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6BFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB6Fu, 0xB1A6BBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A6BF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BBu, 8u, 4u, 0x01AB6Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A6BB JSL -> $01AB6F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA6BEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6BFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB6Fu, 0xB1A6BBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A6BF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6BBu,0xB1A6BBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6BF LDA
    cpu.setA(0x4u, 8);
    goto L_B1A6C1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6BF LDA
    cpu.setA(0x4u, 8);
    goto L_B1A6C1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6BFu,0xB1A6BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A6C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C1u, 8u, 4u, 0x02ACE5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A6C1 JSL -> $02ACE5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA6C4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6C5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACE5u, 0xB1A6C1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A6C5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C1u, 8u, 4u, 0x02ACE5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A6C1 JSL -> $02ACE5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA6C4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6C5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACE5u, 0xB1A6C1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A6C5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6C1u,0xB1A6C1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1A6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6C5u,0xB1A6C5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6C5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A6C7;
L_B1A6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6C7 ASL
    cpu.aslA();
    goto L_B1A6C8;
L_B1A6C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6C8 LDA
    cpu.setA(0x10u, 8);
    goto L_B1A6CA;
L_B1A6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CAu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6CA BCS -> $B1A6CE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A6CE; }
    goto L_B1A6CC;
L_B1A6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6CC LDA
    cpu.setA(0xF0u, 8);
    goto L_B1A6CE;
L_B1A6CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CEu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6CE STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_B1A6D0;
L_B1A6D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D0u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6D0 EOR
    cpu.logicXor(0xFFu);
    goto L_B1A6D2;
L_B1A6D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D2u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6D2 INC
    cpu.inc('A');
    goto L_B1A6D3;
L_B1A6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D3u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D3u, 5u, 3u, cpu.address("absy", 0x00B6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A6D3 STA
    hw.write(cpu.address("absy", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_B1A6D6;
L_B1A6D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A6D6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A6D6u);return;} hw.unresolvedReturn(0xB1A6D6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_E485A4_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xE485A4u: goto L_E485A4;
    case 0xE485A7u: goto L_E485A7;
    case 0xE485A9u: goto L_E485A9;
    case 0xE485ACu: goto L_E485AC;
    case 0xE485ADu: goto L_E485AD;
    case 0xE485AFu: goto L_E485AF;
    case 0xE485B1u: goto L_E485B1;
    case 0xE485B4u: goto L_E485B4;
    case 0xE485B5u: goto L_E485B5;
    case 0xE485B7u: goto L_E485B7;
    case 0xE485B9u: goto L_E485B9;
    case 0xE485BBu: goto L_E485BB;
    case 0xE485BDu: goto L_E485BD;
    case 0xE485C0u: goto L_E485C0;
    case 0xE485C1u: goto L_E485C1;
    case 0xE485C3u: goto L_E485C3;
    case 0xE485C4u: goto L_E485C4;
    case 0xE485C5u: goto L_E485C5;
    case 0xE485C9u: goto L_E485C9;
    case 0xE485CAu: goto L_E485CA;
    case 0xE485CCu: goto L_E485CC;
    case 0xE485CFu: goto L_E485CF;
    case 0xE485D3u: goto L_E485D3;
    case 0xE485D5u: goto L_E485D5;
    case 0xE485D8u: goto L_E485D8;
    case 0xE485DBu: goto L_E485DB;
    case 0xE485DDu: goto L_E485DD;
    case 0xE485E0u: goto L_E485E0;
    case 0xE485E3u: goto L_E485E3;
    case 0xE485E5u: goto L_E485E5;
    case 0xE485E8u: goto L_E485E8;
    case 0xE485EAu: goto L_E485EA;
    case 0xE485ECu: goto L_E485EC;
    case 0xE485EEu: goto L_E485EE;
    case 0xE485F0u: goto L_E485F0;
    case 0xE485F2u: goto L_E485F2;
    case 0xE485F3u: goto L_E485F3;
    case 0xE485F5u: goto L_E485F5;
    case 0xE485F8u: goto L_E485F8;
    case 0xE485F9u: goto L_E485F9;
    case 0xE485FBu: goto L_E485FB;
    case 0xE485FDu: goto L_E485FD;
    case 0xE485FFu: goto L_E485FF;
    case 0xE48602u: goto L_E48602;
    case 0xE48604u: goto L_E48604;
    case 0xE48607u: goto L_E48607;
    case 0xE48609u: goto L_E48609;
    case 0xE4860Cu: goto L_E4860C;
    case 0xE4860Du: goto L_E4860D;
    case 0xE4860Eu: goto L_E4860E;
    case 0xE48610u: goto L_E48610;
    case 0xE48613u: goto L_E48613;
    case 0xE48614u: goto L_E48614;
    case 0xE48615u: goto L_E48615;
    case 0xE48616u: goto L_E48616;
    case 0xE48618u: goto L_E48618;
    case 0xE4861Au: goto L_E4861A;
    case 0xE4861Cu: goto L_E4861C;
    case 0xE4861Eu: goto L_E4861E;
    case 0xE48620u: goto L_E48620;
    case 0xE48621u: goto L_E48621;
    case 0xE48623u: goto L_E48623;
    case 0xE48625u: goto L_E48625;
    case 0xE48626u: goto L_E48626;
    case 0xE48627u: goto L_E48627;
    case 0xE48628u: goto L_E48628;
    case 0xE48629u: goto L_E48629;
    case 0xE4862Bu: goto L_E4862B;
    case 0xE4862Du: goto L_E4862D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_E485A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A4u, 6u, 3u, cpu.address("abs", 0x862Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E485A4 JSR -> $E4862E stack real
    { cpu.push16Value(hw,0x85A6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x85A7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x862Eu), 0xE485A4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_E485A7;
L_E485A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85A7u,0xE485A7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485A7 REP
    cpu.rep(0x20u);
    goto L_E485A9;
L_E485A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485A9 LDA
    cpu.setA(0x1Eu, 16);
    goto L_E485AC;
L_E485AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85ACu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485AC CLC
    cpu.setFlag('C', false);
    goto L_E485AD;
L_E485AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85ADu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485AD ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_E485AF;
L_E485AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85AFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485AF STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_E485B1;
L_E485B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485B1 LDA
    cpu.setA(0x6u, 16);
    goto L_E485B4;
L_E485B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485B4 CLC
    cpu.setFlag('C', false);
    goto L_E485B5;
L_E485B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B5u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485B5 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_E485B7;
L_E485B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485B7 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_E485B9;
L_E485B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485B9 SEP
    cpu.sep(0x20u);
    goto L_E485BB;
L_E485BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485BB LDA
    cpu.setA(0x8u, 8);
    goto L_E485BD;
L_E485BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BDu, 4u, 3u, cpu.address("abs", 0x007Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485BD STA
    hw.write(cpu.address("abs", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_E485C0;
L_E485C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C0u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $E485C0 PHB
    cpu.push("PHB", hw);
    goto L_E485C1;
L_E485C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485C1 LDA
    cpu.setA(0x0u, 8);
    goto L_E485C3;
L_E485C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $E485C3 PHA
    cpu.push("PHA", hw);
    goto L_E485C4;
L_E485C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C4u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $E485C4 PLB
    cpu.pop("PLB", hw);
    goto L_E485C5;
L_E485C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C5u, 8u, 4u, 0x00CEB1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $E485C5 JSL -> $00CEB1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x85C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x85C9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00CEB1u, 0xE485C5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_E485C9;
L_E485C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85C9u,0xE485C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $E485C9 PLB
    cpu.pop("PLB", hw);
    goto L_E485CA;
L_E485CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485CA LDA
    cpu.setA(0x3u, 8);
    goto L_E485CC;
L_E485CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CCu, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485CC STA
    hw.write(cpu.address("abs", 0x13F9u), cpu.a, cpu.m8?8:16);
    goto L_E485CF;
L_E485CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CFu, 8u, 4u, 0x00E2BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $E485CF JSL -> $00E2BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x85D2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x85D3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00E2BDu, 0xE485CFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_E485D3;
L_E485D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85D3u,0xE485D3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485D3 LDA
    cpu.setA(0x6u, 8);
    goto L_E485D5;
L_E485D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D5u, 4u, 3u, cpu.address("abs", 0x0D84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485D5 STA
    hw.write(cpu.address("abs", 0xD84u), cpu.a, cpu.m8?8:16);
    goto L_E485D8;
L_E485D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D8u, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485D8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1496u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E485DB;
L_E485DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485DB BEQ -> $E485E0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_E485E0; }
    goto L_E485DD;
L_E485DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DDu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DDu, 6u, 3u, cpu.address("abs", 0x1496u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485DD DEC
    cpu.decMem(hw, cpu.address("abs", 0x1496u), cpu.m8?8:16);
    goto L_E485E0;
L_E485E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E0u, 4u, 3u, cpu.address("abs", 0x14A2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485E0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E485E3;
L_E485E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485E3 BEQ -> $E485E8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_E485E8; }
    goto L_E485E5;
L_E485E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E5u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E5u, 6u, 3u, cpu.address("abs", 0x14A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485E5 DEC
    cpu.decMem(hw, cpu.address("abs", 0x14A2u), cpu.m8?8:16);
    goto L_E485E8;
L_E485E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485E8 LDA
    cpu.setA(0x18u, 8);
    goto L_E485EA;
L_E485EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485EA STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_E485EC;
L_E485EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85ECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485EC LDA
    cpu.setA(0x7u, 8);
    goto L_E485EE;
L_E485EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485EE STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_E485F0;
L_E485F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485F0 LDY
    cpu.setY(0x0u, 8);
    goto L_E485F2;
L_E485F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F2u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485F2 TYX
    cpu.transfer("TYX");
    goto L_E485F3;
L_E485F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485F3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E485F5;
L_E485F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u, 5u, 3u, cpu.address("absx", 0x0200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485F5 STA
    hw.write(cpu.address("absx", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_E485F8;
L_E485F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485F8 CLC
    cpu.setFlag('C', false);
    goto L_E485F9;
L_E485F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485F9 ADC
    cpu.adc(0x8u);
    goto L_E485FB;
L_E485FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485FB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_E485FD;
L_E485FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485FD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E485FF;
L_E485FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FFu, 5u, 3u, cpu.address("absx", 0x0201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E485FF STA
    hw.write(cpu.address("absx", 0x201u), cpu.a, cpu.m8?8:16);
    goto L_E48602;
L_E48602:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8602u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8602u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8602u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48602 LDA
    cpu.setA(0x7Eu, 8);
    goto L_E48604;
L_E48604:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8604u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8604u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8604u, 5u, 3u, cpu.address("absx", 0x0202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48604 STA
    hw.write(cpu.address("absx", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_E48607;
L_E48607:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8607u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8607u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8607u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48607 LDA
    cpu.setA(0x36u, 8);
    goto L_E48609;
L_E48609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u, 5u, 3u, cpu.address("absx", 0x0203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48609 STA
    hw.write(cpu.address("absx", 0x203u), cpu.a, cpu.m8?8:16);
    goto L_E4860C;
L_E4860C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $E4860C PHX
    cpu.push("PHX", hw);
    goto L_E4860D;
L_E4860D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Du,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4860D TYX
    cpu.transfer("TYX");
    goto L_E4860E;
L_E4860E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4860E LDA
    cpu.setA(0x0u, 8);
    goto L_E48610;
L_E48610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8610u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8610u, 5u, 3u, cpu.address("absx", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48610 STA
    hw.write(cpu.address("absx", 0x420u), cpu.a, cpu.m8?8:16);
    goto L_E48613;
L_E48613:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8613u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8613u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8613u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $E48613 PLX
    cpu.pop("PLX", hw);
    goto L_E48614;
L_E48614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8614u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8614u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48614 INY
    cpu.inc('Y');
    goto L_E48615;
L_E48615:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8615u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8615u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8615u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48615 TYA
    cpu.transfer("TYA");
    goto L_E48616;
L_E48616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8616u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8616u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48616 AND
    cpu.logicAnd(0x3u);
    goto L_E48618;
L_E48618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48618 BNE -> $E48625
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_E48625; }
    goto L_E4861A;
L_E4861A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4861A LDA
    cpu.setA(0x18u, 8);
    goto L_E4861C;
L_E4861C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4861C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_E4861E;
L_E4861E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4861E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48620;
L_E48620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8620u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8620u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48620 CLC
    cpu.setFlag('C', false);
    goto L_E48621;
L_E48621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8621u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8621u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48621 ADC
    cpu.adc(0x8u);
    goto L_E48623;
L_E48623:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8623u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8623u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8623u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48623 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_E48625;
L_E48625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8625u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8625u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48625 INX
    cpu.inc('X');
    goto L_E48626;
L_E48626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8626u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8626u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8626u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48626 INX
    cpu.inc('X');
    goto L_E48627;
L_E48627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8627u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8627u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48627 INX
    cpu.inc('X');
    goto L_E48628;
L_E48628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8628u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8628u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8628u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48628 INX
    cpu.inc('X');
    goto L_E48629;
L_E48629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8629u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8629u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48629 CPY
    cpu.compareY(0x10u);
    goto L_E4862B;
L_E4862B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4862B BNE -> $E485F3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_E485F3; }
    goto L_E4862D;
L_E4862D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E4862D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xE4862Du);return;} hw.unresolvedReturn(0xE4862Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

