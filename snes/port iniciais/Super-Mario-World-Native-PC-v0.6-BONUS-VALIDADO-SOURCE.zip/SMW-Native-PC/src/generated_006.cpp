#include "generated.hpp"
void sub_008EC4_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008EC4u: goto L_008EC4;
    case 0x008EC6u: goto L_008EC6;
    case 0x008EC9u: goto L_008EC9;
    case 0x008ECBu: goto L_008ECB;
    case 0x008ECDu: goto L_008ECD;
    case 0x008ED0u: goto L_008ED0;
    case 0x008ED2u: goto L_008ED2;
    case 0x008ED5u: goto L_008ED5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008EC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EC4 BPL -> $008E97
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x008E97u,0x008EC4u); return; }
    goto L_008EC6;
L_008EC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC6u, 4u, 3u, cpu.address("abs", 0x0F36u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EC6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008EC9;
L_008EC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EC9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_008ECB;
L_008ECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECBu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008ECB STZ
    hw.write(cpu.address("dp", 0x1u), 0, cpu.m8?8:16);
    goto L_008ECD;
L_008ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu, 4u, 3u, cpu.address("abs", 0x0F35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008ECD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF35u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008ED0;
L_008ED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008ED0 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_008ED2;
L_008ED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED2u, 4u, 3u, cpu.address("abs", 0x0F34u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008ED2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF34u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008ED5;
L_008ED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008ED5 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8ED7u,0x008ED5u); return;
}

void sub_009CBE_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x009CBEu: goto L_009CBE;
    case 0x009CC0u: goto L_009CC0;
    case 0x009CC2u: goto L_009CC2;
    case 0x009CC4u: goto L_009CC4;
    case 0x009CC6u: goto L_009CC6;
    case 0x009CC8u: goto L_009CC8;
    case 0x009CCAu: goto L_009CCA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_009CBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009CBE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009CC0;
L_009CC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009CC0 AND
    cpu.logicAnd(0xC0u);
    goto L_009CC2;
L_009CC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009CC2 BNE -> $009CCA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009CCA; }
    goto L_009CC4;
L_009CC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009CC4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009CC6;
L_009CC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009CC6 AND
    cpu.logicAnd(0xF0u);
    goto L_009CC8;
L_009CC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009CC8 BNE -> $009CCA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009CCA; }
    goto L_009CCA;
L_009CCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009CCA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009CCAu);return;} hw.unresolvedReturn(0x009CCAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00ACED_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00ACEDu: goto L_00ACED;
    case 0x00ACF0u: goto L_00ACF0;
    case 0x00ACF2u: goto L_00ACF2;
    case 0x00ACF5u: goto L_00ACF5;
    case 0x00ACF6u: goto L_00ACF6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00ACED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACEDu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACEDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACED LDY
    cpu.setY(0x7u, 16);
    goto L_00ACF0;
L_00ACF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACF0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ACF2;
L_00ACF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF2u, 6u, 3u, cpu.address("absx", 0x0703u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACF2 STA
    hw.write(cpu.address("absx", 0x703u), cpu.a, cpu.m8?8:16);
    goto L_00ACF5;
L_00ACF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACF5 TXA
    cpu.transfer("TXA");
    goto L_00ACF6;
L_00ACF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACF6 CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xACF7u,0x00ACF6u); return;
}

void sub_00ACED_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00ACEDu: goto L_00ACED;
    case 0x00ACF0u: goto L_00ACF0;
    case 0x00ACF2u: goto L_00ACF2;
    case 0x00ACF5u: goto L_00ACF5;
    case 0x00ACF6u: goto L_00ACF6;
    case 0x00ACF7u: goto L_00ACF7;
    case 0x00ACFAu: goto L_00ACFA;
    case 0x00ACFBu: goto L_00ACFB;
    case 0x00ACFCu: goto L_00ACFC;
    case 0x00ACFEu: goto L_00ACFE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00ACED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACEDu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACEDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACED LDY
    cpu.setY(0x7u, 16);
    goto L_00ACF0;
L_00ACF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACF0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ACF2;
L_00ACF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF2u, 6u, 3u, cpu.address("absx", 0x0703u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACF2 STA
    hw.write(cpu.address("absx", 0x703u), cpu.a, cpu.m8?8:16);
    goto L_00ACF5;
L_00ACF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACF5 TXA
    cpu.transfer("TXA");
    goto L_00ACF6;
L_00ACF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACF6 CLC
    cpu.setFlag('C', false);
    goto L_00ACF7;
L_00ACF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACF7 ADC
    cpu.adc(0x20u);
    goto L_00ACFA;
L_00ACFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACFA TAX
    cpu.transfer("TAX");
    goto L_00ACFB;
L_00ACFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFBu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACFB DEY
    cpu.decReg('Y');
    goto L_00ACFC;
L_00ACFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ACFC BPL -> $00ACF0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00ACF0; }
    goto L_00ACFE;
L_00ACFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ACFE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00ACFEu);return;} hw.unresolvedReturn(0x00ACFEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00B983_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00B983u: goto L_00B983;
    case 0x00B985u: goto L_00B985;
    case 0x00B987u: goto L_00B987;
    case 0x00B988u: goto L_00B988;
    case 0x00B98Au: goto L_00B98A;
    case 0x00B98Du: goto L_00B98D;
    case 0x00B98Fu: goto L_00B98F;
    case 0x00B991u: goto L_00B991;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00B983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB983u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB983u,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB983u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Au) & 0xFFFFu), 3u, 0u);
    // $00B983 LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B985;
L_00B985:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB985u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB985u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB985u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B985 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B987;
L_00B987:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB987u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B987 INX
    cpu.inc('X');
    goto L_00B988;
L_00B988:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB988u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB988u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB988u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B988 BNE -> $00B98F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B98F; }
    goto L_00B98A;
L_00B98A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B98A LDX
    cpu.setX(0x8000u, 16);
    goto L_00B98D;
L_00B98D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B98D INC
    cpu.incMem(hw, cpu.address("dp", 0x8Cu), cpu.m8?8:16);
    goto L_00B98F;
L_00B98F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Fu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B98F STX
    hw.write(cpu.address("dp", 0x8Au), cpu.x, cpu.x8?8:16);
    goto L_00B991;
L_00B991:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB991u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB991u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB991u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B991 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00B991u);return;} hw.unresolvedReturn(0x00B991u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00B983_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00B983u: goto L_00B983;
    case 0x00B985u: goto L_00B985;
    case 0x00B987u: goto L_00B987;
    case 0x00B988u: goto L_00B988;
    case 0x00B98Au: goto L_00B98A;
    case 0x00B98Du: goto L_00B98D;
    case 0x00B98Fu: goto L_00B98F;
    case 0x00B991u: goto L_00B991;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00B983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB983u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB983u,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB983u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Au) & 0xFFFFu), 3u, 0u);
    // $00B983 LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B985;
L_00B985:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB985u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB985u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB985u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B985 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B987;
L_00B987:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB987u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B987 INX
    cpu.inc('X');
    goto L_00B988;
L_00B988:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB988u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB988u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB988u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B988 BNE -> $00B98F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B98F; }
    goto L_00B98A;
L_00B98A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B98A LDX
    cpu.setX(0x8000u, 16);
    goto L_00B98D;
L_00B98D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B98D INC
    cpu.incMem(hw, cpu.address("dp", 0x8Cu), cpu.m8?8:16);
    goto L_00B98F;
L_00B98F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Fu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B98F STX
    hw.write(cpu.address("dp", 0x8Au), cpu.x, cpu.x8?8:16);
    goto L_00B991;
L_00B991:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB991u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB991u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB991u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B991 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00B991u);return;} hw.unresolvedReturn(0x00B991u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00C00D_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00C00Du: goto L_00C00D;
    case 0x00C00Fu: goto L_00C00F;
    case 0x00C011u: goto L_00C011;
    case 0x00C014u: goto L_00C014;
    case 0x00C015u: goto L_00C015;
    case 0x00C016u: goto L_00C016;
    case 0x00C017u: goto L_00C017;
    case 0x00C018u: goto L_00C018;
    case 0x00C019u: goto L_00C019;
    case 0x00C01Au: goto L_00C01A;
    case 0x00C01Cu: goto L_00C01C;
    case 0x00C01Eu: goto L_00C01E;
    case 0x00C021u: goto L_00C021;
    case 0x00C022u: goto L_00C022;
    case 0x00C023u: goto L_00C023;
    case 0x00C024u: goto L_00C024;
    case 0x00C025u: goto L_00C025;
    case 0x00C026u: goto L_00C026;
    case 0x00C027u: goto L_00C027;
    case 0x00C028u: goto L_00C028;
    case 0x00C02Au: goto L_00C02A;
    case 0x00C02Cu: goto L_00C02C;
    case 0x00C02Eu: goto L_00C02E;
    case 0x00C031u: goto L_00C031;
    case 0x00C033u: goto L_00C033;
    case 0x00C035u: goto L_00C035;
    case 0x00C038u: goto L_00C038;
    case 0x00C03Au: goto L_00C03A;
    case 0x00C03Du: goto L_00C03D;
    case 0x00C040u: goto L_00C040;
    case 0x00C041u: goto L_00C041;
    case 0x00C042u: goto L_00C042;
    case 0x00C046u: goto L_00C046;
    case 0x00C047u: goto L_00C047;
    case 0x00C049u: goto L_00C049;
    case 0x00C04Bu: goto L_00C04B;
    case 0x00C04Cu: goto L_00C04C;
    case 0x00C04Eu: goto L_00C04E;
    case 0x00C051u: goto L_00C051;
    case 0x00C052u: goto L_00C052;
    case 0x00C053u: goto L_00C053;
    case 0x00C054u: goto L_00C054;
    case 0x00C055u: goto L_00C055;
    case 0x00C056u: goto L_00C056;
    case 0x00C058u: goto L_00C058;
    case 0x00C05Bu: goto L_00C05B;
    case 0x00C05Fu: goto L_00C05F;
    case 0x00C062u: goto L_00C062;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00C00D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC00Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C00D REP
    cpu.rep(0x30u);
    goto L_00C00F;
L_00C00F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC00Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C00F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C011;
L_00C011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC011u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC011u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C011 AND
    cpu.logicAnd(0xFF00u);
    goto L_00C014;
L_00C014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC014u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC014u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C014 LSR
    cpu.lsrA();
    goto L_00C015;
L_00C015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC015u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC015u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC015u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C015 LSR
    cpu.lsrA();
    goto L_00C016;
L_00C016:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC016u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC016u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC016u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C016 LSR
    cpu.lsrA();
    goto L_00C017;
L_00C017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC017u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC017u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C017 LSR
    cpu.lsrA();
    goto L_00C018;
L_00C018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC018u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC018u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C018 LSR
    cpu.lsrA();
    goto L_00C019;
L_00C019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC019u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC019u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C019 LSR
    cpu.lsrA();
    goto L_00C01A;
L_00C01A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC01Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C01A STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00C01C;
L_00C01C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC01Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C01C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C01E;
L_00C01E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC01Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C01E AND
    cpu.logicAnd(0x80u);
    goto L_00C021;
L_00C021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC021u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC021u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C021 LSR
    cpu.lsrA();
    goto L_00C022;
L_00C022:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC022u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC022u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC022u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C022 LSR
    cpu.lsrA();
    goto L_00C023;
L_00C023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC023u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC023u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C023 LSR
    cpu.lsrA();
    goto L_00C024;
L_00C024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC024u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC024u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C024 LSR
    cpu.lsrA();
    goto L_00C025;
L_00C025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC025u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC025u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C025 LSR
    cpu.lsrA();
    goto L_00C026;
L_00C026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC026u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC026u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C026 LSR
    cpu.lsrA();
    goto L_00C027;
L_00C027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC027u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC027u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C027 LSR
    cpu.lsrA();
    goto L_00C028;
L_00C028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC028u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC028u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C028 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_00C02A;
L_00C02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC02Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C02A STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00C02C;
L_00C02C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC02Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C02C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C02E;
L_00C02E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC02Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C02E AND
    cpu.logicAnd(0x100u);
    goto L_00C031;
L_00C031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC031u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC031u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C031 BEQ -> $00C03A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C03A; }
    goto L_00C033;
L_00C033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC033u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC033u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C033 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C035;
L_00C035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC035u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC035u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C035 ORA
    cpu.logicOr(0x2u);
    goto L_00C038;
L_00C038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC038u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC038u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C038 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00C03A;
L_00C03A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC03Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Au, 5u, 3u, cpu.address("abs", 0x13BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C03A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C03D;
L_00C03D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC03Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C03D AND
    cpu.logicAnd(0xFu);
    goto L_00C040;
L_00C040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC040u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC040u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C040 ASL
    cpu.aslA();
    goto L_00C041;
L_00C041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC041u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC041u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC041u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C041 TAX
    cpu.transfer("TAX");
    goto L_00C042;
L_00C042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC042u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC042u, 6u, 4u, ((0x00BFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C042 LDA
    cpu.loadA(hw.readW(((0xBFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C046;
L_00C046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC046u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC046u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C046 CLC
    cpu.setFlag('C', false);
    goto L_00C047;
L_00C047:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC047u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC047u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC047u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C047 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_00C049;
L_00C049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC049u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC049u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C049 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00C04B;
L_00C04B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C04B TAY
    cpu.transfer("TAY");
    goto L_00C04C;
L_00C04C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C04C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C04E;
L_00C04E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C04E AND
    cpu.logicAnd(0x70u);
    goto L_00C051;
L_00C051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC051u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC051u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C051 LSR
    cpu.lsrA();
    goto L_00C052;
L_00C052:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC052u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC052u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC052u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C052 LSR
    cpu.lsrA();
    goto L_00C053;
L_00C053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC053u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC053u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C053 LSR
    cpu.lsrA();
    goto L_00C054;
L_00C054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC054u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC054u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C054 LSR
    cpu.lsrA();
    goto L_00C055;
L_00C055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC055u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC055u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C055 TAX
    cpu.transfer("TAX");
    goto L_00C056;
L_00C056:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC056u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC056u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC056u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C056 SEP
    cpu.sep(0x20u);
    goto L_00C058;
L_00C058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC058u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC058u, 4u + 1u, 3u, cpu.address("absy", 0x19F8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C058 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x19F8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C05B;
L_00C05B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Bu,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Bu, 5u, 4u, ((0x00C005u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C05B ORA
    cpu.logicOr(hw.readW(((0xC005u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00C05F;
L_00C05F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Fu, 5u, 3u, cpu.address("absy", 0x19F8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C05F STA
    hw.write(cpu.address("absy", 0x19F8u), cpu.a, cpu.m8?8:16);
    goto L_00C062;
L_00C062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC062u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC062u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00C062 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00C062u);return;} hw.unresolvedReturn(0x00C062u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00C00D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00C00Du: goto L_00C00D;
    case 0x00C00Fu: goto L_00C00F;
    case 0x00C011u: goto L_00C011;
    case 0x00C014u: goto L_00C014;
    case 0x00C015u: goto L_00C015;
    case 0x00C016u: goto L_00C016;
    case 0x00C017u: goto L_00C017;
    case 0x00C018u: goto L_00C018;
    case 0x00C019u: goto L_00C019;
    case 0x00C01Au: goto L_00C01A;
    case 0x00C01Cu: goto L_00C01C;
    case 0x00C01Eu: goto L_00C01E;
    case 0x00C021u: goto L_00C021;
    case 0x00C022u: goto L_00C022;
    case 0x00C023u: goto L_00C023;
    case 0x00C024u: goto L_00C024;
    case 0x00C025u: goto L_00C025;
    case 0x00C026u: goto L_00C026;
    case 0x00C027u: goto L_00C027;
    case 0x00C028u: goto L_00C028;
    case 0x00C02Au: goto L_00C02A;
    case 0x00C02Cu: goto L_00C02C;
    case 0x00C02Eu: goto L_00C02E;
    case 0x00C031u: goto L_00C031;
    case 0x00C033u: goto L_00C033;
    case 0x00C035u: goto L_00C035;
    case 0x00C038u: goto L_00C038;
    case 0x00C03Au: goto L_00C03A;
    case 0x00C03Du: goto L_00C03D;
    case 0x00C040u: goto L_00C040;
    case 0x00C041u: goto L_00C041;
    case 0x00C042u: goto L_00C042;
    case 0x00C046u: goto L_00C046;
    case 0x00C047u: goto L_00C047;
    case 0x00C049u: goto L_00C049;
    case 0x00C04Bu: goto L_00C04B;
    case 0x00C04Cu: goto L_00C04C;
    case 0x00C04Eu: goto L_00C04E;
    case 0x00C051u: goto L_00C051;
    case 0x00C052u: goto L_00C052;
    case 0x00C053u: goto L_00C053;
    case 0x00C054u: goto L_00C054;
    case 0x00C055u: goto L_00C055;
    case 0x00C056u: goto L_00C056;
    case 0x00C058u: goto L_00C058;
    case 0x00C05Bu: goto L_00C05B;
    case 0x00C05Fu: goto L_00C05F;
    case 0x00C062u: goto L_00C062;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00C00D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC00Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C00D REP
    cpu.rep(0x30u);
    goto L_00C00F;
L_00C00F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC00Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C00F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C011;
L_00C011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC011u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC011u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C011 AND
    cpu.logicAnd(0xFF00u);
    goto L_00C014;
L_00C014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC014u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC014u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C014 LSR
    cpu.lsrA();
    goto L_00C015;
L_00C015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC015u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC015u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC015u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C015 LSR
    cpu.lsrA();
    goto L_00C016;
L_00C016:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC016u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC016u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC016u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C016 LSR
    cpu.lsrA();
    goto L_00C017;
L_00C017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC017u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC017u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C017 LSR
    cpu.lsrA();
    goto L_00C018;
L_00C018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC018u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC018u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C018 LSR
    cpu.lsrA();
    goto L_00C019;
L_00C019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC019u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC019u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C019 LSR
    cpu.lsrA();
    goto L_00C01A;
L_00C01A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC01Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C01A STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00C01C;
L_00C01C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC01Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C01C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C01E;
L_00C01E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC01Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C01E AND
    cpu.logicAnd(0x80u);
    goto L_00C021;
L_00C021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC021u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC021u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C021 LSR
    cpu.lsrA();
    goto L_00C022;
L_00C022:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC022u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC022u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC022u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C022 LSR
    cpu.lsrA();
    goto L_00C023;
L_00C023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC023u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC023u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C023 LSR
    cpu.lsrA();
    goto L_00C024;
L_00C024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC024u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC024u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C024 LSR
    cpu.lsrA();
    goto L_00C025;
L_00C025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC025u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC025u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C025 LSR
    cpu.lsrA();
    goto L_00C026;
L_00C026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC026u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC026u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C026 LSR
    cpu.lsrA();
    goto L_00C027;
L_00C027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC027u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC027u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C027 LSR
    cpu.lsrA();
    goto L_00C028;
L_00C028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC028u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC028u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C028 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_00C02A;
L_00C02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC02Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C02A STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00C02C;
L_00C02C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC02Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C02C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C02E;
L_00C02E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC02Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C02E AND
    cpu.logicAnd(0x100u);
    goto L_00C031;
L_00C031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC031u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC031u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C031 BEQ -> $00C03A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C03A; }
    goto L_00C033;
L_00C033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC033u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC033u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C033 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C035;
L_00C035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC035u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC035u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C035 ORA
    cpu.logicOr(0x2u);
    goto L_00C038;
L_00C038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC038u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC038u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C038 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00C03A;
L_00C03A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC03Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Au, 5u, 3u, cpu.address("abs", 0x13BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C03A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C03D;
L_00C03D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC03Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C03D AND
    cpu.logicAnd(0xFu);
    goto L_00C040;
L_00C040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC040u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC040u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C040 ASL
    cpu.aslA();
    goto L_00C041;
L_00C041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC041u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC041u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC041u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C041 TAX
    cpu.transfer("TAX");
    goto L_00C042;
L_00C042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC042u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC042u, 6u, 4u, ((0x00BFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C042 LDA
    cpu.loadA(hw.readW(((0xBFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C046;
L_00C046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC046u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC046u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C046 CLC
    cpu.setFlag('C', false);
    goto L_00C047;
L_00C047:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC047u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC047u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC047u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C047 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_00C049;
L_00C049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC049u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC049u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C049 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00C04B;
L_00C04B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C04B TAY
    cpu.transfer("TAY");
    goto L_00C04C;
L_00C04C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C04C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C04E;
L_00C04E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C04E AND
    cpu.logicAnd(0x70u);
    goto L_00C051;
L_00C051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC051u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC051u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C051 LSR
    cpu.lsrA();
    goto L_00C052;
L_00C052:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC052u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC052u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC052u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C052 LSR
    cpu.lsrA();
    goto L_00C053;
L_00C053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC053u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC053u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C053 LSR
    cpu.lsrA();
    goto L_00C054;
L_00C054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC054u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC054u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C054 LSR
    cpu.lsrA();
    goto L_00C055;
L_00C055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC055u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC055u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C055 TAX
    cpu.transfer("TAX");
    goto L_00C056;
L_00C056:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC056u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC056u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC056u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C056 SEP
    cpu.sep(0x20u);
    goto L_00C058;
L_00C058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC058u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC058u, 4u + 1u, 3u, cpu.address("absy", 0x19F8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C058 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x19F8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C05B;
L_00C05B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Bu,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Bu, 5u, 4u, ((0x00C005u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C05B ORA
    cpu.logicOr(hw.readW(((0xC005u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00C05F;
L_00C05F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Fu, 5u, 3u, cpu.address("absy", 0x19F8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C05F STA
    hw.write(cpu.address("absy", 0x19F8u), cpu.a, cpu.m8?8:16);
    goto L_00C062;
L_00C062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC062u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC062u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00C062 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00C062u);return;} hw.unresolvedReturn(0x00C062u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00C47E_E1M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00C592u: goto L_00C592;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00C592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC592u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00C592 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00C592u);return;} hw.unresolvedReturn(0x00C592u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00C592 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00C592u);return;} hw.unresolvedReturn(0x00C592u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00C592 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00C592u);return;} hw.unresolvedReturn(0x00C592u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC592u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00C592 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00C592u);return;} hw.unresolvedReturn(0x00C592u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC592u,0x00C592u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E1M1X1CQ_part26(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF65u: goto L_00EF65;
    case 0x00EF68u: goto L_00EF68;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF65u))return;
  // 57 variantes de decodificacao M/X para este endereco; 8 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF65u,0x00EF65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF68u))return;
  // 57 variantes de decodificacao M/X para este endereco; 8 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 5u, 3u, cpu.address("abs", 0x18B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,0x00EF68u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 5u, 3u, cpu.address("abs", 0x18B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,0x00EF68u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 4u, 3u, cpu.address("abs", 0x18B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,0x00EF68u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 4u, 3u, cpu.address("abs", 0x18B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,0x00EF68u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 5u, 3u, cpu.address("abs", 0x18B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,0x00EF68u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 5u, 3u, cpu.address("abs", 0x18B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,0x00EF68u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 4u, 3u, cpu.address("abs", 0x18B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,0x00EF68u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 4u, 3u, cpu.address("abs", 0x18B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,0x00EF68u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF68u,0x00EF68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E0M1X1CQ_part41(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EFAEu: goto L_00EFAE;
    case 0x00EFB0u: goto L_00EFB0;
    case 0x00EFB2u: goto L_00EFB2;
    case 0x00EFB6u: goto L_00EFB6;
    case 0x00EFB8u: goto L_00EFB8;
    case 0x00EFB9u: goto L_00EFB9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFAEu))return;
  // 29 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EFB0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EFB0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EFB0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFAEu,0x00EFAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB0u))return;
  // 29 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB0 BEQ -> $00EFBB
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EFBBu,0x00EFB0u); return; }
    goto L_00EFB2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB0 BEQ -> $00EFBB
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EFBBu,0x00EFB0u); return; }
    goto L_00EFB2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB0 BEQ -> $00EFBB
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EFBBu,0x00EFB0u); return; }
    goto L_00EFB2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB0u,0x00EFB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB2u))return;
  // 29 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u, 8u, 4u, 0x0294C1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EFB2 JSL -> $0294C1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEFB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFB6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0294C1u, 0x00EFB2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EFB6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u, 8u, 4u, 0x0294C1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EFB2 JSL -> $0294C1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEFB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFB6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0294C1u, 0x00EFB2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EFB6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u, 8u, 4u, 0x0294C1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EFB2 JSL -> $0294C1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEFB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFB6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0294C1u, 0x00EFB2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EFB6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB2u,0x00EFB2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB6u))return;
  // 29 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB6 LDA
    cpu.setA(0x8D09u, 16);
    goto L_00EFB9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB6 LDA
    cpu.setA(0x9u, 8);
    goto L_00EFB8;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB6 LDA
    cpu.setA(0x9u, 8);
    goto L_00EFB8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB6u,0x00EFB6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB8u))return;
  // 23 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB8u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB8 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFBBu,0x00EFB8u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB8u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB8 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFBBu,0x00EFB8u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB8u,0x00EFB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB9u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB9u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB9u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x601Du + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $00EFB9 JSR (601D,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x601Du+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0xEFBBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFBCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x00EFB9u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFBCu,0x00EFB9u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB9u,0x00EFB9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_018127_E0M1X1CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x018659u: goto L_018659;
    case 0x01865Au: goto L_01865A;
    case 0x01865Bu: goto L_01865B;
    case 0x01865Cu: goto L_01865C;
    case 0x01865Eu: goto L_01865E;
    case 0x018660u: goto L_018660;
    case 0x018662u: goto L_018662;
    case 0x018664u: goto L_018664;
    case 0x018668u: goto L_018668;
    case 0x01866Cu: goto L_01866C;
    case 0x01866Du: goto L_01866D;
    case 0x01866Fu: goto L_01866F;
    case 0x018671u: goto L_018671;
    case 0x018672u: goto L_018672;
    case 0x018674u: goto L_018674;
    case 0x018677u: goto L_018677;
    case 0x018679u: goto L_018679;
    case 0x01867Bu: goto L_01867B;
    case 0x01867Du: goto L_01867D;
    case 0x01867Fu: goto L_01867F;
    case 0x018681u: goto L_018681;
    case 0x018683u: goto L_018683;
    case 0x018685u: goto L_018685;
    case 0x018687u: goto L_018687;
    case 0x018689u: goto L_018689;
    case 0x01868Bu: goto L_01868B;
    case 0x01868Du: goto L_01868D;
    case 0x018690u: goto L_018690;
    case 0x018691u: goto L_018691;
    case 0x018693u: goto L_018693;
    case 0x018695u: goto L_018695;
    case 0x018697u: goto L_018697;
    case 0x018699u: goto L_018699;
    case 0x01869Bu: goto L_01869B;
    case 0x01869Du: goto L_01869D;
    case 0x01869Fu: goto L_01869F;
    case 0x0186A1u: goto L_0186A1;
    case 0x0186A2u: goto L_0186A2;
    case 0x0186A3u: goto L_0186A3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_018659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8659u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8659u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8659u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018659 DEY
    cpu.decReg('Y');
    goto L_01865A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8659u,0x018659u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01865A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Au))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Au,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01865A PHD
    cpu.push("PHD", hw);
    goto L_01865B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x865Au,0x01865Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01865B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01865B DEY
    cpu.decReg('Y');
    goto L_01865C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x865Bu,0x01865Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01865C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01865C BPL -> $0185E6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x0185E6u,0x01865Cu); return; }
    goto L_01865E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x865Cu,0x01865Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01865E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Eu,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01865E ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0x88u), cpu.m8?8:16));
    goto L_018660;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x865Eu,0x01865Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8660u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8660u,cpu,0x63u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8660u, 4u, 2u, cpu.addressStack(0x87u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018660 ADC
    cpu.adc(hw.readW(cpu.addressStack(0x87u), cpu.m8?8:16));
    goto L_018662;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8660u,0x018660u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018662:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8662u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8662u,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8662u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x88u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $018662 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0x88u), cpu.m8?8:16));
    goto L_018664;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8662u,0x018662u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018664:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8664u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8664u,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8664u, 5u, 4u, 0xE2CF87u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018664 CMP
    cpu.compareA(hw.readW(0xE2CF87u, cpu.m8?8:16));
    goto L_018668;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8664u,0x018664u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018668:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8668u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8668u,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8668u, 5u, 4u, 0x87BBE2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018668 CMP
    cpu.compareA(hw.readW(0x87BBE2u, cpu.m8?8:16));
    goto L_01866C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8668u,0x018668u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01866C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Cu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01866C TYX
    cpu.transfer("TYX");
    goto L_01866D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x866Cu,0x01866Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01866D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Du,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Eu) & 0xFFFFu), 3u, 0u);
    // $01866D STA
    hw.write(cpu.addressDpLong(hw, 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_01866F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x866Du,0x01866Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01866F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Fu,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x93u) & 0xFFFFu), 3u, 0u);
    // $01866F STA
    hw.write(cpu.addressDpLong(hw, 0x93u), cpu.a, cpu.m8?8:16);
    goto L_018671;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x866Fu,0x01866Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8671u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8671u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8671u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018671 DEY
    cpu.decReg('Y');
    goto L_018672;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8671u,0x018671u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018672:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8672u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8672u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8672u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018672 REP
    cpu.rep(0x85u);
    goto L_018674;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8672u,0x018672u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8674u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8674u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8674u, 4u, 3u, cpu.address("abs", 0x6CBAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018674 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x6CBAu), cpu.m8?8:16));
    goto L_018677;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8674u,0x018674u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8677u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8677u,cpu,0xB2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8677u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Cu) & 0xFFFFu), 2u, 0u);
    // $018677 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirect(hw, 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018679;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8677u,0x018677u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8679u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8679u,cpu,0xB2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8679u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Cu) & 0xFFFFu), 2u, 0u);
    // $018679 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirect(hw, 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01867B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8679u,0x018679u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01867B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu,cpu,0xB2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Cu) & 0xFFFFu), 2u, 0u);
    // $01867B LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirect(hw, 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01867D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x867Bu,0x01867Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01867D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Du,cpu,0xB2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xA5u) & 0xFFFFu), 2u, 0u);
    // $01867D LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirect(hw, 0xA5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01867F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x867Du,0x01867Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01867F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Fu,cpu,0xB6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpy", 0xDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01867F LDX
    cpu.setX(hw.readW(cpu.address("dpy", 0xDAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018681;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x867Fu,0x01867Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8681u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8681u,cpu,0xB6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8681u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpy", 0x63u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018681 LDX
    cpu.setX(hw.readW(cpu.address("dpy", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018683;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8681u,0x018681u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8683u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x63u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018683 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x63u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018685;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8683u,0x018683u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8685u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8685u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8685u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x63u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018685 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x63u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018687;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8685u,0x018685u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018687:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8687u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8687u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8687u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018687 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018689;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8687u,0x018687u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8689u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8689u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8689u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018689 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x73u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01868B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8689u,0x018689u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01868B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Bu,cpu,0xC7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x91u) & 0xFFFFu), 3u, 0u);
    // $01868B CMP
    cpu.compareA(hw.readW(cpu.addressDpLong(hw, 0x91u), cpu.m8?8:16));
    goto L_01868D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x868Bu,0x01868Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01868D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Du,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Du, 4u, 3u, cpu.address("abs", 0x87DEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01868D LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x87DEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018690;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x868Du,0x01868Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8690u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8690u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8690u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018690 LSR
    cpu.lsrA();
    goto L_018691;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8690u,0x018690u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8691u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8691u,cpu,0xD7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8691u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x4Au) & 0xFFFFu), 3u, 0u);
    // $018691 CMP
    cpu.compareA(hw.readW(cpu.addressDpLongY(hw, 0x4Au), cpu.m8?8:16));
    goto L_018693;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8691u,0x018691u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018693:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8693u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8693u,cpu,0xD7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8693u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x19u) & 0xFFFFu), 3u, 0u);
    // $018693 CMP
    cpu.compareA(hw.readW(cpu.addressDpLongY(hw, 0x19u), cpu.m8?8:16));
    goto L_018695;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8693u,0x018693u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8695u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8695u,cpu,0xD7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8695u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x19u) & 0xFFFFu), 3u, 0u);
    // $018695 CMP
    cpu.compareA(hw.readW(cpu.addressDpLongY(hw, 0x19u), cpu.m8?8:16));
    goto L_018697;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8695u,0x018695u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8697u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8697u,cpu,0xD7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8697u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x19u) & 0xFFFFu), 3u, 0u);
    // $018697 CMP
    cpu.compareA(hw.readW(cpu.addressDpLongY(hw, 0x19u), cpu.m8?8:16));
    goto L_018699;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8697u,0x018697u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8699u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8699u,cpu,0xD7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8699u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x3Au) & 0xFFFFu), 3u, 0u);
    // $018699 CMP
    cpu.compareA(hw.readW(cpu.addressDpLongY(hw, 0x3Au), cpu.m8?8:16));
    goto L_01869B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8699u,0x018699u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01869B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Bu,cpu,0xD7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x4Au) & 0xFFFFu), 3u, 0u);
    // $01869B CMP
    cpu.compareA(hw.readW(cpu.addressDpLongY(hw, 0x4Au), cpu.m8?8:16));
    goto L_01869D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x869Bu,0x01869Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01869D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Du,cpu,0xD7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xC3u) & 0xFFFFu), 3u, 0u);
    // $01869D CMP
    cpu.compareA(hw.readW(cpu.addressDpLongY(hw, 0xC3u), cpu.m8?8:16));
    goto L_01869F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x869Du,0x01869Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01869F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Fu,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x33u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01869F DEC
    cpu.decMem(hw, cpu.address("dpx", 0x33u), cpu.m8?8:16);
    goto L_0186A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x869Fu,0x01869Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0186A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A1u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0186A1 DEY
    cpu.decReg('Y');
    goto L_0186A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86A1u,0x0186A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0186A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A2u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A2u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0186A2 PHA
    cpu.push("PHA", hw);
    goto L_0186A3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86A2u,0x0186A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0186A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A3u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A3u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0186A3 DEY
    cpu.decReg('Y');
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86A4u,0x0186A3u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86A3u,0x0186A3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_019098_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019098u: goto L_019098;
    case 0x01909Bu: goto L_01909B;
    case 0x01909Du: goto L_01909D;
    case 0x01909Fu: goto L_01909F;
    case 0x0190A2u: goto L_0190A2;
    case 0x0190A4u: goto L_0190A4;
    case 0x0190A6u: goto L_0190A6;
    case 0x0190A7u: goto L_0190A7;
    case 0x0190A9u: goto L_0190A9;
    case 0x0190ACu: goto L_0190AC;
    case 0x0190AEu: goto L_0190AE;
    case 0x0190B1u: goto L_0190B1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9098u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9098u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9098u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019098 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15ACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01909B;
L_01909B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01909B BNE -> $0190B1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0190B1; }
    goto L_01909D;
L_01909D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01909D LDA
    cpu.setA(0x8u, 8);
    goto L_01909F;
L_01909F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu, 5u, 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01909F STA
    hw.write(cpu.address("absx", 0x15ACu), cpu.a, cpu.m8?8:16);
    goto L_0190A2;
L_0190A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A2u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0190A2 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0190A4;
L_0190A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A4u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0190A4 EOR
    cpu.logicXor(0xFFu);
    goto L_0190A6;
L_0190A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0190A6 INC
    cpu.inc('A');
    goto L_0190A7;
L_0190A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0190A7 STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_0190A9;
L_0190A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0190A9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0190AC;
L_0190AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0190AC EOR
    cpu.logicXor(0x1u);
    goto L_0190AE;
L_0190AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0190AE STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_0190B1;
L_0190B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0190B1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0190B1u);return;} hw.unresolvedReturn(0x0190B1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_019098_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019098u: goto L_019098;
    case 0x01909Bu: goto L_01909B;
    case 0x01909Du: goto L_01909D;
    case 0x01909Fu: goto L_01909F;
    case 0x0190A2u: goto L_0190A2;
    case 0x0190A4u: goto L_0190A4;
    case 0x0190A6u: goto L_0190A6;
    case 0x0190A7u: goto L_0190A7;
    case 0x0190A9u: goto L_0190A9;
    case 0x0190ACu: goto L_0190AC;
    case 0x0190AEu: goto L_0190AE;
    case 0x0190B1u: goto L_0190B1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9098u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9098u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9098u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019098 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15ACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01909B;
L_01909B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01909B BNE -> $0190B1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0190B1; }
    goto L_01909D;
L_01909D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01909D LDA
    cpu.setA(0x8u, 8);
    goto L_01909F;
L_01909F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu, 5u, 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01909F STA
    hw.write(cpu.address("absx", 0x15ACu), cpu.a, cpu.m8?8:16);
    goto L_0190A2;
L_0190A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A2u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0190A2 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0190A4;
L_0190A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A4u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0190A4 EOR
    cpu.logicXor(0xFFu);
    goto L_0190A6;
L_0190A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0190A6 INC
    cpu.inc('A');
    goto L_0190A7;
L_0190A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0190A7 STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_0190A9;
L_0190A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0190A9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0190AC;
L_0190AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0190AC EOR
    cpu.logicXor(0x1u);
    goto L_0190AE;
L_0190AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0190AE STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_0190B1;
L_0190B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0190B1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0190B1u);return;} hw.unresolvedReturn(0x0190B1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0190B2_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0190B2u: goto L_0190B2;
    case 0x0190B3u: goto L_0190B3;
    case 0x0190B4u: goto L_0190B4;
    case 0x0190B5u: goto L_0190B5;
    case 0x0190B8u: goto L_0190B8;
    case 0x0190B9u: goto L_0190B9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0190B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B2u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0190B2 PHB
    cpu.push("PHB", hw);
    goto L_0190B3;
L_0190B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0190B3 PHK
    cpu.push("PHK", hw);
    goto L_0190B4;
L_0190B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B4u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0190B4 PLB
    cpu.pop("PLB", hw);
    goto L_0190B5;
L_0190B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B5u, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0190B5 JSR -> $019F0D stack real
    { cpu.push16Value(hw,0x90B7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90B8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0x0190B5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0190B8;
L_0190B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90B8u,0x0190B8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B8u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0190B8 PLB
    cpu.pop("PLB", hw);
    goto L_0190B9;
L_0190B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0190B9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x0190B9u);return;} hw.unresolvedReturn(0x0190B9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_029BE4_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x029BE4u: goto L_029BE4;
    case 0x029BE6u: goto L_029BE6;
    case 0x029BE9u: goto L_029BE9;
    case 0x029BEBu: goto L_029BEB;
    case 0x029BEEu: goto L_029BEE;
    case 0x029BF0u: goto L_029BF0;
    case 0x029BF3u: goto L_029BF3;
    case 0x029BF5u: goto L_029BF5;
    case 0x029BF7u: goto L_029BF7;
    case 0x029BFAu: goto L_029BFA;
    case 0x029BFCu: goto L_029BFC;
    case 0x029BFDu: goto L_029BFD;
    case 0x029BFFu: goto L_029BFF;
    case 0x029C00u: goto L_029C00;
    case 0x029C02u: goto L_029C02;
    case 0x029C05u: goto L_029C05;
    case 0x029C07u: goto L_029C07;
    case 0x029C08u: goto L_029C08;
    case 0x029C0Au: goto L_029C0A;
    case 0x029C0Du: goto L_029C0D;
    case 0x029C0Fu: goto L_029C0F;
    case 0x029C11u: goto L_029C11;
    case 0x029C14u: goto L_029C14;
    case 0x029C16u: goto L_029C16;
    case 0x029C18u: goto L_029C18;
    case 0x029C19u: goto L_029C19;
    case 0x029C1Cu: goto L_029C1C;
    case 0x029C1Fu: goto L_029C1F;
    case 0x029C21u: goto L_029C21;
    case 0x029C24u: goto L_029C24;
    case 0x029C27u: goto L_029C27;
    case 0x029C2Au: goto L_029C2A;
    case 0x029C2Du: goto L_029C2D;
    case 0x029C2Fu: goto L_029C2F;
    case 0x029C32u: goto L_029C32;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_029BE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BE4 LDA
    cpu.setA(0x5u, 8);
    goto L_029BE6;
L_029BE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE6u, 4u, 3u, cpu.address("abs", 0x1887u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BE6 STA
    hw.write(cpu.address("abs", 0x1887u), cpu.a, cpu.m8?8:16);
    goto L_029BE9;
L_029BE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BE9 LDA
    cpu.setA(0x9u, 8);
    goto L_029BEB;
L_029BEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEBu, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BEB STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_029BEE;
L_029BEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BEE STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_029BF0;
L_029BF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF0u, 6u, 3u, cpu.address("abs", 0x9BF5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $029BF0 JSR -> $029BF5 stack real
    { cpu.push16Value(hw,0x9BF2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9BF3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9BF5u), 0x029BF0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_029BF3;
L_029BF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF3u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BF3u,0x029BF3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF3u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BF3 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_029BF5;
L_029BF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BF5 LDY
    cpu.setY(0x7u, 8);
    goto L_029BF7;
L_029BF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF7u, 4u + ((((0x170Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BF7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x170Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029BFA;
L_029BFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BFA BEQ -> $029C00
    if (cpu.z) { hw.addCpuInternalCycles(2u); goto L_029C00; }
    goto L_029BFC;
L_029BFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFCu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BFC DEY
    cpu.decReg('Y');
    goto L_029BFD;
L_029BFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFDu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029BFD BPL -> $029BF7
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_029BF7; }
    goto L_029BFF;
L_029BFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $029BFF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x029BFFu);return;} hw.unresolvedReturn(0x029BFFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_029C00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C00u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C00 LDA
    cpu.setA(0xFu, 8);
    goto L_029C02;
L_029C02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C02u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C02u, 5u, 3u, cpu.address("absy", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C02 STA
    hw.write(cpu.address("absy", 0x170Bu), cpu.a, cpu.m8?8:16);
    goto L_029C05;
L_029C05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C05u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C05u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C05 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029C07;
L_029C07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C07u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C07 CLC
    cpu.setFlag('C', false);
    goto L_029C08;
L_029C08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C08u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C08 ADC
    cpu.adc(0x28u);
    goto L_029C0A;
L_029C0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Au, 5u, 3u, cpu.address("absy", 0x1715u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C0A STA
    hw.write(cpu.address("absy", 0x1715u), cpu.a, cpu.m8?8:16);
    goto L_029C0D;
L_029C0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C0D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029C0F;
L_029C0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C0F ADC
    cpu.adc(0x0u);
    goto L_029C11;
L_029C11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C11u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C11u, 5u, 3u, cpu.address("absy", 0x1729u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C11 STA
    hw.write(cpu.address("absy", 0x1729u), cpu.a, cpu.m8?8:16);
    goto L_029C14;
L_029C14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C14u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C14u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C14 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_029C16;
L_029C16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C16u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C16u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C16 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029C18;
L_029C18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C18u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C18 CLC
    cpu.setFlag('C', false);
    goto L_029C19;
L_029C19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C19u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C19u, 4u + ((((0x9BDEu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9BDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C19 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x9BDEu), cpu.m8?8:16));
    goto L_029C1C;
L_029C1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Cu, 5u, 3u, cpu.address("absy", 0x171Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C1C STA
    hw.write(cpu.address("absy", 0x171Fu), cpu.a, cpu.m8?8:16);
    goto L_029C1F;
L_029C1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029C21;
L_029C21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C21u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C21u, 4u + ((((0x9BE0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9BE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C21 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x9BE0u), cpu.m8?8:16));
    goto L_029C24;
L_029C24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u, 5u, 3u, cpu.address("absy", 0x1733u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C24 STA
    hw.write(cpu.address("absy", 0x1733u), cpu.a, cpu.m8?8:16);
    goto L_029C27;
L_029C27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C27u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C27u, 4u + ((((0x9BE2u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9BE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C27 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9BE2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_029C2A;
L_029C2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Au, 5u, 3u, cpu.address("absy", 0x1747u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C2A STA
    hw.write(cpu.address("absy", 0x1747u), cpu.a, cpu.m8?8:16);
    goto L_029C2D;
L_029C2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C2D LDA
    cpu.setA(0x15u, 8);
    goto L_029C2F;
L_029C2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Fu, 5u, 3u, cpu.address("absy", 0x176Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029C2F STA
    hw.write(cpu.address("absy", 0x176Fu), cpu.a, cpu.m8?8:16);
    goto L_029C32;
L_029C32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C32u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C32u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $029C32 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x029C32u);return;} hw.unresolvedReturn(0x029C32u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_03C816_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x03C7D5u: goto L_03C7D5;
    case 0x03C7D8u: goto L_03C7D8;
    case 0x03C7DBu: goto L_03C7DB;
    case 0x03C816u: goto L_03C816;
    case 0x03C818u: goto L_03C818;
    case 0x03C81Cu: goto L_03C81C;
    case 0x03C81Du: goto L_03C81D;
    case 0x03C81Eu: goto L_03C81E;
    case 0x03C820u: goto L_03C820;
    case 0x03C823u: goto L_03C823;
    case 0x03C825u: goto L_03C825;
    case 0x03C826u: goto L_03C826;
    case 0x03C827u: goto L_03C827;
    case 0x03C828u: goto L_03C828;
    case 0x03C829u: goto L_03C829;
    case 0x03C82Bu: goto L_03C82B;
    case 0x03C82Eu: goto L_03C82E;
    case 0x03C830u: goto L_03C830;
    case 0x03C832u: goto L_03C832;
    case 0x03C833u: goto L_03C833;
    case 0x03C835u: goto L_03C835;
    case 0x03C836u: goto L_03C836;
    case 0x03C837u: goto L_03C837;
    case 0x03C838u: goto L_03C838;
    case 0x03C83Au: goto L_03C83A;
    case 0x03C83Cu: goto L_03C83C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_03C7D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C7D5 LDA
    cpu.setA(0x997Au, 16);
    goto L_03C7D8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C7D5 LDA
    cpu.setA(0x997Au, 16);
    goto L_03C7D8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7D5u,0x03C7D5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D8u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D8u, 6u, 3u, cpu.address("absx", 0xA900u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C7D8 STZ
    hw.write(cpu.address("absx", 0xA900u), 0, cpu.m8?8:16);
    goto L_03C7DB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D8u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D8u, 6u, 3u, cpu.address("absx", 0xA900u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C7D8 STZ
    hw.write(cpu.address("absx", 0xA900u), 0, cpu.m8?8:16);
    goto L_03C7DB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7D8u,0x03C7D8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C7DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7DBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DBu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DBu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $03C7DB BRK
    hw.partial(0x03C7DBu, "BRK"); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DBu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DBu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $03C7DB BRK
    hw.partial(0x03C7DBu, "BRK"); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7DBu,0x03C7DBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC816u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC816u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C816 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C818;
L_03C818:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC818u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC818u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC818u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $03C818 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC81Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC81Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x03C818u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_03C81C;
L_03C81C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC81Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC81Cu,0x03C81Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Cu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $03C81C PLP
    cpu.pop("PLP", hw);
    goto L_03C81D;
L_03C81D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC81Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C81D INY
    cpu.inc('Y');
    goto L_03C81E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C81D INY
    cpu.inc('Y');
    goto L_03C81E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C81D INY
    cpu.inc('Y');
    goto L_03C81E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C81D INY
    cpu.inc('Y');
    goto L_03C81E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC81Du,0x03C81Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C81E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC81Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Eu,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C81E EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0xC8u), cpu.m8?8:16));
    goto L_03C820;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Eu,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C81E EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0xC8u), cpu.m8?8:16));
    goto L_03C820;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Eu,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C81E EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0xC8u), cpu.m8?8:16));
    goto L_03C820;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Eu,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C81E EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0xC8u), cpu.m8?8:16));
    goto L_03C820;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC81Eu,0x03C81Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC820u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC820u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC820u, 5u, 3u, cpu.address("abs", 0x41C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C820 STA
    hw.write(cpu.address("abs", 0x41C8u), cpu.a, cpu.m8?8:16);
    goto L_03C823;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC820u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC820u, 5u, 3u, cpu.address("abs", 0x41C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C820 STA
    hw.write(cpu.address("abs", 0x41C8u), cpu.a, cpu.m8?8:16);
    goto L_03C823;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC820u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC820u, 4u, 3u, cpu.address("abs", 0x41C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C820 STA
    hw.write(cpu.address("abs", 0x41C8u), cpu.a, cpu.m8?8:16);
    goto L_03C823;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC820u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC820u, 4u, 3u, cpu.address("abs", 0x41C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C820 STA
    hw.write(cpu.address("abs", 0x41C8u), cpu.a, cpu.m8?8:16);
    goto L_03C823;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC820u,0x03C820u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC823u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC823u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC823u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C823 CMP
    cpu.compareA(0xE6E4u);
    goto L_03C826;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC823u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC823u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C823 CMP
    cpu.compareA(0xE6E4u);
    goto L_03C826;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC823u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC823u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C823 CMP
    cpu.compareA(0xE4u);
    goto L_03C825;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC823u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC823u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C823 CMP
    cpu.compareA(0xE4u);
    goto L_03C825;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC823u,0x03C823u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC825u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC825u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC825u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C825 INC
    cpu.incMem(hw, cpu.address("dp", 0xE4u), cpu.m8?8:16);
    goto L_03C827;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC825u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC825u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C825 INC
    cpu.incMem(hw, cpu.address("dp", 0xE4u), cpu.m8?8:16);
    goto L_03C827;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC825u,0x03C825u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC826u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC826u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC826u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C826 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0xE2u), cpu.x8?8:16));
    goto L_03C828;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC826u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC826u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C826 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0xE2u), cpu.x8?8:16));
    goto L_03C828;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC826u,0x03C826u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC827u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC827u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC827u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C827 SEP
    cpu.sep(0xBCu);
    goto L_03C829;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC827u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC827u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C827 SEP
    cpu.sep(0xBCu);
    goto L_03C829;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC827u,0x03C827u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C828:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC828u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC828u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC828u, 5u + 1u, 3u, cpu.address("absx", 0x1534u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C828 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1534u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_03C82B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC828u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC828u, 4u + ((((0x1534u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C828 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1534u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_03C82B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC828u,0x03C828u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C829:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC829u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC829u,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC829u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C829 BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0x15u), cpu.m8?8:16), false);
    goto L_03C82B;
L_03C82B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC82Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Bu, 5u + 1u, 3u, cpu.address("absy", 0xC824u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C82B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xC824u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C82E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Bu, 5u + ((((0xC824u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xC824u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C82B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xC824u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C82E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Bu, 4u + ((((0xC824u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xC824u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C82B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xC824u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03C82E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC82Bu,0x03C82Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C82E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC82Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C82E STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_03C830;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C82E STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_03C830;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C82E STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_03C830;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC82Eu,0x03C82Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC830u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC830u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC830u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C830 LDA
    cpu.setA(0x8D25u, 16);
    goto L_03C833;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC830u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC830u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C830 LDA
    cpu.setA(0x8D25u, 16);
    goto L_03C833;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC830u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC830u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C830 LDA
    cpu.setA(0x25u, 8);
    goto L_03C832;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC830u,0x03C830u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC832u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC832u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C832 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_03C835;
L_03C833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC833u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC833u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC833u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xA91Du + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $03C833 JSR (A91D,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xA91Du+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0xC835u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC836u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x03C833u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_03C836;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC833u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC833u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xA91Du + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $03C833 JSR (A91D,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xA91Du+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0xC835u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC836u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x03C833u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_03C836;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC833u,0x03C833u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C835:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC835u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC835u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC835u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C835 LDA
    cpu.setA(0x10u, 8);
    goto L_03C837;
L_03C836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC836u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC836u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC836u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C836 BPL -> $03C7D5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_03C7D5; }
    goto L_03C838;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC836u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC836u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C836 BPL -> $03C7D5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_03C7D5; }
    goto L_03C838;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC836u,0x03C836u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC837u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC837u, 5u, 3u, cpu.address("absx", 0x1564u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C837 STA
    hw.write(cpu.address("absx", 0x1564u), cpu.a, cpu.m8?8:16);
    goto L_03C83A;
L_03C838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC838u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC838u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC838u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C838 STZ
    hw.write(cpu.address("dp", 0x15u), 0, cpu.m8?8:16);
    goto L_03C83A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC838u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC838u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C838 STZ
    hw.write(cpu.address("dp", 0x15u), 0, cpu.m8?8:16);
    goto L_03C83A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC838u,0x03C838u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C83A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC83Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Au,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Au, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C83A INC
    cpu.incMem(hw, cpu.address("dpx", 0xC2u), cpu.m8?8:16);
    goto L_03C83C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Au,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Au, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C83A INC
    cpu.incMem(hw, cpu.address("dpx", 0xC2u), cpu.m8?8:16);
    goto L_03C83C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Au,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C83A INC
    cpu.incMem(hw, cpu.address("dpx", 0xC2u), cpu.m8?8:16);
    goto L_03C83C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC83Au,0x03C83Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_03C83C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC83Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $03C83C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x03C83Cu);return;} hw.unresolvedReturn(0x03C83Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $03C83C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x03C83Cu);return;} hw.unresolvedReturn(0x03C83Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $03C83C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x03C83Cu);return;} hw.unresolvedReturn(0x03C83Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC83Cu,0x03C83Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_048576_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x048576u: goto L_048576;
    case 0x048579u: goto L_048579;
    case 0x04857Du: goto L_04857D;
    case 0x04857Fu: goto L_04857F;
    case 0x048581u: goto L_048581;
    case 0x048583u: goto L_048583;
    case 0x048585u: goto L_048585;
    case 0x048587u: goto L_048587;
    case 0x048589u: goto L_048589;
    case 0x04858Cu: goto L_04858C;
    case 0x04858Du: goto L_04858D;
    case 0x048590u: goto L_048590;
    case 0x048593u: goto L_048593;
    case 0x048596u: goto L_048596;
    case 0x048599u: goto L_048599;
    case 0x04859Cu: goto L_04859C;
    case 0x04859Du: goto L_04859D;
    case 0x04859Fu: goto L_04859F;
    case 0x0485A2u: goto L_0485A2;
    case 0x0485A3u: goto L_0485A3;
    case 0x0485A5u: goto L_0485A5;
    case 0x0485A8u: goto L_0485A8;
    case 0x0485ABu: goto L_0485AB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_048576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8576u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8576u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048576 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13D9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048579;
L_048579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8579u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8579u, 8u, 4u, 0x0086FAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $048579 JSL -> $0086FA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x857Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x857Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086FAu, 0x048579u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04857D;
L_04857D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x857Du,0x04857Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Du,cpu,0xF1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Eu) & 0xFFFFu), 2u, 0u);
    // $04857D SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectY(hw, 0x8Eu), cpu.m8?8:16));
    goto L_04857F;
L_04857F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Fu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x70u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04857F TSB
    cpu.tsb(hw, cpu.address("dp", 0x70u), cpu.m8?8:16);
    goto L_048581;
L_048581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8581u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8581u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048581 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_048583;
L_048583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8583u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8583u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8583u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Fu) & 0xFFFFu), 3u, 0u);
    // $048583 STA
    hw.write(cpu.addressDpLong(hw, 0x8Fu), cpu.a, cpu.m8?8:16);
    goto L_048585;
L_048585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8585u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8585u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8585u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048585 TSB
    cpu.tsb(hw, cpu.address("dp", 0x20u), cpu.m8?8:16);
    goto L_048587;
L_048587:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8587u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8587u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8587u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 2u, 0u);
    // $048587 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x4u), cpu.a, cpu.m8?8:16);
    goto L_048589;
L_048589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8589u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8589u,cpu,0x5Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8589u, 4u + ((((0x0494u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0494u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048589 EOR
    cpu.logicXor(hw.readW(cpu.address("absx", 0x494u), cpu.m8?8:16));
    goto L_04858C;
L_04858C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Cu,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04858C TXS
    cpu.transfer("TXS");
    goto L_04858D;
L_04858D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Du, 5u, 3u, cpu.address("absx", 0x2204u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04858D STA
    hw.write(cpu.address("absx", 0x2204u), cpu.a, cpu.m8?8:16);
    goto L_048590;
L_048590:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8590u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8590u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8590u, 5u, 3u, cpu.address("absx", 0xD104u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048590 STZ
    hw.write(cpu.address("absx", 0xD104u), 0, cpu.m8?8:16);
    goto L_048593;
L_048593:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8593u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8593u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8593u, 5u, 3u, cpu.address("absx", 0x2204u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048593 STA
    hw.write(cpu.address("absx", 0x2204u), cpu.a, cpu.m8?8:16);
    goto L_048596;
L_048596:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8596u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8596u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8596u, 5u, 3u, cpu.address("absx", 0x4C04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048596 STZ
    hw.write(cpu.address("absx", 0x4C04u), 0, cpu.m8?8:16);
    goto L_048599;
L_048599:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8599u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8599u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8599u, 5u, 3u, cpu.address("absx", 0xEF04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048599 STZ
    hw.write(cpu.address("absx", 0xEF04u), 0, cpu.m8?8:16);
    goto L_04859C;
L_04859C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x859Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x859Cu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x859Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04859C PHX
    cpu.push("PHX", hw);
    goto L_04859D;
L_04859D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x859Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x859Du,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x859Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04859D TSB
    cpu.tsb(hw, cpu.address("dp", 0x52u), cpu.m8?8:16);
    goto L_04859F;
L_04859F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x859Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x859Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x859Fu, 5u, 3u, cpu.address("absx", 0xC604u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04859F STZ
    hw.write(cpu.address("absx", 0xC604u), 0, cpu.m8?8:16);
    goto L_0485A2;
L_0485A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A2u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0485A2 TYA
    cpu.transfer("TYA");
    goto L_0485A3;
L_0485A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A3u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0485A3 TSB
    cpu.tsb(hw, cpu.address("dp", 0x20u), cpu.m8?8:16);
    goto L_0485A5;
L_0485A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A5u,cpu,0x2Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A5u, 6u, 3u, cpu.address("abs", 0xC286u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0485A5 ROL
    cpu.rolMem(hw, cpu.address("abs", 0xC286u), cpu.m8?8:16);
    goto L_0485A8;
L_0485A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A8u, 6u, 3u, cpu.address("abs", 0x1EA9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0485A8 JSR -> $041EA9 stack real
    { cpu.push16Value(hw,0x85AAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x85ABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x1EA9u), 0x0485A8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0485AB;
L_0485AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85ABu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85ABu,0x0485ABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85ABu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85ABu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0485AB BRK
    hw.partial(0x0485ABu, "BRK"); return;
}

void sub_048576_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x048576u: goto L_048576;
    case 0x048579u: goto L_048579;
    case 0x04857Du: goto L_04857D;
    case 0x04857Fu: goto L_04857F;
    case 0x048581u: goto L_048581;
    case 0x048583u: goto L_048583;
    case 0x048585u: goto L_048585;
    case 0x048587u: goto L_048587;
    case 0x048589u: goto L_048589;
    case 0x04858Cu: goto L_04858C;
    case 0x04858Du: goto L_04858D;
    case 0x048590u: goto L_048590;
    case 0x048593u: goto L_048593;
    case 0x048596u: goto L_048596;
    case 0x048599u: goto L_048599;
    case 0x04859Cu: goto L_04859C;
    case 0x04859Du: goto L_04859D;
    case 0x04859Fu: goto L_04859F;
    case 0x0485A2u: goto L_0485A2;
    case 0x0485A3u: goto L_0485A3;
    case 0x0485A5u: goto L_0485A5;
    case 0x0485A8u: goto L_0485A8;
    case 0x0485ABu: goto L_0485AB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_048576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8576u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8576u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048576 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13D9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048579;
L_048579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8579u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8579u, 8u, 4u, 0x0086FAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $048579 JSL -> $0086FA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x857Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x857Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086FAu, 0x048579u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04857D;
L_04857D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x857Du,0x04857Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Du,cpu,0xF1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Eu) & 0xFFFFu), 2u, 0u);
    // $04857D SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectY(hw, 0x8Eu), cpu.m8?8:16));
    goto L_04857F;
L_04857F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Fu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x70u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04857F TSB
    cpu.tsb(hw, cpu.address("dp", 0x70u), cpu.m8?8:16);
    goto L_048581;
L_048581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8581u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8581u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048581 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_048583;
L_048583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8583u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8583u,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8583u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Fu) & 0xFFFFu), 3u, 0u);
    // $048583 STA
    hw.write(cpu.addressDpLong(hw, 0x8Fu), cpu.a, cpu.m8?8:16);
    goto L_048585;
L_048585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8585u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8585u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8585u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048585 TSB
    cpu.tsb(hw, cpu.address("dp", 0x20u), cpu.m8?8:16);
    goto L_048587;
L_048587:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8587u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8587u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8587u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 2u, 0u);
    // $048587 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x4u), cpu.a, cpu.m8?8:16);
    goto L_048589;
L_048589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8589u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8589u,cpu,0x5Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8589u, 4u + ((((0x0494u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0494u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048589 EOR
    cpu.logicXor(hw.readW(cpu.address("absx", 0x494u), cpu.m8?8:16));
    goto L_04858C;
L_04858C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Cu,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04858C TXS
    cpu.transfer("TXS");
    goto L_04858D;
L_04858D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Du, 5u, 3u, cpu.address("absx", 0x2204u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04858D STA
    hw.write(cpu.address("absx", 0x2204u), cpu.a, cpu.m8?8:16);
    goto L_048590;
L_048590:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8590u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8590u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8590u, 5u, 3u, cpu.address("absx", 0xD104u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048590 STZ
    hw.write(cpu.address("absx", 0xD104u), 0, cpu.m8?8:16);
    goto L_048593;
L_048593:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8593u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8593u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8593u, 5u, 3u, cpu.address("absx", 0x2204u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048593 STA
    hw.write(cpu.address("absx", 0x2204u), cpu.a, cpu.m8?8:16);
    goto L_048596;
L_048596:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8596u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8596u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8596u, 5u, 3u, cpu.address("absx", 0x4C04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048596 STZ
    hw.write(cpu.address("absx", 0x4C04u), 0, cpu.m8?8:16);
    goto L_048599;
L_048599:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8599u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8599u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8599u, 5u, 3u, cpu.address("absx", 0xEF04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048599 STZ
    hw.write(cpu.address("absx", 0xEF04u), 0, cpu.m8?8:16);
    goto L_04859C;
L_04859C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x859Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x859Cu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x859Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04859C PHX
    cpu.push("PHX", hw);
    goto L_04859D;
L_04859D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x859Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x859Du,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x859Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04859D TSB
    cpu.tsb(hw, cpu.address("dp", 0x52u), cpu.m8?8:16);
    goto L_04859F;
L_04859F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x859Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x859Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x859Fu, 5u, 3u, cpu.address("absx", 0xC604u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04859F STZ
    hw.write(cpu.address("absx", 0xC604u), 0, cpu.m8?8:16);
    goto L_0485A2;
L_0485A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A2u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0485A2 TYA
    cpu.transfer("TYA");
    goto L_0485A3;
L_0485A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A3u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0485A3 TSB
    cpu.tsb(hw, cpu.address("dp", 0x20u), cpu.m8?8:16);
    goto L_0485A5;
L_0485A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A5u,cpu,0x2Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A5u, 6u, 3u, cpu.address("abs", 0xC286u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0485A5 ROL
    cpu.rolMem(hw, cpu.address("abs", 0xC286u), cpu.m8?8:16);
    goto L_0485A8;
L_0485A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A8u, 6u, 3u, cpu.address("abs", 0x1EA9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0485A8 JSR -> $041EA9 stack real
    { cpu.push16Value(hw,0x85AAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x85ABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x1EA9u), 0x0485A8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0485AB;
L_0485AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85ABu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85ABu,0x0485ABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85ABu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85ABu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0485AB BRK
    hw.partial(0x0485ABu, "BRK"); return;
}

void sub_05809E_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05809Eu: goto L_05809E;
    case 0x05809Fu: goto L_05809F;
    case 0x0580A1u: goto L_0580A1;
    case 0x0580A4u: goto L_0580A4;
    case 0x0580A6u: goto L_0580A6;
    case 0x0580A9u: goto L_0580A9;
    case 0x0580ABu: goto L_0580AB;
    case 0x0580ADu: goto L_0580AD;
    case 0x0580B0u: goto L_0580B0;
    case 0x0580B2u: goto L_0580B2;
    case 0x0580B4u: goto L_0580B4;
    case 0x0580B6u: goto L_0580B6;
    case 0x0580B8u: goto L_0580B8;
    case 0x0580BBu: goto L_0580BB;
    case 0x0580BDu: goto L_0580BD;
    case 0x0580BFu: goto L_0580BF;
    case 0x0580C3u: goto L_0580C3;
    case 0x0580C7u: goto L_0580C7;
    case 0x0580CBu: goto L_0580CB;
    case 0x0580CDu: goto L_0580CD;
    case 0x0580CFu: goto L_0580CF;
    case 0x0580D1u: goto L_0580D1;
    case 0x0580D3u: goto L_0580D3;
    case 0x0580D5u: goto L_0580D5;
    case 0x0580D6u: goto L_0580D6;
    case 0x0580D7u: goto L_0580D7;
    case 0x0580D8u: goto L_0580D8;
    case 0x0580DAu: goto L_0580DA;
    case 0x0580DDu: goto L_0580DD;
    case 0x0580DEu: goto L_0580DE;
    case 0x0580E1u: goto L_0580E1;
    case 0x0580E2u: goto L_0580E2;
    case 0x0580E3u: goto L_0580E3;
    case 0x0580E6u: goto L_0580E6;
    case 0x0580E8u: goto L_0580E8;
    case 0x0580ECu: goto L_0580EC;
    case 0x0580EFu: goto L_0580EF;
    case 0x0580F0u: goto L_0580F0;
    case 0x0580F1u: goto L_0580F1;
    case 0x0580F2u: goto L_0580F2;
    case 0x0580F5u: goto L_0580F5;
    case 0x0580F7u: goto L_0580F7;
    case 0x0580F9u: goto L_0580F9;
    case 0x0580FBu: goto L_0580FB;
    case 0x0580FEu: goto L_0580FE;
    case 0x058101u: goto L_058101;
    case 0x058103u: goto L_058103;
    case 0x058105u: goto L_058105;
    case 0x058108u: goto L_058108;
    case 0x05810Bu: goto L_05810B;
    case 0x05810Eu: goto L_05810E;
    case 0x058111u: goto L_058111;
    case 0x058114u: goto L_058114;
    case 0x058117u: goto L_058117;
    case 0x058119u: goto L_058119;
    case 0x05811Cu: goto L_05811C;
    case 0x05811Eu: goto L_05811E;
    case 0x058120u: goto L_058120;
    case 0x058122u: goto L_058122;
    case 0x058124u: goto L_058124;
    case 0x058125u: goto L_058125;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05809E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Eu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05809E PHP
    cpu.push("PHP", hw);
    goto L_05809F;
L_05809F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05809F SEP
    cpu.sep(0x20u);
    goto L_0580A1;
L_0580A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u, 4u, 3u, cpu.address("abs", 0x1928u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580A1 STZ
    hw.write(cpu.address("abs", 0x1928u), 0, cpu.m8?8:16);
    goto L_0580A4;
L_0580A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580A4 REP
    cpu.rep(0x30u);
    goto L_0580A6;
L_0580A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580A6 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_0580A9;
L_0580A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580A9 STA
    hw.write(cpu.address("dp", 0x4Du), cpu.a, cpu.m8?8:16);
    goto L_0580AB;
L_0580AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ABu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580AB STA
    hw.write(cpu.address("dp", 0x4Fu), cpu.a, cpu.m8?8:16);
    goto L_0580AD;
L_0580AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu, 6u, 3u, cpu.address("abs", 0x877Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0580AD JSR -> $05877E stack real
    { cpu.push16Value(hw,0x80AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80B0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x877Eu), 0x0580ADu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580B0;
L_0580B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80B0u,0x0580B0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x45u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580B0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580B2;
L_0580B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580B2 STA
    hw.write(cpu.address("dp", 0x47u), cpu.a, cpu.m8?8:16);
    goto L_0580B4;
L_0580B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580B4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580B6;
L_0580B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580B6 STA
    hw.write(cpu.address("dp", 0x4Bu), cpu.a, cpu.m8?8:16);
    goto L_0580B8;
L_0580B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580B8 LDA
    cpu.setA(0x202u, 16);
    goto L_0580BB;
L_0580BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x55u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580BB STA
    hw.write(cpu.address("dp", 0x55u), cpu.a, cpu.m8?8:16);
    goto L_0580BD;
L_0580BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580BD REP
    cpu.rep(0x30u);
    goto L_0580BF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580BD REP
    cpu.rep(0x30u);
    goto L_0580BF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80BDu,0x0580BDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu, 8u, 4u, 0x0588ECu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580BF JSL -> $0588EC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0588ECu, 0x0580BFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580C3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu, 8u, 4u, 0x0588ECu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580BF JSL -> $0588EC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0588ECu, 0x0580BFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580C3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80BFu,0x0580BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u, 8u, 4u, 0x058955u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580C3 JSL -> $058955 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x058955u, 0x0580C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580C7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u, 8u, 4u, 0x058955u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580C3 JSL -> $058955 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x058955u, 0x0580C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580C7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80C3u,0x0580C3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u, 8u, 4u, 0x0087ADu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580C7 JSL -> $0087AD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80CAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80CBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0087ADu, 0x0580C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580CB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u, 8u, 4u, 0x0087ADu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580C7 JSL -> $0087AD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80CAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80CBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0087ADu, 0x0580C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580CB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80C7u,0x0580C7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CB REP
    cpu.rep(0x30u);
    goto L_0580CD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CB REP
    cpu.rep(0x30u);
    goto L_0580CD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80CBu,0x0580CBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CD INC
    cpu.incMem(hw, cpu.address("dp", 0x47u), cpu.m8?8:16);
    goto L_0580CF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CD INC
    cpu.incMem(hw, cpu.address("dp", 0x47u), cpu.m8?8:16);
    goto L_0580CF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80CDu,0x0580CDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CF INC
    cpu.incMem(hw, cpu.address("dp", 0x4Bu), cpu.m8?8:16);
    goto L_0580D1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CF INC
    cpu.incMem(hw, cpu.address("dp", 0x4Bu), cpu.m8?8:16);
    goto L_0580D1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80CFu,0x0580CFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D1 SEP
    cpu.sep(0x30u);
    goto L_0580D3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D1 SEP
    cpu.sep(0x30u);
    goto L_0580D3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80D1u,0x0580D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x47u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580D5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x47u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580D5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80D3u,0x0580D3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D5 LSR
    cpu.lsrA();
    goto L_0580D6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D5 LSR
    cpu.lsrA();
    goto L_0580D6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80D5u,0x0580D5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D6 LSR
    cpu.lsrA();
    goto L_0580D7;
L_0580D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D7 LSR
    cpu.lsrA();
    goto L_0580D8;
L_0580D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D8 REP
    cpu.rep(0x30u);
    goto L_0580DA;
L_0580DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580DA AND
    cpu.logicAnd(0x6u);
    goto L_0580DD;
L_0580DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580DD TAX
    cpu.transfer("TAX");
    goto L_0580DE;
L_0580DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580DE LDA
    cpu.setA(0x133u, 16);
    goto L_0580E1;
L_0580E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E1 ASL
    cpu.aslA();
    goto L_0580E2;
L_0580E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E2 TAY
    cpu.transfer("TAY");
    goto L_0580E3;
L_0580E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E3 LDA
    cpu.setA(0x7u, 16);
    goto L_0580E6;
L_0580E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E6 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0580E8;
L_0580E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u, 6u, 4u, ((0x058776u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E8 LDA
    cpu.loadA(hw.readW(((0x58776u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580EC;
L_0580EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu, 6u, 3u, cpu.address("absy", 0x0FBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580EC STA
    hw.write(cpu.address("absy", 0xFBEu), cpu.a, cpu.m8?8:16);
    goto L_0580EF;
L_0580EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580EF INY
    cpu.inc('Y');
    goto L_0580F0;
L_0580F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F0u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F0 INY
    cpu.inc('Y');
    goto L_0580F1;
L_0580F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F1 CLC
    cpu.setFlag('C', false);
    goto L_0580F2;
L_0580F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F2 ADC
    cpu.adc(0x8u);
    goto L_0580F5;
L_0580F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F5 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0580F7;
L_0580F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F7 BPL -> $0580EC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0580EC; }
    goto L_0580F9;
L_0580F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F9 SEP
    cpu.sep(0x20u);
    goto L_0580FB;
L_0580FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu, 6u, 3u, cpu.address("abs", 0x1928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580FB INC
    cpu.incMem(hw, cpu.address("abs", 0x1928u), cpu.m8?8:16);
    goto L_0580FE;
L_0580FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu, 4u, 3u, cpu.address("abs", 0x1928u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1928u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058101;
L_058101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058101 CMP
    cpu.compareA(0x20u);
    goto L_058103;
L_058103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058103 BNE -> $0580BD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0580BD; }
    goto L_058105;
L_058105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u, 4u, 3u, cpu.address("abs", 0x0D9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058105 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058108;
L_058108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8108u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8108u, 4u, 3u, cpu.address("abs", 0x212Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058108 STA
    hw.write(cpu.address("abs", 0x212Cu), cpu.a, cpu.m8?8:16);
    goto L_05810B;
L_05810B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Bu, 4u, 3u, cpu.address("abs", 0x212Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05810B STA
    hw.write(cpu.address("abs", 0x212Eu), cpu.a, cpu.m8?8:16);
    goto L_05810E;
L_05810E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu, 4u, 3u, cpu.address("abs", 0x0D9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05810E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058111;
L_058111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u, 4u, 3u, cpu.address("abs", 0x212Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058111 STA
    hw.write(cpu.address("abs", 0x212Du), cpu.a, cpu.m8?8:16);
    goto L_058114;
L_058114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u, 4u, 3u, cpu.address("abs", 0x212Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058114 STA
    hw.write(cpu.address("abs", 0x212Fu), cpu.a, cpu.m8?8:16);
    goto L_058117;
L_058117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8117u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8117u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058117 REP
    cpu.rep(0x20u);
    goto L_058119;
L_058119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058119 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_05811C;
L_05811C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05811C STA
    hw.write(cpu.address("dp", 0x4Du), cpu.a, cpu.m8?8:16);
    goto L_05811E;
L_05811E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05811E STA
    hw.write(cpu.address("dp", 0x4Fu), cpu.a, cpu.m8?8:16);
    goto L_058120;
L_058120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058120 STA
    hw.write(cpu.address("dp", 0x51u), cpu.a, cpu.m8?8:16);
    goto L_058122;
L_058122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x53u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058122 STA
    hw.write(cpu.address("dp", 0x53u), cpu.a, cpu.m8?8:16);
    goto L_058124;
L_058124:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8124u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8124u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8124u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058124 PLP
    cpu.pop("PLP", hw);
    goto L_058125;
L_058125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8125u,0x058125u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058125 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x058125u);return;} hw.unresolvedReturn(0x058125u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_05809E_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05809Eu: goto L_05809E;
    case 0x05809Fu: goto L_05809F;
    case 0x0580A1u: goto L_0580A1;
    case 0x0580A4u: goto L_0580A4;
    case 0x0580A6u: goto L_0580A6;
    case 0x0580A9u: goto L_0580A9;
    case 0x0580ABu: goto L_0580AB;
    case 0x0580ADu: goto L_0580AD;
    case 0x0580B0u: goto L_0580B0;
    case 0x0580B2u: goto L_0580B2;
    case 0x0580B4u: goto L_0580B4;
    case 0x0580B6u: goto L_0580B6;
    case 0x0580B8u: goto L_0580B8;
    case 0x0580BBu: goto L_0580BB;
    case 0x0580BDu: goto L_0580BD;
    case 0x0580BFu: goto L_0580BF;
    case 0x0580C3u: goto L_0580C3;
    case 0x0580C7u: goto L_0580C7;
    case 0x0580CBu: goto L_0580CB;
    case 0x0580CDu: goto L_0580CD;
    case 0x0580CFu: goto L_0580CF;
    case 0x0580D1u: goto L_0580D1;
    case 0x0580D3u: goto L_0580D3;
    case 0x0580D5u: goto L_0580D5;
    case 0x0580D6u: goto L_0580D6;
    case 0x0580D7u: goto L_0580D7;
    case 0x0580D8u: goto L_0580D8;
    case 0x0580DAu: goto L_0580DA;
    case 0x0580DDu: goto L_0580DD;
    case 0x0580DEu: goto L_0580DE;
    case 0x0580E1u: goto L_0580E1;
    case 0x0580E2u: goto L_0580E2;
    case 0x0580E3u: goto L_0580E3;
    case 0x0580E6u: goto L_0580E6;
    case 0x0580E8u: goto L_0580E8;
    case 0x0580ECu: goto L_0580EC;
    case 0x0580EFu: goto L_0580EF;
    case 0x0580F0u: goto L_0580F0;
    case 0x0580F1u: goto L_0580F1;
    case 0x0580F2u: goto L_0580F2;
    case 0x0580F5u: goto L_0580F5;
    case 0x0580F7u: goto L_0580F7;
    case 0x0580F9u: goto L_0580F9;
    case 0x0580FBu: goto L_0580FB;
    case 0x0580FEu: goto L_0580FE;
    case 0x058101u: goto L_058101;
    case 0x058103u: goto L_058103;
    case 0x058105u: goto L_058105;
    case 0x058108u: goto L_058108;
    case 0x05810Bu: goto L_05810B;
    case 0x05810Eu: goto L_05810E;
    case 0x058111u: goto L_058111;
    case 0x058114u: goto L_058114;
    case 0x058117u: goto L_058117;
    case 0x058119u: goto L_058119;
    case 0x05811Cu: goto L_05811C;
    case 0x05811Eu: goto L_05811E;
    case 0x058120u: goto L_058120;
    case 0x058122u: goto L_058122;
    case 0x058124u: goto L_058124;
    case 0x058125u: goto L_058125;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05809E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Eu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05809E PHP
    cpu.push("PHP", hw);
    goto L_05809F;
L_05809F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05809F SEP
    cpu.sep(0x20u);
    goto L_0580A1;
L_0580A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u, 4u, 3u, cpu.address("abs", 0x1928u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580A1 STZ
    hw.write(cpu.address("abs", 0x1928u), 0, cpu.m8?8:16);
    goto L_0580A4;
L_0580A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580A4 REP
    cpu.rep(0x30u);
    goto L_0580A6;
L_0580A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580A6 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_0580A9;
L_0580A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580A9 STA
    hw.write(cpu.address("dp", 0x4Du), cpu.a, cpu.m8?8:16);
    goto L_0580AB;
L_0580AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ABu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580AB STA
    hw.write(cpu.address("dp", 0x4Fu), cpu.a, cpu.m8?8:16);
    goto L_0580AD;
L_0580AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu, 6u, 3u, cpu.address("abs", 0x877Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0580AD JSR -> $05877E stack real
    { cpu.push16Value(hw,0x80AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80B0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x877Eu), 0x0580ADu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580B0;
L_0580B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80B0u,0x0580B0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x45u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580B0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580B2;
L_0580B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580B2 STA
    hw.write(cpu.address("dp", 0x47u), cpu.a, cpu.m8?8:16);
    goto L_0580B4;
L_0580B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580B4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580B6;
L_0580B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580B6 STA
    hw.write(cpu.address("dp", 0x4Bu), cpu.a, cpu.m8?8:16);
    goto L_0580B8;
L_0580B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580B8 LDA
    cpu.setA(0x202u, 16);
    goto L_0580BB;
L_0580BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x55u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580BB STA
    hw.write(cpu.address("dp", 0x55u), cpu.a, cpu.m8?8:16);
    goto L_0580BD;
L_0580BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580BD REP
    cpu.rep(0x30u);
    goto L_0580BF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580BD REP
    cpu.rep(0x30u);
    goto L_0580BF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80BDu,0x0580BDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu, 8u, 4u, 0x0588ECu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580BF JSL -> $0588EC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0588ECu, 0x0580BFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580C3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu, 8u, 4u, 0x0588ECu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580BF JSL -> $0588EC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0588ECu, 0x0580BFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580C3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80BFu,0x0580BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u, 8u, 4u, 0x058955u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580C3 JSL -> $058955 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x058955u, 0x0580C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580C7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u, 8u, 4u, 0x058955u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580C3 JSL -> $058955 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x058955u, 0x0580C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580C7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80C3u,0x0580C3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u, 8u, 4u, 0x0087ADu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580C7 JSL -> $0087AD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80CAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80CBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0087ADu, 0x0580C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580CB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u, 8u, 4u, 0x0087ADu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580C7 JSL -> $0087AD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80CAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80CBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0087ADu, 0x0580C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580CB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80C7u,0x0580C7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CB REP
    cpu.rep(0x30u);
    goto L_0580CD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CB REP
    cpu.rep(0x30u);
    goto L_0580CD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80CBu,0x0580CBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CD INC
    cpu.incMem(hw, cpu.address("dp", 0x47u), cpu.m8?8:16);
    goto L_0580CF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CD INC
    cpu.incMem(hw, cpu.address("dp", 0x47u), cpu.m8?8:16);
    goto L_0580CF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80CDu,0x0580CDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CF INC
    cpu.incMem(hw, cpu.address("dp", 0x4Bu), cpu.m8?8:16);
    goto L_0580D1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CF INC
    cpu.incMem(hw, cpu.address("dp", 0x4Bu), cpu.m8?8:16);
    goto L_0580D1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80CFu,0x0580CFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D1 SEP
    cpu.sep(0x30u);
    goto L_0580D3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D1 SEP
    cpu.sep(0x30u);
    goto L_0580D3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80D1u,0x0580D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x47u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580D5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x47u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580D5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80D3u,0x0580D3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D5 LSR
    cpu.lsrA();
    goto L_0580D6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D5 LSR
    cpu.lsrA();
    goto L_0580D6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80D5u,0x0580D5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D6 LSR
    cpu.lsrA();
    goto L_0580D7;
L_0580D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D7 LSR
    cpu.lsrA();
    goto L_0580D8;
L_0580D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D8 REP
    cpu.rep(0x30u);
    goto L_0580DA;
L_0580DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580DA AND
    cpu.logicAnd(0x6u);
    goto L_0580DD;
L_0580DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580DD TAX
    cpu.transfer("TAX");
    goto L_0580DE;
L_0580DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580DE LDA
    cpu.setA(0x133u, 16);
    goto L_0580E1;
L_0580E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E1 ASL
    cpu.aslA();
    goto L_0580E2;
L_0580E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E2 TAY
    cpu.transfer("TAY");
    goto L_0580E3;
L_0580E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E3 LDA
    cpu.setA(0x7u, 16);
    goto L_0580E6;
L_0580E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E6 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0580E8;
L_0580E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u, 6u, 4u, ((0x058776u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E8 LDA
    cpu.loadA(hw.readW(((0x58776u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580EC;
L_0580EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu, 6u, 3u, cpu.address("absy", 0x0FBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580EC STA
    hw.write(cpu.address("absy", 0xFBEu), cpu.a, cpu.m8?8:16);
    goto L_0580EF;
L_0580EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580EF INY
    cpu.inc('Y');
    goto L_0580F0;
L_0580F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F0u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F0 INY
    cpu.inc('Y');
    goto L_0580F1;
L_0580F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F1 CLC
    cpu.setFlag('C', false);
    goto L_0580F2;
L_0580F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F2 ADC
    cpu.adc(0x8u);
    goto L_0580F5;
L_0580F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F5 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0580F7;
L_0580F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F7 BPL -> $0580EC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0580EC; }
    goto L_0580F9;
L_0580F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F9 SEP
    cpu.sep(0x20u);
    goto L_0580FB;
L_0580FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu, 6u, 3u, cpu.address("abs", 0x1928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580FB INC
    cpu.incMem(hw, cpu.address("abs", 0x1928u), cpu.m8?8:16);
    goto L_0580FE;
L_0580FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu, 4u, 3u, cpu.address("abs", 0x1928u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1928u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058101;
L_058101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058101 CMP
    cpu.compareA(0x20u);
    goto L_058103;
L_058103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058103 BNE -> $0580BD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0580BD; }
    goto L_058105;
L_058105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u, 4u, 3u, cpu.address("abs", 0x0D9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058105 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058108;
L_058108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8108u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8108u, 4u, 3u, cpu.address("abs", 0x212Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058108 STA
    hw.write(cpu.address("abs", 0x212Cu), cpu.a, cpu.m8?8:16);
    goto L_05810B;
L_05810B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Bu, 4u, 3u, cpu.address("abs", 0x212Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05810B STA
    hw.write(cpu.address("abs", 0x212Eu), cpu.a, cpu.m8?8:16);
    goto L_05810E;
L_05810E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu, 4u, 3u, cpu.address("abs", 0x0D9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05810E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058111;
L_058111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u, 4u, 3u, cpu.address("abs", 0x212Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058111 STA
    hw.write(cpu.address("abs", 0x212Du), cpu.a, cpu.m8?8:16);
    goto L_058114;
L_058114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u, 4u, 3u, cpu.address("abs", 0x212Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058114 STA
    hw.write(cpu.address("abs", 0x212Fu), cpu.a, cpu.m8?8:16);
    goto L_058117;
L_058117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8117u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8117u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058117 REP
    cpu.rep(0x20u);
    goto L_058119;
L_058119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058119 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_05811C;
L_05811C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05811C STA
    hw.write(cpu.address("dp", 0x4Du), cpu.a, cpu.m8?8:16);
    goto L_05811E;
L_05811E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05811E STA
    hw.write(cpu.address("dp", 0x4Fu), cpu.a, cpu.m8?8:16);
    goto L_058120;
L_058120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058120 STA
    hw.write(cpu.address("dp", 0x51u), cpu.a, cpu.m8?8:16);
    goto L_058122;
L_058122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x53u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058122 STA
    hw.write(cpu.address("dp", 0x53u), cpu.a, cpu.m8?8:16);
    goto L_058124;
L_058124:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8124u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8124u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8124u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058124 PLP
    cpu.pop("PLP", hw);
    goto L_058125;
L_058125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8125u,0x058125u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058125 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x058125u);return;} hw.unresolvedReturn(0x058125u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_05809E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05809Eu: goto L_05809E;
    case 0x05809Fu: goto L_05809F;
    case 0x0580A1u: goto L_0580A1;
    case 0x0580A4u: goto L_0580A4;
    case 0x0580A6u: goto L_0580A6;
    case 0x0580A9u: goto L_0580A9;
    case 0x0580ABu: goto L_0580AB;
    case 0x0580ADu: goto L_0580AD;
    case 0x0580B0u: goto L_0580B0;
    case 0x0580B2u: goto L_0580B2;
    case 0x0580B4u: goto L_0580B4;
    case 0x0580B6u: goto L_0580B6;
    case 0x0580B8u: goto L_0580B8;
    case 0x0580BBu: goto L_0580BB;
    case 0x0580BDu: goto L_0580BD;
    case 0x0580BFu: goto L_0580BF;
    case 0x0580C3u: goto L_0580C3;
    case 0x0580C7u: goto L_0580C7;
    case 0x0580CBu: goto L_0580CB;
    case 0x0580CDu: goto L_0580CD;
    case 0x0580CFu: goto L_0580CF;
    case 0x0580D1u: goto L_0580D1;
    case 0x0580D3u: goto L_0580D3;
    case 0x0580D5u: goto L_0580D5;
    case 0x0580D6u: goto L_0580D6;
    case 0x0580D7u: goto L_0580D7;
    case 0x0580D8u: goto L_0580D8;
    case 0x0580DAu: goto L_0580DA;
    case 0x0580DDu: goto L_0580DD;
    case 0x0580DEu: goto L_0580DE;
    case 0x0580E1u: goto L_0580E1;
    case 0x0580E2u: goto L_0580E2;
    case 0x0580E3u: goto L_0580E3;
    case 0x0580E6u: goto L_0580E6;
    case 0x0580E8u: goto L_0580E8;
    case 0x0580ECu: goto L_0580EC;
    case 0x0580EFu: goto L_0580EF;
    case 0x0580F0u: goto L_0580F0;
    case 0x0580F1u: goto L_0580F1;
    case 0x0580F2u: goto L_0580F2;
    case 0x0580F5u: goto L_0580F5;
    case 0x0580F7u: goto L_0580F7;
    case 0x0580F9u: goto L_0580F9;
    case 0x0580FBu: goto L_0580FB;
    case 0x0580FEu: goto L_0580FE;
    case 0x058101u: goto L_058101;
    case 0x058103u: goto L_058103;
    case 0x058105u: goto L_058105;
    case 0x058108u: goto L_058108;
    case 0x05810Bu: goto L_05810B;
    case 0x05810Eu: goto L_05810E;
    case 0x058111u: goto L_058111;
    case 0x058114u: goto L_058114;
    case 0x058117u: goto L_058117;
    case 0x058119u: goto L_058119;
    case 0x05811Cu: goto L_05811C;
    case 0x05811Eu: goto L_05811E;
    case 0x058120u: goto L_058120;
    case 0x058122u: goto L_058122;
    case 0x058124u: goto L_058124;
    case 0x058125u: goto L_058125;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05809E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Eu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05809E PHP
    cpu.push("PHP", hw);
    goto L_05809F;
L_05809F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05809F SEP
    cpu.sep(0x20u);
    goto L_0580A1;
L_0580A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u, 4u, 3u, cpu.address("abs", 0x1928u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580A1 STZ
    hw.write(cpu.address("abs", 0x1928u), 0, cpu.m8?8:16);
    goto L_0580A4;
L_0580A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580A4 REP
    cpu.rep(0x30u);
    goto L_0580A6;
L_0580A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580A6 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_0580A9;
L_0580A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580A9 STA
    hw.write(cpu.address("dp", 0x4Du), cpu.a, cpu.m8?8:16);
    goto L_0580AB;
L_0580AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ABu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580AB STA
    hw.write(cpu.address("dp", 0x4Fu), cpu.a, cpu.m8?8:16);
    goto L_0580AD;
L_0580AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu, 6u, 3u, cpu.address("abs", 0x877Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0580AD JSR -> $05877E stack real
    { cpu.push16Value(hw,0x80AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80B0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x877Eu), 0x0580ADu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580B0;
L_0580B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80B0u,0x0580B0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x45u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580B0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580B2;
L_0580B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580B2 STA
    hw.write(cpu.address("dp", 0x47u), cpu.a, cpu.m8?8:16);
    goto L_0580B4;
L_0580B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580B4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580B6;
L_0580B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580B6 STA
    hw.write(cpu.address("dp", 0x4Bu), cpu.a, cpu.m8?8:16);
    goto L_0580B8;
L_0580B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580B8 LDA
    cpu.setA(0x202u, 16);
    goto L_0580BB;
L_0580BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x55u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580BB STA
    hw.write(cpu.address("dp", 0x55u), cpu.a, cpu.m8?8:16);
    goto L_0580BD;
L_0580BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580BD REP
    cpu.rep(0x30u);
    goto L_0580BF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580BD REP
    cpu.rep(0x30u);
    goto L_0580BF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80BDu,0x0580BDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu, 8u, 4u, 0x0588ECu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580BF JSL -> $0588EC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0588ECu, 0x0580BFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580C3;
L_0580C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80C3u,0x0580C3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u, 8u, 4u, 0x058955u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580C3 JSL -> $058955 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x058955u, 0x0580C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580C7;
L_0580C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80C7u,0x0580C7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u, 8u, 4u, 0x0087ADu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580C7 JSL -> $0087AD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80CAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80CBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0087ADu, 0x0580C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580CB;
L_0580CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80CBu,0x0580CBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CB REP
    cpu.rep(0x30u);
    goto L_0580CD;
L_0580CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CD INC
    cpu.incMem(hw, cpu.address("dp", 0x47u), cpu.m8?8:16);
    goto L_0580CF;
L_0580CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CF INC
    cpu.incMem(hw, cpu.address("dp", 0x4Bu), cpu.m8?8:16);
    goto L_0580D1;
L_0580D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D1 SEP
    cpu.sep(0x30u);
    goto L_0580D3;
L_0580D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x47u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580D5;
L_0580D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D5 LSR
    cpu.lsrA();
    goto L_0580D6;
L_0580D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D6 LSR
    cpu.lsrA();
    goto L_0580D7;
L_0580D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D7 LSR
    cpu.lsrA();
    goto L_0580D8;
L_0580D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D8 REP
    cpu.rep(0x30u);
    goto L_0580DA;
L_0580DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580DA AND
    cpu.logicAnd(0x6u);
    goto L_0580DD;
L_0580DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580DD TAX
    cpu.transfer("TAX");
    goto L_0580DE;
L_0580DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580DE LDA
    cpu.setA(0x133u, 16);
    goto L_0580E1;
L_0580E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E1 ASL
    cpu.aslA();
    goto L_0580E2;
L_0580E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E2 TAY
    cpu.transfer("TAY");
    goto L_0580E3;
L_0580E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E3 LDA
    cpu.setA(0x7u, 16);
    goto L_0580E6;
L_0580E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E6 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0580E8;
L_0580E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u, 6u, 4u, ((0x058776u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E8 LDA
    cpu.loadA(hw.readW(((0x58776u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580EC;
L_0580EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu, 6u, 3u, cpu.address("absy", 0x0FBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580EC STA
    hw.write(cpu.address("absy", 0xFBEu), cpu.a, cpu.m8?8:16);
    goto L_0580EF;
L_0580EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580EF INY
    cpu.inc('Y');
    goto L_0580F0;
L_0580F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F0u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F0 INY
    cpu.inc('Y');
    goto L_0580F1;
L_0580F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F1 CLC
    cpu.setFlag('C', false);
    goto L_0580F2;
L_0580F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F2 ADC
    cpu.adc(0x8u);
    goto L_0580F5;
L_0580F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F5 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0580F7;
L_0580F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F7 BPL -> $0580EC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0580EC; }
    goto L_0580F9;
L_0580F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F9 SEP
    cpu.sep(0x20u);
    goto L_0580FB;
L_0580FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu, 6u, 3u, cpu.address("abs", 0x1928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580FB INC
    cpu.incMem(hw, cpu.address("abs", 0x1928u), cpu.m8?8:16);
    goto L_0580FE;
L_0580FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu, 4u, 3u, cpu.address("abs", 0x1928u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1928u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058101;
L_058101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058101 CMP
    cpu.compareA(0x20u);
    goto L_058103;
L_058103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058103 BNE -> $0580BD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0580BD; }
    goto L_058105;
L_058105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u, 4u, 3u, cpu.address("abs", 0x0D9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058105 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058108;
L_058108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8108u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8108u, 4u, 3u, cpu.address("abs", 0x212Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058108 STA
    hw.write(cpu.address("abs", 0x212Cu), cpu.a, cpu.m8?8:16);
    goto L_05810B;
L_05810B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Bu, 4u, 3u, cpu.address("abs", 0x212Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05810B STA
    hw.write(cpu.address("abs", 0x212Eu), cpu.a, cpu.m8?8:16);
    goto L_05810E;
L_05810E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu, 4u, 3u, cpu.address("abs", 0x0D9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05810E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058111;
L_058111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u, 4u, 3u, cpu.address("abs", 0x212Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058111 STA
    hw.write(cpu.address("abs", 0x212Du), cpu.a, cpu.m8?8:16);
    goto L_058114;
L_058114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u, 4u, 3u, cpu.address("abs", 0x212Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058114 STA
    hw.write(cpu.address("abs", 0x212Fu), cpu.a, cpu.m8?8:16);
    goto L_058117;
L_058117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8117u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8117u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058117 REP
    cpu.rep(0x20u);
    goto L_058119;
L_058119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058119 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_05811C;
L_05811C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05811C STA
    hw.write(cpu.address("dp", 0x4Du), cpu.a, cpu.m8?8:16);
    goto L_05811E;
L_05811E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05811E STA
    hw.write(cpu.address("dp", 0x4Fu), cpu.a, cpu.m8?8:16);
    goto L_058120;
L_058120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058120 STA
    hw.write(cpu.address("dp", 0x51u), cpu.a, cpu.m8?8:16);
    goto L_058122;
L_058122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x53u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058122 STA
    hw.write(cpu.address("dp", 0x53u), cpu.a, cpu.m8?8:16);
    goto L_058124;
L_058124:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8124u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8124u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8124u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058124 PLP
    cpu.pop("PLP", hw);
    goto L_058125;
L_058125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8125u,0x058125u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058125 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x058125u);return;} hw.unresolvedReturn(0x058125u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0585FF_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0585FFu: goto L_0585FF;
    case 0x058601u: goto L_058601;
    case 0x058603u: goto L_058603;
    case 0x058605u: goto L_058605;
    case 0x058607u: goto L_058607;
    case 0x058608u: goto L_058608;
    case 0x05860Au: goto L_05860A;
    case 0x05860Cu: goto L_05860C;
    case 0x05860Du: goto L_05860D;
    case 0x05860Fu: goto L_05860F;
    case 0x058611u: goto L_058611;
    case 0x058612u: goto L_058612;
    case 0x058613u: goto L_058613;
    case 0x058614u: goto L_058614;
    case 0x058616u: goto L_058616;
    case 0x058618u: goto L_058618;
    case 0x05861Au: goto L_05861A;
    case 0x05861Cu: goto L_05861C;
    case 0x05861Eu: goto L_05861E;
    case 0x058620u: goto L_058620;
    case 0x058621u: goto L_058621;
    case 0x058622u: goto L_058622;
    case 0x058623u: goto L_058623;
    case 0x058624u: goto L_058624;
    case 0x058626u: goto L_058626;
    case 0x058628u: goto L_058628;
    case 0x05862Au: goto L_05862A;
    case 0x05862Bu: goto L_05862B;
    case 0x05862Du: goto L_05862D;
    case 0x05862Fu: goto L_05862F;
    case 0x058631u: goto L_058631;
    case 0x058634u: goto L_058634;
    case 0x058636u: goto L_058636;
    case 0x058637u: goto L_058637;
    case 0x058639u: goto L_058639;
    case 0x05863Bu: goto L_05863B;
    case 0x05863Eu: goto L_05863E;
    case 0x058640u: goto L_058640;
    case 0x058642u: goto L_058642;
    case 0x058643u: goto L_058643;
    case 0x058644u: goto L_058644;
    case 0x058645u: goto L_058645;
    case 0x058646u: goto L_058646;
    case 0x058648u: goto L_058648;
    case 0x05864Au: goto L_05864A;
    case 0x05864Cu: goto L_05864C;
    case 0x05864Eu: goto L_05864E;
    case 0x058650u: goto L_058650;
    case 0x058652u: goto L_058652;
    case 0x058655u: goto L_058655;
    case 0x058658u: goto L_058658;
    case 0x058659u: goto L_058659;
    case 0x05865Au: goto L_05865A;
    case 0x05865Eu: goto L_05865E;
    case 0x058660u: goto L_058660;
    case 0x058664u: goto L_058664;
    case 0x058666u: goto L_058666;
    case 0x058669u: goto L_058669;
    case 0x05866Cu: goto L_05866C;
    case 0x05866Du: goto L_05866D;
    case 0x05866Eu: goto L_05866E;
    case 0x058670u: goto L_058670;
    case 0x058672u: goto L_058672;
    case 0x058674u: goto L_058674;
    case 0x058676u: goto L_058676;
    case 0x058678u: goto L_058678;
    case 0x05867Au: goto L_05867A;
    case 0x05867Cu: goto L_05867C;
    case 0x05867Eu: goto L_05867E;
    case 0x05867Fu: goto L_05867F;
    case 0x058681u: goto L_058681;
    case 0x058683u: goto L_058683;
    case 0x058685u: goto L_058685;
    case 0x058687u: goto L_058687;
    case 0x058689u: goto L_058689;
    case 0x05868Bu: goto L_05868B;
    case 0x05868Du: goto L_05868D;
    case 0x05868Fu: goto L_05868F;
    case 0x058691u: goto L_058691;
    case 0x058692u: goto L_058692;
    case 0x058695u: goto L_058695;
    case 0x058698u: goto L_058698;
    case 0x05869Bu: goto L_05869B;
    case 0x05869Cu: goto L_05869C;
    case 0x05869Du: goto L_05869D;
    case 0x0586A0u: goto L_0586A0;
    case 0x0586A1u: goto L_0586A1;
    case 0x0586A3u: goto L_0586A3;
    case 0x0586A5u: goto L_0586A5;
    case 0x0586A7u: goto L_0586A7;
    case 0x0586A9u: goto L_0586A9;
    case 0x0586AAu: goto L_0586AA;
    case 0x0586ACu: goto L_0586AC;
    case 0x0586AEu: goto L_0586AE;
    case 0x0586B0u: goto L_0586B0;
    case 0x0586B2u: goto L_0586B2;
    case 0x0586B3u: goto L_0586B3;
    case 0x0586B5u: goto L_0586B5;
    case 0x0586B7u: goto L_0586B7;
    case 0x0586B9u: goto L_0586B9;
    case 0x0586BBu: goto L_0586BB;
    case 0x0586BDu: goto L_0586BD;
    case 0x0586BFu: goto L_0586BF;
    case 0x0586C1u: goto L_0586C1;
    case 0x0586C3u: goto L_0586C3;
    case 0x0586C5u: goto L_0586C5;
    case 0x0586C7u: goto L_0586C7;
    case 0x0586C9u: goto L_0586C9;
    case 0x0586CCu: goto L_0586CC;
    case 0x0586CFu: goto L_0586CF;
    case 0x0586D2u: goto L_0586D2;
    case 0x0586D4u: goto L_0586D4;
    case 0x0586D6u: goto L_0586D6;
    case 0x0586D9u: goto L_0586D9;
    case 0x0586DBu: goto L_0586DB;
    case 0x0586DDu: goto L_0586DD;
    case 0x0586DFu: goto L_0586DF;
    case 0x0586E2u: goto L_0586E2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0585FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585FF SEP
    cpu.sep(0x30u);
    goto L_058601;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0585FF SEP
    cpu.sep(0x30u);
    goto L_058601;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85FFu,0x0585FFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_058601:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8601u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8601u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8601u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058601 LDY
    cpu.setY(0x0u, 8);
    goto L_058603;
L_058603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8603u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8603u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $058603 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058605;
L_058605:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8605u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8605u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8605u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058605 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_058607;
L_058607:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8607u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8607u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8607u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058607 INY
    cpu.inc('Y');
    goto L_058608;
L_058608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8608u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8608u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $058608 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05860A;
L_05860A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05860A STA
    hw.write(cpu.address("dp", 0xBu), cpu.a, cpu.m8?8:16);
    goto L_05860C;
L_05860C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05860C INY
    cpu.inc('Y');
    goto L_05860D;
L_05860D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Du,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $05860D LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05860F;
L_05860F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05860F STA
    hw.write(cpu.address("dp", 0x59u), cpu.a, cpu.m8?8:16);
    goto L_058611;
L_058611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8611u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8611u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8611u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058611 INY
    cpu.inc('Y');
    goto L_058612;
L_058612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8612u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8612u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058612 TYA
    cpu.transfer("TYA");
    goto L_058613;
L_058613:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8613u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8613u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8613u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058613 CLC
    cpu.setFlag('C', false);
    goto L_058614;
L_058614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8614u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8614u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058614 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x65u), cpu.m8?8:16));
    goto L_058616;
L_058616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8616u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8616u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058616 STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_058618;
L_058618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x66u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058618 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x66u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05861A;
L_05861A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05861A ADC
    cpu.adc(0x0u);
    goto L_05861C;
L_05861C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x66u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05861C STA
    hw.write(cpu.address("dp", 0x66u), cpu.a, cpu.m8?8:16);
    goto L_05861E;
L_05861E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05861E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058620;
L_058620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8620u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8620u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058620 LSR
    cpu.lsrA();
    goto L_058621;
L_058621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8621u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8621u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058621 LSR
    cpu.lsrA();
    goto L_058622;
L_058622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8622u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8622u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058622 LSR
    cpu.lsrA();
    goto L_058623;
L_058623:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8623u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8623u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8623u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058623 LSR
    cpu.lsrA();
    goto L_058624;
L_058624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8624u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8624u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058624 STA
    hw.write(cpu.address("dp", 0x5Au), cpu.a, cpu.m8?8:16);
    goto L_058626;
L_058626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8626u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8626u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8626u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058626 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058628;
L_058628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8628u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8628u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8628u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058628 AND
    cpu.logicAnd(0x60u);
    goto L_05862A;
L_05862A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05862A LSR
    cpu.lsrA();
    goto L_05862B;
L_05862B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Bu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05862B ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16));
    goto L_05862D;
L_05862D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05862D STA
    hw.write(cpu.address("dp", 0x5Au), cpu.a, cpu.m8?8:16);
    goto L_05862F;
L_05862F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05862F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058631;
L_058631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8631u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8631u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8631u, 4u, 3u, cpu.address("abs", 0x1933u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058631 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1933u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_058634;
L_058634:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8634u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8634u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8634u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058634 BEQ -> $058637
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_058637; }
    goto L_058636;
L_058636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058636 LSR
    cpu.lsrA();
    goto L_058637;
L_058637:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8637u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8637u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8637u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058637 AND
    cpu.logicAnd(0x1u);
    goto L_058639;
L_058639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058639 BEQ -> $05863E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05863E; }
    goto L_05863B;
L_05863B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Bu, 6u, 3u, cpu.address("abs", 0x85D8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05863B JSR -> $0585D8 stack real
    { cpu.push16Value(hw,0x863Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x863Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85D8u), 0x05863Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05863E;
L_05863E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x863Eu,0x05863Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05863E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058640;
L_058640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8640u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8640u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8640u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058640 AND
    cpu.logicAnd(0xFu);
    goto L_058642;
L_058642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058642 ASL
    cpu.aslA();
    goto L_058643;
L_058643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8643u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8643u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8643u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058643 ASL
    cpu.aslA();
    goto L_058644;
L_058644:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8644u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8644u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8644u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058644 ASL
    cpu.aslA();
    goto L_058645;
L_058645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8645u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8645u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058645 ASL
    cpu.aslA();
    goto L_058646;
L_058646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8646u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8646u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8646u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058646 STA
    hw.write(cpu.address("dp", 0x57u), cpu.a, cpu.m8?8:16);
    goto L_058648;
L_058648:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8648u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8648u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8648u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058648 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05864A;
L_05864A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05864A AND
    cpu.logicAnd(0xFu);
    goto L_05864C;
L_05864C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05864C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x57u), cpu.m8?8:16));
    goto L_05864E;
L_05864E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05864E STA
    hw.write(cpu.address("dp", 0x57u), cpu.a, cpu.m8?8:16);
    goto L_058650;
L_058650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8650u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8650u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058650 REP
    cpu.rep(0x20u);
    goto L_058652;
L_058652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8652u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8652u, 5u, 3u, cpu.address("abs", 0x1933u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058652 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1933u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058655;
L_058655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8655u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8655u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058655 AND
    cpu.logicAnd(0xFFu);
    goto L_058658;
L_058658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8658u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8658u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058658 ASL
    cpu.aslA();
    goto L_058659;
L_058659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8659u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8659u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058659 TAX
    cpu.transfer("TAX");
    goto L_05865A;
L_05865A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Au, 6u, 4u, ((0x00BEA8u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05865A LDA
    cpu.loadA(hw.readW(((0xBEA8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05865E;
L_05865E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05865E STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_058660;
L_058660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8660u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8660u, 6u, 4u, ((0x00BEACu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058660 LDA
    cpu.loadA(hw.readW(((0xBEACu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058664;
L_058664:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8664u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8664u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8664u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058664 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_058666;
L_058666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8666u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8666u, 5u, 3u, cpu.address("abs", 0x1925u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058666 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1925u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058669;
L_058669:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8669u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8669u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8669u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058669 AND
    cpu.logicAnd(0x1Fu);
    goto L_05866C;
L_05866C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05866C ASL
    cpu.aslA();
    goto L_05866D;
L_05866D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05866D TAY
    cpu.transfer("TAY");
    goto L_05866E;
L_05866E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05866E SEP
    cpu.sep(0x20u);
    goto L_058670;
L_058670:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8670u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8670u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8670u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058670 LDA
    cpu.setA(0x0u, 8);
    goto L_058672;
L_058672:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8672u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8672u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8672u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058672 STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_058674;
L_058674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8674u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8674u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8674u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058674 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_058676;
L_058676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x03u) & 0xFFFFu), 3u, 0u);
    // $058676 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058678;
L_058678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8678u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8678u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058678 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_05867A;
L_05867A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x06u) & 0xFFFFu), 3u, 0u);
    // $05867A LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05867C;
L_05867C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05867C STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_05867E;
L_05867E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05867E INY
    cpu.inc('Y');
    goto L_05867F;
L_05867F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Fu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x03u) & 0xFFFFu), 3u, 0u);
    // $05867F LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058681;
L_058681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8681u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8681u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058681 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_058683;
L_058683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x06u) & 0xFFFFu), 3u, 0u);
    // $058683 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058685;
L_058685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8685u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8685u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8685u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058685 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_058687;
L_058687:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8687u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8687u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8687u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058687 LDA
    cpu.setA(0x0u, 8);
    goto L_058689;
L_058689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8689u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8689u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058689 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_05868B;
L_05868B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05868B STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_05868D;
L_05868D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05868D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05868F;
L_05868F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05868F AND
    cpu.logicAnd(0x80u);
    goto L_058691;
L_058691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8691u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8691u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8691u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058691 ASL
    cpu.aslA();
    goto L_058692;
L_058692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8692u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8692u, 4u, 3u, cpu.address("abs", 0x1928u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058692 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1928u), cpu.m8?8:16));
    goto L_058695;
L_058695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8695u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8695u, 4u, 3u, cpu.address("abs", 0x1928u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058695 STA
    hw.write(cpu.address("abs", 0x1928u), cpu.a, cpu.m8?8:16);
    goto L_058698;
L_058698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8698u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8698u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8698u, 4u, 3u, cpu.address("abs", 0x1BA1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058698 STA
    hw.write(cpu.address("abs", 0x1BA1u), cpu.a, cpu.m8?8:16);
    goto L_05869B;
L_05869B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05869B ASL
    cpu.aslA();
    goto L_05869C;
L_05869C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05869C CLC
    cpu.setFlag('C', false);
    goto L_05869D;
L_05869D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Du,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Du, 4u, 3u, cpu.address("abs", 0x1928u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05869D ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1928u), cpu.m8?8:16));
    goto L_0586A0;
L_0586A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586A0 TAY
    cpu.transfer("TAY");
    goto L_0586A1;
L_0586A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $0586A1 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0586A3;
L_0586A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586A3 STA
    hw.write(cpu.address("dp", 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0586A5;
L_0586A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A5u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A5u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Du) & 0xFFFFu), 3u, 0u);
    // $0586A5 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0586A7;
L_0586A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586A7 STA
    hw.write(cpu.address("dp", 0x6Eu), cpu.a, cpu.m8?8:16);
    goto L_0586A9;
L_0586A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586A9 INY
    cpu.inc('Y');
    goto L_0586AA;
L_0586AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86AAu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86AAu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $0586AA LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0586AC;
L_0586AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586AC STA
    hw.write(cpu.address("dp", 0x6Cu), cpu.a, cpu.m8?8:16);
    goto L_0586AE;
L_0586AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86AEu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86AEu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Du) & 0xFFFFu), 3u, 0u);
    // $0586AE LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0586B0;
L_0586B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586B0 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_0586B2;
L_0586B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586B2 INY
    cpu.inc('Y');
    goto L_0586B3;
L_0586B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B3u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B3u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $0586B3 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0586B5;
L_0586B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586B5 STA
    hw.write(cpu.address("dp", 0x6Du), cpu.a, cpu.m8?8:16);
    goto L_0586B7;
L_0586B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Du) & 0xFFFFu), 3u, 0u);
    // $0586B7 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0586B9;
L_0586B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x70u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586B9 STA
    hw.write(cpu.address("dp", 0x70u), cpu.a, cpu.m8?8:16);
    goto L_0586BB;
L_0586BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586BB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0586BD;
L_0586BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586BD AND
    cpu.logicAnd(0x10u);
    goto L_0586BF;
L_0586BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586BF BEQ -> $0586C5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0586C5; }
    goto L_0586C1;
L_0586C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586C1 INC
    cpu.incMem(hw, cpu.address("dp", 0x6Cu), cpu.m8?8:16);
    goto L_0586C3;
L_0586C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586C3 INC
    cpu.incMem(hw, cpu.address("dp", 0x6Fu), cpu.m8?8:16);
    goto L_0586C5;
L_0586C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586C5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0586C7;
L_0586C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586C7 BNE -> $0586CF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0586CF; }
    goto L_0586C9;
L_0586C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u, 6u, 3u, cpu.address("abs", 0x86E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0586C9 JSR -> $0586E3 stack real
    { cpu.push16Value(hw,0x86CBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86CCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x86E3u), 0x0586C9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0586CC;
L_0586CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86CCu,0x0586CCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CCu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CCu, 3u, 3u, cpu.address("abs", 0x86D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586CC JMP -> $0586D2
    goto L_0586D2;
L_0586CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CFu, 6u, 3u, cpu.address("abs", 0x86EAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0586CF JSR -> $0586EA stack real
    { cpu.push16Value(hw,0x86D1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86D2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x86EAu), 0x0586CFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0586D2;
L_0586D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86D2u,0x0586D2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586D2 SEP
    cpu.sep(0x20u);
    goto L_0586D4;
L_0586D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586D4 REP
    cpu.rep(0x10u);
    goto L_0586D6;
L_0586D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586D6 LDY
    cpu.setY(0x0u, 16);
    goto L_0586D9;
L_0586D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x65u) & 0xFFFFu), 3u, 0u);
    // $0586D9 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0586DB;
L_0586DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586DB CMP
    cpu.compareA(0xFFu);
    goto L_0586DD;
L_0586DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586DD BEQ -> $0586E2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0586E2; }
    goto L_0586DF;
L_0586DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DFu, 3u, 3u, cpu.address("abs", 0x85FFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0586DF JMP -> $0585FF
    goto L_0585FF;
L_0586E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0586E2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0586E2u);return;} hw.unresolvedReturn(0x0586E2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0CA051_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CA051u: goto L_0CA051;
    case 0x0CA052u: goto L_0CA052;
    case 0x0CA053u: goto L_0CA053;
    case 0x0CA054u: goto L_0CA054;
    case 0x0CA056u: goto L_0CA056;
    case 0x0CA059u: goto L_0CA059;
    case 0x0CA05Cu: goto L_0CA05C;
    case 0x0CA05Du: goto L_0CA05D;
    case 0x0CA05Fu: goto L_0CA05F;
    case 0x0CA061u: goto L_0CA061;
    case 0x0CA063u: goto L_0CA063;
    case 0x0CA066u: goto L_0CA066;
    case 0x0CA069u: goto L_0CA069;
    case 0x0CA06Cu: goto L_0CA06C;
    case 0x0CA06Fu: goto L_0CA06F;
    case 0x0CA072u: goto L_0CA072;
    case 0x0CA075u: goto L_0CA075;
    case 0x0CA078u: goto L_0CA078;
    case 0x0CA07Bu: goto L_0CA07B;
    case 0x0CA07Du: goto L_0CA07D;
    case 0x0CA080u: goto L_0CA080;
    case 0x0CA081u: goto L_0CA081;
    case 0x0CA082u: goto L_0CA082;
    case 0x0CA084u: goto L_0CA084;
    case 0x0CA086u: goto L_0CA086;
    case 0x0CA088u: goto L_0CA088;
    case 0x0CA08Au: goto L_0CA08A;
    case 0x0CA08Du: goto L_0CA08D;
    case 0x0CA08Eu: goto L_0CA08E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CA051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA051u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA051u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CA051 PHB
    cpu.push("PHB", hw);
    goto L_0CA052;
L_0CA052:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA052u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA052u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA052u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CA052 PHK
    cpu.push("PHK", hw);
    goto L_0CA053;
L_0CA053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA053u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA053u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CA053 PLB
    cpu.pop("PLB", hw);
    goto L_0CA054;
L_0CA054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA054u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA054u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA054 LDX
    cpu.setX(0xEu, 8);
    goto L_0CA056;
L_0CA056:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA056u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA056u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA056u, 5u, 3u, cpu.address("absx", 0x0B23u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA056 STZ
    hw.write(cpu.address("absx", 0xB23u), 0, cpu.m8?8:16);
    goto L_0CA059;
L_0CA059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA059u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA059u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA059u, 5u, 3u, cpu.address("absx", 0x0B32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA059 STZ
    hw.write(cpu.address("absx", 0xB32u), 0, cpu.m8?8:16);
    goto L_0CA05C;
L_0CA05C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA05Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA05C DEX
    cpu.decReg('X');
    goto L_0CA05D;
L_0CA05D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA05Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA05D BPL -> $0CA056
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0CA056; }
    goto L_0CA05F;
L_0CA05F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA05Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA05F LDX
    cpu.setX(0xDu, 8);
    goto L_0CA061;
L_0CA061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA061u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA061u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA061u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA061 LDY
    cpu.setY(0x6u, 8);
    goto L_0CA063;
L_0CA063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA063u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA063u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA063u, 4u + ((((0xA04Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA04Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA063 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA04Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CA066;
L_0CA066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA066u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA066u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA066u, 5u, 3u, cpu.address("absx", 0x0B41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA066 STA
    hw.write(cpu.address("absx", 0xB41u), cpu.a, cpu.m8?8:16);
    goto L_0CA069;
L_0CA069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA069u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA069u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA069u, 5u, 3u, cpu.address("absx", 0x0B5Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA069 STZ
    hw.write(cpu.address("absx", 0xB5Fu), 0, cpu.m8?8:16);
    goto L_0CA06C;
L_0CA06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA06Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Cu, 4u + ((((0xA043u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA043u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA06C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA043u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CA06F;
L_0CA06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA06Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Fu, 5u, 3u, cpu.address("absx", 0x0B50u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA06F STA
    hw.write(cpu.address("absx", 0xB50u), cpu.a, cpu.m8?8:16);
    goto L_0CA072;
L_0CA072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA072u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA072u, 5u, 3u, cpu.address("absx", 0x0B6Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA072 STZ
    hw.write(cpu.address("absx", 0xB6Eu), 0, cpu.m8?8:16);
    goto L_0CA075;
L_0CA075:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA075u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA075u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA075u, 4u + ((((0xA3C2u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA3C2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA075 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA3C2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CA078;
L_0CA078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA078u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA078u, 5u, 3u, cpu.address("absx", 0x0B05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA078 STA
    hw.write(cpu.address("absx", 0xB05u), cpu.a, cpu.m8?8:16);
    goto L_0CA07B;
L_0CA07B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA07Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA07B LDA
    cpu.setA(0x1u, 8);
    goto L_0CA07D;
L_0CA07D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA07Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Du, 5u, 3u, cpu.address("absx", 0x0AF6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA07D STA
    hw.write(cpu.address("absx", 0xAF6u), cpu.a, cpu.m8?8:16);
    goto L_0CA080;
L_0CA080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA080u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA080u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA080 DEY
    cpu.decReg('Y');
    goto L_0CA081;
L_0CA081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA081u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA081u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA081 DEX
    cpu.decReg('X');
    goto L_0CA082;
L_0CA082:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA082u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA082u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA082u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA082 CPX
    cpu.compareX(0x6u);
    goto L_0CA084;
L_0CA084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA084u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA084u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA084u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA084 BNE -> $0CA063
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CA063; }
    goto L_0CA086;
L_0CA086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA086u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA086u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA086u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA086 STZ
    hw.write(cpu.address("dp", 0x76u), 0, cpu.m8?8:16);
    goto L_0CA088;
L_0CA088:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA088u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA088u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA088u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA088 LDA
    cpu.setA(0xE2u, 8);
    goto L_0CA08A;
L_0CA08A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA08Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Au, 4u, 3u, cpu.address("abs", 0x1B89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CA08A STA
    hw.write(cpu.address("abs", 0x1B89u), cpu.a, cpu.m8?8:16);
    goto L_0CA08D;
L_0CA08D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA08Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0CA08D PLB
    cpu.pop("PLB", hw);
    goto L_0CA08E;
L_0CA08E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA08Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CA08E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CA08Eu);return;} hw.unresolvedReturn(0x0CA08Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0CCB5B_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CCB5Bu: goto L_0CCB5B;
    case 0x0CCB5Du: goto L_0CCB5D;
    case 0x0CCB60u: goto L_0CCB60;
    case 0x0CCB62u: goto L_0CCB62;
    case 0x0CCB64u: goto L_0CCB64;
    case 0x0CCB67u: goto L_0CCB67;
    case 0x0CCB69u: goto L_0CCB69;
    case 0x0CCB6Cu: goto L_0CCB6C;
    case 0x0CCB6Eu: goto L_0CCB6E;
    case 0x0CCB71u: goto L_0CCB71;
    case 0x0CCB73u: goto L_0CCB73;
    case 0x0CCB76u: goto L_0CCB76;
    case 0x0CCB78u: goto L_0CCB78;
    case 0x0CCB7Bu: goto L_0CCB7B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CCB5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB5B LDY
    cpu.setY(0xE0u, 8);
    goto L_0CCB5D;
L_0CCB5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Du, 4u, 3u, cpu.address("abs", 0x143Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB5D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x143Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CCB60;
L_0CCB60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB60u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB60 BEQ -> $0CCB64
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CCB64; }
    goto L_0CCB62;
L_0CCB62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB62u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB62 LDY
    cpu.setY(0xE2u, 8);
    goto L_0CCB64;
L_0CCB64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB64u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB64u, 4u, 3u, cpu.address("abs", 0x0202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB64 STY
    hw.write(cpu.address("abs", 0x202u), cpu.y, cpu.x8?8:16);
    goto L_0CCB67;
L_0CCB67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB67u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB67 LDA
    cpu.setA(0x39u, 8);
    goto L_0CCB69;
L_0CCB69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB69u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB69u, 4u, 3u, cpu.address("abs", 0x0203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB69 STA
    hw.write(cpu.address("abs", 0x203u), cpu.a, cpu.m8?8:16);
    goto L_0CCB6C;
L_0CCB6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB6Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB6Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB6C LDA
    cpu.setA(0x50u, 8);
    goto L_0CCB6E;
L_0CCB6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB6Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB6Eu, 4u, 3u, cpu.address("abs", 0x0200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB6E STA
    hw.write(cpu.address("abs", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_0CCB71;
L_0CCB71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB71u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB71u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB71 LDA
    cpu.setA(0x67u, 8);
    goto L_0CCB73;
L_0CCB73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB73u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB73u, 4u, 3u, cpu.address("abs", 0x0201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB73 STA
    hw.write(cpu.address("abs", 0x201u), cpu.a, cpu.m8?8:16);
    goto L_0CCB76;
L_0CCB76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB76u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB76 LDA
    cpu.setA(0x2u, 8);
    goto L_0CCB78;
L_0CCB78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB78u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB78u, 4u, 3u, cpu.address("abs", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CCB78 STA
    hw.write(cpu.address("abs", 0x420u), cpu.a, cpu.m8?8:16);
    goto L_0CCB7B;
L_0CCB7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB7Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB7Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CCB7B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CCB7Bu);return;} hw.unresolvedReturn(0x0CCB7Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DC31E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DC31Eu: goto L_0DC31E;
    case 0x0DC320u: goto L_0DC320;
    case 0x0DC322u: goto L_0DC322;
    case 0x0DC324u: goto L_0DC324;
    case 0x0DC326u: goto L_0DC326;
    case 0x0DC328u: goto L_0DC328;
    case 0x0DC32Au: goto L_0DC32A;
    case 0x0DC32Du: goto L_0DC32D;
    case 0x0DC331u: goto L_0DC331;
    case 0x0DC334u: goto L_0DC334;
    case 0x0DC335u: goto L_0DC335;
    case 0x0DC337u: goto L_0DC337;
    case 0x0DC339u: goto L_0DC339;
    case 0x0DC33Cu: goto L_0DC33C;
    case 0x0DC33Eu: goto L_0DC33E;
    case 0x0DC340u: goto L_0DC340;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DC31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC31E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DC320;
L_0DC320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC320u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC320u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC320 LDX
    cpu.setX(0x0u, 8);
    goto L_0DC322;
L_0DC322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC322u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC322u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC322 LDA
    cpu.setA(0x1u, 8);
    goto L_0DC324;
L_0DC324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC324u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC324u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC324 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DC326;
L_0DC326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC326u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC326u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC326 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DC328;
L_0DC328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC328u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC328u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC328 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DC32A;
L_0DC32A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Au, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC32A JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xC32Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC32Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DC32Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC32D;
L_0DC32D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC32Du,0x0DC32Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Du, 5u, 4u, ((0x0DC318u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC32D LDA
    cpu.loadA(hw.readW(((0xDC318u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DC331;
L_0DC331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC331u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC331u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC331 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xC333u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC334u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DC331u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC334;
L_0DC334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC334u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC334u,0x0DC334u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC334u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC334u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC334 INX
    cpu.inc('X');
    goto L_0DC335;
L_0DC335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC335u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC335u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC335 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DC337;
L_0DC337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC337u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC337u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC337u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC337 BPL -> $0DC32A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DC32A; }
    goto L_0DC339;
L_0DC339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC339u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC339u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC339 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xC33Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC33Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DC339u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DC33C;
L_0DC33C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC33Cu,0x0DC33Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Cu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC33C CPX
    cpu.compareX(0x6u);
    goto L_0DC33E;
L_0DC33E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DC33E BNE -> $0DC326
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DC326; }
    goto L_0DC340;
L_0DC340:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC340u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC340u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC340u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DC340 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DC340u);return;} hw.unresolvedReturn(0x0DC340u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DE9AA_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DE9AAu: goto L_0DE9AA;
    case 0x0DE9ACu: goto L_0DE9AC;
    case 0x0DE9AEu: goto L_0DE9AE;
    case 0x0DE9AFu: goto L_0DE9AF;
    case 0x0DE9B1u: goto L_0DE9B1;
    case 0x0DE9B3u: goto L_0DE9B3;
    case 0x0DE9B4u: goto L_0DE9B4;
    case 0x0DE9B5u: goto L_0DE9B5;
    case 0x0DE9B6u: goto L_0DE9B6;
    case 0x0DE9B7u: goto L_0DE9B7;
    case 0x0DE9B9u: goto L_0DE9B9;
    case 0x0DE9BAu: goto L_0DE9BA;
    case 0x0DE9BCu: goto L_0DE9BC;
    case 0x0DE9BEu: goto L_0DE9BE;
    case 0x0DE9C0u: goto L_0DE9C0;
    case 0x0DE9C3u: goto L_0DE9C3;
    case 0x0DE9C6u: goto L_0DE9C6;
    case 0x0DE9CAu: goto L_0DE9CA;
    case 0x0DE9CDu: goto L_0DE9CD;
    case 0x0DE9CEu: goto L_0DE9CE;
    case 0x0DE9D0u: goto L_0DE9D0;
    case 0x0DE9D2u: goto L_0DE9D2;
    case 0x0DE9D5u: goto L_0DE9D5;
    case 0x0DE9D8u: goto L_0DE9D8;
    case 0x0DE9DAu: goto L_0DE9DA;
    case 0x0DE9DCu: goto L_0DE9DC;
    case 0x0DE9DEu: goto L_0DE9DE;
    case 0x0DE9E0u: goto L_0DE9E0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DE9AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AAu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9AA LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DE9AC;
L_0DE9AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DE9AE;
L_0DE9AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9AE SEC
    cpu.setFlag('C', true);
    goto L_0DE9AF;
L_0DE9AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AFu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9AF SBC
    cpu.sbc(0x61u);
    goto L_0DE9B1;
L_0DE9B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9B1 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DE9B3;
L_0DE9B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9B3 ASL
    cpu.aslA();
    goto L_0DE9B4;
L_0DE9B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9B4 ASL
    cpu.aslA();
    goto L_0DE9B5;
L_0DE9B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9B5 ASL
    cpu.aslA();
    goto L_0DE9B6;
L_0DE9B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9B6 CLC
    cpu.setFlag('C', false);
    goto L_0DE9B7;
L_0DE9B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B7u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9B7 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_0DE9B9;
L_0DE9B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9B9 TAX
    cpu.transfer("TAX");
    goto L_0DE9BA;
L_0DE9BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9BA LDA
    cpu.setA(0x2u, 8);
    goto L_0DE9BC;
L_0DE9BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9BC STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DE9BE;
L_0DE9BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9BEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9BE STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DE9C0;
L_0DE9C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C0u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE9C0 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xE9C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE9C3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DE9C0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DE9C3;
L_0DE9C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9C3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9C3u,0x0DE9C3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C3u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE9C3 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xE9C5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE9C6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DE9C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DE9C6;
L_0DE9C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9C6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9C6u,0x0DE9C6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C6u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9C6u, 5u, 4u, ((0x0DE98Fu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9C6 LDA
    cpu.loadA(hw.readW(((0xDE98Fu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DE9CA;
L_0DE9CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CAu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE9CA JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xE9CCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE9CDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DE9CAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DE9CD;
L_0DE9CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9CDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9CDu,0x0DE9CDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CDu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9CD INX
    cpu.inc('X');
    goto L_0DE9CE;
L_0DE9CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CEu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9CEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9CE DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DE9D0;
L_0DE9D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9D0 BPL -> $0DE9C3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DE9C3; }
    goto L_0DE9D2;
L_0DE9D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D2u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE9D2 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xE9D4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE9D5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DE9D2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DE9D5;
L_0DE9D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9D5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9D5u,0x0DE9D5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D5u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE9D5 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xE9D7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE9D8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DE9D5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DE9D8;
L_0DE9D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9D8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9D8u,0x0DE9D8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9D8 LDA
    cpu.setA(0x2u, 8);
    goto L_0DE9DA;
L_0DE9DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9DA STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DE9DC;
L_0DE9DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DCu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9DC DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DE9DE;
L_0DE9DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DE9DE BPL -> $0DE9C3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DE9C3; }
    goto L_0DE9E0;
L_0DE9E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9E0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DE9E0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DE9E0u);return;} hw.unresolvedReturn(0x0DE9E0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DEE52_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DEE52u: goto L_0DEE52;
    case 0x0DEE54u: goto L_0DEE54;
    case 0x0DEE56u: goto L_0DEE56;
    case 0x0DEE58u: goto L_0DEE58;
    case 0x0DEE5Au: goto L_0DEE5A;
    case 0x0DEE5Cu: goto L_0DEE5C;
    case 0x0DEE5Du: goto L_0DEE5D;
    case 0x0DEE5Eu: goto L_0DEE5E;
    case 0x0DEE5Fu: goto L_0DEE5F;
    case 0x0DEE60u: goto L_0DEE60;
    case 0x0DEE62u: goto L_0DEE62;
    case 0x0DEE65u: goto L_0DEE65;
    case 0x0DEE67u: goto L_0DEE67;
    case 0x0DEE69u: goto L_0DEE69;
    case 0x0DEE6Cu: goto L_0DEE6C;
    case 0x0DEE6Eu: goto L_0DEE6E;
    case 0x0DEE71u: goto L_0DEE71;
    case 0x0DEE72u: goto L_0DEE72;
    case 0x0DEE74u: goto L_0DEE74;
    case 0x0DEE77u: goto L_0DEE77;
    case 0x0DEE79u: goto L_0DEE79;
    case 0x0DEE7Cu: goto L_0DEE7C;
    case 0x0DEE7Fu: goto L_0DEE7F;
    case 0x0DEE82u: goto L_0DEE82;
    case 0x0DEE84u: goto L_0DEE84;
    case 0x0DEE86u: goto L_0DEE86;
    case 0x0DEE88u: goto L_0DEE88;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DEE52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE52u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE52u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE52 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DEE54;
L_0DEE54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE54u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE54u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE54 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DEE56;
L_0DEE56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE56u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE56u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE56 AND
    cpu.logicAnd(0xFu);
    goto L_0DEE58;
L_0DEE58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE58u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE58u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE58 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DEE5A;
L_0DEE5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE5A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DEE5C;
L_0DEE5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE5C LSR
    cpu.lsrA();
    goto L_0DEE5D;
L_0DEE5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE5D LSR
    cpu.lsrA();
    goto L_0DEE5E;
L_0DEE5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE5E LSR
    cpu.lsrA();
    goto L_0DEE5F;
L_0DEE5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE5Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE5F LSR
    cpu.lsrA();
    goto L_0DEE60;
L_0DEE60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE60 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DEE62;
L_0DEE62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE62u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE62u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEE62 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xEE64u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE65u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DEE62u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEE65;
L_0DEE65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE65u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE65u,0x0DEE65u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE65u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE65u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE65 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DEE67;
L_0DEE67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE67u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE67 BEQ -> $0DEE74
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DEE74; }
    goto L_0DEE69;
L_0DEE69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE69u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE69u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEE69 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xEE6Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE6Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DEE69u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEE6C;
L_0DEE6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE6Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE6Cu,0x0DEE6Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE6C LDA
    cpu.setA(0x53u, 8);
    goto L_0DEE6E;
L_0DEE6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Eu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEE6E JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xEE70u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE71u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DEE6Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEE71;
L_0DEE71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE71u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE71u,0x0DEE71u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE71u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE71u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE71 DEX
    cpu.decReg('X');
    goto L_0DEE72;
L_0DEE72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE72u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE72 BNE -> $0DEE69
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DEE69; }
    goto L_0DEE74;
L_0DEE74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE74u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE74u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEE74 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xEE76u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE77u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DEE74u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEE77;
L_0DEE77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE77u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE77u,0x0DEE77u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE77u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE77u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE77 LDA
    cpu.setA(0x55u, 8);
    goto L_0DEE79;
L_0DEE79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE79u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE79u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEE79 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xEE7Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE7Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DEE79u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEE7C;
L_0DEE7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Cu,0x0DEE7Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Cu, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEE7C JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xEE7Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE7Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DEE7Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEE7F;
L_0DEE7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE7Fu,0x0DEE7Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Fu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEE7F JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xEE81u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE82u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DEE7Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEE82;
L_0DEE82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE82u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE82u,0x0DEE82u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE82u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE82u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE82 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DEE84;
L_0DEE84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE84u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE84u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE84 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DEE86;
L_0DEE86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE86u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE86u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE86 BPL -> $0DEE65
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DEE65; }
    goto L_0DEE88;
L_0DEE88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE88u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE88u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEE88 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DEE88u);return;} hw.unresolvedReturn(0x0DEE88u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_22CD59_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x22B7A7u: goto L_22B7A7;
    case 0x22B7ABu: goto L_22B7AB;
    case 0x22CD59u: goto L_22CD59;
    case 0x22CD5Cu: goto L_22CD5C;
    case 0x22CD5Eu: goto L_22CD5E;
    case 0x22CD60u: goto L_22CD60;
    case 0x22CD62u: goto L_22CD62;
    case 0x22CD64u: goto L_22CD64;
    case 0x22CD66u: goto L_22CD66;
    case 0x22CD68u: goto L_22CD68;
    case 0x22CD6Bu: goto L_22CD6B;
    case 0x22CD6Du: goto L_22CD6D;
    case 0x22CD6Fu: goto L_22CD6F;
    case 0x22CD70u: goto L_22CD70;
    case 0x22CD72u: goto L_22CD72;
    case 0x22CD74u: goto L_22CD74;
    case 0x22CD77u: goto L_22CD77;
    case 0x22CD79u: goto L_22CD79;
    case 0x22CD7Bu: goto L_22CD7B;
    case 0x22CD7Fu: goto L_22CD7F;
    case 0x22CD83u: goto L_22CD83;
    case 0x22CD86u: goto L_22CD86;
    case 0x22CD87u: goto L_22CD87;
    case 0x22CD8Au: goto L_22CD8A;
    case 0x22CD8Du: goto L_22CD8D;
    case 0x22CD8Fu: goto L_22CD8F;
    case 0x22CD91u: goto L_22CD91;
    case 0x22CD93u: goto L_22CD93;
    case 0x22CD94u: goto L_22CD94;
    case 0x22CD97u: goto L_22CD97;
    case 0x22CD9Au: goto L_22CD9A;
    case 0x22CD9Cu: goto L_22CD9C;
    case 0x22CD9Du: goto L_22CD9D;
    case 0x22CDA0u: goto L_22CDA0;
    case 0x22CDA3u: goto L_22CDA3;
    case 0x22CDA6u: goto L_22CDA6;
    case 0x22CDA9u: goto L_22CDA9;
    case 0x22CDACu: goto L_22CDAC;
    case 0x22CDAEu: goto L_22CDAE;
    case 0x22CDB0u: goto L_22CDB0;
    case 0x22CDB2u: goto L_22CDB2;
    case 0x22CDB5u: goto L_22CDB5;
    case 0x22CDB6u: goto L_22CDB6;
    case 0x22CDB7u: goto L_22CDB7;
    case 0x22CDB8u: goto L_22CDB8;
    case 0x22CDB9u: goto L_22CDB9;
    case 0x22CDBAu: goto L_22CDBA;
    case 0x22CDBCu: goto L_22CDBC;
    case 0x22CDBDu: goto L_22CDBD;
    case 0x22CDBFu: goto L_22CDBF;
    case 0x22CDC1u: goto L_22CDC1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_22B7A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A7u, 8u, 4u, 0x01B7B3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $22B7A7 JSL -> $01B7B3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB7AAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB7ABu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01B7B3u, 0x22B7A7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_22B7AB;
L_22B7AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7ABu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB7ABu,0x22B7ABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ABu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ABu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $22B7AB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x22B7ABu);return;} hw.unresolvedReturn(0x22B7ABu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_22CD59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD59u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD59u, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD59 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_22CD5C;
L_22CD5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD5C CMP
    cpu.compareA(0x5Eu);
    goto L_22CD5E;
L_22CD5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD5E BNE -> $22CD7F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_22CD7F; }
    goto L_22CD60;
L_22CD60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD60u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD60 LDA
    cpu.setA(0x1Bu, 8);
    goto L_22CD62;
L_22CD62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD62u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD62u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD62 STA
    hw.write(cpu.address("dp", 0x9Cu), cpu.a, cpu.m8?8:16);
    goto L_22CD64;
L_22CD64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD64u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD64u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD64 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_22CD66;
L_22CD66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD66u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD66u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD66 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_22CD68;
L_22CD68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD68u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD68u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD68 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_22CD6B;
L_22CD6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD6B STA
    hw.write(cpu.address("dp", 0x9Bu), cpu.a, cpu.m8?8:16);
    goto L_22CD6D;
L_22CD6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD6D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_22CD6F;
L_22CD6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD6F SEC
    cpu.setFlag('C', true);
    goto L_22CD70;
L_22CD70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD70u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD70 SBC
    cpu.sbc(0x10u);
    goto L_22CD72;
L_22CD72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD72u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD72u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD72 STA
    hw.write(cpu.address("dp", 0x98u), cpu.a, cpu.m8?8:16);
    goto L_22CD74;
L_22CD74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD74u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD74u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD74 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_22CD77;
L_22CD77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD77u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD77u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD77 SBC
    cpu.sbc(0x0u);
    goto L_22CD79;
L_22CD79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD79u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD79u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD79 STA
    hw.write(cpu.address("dp", 0x99u), cpu.a, cpu.m8?8:16);
    goto L_22CD7B;
L_22CD7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Bu, 8u, 4u, 0x00BEB0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $22CD7B JSL -> $00BEB0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCD7Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD7Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00BEB0u, 0x22CD7Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_22CD7F;
L_22CD7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD7Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD7Fu,0x22CD7Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Fu, 8u, 4u, 0x01B44Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $22CD7F JSL -> $01B44F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCD82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD83u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01B44Fu, 0x22CD7Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_22CD83;
L_22CD83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD83u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD83u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD83u, 6u, 3u, cpu.address("abs", 0xD378u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $22CD83 JSR -> $22D378 stack real
    { cpu.push16Value(hw,0xCD85u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD86u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD378u), 0x22CD83u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_22CD86;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD83u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD83u, 6u, 3u, cpu.address("abs", 0xD378u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $22CD83 JSR -> $22D378 stack real
    { cpu.push16Value(hw,0xCD85u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD86u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD378u), 0x22CD83u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_22CD86;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD83u,0x22CD83u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_22CD86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD86u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD86u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD86u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $22CD86 PHX
    cpu.push("PHX", hw);
    goto L_22CD87;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD86u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD86u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $22CD86 PHX
    cpu.push("PHX", hw);
    goto L_22CD87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD86u,0x22CD86u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_22CD87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD87u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD87u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD87u, 4u, 3u, cpu.address("abs", 0x191Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD87 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x191Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_22CD8A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD87u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD87u, 4u, 3u, cpu.address("abs", 0x191Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD87 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x191Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_22CD8A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD87u,0x22CD87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_22CD8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD8Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Au, 4u + ((((0xCD55u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xCD55u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD8A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xCD55u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_22CD8D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Au, 4u + ((((0xCD55u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xCD55u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD8A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xCD55u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_22CD8D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD8Au,0x22CD8Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_22CD8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD8Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD8D STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_22CD8F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD8D STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_22CD8F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD8Du,0x22CD8Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_22CD8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD8Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD8F LDX
    cpu.setX(0x7u, 8);
    goto L_22CD91;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD8F LDX
    cpu.setX(0x7u, 8);
    goto L_22CD91;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD8Fu,0x22CD8Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_22CD91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD91u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD91u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD91u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD91 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_22CD93;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD91u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD91u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD91 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_22CD93;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD91u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD91u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD91 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_22CD93;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD91u,0x22CD91u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_22CD93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD93u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD93u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD93u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD93 CLC
    cpu.setFlag('C', false);
    goto L_22CD94;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD93u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD93u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD93 CLC
    cpu.setFlag('C', false);
    goto L_22CD94;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD93u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD93u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD93 CLC
    cpu.setFlag('C', false);
    goto L_22CD94;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD93u,0x22CD93u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_22CD94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD94u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD94u, 4u + ((((0xCD35u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xCD35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD94 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xCD35u), cpu.m8?8:16));
    goto L_22CD97;
L_22CD97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD97u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD97u, 5u, 3u, cpu.address("absy", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD97 STA
    hw.write(cpu.address("absy", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_22CD9A;
L_22CD9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD9Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD9Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD9A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_22CD9C;
L_22CD9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD9Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD9C CLC
    cpu.setFlag('C', false);
    goto L_22CD9D;
L_22CD9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD9Du,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD9Du, 4u + ((((0xCD3Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xCD3Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CD9D ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xCD3Du), cpu.m8?8:16));
    goto L_22CDA0;
L_22CDA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA0u, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDA0 STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_22CDA3;
L_22CDA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA3u, 4u + ((((0xCD45u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xCD45u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDA3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xCD45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_22CDA6;
L_22CDA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA6u, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDA6 STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_22CDA9;
L_22CDA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA9u, 4u + ((((0xCD4Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xCD4Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDA9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xCD4Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_22CDAC;
L_22CDAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDACu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDAC CPX
    cpu.compareX(0x4u);
    goto L_22CDAE;
L_22CDAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDAEu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDAEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDAE BCS -> $22CDB2
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_22CDB2; }
    goto L_22CDB0;
L_22CDB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB0u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDB0 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_22CDB2;
L_22CDB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB2u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB2u, 5u, 3u, cpu.address("absy", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDB2 STA
    hw.write(cpu.address("absy", 0x303u), cpu.a, cpu.m8?8:16);
    goto L_22CDB5;
L_22CDB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDB5 INY
    cpu.inc('Y');
    goto L_22CDB6;
L_22CDB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB6u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDB6 INY
    cpu.inc('Y');
    goto L_22CDB7;
L_22CDB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB7u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDB7 INY
    cpu.inc('Y');
    goto L_22CDB8;
L_22CDB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDB8 INY
    cpu.inc('Y');
    goto L_22CDB9;
L_22CDB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB9u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDB9 DEX
    cpu.decReg('X');
    goto L_22CDBA;
L_22CDBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDBA BPL -> $22CD91
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_22CD91; }
    goto L_22CDBC;
L_22CDBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBCu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $22CDBC PLX
    cpu.pop("PLX", hw);
    goto L_22CDBD;
L_22CDBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBDu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDBD LDY
    cpu.setY(0x0u, 8);
    goto L_22CDBF;
L_22CDBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDBF LDA
    cpu.setA(0x7u, 8);
    goto L_22CDC1;
L_22CDC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC1u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC1u, 3u, 3u, cpu.address("abs", 0xB7A7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $22CDC1 JMP -> $22B7A7
    goto L_22B7A7;
}

void sub_4C6E75_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x4C6E75u: goto L_4C6E75;
    case 0x60811Du: goto L_60811D;
    case 0x60811Fu: goto L_60811F;
    case 0x608122u: goto L_608122;
    case 0x608125u: goto L_608125;
    case 0x608127u: goto L_608127;
    case 0x60812Au: goto L_60812A;
    case 0x60812Du: goto L_60812D;
    case 0x608130u: goto L_608130;
    case 0x608131u: goto L_608131;
    case 0x608133u: goto L_608133;
    case 0x60815Eu: goto L_60815E;
    case 0x608160u: goto L_608160;
    case 0x608163u: goto L_608163;
    case 0x608165u: goto L_608165;
    case 0x608168u: goto L_608168;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_4C6E75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x6E75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x6E75u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x6E75u, 4u, 4u, 0x60815Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C6E75 JML -> $60815E
    cpu.pb=0x60u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_60815E;
L_60811D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60811D LDA
    cpu.setA(0xFFu, 8);
    goto L_60811F;
L_60811F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60811F STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_608122;
L_608122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u, 6u, 3u, cpu.address("abs", 0x80F7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $608122 JSR -> $6080F7 stack real
    { cpu.push16Value(hw,0x8124u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8125u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80F7u), 0x608122u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_608125;
L_608125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8125u,0x608125u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608125 LDX
    cpu.setX(0x3u, 8);
    goto L_608127;
L_608127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u, 5u, 3u, cpu.address("absx", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608127 STZ
    hw.write(cpu.address("absx", 0x2140u), 0, cpu.m8?8:16);
    goto L_60812A;
L_60812A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au, 5u, 3u, cpu.address("absx", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60812A STZ
    hw.write(cpu.address("absx", 0x1DF9u), 0, cpu.m8?8:16);
    goto L_60812D;
L_60812D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du, 5u, 3u, cpu.address("absx", 0x1DFDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60812D STZ
    hw.write(cpu.address("absx", 0x1DFDu), 0, cpu.m8?8:16);
    goto L_608130;
L_608130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608130 DEX
    cpu.decReg('X');
    goto L_608131;
L_608131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608131 BPL -> $608127
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_608127; }
    goto L_608133;
L_608133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8133u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8133u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8133u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $608133 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x608133u);return;} hw.unresolvedReturn(0x608133u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_60815E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60815E LDA
    cpu.setA(0xE4u, 8);
    goto L_608160;
L_608160:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8160u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8160u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8160u, 4u, 3u, cpu.address("abs", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608160 STA
    hw.write(cpu.address("abs", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_608163;
L_608163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8163u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8163u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8163u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608163 LDA
    cpu.setA(0x3u, 8);
    goto L_608165;
L_608165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8165u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8165u, 4u, 3u, cpu.address("abs", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608165 STA
    hw.write(cpu.address("abs", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_608168;
L_608168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8168u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8168u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $608168 BRA -> $60811D
    goto L_60811D;
}

