#include "generated.hpp"
void sub_00A5AB_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A5ABu: goto L_00A5AB;
    case 0x00A5AFu: goto L_00A5AF;
    case 0x00A5B2u: goto L_00A5B2;
    case 0x00A5B4u: goto L_00A5B4;
    case 0x00A5B9u: goto L_00A5B9;
    case 0x00A5BCu: goto L_00A5BC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A5AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu, 8u, 4u, 0x05809Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A5AB JSL -> $05809E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA5AEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5AFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05809Eu, 0x00A5ABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5AF;
L_00A5AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5AFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5AFu,0x00A5AFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AFu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5AF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A5B2;
L_00A5B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5B2 BPL -> $00A5B9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00A5B9; }
    goto L_00A5B4;
L_00A5B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B4u, 6u, 3u, cpu.address("abs", 0x97BCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5B4 JSR -> $0097BC stack real
    { cpu.push16Value(hw,0xA5B6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5B7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x97BCu), 0x00A5B4u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5B7u,0x00A5B4u); return;
L_00A5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u, 6u, 3u, cpu.address("abs", 0xA9DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5B9 JSR -> $00A9DA stack real
    { cpu.push16Value(hw,0xA5BBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5BCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA9DAu), 0x00A5B9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A5BC;
L_00A5BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5BCu,0x00A5BCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BCu, 6u, 3u, cpu.address("abs", 0xABEDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A5BC JSR -> $00ABED stack real
    { cpu.push16Value(hw,0xA5BEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5BFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABEDu), 0x00A5BCu); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5BFu,0x00A5BCu); return;
}

void sub_00A635_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A635u: goto L_00A635;
    case 0x00A638u: goto L_00A638;
    case 0x00A63Bu: goto L_00A63B;
    case 0x00A63Eu: goto L_00A63E;
    case 0x00A640u: goto L_00A640;
    case 0x00A643u: goto L_00A643;
    case 0x00A645u: goto L_00A645;
    case 0x00A648u: goto L_00A648;
    case 0x00A64Au: goto L_00A64A;
    case 0x00A64Du: goto L_00A64D;
    case 0x00A64Fu: goto L_00A64F;
    case 0x00A651u: goto L_00A651;
    case 0x00A654u: goto L_00A654;
    case 0x00A657u: goto L_00A657;
    case 0x00A65Au: goto L_00A65A;
    case 0x00A65Du: goto L_00A65D;
    case 0x00A660u: goto L_00A660;
    case 0x00A663u: goto L_00A663;
    case 0x00A666u: goto L_00A666;
    case 0x00A669u: goto L_00A669;
    case 0x00A66Cu: goto L_00A66C;
    case 0x00A66Fu: goto L_00A66F;
    case 0x00A671u: goto L_00A671;
    case 0x00A674u: goto L_00A674;
    case 0x00A676u: goto L_00A676;
    case 0x00A678u: goto L_00A678;
    case 0x00A679u: goto L_00A679;
    case 0x00A67Bu: goto L_00A67B;
    case 0x00A67Du: goto L_00A67D;
    case 0x00A680u: goto L_00A680;
    case 0x00A681u: goto L_00A681;
    case 0x00A683u: goto L_00A683;
    case 0x00A686u: goto L_00A686;
    case 0x00A689u: goto L_00A689;
    case 0x00A68Cu: goto L_00A68C;
    case 0x00A68Fu: goto L_00A68F;
    case 0x00A692u: goto L_00A692;
    case 0x00A694u: goto L_00A694;
    case 0x00A697u: goto L_00A697;
    case 0x00A699u: goto L_00A699;
    case 0x00A69Bu: goto L_00A69B;
    case 0x00A69Eu: goto L_00A69E;
    case 0x00A69Fu: goto L_00A69F;
    case 0x00A6A1u: goto L_00A6A1;
    case 0x00A6A4u: goto L_00A6A4;
    case 0x00A6A7u: goto L_00A6A7;
    case 0x00A6AAu: goto L_00A6AA;
    case 0x00A6ACu: goto L_00A6AC;
    case 0x00A6AFu: goto L_00A6AF;
    case 0x00A6B1u: goto L_00A6B1;
    case 0x00A6B4u: goto L_00A6B4;
    case 0x00A6B6u: goto L_00A6B6;
    case 0x00A6B8u: goto L_00A6B8;
    case 0x00A6BAu: goto L_00A6BA;
    case 0x00A6BCu: goto L_00A6BC;
    case 0x00A6BEu: goto L_00A6BE;
    case 0x00A6C0u: goto L_00A6C0;
    case 0x00A6C3u: goto L_00A6C3;
    case 0x00A6C5u: goto L_00A6C5;
    case 0x00A6C7u: goto L_00A6C7;
    case 0x00A6C9u: goto L_00A6C9;
    case 0x00A6CBu: goto L_00A6CB;
    case 0x00A6CCu: goto L_00A6CC;
    case 0x00A6CEu: goto L_00A6CE;
    case 0x00A6D0u: goto L_00A6D0;
    case 0x00A6D2u: goto L_00A6D2;
    case 0x00A6D5u: goto L_00A6D5;
    case 0x00A6D8u: goto L_00A6D8;
    case 0x00A6DAu: goto L_00A6DA;
    case 0x00A6DCu: goto L_00A6DC;
    case 0x00A6DEu: goto L_00A6DE;
    case 0x00A6E0u: goto L_00A6E0;
    case 0x00A6E2u: goto L_00A6E2;
    case 0x00A6E4u: goto L_00A6E4;
    case 0x00A6E6u: goto L_00A6E6;
    case 0x00A6E8u: goto L_00A6E8;
    case 0x00A6EBu: goto L_00A6EB;
    case 0x00A6EDu: goto L_00A6ED;
    case 0x00A6F0u: goto L_00A6F0;
    case 0x00A6F2u: goto L_00A6F2;
    case 0x00A6F5u: goto L_00A6F5;
    case 0x00A6F7u: goto L_00A6F7;
    case 0x00A6F9u: goto L_00A6F9;
    case 0x00A6FCu: goto L_00A6FC;
    case 0x00A6FEu: goto L_00A6FE;
    case 0x00A6FFu: goto L_00A6FF;
    case 0x00A701u: goto L_00A701;
    case 0x00A704u: goto L_00A704;
    case 0x00A707u: goto L_00A707;
    case 0x00A709u: goto L_00A709;
    case 0x00A70Bu: goto L_00A70B;
    case 0x00A70Du: goto L_00A70D;
    case 0x00A70Fu: goto L_00A70F;
    case 0x00A711u: goto L_00A711;
    case 0x00A713u: goto L_00A713;
    case 0x00A715u: goto L_00A715;
    case 0x00A716u: goto L_00A716;
    case 0x00A718u: goto L_00A718;
    case 0x00A71Au: goto L_00A71A;
    case 0x00A71Cu: goto L_00A71C;
    case 0x00A71Eu: goto L_00A71E;
    case 0x00A721u: goto L_00A721;
    case 0x00A723u: goto L_00A723;
    case 0x00A726u: goto L_00A726;
    case 0x00A728u: goto L_00A728;
    case 0x00A72Au: goto L_00A72A;
    case 0x00A72Cu: goto L_00A72C;
    case 0x00A72Eu: goto L_00A72E;
    case 0x00A730u: goto L_00A730;
    case 0x00A732u: goto L_00A732;
    case 0x00A734u: goto L_00A734;
    case 0x00A736u: goto L_00A736;
    case 0x00A739u: goto L_00A739;
    case 0x00A73Cu: goto L_00A73C;
    case 0x00A73Eu: goto L_00A73E;
    case 0x00A740u: goto L_00A740;
    case 0x00A741u: goto L_00A741;
    case 0x00A743u: goto L_00A743;
    case 0x00A745u: goto L_00A745;
    case 0x00A746u: goto L_00A746;
    case 0x00A747u: goto L_00A747;
    case 0x00A748u: goto L_00A748;
    case 0x00A74Bu: goto L_00A74B;
    case 0x00A74Eu: goto L_00A74E;
    case 0x00A750u: goto L_00A750;
    case 0x00A752u: goto L_00A752;
    case 0x00A754u: goto L_00A754;
    case 0x00A756u: goto L_00A756;
    case 0x00A758u: goto L_00A758;
    case 0x00A75Au: goto L_00A75A;
    case 0x00A75Cu: goto L_00A75C;
    case 0x00A75Eu: goto L_00A75E;
    case 0x00A760u: goto L_00A760;
    case 0x00A762u: goto L_00A762;
    case 0x00A764u: goto L_00A764;
    case 0x00A766u: goto L_00A766;
    case 0x00A768u: goto L_00A768;
    case 0x00A76Au: goto L_00A76A;
    case 0x00A76Cu: goto L_00A76C;
    case 0x00A76Fu: goto L_00A76F;
    case 0x00A772u: goto L_00A772;
    case 0x00A774u: goto L_00A774;
    case 0x00A776u: goto L_00A776;
    case 0x00A778u: goto L_00A778;
    case 0x00A779u: goto L_00A779;
    case 0x00A77Cu: goto L_00A77C;
    case 0x00A77Eu: goto L_00A77E;
    case 0x00A77Fu: goto L_00A77F;
    case 0x00A780u: goto L_00A780;
    case 0x00A781u: goto L_00A781;
    case 0x00A783u: goto L_00A783;
    case 0x00A785u: goto L_00A785;
    case 0x00A786u: goto L_00A786;
    case 0x00A789u: goto L_00A789;
    case 0x00A78Bu: goto L_00A78B;
    case 0x00A78Du: goto L_00A78D;
    case 0x00A78Eu: goto L_00A78E;
    case 0x00A791u: goto L_00A791;
    case 0x00A793u: goto L_00A793;
    case 0x00A795u: goto L_00A795;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA635u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA635u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA635u, 4u, 3u, cpu.address("abs", 0x14ADu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A635 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14ADu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A638;
L_00A638:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA638u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA638u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA638u, 4u, 3u, cpu.address("abs", 0x14AEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A638 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x14AEu), cpu.m8?8:16));
    goto L_00A63B;
L_00A63B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Bu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Bu, 4u, 3u, cpu.address("abs", 0x190Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A63B ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x190Cu), cpu.m8?8:16));
    goto L_00A63E;
L_00A63E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A63E BNE -> $00A64A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A64A; }
    goto L_00A640;
L_00A640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA640u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA640u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA640u, 4u, 3u, cpu.address("abs", 0x1490u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A640 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1490u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A643;
L_00A643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA643u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA643u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA643u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A643 BEQ -> $00A660
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A660; }
    goto L_00A645;
L_00A645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA645u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA645u, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A645 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDDAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A648;
L_00A648:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA648u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA648u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA648u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A648 BPL -> $00A64F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00A64F; }
    goto L_00A64A;
L_00A64A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Au, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A64A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDDAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A64D;
L_00A64D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A64D AND
    cpu.logicAnd(0x7Fu);
    goto L_00A64F;
L_00A64F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Fu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A64F ORA
    cpu.logicOr(0x40u);
    goto L_00A651;
L_00A651:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA651u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA651u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA651u, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A651 STA
    hw.write(cpu.address("abs", 0xDDAu), cpu.a, cpu.m8?8:16);
    goto L_00A654;
L_00A654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA654u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA654u, 4u, 3u, cpu.address("abs", 0x14ADu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A654 STZ
    hw.write(cpu.address("abs", 0x14ADu), 0, cpu.m8?8:16);
    goto L_00A657;
L_00A657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA657u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA657u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA657u, 4u, 3u, cpu.address("abs", 0x14AEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A657 STZ
    hw.write(cpu.address("abs", 0x14AEu), 0, cpu.m8?8:16);
    goto L_00A65A;
L_00A65A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Au, 4u, 3u, cpu.address("abs", 0x190Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A65A STZ
    hw.write(cpu.address("abs", 0x190Cu), 0, cpu.m8?8:16);
    goto L_00A65D;
L_00A65D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Du, 4u, 3u, cpu.address("abs", 0x1490u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A65D STZ
    hw.write(cpu.address("abs", 0x1490u), 0, cpu.m8?8:16);
    goto L_00A660;
L_00A660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u, 4u, 3u, cpu.address("abs", 0x13F4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A660 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13F4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A663;
L_00A663:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA663u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA663u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA663u, 4u, 3u, cpu.address("abs", 0x13F5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A663 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13F5u), cpu.m8?8:16));
    goto L_00A666;
L_00A666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA666u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA666u, 4u, 3u, cpu.address("abs", 0x13F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A666 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13F6u), cpu.m8?8:16));
    goto L_00A669;
L_00A669:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA669u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA669u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA669u, 4u, 3u, cpu.address("abs", 0x13F7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A669 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13F7u), cpu.m8?8:16));
    goto L_00A66C;
L_00A66C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Cu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Cu, 4u, 3u, cpu.address("abs", 0x13F8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A66C ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13F8u), cpu.m8?8:16));
    goto L_00A66F;
L_00A66F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A66F BEQ -> $00A674
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A674; }
    goto L_00A671;
L_00A671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA671u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA671u, 4u, 3u, cpu.address("abs", 0x141Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A671 STA
    hw.write(cpu.address("abs", 0x141Bu), cpu.a, cpu.m8?8:16);
    goto L_00A674;
L_00A674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA674u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA674u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA674u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A674 LDX
    cpu.setX(0x23u, 8);
    goto L_00A676;
L_00A676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA676u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA676u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x70u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A676 STZ
    hw.write(cpu.address("dpx", 0x70u), 0, cpu.m8?8:16);
    goto L_00A678;
L_00A678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A678 DEX
    cpu.decReg('X');
    goto L_00A679;
L_00A679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA679u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA679u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A679 BNE -> $00A676
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A676; }
    goto L_00A67B;
L_00A67B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A67B LDX
    cpu.setX(0x37u, 8);
    goto L_00A67D;
L_00A67D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Du, 5u, 3u, cpu.address("absx", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A67D STZ
    hw.write(cpu.address("absx", 0x13D9u), 0, cpu.m8?8:16);
    goto L_00A680;
L_00A680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA680u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA680u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA680u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A680 DEX
    cpu.decReg('X');
    goto L_00A681;
L_00A681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA681u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA681u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A681 BNE -> $00A67D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A67D; }
    goto L_00A683;
L_00A683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA683u,cpu,0x0Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA683u, 6u, 3u, cpu.address("abs", 0x13CBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A683 ASL
    cpu.aslMem(hw, cpu.address("abs", 0x13CBu), cpu.m8?8:16);
    goto L_00A686;
L_00A686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA686u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA686u, 4u, 3u, cpu.address("abs", 0x149Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A686 STZ
    hw.write(cpu.address("abs", 0x149Au), 0, cpu.m8?8:16);
    goto L_00A689;
L_00A689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u, 4u, 3u, cpu.address("abs", 0x1498u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A689 STZ
    hw.write(cpu.address("abs", 0x1498u), 0, cpu.m8?8:16);
    goto L_00A68C;
L_00A68C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Cu, 4u, 3u, cpu.address("abs", 0x1495u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A68C STZ
    hw.write(cpu.address("abs", 0x1495u), 0, cpu.m8?8:16);
    goto L_00A68F;
L_00A68F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Fu, 4u, 3u, cpu.address("abs", 0x1419u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A68F STZ
    hw.write(cpu.address("abs", 0x1419u), 0, cpu.m8?8:16);
    goto L_00A692;
L_00A692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA692u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA692u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A692 LDY
    cpu.setY(0x1u, 8);
    goto L_00A694;
L_00A694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA694u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA694u, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A694 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1931u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00A697;
L_00A697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A697 CPX
    cpu.compareX(0x10u);
    goto L_00A699;
L_00A699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A699 BCS -> $00A6CC
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00A6CC; }
    goto L_00A69B;
L_00A69B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu, 4u + ((((0xA625u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA625u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A69B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA625u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A69E;
L_00A69E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A69E LSR
    cpu.lsrA();
    goto L_00A69F;
L_00A69F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A69F BEQ -> $00A6CC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A6CC; }
    goto L_00A6A1;
L_00A6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u, 4u, 3u, cpu.address("abs", 0x141Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6A1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A6A4;
L_00A6A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A4u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A4u, 4u, 3u, cpu.address("abs", 0x141Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6A4 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x141Au), cpu.m8?8:16));
    goto L_00A6A7;
L_00A6A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A7u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A7u, 4u, 3u, cpu.address("abs", 0x141Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6A7 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x141Fu), cpu.m8?8:16));
    goto L_00A6AA;
L_00A6AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6AA BNE -> $00A6CC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A6CC; }
    goto L_00A6AC;
L_00A6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu, 4u, 3u, cpu.address("abs", 0x13CFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6AC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13CFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A6AF;
L_00A6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6AF BEQ -> $00A6B6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A6B6; }
    goto L_00A6B1;
L_00A6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B1u, 6u, 3u, cpu.address("abs", 0xC90Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A6B1 JSR -> $00C90A stack real
    { cpu.push16Value(hw,0xA6B3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA6B4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC90Au), 0x00A6B1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A6B4;
L_00A6B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B4u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6B4u,0x00A6B4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6B4 BRA -> $00A6CC
    goto L_00A6CC;
L_00A6B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B6u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6B6 STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_00A6B8;
L_00A6B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B8u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6B8 STY
    hw.write(cpu.address("dp", 0x76u), cpu.y, cpu.x8?8:16);
    goto L_00A6BA;
L_00A6BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BAu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6BA STY
    hw.write(cpu.address("dp", 0x89u), cpu.y, cpu.x8?8:16);
    goto L_00A6BC;
L_00A6BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BCu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6BC LDX
    cpu.setX(0xAu, 8);
    goto L_00A6BE;
L_00A6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6BE LDY
    cpu.setY(0x0u, 8);
    goto L_00A6C0;
L_00A6C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C0u, 4u, 3u, cpu.address("abs", 0x0DC1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6C0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDC1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A6C3;
L_00A6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6C3 BEQ -> $00A6C7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A6C7; }
    goto L_00A6C5;
L_00A6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6C5 LDY
    cpu.setY(0xFu, 8);
    goto L_00A6C7;
L_00A6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6C7 STX
    hw.write(cpu.address("dp", 0x71u), cpu.x, cpu.x8?8:16);
    goto L_00A6C9;
L_00A6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C9u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6C9 STY
    hw.write(cpu.address("dp", 0x88u), cpu.y, cpu.x8?8:16);
    goto L_00A6CB;
L_00A6CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A6CB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A6CBu);return;} hw.unresolvedReturn(0x00A6CBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00A6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6CC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A6CE;
L_00A6CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6CE CMP
    cpu.compareA(0xC0u);
    goto L_00A6D0;
L_00A6D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6D0 BEQ -> $00A6D5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A6D5; }
    goto L_00A6D2;
L_00A6D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D2u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D2u, 6u, 3u, cpu.address("abs", 0x13F1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6D2 INC
    cpu.incMem(hw, cpu.address("abs", 0x13F1u), cpu.m8?8:16);
    goto L_00A6D5;
L_00A6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D5u, 4u, 3u, cpu.address("abs", 0x192Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6D5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x192Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A6D8;
L_00A6D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6D8 BEQ -> $00A6E0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A6E0; }
    goto L_00A6DA;
L_00A6DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6DA CMP
    cpu.compareA(0x5u);
    goto L_00A6DC;
L_00A6DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6DC BNE -> $00A716
    if (!cpu.z) { hw.addCpuInternalCycles(2u); goto L_00A716; }
    goto L_00A6DE;
L_00A6DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DEu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6DE ROR
    cpu.rorMem(hw, cpu.address("dp", 0x86u), cpu.m8?8:16);
    goto L_00A6E0;
L_00A6E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E0u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6E0 STY
    hw.write(cpu.address("dp", 0x76u), cpu.y, cpu.x8?8:16);
    goto L_00A6E2;
L_00A6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6E2 LDA
    cpu.setA(0x24u, 8);
    goto L_00A6E4;
L_00A6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6E4 STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00A6E6;
L_00A6E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E6u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6E6 STZ
    hw.write(cpu.address("dp", 0x9Du), 0, cpu.m8?8:16);
    goto L_00A6E8;
L_00A6E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E8u, 4u, 3u, cpu.address("abs", 0x1434u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6E8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1434u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A6EB;
L_00A6EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6EB BEQ -> $00A704
    if (cpu.z) { hw.addCpuInternalCycles(2u); goto L_00A704; }
    goto L_00A6ED;
L_00A6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EDu, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6ED LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDDAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A6F0;
L_00A6F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F0u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6F0 ORA
    cpu.logicOr(0x7Fu);
    goto L_00A6F2;
L_00A6F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F2u, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6F2 STA
    hw.write(cpu.address("abs", 0xDDAu), cpu.a, cpu.m8?8:16);
    goto L_00A6F5;
L_00A6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6F5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A6F7;
L_00A6F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F7u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6F7 ORA
    cpu.logicOr(0x4u);
    goto L_00A6F9;
L_00A6F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F9u, 4u, 3u, cpu.address("abs", 0x1436u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6F9 STA
    hw.write(cpu.address("abs", 0x1436u), cpu.a, cpu.m8?8:16);
    goto L_00A6FC;
L_00A6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6FC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A6FE;
L_00A6FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6FE CLC
    cpu.setFlag('C', false);
    goto L_00A6FF;
L_00A6FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A6FF ADC
    cpu.adc(0x10u);
    goto L_00A701;
L_00A701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA701u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA701u, 4u, 3u, cpu.address("abs", 0x1438u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A701 STA
    hw.write(cpu.address("abs", 0x1438u), cpu.a, cpu.m8?8:16);
    goto L_00A704;
L_00A704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA704u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA704u, 4u, 3u, cpu.address("abs", 0x1B95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A704 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A707;
L_00A707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A707 BEQ -> $00A715
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A715; }
    goto L_00A709;
L_00A709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A709 LDA
    cpu.setA(0x8u, 8);
    goto L_00A70B;
L_00A70B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A70B STA
    hw.write(cpu.address("dp", 0x71u), cpu.a, cpu.m8?8:16);
    goto L_00A70D;
L_00A70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A70D LDA
    cpu.setA(0xA0u, 8);
    goto L_00A70F;
L_00A70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A70F STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00A711;
L_00A711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A711 LDA
    cpu.setA(0x90u, 8);
    goto L_00A713;
L_00A713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A713 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00A715;
L_00A715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA715u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA715u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A715 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A715u);return;} hw.unresolvedReturn(0x00A715u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00A716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA716u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA716u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A716 CMP
    cpu.compareA(0x6u);
    goto L_00A718;
L_00A718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA718u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA718u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A718 BCC -> $00A740
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00A740; }
    goto L_00A71A;
L_00A71A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A71A BNE -> $00A734
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A734; }
    goto L_00A71C;
L_00A71C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Cu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A71C STY
    hw.write(cpu.address("dp", 0x76u), cpu.y, cpu.x8?8:16);
    goto L_00A71E;
L_00A71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu, 4u, 3u, cpu.address("abs", 0x13DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A71E STY
    hw.write(cpu.address("abs", 0x13DFu), cpu.y, cpu.x8?8:16);
    goto L_00A721;
L_00A721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A721 LDA
    cpu.setA(0xFFu, 8);
    goto L_00A723;
L_00A723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA723u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA723u, 4u, 3u, cpu.address("abs", 0x1419u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A723 STA
    hw.write(cpu.address("abs", 0x1419u), cpu.a, cpu.m8?8:16);
    goto L_00A726;
L_00A726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA726u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA726u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A726 LDA
    cpu.setA(0x8u, 8);
    goto L_00A728;
L_00A728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA728u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA728u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A728 TSB
    cpu.tsb(hw, cpu.address("dp", 0x94u), cpu.m8?8:16);
    goto L_00A72A;
L_00A72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A72A LDA
    cpu.setA(0x2u, 8);
    goto L_00A72C;
L_00A72C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Cu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A72C TSB
    cpu.tsb(hw, cpu.address("dp", 0x96u), cpu.m8?8:16);
    goto L_00A72E;
L_00A72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A72E LDX
    cpu.setX(0x7u, 8);
    goto L_00A730;
L_00A730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA730u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA730u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A730 LDY
    cpu.setY(0x20u, 8);
    goto L_00A732;
L_00A732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA732u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA732u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A732 BRA -> $00A6C7
    hw.addCpuInternalCycles(1u); // penalidade de page-cross em emulacao
    goto L_00A6C7;
L_00A734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA734u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA734u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A734 STY
    hw.write(cpu.address("dp", 0x85u), cpu.y, cpu.x8?8:16);
    goto L_00A736;
L_00A736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA736u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA736u, 4u, 3u, cpu.address("abs", 0x13CFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A736 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13CFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A739;
L_00A739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA739u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA739u, 4u, 3u, cpu.address("abs", 0x1434u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A739 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x1434u), cpu.m8?8:16));
    goto L_00A73C;
L_00A73C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA73Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A73C BNE -> $00A6E0
    if (!cpu.z) { hw.addCpuInternalCycles(2u); goto L_00A6E0; }
    goto L_00A73E;
L_00A73E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA73Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A73E LDA
    cpu.setA(0x4u, 8);
    goto L_00A740;
L_00A740:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA740u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA740u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA740u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A740 CLC
    cpu.setFlag('C', false);
    goto L_00A741;
L_00A741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA741u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA741u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A741 ADC
    cpu.adc(0x3u);
    goto L_00A743;
L_00A743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA743u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA743u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A743 STA
    hw.write(cpu.address("dp", 0x89u), cpu.a, cpu.m8?8:16);
    goto L_00A745;
L_00A745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA745u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA745u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A745 TAY
    cpu.transfer("TAY");
    goto L_00A746;
L_00A746:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA746u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA746u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA746u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A746 LSR
    cpu.lsrA();
    goto L_00A747;
L_00A747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA747u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA747u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A747 DEC
    cpu.decReg('A');
    goto L_00A748;
L_00A748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA748u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA748u, 4u, 3u, cpu.address("abs", 0x1419u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A748 STA
    hw.write(cpu.address("abs", 0x1419u), cpu.a, cpu.m8?8:16);
    goto L_00A74B;
L_00A74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Bu, 4u + ((((0xA609u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA609u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A74B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA609u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A74E;
L_00A74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA74Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A74E STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_00A750;
L_00A750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA750u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA750u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A750 LDX
    cpu.setX(0x5u, 8);
    goto L_00A752;
L_00A752:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA752u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA752u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA752u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A752 CPY
    cpu.compareY(0x6u);
    goto L_00A754;
L_00A754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA754u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA754u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A754 BCC -> $00A768
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00A768; }
    goto L_00A756;
L_00A756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA756u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA756u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A756 LDA
    cpu.setA(0x8u, 8);
    goto L_00A758;
L_00A758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA758u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA758u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A758 TSB
    cpu.tsb(hw, cpu.address("dp", 0x94u), cpu.m8?8:16);
    goto L_00A75A;
L_00A75A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A75A LDX
    cpu.setX(0x6u, 8);
    goto L_00A75C;
L_00A75C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Cu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A75C CPY
    cpu.compareY(0x7u);
    goto L_00A75E;
L_00A75E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A75E LDY
    cpu.setY(0x1Eu, 8);
    goto L_00A760;
L_00A760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA760u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA760u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA760u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A760 BCC -> $00A76A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00A76A; }
    goto L_00A762;
L_00A762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA762u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA762u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A762 LDY
    cpu.setY(0xFu, 8);
    goto L_00A764;
L_00A764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA764u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA764u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A764 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A766;
L_00A766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA766u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA766u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A766 BEQ -> $00A76A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A76A; }
    goto L_00A768;
L_00A768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA768u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA768u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A768 LDY
    cpu.setY(0x1Cu, 8);
    goto L_00A76A;
L_00A76A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA76Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Au,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A76A STY
    hw.write(cpu.address("dp", 0x7Du), cpu.y, cpu.x8?8:16);
    goto L_00A76C;
L_00A76C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA76Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Cu, 6u, 3u, cpu.address("abs", 0xA6C7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A76C JSR -> $00A6C7 stack real
    { cpu.push16Value(hw,0xA76Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA76Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6C7u), 0x00A76Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A76F;
L_00A76F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA76Fu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA76Fu,0x00A76Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Fu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A76F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A772;
L_00A772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA772u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA772u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A772 BEQ -> $00A795
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A795; }
    goto L_00A774;
L_00A774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA774u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA774u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A774 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x89u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00A776;
L_00A776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA776u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA776u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A776 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A778;
L_00A778:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA778u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA778u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA778u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A778 CLC
    cpu.setFlag('C', false);
    goto L_00A779;
L_00A779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA779u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA779u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA779u, 4u + ((((0xA61Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA61Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A779 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xA61Du), cpu.m8?8:16));
    goto L_00A77C;
L_00A77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A77C STA
    hw.write(cpu.address("dp", 0x88u), cpu.a, cpu.m8?8:16);
    goto L_00A77E;
L_00A77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A77E TXA
    cpu.transfer("TXA");
    goto L_00A77F;
L_00A77F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A77F ASL
    cpu.aslA();
    goto L_00A780;
L_00A780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA780u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA780u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A780 TAX
    cpu.transfer("TAX");
    goto L_00A781;
L_00A781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA781u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA781u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A781 REP
    cpu.rep(0x20u);
    goto L_00A783;
L_00A783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA783u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA783u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A783 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A785;
L_00A785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA785u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA785u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A785 CLC
    cpu.setFlag('C', false);
    goto L_00A786;
L_00A786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA786u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA786u, 5u + ((((0xA609u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA609u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A786 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xA609u), cpu.m8?8:16));
    goto L_00A789;
L_00A789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA789u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA789u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A789 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00A78B;
L_00A78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A78B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A78D;
L_00A78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A78D CLC
    cpu.setFlag('C', false);
    goto L_00A78E;
L_00A78E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA78Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Eu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Eu, 5u + ((((0xA611u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA611u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A78E ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xA611u), cpu.m8?8:16));
    goto L_00A791;
L_00A791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA791u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA791u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A791 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00A793;
L_00A793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA793u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA793u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A793 SEP
    cpu.sep(0x20u);
    goto L_00A795;
L_00A795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA795u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA795u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A795 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A795u);return;} hw.unresolvedReturn(0x00A795u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00A82D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A82Du: goto L_00A82D;
    case 0x00A82Fu: goto L_00A82F;
    case 0x00A833u: goto L_00A833;
    case 0x00A836u: goto L_00A836;
    case 0x00A838u: goto L_00A838;
    case 0x00A83Au: goto L_00A83A;
    case 0x00A83Cu: goto L_00A83C;
    case 0x00A83Du: goto L_00A83D;
    case 0x00A840u: goto L_00A840;
    case 0x00A842u: goto L_00A842;
    case 0x00A845u: goto L_00A845;
    case 0x00A848u: goto L_00A848;
    case 0x00A84Au: goto L_00A84A;
    case 0x00A84Eu: goto L_00A84E;
    case 0x00A84Fu: goto L_00A84F;
    case 0x00A850u: goto L_00A850;
    case 0x00A852u: goto L_00A852;
    case 0x00A854u: goto L_00A854;
    case 0x00A855u: goto L_00A855;
    case 0x00A857u: goto L_00A857;
    case 0x00A85Au: goto L_00A85A;
    case 0x00A85Cu: goto L_00A85C;
    case 0x00A85Fu: goto L_00A85F;
    case 0x00A863u: goto L_00A863;
    case 0x00A864u: goto L_00A864;
    case 0x00A865u: goto L_00A865;
    case 0x00A867u: goto L_00A867;
    case 0x00A868u: goto L_00A868;
    case 0x00A86Au: goto L_00A86A;
    case 0x00A86Du: goto L_00A86D;
    case 0x00A86Fu: goto L_00A86F;
    case 0x00A871u: goto L_00A871;
    case 0x00A873u: goto L_00A873;
    case 0x00A877u: goto L_00A877;
    case 0x00A879u: goto L_00A879;
    case 0x00A87Cu: goto L_00A87C;
    case 0x00A87Eu: goto L_00A87E;
    case 0x00A881u: goto L_00A881;
    case 0x00A883u: goto L_00A883;
    case 0x00A886u: goto L_00A886;
    case 0x00A889u: goto L_00A889;
    case 0x00A88Bu: goto L_00A88B;
    case 0x00A88Eu: goto L_00A88E;
    case 0x00A88Fu: goto L_00A88F;
    case 0x00A890u: goto L_00A890;
    case 0x00A892u: goto L_00A892;
    case 0x00A894u: goto L_00A894;
    case 0x00A895u: goto L_00A895;
    case 0x00A897u: goto L_00A897;
    case 0x00A89Au: goto L_00A89A;
    case 0x00A89Cu: goto L_00A89C;
    case 0x00A89Fu: goto L_00A89F;
    case 0x00A8A2u: goto L_00A8A2;
    case 0x00A8A3u: goto L_00A8A3;
    case 0x00A8A4u: goto L_00A8A4;
    case 0x00A8A6u: goto L_00A8A6;
    case 0x00A8A7u: goto L_00A8A7;
    case 0x00A8A9u: goto L_00A8A9;
    case 0x00A8ACu: goto L_00A8AC;
    case 0x00A8AEu: goto L_00A8AE;
    case 0x00A8B1u: goto L_00A8B1;
    case 0x00A8B3u: goto L_00A8B3;
    case 0x00A8B6u: goto L_00A8B6;
    case 0x00A8B8u: goto L_00A8B8;
    case 0x00A8BAu: goto L_00A8BA;
    case 0x00A8BCu: goto L_00A8BC;
    case 0x00A8BFu: goto L_00A8BF;
    case 0x00A8C2u: goto L_00A8C2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A82D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA82Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A82D LDY
    cpu.setY(0xFu, 8);
    goto L_00A82F;
L_00A82F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA82Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Fu, 8u, 4u, 0x00BA28u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A82F JSL -> $00BA28 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA832u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA833u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00BA28u, 0x00A82Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A833;
L_00A833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA833u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA833u,0x00A833u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA833u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA833u, 4u, 3u, cpu.address("abs", 0x1425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A833 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1425u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A836;
L_00A836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA836u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA836u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A836 REP
    cpu.rep(0x30u);
    goto L_00A838;
L_00A838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA838u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA838u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A838 BEQ -> $00A842
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A842; }
    goto L_00A83A;
L_00A83A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA83Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A83A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A83C;
L_00A83C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA83Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A83C CLC
    cpu.setFlag('C', false);
    goto L_00A83D;
L_00A83D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA83Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A83D ADC
    cpu.adc(0x30u);
    goto L_00A840;
L_00A840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA840u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA840u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A840 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00A842;
L_00A842:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA842u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA842u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA842u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A842 LDX
    cpu.setX(0x0u, 16);
    goto L_00A845;
L_00A845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA845u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA845u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A845 LDY
    cpu.setY(0x8u, 16);
    goto L_00A848;
L_00A848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA848u,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA848u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00A848 LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A84A;
L_00A84A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Au,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Au, 6u, 4u, ((0x7F977Bu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A84A STA
    hw.write(((0x7F977Bu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_00A84E;
L_00A84E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A84E INX
    cpu.inc('X');
    goto L_00A84F;
L_00A84F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A84F INX
    cpu.inc('X');
    goto L_00A850;
L_00A850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA850u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA850u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA850u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A850 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_00A852;
L_00A852:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA852u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA852u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA852u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A852 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_00A854;
L_00A854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA854u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA854u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A854 DEY
    cpu.decReg('Y');
    goto L_00A855;
L_00A855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A855 BNE -> $00A848
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A848; }
    goto L_00A857;
L_00A857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA857u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA857u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A857 LDY
    cpu.setY(0x8u, 16);
    goto L_00A85A;
L_00A85A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Au,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00A85A LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A85C;
L_00A85C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A85C AND
    cpu.logicAnd(0xFFu);
    goto L_00A85F;
L_00A85F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Fu, 6u, 4u, ((0x7F977Bu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A85F STA
    hw.write(((0x7F977Bu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_00A863;
L_00A863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA863u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA863u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A863 INX
    cpu.inc('X');
    goto L_00A864;
L_00A864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA864u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA864u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA864u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A864 INX
    cpu.inc('X');
    goto L_00A865;
L_00A865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA865u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA865u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A865 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_00A867;
L_00A867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA867u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA867u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A867 DEY
    cpu.decReg('Y');
    goto L_00A868;
L_00A868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA868u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA868u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A868 BNE -> $00A85A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A85A; }
    goto L_00A86A;
L_00A86A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Au,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A86A CPX
    cpu.compareX(0x300u);
    goto L_00A86D;
L_00A86D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A86D BCC -> $00A845
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00A845; }
    goto L_00A86F;
L_00A86F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A86F SEP
    cpu.sep(0x30u);
    goto L_00A871;
L_00A871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA871u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA871u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA871u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A871 LDY
    cpu.setY(0x0u, 8);
    goto L_00A873;
L_00A873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA873u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA873u, 8u, 4u, 0x00BA28u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A873 JSL -> $00BA28 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA876u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA877u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00BA28u, 0x00A873u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A877;
L_00A877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA877u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA877u,0x00A877u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA877u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA877u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A877 REP
    cpu.rep(0x30u);
    goto L_00A879;
L_00A879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA879u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA879u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A879 LDA
    cpu.setA(0xB3F0u, 16);
    goto L_00A87C;
L_00A87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A87C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00A87E;
L_00A87E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A87E LDA
    cpu.setA(0x7EB3u, 16);
    goto L_00A881;
L_00A881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA881u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA881u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A881 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_00A883;
L_00A883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA883u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA883u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA883u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A883 LDX
    cpu.setX(0x0u, 16);
    goto L_00A886;
L_00A886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA886u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA886u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA886u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A886 LDY
    cpu.setY(0x8u, 16);
    goto L_00A889;
L_00A889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA889u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA889u,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA889u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00A889 LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A88B;
L_00A88B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Bu, 6u, 3u, cpu.address("absx", 0x0BF6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A88B STA
    hw.write(cpu.address("absx", 0xBF6u), cpu.a, cpu.m8?8:16);
    goto L_00A88E;
L_00A88E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A88E INX
    cpu.inc('X');
    goto L_00A88F;
L_00A88F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A88F INX
    cpu.inc('X');
    goto L_00A890;
L_00A890:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA890u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA890u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA890u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A890 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_00A892;
L_00A892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA892u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA892u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A892 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_00A894;
L_00A894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA894u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA894u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A894 DEY
    cpu.decReg('Y');
    goto L_00A895;
L_00A895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA895u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA895u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA895u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A895 BNE -> $00A889
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A889; }
    goto L_00A897;
L_00A897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A897 LDY
    cpu.setY(0x8u, 16);
    goto L_00A89A;
L_00A89A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Au,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00A89A LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A89C;
L_00A89C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A89C AND
    cpu.logicAnd(0xFFu);
    goto L_00A89F;
L_00A89F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Fu, 6u, 3u, cpu.address("absx", 0x0BF6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A89F STA
    hw.write(cpu.address("absx", 0xBF6u), cpu.a, cpu.m8?8:16);
    goto L_00A8A2;
L_00A8A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A8A2 INX
    cpu.inc('X');
    goto L_00A8A3;
L_00A8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A8A3 INX
    cpu.inc('X');
    goto L_00A8A4;
L_00A8A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A4u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A8A4 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_00A8A6;
L_00A8A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A6u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A8A6 DEY
    cpu.decReg('Y');
    goto L_00A8A7;
L_00A8A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A8A7 BNE -> $00A89A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A89A; }
    goto L_00A8A9;
L_00A8A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A9u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A8A9 CPX
    cpu.compareX(0xC0u);
    goto L_00A8AC;
L_00A8AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ACu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A8AC BNE -> $00A8B3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A8B3; }
    goto L_00A8AE;
L_00A8AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8AEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A8AE LDA
    cpu.setA(0xB570u, 16);
    goto L_00A8B1;
L_00A8B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A8B1 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00A8B3;
L_00A8B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B3u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A8B3 CPX
    cpu.compareX(0x180u);
    goto L_00A8B6;
L_00A8B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A8B6 BCC -> $00A886
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00A886; }
    goto L_00A8B8;
L_00A8B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A8B8 SEP
    cpu.sep(0x30u);
    goto L_00A8BA;
L_00A8BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A8BA LDA
    cpu.setA(0x1u, 8);
    goto L_00A8BC;
L_00A8BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BCu, 4u, 3u, cpu.address("abs", 0x143Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A8BC STA
    hw.write(cpu.address("abs", 0x143Au), cpu.a, cpu.m8?8:16);
    goto L_00A8BF;
L_00A8BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BFu, 4u, 3u, cpu.address("abs", 0x1935u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A8BF STA
    hw.write(cpu.address("abs", 0x1935u), cpu.a, cpu.m8?8:16);
    goto L_00A8C2;
L_00A8C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A8C2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A8C2u);return;} hw.unresolvedReturn(0x00A8C2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00CC68_E0M1X1CQ_part9(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00DC16u: goto L_00DC16;
    case 0x00DC18u: goto L_00DC18;
    case 0x00DC1Au: goto L_00DC1A;
    case 0x00DC1Du: goto L_00DC1D;
    case 0x00DC1Fu: goto L_00DC1F;
    case 0x00DC20u: goto L_00DC20;
    case 0x00DC22u: goto L_00DC22;
    case 0x00DC24u: goto L_00DC24;
    case 0x00DC25u: goto L_00DC25;
    case 0x00DC26u: goto L_00DC26;
    case 0x00DC27u: goto L_00DC27;
    case 0x00DC28u: goto L_00DC28;
    case 0x00DC29u: goto L_00DC29;
    case 0x00DC2Au: goto L_00DC2A;
    case 0x00DC2Bu: goto L_00DC2B;
    case 0x00DC2Cu: goto L_00DC2C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00DC16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC16u))return;
  // 14 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC16 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00DC18;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC16 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00DC18;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC16 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00DC18;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC16 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00DC18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC16u,0x00DC16u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC18u))return;
  // 14 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC18 BEQ -> $00DC2C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DC2C; }
    goto L_00DC1A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC18 BEQ -> $00DC2C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DC2C; }
    goto L_00DC1A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC18 BEQ -> $00DC2C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DC2C; }
    goto L_00DC1A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC18 BEQ -> $00DC2C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DC2C; }
    goto L_00DC1A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC18u,0x00DC18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Au))return;
  // 14 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au, 5u, 3u, cpu.address("abs", 0x1496u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1496u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC1D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1496u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC1D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1496u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC1D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1496u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC1D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC1Au,0x00DC1Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Du))return;
  // 14 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1D ORA
    cpu.logicOr(0x8D08u);
    goto L_00DC20;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1D ORA
    cpu.logicOr(0x8u);
    goto L_00DC1F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1D ORA
    cpu.logicOr(0x8u);
    goto L_00DC1F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1D ORA
    cpu.logicOr(0x8u);
    goto L_00DC1F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC1Du,0x00DC1Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1F STA
    hw.write(cpu.address("abs", 0x1496u), cpu.a, cpu.m8?8:16);
    goto L_00DC22;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1F STA
    hw.write(cpu.address("abs", 0x1496u), cpu.a, cpu.m8?8:16);
    goto L_00DC22;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC1F STA
    hw.write(cpu.address("abs", 0x1496u), cpu.a, cpu.m8?8:16);
    goto L_00DC22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC1Fu,0x00DC1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC20u))return;
  // 11 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC20u,cpu,0x96u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpy", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC20 STX
    hw.write(cpu.address("dpy", 0x14u), cpu.x, cpu.x8?8:16);
    goto L_00DC22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC20u,0x00DC20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC22u))return;
  // 14 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC22 AND
    cpu.logicAnd(0xD007u);
    goto L_00DC25;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC22 AND
    cpu.logicAnd(0x7u);
    goto L_00DC24;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC22 AND
    cpu.logicAnd(0x7u);
    goto L_00DC24;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC22 AND
    cpu.logicAnd(0x7u);
    goto L_00DC24;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC22u,0x00DC22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC24u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC24u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC24 BNE -> $00DC2C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DC2C; }
    goto L_00DC26;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC24u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC24 BNE -> $00DC2C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DC2C; }
    goto L_00DC26;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC24u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC24 BNE -> $00DC2C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DC2C; }
    goto L_00DC26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC24u,0x00DC24u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC25u))return;
  // 11 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC25u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC25u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA5u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC25 ASL
    cpu.aslMem(hw, cpu.address("dp", 0xA5u), cpu.m8?8:16);
    goto L_00DC27;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC25u,0x00DC25u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC26u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC26 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC28;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC26 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC28;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC26 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC28;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC26u,0x00DC26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC27u))return;
  // 11 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC27u,cpu,0x76u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC27u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x49u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC27 ROR
    cpu.rorMem(hw, cpu.address("dpx", 0x49u), cpu.m8?8:16);
    goto L_00DC29;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC27u,0x00DC27u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC28u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC28u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC28 EOR
    cpu.logicXor(0x1u);
    goto L_00DC2A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC28u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC28 EOR
    cpu.logicXor(0x1u);
    goto L_00DC2A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC28u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC28 EOR
    cpu.logicXor(0x1u);
    goto L_00DC2A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC28u,0x00DC28u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC29u))return;
  // 11 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC29u,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC29u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x85u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00DC29 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0x85u), cpu.m8?8:16));
    goto L_00DC2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC29u,0x00DC29u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC2A STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_00DC2C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC2A STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_00DC2C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC2A STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_00DC2C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC2Au,0x00DC2Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Bu))return;
  // 11 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Bu,cpu,0x76u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Bu, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x60u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC2B ROR
    cpu.rorMem(hw, cpu.address("dpx", 0x60u), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC2Du,0x00DC2Bu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC2Bu,0x00DC2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Cu))return;
  // 14 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC2C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DC2Cu);return;} hw.unresolvedReturn(0x00DC2Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC2C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DC2Cu);return;} hw.unresolvedReturn(0x00DC2Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC2C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DC2Cu);return;} hw.unresolvedReturn(0x00DC2Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC2C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DC2Cu);return;} hw.unresolvedReturn(0x00DC2Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC2Cu,0x00DC2Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EE1D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EE1Du: goto L_00EE1D;
    case 0x00EE20u: goto L_00EE20;
    case 0x00EE22u: goto L_00EE22;
    case 0x00EE24u: goto L_00EE24;
    case 0x00EE26u: goto L_00EE26;
    case 0x00EE28u: goto L_00EE28;
    case 0x00EE2Au: goto L_00EE2A;
    case 0x00EE2Du: goto L_00EE2D;
    case 0x00EE2Fu: goto L_00EE2F;
    case 0x00EE31u: goto L_00EE31;
    case 0x00EE33u: goto L_00EE33;
    case 0x00EE35u: goto L_00EE35;
    case 0x00EE37u: goto L_00EE37;
    case 0x00EE39u: goto L_00EE39;
    case 0x00EEE1u: goto L_00EEE1;
    case 0x00EEE4u: goto L_00EEE4;
    case 0x00EEE6u: goto L_00EEE6;
    case 0x00EEE9u: goto L_00EEE9;
    case 0x00EEEBu: goto L_00EEEB;
    case 0x00EEEDu: goto L_00EEED;
    case 0x00EEEFu: goto L_00EEEF;
    case 0x00EEF2u: goto L_00EEF2;
    case 0x00EEF4u: goto L_00EEF4;
    case 0x00EEF6u: goto L_00EEF6;
    case 0x00EEF8u: goto L_00EEF8;
    case 0x00EEFBu: goto L_00EEFB;
    case 0x00EEFEu: goto L_00EEFE;
    case 0x00EF00u: goto L_00EF00;
    case 0x00EF02u: goto L_00EF02;
    case 0x00EF05u: goto L_00EF05;
    case 0x00EF08u: goto L_00EF08;
    case 0x00EF0Bu: goto L_00EF0B;
    case 0x00EF0Du: goto L_00EF0D;
    case 0x00EF0Fu: goto L_00EF0F;
    case 0x00EF11u: goto L_00EF11;
    case 0x00EF13u: goto L_00EF13;
    case 0x00EF16u: goto L_00EF16;
    case 0x00EF18u: goto L_00EF18;
    case 0x00EF1Au: goto L_00EF1A;
    case 0x00EF1Cu: goto L_00EF1C;
    case 0x00EF1Fu: goto L_00EF1F;
    case 0x00EF21u: goto L_00EF21;
    case 0x00EF23u: goto L_00EF23;
    case 0x00EF25u: goto L_00EF25;
    case 0x00EF26u: goto L_00EF26;
    case 0x00EF28u: goto L_00EF28;
    case 0x00EF2Au: goto L_00EF2A;
    case 0x00EF2Du: goto L_00EF2D;
    case 0x00EF2Fu: goto L_00EF2F;
    case 0x00EF31u: goto L_00EF31;
    case 0x00EF33u: goto L_00EF33;
    case 0x00EF36u: goto L_00EF36;
    case 0x00EF38u: goto L_00EF38;
    case 0x00EF3Bu: goto L_00EF3B;
    case 0x00EF3Du: goto L_00EF3D;
    case 0x00EF3Fu: goto L_00EF3F;
    case 0x00EF42u: goto L_00EF42;
    case 0x00EF43u: goto L_00EF43;
    case 0x00EF45u: goto L_00EF45;
    case 0x00EF48u: goto L_00EF48;
    case 0x00EF4Bu: goto L_00EF4B;
    case 0x00EF4Du: goto L_00EF4D;
    case 0x00EF50u: goto L_00EF50;
    case 0x00EF51u: goto L_00EF51;
    case 0x00EF54u: goto L_00EF54;
    case 0x00EF55u: goto L_00EF55;
    case 0x00EF56u: goto L_00EF56;
    case 0x00EF58u: goto L_00EF58;
    case 0x00EF5Au: goto L_00EF5A;
    case 0x00EF5Cu: goto L_00EF5C;
    case 0x00EF5Du: goto L_00EF5D;
    case 0x00EF5Eu: goto L_00EF5E;
    case 0x00EF60u: goto L_00EF60;
    case 0x00EF62u: goto L_00EF62;
    case 0x00EF63u: goto L_00EF63;
    case 0x00EF65u: goto L_00EF65;
    case 0x00EF68u: goto L_00EF68;
    case 0x00EF6Bu: goto L_00EF6B;
    case 0x00EF6Du: goto L_00EF6D;
    case 0x00EF6Fu: goto L_00EF6F;
    case 0x00EF72u: goto L_00EF72;
    case 0x00EF75u: goto L_00EF75;
    case 0x00EF77u: goto L_00EF77;
    case 0x00EF79u: goto L_00EF79;
    case 0x00EF7Cu: goto L_00EF7C;
    case 0x00EF7Eu: goto L_00EF7E;
    case 0x00EF81u: goto L_00EF81;
    case 0x00EF83u: goto L_00EF83;
    case 0x00EF85u: goto L_00EF85;
    case 0x00EF87u: goto L_00EF87;
    case 0x00EF8Au: goto L_00EF8A;
    case 0x00EF8Cu: goto L_00EF8C;
    case 0x00EF90u: goto L_00EF90;
    case 0x00EF92u: goto L_00EF92;
    case 0x00EF95u: goto L_00EF95;
    case 0x00EF98u: goto L_00EF98;
    case 0x00EF99u: goto L_00EF99;
    case 0x00EF9Cu: goto L_00EF9C;
    case 0x00EF9Fu: goto L_00EF9F;
    case 0x00EFA1u: goto L_00EFA1;
    case 0x00EFA3u: goto L_00EFA3;
    case 0x00EFA5u: goto L_00EFA5;
    case 0x00EFA7u: goto L_00EFA7;
    case 0x00EFA9u: goto L_00EFA9;
    case 0x00EFAAu: goto L_00EFAA;
    case 0x00EFADu: goto L_00EFAD;
    case 0x00EFAEu: goto L_00EFAE;
    case 0x00EFB0u: goto L_00EFB0;
    case 0x00EFB2u: goto L_00EFB2;
    case 0x00EFB6u: goto L_00EFB6;
    case 0x00EFB8u: goto L_00EFB8;
    case 0x00EFBBu: goto L_00EFBB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE20;
L_00EE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE20 BEQ -> $00EE2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE2D; }
    goto L_00EE22;
L_00EE22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE24;
L_00EE24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE24 BMI -> $00EE2D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EE2D; }
    goto L_00EE26;
L_00EE26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE26 STZ
    hw.write(cpu.address("dp", 0x8Eu), 0, cpu.m8?8:16);
    goto L_00EE28;
L_00EE28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE28u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE28 LDY
    cpu.setY(0x20u, 8);
    goto L_00EE2A;
L_00EE2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Au, 3u, 3u, cpu.address("abs", 0xEEE1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2A JMP -> $00EEE1
    goto L_00EEE1;
L_00EE2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE2F;
L_00EE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2F AND
    cpu.logicAnd(0x4u);
    goto L_00EE31;
L_00EE31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE31u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE31u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE31 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16));
    goto L_00EE33;
L_00EE33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE33u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE33 BNE -> $00EE39
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE39; }
    goto L_00EE35;
L_00EE35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE35u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE35 LDA
    cpu.setA(0x24u, 8);
    goto L_00EE37;
L_00EE37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE37u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE37u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE37 STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00EE39;
L_00EE39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE39u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE39u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE39 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EE39u);return;} hw.unresolvedReturn(0x00EE39u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00EEE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE1u, 4u + ((((0xE53Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE53Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE53Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEE4;
L_00EEE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE4 BNE -> $00EEEF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EEEF; }
    goto L_00EEE6;
L_00EEE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE6 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13EDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEE9;
L_00EEE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEE9 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF05; }
    goto L_00EEEB;
L_00EEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EEED;
L_00EEED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEED BEQ -> $00EF02
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF02; }
    goto L_00EEEF;
L_00EEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 4u, 3u, cpu.address("abs", 0x13EEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEEF STA
    hw.write(cpu.address("abs", 0x13EEu), cpu.a, cpu.m8?8:16);
    goto L_00EEF2;
L_00EEF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEF4;
L_00EEF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF4 AND
    cpu.logicAnd(0x4u);
    goto L_00EEF6;
L_00EEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF6 BEQ -> $00EF05
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF05; }
    goto L_00EEF8;
L_00EEF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF8u, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEF8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EEFB;
L_00EEFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFBu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFBu, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEFB ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13EDu), cpu.m8?8:16));
    goto L_00EEFE;
L_00EEFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEFE BNE -> $00EF05
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF05; }
    goto L_00EF00;
L_00EF00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF00u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF00 LDX
    cpu.setX(0x1Cu, 8);
    goto L_00EF02;
L_00EF02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF02u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF02u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF02 STX
    hw.write(cpu.address("abs", 0x13EDu), cpu.x, cpu.x8?8:16);
    goto L_00EF05;
L_00EF05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF05u, 4u + ((((0xE4B9u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4B9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF05 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xE4B9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF08;
L_00EF08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF08 STX
    hw.write(cpu.address("abs", 0x13E1u), cpu.x, cpu.x8?8:16);
    goto L_00EF0B;
L_00EF0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0B CPY
    cpu.compareY(0x1Cu);
    goto L_00EF0D;
L_00EF0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0D BCS -> $00EF38
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EF38; }
    goto L_00EF0F;
L_00EF0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF0F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF11;
L_00EF11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF11u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF11 BEQ -> $00EF31
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF31; }
    goto L_00EF13;
L_00EF13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF13u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF13u, 4u + ((((0xE53Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE53Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF13 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE53Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF16;
L_00EF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF16u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF16 BEQ -> $00EF31
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF31; }
    goto L_00EF18;
L_00EF18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF18u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF18u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF18 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16));
    goto L_00EF1A;
L_00EF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1A BPL -> $00EF31
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF31; }
    goto L_00EF1C;
L_00EF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Cu, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1C STX
    hw.write(cpu.address("abs", 0x13E5u), cpu.x, cpu.x8?8:16);
    goto L_00EF1F;
L_00EF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF1Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF1F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF21;
L_00EF21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF21 BPL -> $00EF26
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF26; }
    goto L_00EF23;
L_00EF23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF23 EOR
    cpu.logicXor(0xFFu);
    goto L_00EF25;
L_00EF25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF25u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF25 INC
    cpu.inc('A');
    goto L_00EF26;
L_00EF26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF26 CMP
    cpu.compareA(0x28u);
    goto L_00EF28;
L_00EF28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF28u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF28 BCC -> $00EF2F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EF2F; }
    goto L_00EF2A;
L_00EF2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Au, 4u + ((((0xE4FBu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4FBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE4FBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF2D;
L_00EF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2D BRA -> $00EF60
    goto L_00EF60;
L_00EF2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2F LDY
    cpu.setY(0x20u, 8);
    goto L_00EF31;
L_00EF31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF31 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF33;
L_00EF33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u, 4u + ((((0xE4DAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF33 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16));
    goto L_00EF36;
L_00EF36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF36u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF36 BCC -> $00EF3B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EF3B; }
    goto L_00EF38;
L_00EF38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u, 4u + ((((0xE4DAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF38 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF3B;
L_00EF3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF3B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF3D;
L_00EF3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF3D BPL -> $00EF60
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF60; }
    goto L_00EF3F;
L_00EF3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Fu, 6u, 3u, cpu.address("abs", 0x140Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF3F INC
    cpu.incMem(hw, cpu.address("abs", 0x140Eu), cpu.m8?8:16);
    goto L_00EF42;
L_00EF42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EF42 PHA
    cpu.push("PHA", hw);
    goto L_00EF43;
L_00EF43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
L_00EF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u, 5u, 3u, cpu.address("abs", 0x17BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF45 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF48;
L_00EF48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF48 AND
    cpu.logicAnd(0xFF00u);
    goto L_00EF4B;
L_00EF4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF4B BPL -> $00EF50
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF50; }
    goto L_00EF4D;
L_00EF4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF4D ORA
    cpu.logicOr(0xFFu);
    goto L_00EF50;
L_00EF50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF50u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF50u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF50 XBA
    cpu.xba();
    goto L_00EF51;
L_00EF51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF51u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF51u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF51 EOR
    cpu.logicXor(0xFFFFu);
    goto L_00EF54;
L_00EF54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF54 INC
    cpu.inc('A');
    goto L_00EF55;
L_00EF55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF55 CLC
    cpu.setFlag('C', false);
    goto L_00EF56;
L_00EF56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF56u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF56 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_00EF58;
L_00EF58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF58 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00EF5A;
L_00EF5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF5A SEP
    cpu.sep(0x20u);
    goto L_00EF5C;
L_00EF5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Cu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EF5C PLA
    cpu.pop("PLA", hw);
    goto L_00EF5D;
L_00EF5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF5D CLC
    cpu.setFlag('C', false);
    goto L_00EF5E;
L_00EF5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF5E ADC
    cpu.adc(0x28u);
    goto L_00EF60;
L_00EF60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF60 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EF62;
L_00EF62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
L_00EF63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF68; }
    goto L_00EF65;
L_00EF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
L_00EF68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 4u, 3u, cpu.address("abs", 0x18B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
L_00EF6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_00EF6D;
L_00EF6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6D STZ
    hw.write(cpu.address("dp", 0x74u), 0, cpu.m8?8:16);
    goto L_00EF6F;
L_00EF6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu, 4u, 3u, cpu.address("abs", 0x1406u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6F STZ
    hw.write(cpu.address("abs", 0x1406u), 0, cpu.m8?8:16);
    goto L_00EF72;
L_00EF72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF72 STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    goto L_00EF75;
L_00EF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF75 LDA
    cpu.setA(0x4u, 8);
    goto L_00EF77;
L_00EF77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF77u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF77u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF77 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00EF79;
L_00EF79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF79u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF79u, 4u, 3u, cpu.address("abs", 0x1407u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF79 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1407u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF7C;
L_00EF7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7C BNE -> $00EF99
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF99; }
    goto L_00EF7E;
L_00EF7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF81;
L_00EF81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF81 BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF95; }
    goto L_00EF83;
L_00EF83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF83u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF83u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF83 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF85;
L_00EF85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF85u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF85 BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF95; }
    goto L_00EF87;
L_00EF87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF87u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF87u, 4u, 3u, cpu.address("abs", 0x18E7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF87 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18E7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF8A;
L_00EF8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF8A BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF95; }
    goto L_00EF8C;
L_00EF8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu, 8u, 4u, 0x0286BFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EF8C JSL -> $0286BF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEF8Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF90u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0286BFu, 0x00EF8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF90;
L_00EF90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF90u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF90u,0x00EF90u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF90 LDA
    cpu.setA(0x25u, 8);
    goto L_00EF92;
L_00EF92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF92u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF92 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00EF95;
L_00EF95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
L_00EF98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00EF99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF99u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF99u, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF99 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF9C;
L_00EF9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF9Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF9Cu, 4u, 3u, cpu.address("abs", 0x1407u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF9C STZ
    hw.write(cpu.address("abs", 0x1407u), 0, cpu.m8?8:16);
    goto L_00EF9F;
L_00EF9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF9Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF9F CPY
    cpu.compareY(0x5u);
    goto L_00EFA1;
L_00EFA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA1u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFA1 BCS -> $00EFAE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EFAE; }
    goto L_00EFA3;
L_00EFA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFA3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EFA5;
L_00EFA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFA5 CMP
    cpu.compareA(0x2u);
    goto L_00EFA7;
L_00EFA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFA7 BNE -> $00EFAD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EFAD; }
    goto L_00EFA9;
L_00EFA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFA9 SEC
    cpu.setFlag('C', true);
    goto L_00EFAA;
L_00EFAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAAu,cpu,0x6Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAAu, 6u, 3u, cpu.address("abs", 0x13EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFAA ROR
    cpu.rorMem(hw, cpu.address("abs", 0x13EDu), cpu.m8?8:16);
    goto L_00EFAD;
L_00EFAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFAD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFADu);return;} hw.unresolvedReturn(0x00EFADu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00EFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EFB0;
L_00EFB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB0 BEQ -> $00EFBB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EFBB; }
    goto L_00EFB2;
L_00EFB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u, 8u, 4u, 0x0294C1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EFB2 JSL -> $0294C1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEFB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFB6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0294C1u, 0x00EFB2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EFB6;
L_00EFB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB6u,0x00EFB6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB6 LDA
    cpu.setA(0x9u, 8);
    goto L_00EFB8;
L_00EFB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB8u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB8 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00EFBB;
L_00EFBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFBB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFBBu);return;} hw.unresolvedReturn(0x00EFBBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00EADB_E0M1X1CQ_part23(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF2Du: goto L_00EF2D;
    case 0x00EF2Eu: goto L_00EF2E;
    case 0x00EF2Fu: goto L_00EF2F;
    case 0x00EF30u: goto L_00EF30;
    case 0x00EF31u: goto L_00EF31;
    case 0x00EF32u: goto L_00EF32;
    case 0x00EF33u: goto L_00EF33;
    case 0x00EF35u: goto L_00EF35;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Du))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2D BRA -> $00EF60
    hw.requestDispatch(0x00EF60u,0x00EF2Du); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2D BRA -> $00EF60
    hw.requestDispatch(0x00EF60u,0x00EF2Du); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF2Du,0x00EF2Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Eu))return;
  // 21 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Eu,cpu,0x31u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Eu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xA0u) & 0xFFFFu), 2u, 0u);
    // $00EF2E AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirectY(hw, 0xA0u), cpu.m8?8:16));
    goto L_00EF30;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Eu,cpu,0x31u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Eu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xA0u) & 0xFFFFu), 2u, 0u);
    // $00EF2E AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirectY(hw, 0xA0u), cpu.m8?8:16));
    goto L_00EF30;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Eu,cpu,0x31u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xA0u) & 0xFFFFu), 2u, 0u);
    // $00EF2E AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirectY(hw, 0xA0u), cpu.m8?8:16));
    goto L_00EF30;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF2Eu,0x00EF2Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Fu))return;
  // 16 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2F LDY
    cpu.setY(0xA520u, 16);
    goto L_00EF32;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2F LDY
    cpu.setY(0x20u, 8);
    goto L_00EF31;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF2Fu,0x00EF2Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF30u))return;
  // 21 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF30u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF30u, 6u, 3u, cpu.address("abs", 0x7DA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF30 JSR -> $007DA5 stack real
    { cpu.push16Value(hw,0xEF32u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF33u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x7DA5u), 0x00EF30u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF33;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF30u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF30u, 6u, 3u, cpu.address("abs", 0x7DA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF30 JSR -> $007DA5 stack real
    { cpu.push16Value(hw,0xEF32u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF33u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x7DA5u), 0x00EF30u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF33;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF30u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF30u, 6u, 3u, cpu.address("abs", 0x7DA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF30 JSR -> $007DA5 stack real
    { cpu.push16Value(hw,0xEF32u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF33u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x7DA5u), 0x00EF30u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF33;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF30u,0x00EF30u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF31u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF31 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF33;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF31 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF33;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF31 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF33;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF31 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF33;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF31u,0x00EF31u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF32u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF32u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF32u, 4u + 1u, 3u, cpu.address("absx", 0xDAD9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF32 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xDAD9u), cpu.m8?8:16));
    goto L_00EF35;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF32u,0x00EF32u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF33u))return;
  // 37 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u, 5u + 1u, 3u, cpu.address("absy", 0xE4DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF33 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF36u,0x00EF33u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u, 5u + ((((0xE4DAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF33 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF36u,0x00EF33u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u, 4u + 1u, 3u, cpu.address("absy", 0xE4DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF33 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF36u,0x00EF33u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u, 4u + ((((0xE4DAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF33 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF36u,0x00EF33u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u, 4u + ((((0xE4DAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF33 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF36u,0x00EF33u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF33u,0x00EF33u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF35u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF35u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF35u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF35 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x90u), cpu.x8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF37u,0x00EF35u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF35u,0x00EF35u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1C1_part28(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF65u: goto L_00EF65;
    case 0x00EF68u: goto L_00EF68;
    case 0x00EF6Bu: goto L_00EF6B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF65u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF65u,0x00EF65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF68u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 5u, 3u, cpu.address("abs", 0x18B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 5u, 3u, cpu.address("abs", 0x18B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 4u, 3u, cpu.address("abs", 0x18B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 4u, 3u, cpu.address("abs", 0x18B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 4u, 3u, cpu.address("abs", 0x18B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF68u,0x00EF68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF6Bu))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Du,0x00EF6Bu); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Du,0x00EF6Bu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Du,0x00EF6Bu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Du,0x00EF6Bu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Du,0x00EF6Bu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,0x00EF6Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part28(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF65u: goto L_00EF65;
    case 0x00EF68u: goto L_00EF68;
    case 0x00EF6Bu: goto L_00EF6B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF65u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF65u,0x00EF65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF68u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 5u, 3u, cpu.address("abs", 0x18B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 5u, 3u, cpu.address("abs", 0x18B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 4u, 3u, cpu.address("abs", 0x18B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 4u, 3u, cpu.address("abs", 0x18B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 4u, 3u, cpu.address("abs", 0x18B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF68u,0x00EF68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF6Bu))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Du,0x00EF6Bu); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Du,0x00EF6Bu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Du,0x00EF6Bu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Du,0x00EF6Bu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Du,0x00EF6Bu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,0x00EF6Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00F120_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00F120u: goto L_00F120;
    case 0x00F121u: goto L_00F121;
    case 0x00F124u: goto L_00F124;
    case 0x00F126u: goto L_00F126;
    case 0x00F127u: goto L_00F127;
    case 0x00F129u: goto L_00F129;
    case 0x00F12Bu: goto L_00F12B;
    case 0x00F12Du: goto L_00F12D;
    case 0x00F12Fu: goto L_00F12F;
    case 0x00F131u: goto L_00F131;
    case 0x00F133u: goto L_00F133;
    case 0x00F134u: goto L_00F134;
    case 0x00F137u: goto L_00F137;
    case 0x00F139u: goto L_00F139;
    case 0x00F13Bu: goto L_00F13B;
    case 0x00F13Du: goto L_00F13D;
    case 0x00F13Fu: goto L_00F13F;
    case 0x00F140u: goto L_00F140;
    case 0x00F142u: goto L_00F142;
    case 0x00F144u: goto L_00F144;
    case 0x00F146u: goto L_00F146;
    case 0x00F148u: goto L_00F148;
    case 0x00F14Au: goto L_00F14A;
    case 0x00F14Cu: goto L_00F14C;
    case 0x00F14Du: goto L_00F14D;
    case 0x00F150u: goto L_00F150;
    case 0x00F152u: goto L_00F152;
    case 0x00F154u: goto L_00F154;
    case 0x00F155u: goto L_00F155;
    case 0x00F157u: goto L_00F157;
    case 0x00F158u: goto L_00F158;
    case 0x00F159u: goto L_00F159;
    case 0x00F15Du: goto L_00F15D;
    case 0x00F15Eu: goto L_00F15E;
    case 0x00F15Fu: goto L_00F15F;
    case 0x00F160u: goto L_00F160;
    case 0x00F161u: goto L_00F161;
    case 0x00F163u: goto L_00F163;
    case 0x00F165u: goto L_00F165;
    case 0x00F167u: goto L_00F167;
    case 0x00F168u: goto L_00F168;
    case 0x00F169u: goto L_00F169;
    case 0x00F16Cu: goto L_00F16C;
    case 0x00F170u: goto L_00F170;
    case 0x00F171u: goto L_00F171;
    case 0x00F173u: goto L_00F173;
    case 0x00F175u: goto L_00F175;
    case 0x00F176u: goto L_00F176;
    case 0x00F177u: goto L_00F177;
    case 0x00F179u: goto L_00F179;
    case 0x00F17Bu: goto L_00F17B;
    case 0x00F17Du: goto L_00F17D;
    case 0x00F17Fu: goto L_00F17F;
    case 0x00F180u: goto L_00F180;
    case 0x00F181u: goto L_00F181;
    case 0x00F182u: goto L_00F182;
    case 0x00F186u: goto L_00F186;
    case 0x00F187u: goto L_00F187;
    case 0x00F18Bu: goto L_00F18B;
    case 0x00F18Du: goto L_00F18D;
    case 0x00F18Fu: goto L_00F18F;
    case 0x00F193u: goto L_00F193;
    case 0x00F195u: goto L_00F195;
    case 0x00F199u: goto L_00F199;
    case 0x00F19Bu: goto L_00F19B;
    case 0x00F19Fu: goto L_00F19F;
    case 0x00F1A1u: goto L_00F1A1;
    case 0x00F1A3u: goto L_00F1A3;
    case 0x00F1A5u: goto L_00F1A5;
    case 0x00F1A7u: goto L_00F1A7;
    case 0x00F1AAu: goto L_00F1AA;
    case 0x00F1ACu: goto L_00F1AC;
    case 0x00F1AEu: goto L_00F1AE;
    case 0x00F1AFu: goto L_00F1AF;
    case 0x00F1B1u: goto L_00F1B1;
    case 0x00F1B2u: goto L_00F1B2;
    case 0x00F1B3u: goto L_00F1B3;
    case 0x00F1B4u: goto L_00F1B4;
    case 0x00F1B5u: goto L_00F1B5;
    case 0x00F1B6u: goto L_00F1B6;
    case 0x00F1BAu: goto L_00F1BA;
    case 0x00F1BBu: goto L_00F1BB;
    case 0x00F1BDu: goto L_00F1BD;
    case 0x00F1BFu: goto L_00F1BF;
    case 0x00F1C1u: goto L_00F1C1;
    case 0x00F1C3u: goto L_00F1C3;
    case 0x00F1C5u: goto L_00F1C5;
    case 0x00F1C7u: goto L_00F1C7;
    case 0x00F1C9u: goto L_00F1C9;
    case 0x00F1CCu: goto L_00F1CC;
    case 0x00F1CEu: goto L_00F1CE;
    case 0x00F1D0u: goto L_00F1D0;
    case 0x00F1D2u: goto L_00F1D2;
    case 0x00F1D4u: goto L_00F1D4;
    case 0x00F1D6u: goto L_00F1D6;
    case 0x00F1D8u: goto L_00F1D8;
    case 0x00F1DAu: goto L_00F1DA;
    case 0x00F1DBu: goto L_00F1DB;
    case 0x00F1DDu: goto L_00F1DD;
    case 0x00F1DFu: goto L_00F1DF;
    case 0x00F1E1u: goto L_00F1E1;
    case 0x00F1E3u: goto L_00F1E3;
    case 0x00F1E5u: goto L_00F1E5;
    case 0x00F1E8u: goto L_00F1E8;
    case 0x00F1EAu: goto L_00F1EA;
    case 0x00F1ECu: goto L_00F1EC;
    case 0x00F1EDu: goto L_00F1ED;
    case 0x00F1EFu: goto L_00F1EF;
    case 0x00F1F0u: goto L_00F1F0;
    case 0x00F1F1u: goto L_00F1F1;
    case 0x00F1F5u: goto L_00F1F5;
    case 0x00F1F6u: goto L_00F1F6;
    case 0x00F1F7u: goto L_00F1F7;
    case 0x00F1F8u: goto L_00F1F8;
    case 0x00F1F9u: goto L_00F1F9;
    case 0x00F1FBu: goto L_00F1FB;
    case 0x00F1FCu: goto L_00F1FC;
    case 0x00F1FEu: goto L_00F1FE;
    case 0x00F200u: goto L_00F200;
    case 0x00F201u: goto L_00F201;
    case 0x00F202u: goto L_00F202;
    case 0x00F203u: goto L_00F203;
    case 0x00F204u: goto L_00F204;
    case 0x00F206u: goto L_00F206;
    case 0x00F207u: goto L_00F207;
    case 0x00F208u: goto L_00F208;
    case 0x00F209u: goto L_00F209;
    case 0x00F20Au: goto L_00F20A;
    case 0x00F20Bu: goto L_00F20B;
    case 0x00F20Eu: goto L_00F20E;
    case 0x00F212u: goto L_00F212;
    case 0x00F215u: goto L_00F215;
    case 0x00F218u: goto L_00F218;
    case 0x00F21Au: goto L_00F21A;
    case 0x00F21Cu: goto L_00F21C;
    case 0x00F21Eu: goto L_00F21E;
    case 0x00F220u: goto L_00F220;
    case 0x00F222u: goto L_00F222;
    case 0x00F224u: goto L_00F224;
    case 0x00F226u: goto L_00F226;
    case 0x00F229u: goto L_00F229;
    case 0x00F22Bu: goto L_00F22B;
    case 0x00F22Cu: goto L_00F22C;
    case 0x00F22Eu: goto L_00F22E;
    case 0x00F230u: goto L_00F230;
    case 0x00F232u: goto L_00F232;
    case 0x00F234u: goto L_00F234;
    case 0x00F236u: goto L_00F236;
    case 0x00F238u: goto L_00F238;
    case 0x00F23Bu: goto L_00F23B;
    case 0x00F23Cu: goto L_00F23C;
    case 0x00F23Eu: goto L_00F23E;
    case 0x00F23Fu: goto L_00F23F;
    case 0x00F241u: goto L_00F241;
    case 0x00F242u: goto L_00F242;
    case 0x00F243u: goto L_00F243;
    case 0x00F247u: goto L_00F247;
    case 0x00F248u: goto L_00F248;
    case 0x00F249u: goto L_00F249;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00F120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF120u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF120u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F120 XBA
    cpu.xba();
    goto L_00F121;
L_00F121:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF121u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF121u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF121u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F121 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F124;
L_00F124:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF124u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF124u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF124u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F124 BNE -> $00F15F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F15F; }
    goto L_00F126;
L_00F126:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF126u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF126u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF126u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F126 XBA
    cpu.xba();
    goto L_00F127;
L_00F127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF127u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF127u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F127 CMP
    cpu.compareA(0x2Fu);
    goto L_00F129;
L_00F129:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF129u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF129u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF129u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F129 BEQ -> $00F154
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F154; }
    goto L_00F12B;
L_00F12B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F12B CMP
    cpu.compareA(0x59u);
    goto L_00F12D;
L_00F12D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F12D BCC -> $00F144
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00F144; }
    goto L_00F12F;
L_00F12F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F12F CMP
    cpu.compareA(0x5Cu);
    goto L_00F131;
L_00F131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF131u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF131u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F131 BCS -> $00F140
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00F140; }
    goto L_00F133;
L_00F133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF133u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF133u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF133u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F133 XBA
    cpu.xba();
    goto L_00F134;
L_00F134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF134u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF134u, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F134 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F137;
L_00F137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF137u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF137u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF137u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F137 CMP
    cpu.compareA(0x5u);
    goto L_00F139;
L_00F139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF139u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF139u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F139 BEQ -> $00F154
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F154; }
    goto L_00F13B;
L_00F13B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF13Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F13B CMP
    cpu.compareA(0xDu);
    goto L_00F13D;
L_00F13D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF13Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F13D BEQ -> $00F154
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F154; }
    goto L_00F13F;
L_00F13F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF13Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Fu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F13F XBA
    cpu.xba();
    goto L_00F140;
L_00F140:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF140u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF140u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF140u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F140 CMP
    cpu.compareA(0x5Du);
    goto L_00F142;
L_00F142:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF142u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF142u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF142u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F142 BCC -> $00F14C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00F14C; }
    goto L_00F144;
L_00F144:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF144u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF144u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF144u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F144 CMP
    cpu.compareA(0x66u);
    goto L_00F146;
L_00F146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF146u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF146u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F146 BCC -> $00F160
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00F160; }
    goto L_00F148;
L_00F148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF148u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF148u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F148 CMP
    cpu.compareA(0x6Au);
    goto L_00F14A;
L_00F14A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F14A BCS -> $00F160
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00F160; }
    goto L_00F14C;
L_00F14C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F14C XBA
    cpu.xba();
    goto L_00F14D;
L_00F14D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Du, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F14D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F150;
L_00F150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF150u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF150u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF150u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F150 CMP
    cpu.compareA(0x1u);
    goto L_00F152;
L_00F152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF152u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF152u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F152 BNE -> $00F15F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F15F; }
    goto L_00F154;
L_00F154:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF154u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF154u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF154u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F154 PHB
    cpu.push("PHB", hw);
    goto L_00F155;
L_00F155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF155u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF155u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F155 LDA
    cpu.setA(0x1u, 8);
    goto L_00F157;
L_00F157:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF157u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF157u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF157u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F157 PHA
    cpu.push("PHA", hw);
    goto L_00F158;
L_00F158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF158u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF158u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F158 PLB
    cpu.pop("PLB", hw);
    goto L_00F159;
L_00F159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF159u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF159u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF159u, 8u, 4u, 0x00F5B7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F159 JSL -> $00F5B7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF15Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF15Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F5B7u, 0x00F159u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F15D;
L_00F15D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF15Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF15Du,0x00F15Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F15D PLB
    cpu.pop("PLB", hw);
    goto L_00F15E;
L_00F15E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF15Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F15E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00F15Eu);return;} hw.unresolvedReturn(0x00F15Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_00F15F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF15Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Fu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F15F XBA
    cpu.xba();
    goto L_00F160;
L_00F160:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF160u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF160u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF160u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F160 SEC
    cpu.setFlag('C', true);
    goto L_00F161;
L_00F161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF161u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF161u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F161 SBC
    cpu.sbc(0x11u);
    goto L_00F163;
L_00F163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF163u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF163u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF163u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F163 CMP
    cpu.compareA(0x1Du);
    goto L_00F165;
L_00F165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF165u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF165u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F165 BCC -> $00F17F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00F17F; }
    goto L_00F167;
L_00F167:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF167u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF167u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF167u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F167 XBA
    cpu.xba();
    goto L_00F168;
L_00F168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF168u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF168u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F168 PHX
    cpu.push("PHX", hw);
    goto L_00F169;
L_00F169:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF169u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF169u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF169u, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F169 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1931u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00F16C;
L_00F16C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF16Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Cu, 5u, 4u, ((0x00A625u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F16C LDA
    cpu.loadA(hw.readW(((0xA625u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F170;
L_00F170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF170u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF170u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F170 PLX
    cpu.pop("PLX", hw);
    goto L_00F171;
L_00F171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF171u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF171u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F171 AND
    cpu.logicAnd(0x3u);
    goto L_00F173;
L_00F173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF173u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF173u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F173 BEQ -> $00F176
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F176; }
    goto L_00F175;
L_00F175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF175u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF175u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF175u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F175 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00F175u);return;} hw.unresolvedReturn(0x00F175u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_00F176:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF176u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF176u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF176u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F176 XBA
    cpu.xba();
    goto L_00F177;
L_00F177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF177u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF177u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F177 SBC
    cpu.sbc(0x59u);
    goto L_00F179;
L_00F179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF179u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF179u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F179 CMP
    cpu.compareA(0x2u);
    goto L_00F17B;
L_00F17B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF17Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F17B BCS -> $00F1F8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00F1F8; }
    goto L_00F17D;
L_00F17D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF17Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F17D ADC
    cpu.adc(0x22u);
    goto L_00F17F;
L_00F17F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF17Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Fu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F17F PHX
    cpu.push("PHX", hw);
    goto L_00F180;
L_00F180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF180u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF180u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F180 PHA
    cpu.push("PHA", hw);
    goto L_00F181;
L_00F181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF181u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF181u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF181u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F181 TYX
    cpu.transfer("TYX");
    goto L_00F182;
L_00F182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF182u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF182u, 5u, 4u, ((0x00F0ECu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F182 LDA
    cpu.loadA(hw.readW(((0xF0ECu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F186;
L_00F186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF186u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF186u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F186 PLX
    cpu.pop("PLX", hw);
    goto L_00F187;
L_00F187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF187u,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF187u, 5u, 4u, ((0x00F0A4u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F187 AND
    cpu.logicAnd(hw.readW(((0xF0A4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F18B;
L_00F18B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF18Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F18B BEQ -> $00F1F6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F1F6; }
    goto L_00F18D;
L_00F18D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF18Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Du,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F18D STY
    hw.write(cpu.address("dp", 0x6u), cpu.y, cpu.x8?8:16);
    goto L_00F18F;
L_00F18F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF18Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Fu, 5u, 4u, ((0x00F0C8u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F18F LDA
    cpu.loadA(hw.readW(((0xF0C8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F193;
L_00F193:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF193u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF193u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF193u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F193 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_00F195;
L_00F195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF195u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF195u, 5u, 4u, ((0x00F05Cu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F195 LDA
    cpu.loadA(hw.readW(((0xF05Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F199;
L_00F199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF199u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF199u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF199u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F199 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00F19B;
L_00F19B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF19Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Bu, 5u, 4u, ((0x00F080u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F19B LDA
    cpu.loadA(hw.readW(((0xF080u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F19F;
L_00F19F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF19Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F19F BPL -> $00F1BA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00F1BA; }
    goto L_00F1A1;
L_00F1A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1A1 CMP
    cpu.compareA(0xFFu);
    goto L_00F1A3;
L_00F1A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1A3 BNE -> $00F1AE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F1AE; }
    goto L_00F1A5;
L_00F1A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1A5 LDA
    cpu.setA(0x5u, 8);
    goto L_00F1A7;
L_00F1A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A7u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A7u, 4u, 3u, cpu.address("abs", 0x0DC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1A7 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0xDC0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00F1AA;
L_00F1AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1AAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1AA BEQ -> $00F1D0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F1D0; }
    goto L_00F1AC;
L_00F1AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ACu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ACu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1AC BRA -> $00F1CE
    goto L_00F1CE;
L_00F1AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1AEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1AE LSR
    cpu.lsrA();
    goto L_00F1AF;
L_00F1AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1AFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1AFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1AF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F1B1;
L_00F1B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B1u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1B1 ROR
    cpu.rorA();
    goto L_00F1B2;
L_00F1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1B2 LSR
    cpu.lsrA();
    goto L_00F1B3;
L_00F1B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1B3 LSR
    cpu.lsrA();
    goto L_00F1B4;
L_00F1B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1B4 LSR
    cpu.lsrA();
    goto L_00F1B5;
L_00F1B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1B5 TAX
    cpu.transfer("TAX");
    goto L_00F1B6;
L_00F1B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B6u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B6u, 5u, 4u, ((0x00F100u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1B6 LDA
    cpu.loadA(hw.readW(((0xF100u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F1BA;
L_00F1BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1BA LSR
    cpu.lsrA();
    goto L_00F1BB;
L_00F1BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1BB BCC -> $00F1D0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00F1D0; }
    goto L_00F1BD;
L_00F1BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1BD CMP
    cpu.compareA(0x3u);
    goto L_00F1BF;
L_00F1BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1BF BEQ -> $00F1C9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F1C9; }
    goto L_00F1C1;
L_00F1C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C1u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1C1 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00F1C3;
L_00F1C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1C3 BNE -> $00F1D0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F1D0; }
    goto L_00F1C5;
L_00F1C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1C5 LDA
    cpu.setA(0x1u, 8);
    goto L_00F1C7;
L_00F1C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1C7 BRA -> $00F1D0
    goto L_00F1D0;
L_00F1C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C9u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C9u, 4u, 3u, cpu.address("abs", 0x1490u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1C9 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1490u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00F1CC;
L_00F1CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1CC BNE -> $00F1D0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F1D0; }
    goto L_00F1CE;
L_00F1CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1CE LDA
    cpu.setA(0x6u, 8);
    goto L_00F1D0;
L_00F1D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1D0 STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_00F1D2;
L_00F1D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1D2 CMP
    cpu.compareA(0x5u);
    goto L_00F1D4;
L_00F1D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1D4 BNE -> $00F1DA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F1DA; }
    goto L_00F1D6;
L_00F1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1D6 LDA
    cpu.setA(0x16u, 8);
    goto L_00F1D8;
L_00F1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1D8 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_00F1DA;
L_00F1DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1DA TAY
    cpu.transfer("TAY");
    goto L_00F1DB;
L_00F1DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1DB LDA
    cpu.setA(0xFu, 8);
    goto L_00F1DD;
L_00F1DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DDu,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1DD TRB
    cpu.trb(hw, cpu.address("dp", 0x9Au), cpu.m8?8:16);
    goto L_00F1DF;
L_00F1DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DFu,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1DF TRB
    cpu.trb(hw, cpu.address("dp", 0x98u), cpu.m8?8:16);
    goto L_00F1E1;
L_00F1E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E1u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1E1 CPY
    cpu.compareY(0x6u);
    goto L_00F1E3;
L_00F1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1E3 BNE -> $00F1EC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F1EC; }
    goto L_00F1E5;
L_00F1E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E5u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E5u, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1E5 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1931u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00F1E8;
L_00F1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E8u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1E8 CPY
    cpu.compareY(0x4u);
    goto L_00F1EA;
L_00F1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1EA BEQ -> $00F1F9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F1F9; }
    goto L_00F1EC;
L_00F1EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ECu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ECu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F1EC PHB
    cpu.push("PHB", hw);
    goto L_00F1ED;
L_00F1ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1ED LDA
    cpu.setA(0x2u, 8);
    goto L_00F1EF;
L_00F1EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EFu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F1EF PHA
    cpu.push("PHA", hw);
    goto L_00F1F0;
L_00F1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F0u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F1F0 PLB
    cpu.pop("PLB", hw);
    goto L_00F1F1;
L_00F1F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F1u, 8u, 4u, 0x028752u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F1F1 JSL -> $028752 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF1F4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF1F5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x028752u, 0x00F1F1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F1F5;
L_00F1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF1F5u,0x00F1F5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F5u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F1F5 PLB
    cpu.pop("PLB", hw);
    goto L_00F1F6;
L_00F1F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F6u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F1F6 PLX
    cpu.pop("PLX", hw);
    goto L_00F1F7;
L_00F1F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1F7 CLC
    cpu.setFlag('C', false);
    goto L_00F1F8;
L_00F1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F1F8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00F1F8u);return;} hw.unresolvedReturn(0x00F1F8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F1F8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00F1F8u);return;} hw.unresolvedReturn(0x00F1F8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF1F8u,0x00F1F8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00F1F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1F9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x99u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F1FB;
L_00F1FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FBu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1FB LSR
    cpu.lsrA();
    goto L_00F1FC;
L_00F1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1FC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F1FE;
L_00F1FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F1FE AND
    cpu.logicAnd(0xC0u);
    goto L_00F200;
L_00F200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF200u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF200u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F200 ROL
    cpu.rolA();
    goto L_00F201;
L_00F201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF201u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF201u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F201 ROL
    cpu.rolA();
    goto L_00F202;
L_00F202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF202u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF202u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F202 ROL
    cpu.rolA();
    goto L_00F203;
L_00F203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF203u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF203u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F203 TAY
    cpu.transfer("TAY");
    goto L_00F204;
L_00F204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF204u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF204u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF204u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F204 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F206;
L_00F206:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF206u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF206u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF206u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F206 LSR
    cpu.lsrA();
    goto L_00F207;
L_00F207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF207u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF207u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F207 LSR
    cpu.lsrA();
    goto L_00F208;
L_00F208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF208u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF208u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F208 LSR
    cpu.lsrA();
    goto L_00F209;
L_00F209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF209u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF209u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F209 LSR
    cpu.lsrA();
    goto L_00F20A;
L_00F20A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF20Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F20A TAX
    cpu.transfer("TAX");
    goto L_00F20B;
L_00F20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF20Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Bu, 4u + ((((0x13F3u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x13F3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F20B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x13F3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F20E;
L_00F20E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF20Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Eu,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Eu, 5u, 4u, ((0x00F0ECu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F20E ORA
    cpu.logicOr(hw.readW(((0xF0ECu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F212;
L_00F212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF212u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF212u, 4u + ((((0x13F3u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x13F3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F212 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x13F3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00F215;
L_00F215:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF215u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF215u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF215u, 5u, 3u, cpu.address("absy", 0x13F3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F215 STA
    hw.write(cpu.address("absy", 0x13F3u), cpu.a, cpu.m8?8:16);
    goto L_00F218;
L_00F218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF218u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF218u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F218 CMP
    cpu.compareA(0xFFu);
    goto L_00F21A;
L_00F21A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF21Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F21A BNE -> $00F226
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F226; }
    goto L_00F21C;
L_00F21C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF21Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F21C LDA
    cpu.setA(0x5u, 8);
    goto L_00F21E;
L_00F21E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF21Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F21E STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_00F220;
L_00F220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF220u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF220u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF220u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F220 LDA
    cpu.setA(0x17u, 8);
    goto L_00F222;
L_00F222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF222u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF222u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F222 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_00F224;
L_00F224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF224u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF224u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F224 BRA -> $00F1EC
    goto L_00F1EC;
L_00F226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF226u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF226u, 4u, 3u, cpu.address("abs", 0x141Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F226 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F229;
L_00F229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF229u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF229u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F229 BNE -> $00F236
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F236; }
    goto L_00F22B;
L_00F22B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF22Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Bu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F22B TXA
    cpu.transfer("TXA");
    goto L_00F22C;
L_00F22C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF22Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F22C BEQ -> $00F230
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F230; }
    goto L_00F22E;
L_00F22E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF22Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F22E LDA
    cpu.setA(0x2u, 8);
    goto L_00F230;
L_00F230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF230u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF230u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F230 EOR
    cpu.logicXor(0x3u);
    goto L_00F232;
L_00F232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF232u,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF232u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F232 AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_00F234;
L_00F234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF234u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF234u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F234 BNE -> $00F220
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F220; }
    goto L_00F236;
L_00F236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF236u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF236u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F236 LDA
    cpu.setA(0x2Au, 8);
    goto L_00F238;
L_00F238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF238u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF238u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F238 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00F23B;
L_00F23B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF23Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Bu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F23B PHY
    cpu.push("PHY", hw);
    goto L_00F23C;
L_00F23C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF23Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F23C STZ
    hw.write(cpu.address("dp", 0x5u), 0, cpu.m8?8:16);
    goto L_00F23E;
L_00F23E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF23Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Eu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F23E PHB
    cpu.push("PHB", hw);
    goto L_00F23F;
L_00F23F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF23Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F23F LDA
    cpu.setA(0x2u, 8);
    goto L_00F241;
L_00F241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF241u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF241u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F241 PHA
    cpu.push("PHA", hw);
    goto L_00F242;
L_00F242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF242u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF242u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F242 PLB
    cpu.pop("PLB", hw);
    goto L_00F243;
L_00F243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF243u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF243u, 8u, 4u, 0x028752u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F243 JSL -> $028752 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF246u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF247u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x028752u, 0x00F243u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F247;
L_00F247:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF247u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF247u,0x00F247u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF247u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF247u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F247 PLB
    cpu.pop("PLB", hw);
    goto L_00F248;
L_00F248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF248u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF248u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F248 PLY
    cpu.pop("PLY", hw);
    goto L_00F249;
L_00F249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF249u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF249u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F249 LDX
    cpu.setX(0x7u, 8);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF24Bu,0x00F249u); return;
}

void sub_019140_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019140u: goto L_019140;
    case 0x019143u: goto L_019143;
    case 0x019146u: goto L_019146;
    case 0x019149u: goto L_019149;
    case 0x01914Cu: goto L_01914C;
    case 0x01914Fu: goto L_01914F;
    case 0x019152u: goto L_019152;
    case 0x019155u: goto L_019155;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019140:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9140u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9140u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9140u, 4u, 3u, cpu.address("abs", 0x1694u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019140 STZ
    hw.write(cpu.address("abs", 0x1694u), 0, cpu.m8?8:16);
    goto L_019143;
L_019143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u, 5u, 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019143 STZ
    hw.write(cpu.address("absx", 0x1588u), 0, cpu.m8?8:16);
    goto L_019146;
L_019146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9146u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9146u, 5u, 3u, cpu.address("absx", 0x15B8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019146 STZ
    hw.write(cpu.address("absx", 0x15B8u), 0, cpu.m8?8:16);
    goto L_019149;
L_019149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u, 4u, 3u, cpu.address("abs", 0x185Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019149 STZ
    hw.write(cpu.address("abs", 0x185Eu), 0, cpu.m8?8:16);
    goto L_01914C;
L_01914C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Cu, 4u + ((((0x164Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x164Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01914C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x164Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01914F;
L_01914F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Fu, 4u, 3u, cpu.address("abs", 0x1695u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01914F STA
    hw.write(cpu.address("abs", 0x1695u), cpu.a, cpu.m8?8:16);
    goto L_019152;
L_019152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9152u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9152u, 5u, 3u, cpu.address("absx", 0x164Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019152 STZ
    hw.write(cpu.address("absx", 0x164Au), 0, cpu.m8?8:16);
    goto L_019155;
L_019155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9155u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9155u, 6u, 3u, cpu.address("abs", 0x9211u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019155 JSR -> $019211 stack real
    { cpu.push16Value(hw,0x9157u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9158u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9211u), 0x019155u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9158u,0x019155u); return;
}

void sub_019140_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019140u: goto L_019140;
    case 0x019143u: goto L_019143;
    case 0x019146u: goto L_019146;
    case 0x019149u: goto L_019149;
    case 0x01914Cu: goto L_01914C;
    case 0x01914Fu: goto L_01914F;
    case 0x019152u: goto L_019152;
    case 0x019155u: goto L_019155;
    case 0x019158u: goto L_019158;
    case 0x01915Au: goto L_01915A;
    case 0x01915Cu: goto L_01915C;
    case 0x01915Fu: goto L_01915F;
    case 0x019161u: goto L_019161;
    case 0x0191BEu: goto L_0191BE;
    case 0x0191C1u: goto L_0191C1;
    case 0x0191C3u: goto L_0191C3;
    case 0x0191C6u: goto L_0191C6;
    case 0x0191C8u: goto L_0191C8;
    case 0x0191CAu: goto L_0191CA;
    case 0x0191CBu: goto L_0191CB;
    case 0x0191CEu: goto L_0191CE;
    case 0x0191D0u: goto L_0191D0;
    case 0x0191D2u: goto L_0191D2;
    case 0x0191EDu: goto L_0191ED;
    case 0x0191F0u: goto L_0191F0;
    case 0x0191F3u: goto L_0191F3;
    case 0x0191F5u: goto L_0191F5;
    case 0x019210u: goto L_019210;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019140:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9140u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9140u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9140u, 4u, 3u, cpu.address("abs", 0x1694u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019140 STZ
    hw.write(cpu.address("abs", 0x1694u), 0, cpu.m8?8:16);
    goto L_019143;
L_019143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u, 5u, 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019143 STZ
    hw.write(cpu.address("absx", 0x1588u), 0, cpu.m8?8:16);
    goto L_019146;
L_019146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9146u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9146u, 5u, 3u, cpu.address("absx", 0x15B8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019146 STZ
    hw.write(cpu.address("absx", 0x15B8u), 0, cpu.m8?8:16);
    goto L_019149;
L_019149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u, 4u, 3u, cpu.address("abs", 0x185Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019149 STZ
    hw.write(cpu.address("abs", 0x185Eu), 0, cpu.m8?8:16);
    goto L_01914C;
L_01914C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Cu, 4u + ((((0x164Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x164Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01914C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x164Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01914F;
L_01914F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Fu, 4u, 3u, cpu.address("abs", 0x1695u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01914F STA
    hw.write(cpu.address("abs", 0x1695u), cpu.a, cpu.m8?8:16);
    goto L_019152;
L_019152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9152u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9152u, 5u, 3u, cpu.address("absx", 0x164Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019152 STZ
    hw.write(cpu.address("absx", 0x164Au), 0, cpu.m8?8:16);
    goto L_019155;
L_019155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9155u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9155u, 6u, 3u, cpu.address("abs", 0x9211u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019155 JSR -> $019211 stack real
    { cpu.push16Value(hw,0x9157u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9158u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9211u), 0x019155u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019158;
L_019158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9158u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9158u,0x019158u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019158 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01915A;
L_01915A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01915A BPL -> $0191BE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0191BE; }
    goto L_01915C;
L_01915C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Cu, 6u, 3u, cpu.address("abs", 0x185Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01915C INC
    cpu.incMem(hw, cpu.address("abs", 0x185Eu), cpu.m8?8:16);
    goto L_01915F;
L_01915F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01915F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019161;
L_019161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9161u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9161u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019161 CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9162u,0x019161u); return;
L_0191BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BEu, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191BE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191C1;
L_0191C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191C1 BPL -> $0191ED
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0191ED; }
    goto L_0191C3;
L_0191C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C3u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191C3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191C6;
L_0191C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191C6 AND
    cpu.logicAnd(0x3u);
    goto L_0191C8;
L_0191C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191C8 BEQ -> $0191ED
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0191ED; }
    goto L_0191CA;
L_0191CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191CA TAY
    cpu.transfer("TAY");
    goto L_0191CB;
L_0191CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CBu, 4u + ((((0x15D0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191CB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15D0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191CE;
L_0191CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191CE BNE -> $0191ED
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0191ED; }
    goto L_0191D0;
L_0191D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191D0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191D2;
L_0191D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191D2 CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91D3u,0x0191D2u); return;
L_0191ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EDu, 4u + ((((0x164Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x164Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191ED LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x164Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191F0;
L_0191F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F0u,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F0u, 4u, 3u, cpu.address("abs", 0x1695u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191F0 EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0x1695u), cpu.m8?8:16));
    goto L_0191F3;
L_0191F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191F3 BEQ -> $019210
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_019210; }
    goto L_0191F5;
L_0191F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191F5 ASL
    cpu.aslA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91F6u,0x0191F5u); return;
L_019210:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9210u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9210u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9210u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019210 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x019210u);return;} hw.unresolvedReturn(0x019210u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_019140_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019140u: goto L_019140;
    case 0x019143u: goto L_019143;
    case 0x019146u: goto L_019146;
    case 0x019149u: goto L_019149;
    case 0x01914Cu: goto L_01914C;
    case 0x01914Fu: goto L_01914F;
    case 0x019152u: goto L_019152;
    case 0x019155u: goto L_019155;
    case 0x019158u: goto L_019158;
    case 0x01915Au: goto L_01915A;
    case 0x01915Cu: goto L_01915C;
    case 0x01915Fu: goto L_01915F;
    case 0x019161u: goto L_019161;
    case 0x019162u: goto L_019162;
    case 0x019164u: goto L_019164;
    case 0x019166u: goto L_019166;
    case 0x019169u: goto L_019169;
    case 0x01916Bu: goto L_01916B;
    case 0x01916Eu: goto L_01916E;
    case 0x019170u: goto L_019170;
    case 0x019171u: goto L_019171;
    case 0x019173u: goto L_019173;
    case 0x019175u: goto L_019175;
    case 0x019178u: goto L_019178;
    case 0x01917Au: goto L_01917A;
    case 0x01917Du: goto L_01917D;
    case 0x019180u: goto L_019180;
    case 0x019182u: goto L_019182;
    case 0x019183u: goto L_019183;
    case 0x019185u: goto L_019185;
    case 0x019187u: goto L_019187;
    case 0x01918Au: goto L_01918A;
    case 0x01918Cu: goto L_01918C;
    case 0x01918Fu: goto L_01918F;
    case 0x019191u: goto L_019191;
    case 0x019192u: goto L_019192;
    case 0x019194u: goto L_019194;
    case 0x019196u: goto L_019196;
    case 0x019199u: goto L_019199;
    case 0x01919Bu: goto L_01919B;
    case 0x01919Eu: goto L_01919E;
    case 0x0191A1u: goto L_0191A1;
    case 0x0191A3u: goto L_0191A3;
    case 0x0191A5u: goto L_0191A5;
    case 0x0191A7u: goto L_0191A7;
    case 0x0191A9u: goto L_0191A9;
    case 0x0191ACu: goto L_0191AC;
    case 0x0191AEu: goto L_0191AE;
    case 0x0191AFu: goto L_0191AF;
    case 0x0191B1u: goto L_0191B1;
    case 0x0191B2u: goto L_0191B2;
    case 0x0191B3u: goto L_0191B3;
    case 0x0191B5u: goto L_0191B5;
    case 0x0191B7u: goto L_0191B7;
    case 0x0191B8u: goto L_0191B8;
    case 0x0191BBu: goto L_0191BB;
    case 0x0191BEu: goto L_0191BE;
    case 0x0191C1u: goto L_0191C1;
    case 0x0191C3u: goto L_0191C3;
    case 0x0191C6u: goto L_0191C6;
    case 0x0191C8u: goto L_0191C8;
    case 0x0191CAu: goto L_0191CA;
    case 0x0191CBu: goto L_0191CB;
    case 0x0191CEu: goto L_0191CE;
    case 0x0191D0u: goto L_0191D0;
    case 0x0191D2u: goto L_0191D2;
    case 0x0191D3u: goto L_0191D3;
    case 0x0191D6u: goto L_0191D6;
    case 0x0191D8u: goto L_0191D8;
    case 0x0191DBu: goto L_0191DB;
    case 0x0191DEu: goto L_0191DE;
    case 0x0191E1u: goto L_0191E1;
    case 0x0191E3u: goto L_0191E3;
    case 0x0191E5u: goto L_0191E5;
    case 0x0191E8u: goto L_0191E8;
    case 0x0191EAu: goto L_0191EA;
    case 0x0191EDu: goto L_0191ED;
    case 0x0191F0u: goto L_0191F0;
    case 0x0191F3u: goto L_0191F3;
    case 0x0191F5u: goto L_0191F5;
    case 0x0191F6u: goto L_0191F6;
    case 0x0191F9u: goto L_0191F9;
    case 0x0191FBu: goto L_0191FB;
    case 0x0191FEu: goto L_0191FE;
    case 0x019200u: goto L_019200;
    case 0x019202u: goto L_019202;
    case 0x019205u: goto L_019205;
    case 0x019207u: goto L_019207;
    case 0x01920Bu: goto L_01920B;
    case 0x01920Cu: goto L_01920C;
    case 0x019210u: goto L_019210;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019140:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9140u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9140u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9140u, 4u, 3u, cpu.address("abs", 0x1694u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019140 STZ
    hw.write(cpu.address("abs", 0x1694u), 0, cpu.m8?8:16);
    goto L_019143;
L_019143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u, 5u, 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019143 STZ
    hw.write(cpu.address("absx", 0x1588u), 0, cpu.m8?8:16);
    goto L_019146;
L_019146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9146u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9146u, 5u, 3u, cpu.address("absx", 0x15B8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019146 STZ
    hw.write(cpu.address("absx", 0x15B8u), 0, cpu.m8?8:16);
    goto L_019149;
L_019149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u, 4u, 3u, cpu.address("abs", 0x185Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019149 STZ
    hw.write(cpu.address("abs", 0x185Eu), 0, cpu.m8?8:16);
    goto L_01914C;
L_01914C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Cu, 4u + ((((0x164Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x164Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01914C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x164Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01914F;
L_01914F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Fu, 4u, 3u, cpu.address("abs", 0x1695u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01914F STA
    hw.write(cpu.address("abs", 0x1695u), cpu.a, cpu.m8?8:16);
    goto L_019152;
L_019152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9152u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9152u, 5u, 3u, cpu.address("absx", 0x164Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019152 STZ
    hw.write(cpu.address("absx", 0x164Au), 0, cpu.m8?8:16);
    goto L_019155;
L_019155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9155u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9155u, 6u, 3u, cpu.address("abs", 0x9211u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019155 JSR -> $019211 stack real
    { cpu.push16Value(hw,0x9157u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9158u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9211u), 0x019155u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019158;
L_019158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9158u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019158 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01915A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019158 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01915A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9158u,0x019158u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01915A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01915A BPL -> $0191BE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0191BE; }
    goto L_01915C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01915A BPL -> $0191BE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0191BE; }
    goto L_01915C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x915Au,0x01915Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01915C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Cu, 6u, 3u, cpu.address("abs", 0x185Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01915C INC
    cpu.incMem(hw, cpu.address("abs", 0x185Eu), cpu.m8?8:16);
    goto L_01915F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Cu, 6u, 3u, cpu.address("abs", 0x185Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01915C INC
    cpu.incMem(hw, cpu.address("abs", 0x185Eu), cpu.m8?8:16);
    goto L_01915F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x915Cu,0x01915Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01915F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01915F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019161;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01915F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019161;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x915Fu,0x01915Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_019161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9161u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9161u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9161u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019161 CLC
    cpu.setFlag('C', false);
    goto L_019162;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9161u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9161u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019161 CLC
    cpu.setFlag('C', false);
    goto L_019162;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9161u,0x019161u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_019162:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9162u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9162u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9162u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019162 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_019164;
L_019164:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9164u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9164u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9164u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019164 STA
    hw.write(cpu.address("dpx", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_019166;
L_019166:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9166u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9166u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9166u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019166 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019169;
L_019169:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9169u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9169u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9169u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x27u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019169 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x27u), cpu.m8?8:16));
    goto L_01916B;
L_01916B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Bu, 5u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01916B STA
    hw.write(cpu.address("absx", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_01916E;
L_01916E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Eu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01916E LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019170;
L_019170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9170u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9170u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019170 CLC
    cpu.setFlag('C', false);
    goto L_019171;
L_019171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9171u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9171u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019171 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16));
    goto L_019173;
L_019173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9173u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9173u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019173 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_019175;
L_019175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9175u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9175u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9175u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019175 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019178;
L_019178:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9178u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9178u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9178u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019178 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x29u), cpu.m8?8:16));
    goto L_01917A;
L_01917A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Au, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01917A STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_01917D;
L_01917D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Du, 6u, 3u, cpu.address("abs", 0x9211u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01917D JSR -> $019211 stack real
    { cpu.push16Value(hw,0x917Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9180u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9211u), 0x01917Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019180;
L_019180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9180u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019180 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019182;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019180 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019182;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9180u,0x019180u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_019182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9182u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9182u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9182u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019182 SEC
    cpu.setFlag('C', true);
    goto L_019183;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9182u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9182u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019182 SEC
    cpu.setFlag('C', true);
    goto L_019183;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9182u,0x019182u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_019183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9183u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9183u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019183 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_019185;
L_019185:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9185u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9185u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9185u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019185 STA
    hw.write(cpu.address("dpx", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_019187;
L_019187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9187u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9187u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019187 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01918A;
L_01918A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Au,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x27u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01918A SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x27u), cpu.m8?8:16));
    goto L_01918C;
L_01918C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Cu, 5u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01918C STA
    hw.write(cpu.address("absx", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_01918F;
L_01918F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01918F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019191;
L_019191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9191u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9191u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9191u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019191 SEC
    cpu.setFlag('C', true);
    goto L_019192;
L_019192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019192 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16));
    goto L_019194;
L_019194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9194u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9194u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019194 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_019196;
L_019196:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9196u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9196u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9196u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019196 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019199;
L_019199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9199u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9199u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9199u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019199 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x29u), cpu.m8?8:16));
    goto L_01919B;
L_01919B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Bu, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01919B STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_01919E;
L_01919E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Eu, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01919E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191A1;
L_0191A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191A1 BPL -> $0191BE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0191BE; }
    goto L_0191A3;
L_0191A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191A3 AND
    cpu.logicAnd(0x3u);
    goto L_0191A5;
L_0191A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191A5 BNE -> $0191BE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0191BE; }
    goto L_0191A7;
L_0191A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191A7 LDY
    cpu.setY(0x0u, 8);
    goto L_0191A9;
L_0191A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A9u, 4u, 3u, cpu.address("abs", 0x17BFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191A9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17BFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191AC;
L_0191AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ACu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191AC EOR
    cpu.logicXor(0xFFu);
    goto L_0191AE;
L_0191AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91AEu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191AE INC
    cpu.inc('A');
    goto L_0191AF;
L_0191AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91AFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191AF BPL -> $0191B2
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0191B2; }
    goto L_0191B1;
L_0191B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191B1 DEY
    cpu.decReg('Y');
    goto L_0191B2;
L_0191B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191B2 CLC
    cpu.setFlag('C', false);
    goto L_0191B3;
L_0191B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191B3 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16));
    goto L_0191B5;
L_0191B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191B5 STA
    hw.write(cpu.address("dpx", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_0191B7;
L_0191B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B7u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191B7 TYA
    cpu.transfer("TYA");
    goto L_0191B8;
L_0191B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B8u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B8u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191B8 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16));
    goto L_0191BB;
L_0191BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BBu, 5u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191BB STA
    hw.write(cpu.address("absx", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_0191BE;
L_0191BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BEu, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191BE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191C1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BEu, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191BE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191C1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91BEu,0x0191BEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0191C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191C1 BPL -> $0191ED
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0191ED; }
    goto L_0191C3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191C1 BPL -> $0191ED
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0191ED; }
    goto L_0191C3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91C1u,0x0191C1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0191C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C3u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191C3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191C6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C3u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191C3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191C6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91C3u,0x0191C3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0191C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191C6 AND
    cpu.logicAnd(0x3u);
    goto L_0191C8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191C6 AND
    cpu.logicAnd(0x3u);
    goto L_0191C8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91C6u,0x0191C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0191C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191C8 BEQ -> $0191ED
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0191ED; }
    goto L_0191CA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191C8 BEQ -> $0191ED
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0191ED; }
    goto L_0191CA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91C8u,0x0191C8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0191CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191CA TAY
    cpu.transfer("TAY");
    goto L_0191CB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191CA TAY
    cpu.transfer("TAY");
    goto L_0191CB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91CAu,0x0191CAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0191CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CBu, 4u + ((((0x15D0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191CB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15D0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191CE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CBu, 4u + ((((0x15D0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191CB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15D0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191CE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91CBu,0x0191CBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0191CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191CE BNE -> $0191ED
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0191ED; }
    goto L_0191D0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191CE BNE -> $0191ED
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0191ED; }
    goto L_0191D0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91CEu,0x0191CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0191D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191D0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191D2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191D0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191D2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91D0u,0x0191D0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0191D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191D2 CLC
    cpu.setFlag('C', false);
    goto L_0191D3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191D2 CLC
    cpu.setFlag('C', false);
    goto L_0191D3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91D2u,0x0191D2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0191D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D3u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D3u, 4u + ((((0x9283u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9283u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191D3 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x9283u), cpu.m8?8:16));
    goto L_0191D6;
L_0191D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D6u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191D6 STA
    hw.write(cpu.address("dpx", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_0191D8;
L_0191D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D8u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191D8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191DB;
L_0191DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DBu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DBu, 4u + ((((0x9285u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9285u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191DB ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x9285u), cpu.m8?8:16));
    goto L_0191DE;
L_0191DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DEu, 5u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191DE STA
    hw.write(cpu.address("absx", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_0191E1;
L_0191E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E1u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191E1 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191E3;
L_0191E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191E3 BNE -> $0191ED
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0191ED; }
    goto L_0191E5;
L_0191E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E5u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191E5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191E8;
L_0191E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191E8 AND
    cpu.logicAnd(0xFCu);
    goto L_0191EA;
L_0191EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EAu, 5u, 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191EA STA
    hw.write(cpu.address("absx", 0x1588u), cpu.a, cpu.m8?8:16);
    goto L_0191ED;
L_0191ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EDu, 4u + ((((0x164Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x164Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191ED LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x164Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191F0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EDu, 4u + ((((0x164Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x164Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191ED LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x164Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91EDu,0x0191EDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0191F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F0u,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F0u, 4u, 3u, cpu.address("abs", 0x1695u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191F0 EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0x1695u), cpu.m8?8:16));
    goto L_0191F3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F0u,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F0u, 4u, 3u, cpu.address("abs", 0x1695u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191F0 EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0x1695u), cpu.m8?8:16));
    goto L_0191F3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91F0u,0x0191F0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0191F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191F3 BEQ -> $019210
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_019210; }
    goto L_0191F5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191F3 BEQ -> $019210
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_019210; }
    goto L_0191F5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91F3u,0x0191F3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0191F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191F5 ASL
    cpu.aslA();
    goto L_0191F6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191F5 ASL
    cpu.aslA();
    goto L_0191F6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91F5u,0x0191F5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0191F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F6u, 4u + ((((0x166Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x166Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191F6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x166Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0191F9;
L_0191F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191F9 AND
    cpu.logicAnd(0x40u);
    goto L_0191FB;
L_0191FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FBu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FBu, 4u + ((((0x1FE2u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1FE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191FB ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1FE2u), cpu.m8?8:16));
    goto L_0191FE;
L_0191FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0191FE BNE -> $019210
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_019210; }
    goto L_019200;
L_019200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9200u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9200u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019200 BCS -> $01920C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_01920C; }
    goto L_019202;
L_019202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9202u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9202u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019202 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), false);
    goto L_019205;
L_019205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9205u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9205u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019205 BMI -> $01920C
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_01920C; }
    goto L_019207;
L_019207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u, 8u, 4u, 0x0284C0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $019207 JSL -> $0284C0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x920Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x920Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0284C0u, 0x019207u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01920B;
L_01920B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x920Bu,0x01920Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01920B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01920Bu);return;} hw.unresolvedReturn(0x01920Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01920C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Cu, 8u, 4u, 0x028528u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01920C JSL -> $028528 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x920Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9210u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x028528u, 0x01920Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019210;
L_019210:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9210u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9210u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9210u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019210 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x019210u);return;} hw.unresolvedReturn(0x019210u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9210u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9210u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019210 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x019210u);return;} hw.unresolvedReturn(0x019210u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9210u,0x019210u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_02C88C_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02C88Cu: goto L_02C88C;
    case 0x02C88Eu: goto L_02C88E;
    case 0x02C891u: goto L_02C891;
    case 0x02C893u: goto L_02C893;
    case 0x02C895u: goto L_02C895;
    case 0x02C896u: goto L_02C896;
    case 0x02C898u: goto L_02C898;
    case 0x02C89Bu: goto L_02C89B;
    case 0x02C89Cu: goto L_02C89C;
    case 0x02C89Eu: goto L_02C89E;
    case 0x02C8A0u: goto L_02C8A0;
    case 0x02C8A1u: goto L_02C8A1;
    case 0x02C8A2u: goto L_02C8A2;
    case 0x02C8A3u: goto L_02C8A3;
    case 0x02C8A4u: goto L_02C8A4;
    case 0x02C8A5u: goto L_02C8A5;
    case 0x02C8A6u: goto L_02C8A6;
    case 0x02C8A8u: goto L_02C8A8;
    case 0x02C8A9u: goto L_02C8A9;
    case 0x02C8AAu: goto L_02C8AA;
    case 0x02C8ABu: goto L_02C8AB;
    case 0x02C8ADu: goto L_02C8AD;
    case 0x02C8AFu: goto L_02C8AF;
    case 0x02C8B1u: goto L_02C8B1;
    case 0x02C8B4u: goto L_02C8B4;
    case 0x02C8B6u: goto L_02C8B6;
    case 0x02C8B9u: goto L_02C8B9;
    case 0x02C8BBu: goto L_02C8BB;
    case 0x02C8BEu: goto L_02C8BE;
    case 0x02C8C0u: goto L_02C8C0;
    case 0x02C8C2u: goto L_02C8C2;
    case 0x02C8C5u: goto L_02C8C5;
    case 0x02C8C7u: goto L_02C8C7;
    case 0x02C8C8u: goto L_02C8C8;
    case 0x02C8CBu: goto L_02C8CB;
    case 0x02C8CCu: goto L_02C8CC;
    case 0x02C8CEu: goto L_02C8CE;
    case 0x02C8D1u: goto L_02C8D1;
    case 0x02C8D3u: goto L_02C8D3;
    case 0x02C8D5u: goto L_02C8D5;
    case 0x02C8D7u: goto L_02C8D7;
    case 0x02C8D8u: goto L_02C8D8;
    case 0x02C8D9u: goto L_02C8D9;
    case 0x02C8DBu: goto L_02C8DB;
    case 0x02C8DEu: goto L_02C8DE;
    case 0x02C8E0u: goto L_02C8E0;
    case 0x02C8E2u: goto L_02C8E2;
    case 0x02C8E3u: goto L_02C8E3;
    case 0x02C8E6u: goto L_02C8E6;
    case 0x02C8E7u: goto L_02C8E7;
    case 0x02C8E9u: goto L_02C8E9;
    case 0x02C8ECu: goto L_02C8EC;
    case 0x02C8EEu: goto L_02C8EE;
    case 0x02C8F1u: goto L_02C8F1;
    case 0x02C8F3u: goto L_02C8F3;
    case 0x02C8F6u: goto L_02C8F6;
    case 0x02C8F9u: goto L_02C8F9;
    case 0x02C8FCu: goto L_02C8FC;
    case 0x02C8FDu: goto L_02C8FD;
    case 0x02C8FEu: goto L_02C8FE;
    case 0x02C8FFu: goto L_02C8FF;
    case 0x02C900u: goto L_02C900;
    case 0x02C902u: goto L_02C902;
    case 0x02C905u: goto L_02C905;
    case 0x02C908u: goto L_02C908;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02C88C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC88Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C88C STZ
    hw.write(cpu.address("dp", 0x7u), 0, cpu.m8?8:16);
    goto L_02C88E;
L_02C88E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC88Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Eu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Eu, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C88E LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1602u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02C891;
L_02C891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC891u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC891u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C891 STY
    hw.write(cpu.address("dp", 0x4u), cpu.y, cpu.x8?8:16);
    goto L_02C893;
L_02C893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC893u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC893u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C893 CPY
    cpu.compareY(0x9u);
    goto L_02C895;
L_02C895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC895u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC895u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC895u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C895 CLC
    cpu.setFlag('C', false);
    goto L_02C896;
L_02C896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC896u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC896u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C896 BNE -> $02C8AB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02C8AB; }
    goto L_02C898;
L_02C898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC898u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC898u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC898u, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C898 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C89B;
L_02C89B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC89Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C89B SEC
    cpu.setFlag('C', true);
    goto L_02C89C;
L_02C89C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC89Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C89C SBC
    cpu.sbc(0x20u);
    goto L_02C89E;
L_02C89E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC89Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C89E BCC -> $02C8AB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_02C8AB; }
    goto L_02C8A0;
L_02C8A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A0u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02C8A0 PHA
    cpu.push("PHA", hw);
    goto L_02C8A1;
L_02C8A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8A1 LSR
    cpu.lsrA();
    goto L_02C8A2;
L_02C8A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8A2 LSR
    cpu.lsrA();
    goto L_02C8A3;
L_02C8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8A3 LSR
    cpu.lsrA();
    goto L_02C8A4;
L_02C8A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8A4 LSR
    cpu.lsrA();
    goto L_02C8A5;
L_02C8A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8A5 LSR
    cpu.lsrA();
    goto L_02C8A6;
L_02C8A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8A6 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_02C8A8;
L_02C8A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A8u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02C8A8 PLA
    cpu.pop("PLA", hw);
    goto L_02C8A9;
L_02C8A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8A9 LSR
    cpu.lsrA();
    goto L_02C8AA;
L_02C8AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8AAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8AA LSR
    cpu.lsrA();
    goto L_02C8AB;
L_02C8AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8ABu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ABu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ABu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8AB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C8AD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ABu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ABu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8AB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C8AD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8ABu,0x02C8ABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02C8AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8ADu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ADu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8AD ADC
    cpu.adc(0x0u);
    goto L_02C8AF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ADu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8AD ADC
    cpu.adc(0x0u);
    goto L_02C8AF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8ADu,0x02C8ADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_02C8AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8AFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8AFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8AF STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_02C8B1;
L_02C8B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B1u, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8B1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C8B4;
L_02C8B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8B4 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_02C8B6;
L_02C8B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B6u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8B6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C8B9;
L_02C8B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8B9 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_02C8BB;
L_02C8BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8BBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8BBu, 4u + ((((0x15F6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8BB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C8BE;
L_02C8BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8BEu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8BEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8BE ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16));
    goto L_02C8C0;
L_02C8C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8C0 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_02C8C2;
L_02C8C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C2u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8C2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15EAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C8C5;
L_02C8C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8C5 STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_02C8C7;
L_02C8C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8C7 CLC
    cpu.setFlag('C', false);
    goto L_02C8C8;
L_02C8C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C8u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C8u, 4u + ((((0xC864u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xC864u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8C8 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xC864u), cpu.m8?8:16));
    goto L_02C8CB;
L_02C8CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8CB TAY
    cpu.transfer("TAY");
    goto L_02C8CC;
L_02C8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CCu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8CC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02C8CE;
L_02C8CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CEu, 4u + ((((0xC830u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xC830u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8CE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xC830u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C8D1;
L_02C8D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D1u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8D1 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02C8D3;
L_02C8D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8D3 BNE -> $02C8D8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02C8D8; }
    goto L_02C8D5;
L_02C8D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D5u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8D5 EOR
    cpu.logicXor(0xFFu);
    goto L_02C8D7;
L_02C8D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D7u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8D7 INC
    cpu.inc('A');
    goto L_02C8D8;
L_02C8D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8D8 CLC
    cpu.setFlag('C', false);
    goto L_02C8D9;
L_02C8D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D9u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8D9 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_02C8DB;
L_02C8DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DBu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DBu, 5u, 3u, cpu.address("absy", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8DB STA
    hw.write(cpu.address("absy", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_02C8DE;
L_02C8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8DE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02C8E0;
L_02C8E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8E0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C8E2;
L_02C8E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8E2 CLC
    cpu.setFlag('C', false);
    goto L_02C8E3;
L_02C8E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E3u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E3u, 4u + ((((0xC84Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xC84Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8E3 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xC84Au), cpu.m8?8:16));
    goto L_02C8E6;
L_02C8E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8E6 SEC
    cpu.setFlag('C', true);
    goto L_02C8E7;
L_02C8E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8E7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16));
    goto L_02C8E9;
L_02C8E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E9u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E9u, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8E9 STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_02C8EC;
L_02C8EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ECu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8EC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02C8EE;
L_02C8EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8EEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8EEu, 4u + ((((0xC885u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xC885u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8EE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xC885u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C8F1;
L_02C8F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F1u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8F1 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_02C8F3;
L_02C8F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F3u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F3u, 5u, 3u, cpu.address("absy", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8F3 STA
    hw.write(cpu.address("absy", 0x303u), cpu.a, cpu.m8?8:16);
    goto L_02C8F6;
L_02C8F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F6u, 4u + ((((0xC87Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xC87Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8F6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xC87Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C8F9;
L_02C8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F9u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F9u, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8F9 STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_02C8FC;
L_02C8FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FCu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8FC TYA
    cpu.transfer("TYA");
    goto L_02C8FD;
L_02C8FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8FD LSR
    cpu.lsrA();
    goto L_02C8FE;
L_02C8FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8FE LSR
    cpu.lsrA();
    goto L_02C8FF;
L_02C8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FFu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C8FF TAY
    cpu.transfer("TAY");
    goto L_02C900;
L_02C900:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC900u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC900u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC900u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C900 LDA
    cpu.setA(0x2u, 8);
    goto L_02C902;
L_02C902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC902u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC902u, 5u, 3u, cpu.address("absy", 0x0460u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C902 STA
    hw.write(cpu.address("absy", 0x460u), cpu.a, cpu.m8?8:16);
    goto L_02C905;
L_02C905:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC905u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC905u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC905u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C905 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_02C908;
L_02C908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC908u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC908u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02C908 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x02C908u);return;} hw.unresolvedReturn(0x02C908u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_049885_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x049885u: goto L_049885;
    case 0x049887u: goto L_049887;
    case 0x04988Au: goto L_04988A;
    case 0x04988Cu: goto L_04988C;
    case 0x04988Eu: goto L_04988E;
    case 0x049891u: goto L_049891;
    case 0x049892u: goto L_049892;
    case 0x049893u: goto L_049893;
    case 0x049894u: goto L_049894;
    case 0x049895u: goto L_049895;
    case 0x049897u: goto L_049897;
    case 0x049899u: goto L_049899;
    case 0x04989Bu: goto L_04989B;
    case 0x04989Cu: goto L_04989C;
    case 0x04989Du: goto L_04989D;
    case 0x04989Eu: goto L_04989E;
    case 0x04989Fu: goto L_04989F;
    case 0x0498A2u: goto L_0498A2;
    case 0x0498A4u: goto L_0498A4;
    case 0x0498A6u: goto L_0498A6;
    case 0x0498A8u: goto L_0498A8;
    case 0x0498ABu: goto L_0498AB;
    case 0x0498ADu: goto L_0498AD;
    case 0x0498AFu: goto L_0498AF;
    case 0x0498B0u: goto L_0498B0;
    case 0x0498B3u: goto L_0498B3;
    case 0x0498B5u: goto L_0498B5;
    case 0x0498B8u: goto L_0498B8;
    case 0x0498BBu: goto L_0498BB;
    case 0x0498BDu: goto L_0498BD;
    case 0x0498BFu: goto L_0498BF;
    case 0x0498C0u: goto L_0498C0;
    case 0x0498C3u: goto L_0498C3;
    case 0x0498C5u: goto L_0498C5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_049885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9885u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9885u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049885 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049887;
L_049887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9887u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9887u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049887 AND
    cpu.logicAnd(0xFu);
    goto L_04988A;
L_04988A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04988A STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_04988C;
L_04988C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04988C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04988E;
L_04988E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04988E AND
    cpu.logicAnd(0x10u);
    goto L_049891;
L_049891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9891u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9891u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049891 ASL
    cpu.aslA();
    goto L_049892;
L_049892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9892u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9892u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049892 ASL
    cpu.aslA();
    goto L_049893;
L_049893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9893u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9893u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049893 ASL
    cpu.aslA();
    goto L_049894;
L_049894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9894u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9894u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049894 ASL
    cpu.aslA();
    goto L_049895;
L_049895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9895u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9895u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9895u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049895 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_049897;
L_049897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9897u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9897u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049897 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_049899;
L_049899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9899u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9899u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049899 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04989B;
L_04989B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04989B ASL
    cpu.aslA();
    goto L_04989C;
L_04989C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04989C ASL
    cpu.aslA();
    goto L_04989D;
L_04989D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04989D ASL
    cpu.aslA();
    goto L_04989E;
L_04989E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04989E ASL
    cpu.aslA();
    goto L_04989F;
L_04989F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04989F AND
    cpu.logicAnd(0xFFu);
    goto L_0498A2;
L_0498A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A2u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498A2 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_0498A4;
L_0498A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498A4 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_0498A6;
L_0498A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0498A8;
L_0498A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498A8 AND
    cpu.logicAnd(0x10u);
    goto L_0498AB;
L_0498AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98ABu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498AB BEQ -> $0498B5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0498B5; }
    goto L_0498AD;
L_0498AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98ADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498AD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0498AF;
L_0498AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98AFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498AF CLC
    cpu.setFlag('C', false);
    goto L_0498B0;
L_0498B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498B0 ADC
    cpu.adc(0x200u);
    goto L_0498B3;
L_0498B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498B3 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_0498B5;
L_0498B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B5u, 5u + 1u, 3u, cpu.address("absx", 0x1F11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498B5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0498B8;
L_0498B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498B8 AND
    cpu.logicAnd(0xFFu);
    goto L_0498BB;
L_0498BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498BB BEQ -> $0498C5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0498C5; }
    goto L_0498BD;
L_0498BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498BD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0498BF;
L_0498BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498BF CLC
    cpu.setFlag('C', false);
    goto L_0498C0;
L_0498C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498C0 ADC
    cpu.adc(0x400u);
    goto L_0498C3;
L_0498C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498C3 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_0498C5;
L_0498C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0498C5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0498C5u);return;} hw.unresolvedReturn(0x0498C5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04DA49_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04DA49u: goto L_04DA49;
    case 0x04DA4Bu: goto L_04DA4B;
    case 0x04DA4Du: goto L_04DA4D;
    case 0x04DA50u: goto L_04DA50;
    case 0x04DA51u: goto L_04DA51;
    case 0x04DA52u: goto L_04DA52;
    case 0x04DA53u: goto L_04DA53;
    case 0x04DA54u: goto L_04DA54;
    case 0x04DA56u: goto L_04DA56;
    case 0x04DA59u: goto L_04DA59;
    case 0x04DA5Au: goto L_04DA5A;
    case 0x04DA5Cu: goto L_04DA5C;
    case 0x04DA5Fu: goto L_04DA5F;
    case 0x04DA63u: goto L_04DA63;
    case 0x04DA65u: goto L_04DA65;
    case 0x04DA67u: goto L_04DA67;
    case 0x04DA6Au: goto L_04DA6A;
    case 0x04DA6Cu: goto L_04DA6C;
    case 0x04DA6Eu: goto L_04DA6E;
    case 0x04DA71u: goto L_04DA71;
    case 0x04DA72u: goto L_04DA72;
    case 0x04DA73u: goto L_04DA73;
    case 0x04DA77u: goto L_04DA77;
    case 0x04DA78u: goto L_04DA78;
    case 0x04DA7Bu: goto L_04DA7B;
    case 0x04DA7Du: goto L_04DA7D;
    case 0x04DA7Fu: goto L_04DA7F;
    case 0x04DA81u: goto L_04DA81;
    case 0x04DA83u: goto L_04DA83;
    case 0x04DA87u: goto L_04DA87;
    case 0x04DA89u: goto L_04DA89;
    case 0x04DA8Au: goto L_04DA8A;
    case 0x04DA8Cu: goto L_04DA8C;
    case 0x04DA8Fu: goto L_04DA8F;
    case 0x04DA93u: goto L_04DA93;
    case 0x04DA95u: goto L_04DA95;
    case 0x04DA98u: goto L_04DA98;
    case 0x04DA9Au: goto L_04DA9A;
    case 0x04DA9Bu: goto L_04DA9B;
    case 0x04DA9Du: goto L_04DA9D;
    case 0x04DA9Fu: goto L_04DA9F;
    case 0x04DAA2u: goto L_04DAA2;
    case 0x04DAA4u: goto L_04DAA4;
    case 0x04DAA7u: goto L_04DAA7;
    case 0x04DAA9u: goto L_04DAA9;
    case 0x04DAACu: goto L_04DAAC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04DA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA49u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA49u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA49 REP
    cpu.rep(0x30u);
    goto L_04DA4B;
L_04DA4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA4B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04DA4D;
L_04DA4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA4D AND
    cpu.logicAnd(0xF8u);
    goto L_04DA50;
L_04DA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA50u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA50 LSR
    cpu.lsrA();
    goto L_04DA51;
L_04DA51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA51u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA51 LSR
    cpu.lsrA();
    goto L_04DA52;
L_04DA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA52u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA52u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA52 LSR
    cpu.lsrA();
    goto L_04DA53;
L_04DA53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA53u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA53u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA53 TAY
    cpu.transfer("TAY");
    goto L_04DA54;
L_04DA54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA54u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA54u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA54 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04DA56;
L_04DA56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA56u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA56u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA56 AND
    cpu.logicAnd(0x7u);
    goto L_04DA59;
L_04DA59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA59u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA59u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA59 TAX
    cpu.transfer("TAX");
    goto L_04DA5A;
L_04DA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA5A SEP
    cpu.sep(0x20u);
    goto L_04DA5C;
L_04DA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Cu, 4u + 1u, 3u, cpu.address("absy", 0x1F02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA5C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1F02u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04DA5F;
L_04DA5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Fu,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA5Fu, 5u, 4u, ((0x04E44Bu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA5F AND
    cpu.logicAnd(hw.readW(((0x4E44Bu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_04DA63;
L_04DA63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA63u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA63 BEQ -> $04DAAC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04DAAC; }
    goto L_04DA65;
L_04DA65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA65u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA65u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA65 REP
    cpu.rep(0x20u);
    goto L_04DA67;
L_04DA67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA67u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA67u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA67 LDA
    cpu.setA(0xC800u, 16);
    goto L_04DA6A;
L_04DA6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA6A STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_04DA6C;
L_04DA6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA6C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04DA6E;
L_04DA6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA6Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA6E AND
    cpu.logicAnd(0xFFu);
    goto L_04DA71;
L_04DA71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA71u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA71u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA71 ASL
    cpu.aslA();
    goto L_04DA72;
L_04DA72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA72u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA72u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA72 TAX
    cpu.transfer("TAX");
    goto L_04DA73;
L_04DA73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA73u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA73u, 6u, 4u, ((0x04D85Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA73 LDA
    cpu.loadA(hw.readW(((0x4D85Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04DA77;
L_04DA77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA77u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA77u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA77 TAY
    cpu.transfer("TAY");
    goto L_04DA78;
L_04DA78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA78u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA78u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA78 LDX
    cpu.setX(0x15u, 16);
    goto L_04DA7B;
L_04DA7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA7B SEP
    cpu.sep(0x20u);
    goto L_04DA7D;
L_04DA7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA7D LDA
    cpu.setA(0x7Eu, 8);
    goto L_04DA7F;
L_04DA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA7Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA7F STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_04DA81;
L_04DA81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA81u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA81u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 3u, 0u);
    // $04DA81 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04DA83;
L_04DA83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA83u,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA83u, 5u, 4u, ((0x04DA1Du + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA83 CMP
    cpu.compareA(hw.readW(((0x4DA1Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_04DA87;
L_04DA87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA87u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA87 BEQ -> $04DA8F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04DA8F; }
    goto L_04DA89;
L_04DA89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA89u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA89 DEX
    cpu.decReg('X');
    goto L_04DA8A;
L_04DA8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA8A BPL -> $04DA83
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04DA83; }
    goto L_04DA8C;
L_04DA8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Cu, 3u, 3u, cpu.address("abs", 0xDA9Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA8C JMP -> $04DA9D
    goto L_04DA9D;
L_04DA8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA8Fu, 5u, 4u, ((0x04DA33u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA8F LDA
    cpu.loadA(hw.readW(((0x4DA33u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04DA93;
L_04DA93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA93u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA93u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 3u, 0u);
    // $04DA93 STA
    hw.write(cpu.addressDpLongY(hw, 0x4u), cpu.a, cpu.m8?8:16);
    goto L_04DA95;
L_04DA95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA95u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA95u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA95 CPX
    cpu.compareX(0x15u);
    goto L_04DA98;
L_04DA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA98u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA98 BNE -> $04DA9D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04DA9D; }
    goto L_04DA9A;
L_04DA9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA9A INY
    cpu.inc('Y');
    goto L_04DA9B;
L_04DA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Bu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 3u, 0u);
    // $04DA9B STA
    hw.write(cpu.addressDpLongY(hw, 0x4u), cpu.a, cpu.m8?8:16);
    goto L_04DA9D;
L_04DA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DA9D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04DA9F;
L_04DA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA9Fu, 6u, 3u, cpu.address("abs", 0xE677u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04DA9F JSR -> $04E677 stack real
    { cpu.push16Value(hw,0xDAA1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDAA2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE677u), 0x04DA9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04DAA2;
L_04DAA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DAA2 SEP
    cpu.sep(0x10u);
    goto L_04DAA4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DAA2 SEP
    cpu.sep(0x10u);
    goto L_04DAA4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDAA2u,0x04DAA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04DAA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA4u, 4u, 3u, cpu.address("abs", 0x1B86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DAA4 STZ
    hw.write(cpu.address("abs", 0x1B86u), 0, cpu.m8?8:16);
    goto L_04DAA7;
L_04DAA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DAA7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04DAA9;
L_04DAA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA9u, 6u, 3u, cpu.address("abs", 0xE9F1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04DAA9 JSR -> $04E9F1 stack real
    { cpu.push16Value(hw,0xDAABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDAACu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE9F1u), 0x04DAA9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04DAAC;
L_04DAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAACu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAACu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAACu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04DAAC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04DAACu);return;} hw.unresolvedReturn(0x04DAACu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAACu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAACu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04DAAC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04DAACu);return;} hw.unresolvedReturn(0x04DAACu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDAACu,0x04DAACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_04DD40_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04DD40u: goto L_04DD40;
    case 0x04DD42u: goto L_04DD42;
    case 0x04DD44u: goto L_04DD44;
    case 0x04DD47u: goto L_04DD47;
    case 0x04DD49u: goto L_04DD49;
    case 0x04DD4Bu: goto L_04DD4B;
    case 0x04DD4Du: goto L_04DD4D;
    case 0x04DD50u: goto L_04DD50;
    case 0x04DD51u: goto L_04DD51;
    case 0x04DD54u: goto L_04DD54;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04DD40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD40u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD40u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD40 REP
    cpu.rep(0x10u);
    goto L_04DD42;
L_04DD42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD42u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD42u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD42 SEP
    cpu.sep(0x20u);
    goto L_04DD44;
L_04DD44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD44u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD44 LDY
    cpu.setY(0x8D00u, 16);
    goto L_04DD47;
L_04DD47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD47u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD47u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD47 STY
    hw.write(cpu.address("dp", 0x2u), cpu.y, cpu.x8?8:16);
    goto L_04DD49;
L_04DD49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD49u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD49u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD49 LDA
    cpu.setA(0xCu, 8);
    goto L_04DD4B;
L_04DD4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD4Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD4Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD4B STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_04DD4D;
L_04DD4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD4Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD4D LDX
    cpu.setX(0x0u, 16);
    goto L_04DD50;
L_04DD50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD50u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD50 TXY
    cpu.transfer("TXY");
    goto L_04DD51;
L_04DD51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u, 6u, 3u, cpu.address("abs", 0xDD57u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04DD51 JSR -> $04DD57 stack real
    { cpu.push16Value(hw,0xDD53u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDD54u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDD57u), 0x04DD51u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04DD54;
L_04DD54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD54u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD54u,0x04DD54u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD54u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD54u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD54 SEP
    cpu.sep(0x30u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD56u,0x04DD54u); return;
}

void sub_04DD40_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04DD40u: goto L_04DD40;
    case 0x04DD42u: goto L_04DD42;
    case 0x04DD44u: goto L_04DD44;
    case 0x04DD47u: goto L_04DD47;
    case 0x04DD49u: goto L_04DD49;
    case 0x04DD4Bu: goto L_04DD4B;
    case 0x04DD4Du: goto L_04DD4D;
    case 0x04DD50u: goto L_04DD50;
    case 0x04DD51u: goto L_04DD51;
    case 0x04DD54u: goto L_04DD54;
    case 0x04DD56u: goto L_04DD56;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04DD40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD40u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD40u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD40 REP
    cpu.rep(0x10u);
    goto L_04DD42;
L_04DD42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD42u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD42u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD42 SEP
    cpu.sep(0x20u);
    goto L_04DD44;
L_04DD44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD44u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD44 LDY
    cpu.setY(0x8D00u, 16);
    goto L_04DD47;
L_04DD47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD47u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD47u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD47 STY
    hw.write(cpu.address("dp", 0x2u), cpu.y, cpu.x8?8:16);
    goto L_04DD49;
L_04DD49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD49u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD49u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD49 LDA
    cpu.setA(0xCu, 8);
    goto L_04DD4B;
L_04DD4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD4Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD4Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD4B STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_04DD4D;
L_04DD4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD4Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD4D LDX
    cpu.setX(0x0u, 16);
    goto L_04DD50;
L_04DD50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD50u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD50 TXY
    cpu.transfer("TXY");
    goto L_04DD51;
L_04DD51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD51u, 6u, 3u, cpu.address("abs", 0xDD57u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04DD51 JSR -> $04DD57 stack real
    { cpu.push16Value(hw,0xDD53u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDD54u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDD57u), 0x04DD51u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04DD54;
L_04DD54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD54u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD54u,0x04DD54u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD54u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD54u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04DD54 SEP
    cpu.sep(0x30u);
    goto L_04DD56;
L_04DD56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD56u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD56u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04DD56 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04DD56u);return;} hw.unresolvedReturn(0x04DD56u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04E496_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04E496u: goto L_04E496;
    case 0x04E498u: goto L_04E498;
    case 0x04E49Bu: goto L_04E49B;
    case 0x04E49Cu: goto L_04E49C;
    case 0x04E49Du: goto L_04E49D;
    case 0x04E49Eu: goto L_04E49E;
    case 0x04E4A2u: goto L_04E4A2;
    case 0x04E4A3u: goto L_04E4A3;
    case 0x04E4A7u: goto L_04E4A7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04E496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE496u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE496u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E496 REP
    cpu.rep(0x30u);
    goto L_04E498;
L_04E498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE498u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE498u, 5u, 3u, cpu.address("abs", 0x1DEBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E498 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DEBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E49B;
L_04E49B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E49B ASL
    cpu.aslA();
    goto L_04E49C;
L_04E49C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E49C ASL
    cpu.aslA();
    goto L_04E49D;
L_04E49D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E49D TAX
    cpu.transfer("TAX");
    goto L_04E49E;
L_04E49E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Eu, 6u, 4u, ((0x04DD8Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E49E LDA
    cpu.loadA(hw.readW(((0x4DD8Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E4A2;
L_04E4A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A2u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4A2 TAY
    cpu.transfer("TAY");
    goto L_04E4A3;
L_04E4A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A3u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A3u, 6u, 4u, ((0x04DD8Fu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4A3 LDA
    cpu.loadA(hw.readW(((0x4DD8Fu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E4A7;
L_04E4A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4A7 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE4A9u,0x04E4A7u); return;
}

void sub_04F407_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04F407u: goto L_04F407;
    case 0x04F409u: goto L_04F409;
    case 0x04F40Bu: goto L_04F40B;
    case 0x04F40Du: goto L_04F40D;
    case 0x04F410u: goto L_04F410;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04F407:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF407u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF407u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF407u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F407 STZ
    hw.write(cpu.address("dp", 0x41u), 0, cpu.m8?8:16);
    goto L_04F409;
L_04F409:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF409u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF409u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF409u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F409 STZ
    hw.write(cpu.address("dp", 0x42u), 0, cpu.m8?8:16);
    goto L_04F40B;
L_04F40B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF40Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF40Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF40Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F40B STZ
    hw.write(cpu.address("dp", 0x43u), 0, cpu.m8?8:16);
    goto L_04F40D;
L_04F40D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF40Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF40Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF40Du, 4u, 3u, cpu.address("abs", 0x0D9Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F40D STZ
    hw.write(cpu.address("abs", 0xD9Fu), 0, cpu.m8?8:16);
    goto L_04F410;
L_04F410:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF410u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF410u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF410u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F410 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04F410u);return;} hw.unresolvedReturn(0x04F410u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_058770_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x058770u: goto L_058770;
    case 0x058774u: goto L_058774;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_058770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8770u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8770u, 8u, 4u, 0x058883u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058770 JSL -> $058883 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8773u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8774u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x058883u, 0x058770u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_058774;
L_058774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8774u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8774u,0x058774u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058774 PLP
    cpu.pop("PLP", hw);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8775u,0x058774u); return;
}

void sub_07F1CA_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x07F1CAu: goto L_07F1CA;
    case 0x07F1CDu: goto L_07F1CD;
    case 0x07F1CFu: goto L_07F1CF;
    case 0x07F1D1u: goto L_07F1D1;
    case 0x07F1D4u: goto L_07F1D4;
    case 0x07F1D5u: goto L_07F1D5;
    case 0x07F1D6u: goto L_07F1D6;
    case 0x07F1D7u: goto L_07F1D7;
    case 0x07F1DBu: goto L_07F1DB;
    case 0x07F1DCu: goto L_07F1DC;
    case 0x07F1DDu: goto L_07F1DD;
    case 0x07F1DEu: goto L_07F1DE;
    case 0x07F1DFu: goto L_07F1DF;
    case 0x07F1E0u: goto L_07F1E0;
    case 0x07F1E1u: goto L_07F1E1;
    case 0x07F1E3u: goto L_07F1E3;
    case 0x07F1E7u: goto L_07F1E7;
    case 0x07F1E8u: goto L_07F1E8;
    case 0x07F1EAu: goto L_07F1EA;
    case 0x07F1EDu: goto L_07F1ED;
    case 0x07F1EEu: goto L_07F1EE;
    case 0x07F1F0u: goto L_07F1F0;
    case 0x07F1F1u: goto L_07F1F1;
    case 0x07F1F5u: goto L_07F1F5;
    case 0x07F1F6u: goto L_07F1F6;
    case 0x07F1F8u: goto L_07F1F8;
    case 0x07F1FAu: goto L_07F1FA;
    case 0x07F1FCu: goto L_07F1FC;
    case 0x07F1FFu: goto L_07F1FF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_07F1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CAu, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1CA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F1CD;
L_07F1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1CD STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_07F1CF;
L_07F1CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CFu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1CF STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_07F1D1;
L_07F1D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D1u, 4u + ((((0x1594u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1594u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1D1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1594u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F1D4;
L_07F1D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1D4 LSR
    cpu.lsrA();
    goto L_07F1D5;
L_07F1D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1D5 LSR
    cpu.lsrA();
    goto L_07F1D6;
L_07F1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1D6 TAX
    cpu.transfer("TAX");
    goto L_07F1D7;
L_07F1D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D7u, 5u, 4u, ((0x07F1AAu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1D7 LDA
    cpu.loadA(hw.readW(((0x7F1AAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F1DB;
L_07F1DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DBu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F1DB PHA
    cpu.push("PHA", hw);
    goto L_07F1DC;
L_07F1DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DCu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1DC LSR
    cpu.lsrA();
    goto L_07F1DD;
L_07F1DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1DD LSR
    cpu.lsrA();
    goto L_07F1DE;
L_07F1DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1DE LSR
    cpu.lsrA();
    goto L_07F1DF;
L_07F1DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1DF LSR
    cpu.lsrA();
    goto L_07F1E0;
L_07F1E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1E0 TAX
    cpu.transfer("TAX");
    goto L_07F1E1;
L_07F1E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1E1 BEQ -> $07F1ED
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_07F1ED; }
    goto L_07F1E3;
L_07F1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E3u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E3u, 5u, 4u, ((0x07F1A0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1E3 LDA
    cpu.loadA(hw.readW(((0x7F1A0u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F1E7;
L_07F1E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1E7 TAX
    cpu.transfer("TAX");
    goto L_07F1E8;
L_07F1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1E8 LDY
    cpu.setY(0x20u, 8);
    goto L_07F1EA;
L_07F1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EAu, 6u, 3u, cpu.address("abs", 0xF200u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $07F1EA JSR -> $07F200 stack real
    { cpu.push16Value(hw,0xF1ECu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF1EDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF200u), 0x07F1EAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_07F1ED;
L_07F1ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF1EDu,0x07F1EDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EDu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F1ED PLA
    cpu.pop("PLA", hw);
    goto L_07F1EE;
L_07F1EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1EE AND
    cpu.logicAnd(0xFu);
    goto L_07F1F0;
L_07F1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1F0 TAX
    cpu.transfer("TAX");
    goto L_07F1F1;
L_07F1F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F1u, 5u, 4u, ((0x07F1A0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1F1 LDA
    cpu.loadA(hw.readW(((0x7F1A0u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F1F5;
L_07F1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1F5 TAX
    cpu.transfer("TAX");
    goto L_07F1F6;
L_07F1F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1F6 LDA
    cpu.setA(0x20u, 8);
    goto L_07F1F8;
L_07F1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1F8 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_07F1FA;
L_07F1FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1FA LDY
    cpu.setY(0x54u, 8);
    goto L_07F1FC;
L_07F1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FCu, 6u, 3u, cpu.address("abs", 0xF200u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $07F1FC JSR -> $07F200 stack real
    { cpu.push16Value(hw,0xF1FEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF1FFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF200u), 0x07F1FCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_07F1FF;
L_07F1FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1FFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF1FFu,0x07F1FFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F1FF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x07F1FFu);return;} hw.unresolvedReturn(0x07F1FFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_07F1CA_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x07F1CAu: goto L_07F1CA;
    case 0x07F1CDu: goto L_07F1CD;
    case 0x07F1CFu: goto L_07F1CF;
    case 0x07F1D1u: goto L_07F1D1;
    case 0x07F1D4u: goto L_07F1D4;
    case 0x07F1D5u: goto L_07F1D5;
    case 0x07F1D6u: goto L_07F1D6;
    case 0x07F1D7u: goto L_07F1D7;
    case 0x07F1DBu: goto L_07F1DB;
    case 0x07F1DCu: goto L_07F1DC;
    case 0x07F1DDu: goto L_07F1DD;
    case 0x07F1DEu: goto L_07F1DE;
    case 0x07F1DFu: goto L_07F1DF;
    case 0x07F1E0u: goto L_07F1E0;
    case 0x07F1E1u: goto L_07F1E1;
    case 0x07F1E3u: goto L_07F1E3;
    case 0x07F1E7u: goto L_07F1E7;
    case 0x07F1E8u: goto L_07F1E8;
    case 0x07F1EAu: goto L_07F1EA;
    case 0x07F1EDu: goto L_07F1ED;
    case 0x07F1EEu: goto L_07F1EE;
    case 0x07F1F0u: goto L_07F1F0;
    case 0x07F1F1u: goto L_07F1F1;
    case 0x07F1F5u: goto L_07F1F5;
    case 0x07F1F6u: goto L_07F1F6;
    case 0x07F1F8u: goto L_07F1F8;
    case 0x07F1FAu: goto L_07F1FA;
    case 0x07F1FCu: goto L_07F1FC;
    case 0x07F1FFu: goto L_07F1FF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_07F1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CAu, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1CA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F1CD;
L_07F1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1CD STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_07F1CF;
L_07F1CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CFu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1CF STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_07F1D1;
L_07F1D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D1u, 4u + ((((0x1594u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1594u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1D1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1594u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F1D4;
L_07F1D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1D4 LSR
    cpu.lsrA();
    goto L_07F1D5;
L_07F1D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1D5 LSR
    cpu.lsrA();
    goto L_07F1D6;
L_07F1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1D6 TAX
    cpu.transfer("TAX");
    goto L_07F1D7;
L_07F1D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D7u, 5u, 4u, ((0x07F1AAu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1D7 LDA
    cpu.loadA(hw.readW(((0x7F1AAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F1DB;
L_07F1DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DBu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F1DB PHA
    cpu.push("PHA", hw);
    goto L_07F1DC;
L_07F1DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DCu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1DC LSR
    cpu.lsrA();
    goto L_07F1DD;
L_07F1DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1DD LSR
    cpu.lsrA();
    goto L_07F1DE;
L_07F1DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1DE LSR
    cpu.lsrA();
    goto L_07F1DF;
L_07F1DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1DF LSR
    cpu.lsrA();
    goto L_07F1E0;
L_07F1E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1E0 TAX
    cpu.transfer("TAX");
    goto L_07F1E1;
L_07F1E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1E1 BEQ -> $07F1ED
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_07F1ED; }
    goto L_07F1E3;
L_07F1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E3u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E3u, 5u, 4u, ((0x07F1A0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1E3 LDA
    cpu.loadA(hw.readW(((0x7F1A0u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F1E7;
L_07F1E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1E7 TAX
    cpu.transfer("TAX");
    goto L_07F1E8;
L_07F1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1E8 LDY
    cpu.setY(0x20u, 8);
    goto L_07F1EA;
L_07F1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EAu, 6u, 3u, cpu.address("abs", 0xF200u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $07F1EA JSR -> $07F200 stack real
    { cpu.push16Value(hw,0xF1ECu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF1EDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF200u), 0x07F1EAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_07F1ED;
L_07F1ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF1EDu,0x07F1EDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EDu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F1ED PLA
    cpu.pop("PLA", hw);
    goto L_07F1EE;
L_07F1EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1EE AND
    cpu.logicAnd(0xFu);
    goto L_07F1F0;
L_07F1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1F0 TAX
    cpu.transfer("TAX");
    goto L_07F1F1;
L_07F1F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F1u, 5u, 4u, ((0x07F1A0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1F1 LDA
    cpu.loadA(hw.readW(((0x7F1A0u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F1F5;
L_07F1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1F5 TAX
    cpu.transfer("TAX");
    goto L_07F1F6;
L_07F1F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1F6 LDA
    cpu.setA(0x20u, 8);
    goto L_07F1F8;
L_07F1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1F8 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_07F1FA;
L_07F1FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F1FA LDY
    cpu.setY(0x54u, 8);
    goto L_07F1FC;
L_07F1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FCu, 6u, 3u, cpu.address("abs", 0xF200u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $07F1FC JSR -> $07F200 stack real
    { cpu.push16Value(hw,0xF1FEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF1FFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF200u), 0x07F1FCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_07F1FF;
L_07F1FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1FFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF1FFu,0x07F1FFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F1FF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x07F1FFu);return;} hw.unresolvedReturn(0x07F1FFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0C9EB1_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0C9EB1u: goto L_0C9EB1;
    case 0x0C9EB3u: goto L_0C9EB3;
    case 0x0C9EB7u: goto L_0C9EB7;
    case 0x0C9EB8u: goto L_0C9EB8;
    case 0x0C9EBBu: goto L_0C9EBB;
    case 0x0C9EBDu: goto L_0C9EBD;
    case 0x0C9EBFu: goto L_0C9EBF;
    case 0x0C9EC3u: goto L_0C9EC3;
    case 0x0C9EC5u: goto L_0C9EC5;
    case 0x0C9EC9u: goto L_0C9EC9;
    case 0x0C9ECAu: goto L_0C9ECA;
    case 0x0C9ECBu: goto L_0C9ECB;
    case 0x0C9ECEu: goto L_0C9ECE;
    case 0x0C9ED2u: goto L_0C9ED2;
    case 0x0C9ED3u: goto L_0C9ED3;
    case 0x0C9ED4u: goto L_0C9ED4;
    case 0x0C9ED7u: goto L_0C9ED7;
    case 0x0C9ED9u: goto L_0C9ED9;
    case 0x0C9EDBu: goto L_0C9EDB;
    case 0x0C9EDCu: goto L_0C9EDC;
    case 0x0C9EDDu: goto L_0C9EDD;
    case 0x0C9EE1u: goto L_0C9EE1;
    case 0x0C9EE3u: goto L_0C9EE3;
    case 0x0C9EE6u: goto L_0C9EE6;
    case 0x0C9EE7u: goto L_0C9EE7;
    case 0x0C9EE8u: goto L_0C9EE8;
    case 0x0C9EEBu: goto L_0C9EEB;
    case 0x0C9EECu: goto L_0C9EEC;
    case 0x0C9EEEu: goto L_0C9EEE;
    case 0x0C9EF0u: goto L_0C9EF0;
    case 0x0C9EF3u: goto L_0C9EF3;
    case 0x0C9EF5u: goto L_0C9EF5;
    case 0x0C9EF7u: goto L_0C9EF7;
    case 0x0C9EFAu: goto L_0C9EFA;
    case 0x0C9EFCu: goto L_0C9EFC;
    case 0x0C9EFFu: goto L_0C9EFF;
    case 0x0C9F01u: goto L_0C9F01;
    case 0x0C9F03u: goto L_0C9F03;
    case 0x0C9F04u: goto L_0C9F04;
    case 0x0C9F05u: goto L_0C9F05;
    case 0x0C9F07u: goto L_0C9F07;
    case 0x0C9F0Bu: goto L_0C9F0B;
    case 0x0C9F0Du: goto L_0C9F0D;
    case 0x0C9F0Eu: goto L_0C9F0E;
    case 0x0C9F10u: goto L_0C9F10;
    case 0x0C9F14u: goto L_0C9F14;
    case 0x0C9F15u: goto L_0C9F15;
    case 0x0C9F16u: goto L_0C9F16;
    case 0x0C9F18u: goto L_0C9F18;
    case 0x0C9F1Cu: goto L_0C9F1C;
    case 0x0C9F1Eu: goto L_0C9F1E;
    case 0x0C9F22u: goto L_0C9F22;
    case 0x0C9F23u: goto L_0C9F23;
    case 0x0C9F24u: goto L_0C9F24;
    case 0x0C9F26u: goto L_0C9F26;
    case 0x0C9F29u: goto L_0C9F29;
    case 0x0C9F2Du: goto L_0C9F2D;
    case 0x0C9F2Eu: goto L_0C9F2E;
    case 0x0C9F2Fu: goto L_0C9F2F;
    case 0x0C9F30u: goto L_0C9F30;
    case 0x0C9F31u: goto L_0C9F31;
    case 0x0C9F33u: goto L_0C9F33;
    case 0x0C9F35u: goto L_0C9F35;
    case 0x0C9F37u: goto L_0C9F37;
    case 0x0C9F3Au: goto L_0C9F3A;
    case 0x0C9F3Eu: goto L_0C9F3E;
    case 0x0C9F3Fu: goto L_0C9F3F;
    case 0x0C9F43u: goto L_0C9F43;
    case 0x0C9F45u: goto L_0C9F45;
    case 0x0C9F47u: goto L_0C9F47;
    case 0x0C9F49u: goto L_0C9F49;
    case 0x0C9F4Au: goto L_0C9F4A;
    case 0x0C9F4Du: goto L_0C9F4D;
    case 0x0C9F4Fu: goto L_0C9F4F;
    case 0x0C9F52u: goto L_0C9F52;
    case 0x0C9F54u: goto L_0C9F54;
    case 0x0C9F56u: goto L_0C9F56;
    case 0x0C9F59u: goto L_0C9F59;
    case 0x0C9F5Bu: goto L_0C9F5B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0C9EB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EB1 REP
    cpu.rep(0x30u);
    goto L_0C9EB3;
L_0C9EB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB3u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB3u, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EB3 LDA
    cpu.loadA(hw.readW(0x7F837Bu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9EB7;
L_0C9EB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EB7 TAX
    cpu.transfer("TAX");
    goto L_0C9EB8;
L_0C9EB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EB8 LDY
    cpu.setY(0x0u, 16);
    goto L_0C9EBB;
L_0C9EBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBBu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EBB SEP
    cpu.sep(0x20u);
    goto L_0C9EBD;
L_0C9EBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x66u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EBD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x66u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9EBF;
L_0C9EBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBFu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBFu, 5u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EBF STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0C9EC3;
L_0C9EC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EC3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9EC5;
L_0C9EC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC5u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC5u, 5u, 4u, ((0x7F837Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EC5 STA
    hw.write(((0x7F837Eu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0C9EC9;
L_0C9EC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EC9 INX
    cpu.inc('X');
    goto L_0C9ECA;
L_0C9ECA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9ECA INX
    cpu.inc('X');
    goto L_0C9ECB;
L_0C9ECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu, 4u + 1u, 3u, cpu.address("absy", 0x9EACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9ECB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9EACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9ECE;
L_0C9ECE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECEu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECEu, 5u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9ECE STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0C9ED2;
L_0C9ED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9ED2 INX
    cpu.inc('X');
    goto L_0C9ED3;
L_0C9ED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9ED3 INY
    cpu.inc('Y');
    goto L_0C9ED4;
L_0C9ED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED4u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9ED4 CPY
    cpu.compareY(0x5u);
    goto L_0C9ED7;
L_0C9ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9ED7 BNE -> $0C9ECB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0C9ECB; }
    goto L_0C9ED9;
L_0C9ED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9ED9 REP
    cpu.rep(0x20u);
    goto L_0C9EDB;
L_0C9EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EDB DEX
    cpu.decReg('X');
    goto L_0C9EDC;
L_0C9EDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDCu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EDC TXA
    cpu.transfer("TXA");
    goto L_0C9EDD;
L_0C9EDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDDu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDDu, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EDD STA
    hw.write(0x7F837Bu, cpu.a, cpu.m8?8:16);
    goto L_0C9EE1;
L_0C9EE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EE1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9EE3;
L_0C9EE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EE3 AND
    cpu.logicAnd(0xFFu);
    goto L_0C9EE6;
L_0C9EE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EE6 ASL
    cpu.aslA();
    goto L_0C9EE7;
L_0C9EE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EE7 TAY
    cpu.transfer("TAY");
    goto L_0C9EE8;
L_0C9EE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE8u, 5u + 1u, 3u, cpu.address("absy", 0x9D18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EE8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9D18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9EEB;
L_0C9EEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EEB TAY
    cpu.transfer("TAY");
    goto L_0C9EEC;
L_0C9EEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EECu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EECu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EEC SEP
    cpu.sep(0x20u);
    goto L_0C9EEE;
L_0C9EEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEEu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EEE INC
    cpu.incMem(hw, cpu.address("dp", 0x67u), cpu.m8?8:16);
    goto L_0C9EF0;
L_0C9EF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF0u, 4u + 1u, 3u, cpu.address("absy", 0x95C7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EF0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x95C7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9EF3;
L_0C9EF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EF3 CMP
    cpu.compareA(0xFFu);
    goto L_0C9EF5;
L_0C9EF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EF5 BEQ -> $0C9F43
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0C9F43; }
    goto L_0C9EF7;
L_0C9EF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF7u, 4u + 1u, 3u, cpu.address("absy", 0x95C7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EF7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x95C7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9EFA;
L_0C9EFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EFA STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0C9EFC;
L_0C9EFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFCu, 4u + 1u, 3u, cpu.address("absy", 0x95C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EFC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x95C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9EFF;
L_0C9EFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9EFF STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0C9F01;
L_0C9F01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F01u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F01u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F01 STZ
    hw.write(cpu.address("dp", 0x1u), 0, cpu.m8?8:16);
    goto L_0C9F03;
L_0C9F03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F03u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F03 INY
    cpu.inc('Y');
    goto L_0C9F04;
L_0C9F04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F04u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F04 INY
    cpu.inc('Y');
    goto L_0C9F05;
L_0C9F05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F05u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F05u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x66u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F05 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x66u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9F07;
L_0C9F07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F07u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F07u, 5u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F07 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0C9F0B;
L_0C9F0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F0B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9F0D;
L_0C9F0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F0D CLC
    cpu.setFlag('C', false);
    goto L_0C9F0E;
L_0C9F0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Eu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F0E ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_0C9F10;
L_0C9F10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F10u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F10u, 5u, 4u, ((0x7F837Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F10 STA
    hw.write(((0x7F837Eu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0C9F14;
L_0C9F14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F14u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F14u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F14 INX
    cpu.inc('X');
    goto L_0C9F15;
L_0C9F15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F15 INX
    cpu.inc('X');
    goto L_0C9F16;
L_0C9F16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F16u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F16u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F16 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9F18;
L_0C9F18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F18u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F18u, 5u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F18 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0C9F1C;
L_0C9F1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F1C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9F1E;
L_0C9F1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Eu, 5u, 4u, ((0x7F837Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F1E STA
    hw.write(((0x7F837Eu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0C9F22;
L_0C9F22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F22u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F22 INX
    cpu.inc('X');
    goto L_0C9F23;
L_0C9F23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F23u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F23 INX
    cpu.inc('X');
    goto L_0C9F24;
L_0C9F24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F24u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F24u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F24 REP
    cpu.rep(0x20u);
    goto L_0C9F26;
L_0C9F26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F26u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F26u, 5u + 1u, 3u, cpu.address("absy", 0x95C7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F26 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x95C7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9F29;
L_0C9F29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F29u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F29u, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F29 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0C9F2D;
L_0C9F2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F2D INX
    cpu.inc('X');
    goto L_0C9F2E;
L_0C9F2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F2E INX
    cpu.inc('X');
    goto L_0C9F2F;
L_0C9F2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F2F INY
    cpu.inc('Y');
    goto L_0C9F30;
L_0C9F30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F30u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F30u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F30 INY
    cpu.inc('Y');
    goto L_0C9F31;
L_0C9F31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F31u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F31u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F31 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0C9F33;
L_0C9F33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F33u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F33u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F33 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0C9F35;
L_0C9F35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F35u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F35 BPL -> $0C9F26
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0C9F26; }
    goto L_0C9F37;
L_0C9F37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F37u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F37u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F37 LDA
    cpu.setA(0xFFu, 16);
    goto L_0C9F3A;
L_0C9F3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Au,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Au, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F3A STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_0C9F3E;
L_0C9F3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F3E TXA
    cpu.transfer("TXA");
    goto L_0C9F3F;
L_0C9F3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Fu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Fu, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F3F STA
    hw.write(0x7F837Bu, cpu.a, cpu.m8?8:16);
    goto L_0C9F43;
L_0C9F43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F43u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F43 REP
    cpu.rep(0x20u);
    goto L_0C9F45;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F43 REP
    cpu.rep(0x20u);
    goto L_0C9F45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F43u,0x0C9F43u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0C9F45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F45u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F45u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F45 SEP
    cpu.sep(0x10u);
    goto L_0C9F47;
L_0C9F47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F47u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F47u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F47 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9F49;
L_0C9F49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F49u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F49 CLC
    cpu.setFlag('C', false);
    goto L_0C9F4A;
L_0C9F4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F4A ADC
    cpu.adc(0x20u);
    goto L_0C9F4D;
L_0C9F4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F4D STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_0C9F4F;
L_0C9F4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F4F AND
    cpu.logicAnd(0x3FFu);
    goto L_0C9F52;
L_0C9F52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F52u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F52u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F52 BNE -> $0C9F5B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0C9F5B; }
    goto L_0C9F54;
L_0C9F54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F54u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F54u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F54 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9F56;
L_0C9F56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F56u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F56u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F56 EOR
    cpu.logicXor(0xC00u);
    goto L_0C9F59;
L_0C9F59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F59u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F59u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9F59 STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_0C9F5B;
L_0C9F5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0C9F5B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0C9F5Bu);return;} hw.unresolvedReturn(0x0C9F5Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DDAA2_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DDAA2u: goto L_0DDAA2;
    case 0x0DDAA4u: goto L_0DDAA4;
    case 0x0DDAA6u: goto L_0DDAA6;
    case 0x0DDAA9u: goto L_0DDAA9;
    case 0x0DDAACu: goto L_0DDAAC;
    case 0x0DDAB0u: goto L_0DDAB0;
    case 0x0DDAB3u: goto L_0DDAB3;
    case 0x0DDAB4u: goto L_0DDAB4;
    case 0x0DDAB5u: goto L_0DDAB5;
    case 0x0DDAB7u: goto L_0DDAB7;
    case 0x0DDAB9u: goto L_0DDAB9;
    case 0x0DDABCu: goto L_0DDABC;
    case 0x0DDABFu: goto L_0DDABF;
    case 0x0DDAC1u: goto L_0DDAC1;
    case 0x0DDAC3u: goto L_0DDAC3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DDAA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA2u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAA2 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DDAA4;
L_0DDAA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAA4 LDX
    cpu.setX(0x0u, 8);
    goto L_0DDAA6;
L_0DDAA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA6u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDAA6 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xDAA8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDAA9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DDAA6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDAA9;
L_0DDAA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAA9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDAA9u,0x0DDAA9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAA9u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDAA9 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDAABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDAACu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDAA9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDAAC;
L_0DDAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAACu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDAACu,0x0DDAACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAACu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAACu, 5u, 4u, ((0x0DDA9Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAAC LDA
    cpu.loadA(hw.readW(((0xDDA9Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDAB0;
L_0DDAB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB0u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDAB0 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xDAB2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDAB3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DDAB0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDAB3;
L_0DDAB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAB3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDAB3u,0x0DDAB3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAB3 INX
    cpu.inc('X');
    goto L_0DDAB4;
L_0DDAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAB4 TXA
    cpu.transfer("TXA");
    goto L_0DDAB5;
L_0DDAB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAB5 AND
    cpu.logicAnd(0x1u);
    goto L_0DDAB7;
L_0DDAB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAB7 BNE -> $0DDAA9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DDAA9; }
    goto L_0DDAB9;
L_0DDAB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAB9u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDAB9 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xDABBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDABCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DDAB9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDABC;
L_0DDABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDABCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDABCu,0x0DDABCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDABCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDABCu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDABC JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xDABEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDABFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DDABCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDABF;
L_0DDABF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDABFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDABFu,0x0DDABFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDABFu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDABFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDABF CPX
    cpu.compareX(0x4u);
    goto L_0DDAC1;
L_0DDAC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAC1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAC1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDAC1 BNE -> $0DDAA9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DDAA9; }
    goto L_0DDAC3;
L_0DDAC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAC3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAC3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDAC3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DDAC3u);return;} hw.unresolvedReturn(0x0DDAC3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B18D00_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB18D00u: goto L_B18D00;
    case 0xB18D02u: goto L_B18D02;
    case 0xB18D04u: goto L_B18D04;
    case 0xB18D06u: goto L_B18D06;
    case 0xB18D08u: goto L_B18D08;
    case 0xB18D0Au: goto L_B18D0A;
    case 0xB18D0Du: goto L_B18D0D;
    case 0xB18D0Fu: goto L_B18D0F;
    case 0xB18D10u: goto L_B18D10;
    case 0xB18D12u: goto L_B18D12;
    case 0xB18D13u: goto L_B18D13;
    case 0xB18D16u: goto L_B18D16;
    case 0xB18D18u: goto L_B18D18;
    case 0xB18D1Au: goto L_B18D1A;
    case 0xB18D1Du: goto L_B18D1D;
    case 0xB18D1Fu: goto L_B18D1F;
    case 0xB18D22u: goto L_B18D22;
    case 0xB18D24u: goto L_B18D24;
    case 0xB18D27u: goto L_B18D27;
    case 0xB18D2Au: goto L_B18D2A;
    case 0xB18D2Du: goto L_B18D2D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B18D00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D00u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D00 BNE -> $B18D27
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18D27; }
    goto L_B18D02;
L_B18D02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D02u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D02u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D02 INC
    cpu.incMem(hw, cpu.address("dpx", 0xC2u), cpu.m8?8:16);
    goto L_B18D04;
L_B18D04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D04u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D04u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D04 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18D06;
L_B18D06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D06u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D06 AND
    cpu.logicAnd(0x3u);
    goto L_B18D08;
L_B18D08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D08u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D08 BNE -> $B18D27
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18D27; }
    goto L_B18D0A;
L_B18D0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Au, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D0A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18D0D;
L_B18D0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D0D AND
    cpu.logicAnd(0x1u);
    goto L_B18D0F;
L_B18D0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D0F TAY
    cpu.transfer("TAY");
    goto L_B18D10;
L_B18D10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D10 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18D12;
L_B18D12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D12u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D12 CLC
    cpu.setFlag('C', false);
    goto L_B18D13;
L_B18D13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u, 4u + ((((0x8CBAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8CBAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D13 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x8CBAu), cpu.m8?8:16));
    goto L_B18D16;
L_B18D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D16 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B18D18;
L_B18D18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D18 STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_B18D1A;
L_B18D1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au, 4u + ((((0x8CBCu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8CBCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D1A CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x8CBCu), cpu.m8?8:16));
    goto L_B18D1D;
L_B18D1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D1D BNE -> $B18D27
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18D27; }
    goto L_B18D1F;
L_B18D1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Fu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Fu, 7u, 3u, cpu.address("absx", 0x151Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D1F INC
    cpu.incMem(hw, cpu.address("absx", 0x151Cu), cpu.m8?8:16);
    goto L_B18D22;
L_B18D22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D22u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D22 LDA
    cpu.setA(0x30u, 8);
    goto L_B18D24;
L_B18D24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D24u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D24u, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D24 STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_B18D27;
L_B18D27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D27u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D27u, 6u, 3u, cpu.address("abs", 0x8FC1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D27 JSR -> $B18FC1 stack real
    { cpu.push16Value(hw,0x8D29u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D2Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8FC1u), 0xB18D27u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D2A;
L_B18D2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au, 6u, 3u, cpu.address("abs", 0x8CB7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D2A JSR -> $B18CB7 stack real
    { cpu.push16Value(hw,0x8D2Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D2Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8CB7u), 0xB18D2Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D2D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au, 6u, 3u, cpu.address("abs", 0x8CB7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D2A JSR -> $B18CB7 stack real
    { cpu.push16Value(hw,0x8D2Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D2Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8CB7u), 0xB18D2Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D2D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au, 6u, 3u, cpu.address("abs", 0x8CB7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D2A JSR -> $B18CB7 stack real
    { cpu.push16Value(hw,0x8D2Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D2Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8CB7u), 0xB18D2Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D2D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D2Au,0xB18D2Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18D2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D2Du,0xB18D2Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D2D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB18D2Du);return;} hw.unresolvedReturn(0xB18D2Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B18D0F_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB18D0Fu: goto L_B18D0F;
    case 0xB18D10u: goto L_B18D10;
    case 0xB18D12u: goto L_B18D12;
    case 0xB18D13u: goto L_B18D13;
    case 0xB18D16u: goto L_B18D16;
    case 0xB18D18u: goto L_B18D18;
    case 0xB18D1Au: goto L_B18D1A;
    case 0xB18D1Du: goto L_B18D1D;
    case 0xB18D1Fu: goto L_B18D1F;
    case 0xB18D22u: goto L_B18D22;
    case 0xB18D24u: goto L_B18D24;
    case 0xB18D27u: goto L_B18D27;
    case 0xB18D2Au: goto L_B18D2A;
    case 0xB18D2Du: goto L_B18D2D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B18D0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D0F TAY
    cpu.transfer("TAY");
    goto L_B18D10;
L_B18D10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D10 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18D12;
L_B18D12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D12u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D12 CLC
    cpu.setFlag('C', false);
    goto L_B18D13;
L_B18D13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u, 4u + ((((0x8CBAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8CBAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D13 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x8CBAu), cpu.m8?8:16));
    goto L_B18D16;
L_B18D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D16 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B18D18;
L_B18D18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D18 STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_B18D1A;
L_B18D1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au, 4u + ((((0x8CBCu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8CBCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D1A CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x8CBCu), cpu.m8?8:16));
    goto L_B18D1D;
L_B18D1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D1D BNE -> $B18D27
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18D27; }
    goto L_B18D1F;
L_B18D1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Fu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Fu, 7u, 3u, cpu.address("absx", 0x151Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D1F INC
    cpu.incMem(hw, cpu.address("absx", 0x151Cu), cpu.m8?8:16);
    goto L_B18D22;
L_B18D22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D22u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D22 LDA
    cpu.setA(0x30u, 8);
    goto L_B18D24;
L_B18D24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D24u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D24u, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D24 STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_B18D27;
L_B18D27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D27u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D27u, 6u, 3u, cpu.address("abs", 0x8FC1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D27 JSR -> $B18FC1 stack real
    { cpu.push16Value(hw,0x8D29u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D2Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8FC1u), 0xB18D27u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D2A;
L_B18D2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au, 6u, 3u, cpu.address("abs", 0x8CB7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D2A JSR -> $B18CB7 stack real
    { cpu.push16Value(hw,0x8D2Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D2Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8CB7u), 0xB18D2Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D2D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au, 6u, 3u, cpu.address("abs", 0x8CB7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D2A JSR -> $B18CB7 stack real
    { cpu.push16Value(hw,0x8D2Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D2Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8CB7u), 0xB18D2Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D2D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au, 6u, 3u, cpu.address("abs", 0x8CB7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D2A JSR -> $B18CB7 stack real
    { cpu.push16Value(hw,0x8D2Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D2Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8CB7u), 0xB18D2Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D2D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D2Au,0xB18D2Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18D2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D2Du,0xB18D2Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D2D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB18D2Du);return;} hw.unresolvedReturn(0xB18D2Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

