#include "generated.hpp"
void sub_00871E_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00871Eu: goto L_00871E;
    case 0x008720u: goto L_008720;
    case 0x008723u: goto L_008723;
    case 0x008726u: goto L_008726;
    case 0x008728u: goto L_008728;
    case 0x00872Au: goto L_00872A;
    case 0x00872Cu: goto L_00872C;
    case 0x00872Du: goto L_00872D;
    case 0x00872Fu: goto L_00872F;
    case 0x008730u: goto L_008730;
    case 0x008732u: goto L_008732;
    case 0x008734u: goto L_008734;
    case 0x008735u: goto L_008735;
    case 0x008737u: goto L_008737;
    case 0x008739u: goto L_008739;
    case 0x00873Au: goto L_00873A;
    case 0x00873Cu: goto L_00873C;
    case 0x00873Eu: goto L_00873E;
    case 0x008741u: goto L_008741;
    case 0x008743u: goto L_008743;
    case 0x008745u: goto L_008745;
    case 0x008746u: goto L_008746;
    case 0x008747u: goto L_008747;
    case 0x008748u: goto L_008748;
    case 0x00874Au: goto L_00874A;
    case 0x00874Cu: goto L_00874C;
    case 0x00874Eu: goto L_00874E;
    case 0x008751u: goto L_008751;
    case 0x008753u: goto L_008753;
    case 0x008755u: goto L_008755;
    case 0x008758u: goto L_008758;
    case 0x00875Au: goto L_00875A;
    case 0x00875Bu: goto L_00875B;
    case 0x00875Eu: goto L_00875E;
    case 0x00875Fu: goto L_00875F;
    case 0x008760u: goto L_008760;
    case 0x008761u: goto L_008761;
    case 0x008762u: goto L_008762;
    case 0x008763u: goto L_008763;
    case 0x008764u: goto L_008764;
    case 0x008766u: goto L_008766;
    case 0x008769u: goto L_008769;
    case 0x00876Cu: goto L_00876C;
    case 0x00876Eu: goto L_00876E;
    case 0x008770u: goto L_008770;
    case 0x008772u: goto L_008772;
    case 0x008774u: goto L_008774;
    case 0x008777u: goto L_008777;
    case 0x008779u: goto L_008779;
    case 0x00877Cu: goto L_00877C;
    case 0x00877Eu: goto L_00877E;
    case 0x008781u: goto L_008781;
    case 0x008783u: goto L_008783;
    case 0x008785u: goto L_008785;
    case 0x008788u: goto L_008788;
    case 0x008789u: goto L_008789;
    case 0x00878Bu: goto L_00878B;
    case 0x00878Cu: goto L_00878C;
    case 0x00878Fu: goto L_00878F;
    case 0x008792u: goto L_008792;
    case 0x008795u: goto L_008795;
    case 0x008797u: goto L_008797;
    case 0x008798u: goto L_008798;
    case 0x008799u: goto L_008799;
    case 0x00879Bu: goto L_00879B;
    case 0x00879Cu: goto L_00879C;
    case 0x00879Eu: goto L_00879E;
    case 0x0087A0u: goto L_0087A0;
    case 0x0087A2u: goto L_0087A2;
    case 0x0087A5u: goto L_0087A5;
    case 0x0087A7u: goto L_0087A7;
    case 0x0087AAu: goto L_0087AA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00871E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00871E REP
    cpu.rep(0x10u);
    goto L_008720;
L_008720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8720u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8720u, 4u, 3u, cpu.address("abs", 0x4314u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008720 STA
    hw.write(cpu.address("abs", 0x4314u), cpu.a, cpu.m8?8:16);
    goto L_008723;
L_008723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8723u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8723u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008723 LDY
    cpu.setY(0x0u, 16);
    goto L_008726;
L_008726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $008726 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008728;
L_008728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008728 BPL -> $00872D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00872D; }
    goto L_00872A;
L_00872A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00872A SEP
    cpu.sep(0x30u);
    goto L_00872C;
L_00872C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00872C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00872Cu);return;} hw.unresolvedReturn(0x00872Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00872D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00872D STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00872F;
L_00872F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00872F INY
    cpu.inc('Y');
    goto L_008730;
L_008730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8730u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8730u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $008730 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008732;
L_008732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008732 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_008734;
L_008734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008734 INY
    cpu.inc('Y');
    goto L_008735;
L_008735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8735u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8735u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $008735 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008737;
L_008737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8737u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8737u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008737 STZ
    hw.write(cpu.address("dp", 0x7u), 0, cpu.m8?8:16);
    goto L_008739;
L_008739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8739u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8739u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008739 ASL
    cpu.aslA();
    goto L_00873A;
L_00873A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Au,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00873A ROL
    cpu.rolMem(hw, cpu.address("dp", 0x7u), cpu.m8?8:16);
    goto L_00873C;
L_00873C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00873C LDA
    cpu.setA(0x18u, 8);
    goto L_00873E;
L_00873E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Eu, 4u, 3u, cpu.address("abs", 0x4311u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00873E STA
    hw.write(cpu.address("abs", 0x4311u), cpu.a, cpu.m8?8:16);
    goto L_008741;
L_008741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8741u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8741u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $008741 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008743;
L_008743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8743u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8743u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008743 AND
    cpu.logicAnd(0x40u);
    goto L_008745;
L_008745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008745 LSR
    cpu.lsrA();
    goto L_008746;
L_008746:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8746u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8746u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8746u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008746 LSR
    cpu.lsrA();
    goto L_008747;
L_008747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8747u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8747u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008747 LSR
    cpu.lsrA();
    goto L_008748;
L_008748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8748u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8748u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008748 STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_00874A;
L_00874A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00874A STZ
    hw.write(cpu.address("dp", 0x6u), 0, cpu.m8?8:16);
    goto L_00874C;
L_00874C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Cu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00874C ORA
    cpu.logicOr(0x1u);
    goto L_00874E;
L_00874E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Eu, 4u, 3u, cpu.address("abs", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00874E STA
    hw.write(cpu.address("abs", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008751;
L_008751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8751u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8751u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008751 REP
    cpu.rep(0x20u);
    goto L_008753;
L_008753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8753u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8753u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8753u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008753 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008755;
L_008755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8755u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8755u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8755u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008755 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008758;
L_008758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $008758 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00875A;
L_00875A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Au,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00875A XBA
    cpu.xba();
    goto L_00875B;
L_00875B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00875B AND
    cpu.logicAnd(0x3FFFu);
    goto L_00875E;
L_00875E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00875E TAX
    cpu.transfer("TAX");
    goto L_00875F;
L_00875F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00875F INX
    cpu.inc('X');
    goto L_008760;
L_008760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8760u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8760u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8760u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008760 INY
    cpu.inc('Y');
    goto L_008761;
L_008761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8761u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8761u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008761 INY
    cpu.inc('Y');
    goto L_008762;
L_008762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8762u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8762u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008762 TYA
    cpu.transfer("TYA");
    goto L_008763;
L_008763:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8763u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8763u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8763u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008763 CLC
    cpu.setFlag('C', false);
    goto L_008764;
L_008764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8764u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8764u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008764 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_008766;
L_008766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u, 5u, 3u, cpu.address("abs", 0x4312u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008766 STA
    hw.write(cpu.address("abs", 0x4312u), cpu.a, cpu.m8?8:16);
    goto L_008769;
L_008769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8769u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8769u, 5u, 3u, cpu.address("abs", 0x4315u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008769 STX
    hw.write(cpu.address("abs", 0x4315u), cpu.x, cpu.x8?8:16);
    goto L_00876C;
L_00876C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00876C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00876E;
L_00876E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00876E BEQ -> $008795
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008795; }
    goto L_008770;
L_008770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8770u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8770u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008770 SEP
    cpu.sep(0x20u);
    goto L_008772;
L_008772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8772u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8772u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008772 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008774;
L_008774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008774 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_008777;
L_008777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8777u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008777 LDA
    cpu.setA(0x2u, 8);
    goto L_008779;
L_008779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8779u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8779u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8779u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008779 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_00877C;
L_00877C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00877C LDA
    cpu.setA(0x19u, 8);
    goto L_00877E;
L_00877E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu, 4u, 3u, cpu.address("abs", 0x4311u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00877E STA
    hw.write(cpu.address("abs", 0x4311u), cpu.a, cpu.m8?8:16);
    goto L_008781;
L_008781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8781u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8781u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008781 REP
    cpu.rep(0x21u);
    goto L_008783;
L_008783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008783 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008785;
L_008785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008785 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008788;
L_008788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008788 TYA
    cpu.transfer("TYA");
    goto L_008789;
L_008789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8789u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8789u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008789 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_00878B;
L_00878B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00878B INC
    cpu.inc('A');
    goto L_00878C;
L_00878C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu, 5u, 3u, cpu.address("abs", 0x4312u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00878C STA
    hw.write(cpu.address("abs", 0x4312u), cpu.a, cpu.m8?8:16);
    goto L_00878F;
L_00878F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Fu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Fu, 5u, 3u, cpu.address("abs", 0x4315u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00878F STX
    hw.write(cpu.address("abs", 0x4315u), cpu.x, cpu.x8?8:16);
    goto L_008792;
L_008792:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8792u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8792u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8792u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008792 LDX
    cpu.setX(0x2u, 16);
    goto L_008795;
L_008795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8795u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8795u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008795 STX
    hw.write(cpu.address("dp", 0x3u), cpu.x, cpu.x8?8:16);
    goto L_008797;
L_008797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008797 TYA
    cpu.transfer("TYA");
    goto L_008798;
L_008798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8798u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8798u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008798 CLC
    cpu.setFlag('C', false);
    goto L_008799;
L_008799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8799u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8799u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008799 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16));
    goto L_00879B;
L_00879B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00879B TAY
    cpu.transfer("TAY");
    goto L_00879C;
L_00879C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00879C SEP
    cpu.sep(0x20u);
    goto L_00879E;
L_00879E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00879E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0087A0;
L_0087A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A0u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087A0 ORA
    cpu.logicOr(0x80u);
    goto L_0087A2;
L_0087A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087A2 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_0087A5;
L_0087A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087A5 LDA
    cpu.setA(0x2u, 8);
    goto L_0087A7;
L_0087A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087A7 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_0087AA;
L_0087AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AAu, 3u, 3u, cpu.address("abs", 0x8726u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0087AA JMP -> $008726
    goto L_008726;
}

void sub_008EEA_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008EEAu: goto L_008EEA;
    case 0x008EEBu: goto L_008EEB;
    case 0x008EEDu: goto L_008EED;
    case 0x008EEFu: goto L_008EEF;
    case 0x008EF2u: goto L_008EF2;
    case 0x008EF4u: goto L_008EF4;
    case 0x008EF7u: goto L_008EF7;
    case 0x008EF9u: goto L_008EF9;
    case 0x008EFBu: goto L_008EFB;
    case 0x008EFEu: goto L_008EFE;
    case 0x008F00u: goto L_008F00;
    case 0x008F03u: goto L_008F03;
    case 0x008F05u: goto L_008F05;
    case 0x008F07u: goto L_008F07;
    case 0x008F09u: goto L_008F09;
    case 0x008F0Cu: goto L_008F0C;
    case 0x008F0Eu: goto L_008F0E;
    case 0x008F11u: goto L_008F11;
    case 0x008F13u: goto L_008F13;
    case 0x008F15u: goto L_008F15;
    case 0x008F18u: goto L_008F18;
    case 0x008F19u: goto L_008F19;
    case 0x008F1Bu: goto L_008F1B;
    case 0x008F1Du: goto L_008F1D;
    case 0x008F20u: goto L_008F20;
    case 0x008F22u: goto L_008F22;
    case 0x008F25u: goto L_008F25;
    case 0x008F28u: goto L_008F28;
    case 0x008F2Bu: goto L_008F2B;
    case 0x008F2Du: goto L_008F2D;
    case 0x008F2Fu: goto L_008F2F;
    case 0x008F32u: goto L_008F32;
    case 0x008F35u: goto L_008F35;
    case 0x008F36u: goto L_008F36;
    case 0x008F38u: goto L_008F38;
    case 0x008F3Bu: goto L_008F3B;
    case 0x008F3Eu: goto L_008F3E;
    case 0x008F40u: goto L_008F40;
    case 0x008F42u: goto L_008F42;
    case 0x008F44u: goto L_008F44;
    case 0x008F46u: goto L_008F46;
    case 0x008F49u: goto L_008F49;
    case 0x008F4Cu: goto L_008F4C;
    case 0x008F4Du: goto L_008F4D;
    case 0x008F50u: goto L_008F50;
    case 0x008F51u: goto L_008F51;
    case 0x008F53u: goto L_008F53;
    case 0x008F55u: goto L_008F55;
    case 0x008F58u: goto L_008F58;
    case 0x008F5Bu: goto L_008F5B;
    case 0x008F5Eu: goto L_008F5E;
    case 0x008F61u: goto L_008F61;
    case 0x008F63u: goto L_008F63;
    case 0x008F65u: goto L_008F65;
    case 0x008F67u: goto L_008F67;
    case 0x008F6Au: goto L_008F6A;
    case 0x008F6Du: goto L_008F6D;
    case 0x008F6Eu: goto L_008F6E;
    case 0x008F70u: goto L_008F70;
    case 0x008F73u: goto L_008F73;
    case 0x008F76u: goto L_008F76;
    case 0x008F79u: goto L_008F79;
    case 0x008F7Au: goto L_008F7A;
    case 0x008F7Cu: goto L_008F7C;
    case 0x008F7Eu: goto L_008F7E;
    case 0x008F81u: goto L_008F81;
    case 0x008F84u: goto L_008F84;
    case 0x008F86u: goto L_008F86;
    case 0x008F89u: goto L_008F89;
    case 0x008F8Bu: goto L_008F8B;
    case 0x008F8Du: goto L_008F8D;
    case 0x008F8Fu: goto L_008F8F;
    case 0x008F92u: goto L_008F92;
    case 0x008F94u: goto L_008F94;
    case 0x008F96u: goto L_008F96;
    case 0x008F98u: goto L_008F98;
    case 0x008F9Bu: goto L_008F9B;
    case 0x008F9Du: goto L_008F9D;
    case 0x008FA0u: goto L_008FA0;
    case 0x008FA2u: goto L_008FA2;
    case 0x008FA4u: goto L_008FA4;
    case 0x008FA7u: goto L_008FA7;
    case 0x008FAAu: goto L_008FAA;
    case 0x008FABu: goto L_008FAB;
    case 0x008FADu: goto L_008FAD;
    case 0x008FAFu: goto L_008FAF;
    case 0x008FB2u: goto L_008FB2;
    case 0x008FB3u: goto L_008FB3;
    case 0x008FB4u: goto L_008FB4;
    case 0x008FB7u: goto L_008FB7;
    case 0x008FBAu: goto L_008FBA;
    case 0x008FBDu: goto L_008FBD;
    case 0x008FC0u: goto L_008FC0;
    case 0x008FC1u: goto L_008FC1;
    case 0x008FC3u: goto L_008FC3;
    case 0x008FC5u: goto L_008FC5;
    case 0x008FC8u: goto L_008FC8;
    case 0x008FCBu: goto L_008FCB;
    case 0x008FCDu: goto L_008FCD;
    case 0x008FCFu: goto L_008FCF;
    case 0x008FD2u: goto L_008FD2;
    case 0x008FD5u: goto L_008FD5;
    case 0x008FD6u: goto L_008FD6;
    case 0x008FD8u: goto L_008FD8;
    case 0x008FDBu: goto L_008FDB;
    case 0x008FDDu: goto L_008FDD;
    case 0x008FDFu: goto L_008FDF;
    case 0x008FE1u: goto L_008FE1;
    case 0x008FE2u: goto L_008FE2;
    case 0x008FE4u: goto L_008FE4;
    case 0x008FE6u: goto L_008FE6;
    case 0x008FE8u: goto L_008FE8;
    case 0x008FEAu: goto L_008FEA;
    case 0x008FECu: goto L_008FEC;
    case 0x008FEEu: goto L_008FEE;
    case 0x008FEFu: goto L_008FEF;
    case 0x008FF2u: goto L_008FF2;
    case 0x008FF4u: goto L_008FF4;
    case 0x008FF5u: goto L_008FF5;
    case 0x008FF7u: goto L_008FF7;
    case 0x008FF9u: goto L_008FF9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008EEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EEA INX
    cpu.inc('X');
    goto L_008EEB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EEA INX
    cpu.inc('X');
    goto L_008EEB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EEAu,0x008EEAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_008EEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEBu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EEB CPX
    cpu.compareX(0x6u);
    goto L_008EED;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEBu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EEB CPX
    cpu.compareX(0x6u);
    goto L_008EED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EEBu,0x008EEBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_008EED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EED BNE -> $008EE0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x008EE0u,0x008EEDu); return; }
    goto L_008EEF;
L_008EEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEFu, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EEF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDB3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008EF2;
L_008EF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EF2 BEQ -> $008F1D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F1D; }
    goto L_008EF4;
L_008EF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF4u, 4u, 3u, cpu.address("abs", 0x0F39u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EF4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF39u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008EF7;
L_008EF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EF7 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_008EF9;
L_008EF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF9u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EF9 STZ
    hw.write(cpu.address("dp", 0x1u), 0, cpu.m8?8:16);
    goto L_008EFB;
L_008EFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFBu, 4u, 3u, cpu.address("abs", 0x0F38u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EFB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008EFE;
L_008EFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EFE STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_008F00;
L_008F00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F00u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F00u, 4u, 3u, cpu.address("abs", 0x0F37u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F00 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF37u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F03;
L_008F03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F03u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F03u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F03 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_008F05;
L_008F05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F05u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F05u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F05 LDX
    cpu.setX(0x14u, 8);
    goto L_008F07;
L_008F07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F07 LDY
    cpu.setY(0x0u, 8);
    goto L_008F09;
L_008F09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F09u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F09u, 6u, 3u, cpu.address("abs", 0x9012u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008F09 JSR -> $009012 stack real
    { cpu.push16Value(hw,0x8F0Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F0Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9012u), 0x008F09u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008F0C;
L_008F0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F0Cu,0x008F0Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F0C LDX
    cpu.setX(0x0u, 8);
    goto L_008F0E;
L_008F0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Eu, 4u + ((((0x0F29u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F0E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF29u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F11;
L_008F11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F11u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F11 BNE -> $008F1D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F1D; }
    goto L_008F13;
L_008F13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F13u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F13 LDA
    cpu.setA(0xFCu, 8);
    goto L_008F15;
L_008F15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F15u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F15u, 5u, 3u, cpu.address("absx", 0x0F29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F15 STA
    hw.write(cpu.address("absx", 0xF29u), cpu.a, cpu.m8?8:16);
    goto L_008F18;
L_008F18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F18u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F18 INX
    cpu.inc('X');
    goto L_008F19;
L_008F19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F19u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F19 CPX
    cpu.compareX(0x6u);
    goto L_008F1B;
L_008F1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F1B BNE -> $008F0E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F0E; }
    goto L_008F1D;
L_008F1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Du, 4u, 3u, cpu.address("abs", 0x13CCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13CCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F20;
L_008F20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F20 BEQ -> $008F3B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F3B; }
    goto L_008F22;
L_008F22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F22u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F22u, 6u, 3u, cpu.address("abs", 0x13CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F22 DEC
    cpu.decMem(hw, cpu.address("abs", 0x13CCu), cpu.m8?8:16);
    goto L_008F25;
L_008F25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F25u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F25u, 6u, 3u, cpu.address("abs", 0x0DBFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F25 INC
    cpu.incMem(hw, cpu.address("abs", 0xDBFu), cpu.m8?8:16);
    goto L_008F28;
L_008F28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F28u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F28u, 4u, 3u, cpu.address("abs", 0x0DBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F28 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F2B;
L_008F2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F2B CMP
    cpu.compareA(0x64u);
    goto L_008F2D;
L_008F2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F2D BCC -> $008F3B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_008F3B; }
    goto L_008F2F;
L_008F2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Fu, 6u, 3u, cpu.address("abs", 0x18E4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F2F INC
    cpu.incMem(hw, cpu.address("abs", 0x18E4u), cpu.m8?8:16);
    goto L_008F32;
L_008F32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F32u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F32u, 4u, 3u, cpu.address("abs", 0x0DBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F32 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F35;
L_008F35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F35u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F35 SEC
    cpu.setFlag('C', true);
    goto L_008F36;
L_008F36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F36u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F36 SBC
    cpu.sbc(0x64u);
    goto L_008F38;
L_008F38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F38u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F38u, 4u, 3u, cpu.address("abs", 0x0DBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F38 STA
    hw.write(cpu.address("abs", 0xDBFu), cpu.a, cpu.m8?8:16);
    goto L_008F3B;
L_008F3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Bu, 4u, 3u, cpu.address("abs", 0x0DBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F3B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F3E;
L_008F3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F3E BMI -> $008F49
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_008F49; }
    goto L_008F40;
L_008F40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F40u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F40 CMP
    cpu.compareA(0x62u);
    goto L_008F42;
L_008F42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F42u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F42 BCC -> $008F49
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_008F49; }
    goto L_008F44;
L_008F44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F44u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F44 LDA
    cpu.setA(0x62u, 8);
    goto L_008F46;
L_008F46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F46u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F46u, 4u, 3u, cpu.address("abs", 0x0DBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F46 STA
    hw.write(cpu.address("abs", 0xDBEu), cpu.a, cpu.m8?8:16);
    goto L_008F49;
L_008F49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F49u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F49u, 4u, 3u, cpu.address("abs", 0x0DBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F49 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F4C;
L_008F4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Cu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F4C INC
    cpu.inc('A');
    goto L_008F4D;
L_008F4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Du, 6u, 3u, cpu.address("abs", 0x9045u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008F4D JSR -> $009045 stack real
    { cpu.push16Value(hw,0x8F4Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F50u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9045u), 0x008F4Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008F50;
L_008F50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F50u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F50u,0x008F50u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F50u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F50 TXY
    cpu.transfer("TXY");
    goto L_008F51;
L_008F51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F51u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F51u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F51 BNE -> $008F55
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F55; }
    goto L_008F53;
L_008F53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F53u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F53 LDX
    cpu.setX(0xFCu, 8);
    goto L_008F55;
L_008F55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F55u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F55u, 4u, 3u, cpu.address("abs", 0x0F16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F55 STX
    hw.write(cpu.address("abs", 0xF16u), cpu.x, cpu.x8?8:16);
    goto L_008F58;
L_008F58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F58u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F58u, 4u, 3u, cpu.address("abs", 0x0F17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F58 STA
    hw.write(cpu.address("abs", 0xF17u), cpu.a, cpu.m8?8:16);
    goto L_008F5B;
L_008F5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Bu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Bu, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F5B LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDB3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008F5E;
L_008F5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Eu, 4u + ((((0x0F48u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F5E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F61;
L_008F61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F61u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F61 CMP
    cpu.compareA(0x64u);
    goto L_008F63;
L_008F63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F63u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F63 BCC -> $008F73
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_008F73; }
    goto L_008F65;
L_008F65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F65u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F65u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F65 LDA
    cpu.setA(0xFFu, 8);
    goto L_008F67;
L_008F67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F67u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F67u, 4u, 3u, cpu.address("abs", 0x1425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F67 STA
    hw.write(cpu.address("abs", 0x1425u), cpu.a, cpu.m8?8:16);
    goto L_008F6A;
L_008F6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Au, 4u + ((((0x0F48u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F6A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F6D;
L_008F6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F6D SEC
    cpu.setFlag('C', true);
    goto L_008F6E;
L_008F6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F6E SBC
    cpu.sbc(0x64u);
    goto L_008F70;
L_008F70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F70u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F70u, 5u, 3u, cpu.address("absx", 0x0F48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F70 STA
    hw.write(cpu.address("absx", 0xF48u), cpu.a, cpu.m8?8:16);
    goto L_008F73;
L_008F73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F73u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F73u, 4u, 3u, cpu.address("abs", 0x0DBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F73 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F76;
L_008F76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F76u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F76u, 6u, 3u, cpu.address("abs", 0x9045u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008F76 JSR -> $009045 stack real
    { cpu.push16Value(hw,0x8F78u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F79u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9045u), 0x008F76u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008F79;
L_008F79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F79u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F79u,0x008F79u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F79u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F79u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F79 TXY
    cpu.transfer("TXY");
    goto L_008F7A;
L_008F7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F7A BNE -> $008F7E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F7E; }
    goto L_008F7C;
L_008F7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F7C LDX
    cpu.setX(0xFCu, 8);
    goto L_008F7E;
L_008F7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Eu, 4u, 3u, cpu.address("abs", 0x0F14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F7E STA
    hw.write(cpu.address("abs", 0xF14u), cpu.a, cpu.m8?8:16);
    goto L_008F81;
L_008F81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F81u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F81u, 4u, 3u, cpu.address("abs", 0x0F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F81 STX
    hw.write(cpu.address("abs", 0xF13u), cpu.x, cpu.x8?8:16);
    goto L_008F84;
L_008F84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F84u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F84u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F84 SEP
    cpu.sep(0x20u);
    goto L_008F86;
L_008F86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F86u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F86u, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F86 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDB3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008F89;
L_008F89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F89u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F89u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F89 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_008F8B;
L_008F8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F8B STZ
    hw.write(cpu.address("dp", 0x1u), 0, cpu.m8?8:16);
    goto L_008F8D;
L_008F8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F8D STZ
    hw.write(cpu.address("dp", 0x3u), 0, cpu.m8?8:16);
    goto L_008F8F;
L_008F8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Fu, 4u + ((((0x0F48u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F8F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F92;
L_008F92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F92u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F92u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F92 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_008F94;
L_008F94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F94u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F94 LDX
    cpu.setX(0x9u, 8);
    goto L_008F96;
L_008F96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F96u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F96 LDY
    cpu.setY(0x10u, 8);
    goto L_008F98;
L_008F98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F98u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F98u, 6u, 3u, cpu.address("abs", 0x9051u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008F98 JSR -> $009051 stack real
    { cpu.push16Value(hw,0x8F9Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F9Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9051u), 0x008F98u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008F9B;
L_008F9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F9Bu,0x008F9Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F9B LDX
    cpu.setX(0x0u, 8);
    goto L_008F9D;
L_008F9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Du, 4u + ((((0x0F1Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F1Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F9D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF1Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008FA0;
L_008FA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FA0 BNE -> $008FAF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008FAF; }
    goto L_008FA2;
L_008FA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FA2 LDA
    cpu.setA(0xFCu, 8);
    goto L_008FA4;
L_008FA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA4u, 5u, 3u, cpu.address("absx", 0x0F1Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FA4 STA
    hw.write(cpu.address("absx", 0xF1Eu), cpu.a, cpu.m8?8:16);
    goto L_008FA7;
L_008FA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA7u, 5u, 3u, cpu.address("absx", 0x0F03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FA7 STA
    hw.write(cpu.address("absx", 0xF03u), cpu.a, cpu.m8?8:16);
    goto L_008FAA;
L_008FAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FAA INX
    cpu.inc('X');
    goto L_008FAB;
L_008FAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FABu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FAB CPX
    cpu.compareX(0x1u);
    goto L_008FAD;
L_008FAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FADu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FAD BNE -> $008F9D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F9D; }
    goto L_008FAF;
L_008FAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAFu, 4u + ((((0x0F1Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F1Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FAF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF1Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008FB2;
L_008FB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FB2 ASL
    cpu.aslA();
    goto L_008FB3;
L_008FB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FB3 TAY
    cpu.transfer("TAY");
    goto L_008FB4;
L_008FB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB4u, 4u + ((((0x8E06u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8E06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FB4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8E06u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008FB7;
L_008FB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB7u, 5u, 3u, cpu.address("absx", 0x0F03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FB7 STA
    hw.write(cpu.address("absx", 0xF03u), cpu.a, cpu.m8?8:16);
    goto L_008FBA;
L_008FBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBAu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBAu, 4u + ((((0x8E07u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8E07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FBA LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8E07u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008FBD;
L_008FBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBDu, 5u, 3u, cpu.address("absx", 0x0F1Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FBD STA
    hw.write(cpu.address("absx", 0xF1Eu), cpu.a, cpu.m8?8:16);
    goto L_008FC0;
L_008FC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FC0 INX
    cpu.inc('X');
    goto L_008FC1;
L_008FC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FC1 CPX
    cpu.compareX(0x2u);
    goto L_008FC3;
L_008FC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FC3 BNE -> $008FAF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008FAF; }
    goto L_008FC5;
L_008FC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC5u, 6u, 3u, cpu.address("abs", 0x9079u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008FC5 JSR -> $009079 stack real
    { cpu.push16Value(hw,0x8FC7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8FC8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9079u), 0x008FC5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008FC8;
L_008FC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FC8u,0x008FC8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC8u, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FC8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDB3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008FCB;
L_008FCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FCB BEQ -> $008FD8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008FD8; }
    goto L_008FCD;
L_008FCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FCD LDX
    cpu.setX(0x4u, 8);
    goto L_008FCF;
L_008FCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCFu, 4u + ((((0x8DF5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8DF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FCF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8DF5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008FD2;
L_008FD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD2u, 5u, 3u, cpu.address("absx", 0x0EF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FD2 STA
    hw.write(cpu.address("absx", 0xEF9u), cpu.a, cpu.m8?8:16);
    goto L_008FD5;
L_008FD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD5u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FD5 DEX
    cpu.decReg('X');
    goto L_008FD6;
L_008FD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FD6 BPL -> $008FCF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008FCF; }
    goto L_008FD8;
L_008FD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD8u, 4u, 3u, cpu.address("abs", 0x1422u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FD8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1422u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008FDB;
L_008FDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FDB CMP
    cpu.compareA(0x5u);
    goto L_008FDD;
L_008FDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FDD BCC -> $008FE1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_008FE1; }
    goto L_008FDF;
L_008FDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FDF LDA
    cpu.setA(0x0u, 8);
    goto L_008FE1;
L_008FE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE1u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FE1 DEC
    cpu.decReg('A');
    goto L_008FE2;
L_008FE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FE2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_008FE4;
L_008FE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FE4 LDX
    cpu.setX(0x0u, 8);
    goto L_008FE6;
L_008FE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FE6 LDY
    cpu.setY(0xFCu, 8);
    goto L_008FE8;
L_008FE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FE8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008FEA;
L_008FEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FEA BMI -> $008FEE
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_008FEE; }
    goto L_008FEC;
L_008FEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FECu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FEC LDY
    cpu.setY(0x2Eu, 8);
    goto L_008FEE;
L_008FEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEEu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FEE TYA
    cpu.transfer("TYA");
    goto L_008FEF;
L_008FEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEFu, 5u, 3u, cpu.address("absx", 0x0EFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FEF STA
    hw.write(cpu.address("absx", 0xEFFu), cpu.a, cpu.m8?8:16);
    goto L_008FF2;
L_008FF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF2u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FF2 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_008FF4;
L_008FF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FF4 INX
    cpu.inc('X');
    goto L_008FF5;
L_008FF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF5u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FF5 CPX
    cpu.compareX(0x4u);
    goto L_008FF7;
L_008FF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FF7 BNE -> $008FE6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008FE6; }
    goto L_008FF9;
L_008FF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008FF9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008FF9u);return;} hw.unresolvedReturn(0x008FF9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_008EEA_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008EEAu: goto L_008EEA;
    case 0x008EEBu: goto L_008EEB;
    case 0x008EEDu: goto L_008EED;
    case 0x008EEFu: goto L_008EEF;
    case 0x008EF2u: goto L_008EF2;
    case 0x008EF4u: goto L_008EF4;
    case 0x008EF7u: goto L_008EF7;
    case 0x008EF9u: goto L_008EF9;
    case 0x008EFBu: goto L_008EFB;
    case 0x008EFEu: goto L_008EFE;
    case 0x008F00u: goto L_008F00;
    case 0x008F03u: goto L_008F03;
    case 0x008F05u: goto L_008F05;
    case 0x008F07u: goto L_008F07;
    case 0x008F09u: goto L_008F09;
    case 0x008F0Cu: goto L_008F0C;
    case 0x008F0Eu: goto L_008F0E;
    case 0x008F11u: goto L_008F11;
    case 0x008F13u: goto L_008F13;
    case 0x008F15u: goto L_008F15;
    case 0x008F18u: goto L_008F18;
    case 0x008F19u: goto L_008F19;
    case 0x008F1Bu: goto L_008F1B;
    case 0x008F1Du: goto L_008F1D;
    case 0x008F20u: goto L_008F20;
    case 0x008F22u: goto L_008F22;
    case 0x008F25u: goto L_008F25;
    case 0x008F28u: goto L_008F28;
    case 0x008F2Bu: goto L_008F2B;
    case 0x008F2Du: goto L_008F2D;
    case 0x008F2Fu: goto L_008F2F;
    case 0x008F32u: goto L_008F32;
    case 0x008F35u: goto L_008F35;
    case 0x008F36u: goto L_008F36;
    case 0x008F38u: goto L_008F38;
    case 0x008F3Bu: goto L_008F3B;
    case 0x008F3Eu: goto L_008F3E;
    case 0x008F40u: goto L_008F40;
    case 0x008F42u: goto L_008F42;
    case 0x008F44u: goto L_008F44;
    case 0x008F46u: goto L_008F46;
    case 0x008F49u: goto L_008F49;
    case 0x008F4Cu: goto L_008F4C;
    case 0x008F4Du: goto L_008F4D;
    case 0x008F50u: goto L_008F50;
    case 0x008F51u: goto L_008F51;
    case 0x008F53u: goto L_008F53;
    case 0x008F55u: goto L_008F55;
    case 0x008F58u: goto L_008F58;
    case 0x008F5Bu: goto L_008F5B;
    case 0x008F5Eu: goto L_008F5E;
    case 0x008F61u: goto L_008F61;
    case 0x008F63u: goto L_008F63;
    case 0x008F65u: goto L_008F65;
    case 0x008F67u: goto L_008F67;
    case 0x008F6Au: goto L_008F6A;
    case 0x008F6Du: goto L_008F6D;
    case 0x008F6Eu: goto L_008F6E;
    case 0x008F70u: goto L_008F70;
    case 0x008F73u: goto L_008F73;
    case 0x008F76u: goto L_008F76;
    case 0x008F79u: goto L_008F79;
    case 0x008F7Au: goto L_008F7A;
    case 0x008F7Cu: goto L_008F7C;
    case 0x008F7Eu: goto L_008F7E;
    case 0x008F81u: goto L_008F81;
    case 0x008F84u: goto L_008F84;
    case 0x008F86u: goto L_008F86;
    case 0x008F89u: goto L_008F89;
    case 0x008F8Bu: goto L_008F8B;
    case 0x008F8Du: goto L_008F8D;
    case 0x008F8Fu: goto L_008F8F;
    case 0x008F92u: goto L_008F92;
    case 0x008F94u: goto L_008F94;
    case 0x008F96u: goto L_008F96;
    case 0x008F98u: goto L_008F98;
    case 0x008F9Bu: goto L_008F9B;
    case 0x008F9Du: goto L_008F9D;
    case 0x008FA0u: goto L_008FA0;
    case 0x008FA2u: goto L_008FA2;
    case 0x008FA4u: goto L_008FA4;
    case 0x008FA7u: goto L_008FA7;
    case 0x008FAAu: goto L_008FAA;
    case 0x008FABu: goto L_008FAB;
    case 0x008FADu: goto L_008FAD;
    case 0x008FAFu: goto L_008FAF;
    case 0x008FB2u: goto L_008FB2;
    case 0x008FB3u: goto L_008FB3;
    case 0x008FB4u: goto L_008FB4;
    case 0x008FB7u: goto L_008FB7;
    case 0x008FBAu: goto L_008FBA;
    case 0x008FBDu: goto L_008FBD;
    case 0x008FC0u: goto L_008FC0;
    case 0x008FC1u: goto L_008FC1;
    case 0x008FC3u: goto L_008FC3;
    case 0x008FC5u: goto L_008FC5;
    case 0x008FC8u: goto L_008FC8;
    case 0x008FCBu: goto L_008FCB;
    case 0x008FCDu: goto L_008FCD;
    case 0x008FCFu: goto L_008FCF;
    case 0x008FD2u: goto L_008FD2;
    case 0x008FD5u: goto L_008FD5;
    case 0x008FD6u: goto L_008FD6;
    case 0x008FD8u: goto L_008FD8;
    case 0x008FDBu: goto L_008FDB;
    case 0x008FDDu: goto L_008FDD;
    case 0x008FDFu: goto L_008FDF;
    case 0x008FE1u: goto L_008FE1;
    case 0x008FE2u: goto L_008FE2;
    case 0x008FE4u: goto L_008FE4;
    case 0x008FE6u: goto L_008FE6;
    case 0x008FE8u: goto L_008FE8;
    case 0x008FEAu: goto L_008FEA;
    case 0x008FECu: goto L_008FEC;
    case 0x008FEEu: goto L_008FEE;
    case 0x008FEFu: goto L_008FEF;
    case 0x008FF2u: goto L_008FF2;
    case 0x008FF4u: goto L_008FF4;
    case 0x008FF5u: goto L_008FF5;
    case 0x008FF7u: goto L_008FF7;
    case 0x008FF9u: goto L_008FF9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008EEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EEA INX
    cpu.inc('X');
    goto L_008EEB;
L_008EEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEBu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EEB CPX
    cpu.compareX(0x6u);
    goto L_008EED;
L_008EED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EED BNE -> $008EE0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x008EE0u,0x008EEDu); return; }
    goto L_008EEF;
L_008EEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEFu, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EEF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDB3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008EF2;
L_008EF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EF2 BEQ -> $008F1D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F1D; }
    goto L_008EF4;
L_008EF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF4u, 4u, 3u, cpu.address("abs", 0x0F39u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EF4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF39u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008EF7;
L_008EF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EF7 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_008EF9;
L_008EF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF9u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EF9 STZ
    hw.write(cpu.address("dp", 0x1u), 0, cpu.m8?8:16);
    goto L_008EFB;
L_008EFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFBu, 4u, 3u, cpu.address("abs", 0x0F38u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EFB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008EFE;
L_008EFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EFE STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_008F00;
L_008F00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F00u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F00u, 4u, 3u, cpu.address("abs", 0x0F37u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F00 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF37u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F03;
L_008F03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F03u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F03u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F03 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_008F05;
L_008F05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F05u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F05u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F05 LDX
    cpu.setX(0x14u, 8);
    goto L_008F07;
L_008F07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F07 LDY
    cpu.setY(0x0u, 8);
    goto L_008F09;
L_008F09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F09u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F09u, 6u, 3u, cpu.address("abs", 0x9012u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008F09 JSR -> $009012 stack real
    { cpu.push16Value(hw,0x8F0Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F0Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9012u), 0x008F09u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008F0C;
L_008F0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F0Cu,0x008F0Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F0C LDX
    cpu.setX(0x0u, 8);
    goto L_008F0E;
L_008F0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Eu, 4u + ((((0x0F29u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F0E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF29u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F11;
L_008F11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F11u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F11 BNE -> $008F1D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F1D; }
    goto L_008F13;
L_008F13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F13u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F13 LDA
    cpu.setA(0xFCu, 8);
    goto L_008F15;
L_008F15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F15u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F15u, 5u, 3u, cpu.address("absx", 0x0F29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F15 STA
    hw.write(cpu.address("absx", 0xF29u), cpu.a, cpu.m8?8:16);
    goto L_008F18;
L_008F18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F18u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F18 INX
    cpu.inc('X');
    goto L_008F19;
L_008F19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F19u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F19 CPX
    cpu.compareX(0x6u);
    goto L_008F1B;
L_008F1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F1B BNE -> $008F0E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F0E; }
    goto L_008F1D;
L_008F1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Du, 4u, 3u, cpu.address("abs", 0x13CCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13CCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F20;
L_008F20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F20 BEQ -> $008F3B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F3B; }
    goto L_008F22;
L_008F22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F22u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F22u, 6u, 3u, cpu.address("abs", 0x13CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F22 DEC
    cpu.decMem(hw, cpu.address("abs", 0x13CCu), cpu.m8?8:16);
    goto L_008F25;
L_008F25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F25u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F25u, 6u, 3u, cpu.address("abs", 0x0DBFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F25 INC
    cpu.incMem(hw, cpu.address("abs", 0xDBFu), cpu.m8?8:16);
    goto L_008F28;
L_008F28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F28u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F28u, 4u, 3u, cpu.address("abs", 0x0DBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F28 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F2B;
L_008F2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F2B CMP
    cpu.compareA(0x64u);
    goto L_008F2D;
L_008F2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F2D BCC -> $008F3B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_008F3B; }
    goto L_008F2F;
L_008F2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Fu, 6u, 3u, cpu.address("abs", 0x18E4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F2F INC
    cpu.incMem(hw, cpu.address("abs", 0x18E4u), cpu.m8?8:16);
    goto L_008F32;
L_008F32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F32u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F32u, 4u, 3u, cpu.address("abs", 0x0DBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F32 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F35;
L_008F35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F35u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F35 SEC
    cpu.setFlag('C', true);
    goto L_008F36;
L_008F36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F36u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F36 SBC
    cpu.sbc(0x64u);
    goto L_008F38;
L_008F38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F38u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F38u, 4u, 3u, cpu.address("abs", 0x0DBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F38 STA
    hw.write(cpu.address("abs", 0xDBFu), cpu.a, cpu.m8?8:16);
    goto L_008F3B;
L_008F3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Bu, 4u, 3u, cpu.address("abs", 0x0DBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F3B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F3E;
L_008F3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F3E BMI -> $008F49
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_008F49; }
    goto L_008F40;
L_008F40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F40u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F40 CMP
    cpu.compareA(0x62u);
    goto L_008F42;
L_008F42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F42u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F42 BCC -> $008F49
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_008F49; }
    goto L_008F44;
L_008F44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F44u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F44 LDA
    cpu.setA(0x62u, 8);
    goto L_008F46;
L_008F46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F46u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F46u, 4u, 3u, cpu.address("abs", 0x0DBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F46 STA
    hw.write(cpu.address("abs", 0xDBEu), cpu.a, cpu.m8?8:16);
    goto L_008F49;
L_008F49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F49u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F49u, 4u, 3u, cpu.address("abs", 0x0DBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F49 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F4C;
L_008F4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Cu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F4C INC
    cpu.inc('A');
    goto L_008F4D;
L_008F4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Du, 6u, 3u, cpu.address("abs", 0x9045u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008F4D JSR -> $009045 stack real
    { cpu.push16Value(hw,0x8F4Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F50u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9045u), 0x008F4Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008F50;
L_008F50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F50u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F50u,0x008F50u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F50u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F50 TXY
    cpu.transfer("TXY");
    goto L_008F51;
L_008F51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F51u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F51u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F51 BNE -> $008F55
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F55; }
    goto L_008F53;
L_008F53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F53u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F53 LDX
    cpu.setX(0xFCu, 8);
    goto L_008F55;
L_008F55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F55u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F55u, 4u, 3u, cpu.address("abs", 0x0F16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F55 STX
    hw.write(cpu.address("abs", 0xF16u), cpu.x, cpu.x8?8:16);
    goto L_008F58;
L_008F58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F58u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F58u, 4u, 3u, cpu.address("abs", 0x0F17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F58 STA
    hw.write(cpu.address("abs", 0xF17u), cpu.a, cpu.m8?8:16);
    goto L_008F5B;
L_008F5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Bu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Bu, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F5B LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDB3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008F5E;
L_008F5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Eu, 4u + ((((0x0F48u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F5E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F61;
L_008F61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F61u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F61 CMP
    cpu.compareA(0x64u);
    goto L_008F63;
L_008F63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F63u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F63 BCC -> $008F73
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_008F73; }
    goto L_008F65;
L_008F65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F65u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F65u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F65 LDA
    cpu.setA(0xFFu, 8);
    goto L_008F67;
L_008F67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F67u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F67u, 4u, 3u, cpu.address("abs", 0x1425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F67 STA
    hw.write(cpu.address("abs", 0x1425u), cpu.a, cpu.m8?8:16);
    goto L_008F6A;
L_008F6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Au, 4u + ((((0x0F48u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F6A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F6D;
L_008F6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F6D SEC
    cpu.setFlag('C', true);
    goto L_008F6E;
L_008F6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F6E SBC
    cpu.sbc(0x64u);
    goto L_008F70;
L_008F70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F70u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F70u, 5u, 3u, cpu.address("absx", 0x0F48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F70 STA
    hw.write(cpu.address("absx", 0xF48u), cpu.a, cpu.m8?8:16);
    goto L_008F73;
L_008F73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F73u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F73u, 4u, 3u, cpu.address("abs", 0x0DBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F73 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F76;
L_008F76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F76u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F76u, 6u, 3u, cpu.address("abs", 0x9045u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008F76 JSR -> $009045 stack real
    { cpu.push16Value(hw,0x8F78u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F79u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9045u), 0x008F76u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008F79;
L_008F79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F79u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F79u,0x008F79u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F79u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F79u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F79 TXY
    cpu.transfer("TXY");
    goto L_008F7A;
L_008F7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F7A BNE -> $008F7E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F7E; }
    goto L_008F7C;
L_008F7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F7C LDX
    cpu.setX(0xFCu, 8);
    goto L_008F7E;
L_008F7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Eu, 4u, 3u, cpu.address("abs", 0x0F14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F7E STA
    hw.write(cpu.address("abs", 0xF14u), cpu.a, cpu.m8?8:16);
    goto L_008F81;
L_008F81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F81u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F81u, 4u, 3u, cpu.address("abs", 0x0F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F81 STX
    hw.write(cpu.address("abs", 0xF13u), cpu.x, cpu.x8?8:16);
    goto L_008F84;
L_008F84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F84u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F84u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F84 SEP
    cpu.sep(0x20u);
    goto L_008F86;
L_008F86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F86u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F86u, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F86 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDB3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008F89;
L_008F89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F89u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F89u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F89 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_008F8B;
L_008F8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F8B STZ
    hw.write(cpu.address("dp", 0x1u), 0, cpu.m8?8:16);
    goto L_008F8D;
L_008F8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F8D STZ
    hw.write(cpu.address("dp", 0x3u), 0, cpu.m8?8:16);
    goto L_008F8F;
L_008F8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Fu, 4u + ((((0x0F48u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F8F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F92;
L_008F92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F92u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F92u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F92 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_008F94;
L_008F94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F94u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F94 LDX
    cpu.setX(0x9u, 8);
    goto L_008F96;
L_008F96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F96u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F96 LDY
    cpu.setY(0x10u, 8);
    goto L_008F98;
L_008F98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F98u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F98u, 6u, 3u, cpu.address("abs", 0x9051u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008F98 JSR -> $009051 stack real
    { cpu.push16Value(hw,0x8F9Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F9Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9051u), 0x008F98u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008F9B;
L_008F9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F9Bu,0x008F9Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F9B LDX
    cpu.setX(0x0u, 8);
    goto L_008F9D;
L_008F9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Du, 4u + ((((0x0F1Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F1Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F9D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF1Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008FA0;
L_008FA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FA0 BNE -> $008FAF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008FAF; }
    goto L_008FA2;
L_008FA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FA2 LDA
    cpu.setA(0xFCu, 8);
    goto L_008FA4;
L_008FA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA4u, 5u, 3u, cpu.address("absx", 0x0F1Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FA4 STA
    hw.write(cpu.address("absx", 0xF1Eu), cpu.a, cpu.m8?8:16);
    goto L_008FA7;
L_008FA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA7u, 5u, 3u, cpu.address("absx", 0x0F03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FA7 STA
    hw.write(cpu.address("absx", 0xF03u), cpu.a, cpu.m8?8:16);
    goto L_008FAA;
L_008FAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FAA INX
    cpu.inc('X');
    goto L_008FAB;
L_008FAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FABu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FAB CPX
    cpu.compareX(0x1u);
    goto L_008FAD;
L_008FAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FADu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FAD BNE -> $008F9D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F9D; }
    goto L_008FAF;
L_008FAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAFu, 4u + ((((0x0F1Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F1Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FAF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF1Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008FB2;
L_008FB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FB2 ASL
    cpu.aslA();
    goto L_008FB3;
L_008FB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FB3 TAY
    cpu.transfer("TAY");
    goto L_008FB4;
L_008FB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB4u, 4u + ((((0x8E06u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8E06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FB4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8E06u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008FB7;
L_008FB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB7u, 5u, 3u, cpu.address("absx", 0x0F03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FB7 STA
    hw.write(cpu.address("absx", 0xF03u), cpu.a, cpu.m8?8:16);
    goto L_008FBA;
L_008FBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBAu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBAu, 4u + ((((0x8E07u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8E07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FBA LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8E07u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008FBD;
L_008FBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBDu, 5u, 3u, cpu.address("absx", 0x0F1Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FBD STA
    hw.write(cpu.address("absx", 0xF1Eu), cpu.a, cpu.m8?8:16);
    goto L_008FC0;
L_008FC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FC0 INX
    cpu.inc('X');
    goto L_008FC1;
L_008FC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FC1 CPX
    cpu.compareX(0x2u);
    goto L_008FC3;
L_008FC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FC3 BNE -> $008FAF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008FAF; }
    goto L_008FC5;
L_008FC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC5u, 6u, 3u, cpu.address("abs", 0x9079u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008FC5 JSR -> $009079 stack real
    { cpu.push16Value(hw,0x8FC7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8FC8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9079u), 0x008FC5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008FC8;
L_008FC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FC8u,0x008FC8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC8u, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FC8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDB3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008FCB;
L_008FCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FCB BEQ -> $008FD8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008FD8; }
    goto L_008FCD;
L_008FCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FCD LDX
    cpu.setX(0x4u, 8);
    goto L_008FCF;
L_008FCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCFu, 4u + ((((0x8DF5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8DF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FCF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8DF5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008FD2;
L_008FD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD2u, 5u, 3u, cpu.address("absx", 0x0EF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FD2 STA
    hw.write(cpu.address("absx", 0xEF9u), cpu.a, cpu.m8?8:16);
    goto L_008FD5;
L_008FD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD5u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FD5 DEX
    cpu.decReg('X');
    goto L_008FD6;
L_008FD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FD6 BPL -> $008FCF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008FCF; }
    goto L_008FD8;
L_008FD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD8u, 4u, 3u, cpu.address("abs", 0x1422u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FD8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1422u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008FDB;
L_008FDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FDB CMP
    cpu.compareA(0x5u);
    goto L_008FDD;
L_008FDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FDD BCC -> $008FE1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_008FE1; }
    goto L_008FDF;
L_008FDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FDF LDA
    cpu.setA(0x0u, 8);
    goto L_008FE1;
L_008FE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE1u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FE1 DEC
    cpu.decReg('A');
    goto L_008FE2;
L_008FE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FE2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_008FE4;
L_008FE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FE4 LDX
    cpu.setX(0x0u, 8);
    goto L_008FE6;
L_008FE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FE6 LDY
    cpu.setY(0xFCu, 8);
    goto L_008FE8;
L_008FE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FE8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008FEA;
L_008FEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FEA BMI -> $008FEE
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_008FEE; }
    goto L_008FEC;
L_008FEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FECu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FEC LDY
    cpu.setY(0x2Eu, 8);
    goto L_008FEE;
L_008FEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEEu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FEE TYA
    cpu.transfer("TYA");
    goto L_008FEF;
L_008FEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEFu, 5u, 3u, cpu.address("absx", 0x0EFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FEF STA
    hw.write(cpu.address("absx", 0xEFFu), cpu.a, cpu.m8?8:16);
    goto L_008FF2;
L_008FF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF2u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FF2 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_008FF4;
L_008FF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FF4 INX
    cpu.inc('X');
    goto L_008FF5;
L_008FF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF5u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FF5 CPX
    cpu.compareX(0x4u);
    goto L_008FF7;
L_008FF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008FF7 BNE -> $008FE6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008FE6; }
    goto L_008FF9;
L_008FF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008FF9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008FF9u);return;} hw.unresolvedReturn(0x008FF9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_009389_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x009389u: goto L_009389;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_009389:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9389u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9389u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9389u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009389 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009389u);return;} hw.unresolvedReturn(0x009389u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00968D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00968Du: goto L_00968D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00968D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x968Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x968Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x968Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00968D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00968Du);return;} hw.unresolvedReturn(0x00968Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00C593_E1M1X1CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CDBDu: goto L_00CDBD;
    case 0x00CDBEu: goto L_00CDBE;
    case 0x00CDBFu: goto L_00CDBF;
    case 0x00CDC0u: goto L_00CDC0;
    case 0x00CDC1u: goto L_00CDC1;
    case 0x00CDC2u: goto L_00CDC2;
    case 0x00CDC3u: goto L_00CDC3;
    case 0x00CDC4u: goto L_00CDC4;
    case 0x00CDC5u: goto L_00CDC5;
    case 0x00CDC6u: goto L_00CDC6;
    case 0x00CDC8u: goto L_00CDC8;
    case 0x00CDC9u: goto L_00CDC9;
    case 0x00CDCAu: goto L_00CDCA;
    case 0x00CDCCu: goto L_00CDCC;
    case 0x00CDCDu: goto L_00CDCD;
    case 0x00CDCEu: goto L_00CDCE;
    case 0x00CDCFu: goto L_00CDCF;
    case 0x00CDD0u: goto L_00CDD0;
    case 0x00CDD2u: goto L_00CDD2;
    case 0x00CDD4u: goto L_00CDD4;
    case 0x00CDD6u: goto L_00CDD6;
    case 0x00CDD9u: goto L_00CDD9;
    case 0x00CDDCu: goto L_00CDDC;
    case 0x00DB17u: goto L_00DB17;
    case 0x00DB19u: goto L_00DB19;
    case 0x00DB1Bu: goto L_00DB1B;
    case 0x00DB1Eu: goto L_00DB1E;
    case 0x00DB21u: goto L_00DB21;
    case 0x00DB24u: goto L_00DB24;
    case 0x00DB26u: goto L_00DB26;
    case 0x00DB29u: goto L_00DB29;
    case 0x00DB2Bu: goto L_00DB2B;
    case 0x00DB2Du: goto L_00DB2D;
    case 0x00DB2Eu: goto L_00DB2E;
    case 0x00DB2Fu: goto L_00DB2F;
    case 0x00DB31u: goto L_00DB31;
    case 0x00DB32u: goto L_00DB32;
    case 0x00DB33u: goto L_00DB33;
    case 0x00DB34u: goto L_00DB34;
    case 0x00DB36u: goto L_00DB36;
    case 0x00DB38u: goto L_00DB38;
    case 0x00DB39u: goto L_00DB39;
    case 0x00DB3Bu: goto L_00DB3B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CDBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDBDu))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBDu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDBD DEY
    cpu.decReg('Y');
    goto L_00CDBE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBDu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDBD DEY
    cpu.decReg('Y');
    goto L_00CDBE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBDu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDBD DEY
    cpu.decReg('Y');
    goto L_00CDBE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBDu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDBD DEY
    cpu.decReg('Y');
    goto L_00CDBE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDBDu,0x00CDBDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDBEu))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDBE BNE -> $00CDC6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CDC6; }
    goto L_00CDC0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDBE BNE -> $00CDC6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CDC6; }
    goto L_00CDC0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDBE BNE -> $00CDC6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CDC6; }
    goto L_00CDC0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDBE BNE -> $00CDC6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CDC6; }
    goto L_00CDC0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDBEu,0x00CDBEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDBFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBFu,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDBF ASL
    cpu.aslMem(hw, cpu.address("dp", 0xA4u), cpu.m8?8:16);
    goto L_00CDC1;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBFu,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDBF ASL
    cpu.aslMem(hw, cpu.address("dp", 0xA4u), cpu.m8?8:16);
    goto L_00CDC1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDBFu,0x00CDBFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC0u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC0u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC0 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x73u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CDC2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC0u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC0 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x73u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CDC2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC0u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC0 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x73u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CDC2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC0u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC0 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x73u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CDC2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDC0u,0x00CDC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC1u,cpu,0x73u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC1u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xF0u) & 0xFFFFu), 2u, 0u);
    // $00CDC1 ADC
    cpu.adc(hw.readW(cpu.addressStackIndirectY(hw, 0xF0u), cpu.m8?8:16));
    goto L_00CDC3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC1u,cpu,0x73u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC1u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xF0u) & 0xFFFFu), 2u, 0u);
    // $00CDC1 ADC
    cpu.adc(hw.readW(cpu.addressStackIndirectY(hw, 0xF0u), cpu.m8?8:16));
    goto L_00CDC3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDC1u,0x00CDC1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC2u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC2 BEQ -> $00CDC6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CDC6; }
    goto L_00CDC4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC2 BEQ -> $00CDC6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CDC6; }
    goto L_00CDC4;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC2 BEQ -> $00CDC6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CDC6; }
    goto L_00CDC4;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC2 BEQ -> $00CDC6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CDC6; }
    goto L_00CDC4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDC2u,0x00CDC2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC3u,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC3u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xCDC5u,true);
    hw.requestDispatch(0x0082C3u,0x00CDC3u);return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC3u,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC3u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xCDC5u,true);
    hw.requestDispatch(0x0082C3u,0x00CDC3u);return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDC3u,0x00CDC3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC4u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC4 LDA
    cpu.setA(0x1Du, 8);
    goto L_00CDC6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC4 LDA
    cpu.setA(0x1Du, 8);
    goto L_00CDC6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC4 LDA
    cpu.setA(0x1Du, 8);
    goto L_00CDC6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC4 LDA
    cpu.setA(0x1Du, 8);
    goto L_00CDC6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDC4u,0x00CDC4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC5u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC5u, 4u + 1u, 3u, cpu.address("absx", 0xE08Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC5 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0xE08Du), cpu.m8?8:16));
    goto L_00CDC8;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC5u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC5u, 4u + 1u, 3u, cpu.address("absx", 0xE08Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC5 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0xE08Du), cpu.m8?8:16));
    goto L_00CDC8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDC5u,0x00CDC5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC6u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC6u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC6 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00CDC9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC6u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC6 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00CDC9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC6u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC6 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00CDC9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC6u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC6 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00CDC9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDC6u,0x00CDC6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC8u,cpu,0x13u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC8u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xADu) & 0xFFFFu), 2u, 0u);
    // $00CDC8 ORA
    cpu.logicOr(hw.readW(cpu.addressStackIndirectY(hw, 0xADu), cpu.m8?8:16));
    goto L_00CDCA;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC8u,cpu,0x13u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC8u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xADu) & 0xFFFFu), 2u, 0u);
    // $00CDC8 ORA
    cpu.logicOr(hw.readW(cpu.addressStackIndirectY(hw, 0xADu), cpu.m8?8:16));
    goto L_00CDCA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDC8u,0x00CDC8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC9u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u, 4u, 3u, cpu.address("abs", 0x141Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CDCC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u, 4u, 3u, cpu.address("abs", 0x141Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CDCC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u, 4u, 3u, cpu.address("abs", 0x141Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CDCC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u, 4u, 3u, cpu.address("abs", 0x141Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CDCC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDC9u,0x00CDC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDCAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCAu,cpu,0x1Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCAu, 7u, 3u, cpu.address("absx", 0xC914u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCA ASL
    cpu.aslMem(hw, cpu.address("absx", 0xC914u), cpu.m8?8:16);
    goto L_00CDCD;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCAu,cpu,0x1Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCAu, 7u, 3u, cpu.address("absx", 0xC914u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCA ASL
    cpu.aslMem(hw, cpu.address("absx", 0xC914u), cpu.m8?8:16);
    goto L_00CDCD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDCAu,0x00CDCAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDCCu))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCC CMP
    cpu.compareA(0x1u);
    goto L_00CDCE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCC CMP
    cpu.compareA(0x1u);
    goto L_00CDCE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCC CMP
    cpu.compareA(0x1u);
    goto L_00CDCE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCC CMP
    cpu.compareA(0x1u);
    goto L_00CDCE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDCCu,0x00CDCCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDCDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCDu,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCDu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xD0u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00CDCD ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0xD0u), cpu.m8?8:16));
    goto L_00CDCF;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCDu,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCDu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xD0u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00CDCD ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0xD0u), cpu.m8?8:16));
    goto L_00CDCF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDCDu,0x00CDCDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDCEu))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCE BNE -> $00CDDC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CDDC; }
    goto L_00CDD0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCE BNE -> $00CDDC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CDDC; }
    goto L_00CDD0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCE BNE -> $00CDDC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CDDC; }
    goto L_00CDD0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCE BNE -> $00CDDC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CDDC; }
    goto L_00CDD0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDCEu,0x00CDCEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDCFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCFu,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCFu, 6u, 3u, cpu.address("abs", 0x1624u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCF TSB
    cpu.tsb(hw, cpu.address("abs", 0x1624u), cpu.m8?8:16);
    goto L_00CDD2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCFu,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCFu, 6u, 3u, cpu.address("abs", 0x1624u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCF TSB
    cpu.tsb(hw, cpu.address("abs", 0x1624u), cpu.m8?8:16);
    goto L_00CDD2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDCFu,0x00CDCFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDD0u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD0u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD0 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), false);
    goto L_00CDD2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD0u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD0 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), false);
    goto L_00CDD2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD0u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD0 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), false);
    goto L_00CDD2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD0u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD0 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), false);
    goto L_00CDD2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDD0u,0x00CDD0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDD2u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD2u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD2 BVC -> $00CDDC
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_00CDDC; }
    goto L_00CDD4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD2u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD2 BVC -> $00CDDC
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_00CDDC; }
    goto L_00CDD4;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD2u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD2 BVC -> $00CDDC
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_00CDDC; }
    goto L_00CDD4;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD2u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD2 BVC -> $00CDDC
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_00CDDC; }
    goto L_00CDD4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDD2u,0x00CDD2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDD4u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD4 LDA
    cpu.setA(0x8u, 8);
    goto L_00CDD6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD4 LDA
    cpu.setA(0x8u, 8);
    goto L_00CDD6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD4 LDA
    cpu.setA(0x8u, 8);
    goto L_00CDD6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD4 LDA
    cpu.setA(0x8u, 8);
    goto L_00CDD6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDD4u,0x00CDD4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDD6u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD6u, 4u, 3u, cpu.address("abs", 0x18DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD6 STA
    hw.write(cpu.address("abs", 0x18DBu), cpu.a, cpu.m8?8:16);
    goto L_00CDD9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD6u, 4u, 3u, cpu.address("abs", 0x18DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD6 STA
    hw.write(cpu.address("abs", 0x18DBu), cpu.a, cpu.m8?8:16);
    goto L_00CDD9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD6u, 4u, 3u, cpu.address("abs", 0x18DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD6 STA
    hw.write(cpu.address("abs", 0x18DBu), cpu.a, cpu.m8?8:16);
    goto L_00CDD9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD6u, 4u, 3u, cpu.address("abs", 0x18DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD6 STA
    hw.write(cpu.address("abs", 0x18DBu), cpu.a, cpu.m8?8:16);
    goto L_00CDD9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDD6u,0x00CDD6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDD9u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD9u, 6u, 3u, cpu.address("abs", 0xFEA8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CDD9 JSR -> $00FEA8 stack real
    { cpu.push16Value(hw,0xCDDBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCDDCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFEA8u), 0x00CDD9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CDDC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD9u, 6u, 3u, cpu.address("abs", 0xFEA8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CDD9 JSR -> $00FEA8 stack real
    { cpu.push16Value(hw,0xCDDBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCDDCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFEA8u), 0x00CDD9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CDDC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD9u, 6u, 3u, cpu.address("abs", 0xFEA8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CDD9 JSR -> $00FEA8 stack real
    { cpu.push16Value(hw,0xCDDBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCDDCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFEA8u), 0x00CDD9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CDDC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD9u, 6u, 3u, cpu.address("abs", 0xFEA8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CDD9 JSR -> $00FEA8 stack real
    { cpu.push16Value(hw,0xCDDBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCDDCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFEA8u), 0x00CDD9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CDDC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDD9u,0x00CDD9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDDCu))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CDDC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CDDCu);return;} hw.unresolvedReturn(0x00CDDCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CDDC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CDDCu);return;} hw.unresolvedReturn(0x00CDDCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CDDC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CDDCu);return;} hw.unresolvedReturn(0x00CDDCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CDDC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CDDCu);return;} hw.unresolvedReturn(0x00CDDCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDDCu,0x00CDDCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB17u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB17u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB17u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB17 STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_00DB19;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB17u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB17u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB17 STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_00DB19;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB17u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB17u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB17 STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_00DB19;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB17u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB17u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB17 STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_00DB19;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB17u,0x00DB17u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB19u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB19u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB19u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB19 STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    goto L_00DB1B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB19u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB19u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB19 STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    goto L_00DB1B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB19u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB19u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB19 STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    goto L_00DB1B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB19u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB19u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB19 STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    goto L_00DB1B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB19u,0x00DB19u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB1Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu, 4u, 3u, cpu.address("abs", 0x13DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB1B STZ
    hw.write(cpu.address("abs", 0x13DFu), 0, cpu.m8?8:16);
    goto L_00DB1E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu, 4u, 3u, cpu.address("abs", 0x13DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB1B STZ
    hw.write(cpu.address("abs", 0x13DFu), 0, cpu.m8?8:16);
    goto L_00DB1E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu, 4u, 3u, cpu.address("abs", 0x13DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB1B STZ
    hw.write(cpu.address("abs", 0x13DFu), 0, cpu.m8?8:16);
    goto L_00DB1E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu, 4u, 3u, cpu.address("abs", 0x13DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB1B STZ
    hw.write(cpu.address("abs", 0x13DFu), 0, cpu.m8?8:16);
    goto L_00DB1E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB1Bu,0x00DB1Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB1Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB1E STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    goto L_00DB21;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB1E STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    goto L_00DB21;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB1E STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    goto L_00DB21;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB1E STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    goto L_00DB21;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB1Eu,0x00DB1Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB21u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u, 5u, 3u, cpu.address("abs", 0x149Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB21 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x149Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DB24;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u, 4u, 3u, cpu.address("abs", 0x149Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB21 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x149Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DB24;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u, 5u, 3u, cpu.address("abs", 0x149Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB21 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x149Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DB24;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u, 4u, 3u, cpu.address("abs", 0x149Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB21 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x149Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DB24;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB21u,0x00DB21u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB24u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB24 BEQ -> $00DB7D
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB7Du,0x00DB24u); return; }
    goto L_00DB26;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB24 BEQ -> $00DB7D
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB7Du,0x00DB24u); return; }
    goto L_00DB26;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB24 BEQ -> $00DB7D
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB7Du,0x00DB24u); return; }
    goto L_00DB26;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB24 BEQ -> $00DB7D
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB7Du,0x00DB24u); return; }
    goto L_00DB26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB24u,0x00DB24u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB26u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB26 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB29;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB26 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB29;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB26 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB29;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB26 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB29;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB26u,0x00DB26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB29u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB29 BPL -> $00DB2E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB2E; }
    goto L_00DB2B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB29 BPL -> $00DB2E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB2E; }
    goto L_00DB2B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB29 BPL -> $00DB2E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB2E; }
    goto L_00DB2B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB29 BPL -> $00DB2E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB2E; }
    goto L_00DB2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB29u,0x00DB29u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB2Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2B EOR
    cpu.logicXor(0xFFu);
    goto L_00DB2D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2B EOR
    cpu.logicXor(0xFFu);
    goto L_00DB2D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2B EOR
    cpu.logicXor(0xFFu);
    goto L_00DB2D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2B EOR
    cpu.logicXor(0xFFu);
    goto L_00DB2D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB2Bu,0x00DB2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB2Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2D INC
    cpu.inc('A');
    goto L_00DB2E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2D INC
    cpu.inc('A');
    goto L_00DB2E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2D INC
    cpu.inc('A');
    goto L_00DB2E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2D INC
    cpu.inc('A');
    goto L_00DB2E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB2Du,0x00DB2Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB2Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2E TAX
    cpu.transfer("TAX");
    goto L_00DB2F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2E TAX
    cpu.transfer("TAX");
    goto L_00DB2F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2E TAX
    cpu.transfer("TAX");
    goto L_00DB2F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2E TAX
    cpu.transfer("TAX");
    goto L_00DB2F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB2Eu,0x00DB2Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB2Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2F CPY
    cpu.compareY(0x901Eu);
    goto L_00DB32;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2F CPY
    cpu.compareY(0x1Eu);
    goto L_00DB31;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2F CPY
    cpu.compareY(0x901Eu);
    goto L_00DB32;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2F CPY
    cpu.compareY(0x1Eu);
    goto L_00DB31;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB2Fu,0x00DB2Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB31u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB31u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB31 BCC -> $00DB45
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB45u,0x00DB31u); return; }
    goto L_00DB33;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB31u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB31 BCC -> $00DB45
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB45u,0x00DB31u); return; }
    goto L_00DB33;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB31u,0x00DB31u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB32u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB32u,cpu,0x12u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB32u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xBDu) & 0xFFFFu), 2u, 0u);
    // $00DB32 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirect(hw, 0xBDu), cpu.m8?8:16));
    goto L_00DB34;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB32u,cpu,0x12u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB32u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xBDu) & 0xFFFFu), 2u, 0u);
    // $00DB32 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirect(hw, 0xBDu), cpu.m8?8:16));
    goto L_00DB34;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB32u,0x00DB32u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB33u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB33u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB33u, 4u + ((((0xDADFu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDADFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB33 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDADFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB36;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB33u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB33u, 4u + ((((0xDADFu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDADFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB33 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDADFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB36;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB33u,0x00DB33u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB34u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB34u,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB34u, 5u, 4u, ((0x782CDAu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB34 CMP
    cpu.compareA(hw.readW(((0x782CDAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00DB38;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB34u,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB34u, 5u, 4u, ((0x782CDAu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB34 CMP
    cpu.compareA(hw.readW(((0x782CDAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00DB38;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB34u,0x00DB34u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB36u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB36u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB36u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB36 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), false);
    goto L_00DB39;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB36u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB36u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB36 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), false);
    goto L_00DB39;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB36u,0x00DB36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB38u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB38u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB38 CLC
    cpu.setFlag('C', false);
    goto L_00DB39;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB38u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB38 CLC
    cpu.setFlag('C', false);
    goto L_00DB39;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB38u,0x00DB38u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB39u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB39 BPL -> $00DB3E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB3Eu,0x00DB39u); return; }
    goto L_00DB3B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB39 BPL -> $00DB3E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB3Eu,0x00DB39u); return; }
    goto L_00DB3B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB39 BPL -> $00DB3E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB3Eu,0x00DB39u); return; }
    goto L_00DB3B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB39 BPL -> $00DB3E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB3Eu,0x00DB39u); return; }
    goto L_00DB3B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB39u,0x00DB39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB3Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3B EOR
    cpu.logicXor(0xFFu);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB3Du,0x00DB3Bu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3B EOR
    cpu.logicXor(0xFFu);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB3Du,0x00DB3Bu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3B EOR
    cpu.logicXor(0xFFu);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB3Du,0x00DB3Bu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3B EOR
    cpu.logicXor(0xFFu);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB3Du,0x00DB3Bu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB3Bu,0x00DB3Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1C1_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00ED5Eu: goto L_00ED5E;
    case 0x00ED60u: goto L_00ED60;
    case 0x00ED62u: goto L_00ED62;
    case 0x00ED64u: goto L_00ED64;
    case 0x00ED66u: goto L_00ED66;
    case 0x00ED69u: goto L_00ED69;
    case 0x00ED6Bu: goto L_00ED6B;
    case 0x00ED6Du: goto L_00ED6D;
    case 0x00ED6Eu: goto L_00ED6E;
    case 0x00ED71u: goto L_00ED71;
    case 0x00ED73u: goto L_00ED73;
    case 0x00ED76u: goto L_00ED76;
    case 0x00ED78u: goto L_00ED78;
    case 0x00ED7Au: goto L_00ED7A;
    case 0x00ED7Cu: goto L_00ED7C;
    case 0x00ED7Eu: goto L_00ED7E;
    case 0x00ED80u: goto L_00ED80;
    case 0x00ED82u: goto L_00ED82;
    case 0x00ED85u: goto L_00ED85;
    case 0x00ED87u: goto L_00ED87;
    case 0x00ED89u: goto L_00ED89;
    case 0x00ED8Cu: goto L_00ED8C;
    case 0x00ED8Eu: goto L_00ED8E;
    case 0x00ED91u: goto L_00ED91;
    case 0x00ED93u: goto L_00ED93;
    case 0x00ED95u: goto L_00ED95;
    case 0x00ED96u: goto L_00ED96;
    case 0x00ED97u: goto L_00ED97;
    case 0x00ED9Au: goto L_00ED9A;
    case 0x00ED9Cu: goto L_00ED9C;
    case 0x00ED9Du: goto L_00ED9D;
    case 0x00ED9Fu: goto L_00ED9F;
    case 0x00EDA2u: goto L_00EDA2;
    case 0x00EDA3u: goto L_00EDA3;
    case 0x00EDA4u: goto L_00EDA4;
    case 0x00EDA5u: goto L_00EDA5;
    case 0x00EDA6u: goto L_00EDA6;
    case 0x00EDA8u: goto L_00EDA8;
    case 0x00EDAAu: goto L_00EDAA;
    case 0x00EDABu: goto L_00EDAB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00ED5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED5Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED5Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED5E CPY
    cpu.compareY(0xD8u);
    goto L_00ED60;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED5Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED5E CPY
    cpu.compareY(0xD8u);
    goto L_00ED60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED5Eu,0x00ED5Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED60u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED60u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED60 BCC -> $00ED86
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ED86u,0x00ED60u); return; }
    goto L_00ED62;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED60u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED60 BCC -> $00ED86
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ED86u,0x00ED60u); return; }
    goto L_00ED62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED60u,0x00ED60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED62u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED62u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED62 CPY
    cpu.compareY(0xFBu);
    goto L_00ED64;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED62u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED62 CPY
    cpu.compareY(0xFBu);
    goto L_00ED64;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED62u,0x00ED62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED64u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED64u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED64u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED64 BCC -> $00ED69
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00ED69; }
    goto L_00ED66;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED64u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED64u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED64 BCC -> $00ED69
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00ED69; }
    goto L_00ED66;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED64u,0x00ED64u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED66u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED66u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED66u, 3u, 3u, cpu.address("abs", 0xF629u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED66 JMP -> $00F629
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xF629u),0x00ED66u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED66u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED66u, 3u, 3u, cpu.address("abs", 0xF629u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED66 JMP -> $00F629
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xF629u),0x00ED66u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED66u,0x00ED66u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED69u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED69u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED69u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED69 REP
    cpu.rep(0x20u);
    goto L_00ED6B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED69u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED69u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED69 REP
    cpu.rep(0x20u);
    goto L_00ED6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED69u,0x00ED69u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED6Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED6Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED6B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED6D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED6Bu,0x00ED6Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED6Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED6Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED6Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED6D SEC
    cpu.setFlag('C', true);
    goto L_00ED6E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED6Du,0x00ED6Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED6Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED6Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED6Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED6E SBC
    cpu.sbc(0x10u);
    goto L_00ED71;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED6Eu,0x00ED6Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED71u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED71u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED71u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED71 STA
    hw.write(cpu.address("dp", 0x98u), cpu.a, cpu.m8?8:16);
    goto L_00ED73;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED71u,0x00ED71u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED73u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED73u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED73u, 6u, 3u, cpu.address("abs", 0xF461u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ED73 JSR -> $00F461 stack real
    { cpu.push16Value(hw,0xED75u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xED76u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF461u), 0x00ED73u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00ED76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED73u,0x00ED73u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED76u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED76u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED76 BEQ -> $00EDE9
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED76u); return; }
    goto L_00ED78;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED76u,0x00ED76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED78u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED78u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED78 CPY
    cpu.compareY(0x6Eu);
    goto L_00ED7A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED78u,0x00ED78u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED7Au))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED7A BCC -> $00EDE9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED7Au); return; }
    goto L_00ED7C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED7Au,0x00ED7Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED7Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Cu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED7C CPY
    cpu.compareY(0xD8u);
    goto L_00ED7E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED7Cu,0x00ED7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED7Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED7E BCS -> $00EDE9
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED7Eu); return; }
    goto L_00ED80;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED7Eu,0x00ED7Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED80u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED80u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED80u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED80 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED82;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED80u,0x00ED80u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED82u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED82u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED82u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED82 ADC
    cpu.adc(0x8510u);
    goto L_00ED85;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED82u,0x00ED82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED85u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED85u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED85 BCC -> $00ED34
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ED34u,0x00ED85u); return; }
    goto L_00ED87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED85u,0x00ED85u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED87u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED87u,cpu,0x31u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED87u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x19u) & 0xFFFFu), 2u, 0u);
    // $00ED87 AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirectY(hw, 0x19u), cpu.m8?8:16));
    goto L_00ED89;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED87u,0x00ED87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED89u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED89u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED89u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED89 CMP
    cpu.compareA(0xF003u);
    goto L_00ED8C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED89u,0x00ED89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Cu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED8C TSB
    cpu.tsb(hw, cpu.address("dp", 0xC9u), cpu.m8?8:16);
    goto L_00ED8E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED8Cu,0x00ED8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Eu,cpu,0x0Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Eu, 8u, 3u, cpu.address("abs", 0x04D0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED8E ASL
    cpu.aslMem(hw, cpu.address("abs", 0x4D0u), cpu.m8?8:16);
    goto L_00ED91;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED8Eu,0x00ED8Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED91u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED91u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED91 CPY
    cpu.compareY(0xD2u);
    goto L_00ED93;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED91u,0x00ED91u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED93u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED93u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED93 BCS -> $00EDE9
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED93u); return; }
    goto L_00ED95;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED93u,0x00ED93u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED95u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED95u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED95 TYA
    cpu.transfer("TYA");
    goto L_00ED96;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED95u,0x00ED95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED96u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED96u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED96 SEC
    cpu.setFlag('C', true);
    goto L_00ED97;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED96u,0x00ED96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED97u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED97u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED97u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED97 SBC
    cpu.sbc(0xA86Eu);
    goto L_00ED9A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED97u,0x00ED97u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Au))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Au,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x82u) & 0xFFFFu), 3u, 0u);
    // $00ED9A LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED9Au,0x00ED9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ED9C PHA
    cpu.push("PHA", hw);
    goto L_00ED9D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED9Cu,0x00ED9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED9D REP
    cpu.rep(0x20u);
    goto L_00ED9F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED9Du,0x00ED9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED9F AND
    cpu.logicAnd(0xFFu);
    goto L_00EDA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED9Fu,0x00ED9Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA2u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA2 ASL
    cpu.aslA();
    goto L_00EDA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA2u,0x00EDA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA3u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA3 ASL
    cpu.aslA();
    goto L_00EDA4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA3u,0x00EDA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA4u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA4 ASL
    cpu.aslA();
    goto L_00EDA5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA4u,0x00EDA4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA5u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA5 ASL
    cpu.aslA();
    goto L_00EDA6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA5u,0x00EDA5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA6u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA6 SEP
    cpu.sep(0x20u);
    goto L_00EDA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA6u,0x00EDA6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA8u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA8u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA8 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x92u), cpu.m8?8:16));
    goto L_00EDAA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA8u,0x00EDA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDAAu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAAu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EDAA PHX
    cpu.push("PHX", hw);
    goto L_00EDAB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDAAu,0x00EDAAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDABu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDABu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDABu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDAB REP
    cpu.rep(0x10u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDADu,0x00EDABu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDABu,0x00EDABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00ED5Eu: goto L_00ED5E;
    case 0x00ED60u: goto L_00ED60;
    case 0x00ED62u: goto L_00ED62;
    case 0x00ED64u: goto L_00ED64;
    case 0x00ED66u: goto L_00ED66;
    case 0x00ED69u: goto L_00ED69;
    case 0x00ED6Bu: goto L_00ED6B;
    case 0x00ED6Du: goto L_00ED6D;
    case 0x00ED6Eu: goto L_00ED6E;
    case 0x00ED71u: goto L_00ED71;
    case 0x00ED73u: goto L_00ED73;
    case 0x00ED76u: goto L_00ED76;
    case 0x00ED78u: goto L_00ED78;
    case 0x00ED7Au: goto L_00ED7A;
    case 0x00ED7Cu: goto L_00ED7C;
    case 0x00ED7Eu: goto L_00ED7E;
    case 0x00ED80u: goto L_00ED80;
    case 0x00ED82u: goto L_00ED82;
    case 0x00ED85u: goto L_00ED85;
    case 0x00ED87u: goto L_00ED87;
    case 0x00ED89u: goto L_00ED89;
    case 0x00ED8Cu: goto L_00ED8C;
    case 0x00ED8Eu: goto L_00ED8E;
    case 0x00ED91u: goto L_00ED91;
    case 0x00ED93u: goto L_00ED93;
    case 0x00ED95u: goto L_00ED95;
    case 0x00ED96u: goto L_00ED96;
    case 0x00ED97u: goto L_00ED97;
    case 0x00ED9Au: goto L_00ED9A;
    case 0x00ED9Cu: goto L_00ED9C;
    case 0x00ED9Du: goto L_00ED9D;
    case 0x00ED9Fu: goto L_00ED9F;
    case 0x00EDA2u: goto L_00EDA2;
    case 0x00EDA3u: goto L_00EDA3;
    case 0x00EDA4u: goto L_00EDA4;
    case 0x00EDA5u: goto L_00EDA5;
    case 0x00EDA6u: goto L_00EDA6;
    case 0x00EDA8u: goto L_00EDA8;
    case 0x00EDAAu: goto L_00EDAA;
    case 0x00EDABu: goto L_00EDAB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00ED5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED5Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED5Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED5E CPY
    cpu.compareY(0xD8u);
    goto L_00ED60;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED5Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED5E CPY
    cpu.compareY(0xD8u);
    goto L_00ED60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED5Eu,0x00ED5Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED60u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED60u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED60 BCC -> $00ED86
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ED86u,0x00ED60u); return; }
    goto L_00ED62;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED60u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED60 BCC -> $00ED86
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ED86u,0x00ED60u); return; }
    goto L_00ED62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED60u,0x00ED60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED62u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED62u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED62 CPY
    cpu.compareY(0xFBu);
    goto L_00ED64;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED62u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED62 CPY
    cpu.compareY(0xFBu);
    goto L_00ED64;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED62u,0x00ED62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED64u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED64u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED64u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED64 BCC -> $00ED69
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00ED69; }
    goto L_00ED66;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED64u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED64u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED64 BCC -> $00ED69
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00ED69; }
    goto L_00ED66;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED64u,0x00ED64u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED66u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED66u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED66u, 3u, 3u, cpu.address("abs", 0xF629u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED66 JMP -> $00F629
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xF629u),0x00ED66u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED66u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED66u, 3u, 3u, cpu.address("abs", 0xF629u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED66 JMP -> $00F629
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xF629u),0x00ED66u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED66u,0x00ED66u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED69u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED69u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED69u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED69 REP
    cpu.rep(0x20u);
    goto L_00ED6B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED69u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED69u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED69 REP
    cpu.rep(0x20u);
    goto L_00ED6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED69u,0x00ED69u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED6Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED6Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED6B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED6D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED6Bu,0x00ED6Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED6Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED6Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED6Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED6D SEC
    cpu.setFlag('C', true);
    goto L_00ED6E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED6Du,0x00ED6Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED6Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED6Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED6Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED6E SBC
    cpu.sbc(0x10u);
    goto L_00ED71;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED6Eu,0x00ED6Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED71u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED71u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED71u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED71 STA
    hw.write(cpu.address("dp", 0x98u), cpu.a, cpu.m8?8:16);
    goto L_00ED73;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED71u,0x00ED71u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED73u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED73u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED73u, 6u, 3u, cpu.address("abs", 0xF461u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ED73 JSR -> $00F461 stack real
    { cpu.push16Value(hw,0xED75u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xED76u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF461u), 0x00ED73u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00ED76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED73u,0x00ED73u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED76u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED76u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED76 BEQ -> $00EDE9
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED76u); return; }
    goto L_00ED78;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED76u,0x00ED76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED78u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED78u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED78 CPY
    cpu.compareY(0x6Eu);
    goto L_00ED7A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED78u,0x00ED78u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED7Au))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED7A BCC -> $00EDE9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED7Au); return; }
    goto L_00ED7C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED7Au,0x00ED7Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED7Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Cu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED7C CPY
    cpu.compareY(0xD8u);
    goto L_00ED7E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED7Cu,0x00ED7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED7Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED7E BCS -> $00EDE9
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED7Eu); return; }
    goto L_00ED80;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED7Eu,0x00ED7Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED80u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED80u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED80u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED80 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED82;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED80u,0x00ED80u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED82u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED82u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED82u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED82 ADC
    cpu.adc(0x8510u);
    goto L_00ED85;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED82u,0x00ED82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED85u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED85u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED85 BCC -> $00ED34
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ED34u,0x00ED85u); return; }
    goto L_00ED87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED85u,0x00ED85u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED87u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED87u,cpu,0x31u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED87u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x19u) & 0xFFFFu), 2u, 0u);
    // $00ED87 AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirectY(hw, 0x19u), cpu.m8?8:16));
    goto L_00ED89;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED87u,0x00ED87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED89u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED89u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED89u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED89 CMP
    cpu.compareA(0xF003u);
    goto L_00ED8C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED89u,0x00ED89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Cu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED8C TSB
    cpu.tsb(hw, cpu.address("dp", 0xC9u), cpu.m8?8:16);
    goto L_00ED8E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED8Cu,0x00ED8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Eu,cpu,0x0Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Eu, 8u, 3u, cpu.address("abs", 0x04D0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED8E ASL
    cpu.aslMem(hw, cpu.address("abs", 0x4D0u), cpu.m8?8:16);
    goto L_00ED91;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED8Eu,0x00ED8Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED91u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED91u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED91 CPY
    cpu.compareY(0xD2u);
    goto L_00ED93;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED91u,0x00ED91u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED93u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED93u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED93 BCS -> $00EDE9
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED93u); return; }
    goto L_00ED95;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED93u,0x00ED93u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED95u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED95u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED95 TYA
    cpu.transfer("TYA");
    goto L_00ED96;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED95u,0x00ED95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED96u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED96u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED96 SEC
    cpu.setFlag('C', true);
    goto L_00ED97;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED96u,0x00ED96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED97u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED97u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED97u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED97 SBC
    cpu.sbc(0xA86Eu);
    goto L_00ED9A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED97u,0x00ED97u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Au))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Au,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x82u) & 0xFFFFu), 3u, 0u);
    // $00ED9A LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED9Au,0x00ED9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ED9C PHA
    cpu.push("PHA", hw);
    goto L_00ED9D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED9Cu,0x00ED9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED9D REP
    cpu.rep(0x20u);
    goto L_00ED9F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED9Du,0x00ED9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED9F AND
    cpu.logicAnd(0xFFu);
    goto L_00EDA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED9Fu,0x00ED9Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA2u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA2 ASL
    cpu.aslA();
    goto L_00EDA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA2u,0x00EDA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA3u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA3 ASL
    cpu.aslA();
    goto L_00EDA4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA3u,0x00EDA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA4u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA4 ASL
    cpu.aslA();
    goto L_00EDA5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA4u,0x00EDA4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA5u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA5 ASL
    cpu.aslA();
    goto L_00EDA6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA5u,0x00EDA5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA6u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA6 SEP
    cpu.sep(0x20u);
    goto L_00EDA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA6u,0x00EDA6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA8u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA8u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA8 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x92u), cpu.m8?8:16));
    goto L_00EDAA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA8u,0x00EDA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDAAu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAAu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EDAA PHX
    cpu.push("PHX", hw);
    goto L_00EDAB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDAAu,0x00EDAAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDABu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDABu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDABu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDAB REP
    cpu.rep(0x10u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDADu,0x00EDABu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDABu,0x00EDABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_01878E_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01878Eu: goto L_01878E;
    case 0x018792u: goto L_018792;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01878E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Eu, 8u, 4u, 0x03A118u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01878E JSL -> $03A118 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8791u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8792u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x03A118u, 0x01878Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018792;
L_018792:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8792u))return;
  // 5 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8792u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8792u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018792 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018792u);return;} hw.unresolvedReturn(0x018792u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8792u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8792u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018792 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018792u);return;} hw.unresolvedReturn(0x018792u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8792u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8792u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018792 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018792u);return;} hw.unresolvedReturn(0x018792u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8792u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8792u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018792 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018792u);return;} hw.unresolvedReturn(0x018792u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8792u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8792u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018792 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018792u);return;} hw.unresolvedReturn(0x018792u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8792u,0x018792u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_01878E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01878Eu: goto L_01878E;
    case 0x018792u: goto L_018792;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01878E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Eu, 8u, 4u, 0x03A118u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01878E JSL -> $03A118 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8791u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8792u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x03A118u, 0x01878Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018792;
L_018792:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8792u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8792u,0x018792u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8792u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8792u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018792 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018792u);return;} hw.unresolvedReturn(0x018792u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01A7F7_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01A7F7u: goto L_01A7F7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01A7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F7u, 6u, 3u, cpu.address("abs", 0xAD30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A7F7 JSR -> $01AD30 stack real
    { cpu.push16Value(hw,0xA7F9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7FAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD30u), 0x01A7F7u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7FAu,0x01A7F7u); return;
}

void sub_01A7F7_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01A7F5u: goto L_01A7F5;
    case 0x01A7F6u: goto L_01A7F6;
    case 0x01A7F7u: goto L_01A7F7;
    case 0x01A7FAu: goto L_01A7FA;
    case 0x01A7FCu: goto L_01A7FC;
    case 0x01A7FDu: goto L_01A7FD;
    case 0x01A7FFu: goto L_01A7FF;
    case 0x01A801u: goto L_01A801;
    case 0x01A803u: goto L_01A803;
    case 0x01A806u: goto L_01A806;
    case 0x01A808u: goto L_01A808;
    case 0x01A809u: goto L_01A809;
    case 0x01A80Bu: goto L_01A80B;
    case 0x01A80Du: goto L_01A80D;
    case 0x01A80Fu: goto L_01A80F;
    case 0x01A811u: goto L_01A811;
    case 0x01A813u: goto L_01A813;
    case 0x01A815u: goto L_01A815;
    case 0x01A817u: goto L_01A817;
    case 0x01A81Au: goto L_01A81A;
    case 0x01A81Cu: goto L_01A81C;
    case 0x01A81Fu: goto L_01A81F;
    case 0x01A822u: goto L_01A822;
    case 0x01A824u: goto L_01A824;
    case 0x01A828u: goto L_01A828;
    case 0x01A82Cu: goto L_01A82C;
    case 0x01A830u: goto L_01A830;
    case 0x01A832u: goto L_01A832;
    case 0x01A835u: goto L_01A835;
    case 0x01A837u: goto L_01A837;
    case 0x01A838u: goto L_01A838;
    case 0x01A83Bu: goto L_01A83B;
    case 0x01A83Eu: goto L_01A83E;
    case 0x01A840u: goto L_01A840;
    case 0x01A843u: goto L_01A843;
    case 0x01A845u: goto L_01A845;
    case 0x01A847u: goto L_01A847;
    case 0x01A84Bu: goto L_01A84B;
    case 0x01A84Eu: goto L_01A84E;
    case 0x01A851u: goto L_01A851;
    case 0x01A853u: goto L_01A853;
    case 0x01A855u: goto L_01A855;
    case 0x01A857u: goto L_01A857;
    case 0x01A85Au: goto L_01A85A;
    case 0x01A85Eu: goto L_01A85E;
    case 0x01A861u: goto L_01A861;
    case 0x01A863u: goto L_01A863;
    case 0x01A865u: goto L_01A865;
    case 0x01A868u: goto L_01A868;
    case 0x01A86Bu: goto L_01A86B;
    case 0x01A86Du: goto L_01A86D;
    case 0x01A870u: goto L_01A870;
    case 0x01A872u: goto L_01A872;
    case 0x01A874u: goto L_01A874;
    case 0x01A877u: goto L_01A877;
    case 0x01A87Au: goto L_01A87A;
    case 0x01A87Cu: goto L_01A87C;
    case 0x01A87Du: goto L_01A87D;
    case 0x01A87Eu: goto L_01A87E;
    case 0x01A881u: goto L_01A881;
    case 0x01A884u: goto L_01A884;
    case 0x01A886u: goto L_01A886;
    case 0x01A888u: goto L_01A888;
    case 0x01A88Bu: goto L_01A88B;
    case 0x01A88Eu: goto L_01A88E;
    case 0x01A890u: goto L_01A890;
    case 0x01A892u: goto L_01A892;
    case 0x01A895u: goto L_01A895;
    case 0x01A896u: goto L_01A896;
    case 0x01A897u: goto L_01A897;
    case 0x01A899u: goto L_01A899;
    case 0x01A89Bu: goto L_01A89B;
    case 0x01A89Du: goto L_01A89D;
    case 0x01A89Eu: goto L_01A89E;
    case 0x01A8A0u: goto L_01A8A0;
    case 0x01A8A2u: goto L_01A8A2;
    case 0x01A8A4u: goto L_01A8A4;
    case 0x01A8A5u: goto L_01A8A5;
    case 0x01A8A7u: goto L_01A8A7;
    case 0x01A8A9u: goto L_01A8A9;
    case 0x01A8ABu: goto L_01A8AB;
    case 0x01A8ACu: goto L_01A8AC;
    case 0x01A8AEu: goto L_01A8AE;
    case 0x01A8B0u: goto L_01A8B0;
    case 0x01A8B2u: goto L_01A8B2;
    case 0x01A8B4u: goto L_01A8B4;
    case 0x01A8B7u: goto L_01A8B7;
    case 0x01A8B9u: goto L_01A8B9;
    case 0x01A8BBu: goto L_01A8BB;
    case 0x01A8BEu: goto L_01A8BE;
    case 0x01A8C0u: goto L_01A8C0;
    case 0x01A8C3u: goto L_01A8C3;
    case 0x01A8C5u: goto L_01A8C5;
    case 0x01A8C7u: goto L_01A8C7;
    case 0x01A8C9u: goto L_01A8C9;
    case 0x01A8CCu: goto L_01A8CC;
    case 0x01A8CEu: goto L_01A8CE;
    case 0x01A8D0u: goto L_01A8D0;
    case 0x01A8D3u: goto L_01A8D3;
    case 0x01A8D6u: goto L_01A8D6;
    case 0x01A8D8u: goto L_01A8D8;
    case 0x01A8DAu: goto L_01A8DA;
    case 0x01A8DDu: goto L_01A8DD;
    case 0x01A8E1u: goto L_01A8E1;
    case 0x01A8E5u: goto L_01A8E5;
    case 0x01A8E6u: goto L_01A8E6;
    case 0x01A8E9u: goto L_01A8E9;
    case 0x01A8EBu: goto L_01A8EB;
    case 0x01A8EEu: goto L_01A8EE;
    case 0x01A8F0u: goto L_01A8F0;
    case 0x01A8F2u: goto L_01A8F2;
    case 0x01A8F5u: goto L_01A8F5;
    case 0x01A8F8u: goto L_01A8F8;
    case 0x01A8F9u: goto L_01A8F9;
    case 0x01A8FCu: goto L_01A8FC;
    case 0x01A8FEu: goto L_01A8FE;
    case 0x01A901u: goto L_01A901;
    case 0x01A903u: goto L_01A903;
    case 0x01A906u: goto L_01A906;
    case 0x01A908u: goto L_01A908;
    case 0x01A90Au: goto L_01A90A;
    case 0x01A90Du: goto L_01A90D;
    case 0x01A90Eu: goto L_01A90E;
    case 0x01A911u: goto L_01A911;
    case 0x01A913u: goto L_01A913;
    case 0x01A915u: goto L_01A915;
    case 0x01A917u: goto L_01A917;
    case 0x01A91Bu: goto L_01A91B;
    case 0x01A91Cu: goto L_01A91C;
    case 0x01A91Fu: goto L_01A91F;
    case 0x01A922u: goto L_01A922;
    case 0x01A924u: goto L_01A924;
    case 0x01A928u: goto L_01A928;
    case 0x01A92Au: goto L_01A92A;
    case 0x01A92Cu: goto L_01A92C;
    case 0x01A92Fu: goto L_01A92F;
    case 0x01A931u: goto L_01A931;
    case 0x01A935u: goto L_01A935;
    case 0x01A938u: goto L_01A938;
    case 0x01A93Cu: goto L_01A93C;
    case 0x01A93Fu: goto L_01A93F;
    case 0x01A941u: goto L_01A941;
    case 0x01A944u: goto L_01A944;
    case 0x01A947u: goto L_01A947;
    case 0x01A94Au: goto L_01A94A;
    case 0x01A94Du: goto L_01A94D;
    case 0x01A94Fu: goto L_01A94F;
    case 0x01A952u: goto L_01A952;
    case 0x01A954u: goto L_01A954;
    case 0x01A956u: goto L_01A956;
    case 0x01A958u: goto L_01A958;
    case 0x01A95Au: goto L_01A95A;
    case 0x01A95Cu: goto L_01A95C;
    case 0x01A95Du: goto L_01A95D;
    case 0x01A960u: goto L_01A960;
    case 0x01A962u: goto L_01A962;
    case 0x01A965u: goto L_01A965;
    case 0x01A967u: goto L_01A967;
    case 0x01A969u: goto L_01A969;
    case 0x01A96Bu: goto L_01A96B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01A7F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7F5 CLC
    cpu.setFlag('C', false);
    goto L_01A7F6;
L_01A7F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A7F6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A7F6u);return;} hw.unresolvedReturn(0x01A7F6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01A7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F7u, 6u, 3u, cpu.address("abs", 0xAD30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A7F7 JSR -> $01AD30 stack real
    { cpu.push16Value(hw,0xA7F9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA7FAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD30u), 0x01A7F7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A7FA;
L_01A7FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA7FAu,0x01A7FAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7FA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A7FC;
L_01A7FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7FC CLC
    cpu.setFlag('C', false);
    goto L_01A7FD;
L_01A7FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7FD ADC
    cpu.adc(0x50u);
    goto L_01A7FF;
L_01A7FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7FF CMP
    cpu.compareA(0xA0u);
    goto L_01A801;
L_01A801:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA801u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA801u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA801u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A801 BCS -> $01A7F5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_01A7F5; }
    goto L_01A803;
L_01A803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA803u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA803u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA803u, 6u, 3u, cpu.address("abs", 0xAD42u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A803 JSR -> $01AD42 stack real
    { cpu.push16Value(hw,0xA805u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA806u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD42u), 0x01A803u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A806;
L_01A806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA806u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA806u,0x01A806u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA806u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA806u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A806 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A808;
L_01A808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA808u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA808u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A808 CLC
    cpu.setFlag('C', false);
    goto L_01A809;
L_01A809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA809u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA809u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A809 ADC
    cpu.adc(0x60u);
    goto L_01A80B;
L_01A80B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA80Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A80B CMP
    cpu.compareA(0xC0u);
    goto L_01A80D;
L_01A80D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA80Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A80D BCS -> $01A7F5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_01A7F5; }
    goto L_01A80F;
L_01A80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA80Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A80F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x71u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A811;
L_01A811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA811u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA811u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A811 CMP
    cpu.compareA(0x1u);
    goto L_01A813;
L_01A813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA813u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA813u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A813 BCS -> $01A7F5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_01A7F5; }
    goto L_01A815;
L_01A815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA815u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA815u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A815 LDA
    cpu.setA(0x0u, 8);
    goto L_01A817;
L_01A817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA817u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA817u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA817u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A817 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), false);
    goto L_01A81A;
L_01A81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA81Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Au,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A81A BVS -> $01A822
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_01A822; }
    goto L_01A81C;
L_01A81C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA81Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Cu, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A81C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13F9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A81F;
L_01A81F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA81Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Fu,cpu,0x5Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA81Fu, 4u + ((((0x1632u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1632u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A81F EOR
    cpu.logicXor(hw.readW(cpu.address("absx", 0x1632u), cpu.m8?8:16));
    goto L_01A822;
L_01A822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA822u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA822u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A822 BNE -> $01A87C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A87C; }
    goto L_01A824;
L_01A824:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA824u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA824u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA824u, 8u, 4u, 0x03B664u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01A824 JSL -> $03B664 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA827u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA828u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x03B664u, 0x01A824u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A828;
L_01A828:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA828u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA828u,0x01A828u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA828u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA828u, 8u, 4u, 0x03B69Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01A828 JSL -> $03B69F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA82Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA82Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x03B69Fu, 0x01A828u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A82C;
L_01A82C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA82Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA82Cu,0x01A82Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Cu, 8u, 4u, 0x03B72Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01A82C JSL -> $03B72B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA82Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA830u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x03B72Bu, 0x01A82Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A830;
L_01A830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA830u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA830u,0x01A830u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA830u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA830u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A830 BCC -> $01A87C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01A87C; }
    goto L_01A832;
L_01A832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA832u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA832u, 4u + ((((0x167Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x167Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A832 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x167Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A835;
L_01A835:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA835u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA835u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA835u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A835 BPL -> $01A83B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01A83B; }
    goto L_01A837;
L_01A837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA837u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA837u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A837 SEC
    cpu.setFlag('C', true);
    goto L_01A838;
L_01A838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA838u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA838u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A838 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A838u);return;} hw.unresolvedReturn(0x01A838u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01A83B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA83Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Bu, 4u, 3u, cpu.address("abs", 0x1490u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A83B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1490u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A83E;
L_01A83E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA83Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A83E BEQ -> $01A87E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A87E; }
    goto L_01A840;
L_01A840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA840u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA840u, 4u + ((((0x167Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x167Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A840 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x167Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A843;
L_01A843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA843u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA843u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A843 AND
    cpu.logicAnd(0x2u);
    goto L_01A845;
L_01A845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA845u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA845u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A845 BNE -> $01A87E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A87E; }
    goto L_01A847;
L_01A847:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA847u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA847u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA847u, 8u, 4u, 0x01AB6Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01A847 JSL -> $01AB6F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA84Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA84Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB6Fu, 0x01A847u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A84B;
L_01A84B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA84Bu,0x01A84Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Bu, 6u, 3u, cpu.address("abs", 0x18D2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A84B INC
    cpu.incMem(hw, cpu.address("abs", 0x18D2u), cpu.m8?8:16);
    goto L_01A84E;
L_01A84E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Eu, 4u, 3u, cpu.address("abs", 0x18D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A84E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18D2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A851;
L_01A851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA851u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA851u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A851 CMP
    cpu.compareA(0x8u);
    goto L_01A853;
L_01A853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA853u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA853u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A853 BCC -> $01A85A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01A85A; }
    goto L_01A855;
L_01A855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A855 LDA
    cpu.setA(0x8u, 8);
    goto L_01A857;
L_01A857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA857u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA857u, 4u, 3u, cpu.address("abs", 0x18D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A857 STA
    hw.write(cpu.address("abs", 0x18D2u), cpu.a, cpu.m8?8:16);
    goto L_01A85A;
L_01A85A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Au, 8u, 4u, 0x02ACE5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01A85A JSL -> $02ACE5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA85Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA85Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACE5u, 0x01A85Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A85E;
L_01A85E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA85Eu,0x01A85Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Eu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Eu, 4u, 3u, cpu.address("abs", 0x18D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A85E LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x18D2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A861;
L_01A861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA861u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA861u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA861u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A861 CPY
    cpu.compareY(0x8u);
    goto L_01A863;
L_01A863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA863u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA863u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A863 BCS -> $01A86B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_01A86B; }
    goto L_01A865;
L_01A865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA865u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA865u, 4u + ((((0xA61Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA61Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A865 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA61Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A868;
L_01A868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA868u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA868u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A868 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_01A86B;
L_01A86B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A86B LDA
    cpu.setA(0x2u, 8);
    goto L_01A86D;
L_01A86D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Du, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A86D STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_01A870;
L_01A870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA870u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA870u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A870 LDA
    cpu.setA(0xD0u, 8);
    goto L_01A872;
L_01A872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA872u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA872u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A872 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_01A874;
L_01A874:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA874u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA874u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA874u, 6u, 3u, cpu.address("abs", 0xAD30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A874 JSR -> $01AD30 stack real
    { cpu.push16Value(hw,0xA876u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA877u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD30u), 0x01A874u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A877;
L_01A877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA877u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA877u,0x01A877u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA877u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA877u, 4u + ((((0xA839u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA839u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A877 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA839u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A87A;
L_01A87A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A87A STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_01A87C;
L_01A87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A87C CLC
    cpu.setFlag('C', false);
    goto L_01A87D;
L_01A87D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A87D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A87Du);return;} hw.unresolvedReturn(0x01A87Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01A87E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Eu, 4u, 3u, cpu.address("abs", 0x18D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A87E STZ
    hw.write(cpu.address("abs", 0x18D2u), 0, cpu.m8?8:16);
    goto L_01A881;
L_01A881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA881u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA881u, 4u + ((((0x154Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A881 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x154Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A884;
L_01A884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A884 BNE -> $01A895
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A895; }
    goto L_01A886;
L_01A886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA886u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA886u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA886u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A886 LDA
    cpu.setA(0x8u, 8);
    goto L_01A888;
L_01A888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA888u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA888u, 5u, 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A888 STA
    hw.write(cpu.address("absx", 0x154Cu), cpu.a, cpu.m8?8:16);
    goto L_01A88B;
L_01A88B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Bu, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A88B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A88E;
L_01A88E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A88E CMP
    cpu.compareA(0x9u);
    goto L_01A890;
L_01A890:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA890u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA890u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA890u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A890 BNE -> $01A897
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A897; }
    goto L_01A892;
L_01A892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA892u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA892u, 6u, 3u, cpu.address("abs", 0xAA42u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A892 JSR -> $01AA42 stack real
    { cpu.push16Value(hw,0xA894u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA895u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA42u), 0x01A892u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A895;
L_01A895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA895u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA895u,0x01A895u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA895u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA895u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A895 CLC
    cpu.setFlag('C', false);
    goto L_01A896;
L_01A896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA896u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA896u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A896 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A896u);return;} hw.unresolvedReturn(0x01A896u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01A897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A897 LDA
    cpu.setA(0x14u, 8);
    goto L_01A899;
L_01A899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA899u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA899u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A899 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_01A89B;
L_01A89B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A89B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A89D;
L_01A89D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A89D SEC
    cpu.setFlag('C', true);
    goto L_01A89E;
L_01A89E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Eu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A89E SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16));
    goto L_01A8A0;
L_01A8A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A0u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8A0 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_01A8A2;
L_01A8A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A2u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8A2 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xD3u), cpu.m8?8:16));
    goto L_01A8A4;
L_01A8A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A4u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A8A4 PHP
    cpu.push("PHP", hw);
    goto L_01A8A5;
L_01A8A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A5u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8A5 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_01A8A7;
L_01A8A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8A7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A8A9;
L_01A8A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A9u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8A9 SBC
    cpu.sbc(0x0u);
    goto L_01A8AB;
L_01A8AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ABu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ABu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A8AB PLP
    cpu.pop("PLP", hw);
    goto L_01A8AC;
L_01A8AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8ACu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8ACu,0x01A8ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ACu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8AC SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xD4u), cpu.m8?8:16));
    goto L_01A8AE;
L_01A8AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8AEu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8AE BMI -> $01A8E6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_01A8E6; }
    goto L_01A8B0;
L_01A8B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8B0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A8B2;
L_01A8B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8B2 BPL -> $01A8C0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01A8C0; }
    goto L_01A8B4;
L_01A8B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B4u, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8B4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A8B7;
L_01A8B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8B7 AND
    cpu.logicAnd(0x10u);
    goto L_01A8B9;
L_01A8B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8B9 BNE -> $01A8C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A8C0; }
    goto L_01A8BB;
L_01A8BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BBu, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8BB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1697u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A8BE;
L_01A8BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8BE BEQ -> $01A8E6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A8E6; }
    goto L_01A8C0;
L_01A8C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C0u, 6u, 3u, cpu.address("abs", 0x800Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A8C0 JSR -> $01800E stack real
    { cpu.push16Value(hw,0xA8C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8C3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x800Eu), 0x01A8C0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A8C3;
L_01A8C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8C3u,0x01A8C3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8C3 BEQ -> $01A8C9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A8C9; }
    goto L_01A8C5;
L_01A8C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8C5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A8C7;
L_01A8C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8C7 BEQ -> $01A8E6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A8E6; }
    goto L_01A8C9;
L_01A8C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C9u, 4u + ((((0x1656u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1656u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8C9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1656u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A8CC;
L_01A8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8CC AND
    cpu.logicAnd(0x10u);
    goto L_01A8CE;
L_01A8CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8CE BNE -> $01A91C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A91C; }
    goto L_01A8D0;
L_01A8D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D0u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8D0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x140Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A8D3;
L_01A8D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D3u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D3u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8D3 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16));
    goto L_01A8D6;
L_01A8D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8D6 BEQ -> $01A8E6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A8E6; }
    goto L_01A8D8;
L_01A8D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8D8 LDA
    cpu.setA(0x2u, 8);
    goto L_01A8DA;
L_01A8DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DAu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8DA STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_01A8DD;
L_01A8DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DDu, 8u, 4u, 0x01AA33u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01A8DD JSL -> $01AA33 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA8E0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8E1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AA33u, 0x01A8DDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A8E1;
L_01A8E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8E1u,0x01A8E1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E1u, 8u, 4u, 0x01AB99u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01A8E1 JSL -> $01AB99 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA8E4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8E5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB99u, 0x01A8E1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A8E5;
L_01A8E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8E5u,0x01A8E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A8E5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A8E5u);return;} hw.unresolvedReturn(0x01A8E5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01A8E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E6u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8E6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13EDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A8E9;
L_01A8E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8E9 BEQ -> $01A8F9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A8F9; }
    goto L_01A8EB;
L_01A8EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EBu, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8EB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A8EE;
L_01A8EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8EE AND
    cpu.logicAnd(0x4u);
    goto L_01A8F0;
L_01A8F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8F0 BNE -> $01A8F9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A8F9; }
    goto L_01A8F2;
L_01A8F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u, 6u, 3u, cpu.address("abs", 0xA728u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A8F2 JSR -> $01A728 stack real
    { cpu.push16Value(hw,0xA8F4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8F5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA728u), 0x01A8F2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A8F5;
L_01A8F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8F5u,0x01A8F5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F5u, 6u, 3u, cpu.address("abs", 0xA847u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A8F5 JSR -> $01A847 stack real
    { cpu.push16Value(hw,0xA8F7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8F8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA847u), 0x01A8F5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A8F8;
L_01A8F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8F8u,0x01A8F8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A8F8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A8F8u);return;} hw.unresolvedReturn(0x01A8F8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01A8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u, 4u, 3u, cpu.address("abs", 0x1497u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8F9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1497u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A8FC;
L_01A8FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8FC BNE -> $01A91B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A91B; }
    goto L_01A8FE;
L_01A8FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FEu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A8FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A901;
L_01A901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA901u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA901u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A901 BNE -> $01A91B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A91B; }
    goto L_01A903;
L_01A903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u, 4u + ((((0x1686u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A903 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1686u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A906;
L_01A906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA906u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA906u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A906 AND
    cpu.logicAnd(0x10u);
    goto L_01A908;
L_01A908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A908 BNE -> $01A911
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A911; }
    goto L_01A90A;
L_01A90A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Au, 6u, 3u, cpu.address("abs", 0xAD30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A90A JSR -> $01AD30 stack real
    { cpu.push16Value(hw,0xA90Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA90Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD30u), 0x01A90Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A90D;
L_01A90D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA90Du,0x01A90Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A90D TYA
    cpu.transfer("TYA");
    goto L_01A90E;
L_01A90E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A90E STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_01A911;
L_01A911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA911u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA911u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A911 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A913;
L_01A913:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA913u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA913u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA913u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A913 CMP
    cpu.compareA(0x53u);
    goto L_01A915;
L_01A915:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA915u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA915u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA915u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A915 BEQ -> $01A91B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A91B; }
    goto L_01A917;
L_01A917:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA917u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA917u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA917u, 8u, 4u, 0x00F5B7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01A917 JSL -> $00F5B7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA91Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA91Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F5B7u, 0x01A917u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A91B;
L_01A91B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA91Bu,0x01A91Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A91B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A91Bu);return;} hw.unresolvedReturn(0x01A91Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01A91C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Cu, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A91C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x140Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A91F;
L_01A91F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Fu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Fu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A91F ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16));
    goto L_01A922;
L_01A922:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA922u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA922u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA922u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A922 BEQ -> $01A947
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A947; }
    goto L_01A924;
L_01A924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA924u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA924u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA924u, 8u, 4u, 0x01AB99u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01A924 JSL -> $01AB99 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA927u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA928u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB99u, 0x01A924u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A928;
L_01A928:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA928u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA928u,0x01A928u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA928u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA928u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A928 LDA
    cpu.setA(0xF8u, 8);
    goto L_01A92A;
L_01A92A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA92Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A92A STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_01A92C;
L_01A92C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA92Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Cu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A92C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A92F;
L_01A92F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA92Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A92F BEQ -> $01A935
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A935; }
    goto L_01A931;
L_01A931:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA931u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA931u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA931u, 8u, 4u, 0x01AA33u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01A931 JSL -> $01AA33 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA934u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA935u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AA33u, 0x01A931u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A935;
L_01A935:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA935u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA935u,0x01A935u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA935u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA935u, 6u, 3u, cpu.address("abs", 0x9ACBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A935 JSR -> $019ACB stack real
    { cpu.push16Value(hw,0xA937u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA938u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9ACBu), 0x01A935u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A938;
L_01A938:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA938u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA938u,0x01A938u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA938u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA938u, 8u, 4u, 0x07FC3Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01A938 JSL -> $07FC3B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA93Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA93Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07FC3Bu, 0x01A938u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A93C;
L_01A93C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA93Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA93Cu,0x01A93Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Cu, 6u, 3u, cpu.address("abs", 0xAB46u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A93C JSR -> $01AB46 stack real
    { cpu.push16Value(hw,0xA93Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA93Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAB46u), 0x01A93Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A93F;
L_01A93F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA93Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA93Fu,0x01A93Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A93F LDA
    cpu.setA(0x8u, 8);
    goto L_01A941;
L_01A941:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA941u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA941u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA941u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A941 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_01A944;
L_01A944:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA944u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA944u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA944u, 3u, 3u, cpu.address("abs", 0xA9F2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A944 JMP -> $01A9F2
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xA9F2u),0x01A944u); return;
L_01A947:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA947u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA947u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA947u, 6u, 3u, cpu.address("abs", 0xA8D8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A947 JSR -> $01A8D8 stack real
    { cpu.push16Value(hw,0xA949u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA94Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA8D8u), 0x01A947u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A94A;
L_01A94A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA94Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA94Au,0x01A94Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Au, 4u + ((((0x187Bu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x187Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A94A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x187Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A94D;
L_01A94D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA94Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A94D BEQ -> $01A95D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A95D; }
    goto L_01A94F;
L_01A94F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA94Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Fu, 6u, 3u, cpu.address("abs", 0xAD30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A94F JSR -> $01AD30 stack real
    { cpu.push16Value(hw,0xA951u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA952u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD30u), 0x01A94Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A952;
L_01A952:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA952u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA952u,0x01A952u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA952u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA952u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A952 LDA
    cpu.setA(0x18u, 8);
    goto L_01A954;
L_01A954:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA954u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA954u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA954u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A954 CPY
    cpu.compareY(0x0u);
    goto L_01A956;
L_01A956:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA956u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA956u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA956u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A956 BEQ -> $01A95A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A95A; }
    goto L_01A958;
L_01A958:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA958u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA958u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA958u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A958 LDA
    cpu.setA(0xE8u, 8);
    goto L_01A95A;
L_01A95A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A95A STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_01A95C;
L_01A95C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A95C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A95Cu);return;} hw.unresolvedReturn(0x01A95Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01A95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Du, 6u, 3u, cpu.address("abs", 0xAB46u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A95D JSR -> $01AB46 stack real
    { cpu.push16Value(hw,0xA95Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA960u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAB46u), 0x01A95Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A960;
L_01A960:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA960u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA960u,0x01A960u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA960u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA960u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A960 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A962;
L_01A962:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA962u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA962u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA962u, 4u + ((((0x1686u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A962 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1686u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A965;
L_01A965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA965u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA965u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A965 AND
    cpu.logicAnd(0x40u);
    goto L_01A967;
L_01A967:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA967u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA967u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA967u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A967 BEQ -> $01A9BE
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x01A9BEu,0x01A967u); return; }
    goto L_01A969;
L_01A969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA969u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA969u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA969u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A969 CPY
    cpu.compareY(0x72u);
    goto L_01A96B;
L_01A96B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA96Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA96Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A96B BCC -> $01A979
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x01A979u,0x01A96Bu); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA96Du,0x01A96Bu); return;
}

void sub_01AD6E_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01AD6Eu: goto L_01AD6E;
    case 0x01AD71u: goto L_01AD71;
    case 0x01AD73u: goto L_01AD73;
    case 0x01AD76u: goto L_01AD76;
    case 0x01AD79u: goto L_01AD79;
    case 0x01AD7Bu: goto L_01AD7B;
    case 0x01AD7Du: goto L_01AD7D;
    case 0x01AD80u: goto L_01AD80;
    case 0x01AD83u: goto L_01AD83;
    case 0x01AD86u: goto L_01AD86;
    case 0x01AD89u: goto L_01AD89;
    case 0x01AD8Au: goto L_01AD8A;
    case 0x01AD8Du: goto L_01AD8D;
    case 0x01AD90u: goto L_01AD90;
    case 0x01AD92u: goto L_01AD92;
    case 0x01AD94u: goto L_01AD94;
    case 0x01AD97u: goto L_01AD97;
    case 0x01AD99u: goto L_01AD99;
    case 0x01AD9Bu: goto L_01AD9B;
    case 0x01AD9Du: goto L_01AD9D;
    case 0x01AD9Fu: goto L_01AD9F;
    case 0x01ADA1u: goto L_01ADA1;
    case 0x01ADA4u: goto L_01ADA4;
    case 0x01ADA6u: goto L_01ADA6;
    case 0x01ADA7u: goto L_01ADA7;
    case 0x01ADA9u: goto L_01ADA9;
    case 0x01ADAAu: goto L_01ADAA;
    case 0x01ADADu: goto L_01ADAD;
    case 0x01ADAFu: goto L_01ADAF;
    case 0x01ADB2u: goto L_01ADB2;
    case 0x01ADB4u: goto L_01ADB4;
    case 0x01ADB7u: goto L_01ADB7;
    case 0x01ADBAu: goto L_01ADBA;
    case 0x01ADBCu: goto L_01ADBC;
    case 0x01ADBEu: goto L_01ADBE;
    case 0x01ADC0u: goto L_01ADC0;
    case 0x01ADC3u: goto L_01ADC3;
    case 0x01ADC5u: goto L_01ADC5;
    case 0x01ADC7u: goto L_01ADC7;
    case 0x01ADC9u: goto L_01ADC9;
    case 0x01ADCBu: goto L_01ADCB;
    case 0x01ADCEu: goto L_01ADCE;
    case 0x01ADD0u: goto L_01ADD0;
    case 0x01ADD1u: goto L_01ADD1;
    case 0x01ADD3u: goto L_01ADD3;
    case 0x01ADD4u: goto L_01ADD4;
    case 0x01ADD7u: goto L_01ADD7;
    case 0x01ADD9u: goto L_01ADD9;
    case 0x01ADDCu: goto L_01ADDC;
    case 0x01ADDEu: goto L_01ADDE;
    case 0x01ADE1u: goto L_01ADE1;
    case 0x01ADE3u: goto L_01ADE3;
    case 0x01ADE6u: goto L_01ADE6;
    case 0x01ADE8u: goto L_01ADE8;
    case 0x01ADEAu: goto L_01ADEA;
    case 0x01ADECu: goto L_01ADEC;
    case 0x01ADEFu: goto L_01ADEF;
    case 0x01ADF2u: goto L_01ADF2;
    case 0x01ADF5u: goto L_01ADF5;
    case 0x01ADF8u: goto L_01ADF8;
    case 0x01ADFBu: goto L_01ADFB;
    case 0x01ADFEu: goto L_01ADFE;
    case 0x01AE01u: goto L_01AE01;
    case 0x01AE04u: goto L_01AE04;
    case 0x01AE06u: goto L_01AE06;
    case 0x01AE08u: goto L_01AE08;
    case 0x01AE0Au: goto L_01AE0A;
    case 0x01AE0Cu: goto L_01AE0C;
    case 0x01AE0Eu: goto L_01AE0E;
    case 0x01AE0Fu: goto L_01AE0F;
    case 0x01AE11u: goto L_01AE11;
    case 0x01AE13u: goto L_01AE13;
    case 0x01AE16u: goto L_01AE16;
    case 0x01AE18u: goto L_01AE18;
    case 0x01AE1Au: goto L_01AE1A;
    case 0x01AE1Du: goto L_01AE1D;
    case 0x01AE1Fu: goto L_01AE1F;
    case 0x01AE21u: goto L_01AE21;
    case 0x01AE23u: goto L_01AE23;
    case 0x01AE26u: goto L_01AE26;
    case 0x01AE28u: goto L_01AE28;
    case 0x01AE2Au: goto L_01AE2A;
    case 0x01AE2Du: goto L_01AE2D;
    case 0x01AE30u: goto L_01AE30;
    case 0x01AE32u: goto L_01AE32;
    case 0x01AE34u: goto L_01AE34;
    case 0x01AE35u: goto L_01AE35;
    case 0x01AE36u: goto L_01AE36;
    case 0x01AE37u: goto L_01AE37;
    case 0x01AE38u: goto L_01AE38;
    case 0x01AE3Bu: goto L_01AE3B;
    case 0x01AE3Du: goto L_01AE3D;
    case 0x01AE3Eu: goto L_01AE3E;
    case 0x01AE40u: goto L_01AE40;
    case 0x01AE41u: goto L_01AE41;
    case 0x01AE42u: goto L_01AE42;
    case 0x01AE43u: goto L_01AE43;
    case 0x01AE47u: goto L_01AE47;
    case 0x01AE48u: goto L_01AE48;
    case 0x01AE4Bu: goto L_01AE4B;
    case 0x01AE4Du: goto L_01AE4D;
    case 0x01AE50u: goto L_01AE50;
    case 0x01AE53u: goto L_01AE53;
    case 0x01AE55u: goto L_01AE55;
    case 0x01AE57u: goto L_01AE57;
    case 0x01AE59u: goto L_01AE59;
    case 0x01AE5Cu: goto L_01AE5C;
    case 0x01AE5Du: goto L_01AE5D;
    case 0x01AE5Eu: goto L_01AE5E;
    case 0x01AE5Fu: goto L_01AE5F;
    case 0x01AE60u: goto L_01AE60;
    case 0x01AE63u: goto L_01AE63;
    case 0x01AE65u: goto L_01AE65;
    case 0x01AE68u: goto L_01AE68;
    case 0x01AE6Bu: goto L_01AE6B;
    case 0x01AE6Cu: goto L_01AE6C;
    case 0x01AE6Eu: goto L_01AE6E;
    case 0x01AE71u: goto L_01AE71;
    case 0x01AE73u: goto L_01AE73;
    case 0x01AE75u: goto L_01AE75;
    case 0x01AE77u: goto L_01AE77;
    case 0x01AE79u: goto L_01AE79;
    case 0x01AE7Bu: goto L_01AE7B;
    case 0x01AE7Eu: goto L_01AE7E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01AD6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Eu, 4u + ((((0x163Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x163Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD6E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x163Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AD71;
L_01AD71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD71u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD71u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD71 BEQ -> $01AD80
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AD80; }
    goto L_01AD73;
L_01AD73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD73u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD73u, 5u, 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD73 STZ
    hw.write(cpu.address("absx", 0x15EAu), 0, cpu.m8?8:16);
    goto L_01AD76;
L_01AD76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD76u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD76u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD76 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AD79;
L_01AD79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD79u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD79 BNE -> $01AD80
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AD80; }
    goto L_01AD7B;
L_01AD7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD7B LDA
    cpu.setA(0x4u, 8);
    goto L_01AD7D;
L_01AD7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Du, 5u, 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD7D STA
    hw.write(cpu.address("absx", 0x15EAu), cpu.a, cpu.m8?8:16);
    goto L_01AD80;
L_01AD80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD80u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD80u, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01AD80 JSR -> $019F0D stack real
    { cpu.push16Value(hw,0xAD82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD83u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0x01AD80u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01AD83;
L_01AD83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD83u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD83u,0x01AD83u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD83u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD83u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD83 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01AD86;
L_01AD86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u, 4u + ((((0x0301u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD86 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x301u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AD89;
L_01AD89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD89u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD89 DEC
    cpu.decReg('A');
    goto L_01AD8A;
L_01AD8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Au, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD8A STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_01AD8D;
L_01AD8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Du, 5u, 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD8D STZ
    hw.write(cpu.address("absx", 0x1528u), 0, cpu.m8?8:16);
    goto L_01AD90;
L_01AD90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD90u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD90u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD90 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AD92;
L_01AD92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD92u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD92 BNE -> $01ADF8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ADF8; }
    goto L_01AD94;
L_01AD94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD94u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD94u, 6u, 3u, cpu.address("abs", 0x9E95u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01AD94 JSR -> $019E95 stack real
    { cpu.push16Value(hw,0xAD96u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD97u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E95u), 0x01AD94u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01AD97;
L_01AD97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD97u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD97u,0x01AD97u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD97u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD97u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD97 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AD99;
L_01AD99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD99u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD99 BNE -> $01ADF8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ADF8; }
    goto L_01AD9B;
L_01AD9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD9B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AD9D;
L_01AD9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD9D AND
    cpu.logicAnd(0x1u);
    goto L_01AD9F;
L_01AD9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD9F BNE -> $01ADB7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ADB7; }
    goto L_01ADA1;
L_01ADA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA1u, 4u + ((((0x1594u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1594u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADA1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1594u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADA4;
L_01ADA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADA4 AND
    cpu.logicAnd(0x1u);
    goto L_01ADA6;
L_01ADA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADA6 TAY
    cpu.transfer("TAY");
    goto L_01ADA7;
L_01ADA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADA7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADA9;
L_01ADA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADA9 CLC
    cpu.setFlag('C', false);
    goto L_01ADAA;
L_01ADAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADAAu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADAAu, 4u + ((((0xAD68u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xAD68u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADAA ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xAD68u), cpu.m8?8:16));
    goto L_01ADAD;
L_01ADAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADADu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADAD STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_01ADAF;
L_01ADAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADAFu,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADAFu, 4u + ((((0xAD6Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xAD6Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADAF CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xAD6Au), cpu.m8?8:16));
    goto L_01ADB2;
L_01ADB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADB2 BNE -> $01ADB7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ADB7; }
    goto L_01ADB4;
L_01ADB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB4u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB4u, 7u, 3u, cpu.address("absx", 0x1594u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADB4 INC
    cpu.incMem(hw, cpu.address("absx", 0x1594u), cpu.m8?8:16);
    goto L_01ADB7;
L_01ADB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB7u, 6u, 3u, cpu.address("abs", 0xABD8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ADB7 JSR -> $01ABD8 stack real
    { cpu.push16Value(hw,0xADB9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADBAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABD8u), 0x01ADB7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01ADBA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB7u, 6u, 3u, cpu.address("abs", 0xABD8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ADB7 JSR -> $01ABD8 stack real
    { cpu.push16Value(hw,0xADB9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADBAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABD8u), 0x01ADB7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01ADBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADB7u,0x01ADB7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01ADBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADBA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADBC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADBA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADBC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADBAu,0x01ADBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01ADBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADBC CMP
    cpu.compareA(0x83u);
    goto L_01ADBE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADBC CMP
    cpu.compareA(0x83u);
    goto L_01ADBE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADBCu,0x01ADBCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01ADBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADBE BEQ -> $01ADE8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ADE8; }
    goto L_01ADC0;
L_01ADC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC0u, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADC0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADC3;
L_01ADC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADC3 BNE -> $01ADE6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ADE6; }
    goto L_01ADC5;
L_01ADC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADC5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADC7;
L_01ADC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADC7 AND
    cpu.logicAnd(0x3u);
    goto L_01ADC9;
L_01ADC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADC9 BNE -> $01ADE6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ADE6; }
    goto L_01ADCB;
L_01ADCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCBu, 4u + ((((0x1534u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADCB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1534u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADCE;
L_01ADCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADCE AND
    cpu.logicAnd(0x1u);
    goto L_01ADD0;
L_01ADD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADD0 TAY
    cpu.transfer("TAY");
    goto L_01ADD1;
L_01ADD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD1u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADD1 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADD3;
L_01ADD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADD3 CLC
    cpu.setFlag('C', false);
    goto L_01ADD4;
L_01ADD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD4u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD4u, 4u + ((((0xAD68u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xAD68u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADD4 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xAD68u), cpu.m8?8:16));
    goto L_01ADD7;
L_01ADD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADD7 STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_01ADD9;
L_01ADD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD9u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD9u, 4u + ((((0xAD6Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xAD6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADD9 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xAD6Cu), cpu.m8?8:16));
    goto L_01ADDC;
L_01ADDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADDC BNE -> $01ADE6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ADE6; }
    goto L_01ADDE;
L_01ADDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDEu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDEu, 7u, 3u, cpu.address("absx", 0x1534u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADDE INC
    cpu.incMem(hw, cpu.address("absx", 0x1534u), cpu.m8?8:16);
    goto L_01ADE1;
L_01ADE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADE1 LDA
    cpu.setA(0x20u, 8);
    goto L_01ADE3;
L_01ADE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE3u, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADE3 STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_01ADE6;
L_01ADE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADE6 BRA -> $01ADEC
    goto L_01ADEC;
L_01ADE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADE8 LDA
    cpu.setA(0xF4u, 8);
    goto L_01ADEA;
L_01ADEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADEAu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADEAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADEA STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_01ADEC;
L_01ADEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADECu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADECu, 6u, 3u, cpu.address("abs", 0xABCCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ADEC JSR -> $01ABCC stack real
    { cpu.push16Value(hw,0xADEEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADEFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABCCu), 0x01ADECu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01ADEF;
L_01ADEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADEFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADEFu,0x01ADEFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADEFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADEFu, 4u, 3u, cpu.address("abs", 0x1491u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADEF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1491u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADF2;
L_01ADF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF2u, 5u, 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADF2 STA
    hw.write(cpu.address("absx", 0x1528u), cpu.a, cpu.m8?8:16);
    goto L_01ADF5;
L_01ADF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF5u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF5u, 7u, 3u, cpu.address("absx", 0x1570u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADF5 INC
    cpu.incMem(hw, cpu.address("absx", 0x1570u), cpu.m8?8:16);
    goto L_01ADF8;
L_01ADF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF8u, 6u, 3u, cpu.address("abs", 0xA40Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ADF8 JSR -> $01A40D stack real
    { cpu.push16Value(hw,0xADFAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADFBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA40Du), 0x01ADF8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01ADFB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF8u, 6u, 3u, cpu.address("abs", 0xA40Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ADF8 JSR -> $01A40D stack real
    { cpu.push16Value(hw,0xADFAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADFBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA40Du), 0x01ADF8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01ADFB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADF8u,0x01ADF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01ADFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFBu, 6u, 3u, cpu.address("abs", 0xB457u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ADFB JSR -> $01B457 stack real
    { cpu.push16Value(hw,0xADFDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADFEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB457u), 0x01ADFBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01ADFE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFBu, 6u, 3u, cpu.address("abs", 0xB457u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ADFB JSR -> $01B457 stack real
    { cpu.push16Value(hw,0xADFDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADFEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB457u), 0x01ADFBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01ADFE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADFBu,0x01ADFBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01ADFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFEu, 6u, 3u, cpu.address("abs", 0xAC31u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ADFE JSR -> $01AC31 stack real
    { cpu.push16Value(hw,0xAE00u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE01u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC31u), 0x01ADFEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01AE01;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFEu, 6u, 3u, cpu.address("abs", 0xAC31u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ADFE JSR -> $01AC31 stack real
    { cpu.push16Value(hw,0xAE00u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE01u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC31u), 0x01ADFEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01AE01;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADFEu,0x01ADFEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01AE01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE01u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE01u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE01u, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE01 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE04;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE01u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE01u, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE01 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE04;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE01u,0x01AE01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01AE04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE04u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE04u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE04 CMP
    cpu.compareA(0x8u);
    goto L_01AE06;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE04u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE04 CMP
    cpu.compareA(0x8u);
    goto L_01AE06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE04u,0x01AE04u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01AE06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE06u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE06 BNE -> $01AE5E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AE5E; }
    goto L_01AE08;
L_01AE08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE08u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE08u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE08 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0xC2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01AE0A;
L_01AE0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Au,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE0A CPY
    cpu.compareY(0x2u);
    goto L_01AE0C;
L_01AE0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE0C BEQ -> $01AE5E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AE5E; }
    goto L_01AE0E;
L_01AE0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Eu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AE0E PHA
    cpu.push("PHA", hw);
    goto L_01AE0F;
L_01AE0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Fu,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE0F INC
    cpu.incMem(hw, cpu.address("dpx", 0xC2u), cpu.m8?8:16);
    goto L_01AE11;
L_01AE11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE11u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE11 LDA
    cpu.setA(0x50u, 8);
    goto L_01AE13;
L_01AE13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE13u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE13u, 5u, 3u, cpu.address("absx", 0x163Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE13 STA
    hw.write(cpu.address("absx", 0x163Eu), cpu.a, cpu.m8?8:16);
    goto L_01AE16;
L_01AE16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE16u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE16 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE18;
L_01AE18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE18u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE18u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE18 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_01AE1A;
L_01AE1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Au, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE1A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE1D;
L_01AE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE1D STA
    hw.write(cpu.address("dp", 0x9Bu), cpu.a, cpu.m8?8:16);
    goto L_01AE1F;
L_01AE1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE1F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE21;
L_01AE21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE21u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE21u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE21 STA
    hw.write(cpu.address("dp", 0x98u), cpu.a, cpu.m8?8:16);
    goto L_01AE23;
L_01AE23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE23 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE26;
L_01AE26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE26 STA
    hw.write(cpu.address("dp", 0x99u), cpu.a, cpu.m8?8:16);
    goto L_01AE28;
L_01AE28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE28u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE28 LDA
    cpu.setA(0xFFu, 8);
    goto L_01AE2A;
L_01AE2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Au, 5u, 3u, cpu.address("absx", 0x161Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE2A STA
    hw.write(cpu.address("absx", 0x161Au), cpu.a, cpu.m8?8:16);
    goto L_01AE2D;
L_01AE2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Du,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Du, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE2D LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x151Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01AE30;
L_01AE30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE30u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE30u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE30 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE32;
L_01AE32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE32u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE32 BNE -> $01AE38
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AE38; }
    goto L_01AE34;
L_01AE34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE34u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE34 INY
    cpu.inc('Y');
    goto L_01AE35;
L_01AE35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE35u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE35 INY
    cpu.inc('Y');
    goto L_01AE36;
L_01AE36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE36u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE36u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE36 INY
    cpu.inc('Y');
    goto L_01AE37;
L_01AE37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE37u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE37u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE37 INY
    cpu.inc('Y');
    goto L_01AE38;
L_01AE38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE38u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE38u, 4u + ((((0xAE88u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xAE88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE38 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAE88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE3B;
L_01AE3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE3B STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_01AE3D;
L_01AE3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Du,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AE3D PHB
    cpu.push("PHB", hw);
    goto L_01AE3E;
L_01AE3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE3E LDA
    cpu.setA(0x2u, 8);
    goto L_01AE40;
L_01AE40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AE40 PHA
    cpu.push("PHA", hw);
    goto L_01AE41;
L_01AE41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE41u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE41u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AE41 PLB
    cpu.pop("PLB", hw);
    goto L_01AE42;
L_01AE42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE42u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE42u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AE42 PHX
    cpu.push("PHX", hw);
    goto L_01AE43;
L_01AE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u, 8u, 4u, 0x02887Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01AE43 JSL -> $02887D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE46u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE47u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02887Du, 0x01AE43u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01AE47;
L_01AE47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE47u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE47u,0x01AE47u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE47u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE47u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AE47 PLX
    cpu.pop("PLX", hw);
    goto L_01AE48;
L_01AE48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE48u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE48u, 4u, 3u, cpu.address("abs", 0x185Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE48 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x185Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01AE4B;
L_01AE4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE4B LDA
    cpu.setA(0x1u, 8);
    goto L_01AE4D;
L_01AE4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Du, 5u, 3u, cpu.address("absy", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE4D STA
    hw.write(cpu.address("absy", 0x1528u), cpu.a, cpu.m8?8:16);
    goto L_01AE50;
L_01AE50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE50u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE50u, 4u + ((((0x009Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x009Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE50 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE53;
L_01AE53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE53u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE53 CMP
    cpu.compareA(0x75u);
    goto L_01AE55;
L_01AE55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE55u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE55 BNE -> $01AE5C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AE5C; }
    goto L_01AE57;
L_01AE57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE57u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE57 LDA
    cpu.setA(0xFFu, 8);
    goto L_01AE59;
L_01AE59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE59u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE59u, 5u, 3u, cpu.address("absy", 0x00C2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE59 STA
    hw.write(cpu.address("absy", 0xC2u), cpu.a, cpu.m8?8:16);
    goto L_01AE5C;
L_01AE5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AE5C PLB
    cpu.pop("PLB", hw);
    goto L_01AE5D;
L_01AE5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Du,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AE5D PLA
    cpu.pop("PLA", hw);
    goto L_01AE5E;
L_01AE5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE5E LSR
    cpu.lsrA();
    goto L_01AE5F;
L_01AE5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE5F TAY
    cpu.transfer("TAY");
    goto L_01AE60;
L_01AE60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u, 4u + ((((0xAE7Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xAE7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE60 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAE7Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE63;
L_01AE63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE63u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE63u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE63 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_01AE65;
L_01AE65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE65u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE65u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE65 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01AE68;
L_01AE68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE68u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE68u, 4u + ((((0x0301u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE68 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x301u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE6B;
L_01AE6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE6B SEC
    cpu.setFlag('C', true);
    goto L_01AE6C;
L_01AE6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Cu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE6C SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_01AE6E;
L_01AE6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Eu, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE6E STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_01AE71;
L_01AE71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE71u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE71u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE71 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE73;
L_01AE73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE73u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE73u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE73 CMP
    cpu.compareA(0x1u);
    goto L_01AE75;
L_01AE75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE75u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE75 LDA
    cpu.setA(0x2Au, 8);
    goto L_01AE77;
L_01AE77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE77u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE77u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE77 BCC -> $01AE7B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01AE7B; }
    goto L_01AE79;
L_01AE79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE79u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE79 LDA
    cpu.setA(0x2Eu, 8);
    goto L_01AE7B;
L_01AE7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Bu, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE7B STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_01AE7E;
L_01AE7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01AE7E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01AE7Eu);return;} hw.unresolvedReturn(0x01AE7Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01AD6E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01AD6Eu: goto L_01AD6E;
    case 0x01AD71u: goto L_01AD71;
    case 0x01AD73u: goto L_01AD73;
    case 0x01AD76u: goto L_01AD76;
    case 0x01AD79u: goto L_01AD79;
    case 0x01AD7Bu: goto L_01AD7B;
    case 0x01AD7Du: goto L_01AD7D;
    case 0x01AD80u: goto L_01AD80;
    case 0x01AD83u: goto L_01AD83;
    case 0x01AD86u: goto L_01AD86;
    case 0x01AD89u: goto L_01AD89;
    case 0x01AD8Au: goto L_01AD8A;
    case 0x01AD8Du: goto L_01AD8D;
    case 0x01AD90u: goto L_01AD90;
    case 0x01AD92u: goto L_01AD92;
    case 0x01AD94u: goto L_01AD94;
    case 0x01AD97u: goto L_01AD97;
    case 0x01AD99u: goto L_01AD99;
    case 0x01AD9Bu: goto L_01AD9B;
    case 0x01AD9Du: goto L_01AD9D;
    case 0x01AD9Fu: goto L_01AD9F;
    case 0x01ADA1u: goto L_01ADA1;
    case 0x01ADA4u: goto L_01ADA4;
    case 0x01ADA6u: goto L_01ADA6;
    case 0x01ADA7u: goto L_01ADA7;
    case 0x01ADA9u: goto L_01ADA9;
    case 0x01ADAAu: goto L_01ADAA;
    case 0x01ADADu: goto L_01ADAD;
    case 0x01ADAFu: goto L_01ADAF;
    case 0x01ADB2u: goto L_01ADB2;
    case 0x01ADB4u: goto L_01ADB4;
    case 0x01ADB7u: goto L_01ADB7;
    case 0x01ADBAu: goto L_01ADBA;
    case 0x01ADBCu: goto L_01ADBC;
    case 0x01ADBEu: goto L_01ADBE;
    case 0x01ADC0u: goto L_01ADC0;
    case 0x01ADC3u: goto L_01ADC3;
    case 0x01ADC5u: goto L_01ADC5;
    case 0x01ADC7u: goto L_01ADC7;
    case 0x01ADC9u: goto L_01ADC9;
    case 0x01ADCBu: goto L_01ADCB;
    case 0x01ADCEu: goto L_01ADCE;
    case 0x01ADD0u: goto L_01ADD0;
    case 0x01ADD1u: goto L_01ADD1;
    case 0x01ADD3u: goto L_01ADD3;
    case 0x01ADD4u: goto L_01ADD4;
    case 0x01ADD7u: goto L_01ADD7;
    case 0x01ADD9u: goto L_01ADD9;
    case 0x01ADDCu: goto L_01ADDC;
    case 0x01ADDEu: goto L_01ADDE;
    case 0x01ADE1u: goto L_01ADE1;
    case 0x01ADE3u: goto L_01ADE3;
    case 0x01ADE6u: goto L_01ADE6;
    case 0x01ADE8u: goto L_01ADE8;
    case 0x01ADEAu: goto L_01ADEA;
    case 0x01ADECu: goto L_01ADEC;
    case 0x01ADEFu: goto L_01ADEF;
    case 0x01ADF2u: goto L_01ADF2;
    case 0x01ADF5u: goto L_01ADF5;
    case 0x01ADF8u: goto L_01ADF8;
    case 0x01ADFBu: goto L_01ADFB;
    case 0x01ADFEu: goto L_01ADFE;
    case 0x01AE01u: goto L_01AE01;
    case 0x01AE04u: goto L_01AE04;
    case 0x01AE06u: goto L_01AE06;
    case 0x01AE08u: goto L_01AE08;
    case 0x01AE0Au: goto L_01AE0A;
    case 0x01AE0Cu: goto L_01AE0C;
    case 0x01AE0Eu: goto L_01AE0E;
    case 0x01AE0Fu: goto L_01AE0F;
    case 0x01AE11u: goto L_01AE11;
    case 0x01AE13u: goto L_01AE13;
    case 0x01AE16u: goto L_01AE16;
    case 0x01AE18u: goto L_01AE18;
    case 0x01AE1Au: goto L_01AE1A;
    case 0x01AE1Du: goto L_01AE1D;
    case 0x01AE1Fu: goto L_01AE1F;
    case 0x01AE21u: goto L_01AE21;
    case 0x01AE23u: goto L_01AE23;
    case 0x01AE26u: goto L_01AE26;
    case 0x01AE28u: goto L_01AE28;
    case 0x01AE2Au: goto L_01AE2A;
    case 0x01AE2Du: goto L_01AE2D;
    case 0x01AE30u: goto L_01AE30;
    case 0x01AE32u: goto L_01AE32;
    case 0x01AE34u: goto L_01AE34;
    case 0x01AE35u: goto L_01AE35;
    case 0x01AE36u: goto L_01AE36;
    case 0x01AE37u: goto L_01AE37;
    case 0x01AE38u: goto L_01AE38;
    case 0x01AE3Bu: goto L_01AE3B;
    case 0x01AE3Du: goto L_01AE3D;
    case 0x01AE3Eu: goto L_01AE3E;
    case 0x01AE40u: goto L_01AE40;
    case 0x01AE41u: goto L_01AE41;
    case 0x01AE42u: goto L_01AE42;
    case 0x01AE43u: goto L_01AE43;
    case 0x01AE47u: goto L_01AE47;
    case 0x01AE48u: goto L_01AE48;
    case 0x01AE4Bu: goto L_01AE4B;
    case 0x01AE4Du: goto L_01AE4D;
    case 0x01AE50u: goto L_01AE50;
    case 0x01AE53u: goto L_01AE53;
    case 0x01AE55u: goto L_01AE55;
    case 0x01AE57u: goto L_01AE57;
    case 0x01AE59u: goto L_01AE59;
    case 0x01AE5Cu: goto L_01AE5C;
    case 0x01AE5Du: goto L_01AE5D;
    case 0x01AE5Eu: goto L_01AE5E;
    case 0x01AE5Fu: goto L_01AE5F;
    case 0x01AE60u: goto L_01AE60;
    case 0x01AE63u: goto L_01AE63;
    case 0x01AE65u: goto L_01AE65;
    case 0x01AE68u: goto L_01AE68;
    case 0x01AE6Bu: goto L_01AE6B;
    case 0x01AE6Cu: goto L_01AE6C;
    case 0x01AE6Eu: goto L_01AE6E;
    case 0x01AE71u: goto L_01AE71;
    case 0x01AE73u: goto L_01AE73;
    case 0x01AE75u: goto L_01AE75;
    case 0x01AE77u: goto L_01AE77;
    case 0x01AE79u: goto L_01AE79;
    case 0x01AE7Bu: goto L_01AE7B;
    case 0x01AE7Eu: goto L_01AE7E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01AD6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Eu, 4u + ((((0x163Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x163Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD6E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x163Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AD71;
L_01AD71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD71u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD71u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD71 BEQ -> $01AD80
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AD80; }
    goto L_01AD73;
L_01AD73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD73u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD73u, 5u, 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD73 STZ
    hw.write(cpu.address("absx", 0x15EAu), 0, cpu.m8?8:16);
    goto L_01AD76;
L_01AD76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD76u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD76u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD76 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AD79;
L_01AD79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD79u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD79 BNE -> $01AD80
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AD80; }
    goto L_01AD7B;
L_01AD7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD7B LDA
    cpu.setA(0x4u, 8);
    goto L_01AD7D;
L_01AD7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Du, 5u, 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD7D STA
    hw.write(cpu.address("absx", 0x15EAu), cpu.a, cpu.m8?8:16);
    goto L_01AD80;
L_01AD80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD80u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD80u, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01AD80 JSR -> $019F0D stack real
    { cpu.push16Value(hw,0xAD82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD83u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0x01AD80u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01AD83;
L_01AD83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD83u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD83u,0x01AD83u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD83u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD83u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD83 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01AD86;
L_01AD86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u, 4u + ((((0x0301u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD86 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x301u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AD89;
L_01AD89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD89u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD89 DEC
    cpu.decReg('A');
    goto L_01AD8A;
L_01AD8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Au, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD8A STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_01AD8D;
L_01AD8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Du, 5u, 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD8D STZ
    hw.write(cpu.address("absx", 0x1528u), 0, cpu.m8?8:16);
    goto L_01AD90;
L_01AD90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD90u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD90u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD90 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AD92;
L_01AD92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD92u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD92 BNE -> $01ADF8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ADF8; }
    goto L_01AD94;
L_01AD94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD94u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD94u, 6u, 3u, cpu.address("abs", 0x9E95u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01AD94 JSR -> $019E95 stack real
    { cpu.push16Value(hw,0xAD96u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD97u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E95u), 0x01AD94u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01AD97;
L_01AD97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD97u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD97u,0x01AD97u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD97u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD97u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD97 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AD99;
L_01AD99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD99u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD99 BNE -> $01ADF8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ADF8; }
    goto L_01AD9B;
L_01AD9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD9B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AD9D;
L_01AD9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD9D AND
    cpu.logicAnd(0x1u);
    goto L_01AD9F;
L_01AD9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AD9F BNE -> $01ADB7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ADB7; }
    goto L_01ADA1;
L_01ADA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA1u, 4u + ((((0x1594u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1594u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADA1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1594u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADA4;
L_01ADA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADA4 AND
    cpu.logicAnd(0x1u);
    goto L_01ADA6;
L_01ADA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADA6 TAY
    cpu.transfer("TAY");
    goto L_01ADA7;
L_01ADA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADA7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADA9;
L_01ADA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADA9 CLC
    cpu.setFlag('C', false);
    goto L_01ADAA;
L_01ADAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADAAu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADAAu, 4u + ((((0xAD68u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xAD68u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADAA ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xAD68u), cpu.m8?8:16));
    goto L_01ADAD;
L_01ADAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADADu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADAD STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_01ADAF;
L_01ADAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADAFu,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADAFu, 4u + ((((0xAD6Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xAD6Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADAF CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xAD6Au), cpu.m8?8:16));
    goto L_01ADB2;
L_01ADB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADB2 BNE -> $01ADB7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ADB7; }
    goto L_01ADB4;
L_01ADB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB4u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB4u, 7u, 3u, cpu.address("absx", 0x1594u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADB4 INC
    cpu.incMem(hw, cpu.address("absx", 0x1594u), cpu.m8?8:16);
    goto L_01ADB7;
L_01ADB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB7u, 6u, 3u, cpu.address("abs", 0xABD8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ADB7 JSR -> $01ABD8 stack real
    { cpu.push16Value(hw,0xADB9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADBAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABD8u), 0x01ADB7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01ADBA;
L_01ADBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADBAu,0x01ADBAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADBA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADBC;
L_01ADBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADBC CMP
    cpu.compareA(0x83u);
    goto L_01ADBE;
L_01ADBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADBE BEQ -> $01ADE8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ADE8; }
    goto L_01ADC0;
L_01ADC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC0u, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADC0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADC3;
L_01ADC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADC3 BNE -> $01ADE6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ADE6; }
    goto L_01ADC5;
L_01ADC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADC5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADC7;
L_01ADC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADC7 AND
    cpu.logicAnd(0x3u);
    goto L_01ADC9;
L_01ADC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADC9 BNE -> $01ADE6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ADE6; }
    goto L_01ADCB;
L_01ADCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCBu, 4u + ((((0x1534u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADCB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1534u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADCE;
L_01ADCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADCE AND
    cpu.logicAnd(0x1u);
    goto L_01ADD0;
L_01ADD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADD0 TAY
    cpu.transfer("TAY");
    goto L_01ADD1;
L_01ADD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD1u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADD1 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADD3;
L_01ADD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADD3 CLC
    cpu.setFlag('C', false);
    goto L_01ADD4;
L_01ADD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD4u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD4u, 4u + ((((0xAD68u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xAD68u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADD4 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xAD68u), cpu.m8?8:16));
    goto L_01ADD7;
L_01ADD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADD7 STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_01ADD9;
L_01ADD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD9u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD9u, 4u + ((((0xAD6Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xAD6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADD9 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xAD6Cu), cpu.m8?8:16));
    goto L_01ADDC;
L_01ADDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADDC BNE -> $01ADE6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ADE6; }
    goto L_01ADDE;
L_01ADDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDEu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDEu, 7u, 3u, cpu.address("absx", 0x1534u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADDE INC
    cpu.incMem(hw, cpu.address("absx", 0x1534u), cpu.m8?8:16);
    goto L_01ADE1;
L_01ADE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADE1 LDA
    cpu.setA(0x20u, 8);
    goto L_01ADE3;
L_01ADE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE3u, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADE3 STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_01ADE6;
L_01ADE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADE6 BRA -> $01ADEC
    goto L_01ADEC;
L_01ADE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADE8 LDA
    cpu.setA(0xF4u, 8);
    goto L_01ADEA;
L_01ADEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADEAu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADEAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADEA STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_01ADEC;
L_01ADEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADECu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADECu, 6u, 3u, cpu.address("abs", 0xABCCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ADEC JSR -> $01ABCC stack real
    { cpu.push16Value(hw,0xADEEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADEFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABCCu), 0x01ADECu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01ADEF;
L_01ADEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADEFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADEFu,0x01ADEFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADEFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADEFu, 4u, 3u, cpu.address("abs", 0x1491u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADEF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1491u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01ADF2;
L_01ADF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF2u, 5u, 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADF2 STA
    hw.write(cpu.address("absx", 0x1528u), cpu.a, cpu.m8?8:16);
    goto L_01ADF5;
L_01ADF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF5u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF5u, 7u, 3u, cpu.address("absx", 0x1570u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ADF5 INC
    cpu.incMem(hw, cpu.address("absx", 0x1570u), cpu.m8?8:16);
    goto L_01ADF8;
L_01ADF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF8u, 6u, 3u, cpu.address("abs", 0xA40Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ADF8 JSR -> $01A40D stack real
    { cpu.push16Value(hw,0xADFAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADFBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA40Du), 0x01ADF8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01ADFB;
L_01ADFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADFBu,0x01ADFBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFBu, 6u, 3u, cpu.address("abs", 0xB457u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ADFB JSR -> $01B457 stack real
    { cpu.push16Value(hw,0xADFDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADFEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB457u), 0x01ADFBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01ADFE;
L_01ADFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADFEu,0x01ADFEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFEu, 6u, 3u, cpu.address("abs", 0xAC31u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ADFE JSR -> $01AC31 stack real
    { cpu.push16Value(hw,0xAE00u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE01u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC31u), 0x01ADFEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01AE01;
L_01AE01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE01u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE01u,0x01AE01u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE01u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE01u, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE01 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE04;
L_01AE04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE04u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE04 CMP
    cpu.compareA(0x8u);
    goto L_01AE06;
L_01AE06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE06u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE06 BNE -> $01AE5E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AE5E; }
    goto L_01AE08;
L_01AE08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE08u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE08u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE08 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0xC2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01AE0A;
L_01AE0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Au,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE0A CPY
    cpu.compareY(0x2u);
    goto L_01AE0C;
L_01AE0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE0C BEQ -> $01AE5E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AE5E; }
    goto L_01AE0E;
L_01AE0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Eu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AE0E PHA
    cpu.push("PHA", hw);
    goto L_01AE0F;
L_01AE0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Fu,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE0F INC
    cpu.incMem(hw, cpu.address("dpx", 0xC2u), cpu.m8?8:16);
    goto L_01AE11;
L_01AE11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE11u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE11 LDA
    cpu.setA(0x50u, 8);
    goto L_01AE13;
L_01AE13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE13u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE13u, 5u, 3u, cpu.address("absx", 0x163Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE13 STA
    hw.write(cpu.address("absx", 0x163Eu), cpu.a, cpu.m8?8:16);
    goto L_01AE16;
L_01AE16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE16u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE16 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE18;
L_01AE18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE18u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE18u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE18 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_01AE1A;
L_01AE1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Au, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE1A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE1D;
L_01AE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE1D STA
    hw.write(cpu.address("dp", 0x9Bu), cpu.a, cpu.m8?8:16);
    goto L_01AE1F;
L_01AE1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE1F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE21;
L_01AE21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE21u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE21u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE21 STA
    hw.write(cpu.address("dp", 0x98u), cpu.a, cpu.m8?8:16);
    goto L_01AE23;
L_01AE23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE23 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE26;
L_01AE26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE26 STA
    hw.write(cpu.address("dp", 0x99u), cpu.a, cpu.m8?8:16);
    goto L_01AE28;
L_01AE28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE28u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE28 LDA
    cpu.setA(0xFFu, 8);
    goto L_01AE2A;
L_01AE2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Au, 5u, 3u, cpu.address("absx", 0x161Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE2A STA
    hw.write(cpu.address("absx", 0x161Au), cpu.a, cpu.m8?8:16);
    goto L_01AE2D;
L_01AE2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Du,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Du, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE2D LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x151Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01AE30;
L_01AE30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE30u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE30u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE30 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE32;
L_01AE32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE32u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE32 BNE -> $01AE38
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AE38; }
    goto L_01AE34;
L_01AE34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE34u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE34 INY
    cpu.inc('Y');
    goto L_01AE35;
L_01AE35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE35u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE35 INY
    cpu.inc('Y');
    goto L_01AE36;
L_01AE36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE36u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE36u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE36 INY
    cpu.inc('Y');
    goto L_01AE37;
L_01AE37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE37u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE37u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE37 INY
    cpu.inc('Y');
    goto L_01AE38;
L_01AE38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE38u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE38u, 4u + ((((0xAE88u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xAE88u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE38 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAE88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE3B;
L_01AE3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE3B STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_01AE3D;
L_01AE3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Du,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AE3D PHB
    cpu.push("PHB", hw);
    goto L_01AE3E;
L_01AE3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE3E LDA
    cpu.setA(0x2u, 8);
    goto L_01AE40;
L_01AE40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AE40 PHA
    cpu.push("PHA", hw);
    goto L_01AE41;
L_01AE41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE41u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE41u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AE41 PLB
    cpu.pop("PLB", hw);
    goto L_01AE42;
L_01AE42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE42u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE42u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AE42 PHX
    cpu.push("PHX", hw);
    goto L_01AE43;
L_01AE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u, 8u, 4u, 0x02887Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01AE43 JSL -> $02887D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE46u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE47u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02887Du, 0x01AE43u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01AE47;
L_01AE47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE47u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE47u,0x01AE47u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE47u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE47u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AE47 PLX
    cpu.pop("PLX", hw);
    goto L_01AE48;
L_01AE48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE48u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE48u, 4u, 3u, cpu.address("abs", 0x185Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE48 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x185Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01AE4B;
L_01AE4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE4B LDA
    cpu.setA(0x1u, 8);
    goto L_01AE4D;
L_01AE4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Du, 5u, 3u, cpu.address("absy", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE4D STA
    hw.write(cpu.address("absy", 0x1528u), cpu.a, cpu.m8?8:16);
    goto L_01AE50;
L_01AE50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE50u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE50u, 4u + ((((0x009Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x009Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE50 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE53;
L_01AE53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE53u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE53 CMP
    cpu.compareA(0x75u);
    goto L_01AE55;
L_01AE55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE55u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE55 BNE -> $01AE5C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AE5C; }
    goto L_01AE57;
L_01AE57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE57u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE57 LDA
    cpu.setA(0xFFu, 8);
    goto L_01AE59;
L_01AE59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE59u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE59u, 5u, 3u, cpu.address("absy", 0x00C2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE59 STA
    hw.write(cpu.address("absy", 0xC2u), cpu.a, cpu.m8?8:16);
    goto L_01AE5C;
L_01AE5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AE5C PLB
    cpu.pop("PLB", hw);
    goto L_01AE5D;
L_01AE5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Du,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01AE5D PLA
    cpu.pop("PLA", hw);
    goto L_01AE5E;
L_01AE5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE5E LSR
    cpu.lsrA();
    goto L_01AE5F;
L_01AE5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE5F TAY
    cpu.transfer("TAY");
    goto L_01AE60;
L_01AE60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u, 4u + ((((0xAE7Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xAE7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE60 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAE7Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE63;
L_01AE63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE63u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE63u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE63 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_01AE65;
L_01AE65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE65u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE65u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE65 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01AE68;
L_01AE68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE68u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE68u, 4u + ((((0x0301u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE68 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x301u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE6B;
L_01AE6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE6B SEC
    cpu.setFlag('C', true);
    goto L_01AE6C;
L_01AE6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Cu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE6C SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_01AE6E;
L_01AE6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Eu, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE6E STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_01AE71;
L_01AE71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE71u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE71u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE71 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AE73;
L_01AE73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE73u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE73u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE73 CMP
    cpu.compareA(0x1u);
    goto L_01AE75;
L_01AE75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE75u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE75 LDA
    cpu.setA(0x2Au, 8);
    goto L_01AE77;
L_01AE77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE77u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE77u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE77 BCC -> $01AE7B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01AE7B; }
    goto L_01AE79;
L_01AE79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE79u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE79 LDA
    cpu.setA(0x2Eu, 8);
    goto L_01AE7B;
L_01AE7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Bu, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AE7B STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_01AE7E;
L_01AE7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01AE7E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01AE7Eu);return;} hw.unresolvedReturn(0x01AE7Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_028752_E1M1X1CQ_part8(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x028A1Fu: goto L_028A1F;
    case 0x028A22u: goto L_028A22;
    case 0x028A24u: goto L_028A24;
    case 0x028A26u: goto L_028A26;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_028A1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Fu))return;
  // 33 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Fu, 4u + 1u, 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A1F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028A22;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Fu, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A1F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028A22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A1Fu,0x028A1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028A22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A22u))return;
  // 33 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A22u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A22 BPL -> $028A29
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x028A29u,0x028A22u); return; }
    goto L_028A24;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A22u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A22 BPL -> $028A29
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x028A29u,0x028A22u); return; }
    goto L_028A24;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A22u,0x028A22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028A24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A24u))return;
  // 33 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A24u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A24 LDA
    cpu.setA(0x10u, 8);
    goto L_028A26;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A24u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A24 LDA
    cpu.setA(0x10u, 8);
    goto L_028A26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A24u,0x028A24u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028A26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A26u))return;
  // 33 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A26u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A26u, 5u, 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A26 STA
    hw.write(cpu.address("absx", 0x15ACu), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A29u,0x028A26u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A26u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A26u, 5u, 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A26 STA
    hw.write(cpu.address("absx", 0x15ACu), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A29u,0x028A26u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A26u,0x028A26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_02ACEF_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02ACEFu: goto L_02ACEF;
    case 0x02ACF0u: goto L_02ACF0;
    case 0x02ACF1u: goto L_02ACF1;
    case 0x02ACF5u: goto L_02ACF5;
    case 0x02ACF6u: goto L_02ACF6;
    case 0x02ACF9u: goto L_02ACF9;
    case 0x02ACFBu: goto L_02ACFB;
    case 0x02ACFCu: goto L_02ACFC;
    case 0x02ACFEu: goto L_02ACFE;
    case 0x02AD01u: goto L_02AD01;
    case 0x02AD02u: goto L_02AD02;
    case 0x02AD05u: goto L_02AD05;
    case 0x02AD07u: goto L_02AD07;
    case 0x02AD0Au: goto L_02AD0A;
    case 0x02AD0Bu: goto L_02AD0B;
    case 0x02AD0Cu: goto L_02AD0C;
    case 0x02AD0Eu: goto L_02AD0E;
    case 0x02AD10u: goto L_02AD10;
    case 0x02AD12u: goto L_02AD12;
    case 0x02AD15u: goto L_02AD15;
    case 0x02AD17u: goto L_02AD17;
    case 0x02AD1Au: goto L_02AD1A;
    case 0x02AD1Du: goto L_02AD1D;
    case 0x02AD1Fu: goto L_02AD1F;
    case 0x02AD22u: goto L_02AD22;
    case 0x02AD24u: goto L_02AD24;
    case 0x02AD27u: goto L_02AD27;
    case 0x02AD2Au: goto L_02AD2A;
    case 0x02AD2Du: goto L_02AD2D;
    case 0x02AD2Fu: goto L_02AD2F;
    case 0x02AD32u: goto L_02AD32;
    case 0x02AD33u: goto L_02AD33;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02ACEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACEFu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACEFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02ACEF PHY
    cpu.push("PHY", hw);
    goto L_02ACF0;
L_02ACF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF0u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02ACF0 PHA
    cpu.push("PHA", hw);
    goto L_02ACF1;
L_02ACF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF1u, 8u, 4u, 0x02AD34u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02ACF1 JSL -> $02AD34 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xACF4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xACF5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02AD34u, 0x02ACF1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02ACF5;
L_02ACF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF5u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xACF5u,0x02ACF5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF5u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02ACF5 PLA
    cpu.pop("PLA", hw);
    goto L_02ACF6;
L_02ACF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF6u, 5u, 3u, cpu.address("absy", 0x16E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ACF6 STA
    hw.write(cpu.address("absy", 0x16E1u), cpu.a, cpu.m8?8:16);
    goto L_02ACF9;
L_02ACF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACF9u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACF9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ACF9 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02ACFB;
L_02ACFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFBu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ACFB SEC
    cpu.setFlag('C', true);
    goto L_02ACFC;
L_02ACFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFCu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ACFC SBC
    cpu.sbc(0x8u);
    goto L_02ACFE;
L_02ACFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACFEu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACFEu, 5u, 3u, cpu.address("absy", 0x16E7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02ACFE STA
    hw.write(cpu.address("absy", 0x16E7u), cpu.a, cpu.m8?8:16);
    goto L_02AD01;
L_02AD01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD01u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD01u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02AD01 PHA
    cpu.push("PHA", hw);
    goto L_02AD02;
L_02AD02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD02u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD02u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD02 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02AD05;
L_02AD05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD05u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD05u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD05 SBC
    cpu.sbc(0x0u);
    goto L_02AD07;
L_02AD07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD07u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD07u, 5u, 3u, cpu.address("absy", 0x16F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD07 STA
    hw.write(cpu.address("absy", 0x16F9u), cpu.a, cpu.m8?8:16);
    goto L_02AD0A;
L_02AD0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Au,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02AD0A PLA
    cpu.pop("PLA", hw);
    goto L_02AD0B;
L_02AD0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD0B SEC
    cpu.setFlag('C', true);
    goto L_02AD0C;
L_02AD0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Cu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD0C SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_02AD0E;
L_02AD0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD0E CMP
    cpu.compareA(0xF0u);
    goto L_02AD10;
L_02AD10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD10u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD10u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD10 BCC -> $02AD22
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_02AD22; }
    goto L_02AD12;
L_02AD12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD12u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD12u, 4u + ((((0x16E7u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x16E7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD12 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x16E7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02AD15;
L_02AD15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD15u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD15u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD15 ADC
    cpu.adc(0x10u);
    goto L_02AD17;
L_02AD17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD17u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD17u, 5u, 3u, cpu.address("absy", 0x16E7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD17 STA
    hw.write(cpu.address("absy", 0x16E7u), cpu.a, cpu.m8?8:16);
    goto L_02AD1A;
L_02AD1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD1Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD1Au, 4u + ((((0x16F9u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x16F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD1A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x16F9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02AD1D;
L_02AD1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD1Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD1D ADC
    cpu.adc(0x0u);
    goto L_02AD1F;
L_02AD1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD1Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD1Fu, 5u, 3u, cpu.address("absy", 0x16F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD1F STA
    hw.write(cpu.address("absy", 0x16F9u), cpu.a, cpu.m8?8:16);
    goto L_02AD22;
L_02AD22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD22u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD22 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02AD24;
L_02AD24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD24u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD24u, 5u, 3u, cpu.address("absy", 0x16EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD24 STA
    hw.write(cpu.address("absy", 0x16EDu), cpu.a, cpu.m8?8:16);
    goto L_02AD27;
L_02AD27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD27u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD27u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD27 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02AD2A;
L_02AD2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD2Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD2Au, 5u, 3u, cpu.address("absy", 0x16F3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD2A STA
    hw.write(cpu.address("absy", 0x16F3u), cpu.a, cpu.m8?8:16);
    goto L_02AD2D;
L_02AD2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD2Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD2D LDA
    cpu.setA(0x30u, 8);
    goto L_02AD2F;
L_02AD2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD2Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD2Fu, 5u, 3u, cpu.address("absy", 0x16FFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02AD2F STA
    hw.write(cpu.address("absy", 0x16FFu), cpu.a, cpu.m8?8:16);
    goto L_02AD32;
L_02AD32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD32u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD32u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02AD32 PLY
    cpu.pop("PLY", hw);
    goto L_02AD33;
L_02AD33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD33u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD33u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02AD33 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02AD33u);return;} hw.unresolvedReturn(0x02AD33u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_048D91_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x048D91u: goto L_048D91;
    case 0x048D92u: goto L_048D92;
    case 0x048D93u: goto L_048D93;
    case 0x048D94u: goto L_048D94;
    case 0x048D97u: goto L_048D97;
    case 0x048D99u: goto L_048D99;
    case 0x048D9Cu: goto L_048D9C;
    case 0x048D9Eu: goto L_048D9E;
    case 0x048DA1u: goto L_048DA1;
    case 0x048DA3u: goto L_048DA3;
    case 0x048DA5u: goto L_048DA5;
    case 0x048DA7u: goto L_048DA7;
    case 0x048DA9u: goto L_048DA9;
    case 0x048DABu: goto L_048DAB;
    case 0x048DAEu: goto L_048DAE;
    case 0x048DB0u: goto L_048DB0;
    case 0x048DB3u: goto L_048DB3;
    case 0x048DB5u: goto L_048DB5;
    case 0x048DB7u: goto L_048DB7;
    case 0x048DB9u: goto L_048DB9;
    case 0x048DBBu: goto L_048DBB;
    case 0x048DBDu: goto L_048DBD;
    case 0x048DC0u: goto L_048DC0;
    case 0x048DC2u: goto L_048DC2;
    case 0x048DC5u: goto L_048DC5;
    case 0x048DC7u: goto L_048DC7;
    case 0x048DCAu: goto L_048DCA;
    case 0x048DCDu: goto L_048DCD;
    case 0x048DCFu: goto L_048DCF;
    case 0x048DD1u: goto L_048DD1;
    case 0x048DD4u: goto L_048DD4;
    case 0x048DD7u: goto L_048DD7;
    case 0x048DDAu: goto L_048DDA;
    case 0x048DDCu: goto L_048DDC;
    case 0x048DDFu: goto L_048DDF;
    case 0x048DE2u: goto L_048DE2;
    case 0x048DE5u: goto L_048DE5;
    case 0x048DE7u: goto L_048DE7;
    case 0x048DEAu: goto L_048DEA;
    case 0x048DEDu: goto L_048DED;
    case 0x048DF0u: goto L_048DF0;
    case 0x048DF2u: goto L_048DF2;
    case 0x048DF5u: goto L_048DF5;
    case 0x048DF8u: goto L_048DF8;
    case 0x048DF9u: goto L_048DF9;
    case 0x048DFAu: goto L_048DFA;
    case 0x048DFBu: goto L_048DFB;
    case 0x048DFCu: goto L_048DFC;
    case 0x048DFEu: goto L_048DFE;
    case 0x048E01u: goto L_048E01;
    case 0x048E02u: goto L_048E02;
    case 0x048E03u: goto L_048E03;
    case 0x048E04u: goto L_048E04;
    case 0x048E05u: goto L_048E05;
    case 0x048E07u: goto L_048E07;
    case 0x048E08u: goto L_048E08;
    case 0x048E09u: goto L_048E09;
    case 0x048E0Au: goto L_048E0A;
    case 0x048E0Bu: goto L_048E0B;
    case 0x048E0Eu: goto L_048E0E;
    case 0x048E10u: goto L_048E10;
    case 0x048E12u: goto L_048E12;
    case 0x048E16u: goto L_048E16;
    case 0x048E19u: goto L_048E19;
    case 0x048E1Au: goto L_048E1A;
    case 0x048E1Du: goto L_048E1D;
    case 0x048E20u: goto L_048E20;
    case 0x048E22u: goto L_048E22;
    case 0x048E25u: goto L_048E25;
    case 0x048E28u: goto L_048E28;
    case 0x048E2Bu: goto L_048E2B;
    case 0x048E2Eu: goto L_048E2E;
    case 0x048E30u: goto L_048E30;
    case 0x048E31u: goto L_048E31;
    case 0x048E32u: goto L_048E32;
    case 0x048E34u: goto L_048E34;
    case 0x048E36u: goto L_048E36;
    case 0x048E38u: goto L_048E38;
    case 0x048E3Au: goto L_048E3A;
    case 0x048E3Du: goto L_048E3D;
    case 0x048E40u: goto L_048E40;
    case 0x048E41u: goto L_048E41;
    case 0x048E44u: goto L_048E44;
    case 0x048E47u: goto L_048E47;
    case 0x048E48u: goto L_048E48;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_048D91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D91u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D91u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $048D91 PHB
    cpu.push("PHB", hw);
    goto L_048D92;
L_048D92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D92u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D92u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $048D92 PHK
    cpu.push("PHK", hw);
    goto L_048D93;
L_048D93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D93u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D93u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $048D93 PLB
    cpu.pop("PLB", hw);
    goto L_048D94;
L_048D94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D94u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D94u, 4u, 3u, cpu.address("abs", 0x1B9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048D94 STZ
    hw.write(cpu.address("abs", 0x1B9Eu), 0, cpu.m8?8:16);
    goto L_048D97;
L_048D97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D97u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048D97 LDA
    cpu.setA(0xFu, 8);
    goto L_048D99;
L_048D99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D99u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D99u, 4u, 3u, cpu.address("abs", 0x144Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048D99 STA
    hw.write(cpu.address("abs", 0x144Eu), cpu.a, cpu.m8?8:16);
    goto L_048D9C;
L_048D9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048D9C LDX
    cpu.setX(0x2u, 8);
    goto L_048D9E;
L_048D9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Eu, 4u, 3u, cpu.address("abs", 0x1F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048D9E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1F13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048DA1;
L_048DA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DA1 CMP
    cpu.compareA(0x12u);
    goto L_048DA3;
L_048DA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DA3 BEQ -> $048DA9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_048DA9; }
    goto L_048DA5;
L_048DA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DA5 AND
    cpu.logicAnd(0x8u);
    goto L_048DA7;
L_048DA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DA7 BEQ -> $048DAB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_048DAB; }
    goto L_048DA9;
L_048DA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DA9 LDX
    cpu.setX(0xAu, 8);
    goto L_048DAB;
L_048DAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu, 4u, 3u, cpu.address("abs", 0x1F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DAB STX
    hw.write(cpu.address("abs", 0x1F13u), cpu.x, cpu.x8?8:16);
    goto L_048DAE;
L_048DAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DAE LDX
    cpu.setX(0x2u, 8);
    goto L_048DB0;
L_048DB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB0u, 4u, 3u, cpu.address("abs", 0x1F15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DB0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1F15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048DB3;
L_048DB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DB3 CMP
    cpu.compareA(0x12u);
    goto L_048DB5;
L_048DB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DB5 BEQ -> $048DBB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_048DBB; }
    goto L_048DB7;
L_048DB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DB7 AND
    cpu.logicAnd(0x8u);
    goto L_048DB9;
L_048DB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DB9 BEQ -> $048DBD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_048DBD; }
    goto L_048DBB;
L_048DBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DBB LDX
    cpu.setX(0xAu, 8);
    goto L_048DBD;
L_048DBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBDu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBDu, 4u, 3u, cpu.address("abs", 0x1F15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DBD STX
    hw.write(cpu.address("abs", 0x1F15u), cpu.x, cpu.x8?8:16);
    goto L_048DC0;
L_048DC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DC0 SEP
    cpu.sep(0x10u);
    goto L_048DC2;
L_048DC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC2u, 6u, 3u, cpu.address("abs", 0x8E55u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048DC2 JSR -> $048E55 stack real
    { cpu.push16Value(hw,0x8DC4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8DC5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8E55u), 0x048DC2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_048DC5;
L_048DC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DC5u,0x048DC5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DC5 REP
    cpu.rep(0x30u);
    goto L_048DC7;
L_048DC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC7u, 5u, 3u, cpu.address("abs", 0x0DD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DC7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048DCA;
L_048DCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DCA AND
    cpu.logicAnd(0xFF00u);
    goto L_048DCD;
L_048DCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DCD BEQ -> $048DDF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_048DDF; }
    goto L_048DCF;
L_048DCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCFu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DCF BMI -> $048DDF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_048DDF; }
    goto L_048DD1;
L_048DD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD1u, 5u, 3u, cpu.address("abs", 0x13BFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DD1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13BFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048DD4;
L_048DD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DD4 AND
    cpu.logicAnd(0xFFu);
    goto L_048DD7;
L_048DD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DD7 CMP
    cpu.compareA(0x18u);
    goto L_048DDA;
L_048DDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DDA BNE -> $048DDF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_048DDF; }
    goto L_048DDC;
L_048DDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDCu,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDCu, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DDC BRL -> $048E34
    goto L_048E34;
L_048DDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDFu, 5u, 3u, cpu.address("abs", 0x13C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DDF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048DE2;
L_048DE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DE2 AND
    cpu.logicAnd(0xFFu);
    goto L_048DE5;
L_048DE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DE5 BEQ -> $048E38
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_048E38; }
    goto L_048DE7;
L_048DE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE7u, 5u, 3u, cpu.address("abs", 0x13C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DE7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048DEA;
L_048DEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DEA AND
    cpu.logicAnd(0xFF00u);
    goto L_048DED;
L_048DED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DEDu, 5u, 3u, cpu.address("abs", 0x13C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DED STA
    hw.write(cpu.address("abs", 0x13C6u), cpu.a, cpu.m8?8:16);
    goto L_048DF0;
L_048DF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DF0 SEP
    cpu.sep(0x10u);
    goto L_048DF2;
L_048DF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF2u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF2u, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DF2 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_048DF5;
L_048DF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF5u, 5u + ((((0x1F17u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DF5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048DF8;
L_048DF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DF8 LSR
    cpu.lsrA();
    goto L_048DF9;
L_048DF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DF9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DF9 LSR
    cpu.lsrA();
    goto L_048DFA;
L_048DFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DFA LSR
    cpu.lsrA();
    goto L_048DFB;
L_048DFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFBu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DFB LSR
    cpu.lsrA();
    goto L_048DFC;
L_048DFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DFC STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_048DFE;
L_048DFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DFEu, 5u + ((((0x1F19u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048DFE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048E01;
L_048E01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E01u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E01u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E01 LSR
    cpu.lsrA();
    goto L_048E02;
L_048E02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E02u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E02 LSR
    cpu.lsrA();
    goto L_048E03;
L_048E03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E03u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E03 LSR
    cpu.lsrA();
    goto L_048E04;
L_048E04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E04u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E04 LSR
    cpu.lsrA();
    goto L_048E05;
L_048E05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E05u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E05u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E05 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_048E07;
L_048E07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E07u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E07 TXA
    cpu.transfer("TXA");
    goto L_048E08;
L_048E08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E08u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E08u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E08 LSR
    cpu.lsrA();
    goto L_048E09;
L_048E09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E09u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E09 LSR
    cpu.lsrA();
    goto L_048E0A;
L_048E0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E0A TAX
    cpu.transfer("TAX");
    goto L_048E0B;
L_048E0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Bu, 6u, 3u, cpu.address("abs", 0x9885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048E0B JSR -> $049885 stack real
    { cpu.push16Value(hw,0x8E0Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E0Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9885u), 0x048E0Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_048E0E;
L_048E0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E0Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E0Eu,0x048E0Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E0Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E0E REP
    cpu.rep(0x10u);
    goto L_048E10;
L_048E10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E10u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E10u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E10 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_048E12;
L_048E12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E12u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E12u, 6u, 4u, ((0x7ED000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E12 LDA
    cpu.loadA(hw.readW(((0x7ED000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048E16;
L_048E16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E16u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E16u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E16 AND
    cpu.logicAnd(0xFFu);
    goto L_048E19;
L_048E19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E19u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E19u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E19 TAX
    cpu.transfer("TAX");
    goto L_048E1A;
L_048E1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Au, 5u + 1u, 3u, cpu.address("absx", 0x1EA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E1A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1EA2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048E1D;
L_048E1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E1D AND
    cpu.logicAnd(0x80u);
    goto L_048E20;
L_048E20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E20u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E20 BNE -> $048E38
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_048E38; }
    goto L_048E22;
L_048E22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E22u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E22u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E22 LDY
    cpu.setY(0x14u, 16);
    goto L_048E25;
L_048E25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E25u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E25u, 5u, 3u, cpu.address("abs", 0x13BFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E25 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13BFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048E28;
L_048E28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E28u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E28u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E28 AND
    cpu.logicAnd(0xFFu);
    goto L_048E2B;
L_048E2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Bu,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Bu, 5u + 1u, 3u, cpu.address("absy", 0x8D74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E2B CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x8D74u), cpu.m8?8:16));
    goto L_048E2E;
L_048E2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E2E BEQ -> $048E38
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_048E38; }
    goto L_048E30;
L_048E30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E30u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E30u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E30 DEY
    cpu.decReg('Y');
    goto L_048E31;
L_048E31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E31u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E31 DEY
    cpu.decReg('Y');
    goto L_048E32;
L_048E32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E32u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E32 BPL -> $048E25
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_048E25; }
    goto L_048E34;
L_048E34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E34u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E34u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E34 SEP
    cpu.sep(0x30u);
    goto L_048E36;
L_048E36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E36u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E36u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E36 BRA -> $048E47
    goto L_048E47;
L_048E38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E38 SEP
    cpu.sep(0x30u);
    goto L_048E3A;
L_048E3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Au,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Au, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E3A LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDB3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_048E3D;
L_048E3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Du, 4u + ((((0x1F11u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E3D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048E40;
L_048E40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E40u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E40u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E40 TAX
    cpu.transfer("TAX");
    goto L_048E41;
L_048E41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E41u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E41u, 4u + ((((0x8D8Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8D8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E41 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8D8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048E44;
L_048E44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E44 STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_048E47;
L_048E47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E47u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E47u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $048E47 PLB
    cpu.pop("PLB", hw);
    goto L_048E48;
L_048E48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E48u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E48u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $048E48 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x048E48u);return;} hw.unresolvedReturn(0x048E48u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_049831_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x049831u: goto L_049831;
    case 0x049833u: goto L_049833;
    case 0x049836u: goto L_049836;
    case 0x049838u: goto L_049838;
    case 0x04983Au: goto L_04983A;
    case 0x04983Du: goto L_04983D;
    case 0x04983Fu: goto L_04983F;
    case 0x049841u: goto L_049841;
    case 0x049844u: goto L_049844;
    case 0x049847u: goto L_049847;
    case 0x049849u: goto L_049849;
    case 0x04984Cu: goto L_04984C;
    case 0x04984Eu: goto L_04984E;
    case 0x04984Fu: goto L_04984F;
    case 0x049850u: goto L_049850;
    case 0x049851u: goto L_049851;
    case 0x049852u: goto L_049852;
    case 0x049855u: goto L_049855;
    case 0x049858u: goto L_049858;
    case 0x04985Au: goto L_04985A;
    case 0x04985Du: goto L_04985D;
    case 0x04985Eu: goto L_04985E;
    case 0x049860u: goto L_049860;
    case 0x049861u: goto L_049861;
    case 0x049864u: goto L_049864;
    case 0x049866u: goto L_049866;
    case 0x049869u: goto L_049869;
    case 0x04986Bu: goto L_04986B;
    case 0x04986Eu: goto L_04986E;
    case 0x049870u: goto L_049870;
    case 0x049873u: goto L_049873;
    case 0x049875u: goto L_049875;
    case 0x049878u: goto L_049878;
    case 0x04987Au: goto L_04987A;
    case 0x04987Cu: goto L_04987C;
    case 0x04987Du: goto L_04987D;
    case 0x04987Eu: goto L_04987E;
    case 0x04987Fu: goto L_04987F;
    case 0x049880u: goto L_049880;
    case 0x049882u: goto L_049882;
    case 0x049884u: goto L_049884;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_049831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9831u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9831u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049831 SEP
    cpu.sep(0x20u);
    goto L_049833;
L_049833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9833u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9833u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049833 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13D9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049836;
L_049836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9836u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9836u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049836 CMP
    cpu.compareA(0xAu);
    goto L_049838;
L_049838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9838u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9838u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049838 BEQ -> $049882
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_049882; }
    goto L_04983A;
L_04983A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x983Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x983Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x983Au, 4u, 3u, cpu.address("abs", 0x1BA0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04983A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04983D;
L_04983D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x983Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x983Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x983Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04983D BNE -> $049882
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049882; }
    goto L_04983F;
L_04983F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x983Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x983Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x983Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04983F REP
    cpu.rep(0x30u);
    goto L_049841;
L_049841:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9841u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9841u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9841u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049841 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049844;
L_049844:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9844u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9844u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9844u, 5u + 1u, 3u, cpu.address("absx", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049844 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049847;
L_049847:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9847u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9847u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9847u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049847 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_049849;
L_049849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9849u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9849u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9849u, 5u + 1u, 3u, cpu.address("absx", 0x1F19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049849 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04984C;
L_04984C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04984C STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04984E;
L_04984E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04984E TXA
    cpu.transfer("TXA");
    goto L_04984F;
L_04984F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04984F LSR
    cpu.lsrA();
    goto L_049850;
L_049850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9850u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9850u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9850u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049850 LSR
    cpu.lsrA();
    goto L_049851;
L_049851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049851 TAX
    cpu.transfer("TAX");
    goto L_049852;
L_049852:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9852u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9852u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9852u, 5u + 1u, 3u, cpu.address("absx", 0x1F11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049852 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049855;
L_049855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9855u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9855u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049855 AND
    cpu.logicAnd(0xFFu);
    goto L_049858;
L_049858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9858u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9858u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049858 BNE -> $049882
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049882; }
    goto L_04985A;
L_04985A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04985A LDX
    cpu.setX(0x2u, 16);
    goto L_04985D;
L_04985D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Du,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04985D TXY
    cpu.transfer("TXY");
    goto L_04985E;
L_04985E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Eu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04985E LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049860;
L_049860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9860u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9860u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049860 SEC
    cpu.setFlag('C', true);
    goto L_049861;
L_049861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9861u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9861u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9861u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049861 SBC
    cpu.sbc(0x80u);
    goto L_049864;
L_049864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9864u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9864u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9864u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049864 BPL -> $049870
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_049870; }
    goto L_049866;
L_049866:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9866u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9866u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9866u, 5u + 1u, 3u, cpu.address("absy", 0x9416u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049866 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x9416u), cpu.m8?8:16));
    goto L_049869;
L_049869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9869u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9869u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049869 BCS -> $049878
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_049878; }
    goto L_04986B;
L_04986B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x986Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x986Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x986Bu, 5u + 1u, 3u, cpu.address("absy", 0x9416u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04986B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9416u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04986E;
L_04986E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x986Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x986Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x986Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04986E BRA -> $049878
    goto L_049878;
L_049870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9870u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9870u, 5u + 1u, 3u, cpu.address("absy", 0x941Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049870 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x941Au), cpu.m8?8:16));
    goto L_049873;
L_049873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9873u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9873u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049873 BCC -> $049878
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_049878; }
    goto L_049875;
L_049875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9875u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9875u, 5u + 1u, 3u, cpu.address("absy", 0x941Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049875 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x941Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049878;
L_049878:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9878u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9878u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9878u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049878 STA
    hw.write(cpu.address("dpx", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_04987A;
L_04987A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x987Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x987Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x987Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04987A STA
    hw.write(cpu.address("dpx", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_04987C;
L_04987C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x987Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x987Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x987Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04987C DEY
    cpu.decReg('Y');
    goto L_04987D;
L_04987D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x987Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x987Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x987Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04987D DEY
    cpu.decReg('Y');
    goto L_04987E;
L_04987E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x987Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x987Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x987Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04987E DEX
    cpu.decReg('X');
    goto L_04987F;
L_04987F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x987Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x987Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x987Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04987F DEX
    cpu.decReg('X');
    goto L_049880;
L_049880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9880u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9880u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049880 BPL -> $04985E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04985E; }
    goto L_049882;
L_049882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9882u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9882u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9882u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049882 SEP
    cpu.sep(0x30u);
    goto L_049884;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9882u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9882u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049882 SEP
    cpu.sep(0x30u);
    goto L_049884;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9882u,0x049882u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_049884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9884u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9884u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049884 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x049884u);return;} hw.unresolvedReturn(0x049884u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04D7F2_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04D7F2u: goto L_04D7F2;
    case 0x04D7F4u: goto L_04D7F4;
    case 0x04D7F7u: goto L_04D7F7;
    case 0x04D7F9u: goto L_04D7F9;
    case 0x04D7FBu: goto L_04D7FB;
    case 0x04D7FDu: goto L_04D7FD;
    case 0x04D7FFu: goto L_04D7FF;
    case 0x04D801u: goto L_04D801;
    case 0x04D803u: goto L_04D803;
    case 0x04D805u: goto L_04D805;
    case 0x04D807u: goto L_04D807;
    case 0x04D809u: goto L_04D809;
    case 0x04D80Bu: goto L_04D80B;
    case 0x04D80Du: goto L_04D80D;
    case 0x04D80Fu: goto L_04D80F;
    case 0x04D811u: goto L_04D811;
    case 0x04D813u: goto L_04D813;
    case 0x04D815u: goto L_04D815;
    case 0x04D817u: goto L_04D817;
    case 0x04D819u: goto L_04D819;
    case 0x04D81Bu: goto L_04D81B;
    case 0x04D81Du: goto L_04D81D;
    case 0x04D820u: goto L_04D820;
    case 0x04D822u: goto L_04D822;
    case 0x04D825u: goto L_04D825;
    case 0x04D827u: goto L_04D827;
    case 0x04D829u: goto L_04D829;
    case 0x04D82Bu: goto L_04D82B;
    case 0x04D82Cu: goto L_04D82C;
    case 0x04D82Eu: goto L_04D82E;
    case 0x04D831u: goto L_04D831;
    case 0x04D832u: goto L_04D832;
    case 0x04D834u: goto L_04D834;
    case 0x04D836u: goto L_04D836;
    case 0x04D838u: goto L_04D838;
    case 0x04D83Au: goto L_04D83A;
    case 0x04D83Cu: goto L_04D83C;
    case 0x04D83Eu: goto L_04D83E;
    case 0x04D840u: goto L_04D840;
    case 0x04D841u: goto L_04D841;
    case 0x04D845u: goto L_04D845;
    case 0x04D847u: goto L_04D847;
    case 0x04D849u: goto L_04D849;
    case 0x04D84Au: goto L_04D84A;
    case 0x04D84Du: goto L_04D84D;
    case 0x04D84Fu: goto L_04D84F;
    case 0x04D851u: goto L_04D851;
    case 0x04D854u: goto L_04D854;
    case 0x04D856u: goto L_04D856;
    case 0x04D858u: goto L_04D858;
    case 0x04D85Au: goto L_04D85A;
    case 0x04D85Cu: goto L_04D85C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04D7F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7F2 REP
    cpu.rep(0x30u);
    goto L_04D7F4;
L_04D7F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7F4 LDA
    cpu.setA(0x0u, 16);
    goto L_04D7F7;
L_04D7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7F7 SEP
    cpu.sep(0x20u);
    goto L_04D7F9;
L_04D7F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7F9 LDA
    cpu.setA(0x0u, 8);
    goto L_04D7FB;
L_04D7FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7FB STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_04D7FD;
L_04D7FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7FD LDA
    cpu.setA(0xD0u, 8);
    goto L_04D7FF;
L_04D7FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D7FF STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_04D801;
L_04D801:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD801u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD801u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD801u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D801 LDA
    cpu.setA(0x7Eu, 8);
    goto L_04D803;
L_04D803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD803u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD803u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD803u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D803 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_04D805;
L_04D805:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD805u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD805u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD805u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D805 LDA
    cpu.setA(0x0u, 8);
    goto L_04D807;
L_04D807:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD807u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD807u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD807u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D807 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_04D809;
L_04D809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD809u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD809u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D809 LDA
    cpu.setA(0xD8u, 8);
    goto L_04D80B;
L_04D80B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D80B STA
    hw.write(cpu.address("dp", 0xBu), cpu.a, cpu.m8?8:16);
    goto L_04D80D;
L_04D80D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D80D LDA
    cpu.setA(0x7Eu, 8);
    goto L_04D80F;
L_04D80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D80F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_04D811;
L_04D811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD811u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD811u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D811 LDA
    cpu.setA(0x0u, 8);
    goto L_04D813;
L_04D813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD813u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD813u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D813 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_04D815;
L_04D815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD815u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD815u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D815 LDA
    cpu.setA(0xC8u, 8);
    goto L_04D817;
L_04D817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD817u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD817u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD817u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D817 STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_04D819;
L_04D819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD819u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD819u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD819u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D819 LDA
    cpu.setA(0x7Eu, 8);
    goto L_04D81B;
L_04D81B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD81Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D81B STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_04D81D;
L_04D81D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD81Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D81D LDY
    cpu.setY(0x1u, 16);
    goto L_04D820;
L_04D820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD820u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD820u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D820 STY
    hw.write(cpu.address("dp", 0x0u), cpu.y, cpu.x8?8:16);
    goto L_04D822;
L_04D822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD822u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD822u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D822 LDY
    cpu.setY(0x7FFu, 16);
    goto L_04D825;
L_04D825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD825u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD825u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD825u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D825 LDA
    cpu.setA(0x0u, 8);
    goto L_04D827;
L_04D827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD827u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD827u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $04D827 STA
    hw.write(cpu.addressDpLongY(hw, 0xAu), cpu.a, cpu.m8?8:16);
    goto L_04D829;
L_04D829:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD829u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD829u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD829u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Du) & 0xFFFFu), 3u, 0u);
    // $04D829 STA
    hw.write(cpu.addressDpLongY(hw, 0xDu), cpu.a, cpu.m8?8:16);
    goto L_04D82B;
L_04D82B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD82Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D82B DEY
    cpu.decReg('Y');
    goto L_04D82C;
L_04D82C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD82Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D82C BPL -> $04D827
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04D827; }
    goto L_04D82E;
L_04D82E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD82Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D82E LDY
    cpu.setY(0x0u, 16);
    goto L_04D831;
L_04D831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD831u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD831u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D831 TYX
    cpu.transfer("TYX");
    goto L_04D832;
L_04D832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD832u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD832u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 3u, 0u);
    // $04D832 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04D834;
L_04D834:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD834u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD834u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD834u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D834 CMP
    cpu.compareA(0x56u);
    goto L_04D836;
L_04D836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD836u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD836u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D836 BCC -> $04D849
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_04D849; }
    goto L_04D838;
L_04D838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD838u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD838u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D838 CMP
    cpu.compareA(0x81u);
    goto L_04D83A;
L_04D83A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD83Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D83A BCS -> $04D849
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_04D849; }
    goto L_04D83C;
L_04D83C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD83Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D83C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04D83E;
L_04D83E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD83Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Eu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Eu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Du) & 0xFFFFu), 3u, 0u);
    // $04D83E STA
    hw.write(cpu.addressDpLongY(hw, 0xDu), cpu.a, cpu.m8?8:16);
    goto L_04D840;
L_04D840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD840u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD840u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D840 TAX
    cpu.transfer("TAX");
    goto L_04D841;
L_04D841:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD841u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD841u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD841u, 5u, 4u, ((0x04D678u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D841 LDA
    cpu.loadA(hw.readW(((0x4D678u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04D845;
L_04D845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD845u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD845u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 3u, 0u);
    // $04D845 STA
    hw.write(cpu.addressDpLongY(hw, 0xAu), cpu.a, cpu.m8?8:16);
    goto L_04D847;
L_04D847:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD847u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD847u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD847u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D847 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_04D849;
L_04D849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD849u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD849u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD849u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D849 INY
    cpu.inc('Y');
    goto L_04D84A;
L_04D84A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD84Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD84Au,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD84Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D84A CPY
    cpu.compareY(0x800u);
    goto L_04D84D;
L_04D84D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD84Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD84Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD84Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D84D BNE -> $04D832
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04D832; }
    goto L_04D84F;
L_04D84F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD84Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD84Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD84Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D84F STZ
    hw.write(cpu.address("dp", 0xFu), 0, cpu.m8?8:16);
    goto L_04D851;
L_04D851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD851u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD851u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD851u, 6u, 3u, cpu.address("abs", 0xDA49u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04D851 JSR -> $04DA49 stack real
    { cpu.push16Value(hw,0xD853u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD854u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDA49u), 0x04D851u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04D854;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD851u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD851u, 6u, 3u, cpu.address("abs", 0xDA49u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04D851 JSR -> $04DA49 stack real
    { cpu.push16Value(hw,0xD853u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD854u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDA49u), 0x04D851u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04D854;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD851u,0x04D851u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04D854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD854u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD854u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD854u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D854 INC
    cpu.incMem(hw, cpu.address("dp", 0xFu), cpu.m8?8:16);
    goto L_04D856;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD854u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD854u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D854 INC
    cpu.incMem(hw, cpu.address("dp", 0xFu), cpu.m8?8:16);
    goto L_04D856;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD854u,0x04D854u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04D856:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD856u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD856u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD856u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D856 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04D858;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD856u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD856u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D856 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04D858;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD856u,0x04D856u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04D858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD858u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD858u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD858u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D858 CMP
    cpu.compareA(0x6Fu);
    goto L_04D85A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD858u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD858u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D858 CMP
    cpu.compareA(0x6Fu);
    goto L_04D85A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD858u,0x04D858u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04D85A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD85Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D85A BNE -> $04D851
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04D851; }
    goto L_04D85C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04D85A BNE -> $04D851
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04D851; }
    goto L_04D85C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD85Au,0x04D85Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04D85C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD85Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04D85C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04D85Cu);return;} hw.unresolvedReturn(0x04D85Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04D85C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04D85Cu);return;} hw.unresolvedReturn(0x04D85Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD85Cu,0x04D85Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_058955_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x058955u: goto L_058955;
    case 0x058957u: goto L_058957;
    case 0x05895Au: goto L_05895A;
    case 0x05895Eu: goto L_05895E;
    case 0x05895Fu: goto L_05895F;
    case 0x058962u: goto L_058962;
    case 0x058963u: goto L_058963;
    case 0x058965u: goto L_058965;
    case 0x058966u: goto L_058966;
    case 0x058968u: goto L_058968;
    case 0x058969u: goto L_058969;
    case 0x05896Bu: goto L_05896B;
    case 0x05896Cu: goto L_05896C;
    case 0x05896Eu: goto L_05896E;
    case 0x058971u: goto L_058971;
    case 0x058974u: goto L_058974;
    case 0x058977u: goto L_058977;
    case 0x05897Au: goto L_05897A;
    case 0x05897Du: goto L_05897D;
    case 0x058980u: goto L_058980;
    case 0x058983u: goto L_058983;
    case 0x058986u: goto L_058986;
    case 0x058989u: goto L_058989;
    case 0x05898Cu: goto L_05898C;
    case 0x05898Du: goto L_05898D;
    case 0x05898Fu: goto L_05898F;
    case 0x058992u: goto L_058992;
    case 0x058995u: goto L_058995;
    case 0x058998u: goto L_058998;
    case 0x05899Bu: goto L_05899B;
    case 0x05899Eu: goto L_05899E;
    case 0x0589A1u: goto L_0589A1;
    case 0x0589A4u: goto L_0589A4;
    case 0x0589A7u: goto L_0589A7;
    case 0x0589AAu: goto L_0589AA;
    case 0x0589ADu: goto L_0589AD;
    case 0x0589B0u: goto L_0589B0;
    case 0x0589B3u: goto L_0589B3;
    case 0x0589B6u: goto L_0589B6;
    case 0x0589B9u: goto L_0589B9;
    case 0x0589BCu: goto L_0589BC;
    case 0x0589BDu: goto L_0589BD;
    case 0x0589BFu: goto L_0589BF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_058955:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8955u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8955u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8955u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058955 SEP
    cpu.sep(0x30u);
    goto L_058957;
L_058957:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8957u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8957u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8957u, 4u, 3u, cpu.address("abs", 0x1925u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058957 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1925u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05895A;
L_05895A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x895Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x895Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x895Au, 8u, 4u, 0x0086FAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05895A JSL -> $0086FA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x895Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x895Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086FAu, 0x05895Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05895E;
L_05895E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x895Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x895Eu,0x05895Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x895Eu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x895Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05895E PLY
    cpu.pop("PLY", hw);
    goto L_05895F;
L_05895F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x895Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x895Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x895Fu, 4u, 3u, cpu.address("abs", 0x8D05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05895F STA
    hw.write(cpu.address("abs", 0x8D05u), cpu.a, cpu.m8?8:16);
    goto L_058962;
L_058962:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8962u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8962u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8962u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058962 PHB
    cpu.push("PHB", hw);
    goto L_058963;
L_058963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8963u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8963u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058963 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_058965;
L_058965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8965u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8965u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058965 PHB
    cpu.push("PHB", hw);
    goto L_058966;
L_058966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8966u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8966u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058966 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_058968;
L_058968:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8968u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8968u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8968u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058968 PHB
    cpu.push("PHB", hw);
    goto L_058969;
L_058969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8969u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8969u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8969u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058969 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_05896B;
L_05896B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x896Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x896Bu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x896Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05896B PHB
    cpu.push("PHB", hw);
    goto L_05896C;
L_05896C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x896Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x896Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x896Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05896C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x71u), cpu.m8?8:16));
    goto L_05896E;
L_05896E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x896Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x896Eu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x896Eu, 4u, 3u, cpu.address("abs", 0x7105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05896E STY
    hw.write(cpu.address("abs", 0x7105u), cpu.y, cpu.x8?8:16);
    goto L_058971;
L_058971:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8971u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8971u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8971u, 4u, 3u, cpu.address("abs", 0x7105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058971 STY
    hw.write(cpu.address("abs", 0x7105u), cpu.y, cpu.x8?8:16);
    goto L_058974;
L_058974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8974u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8974u, 4u, 3u, cpu.address("abs", 0x7105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058974 STY
    hw.write(cpu.address("abs", 0x7105u), cpu.y, cpu.x8?8:16);
    goto L_058977;
L_058977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8977u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8977u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058977 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_05897A;
L_05897A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x897Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x897Au,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x897Au, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05897A STY
    hw.write(cpu.address("abs", 0x7A05u), cpu.y, cpu.x8?8:16);
    goto L_05897D;
L_05897D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x897Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x897Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x897Du, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05897D STA
    hw.write(cpu.address("abs", 0x7005u), cpu.a, cpu.m8?8:16);
    goto L_058980;
L_058980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8980u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8980u, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058980 STY
    hw.write(cpu.address("abs", 0x7A05u), cpu.y, cpu.x8?8:16);
    goto L_058983;
L_058983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8983u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8983u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8983u, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058983 STA
    hw.write(cpu.address("abs", 0x7A05u), cpu.a, cpu.m8?8:16);
    goto L_058986;
L_058986:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8986u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8986u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8986u, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058986 STA
    hw.write(cpu.address("abs", 0x7A05u), cpu.a, cpu.m8?8:16);
    goto L_058989;
L_058989:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8989u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8989u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8989u, 4u, 3u, cpu.address("abs", 0x8D05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058989 STA
    hw.write(cpu.address("abs", 0x8D05u), cpu.a, cpu.m8?8:16);
    goto L_05898C;
L_05898C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x898Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x898Cu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x898Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05898C PHB
    cpu.push("PHB", hw);
    goto L_05898D;
L_05898D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x898Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x898Du,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x898Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x70u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05898D ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x70u), cpu.m8?8:16));
    goto L_05898F;
L_05898F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x898Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x898Fu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x898Fu, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05898F STY
    hw.write(cpu.address("abs", 0x7A05u), cpu.y, cpu.x8?8:16);
    goto L_058992;
L_058992:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8992u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8992u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8992u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058992 STA
    hw.write(cpu.address("abs", 0x7005u), cpu.a, cpu.m8?8:16);
    goto L_058995;
L_058995:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8995u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8995u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8995u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058995 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_058998;
L_058998:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8998u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8998u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8998u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058998 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_05899B;
L_05899B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x899Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x899Bu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x899Bu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05899B STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_05899E;
L_05899E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x899Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x899Eu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x899Eu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05899E STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589A1;
L_0589A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A1u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A1u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589A1 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589A4;
L_0589A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A4u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A4u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589A4 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589A7;
L_0589A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A7u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A7u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589A7 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589AA;
L_0589AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89AAu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89AAu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589AA STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589AD;
L_0589AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89ADu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89ADu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589AD STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589B0;
L_0589B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B0u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B0u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589B0 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589B3;
L_0589B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B3u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B3u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589B3 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589B6;
L_0589B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B6u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B6u, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589B6 STY
    hw.write(cpu.address("abs", 0x7A05u), cpu.y, cpu.x8?8:16);
    goto L_0589B9;
L_0589B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B9u, 4u, 3u, cpu.address("abs", 0x8D05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589B9 STA
    hw.write(cpu.address("abs", 0x8D05u), cpu.a, cpu.m8?8:16);
    goto L_0589BC;
L_0589BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89BCu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89BCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0589BC PHB
    cpu.push("PHB", hw);
    goto L_0589BD;
L_0589BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89BDu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89BDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589BD ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16));
    goto L_0589BF;
L_0589BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89BFu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89BFu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0589BF BRK
    hw.partial(0x0589BFu, "BRK"); return;
}

void sub_058955_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x058955u: goto L_058955;
    case 0x058957u: goto L_058957;
    case 0x05895Au: goto L_05895A;
    case 0x05895Eu: goto L_05895E;
    case 0x05895Fu: goto L_05895F;
    case 0x058962u: goto L_058962;
    case 0x058963u: goto L_058963;
    case 0x058965u: goto L_058965;
    case 0x058966u: goto L_058966;
    case 0x058968u: goto L_058968;
    case 0x058969u: goto L_058969;
    case 0x05896Bu: goto L_05896B;
    case 0x05896Cu: goto L_05896C;
    case 0x05896Eu: goto L_05896E;
    case 0x058971u: goto L_058971;
    case 0x058974u: goto L_058974;
    case 0x058977u: goto L_058977;
    case 0x05897Au: goto L_05897A;
    case 0x05897Du: goto L_05897D;
    case 0x058980u: goto L_058980;
    case 0x058983u: goto L_058983;
    case 0x058986u: goto L_058986;
    case 0x058989u: goto L_058989;
    case 0x05898Cu: goto L_05898C;
    case 0x05898Du: goto L_05898D;
    case 0x05898Fu: goto L_05898F;
    case 0x058992u: goto L_058992;
    case 0x058995u: goto L_058995;
    case 0x058998u: goto L_058998;
    case 0x05899Bu: goto L_05899B;
    case 0x05899Eu: goto L_05899E;
    case 0x0589A1u: goto L_0589A1;
    case 0x0589A4u: goto L_0589A4;
    case 0x0589A7u: goto L_0589A7;
    case 0x0589AAu: goto L_0589AA;
    case 0x0589ADu: goto L_0589AD;
    case 0x0589B0u: goto L_0589B0;
    case 0x0589B3u: goto L_0589B3;
    case 0x0589B6u: goto L_0589B6;
    case 0x0589B9u: goto L_0589B9;
    case 0x0589BCu: goto L_0589BC;
    case 0x0589BDu: goto L_0589BD;
    case 0x0589BFu: goto L_0589BF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_058955:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8955u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8955u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8955u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058955 SEP
    cpu.sep(0x30u);
    goto L_058957;
L_058957:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8957u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8957u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8957u, 4u, 3u, cpu.address("abs", 0x1925u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058957 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1925u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05895A;
L_05895A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x895Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x895Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x895Au, 8u, 4u, 0x0086FAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05895A JSL -> $0086FA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x895Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x895Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086FAu, 0x05895Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05895E;
L_05895E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x895Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x895Eu,0x05895Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x895Eu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x895Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05895E PLY
    cpu.pop("PLY", hw);
    goto L_05895F;
L_05895F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x895Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x895Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x895Fu, 4u, 3u, cpu.address("abs", 0x8D05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05895F STA
    hw.write(cpu.address("abs", 0x8D05u), cpu.a, cpu.m8?8:16);
    goto L_058962;
L_058962:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8962u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8962u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8962u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058962 PHB
    cpu.push("PHB", hw);
    goto L_058963;
L_058963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8963u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8963u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058963 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_058965;
L_058965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8965u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8965u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058965 PHB
    cpu.push("PHB", hw);
    goto L_058966;
L_058966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8966u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8966u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058966 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_058968;
L_058968:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8968u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8968u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8968u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058968 PHB
    cpu.push("PHB", hw);
    goto L_058969;
L_058969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8969u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8969u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8969u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058969 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16));
    goto L_05896B;
L_05896B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x896Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x896Bu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x896Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05896B PHB
    cpu.push("PHB", hw);
    goto L_05896C;
L_05896C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x896Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x896Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x896Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05896C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x71u), cpu.m8?8:16));
    goto L_05896E;
L_05896E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x896Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x896Eu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x896Eu, 4u, 3u, cpu.address("abs", 0x7105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05896E STY
    hw.write(cpu.address("abs", 0x7105u), cpu.y, cpu.x8?8:16);
    goto L_058971;
L_058971:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8971u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8971u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8971u, 4u, 3u, cpu.address("abs", 0x7105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058971 STY
    hw.write(cpu.address("abs", 0x7105u), cpu.y, cpu.x8?8:16);
    goto L_058974;
L_058974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8974u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8974u, 4u, 3u, cpu.address("abs", 0x7105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058974 STY
    hw.write(cpu.address("abs", 0x7105u), cpu.y, cpu.x8?8:16);
    goto L_058977;
L_058977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8977u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8977u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058977 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_05897A;
L_05897A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x897Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x897Au,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x897Au, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05897A STY
    hw.write(cpu.address("abs", 0x7A05u), cpu.y, cpu.x8?8:16);
    goto L_05897D;
L_05897D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x897Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x897Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x897Du, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05897D STA
    hw.write(cpu.address("abs", 0x7005u), cpu.a, cpu.m8?8:16);
    goto L_058980;
L_058980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8980u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8980u, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058980 STY
    hw.write(cpu.address("abs", 0x7A05u), cpu.y, cpu.x8?8:16);
    goto L_058983;
L_058983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8983u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8983u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8983u, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058983 STA
    hw.write(cpu.address("abs", 0x7A05u), cpu.a, cpu.m8?8:16);
    goto L_058986;
L_058986:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8986u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8986u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8986u, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058986 STA
    hw.write(cpu.address("abs", 0x7A05u), cpu.a, cpu.m8?8:16);
    goto L_058989;
L_058989:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8989u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8989u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8989u, 4u, 3u, cpu.address("abs", 0x8D05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058989 STA
    hw.write(cpu.address("abs", 0x8D05u), cpu.a, cpu.m8?8:16);
    goto L_05898C;
L_05898C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x898Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x898Cu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x898Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05898C PHB
    cpu.push("PHB", hw);
    goto L_05898D;
L_05898D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x898Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x898Du,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x898Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x70u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05898D ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x70u), cpu.m8?8:16));
    goto L_05898F;
L_05898F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x898Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x898Fu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x898Fu, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05898F STY
    hw.write(cpu.address("abs", 0x7A05u), cpu.y, cpu.x8?8:16);
    goto L_058992;
L_058992:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8992u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8992u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8992u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058992 STA
    hw.write(cpu.address("abs", 0x7005u), cpu.a, cpu.m8?8:16);
    goto L_058995;
L_058995:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8995u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8995u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8995u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058995 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_058998;
L_058998:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8998u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8998u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8998u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058998 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_05899B;
L_05899B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x899Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x899Bu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x899Bu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05899B STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_05899E;
L_05899E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x899Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x899Eu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x899Eu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05899E STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589A1;
L_0589A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A1u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A1u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589A1 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589A4;
L_0589A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A4u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A4u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589A4 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589A7;
L_0589A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89A7u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89A7u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589A7 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589AA;
L_0589AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89AAu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89AAu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589AA STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589AD;
L_0589AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89ADu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89ADu, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589AD STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589B0;
L_0589B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B0u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B0u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589B0 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589B3;
L_0589B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B3u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B3u, 4u, 3u, cpu.address("abs", 0x7005u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589B3 STY
    hw.write(cpu.address("abs", 0x7005u), cpu.y, cpu.x8?8:16);
    goto L_0589B6;
L_0589B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B6u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B6u, 4u, 3u, cpu.address("abs", 0x7A05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589B6 STY
    hw.write(cpu.address("abs", 0x7A05u), cpu.y, cpu.x8?8:16);
    goto L_0589B9;
L_0589B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B9u, 4u, 3u, cpu.address("abs", 0x8D05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589B9 STA
    hw.write(cpu.address("abs", 0x8D05u), cpu.a, cpu.m8?8:16);
    goto L_0589BC;
L_0589BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89BCu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89BCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0589BC PHB
    cpu.push("PHB", hw);
    goto L_0589BD;
L_0589BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89BDu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89BDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0589BD ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16));
    goto L_0589BF;
L_0589BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89BFu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89BFu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0589BF BRK
    hw.partial(0x0589BFu, "BRK"); return;
}

void sub_0C9567_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0C9567u: goto L_0C9567;
    case 0x0C9569u: goto L_0C9569;
    case 0x0C956Au: goto L_0C956A;
    case 0x0C956Bu: goto L_0C956B;
    case 0x0C956Cu: goto L_0C956C;
    case 0x0C956Eu: goto L_0C956E;
    case 0x0C9571u: goto L_0C9571;
    case 0x0C9573u: goto L_0C9573;
    case 0x0C9576u: goto L_0C9576;
    case 0x0C9578u: goto L_0C9578;
    case 0x0C957Bu: goto L_0C957B;
    case 0x0C957Du: goto L_0C957D;
    case 0x0C9580u: goto L_0C9580;
    case 0x0C9583u: goto L_0C9583;
    case 0x0C9584u: goto L_0C9584;
    case 0x0C9586u: goto L_0C9586;
    case 0x0C9589u: goto L_0C9589;
    case 0x0C958Au: goto L_0C958A;
    case 0x0C958Bu: goto L_0C958B;
    case 0x0C958Cu: goto L_0C958C;
    case 0x0C958Fu: goto L_0C958F;
    case 0x0C9592u: goto L_0C9592;
    case 0x0C9594u: goto L_0C9594;
    case 0x0C9597u: goto L_0C9597;
    case 0x0C9599u: goto L_0C9599;
    case 0x0C959Cu: goto L_0C959C;
    case 0x0C959Eu: goto L_0C959E;
    case 0x0C95A1u: goto L_0C95A1;
    case 0x0C95A3u: goto L_0C95A3;
    case 0x0C95A6u: goto L_0C95A6;
    case 0x0C95A8u: goto L_0C95A8;
    case 0x0C95ABu: goto L_0C95AB;
    case 0x0C95AEu: goto L_0C95AE;
    case 0x0C95AFu: goto L_0C95AF;
    case 0x0C95B1u: goto L_0C95B1;
    case 0x0C95B4u: goto L_0C95B4;
    case 0x0C95B5u: goto L_0C95B5;
    case 0x0C95B6u: goto L_0C95B6;
    case 0x0C95B7u: goto L_0C95B7;
    case 0x0C95BAu: goto L_0C95BA;
    case 0x0C95BDu: goto L_0C95BD;
    case 0x0C95BFu: goto L_0C95BF;
    case 0x0C95C2u: goto L_0C95C2;
    case 0x0C95C5u: goto L_0C95C5;
    case 0x0C95C6u: goto L_0C95C6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0C9567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9567u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9567u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9567 SEP
    cpu.sep(0x30u);
    goto L_0C9569;
L_0C9569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9569u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9569u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0C9569 PHB
    cpu.push("PHB", hw);
    goto L_0C956A;
L_0C956A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x956Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x956Au,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x956Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0C956A PHK
    cpu.push("PHK", hw);
    goto L_0C956B;
L_0C956B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x956Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x956Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x956Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0C956B PLB
    cpu.pop("PLB", hw);
    goto L_0C956C;
L_0C956C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x956Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x956Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x956Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C956C LDA
    cpu.setA(0x80u, 8);
    goto L_0C956E;
L_0C956E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x956Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x956Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x956Eu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C956E STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_0C9571;
L_0C9571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9571u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9571u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9571u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9571 LDA
    cpu.setA(0xC0u, 8);
    goto L_0C9573;
L_0C9573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9573u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9573u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9573 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_0C9576;
L_0C9576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9576 LDA
    cpu.setA(0x30u, 8);
    goto L_0C9578;
L_0C9578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9578u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9578u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9578u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9578 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_0C957B;
L_0C957B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x957Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x957Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x957Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C957B LDY
    cpu.setY(0x6u, 8);
    goto L_0C957D;
L_0C957D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x957Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x957Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x957Du, 4u + ((((0x9559u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9559u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C957D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9559u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9580;
L_0C9580:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9580u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9580u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9580u, 5u, 3u, cpu.address("absy", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9580 STA
    hw.write(cpu.address("absy", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_0C9583;
L_0C9583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9583u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9583u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9583u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9583 DEY
    cpu.decReg('Y');
    goto L_0C9584;
L_0C9584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9584u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9584u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9584u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9584 BPL -> $0C957D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0C957D; }
    goto L_0C9586;
L_0C9586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9586u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9586u, 4u, 3u, cpu.address("abs", 0x1928u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9586 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1928u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C9589;
L_0C9589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9589u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9589u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9589u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9589 ASL
    cpu.aslA();
    goto L_0C958A;
L_0C958A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C958A ASL
    cpu.aslA();
    goto L_0C958B;
L_0C958B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C958B ASL
    cpu.aslA();
    goto L_0C958C;
L_0C958C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Cu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Cu, 4u, 3u, cpu.address("abs", 0x4313u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C958C ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x4313u), cpu.m8?8:16));
    goto L_0C958F;
L_0C958F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Fu, 4u, 3u, cpu.address("abs", 0x4313u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C958F STA
    hw.write(cpu.address("abs", 0x4313u), cpu.a, cpu.m8?8:16);
    goto L_0C9592;
L_0C9592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9592u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9592u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9592u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9592 LDA
    cpu.setA(0x2u, 8);
    goto L_0C9594;
L_0C9594:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9594u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9594u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9594u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9594 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_0C9597;
L_0C9597:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9597u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9597u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9597u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9597 LDA
    cpu.setA(0x80u, 8);
    goto L_0C9599;
L_0C9599:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9599u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9599u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9599u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C9599 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_0C959C;
L_0C959C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C959C LDA
    cpu.setA(0xC0u, 8);
    goto L_0C959E;
L_0C959E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Eu, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C959E STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_0C95A1;
L_0C95A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C95A1 LDA
    cpu.setA(0x34u, 8);
    goto L_0C95A3;
L_0C95A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A3u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C95A3 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_0C95A6;
L_0C95A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C95A6 LDY
    cpu.setY(0x6u, 8);
    goto L_0C95A8;
L_0C95A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A8u, 4u + ((((0x9560u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9560u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C95A8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9560u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C95AB;
L_0C95AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95ABu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95ABu, 5u, 3u, cpu.address("absy", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C95AB STA
    hw.write(cpu.address("absy", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_0C95AE;
L_0C95AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95AEu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C95AE DEY
    cpu.decReg('Y');
    goto L_0C95AF;
L_0C95AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95AFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C95AF BPL -> $0C95A8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0C95A8; }
    goto L_0C95B1;
L_0C95B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B1u, 4u, 3u, cpu.address("abs", 0x1928u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C95B1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1928u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0C95B4;
L_0C95B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C95B4 ASL
    cpu.aslA();
    goto L_0C95B5;
L_0C95B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C95B5 ASL
    cpu.aslA();
    goto L_0C95B6;
L_0C95B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C95B6 ASL
    cpu.aslA();
    goto L_0C95B7;
L_0C95B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B7u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B7u, 4u, 3u, cpu.address("abs", 0x4313u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C95B7 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x4313u), cpu.m8?8:16));
    goto L_0C95BA;
L_0C95BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BAu, 4u, 3u, cpu.address("abs", 0x4313u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C95BA STA
    hw.write(cpu.address("abs", 0x4313u), cpu.a, cpu.m8?8:16);
    goto L_0C95BD;
L_0C95BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C95BD LDA
    cpu.setA(0x2u, 8);
    goto L_0C95BF;
L_0C95BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BFu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C95BF STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_0C95C2;
L_0C95C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C2u, 4u, 3u, cpu.address("abs", 0x1FFEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0C95C2 STZ
    hw.write(cpu.address("abs", 0x1FFEu), 0, cpu.m8?8:16);
    goto L_0C95C5;
L_0C95C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C5u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0C95C5 PLB
    cpu.pop("PLB", hw);
    goto L_0C95C6;
L_0C95C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C6u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0C95C6 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x0C95C6u);return;} hw.unresolvedReturn(0x0C95C6u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0DA87D_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DA87Du: goto L_0DA87D;
    case 0x0DA87Fu: goto L_0DA87F;
    case 0x0DA880u: goto L_0DA880;
    case 0x0DA881u: goto L_0DA881;
    case 0x0DA883u: goto L_0DA883;
    case 0x0DA884u: goto L_0DA884;
    case 0x0DA887u: goto L_0DA887;
    case 0x0DA88Bu: goto L_0DA88B;
    case 0x0DA88Du: goto L_0DA88D;
    case 0x0DA890u: goto L_0DA890;
    case 0x0DA893u: goto L_0DA893;
    case 0x0DA897u: goto L_0DA897;
    case 0x0DA899u: goto L_0DA899;
    case 0x0DA89Cu: goto L_0DA89C;
    case 0x0DA89Fu: goto L_0DA89F;
    case 0x0DA8A3u: goto L_0DA8A3;
    case 0x0DA8A5u: goto L_0DA8A5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DA87D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA87D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DA87F;
L_0DA87F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA87F TXA
    cpu.transfer("TXA");
    goto L_0DA880;
L_0DA880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA880u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA880u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA880 SEC
    cpu.setFlag('C', true);
    goto L_0DA881;
L_0DA881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA881u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA881u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA881 SBC
    cpu.sbc(0x95u);
    goto L_0DA883;
L_0DA883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA883u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA883u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA883u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA883 TAX
    cpu.transfer("TAX");
    goto L_0DA884;
L_0DA884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA884 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xA886u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA887u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DA884u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA887;
L_0DA887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA887u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA887u,0x0DA887u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA887u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA887u, 5u, 4u, ((0x0DA877u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA887 LDA
    cpu.loadA(hw.readW(((0xDA877u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA88B;
L_0DA88B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Bu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DA88B STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DA88D;
L_0DA88D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Du, 6u, 3u, cpu.address("abs", 0xA82Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA88D JSR -> $0DA82A stack real
    { cpu.push16Value(hw,0xA88Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA890u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA82Au), 0x0DA88Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA890;
L_0DA890:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA890u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA890u,0x0DA890u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA890u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA890u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA890 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xA892u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA893u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DA890u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA893;
L_0DA893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA893u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA893u,0x0DA893u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA893u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA893u, 5u, 4u, ((0x0DA879u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA893 LDA
    cpu.loadA(hw.readW(((0xDA879u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA897;
L_0DA897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DA897 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DA899;
L_0DA899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA899u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA899u, 6u, 3u, cpu.address("abs", 0xA82Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA899 JSR -> $0DA82A stack real
    { cpu.push16Value(hw,0xA89Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA89Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA82Au), 0x0DA899u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA89C;
L_0DA89C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA89Cu,0x0DA89Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Cu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA89C JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xA89Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA89Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DA89Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA89F;
L_0DA89F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA89Fu,0x0DA89Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Fu, 5u, 4u, ((0x0DA87Bu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA89F LDA
    cpu.loadA(hw.readW(((0xDA87Bu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA8A3;
L_0DA8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A3u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A3u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DA8A3 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DA8A5;
L_0DA8A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA8A5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA8A5u);return;} hw.unresolvedReturn(0x0DA8A5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DA87D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DA87Du: goto L_0DA87D;
    case 0x0DA87Fu: goto L_0DA87F;
    case 0x0DA880u: goto L_0DA880;
    case 0x0DA881u: goto L_0DA881;
    case 0x0DA883u: goto L_0DA883;
    case 0x0DA884u: goto L_0DA884;
    case 0x0DA887u: goto L_0DA887;
    case 0x0DA88Bu: goto L_0DA88B;
    case 0x0DA88Du: goto L_0DA88D;
    case 0x0DA890u: goto L_0DA890;
    case 0x0DA893u: goto L_0DA893;
    case 0x0DA897u: goto L_0DA897;
    case 0x0DA899u: goto L_0DA899;
    case 0x0DA89Cu: goto L_0DA89C;
    case 0x0DA89Fu: goto L_0DA89F;
    case 0x0DA8A3u: goto L_0DA8A3;
    case 0x0DA8A5u: goto L_0DA8A5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DA87D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA87D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DA87F;
L_0DA87F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA87F TXA
    cpu.transfer("TXA");
    goto L_0DA880;
L_0DA880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA880u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA880u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA880 SEC
    cpu.setFlag('C', true);
    goto L_0DA881;
L_0DA881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA881u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA881u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA881 SBC
    cpu.sbc(0x95u);
    goto L_0DA883;
L_0DA883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA883u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA883u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA883u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA883 TAX
    cpu.transfer("TAX");
    goto L_0DA884;
L_0DA884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA884 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xA886u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA887u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DA884u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA887;
L_0DA887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA887u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA887u,0x0DA887u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA887u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA887u, 5u, 4u, ((0x0DA877u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA887 LDA
    cpu.loadA(hw.readW(((0xDA877u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA88B;
L_0DA88B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Bu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DA88B STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DA88D;
L_0DA88D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Du, 6u, 3u, cpu.address("abs", 0xA82Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA88D JSR -> $0DA82A stack real
    { cpu.push16Value(hw,0xA88Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA890u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA82Au), 0x0DA88Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA890;
L_0DA890:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA890u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA890u,0x0DA890u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA890u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA890u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA890 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xA892u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA893u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DA890u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA893;
L_0DA893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA893u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA893u,0x0DA893u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA893u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA893u, 5u, 4u, ((0x0DA879u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA893 LDA
    cpu.loadA(hw.readW(((0xDA879u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA897;
L_0DA897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DA897 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DA899;
L_0DA899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA899u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA899u, 6u, 3u, cpu.address("abs", 0xA82Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA899 JSR -> $0DA82A stack real
    { cpu.push16Value(hw,0xA89Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA89Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA82Au), 0x0DA899u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA89C;
L_0DA89C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA89Cu,0x0DA89Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Cu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA89C JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xA89Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA89Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DA89Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA89F;
L_0DA89F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA89Fu,0x0DA89Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Fu, 5u, 4u, ((0x0DA87Bu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA89F LDA
    cpu.loadA(hw.readW(((0xDA87Bu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA8A3;
L_0DA8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A3u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A3u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DA8A3 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DA8A5;
L_0DA8A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA8A5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA8A5u);return;} hw.unresolvedReturn(0x0DA8A5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DA987_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DA987u: goto L_0DA987;
    case 0x0DA989u: goto L_0DA989;
    case 0x0DA98Bu: goto L_0DA98B;
    case 0x0DA98Du: goto L_0DA98D;
    case 0x0DA98Fu: goto L_0DA98F;
    case 0x0DA991u: goto L_0DA991;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DA987:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA987u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA987u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA987u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA987 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA989;
L_0DA989:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA989u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA989u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA989u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA989 ADC
    cpu.adc(0x0u);
    goto L_0DA98B;
L_0DA98B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA98Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA98B STA
    hw.write(cpu.address("dp", 0x6Cu), cpu.a, cpu.m8?8:16);
    goto L_0DA98D;
L_0DA98D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA98Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA98D STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_0DA98F;
L_0DA98F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA98Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA98Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA98F STA
    hw.write(cpu.address("dp", 0x5u), cpu.a, cpu.m8?8:16);
    goto L_0DA991;
L_0DA991:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA991u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA991u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA991u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA991 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA991u);return;} hw.unresolvedReturn(0x0DA991u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DECC9_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DECC9u: goto L_0DECC9;
    case 0x0DECCAu: goto L_0DECCA;
    case 0x0DECCBu: goto L_0DECCB;
    case 0x0DECCDu: goto L_0DECCD;
    case 0x0DECCEu: goto L_0DECCE;
    case 0x0DECD0u: goto L_0DECD0;
    case 0x0DECD2u: goto L_0DECD2;
    case 0x0DECD4u: goto L_0DECD4;
    case 0x0DECD6u: goto L_0DECD6;
    case 0x0DECD8u: goto L_0DECD8;
    case 0x0DECDAu: goto L_0DECDA;
    case 0x0DECDBu: goto L_0DECDB;
    case 0x0DECDCu: goto L_0DECDC;
    case 0x0DECDDu: goto L_0DECDD;
    case 0x0DECDEu: goto L_0DECDE;
    case 0x0DECE0u: goto L_0DECE0;
    case 0x0DECE3u: goto L_0DECE3;
    case 0x0DECE6u: goto L_0DECE6;
    case 0x0DECE8u: goto L_0DECE8;
    case 0x0DECEAu: goto L_0DECEA;
    case 0x0DECEDu: goto L_0DECED;
    case 0x0DECF1u: goto L_0DECF1;
    case 0x0DECF4u: goto L_0DECF4;
    case 0x0DECF6u: goto L_0DECF6;
    case 0x0DECF8u: goto L_0DECF8;
    case 0x0DECFAu: goto L_0DECFA;
    case 0x0DECFDu: goto L_0DECFD;
    case 0x0DED00u: goto L_0DED00;
    case 0x0DED02u: goto L_0DED02;
    case 0x0DED04u: goto L_0DED04;
    case 0x0DED06u: goto L_0DED06;
    case 0x0DED08u: goto L_0DED08;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DECC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECC9u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECC9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECC9 TXA
    cpu.transfer("TXA");
    goto L_0DECCA;
L_0DECCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECCAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECCAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECCA SEC
    cpu.setFlag('C', true);
    goto L_0DECCB;
L_0DECCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECCBu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECCB SBC
    cpu.sbc(0x34u);
    goto L_0DECCD;
L_0DECCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECCDu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECCDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECCD TAX
    cpu.transfer("TAX");
    goto L_0DECCE;
L_0DECCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECCEu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECCEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECCE LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DECD0;
L_0DECD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECD0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECD0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECD0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DECD2;
L_0DECD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECD2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECD2 AND
    cpu.logicAnd(0xFu);
    goto L_0DECD4;
L_0DECD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECD4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECD4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECD4 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DECD6;
L_0DECD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECD6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECD6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECD6 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DECD8;
L_0DECD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECD8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECD8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECD8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DECDA;
L_0DECDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECDAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECDA LSR
    cpu.lsrA();
    goto L_0DECDB;
L_0DECDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECDBu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECDB LSR
    cpu.lsrA();
    goto L_0DECDC;
L_0DECDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECDCu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECDC LSR
    cpu.lsrA();
    goto L_0DECDD;
L_0DECDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECDDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECDDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECDD LSR
    cpu.lsrA();
    goto L_0DECDE;
L_0DECDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECDEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECDEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECDE STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DECE0;
L_0DECE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECE0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECE0u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DECE0 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xECE2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xECE3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DECE0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DECE3;
L_0DECE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECE3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xECE3u,0x0DECE3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECE3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECE3u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DECE3 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xECE5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xECE6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DECE3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DECE6;
L_0DECE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECE6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xECE6u,0x0DECE6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECE6u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECE6 CPX
    cpu.compareX(0x1u);
    goto L_0DECE8;
L_0DECE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECE8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECE8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECE8 BNE -> $0DECED
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DECED; }
    goto L_0DECEA;
L_0DECEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECEAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECEAu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DECEA JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xECECu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xECEDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DECEAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DECED;
L_0DECED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECEDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xECEDu,0x0DECEDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECEDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECEDu, 5u, 4u, ((0x0DECC6u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECED LDA
    cpu.loadA(hw.readW(((0xDECC6u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DECF1;
L_0DECF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECF1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECF1u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DECF1 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xECF3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xECF4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DECF1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DECF4;
L_0DECF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECF4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xECF4u,0x0DECF4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECF4u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECF4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECF4 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DECF6;
L_0DECF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECF6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECF6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECF6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DECF8;
L_0DECF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECF8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DECF8 BPL -> $0DECE3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DECE3; }
    goto L_0DECFA;
L_0DECFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECFAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECFAu, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DECFA JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xECFCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xECFDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DECFAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DECFD;
L_0DECFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECFDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xECFDu,0x0DECFDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECFDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECFDu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DECFD JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xECFFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xED00u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DECFDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DED00;
L_0DED00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED00u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED00u,0x0DED00u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED00u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED00u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED00 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DED02;
L_0DED02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED02u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED02u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED02 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DED04;
L_0DED04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED04u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED04u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED04 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DED06;
L_0DED06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED06u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DED06 BPL -> $0DECE3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DECE3; }
    goto L_0DED08;
L_0DED08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED08u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED08u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DED08 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DED08u);return;} hw.unresolvedReturn(0x0DED08u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_808D0F_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808CA0u: goto L_808CA0;
    case 0x808CA1u: goto L_808CA1;
    case 0x808CA2u: goto L_808CA2;
    case 0x808CA3u: goto L_808CA3;
    case 0x808CA6u: goto L_808CA6;
    case 0x808CA7u: goto L_808CA7;
    case 0x808CA8u: goto L_808CA8;
    case 0x808CA9u: goto L_808CA9;
    case 0x808CACu: goto L_808CAC;
    case 0x808CAFu: goto L_808CAF;
    case 0x808CB3u: goto L_808CB3;
    case 0x808CB6u: goto L_808CB6;
    case 0x808CB7u: goto L_808CB7;
    case 0x808CBAu: goto L_808CBA;
    case 0x808CBBu: goto L_808CBB;
    case 0x808CBEu: goto L_808CBE;
    case 0x808CBFu: goto L_808CBF;
    case 0x808D0Fu: goto L_808D0F;
    case 0x808D10u: goto L_808D10;
    case 0x808D11u: goto L_808D11;
    case 0x808D13u: goto L_808D13;
    case 0x808D16u: goto L_808D16;
    case 0x808D17u: goto L_808D17;
    case 0x808D19u: goto L_808D19;
    case 0x808D1Bu: goto L_808D1B;
    case 0x808D1Eu: goto L_808D1E;
    case 0x808D20u: goto L_808D20;
    case 0x808D23u: goto L_808D23;
    case 0x808D25u: goto L_808D25;
    case 0x808D28u: goto L_808D28;
    case 0x808D2Au: goto L_808D2A;
    case 0x808D2Du: goto L_808D2D;
    case 0x808D2Fu: goto L_808D2F;
    case 0x808D32u: goto L_808D32;
    case 0x808D35u: goto L_808D35;
    case 0x808D36u: goto L_808D36;
    case 0x808D38u: goto L_808D38;
    case 0x808D3Au: goto L_808D3A;
    case 0x808D3Du: goto L_808D3D;
    case 0x808D3Fu: goto L_808D3F;
    case 0x808D42u: goto L_808D42;
    case 0x808D44u: goto L_808D44;
    case 0x808D47u: goto L_808D47;
    case 0x808D49u: goto L_808D49;
    case 0x808D4Cu: goto L_808D4C;
    case 0x808D4Eu: goto L_808D4E;
    case 0x808D51u: goto L_808D51;
    case 0x808D54u: goto L_808D54;
    case 0x808D55u: goto L_808D55;
    case 0x808D57u: goto L_808D57;
    case 0x808D59u: goto L_808D59;
    case 0x808D5Cu: goto L_808D5C;
    case 0x808D5Eu: goto L_808D5E;
    case 0x808D61u: goto L_808D61;
    case 0x808D63u: goto L_808D63;
    case 0x808D66u: goto L_808D66;
    case 0x808D68u: goto L_808D68;
    case 0x808D6Bu: goto L_808D6B;
    case 0x808D6Du: goto L_808D6D;
    case 0x808D70u: goto L_808D70;
    case 0x808D73u: goto L_808D73;
    case 0x808D74u: goto L_808D74;
    case 0x808D76u: goto L_808D76;
    case 0x808D78u: goto L_808D78;
    case 0x808D7Bu: goto L_808D7B;
    case 0x808D7Du: goto L_808D7D;
    case 0x808D7Fu: goto L_808D7F;
    case 0x808D82u: goto L_808D82;
    case 0x808D85u: goto L_808D85;
    case 0x808D86u: goto L_808D86;
    case 0x808D87u: goto L_808D87;
    case 0x808D88u: goto L_808D88;
    case 0x808D8Au: goto L_808D8A;
    case 0x808D8Cu: goto L_808D8C;
    case 0x808D8Fu: goto L_808D8F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808CA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA0 SEC
    cpu.setFlag('C', true);
    goto L_808CA1;
L_808CA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA1 LSR
    cpu.lsrA();
    goto L_808CA2;
L_808CA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA2 SEC
    cpu.setFlag('C', true);
    goto L_808CA3;
L_808CA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $808CA3 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CA5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CA6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x808CA3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808CA6;
L_808CA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CA6u,0x808CA6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA6 SEC
    cpu.setFlag('C', true);
    goto L_808CA7;
L_808CA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA7 LSR
    cpu.lsrA();
    goto L_808CA8;
L_808CA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u,cpu,0x78u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA8 SEI
    cpu.setFlag('I', true);
    goto L_808CA9;
L_808CA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x3D38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $808CA9 JSR (3D38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x3D38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CACu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x808CA9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808CAC;
L_808CAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CACu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CACu,0x808CACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu, 4u + ((((0x3C3Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x3C3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CAC BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x3C3Eu), cpu.m8?8:16), false);
    goto L_808CAF;
L_808CAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu, 5u, 4u, ((0x38FC3Cu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CAF AND
    cpu.logicAnd(hw.readW(((0x38FC3Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_808CB3;
L_808CB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB3u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB3u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $808CB3 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CB6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x808CB3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808CB6;
L_808CB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CB6u,0x808CB6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CB6 SEC
    cpu.setFlag('C', true);
    goto L_808CB7;
L_808CB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u,cpu,0x2Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u, 6u, 3u, cpu.address("abs", 0x263Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CB7 ROL
    cpu.rolMem(hw, cpu.address("abs", 0x263Cu), cpu.m8?8:16);
    goto L_808CBA;
L_808CBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CBA SEC
    cpu.setFlag('C', true);
    goto L_808CBB;
L_808CBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBBu,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBBu, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $808CBB JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CBDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CBEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x808CBBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808CBE;
L_808CBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CBEu,0x808CBEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CBE SEC
    cpu.setFlag('C', true);
    goto L_808CBF;
L_808CBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBFu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBFu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $808CBF BRK
    hw.partial(0x808CBFu, "BRK"); return;
L_808D0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D0F ASL
    cpu.aslMem(hw, cpu.address("dp", 0xBDu), cpu.m8?8:16);
    goto L_808D11;
L_808D10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u, 4u + ((((0x8D90u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8D90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D10 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8D90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808D13;
L_808D11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D11u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D11 BCC -> $808CA0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_808CA0; }
    goto L_808D13;
L_808D13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D13 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_808D16;
L_808D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D16 DEX
    cpu.decReg('X');
    goto L_808D17;
L_808D17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D17u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D17 BPL -> $808D10
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808D10; }
    goto L_808D19;
L_808D19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D19 LDA
    cpu.setA(0x2u, 8);
    goto L_808D1B;
L_808D1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Bu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D1B STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_808D1E;
L_808D1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D1E LDA
    cpu.setA(0x80u, 8);
    goto L_808D20;
L_808D20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D20u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D20u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D20 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_808D23;
L_808D23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D23u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D23 LDA
    cpu.setA(0x42u, 8);
    goto L_808D25;
L_808D25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D25u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D25u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D25 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_808D28;
L_808D28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D28u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D28 LDA
    cpu.setA(0x50u, 8);
    goto L_808D2A;
L_808D2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D2A STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_808D2D;
L_808D2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D2D LDX
    cpu.setX(0x6u, 8);
    goto L_808D2F;
L_808D2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Fu, 4u + ((((0x8D97u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8D97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D2F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8D97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808D32;
L_808D32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D32u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D32u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D32 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_808D35;
L_808D35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D35u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D35 DEX
    cpu.decReg('X');
    goto L_808D36;
L_808D36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D36u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D36 BPL -> $808D2F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808D2F; }
    goto L_808D38;
L_808D38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D38u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D38 LDA
    cpu.setA(0x2u, 8);
    goto L_808D3A;
L_808D3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Au, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D3A STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_808D3D;
L_808D3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D3D LDA
    cpu.setA(0x80u, 8);
    goto L_808D3F;
L_808D3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D3F STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_808D42;
L_808D42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D42u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D42 LDA
    cpu.setA(0x63u, 8);
    goto L_808D44;
L_808D44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D44 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_808D47;
L_808D47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D47u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D47 LDA
    cpu.setA(0x50u, 8);
    goto L_808D49;
L_808D49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D49u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D49u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D49 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_808D4C;
L_808D4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D4C LDX
    cpu.setX(0x6u, 8);
    goto L_808D4E;
L_808D4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu, 4u + ((((0x8D9Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8D9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D4E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8D9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808D51;
L_808D51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D51u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D51u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D51 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_808D54;
L_808D54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D54u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D54 DEX
    cpu.decReg('X');
    goto L_808D55;
L_808D55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D55u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D55 BPL -> $808D4E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808D4E; }
    goto L_808D57;
L_808D57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D57u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D57 LDA
    cpu.setA(0x2u, 8);
    goto L_808D59;
L_808D59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D59u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D59u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D59 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_808D5C;
L_808D5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D5C LDA
    cpu.setA(0x80u, 8);
    goto L_808D5E;
L_808D5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Eu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D5E STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_808D61;
L_808D61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D61u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D61 LDA
    cpu.setA(0x8Eu, 8);
    goto L_808D63;
L_808D63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D63u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D63u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D63 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_808D66;
L_808D66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D66u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D66 LDA
    cpu.setA(0x50u, 8);
    goto L_808D68;
L_808D68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D68u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D68u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D68 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_808D6B;
L_808D6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D6B LDX
    cpu.setX(0x6u, 8);
    goto L_808D6D;
L_808D6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Du, 4u + ((((0x8DA5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8DA5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D6D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8DA5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808D70;
L_808D70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D70u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D70u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D70 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_808D73;
L_808D73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D73 DEX
    cpu.decReg('X');
    goto L_808D74;
L_808D74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D74u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D74 BPL -> $808D6D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808D6D; }
    goto L_808D76;
L_808D76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D76 LDA
    cpu.setA(0x2u, 8);
    goto L_808D78;
L_808D78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D78 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_808D7B;
L_808D7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D7B LDX
    cpu.setX(0x36u, 8);
    goto L_808D7D;
L_808D7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D7D LDY
    cpu.setY(0x6Cu, 8);
    goto L_808D7F;
L_808D7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu, 4u + ((((0x8C89u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8C89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D7F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8C89u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808D82;
L_808D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u, 5u, 3u, cpu.address("absx", 0x0EF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D82 STA
    hw.write(cpu.address("absx", 0xEF9u), cpu.a, cpu.m8?8:16);
    goto L_808D85;
L_808D85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D85 DEY
    cpu.decReg('Y');
    goto L_808D86;
L_808D86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D86u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D86u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D86 DEY
    cpu.decReg('Y');
    goto L_808D87;
L_808D87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D87 DEX
    cpu.decReg('X');
    goto L_808D88;
L_808D88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D88 BPL -> $808D7F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808D7F; }
    goto L_808D8A;
L_808D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D8A LDA
    cpu.setA(0x28u, 8);
    goto L_808D8C;
L_808D8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu, 4u, 3u, cpu.address("abs", 0x0F30u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D8C STA
    hw.write(cpu.address("abs", 0xF30u), cpu.a, cpu.m8?8:16);
    goto L_808D8F;
L_808D8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808D8F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x808D8Fu);return;} hw.unresolvedReturn(0x808D8Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

