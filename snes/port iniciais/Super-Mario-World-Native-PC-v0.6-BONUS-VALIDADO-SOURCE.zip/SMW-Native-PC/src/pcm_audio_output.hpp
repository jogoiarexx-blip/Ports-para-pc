#pragma once
// Host PCM transport only. Does not read or mutate SNES CPU/APU/DSP state.
// 16-bit interleaved stereo, 32000 Hz; no additional dependencies on Windows.
#include <array>
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <string>
#include <cstdlib>
#include <utility>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <mmsystem.h>
#endif

class PcmAudioOutput {
public:
  static constexpr unsigned rate=32000,channels=2,blockFrames=512,blocks=12;
  std::uint64_t framesGenerated{},framesNonzero{},framesQueued{},framesDropped{},waveFrames{};
  unsigned peak{};
  bool liveRequested{},liveReady{},liveEverOpened{},wavRequested{},wavReady{},wavEverOpened{};
  unsigned gainPercent{100};
  std::string deviceError;
  PcmAudioOutput()=default;
  PcmAudioOutput(const PcmAudioOutput&)=delete;
  PcmAudioOutput& operator=(const PcmAudioOutput&)=delete;
  ~PcmAudioOutput(){finish();}

  void start(bool live,bool saveWav,const std::string&path="forja65-native-audio.wav"){
    finish();framesGenerated=framesNonzero=framesQueued=framesDropped=waveFrames=0;
    peak=0;deviceError.clear();liveRequested=live;wavRequested=saveWav;
    liveEverOpened=wavEverOpened=false;
    if(const char*v=std::getenv("FORJA65_AUDIO_GAIN")){
      char*end=nullptr;const long n=std::strtol(v,&end,10);
      gainPercent=(end&&*end=='\0'&&n>=0&&n<=400)?unsigned(n):100u;
    }else gainPercent=100u;
    if(saveWav){wav.open(path,std::ios::binary|std::ios::trunc);if(wav){writeWavHeader(0);wavReady=bool(wav);wavEverOpened=wavReady;}else deviceError="Nao foi possivel abrir o arquivo WAV";}
#ifdef _WIN32
    if(live){
      WAVEFORMATEX fmt{};fmt.wFormatTag=WAVE_FORMAT_PCM;fmt.nChannels=channels;
      fmt.nSamplesPerSec=rate;fmt.wBitsPerSample=16;fmt.nBlockAlign=4;
      fmt.nAvgBytesPerSec=rate*4;
      const MMRESULT result=waveOutOpen(&device,WAVE_MAPPER,&fmt,0,0,CALLBACK_NULL);
      if(result==MMSYSERR_NOERROR){
        liveReady=true;
        for(auto&b:buffers){
          b.hdr.lpData=reinterpret_cast<LPSTR>(b.samples.data());
          b.hdr.dwBufferLength=sizeof(b.samples);
          const MMRESULT prep=waveOutPrepareHeader(device,&b.hdr,sizeof(b.hdr));
          if(prep!=MMSYSERR_NOERROR){deviceError="waveOutPrepareHeader falhou ("+std::to_string(prep)+")";liveReady=false;break;}
          b.prepared=true;
        }
        if(!liveReady)closeDevice();else liveEverOpened=true;
      }else{deviceError="waveOutOpen falhou ("+std::to_string(result)+")";device=nullptr;}
    }
#else
    if(live)deviceError="Reproducao em tempo real implementada somente no Windows";
#endif
  }
  void push(std::int16_t left,std::int16_t right){
    if(!liveReady&&!wavReady)return;
    const auto gain=[this](std::int16_t q){
      const int v=int(q)*int(gainPercent)/100;
      return std::int16_t(std::clamp(v,-32768,32767));
    };
    left=gain(left);right=gain(right);
    pending[pendingFrames*2]=left;pending[pendingFrames*2+1]=right;
    ++pendingFrames;++framesGenerated;
    const auto abs16=[](std::int16_t x){return x==-32768?32768u:unsigned(x<0?-int(x):int(x));};
    peak=std::max({peak,abs16(left),abs16(right)});
    if(left||right)++framesNonzero;
    if(pendingFrames==blockFrames)flush(false);
  }
  void finish(){
    if(liveReady||wavReady)flush(true);
#ifdef _WIN32
    closeDevice();
#endif
    if(wav.is_open()){
      wav.seekp(0,std::ios::beg);writeWavHeader(waveFrames*4);
      wav.close();
    }
    liveReady=wavReady=false;
  }
private:
  std::array<std::int16_t,blockFrames*channels> pending{};
  unsigned pendingFrames{};
  std::ofstream wav;
#ifdef _WIN32
  HWAVEOUT device{};
  struct Buffer {std::array<std::int16_t,blockFrames*channels> samples{};WAVEHDR hdr{};bool prepared{},submitted{};};
  std::array<Buffer,blocks> buffers{};
  unsigned nextSlot{};
  void closeDevice(){
    if(!device)return;
    waveOutReset(device);
    for(auto&b:buffers){if(b.prepared)waveOutUnprepareHeader(device,&b.hdr,sizeof(b.hdr));b.prepared=b.submitted=false;b.hdr.dwFlags=0;}
    waveOutClose(device);device=nullptr;
  }
#endif
  void flush(bool partial){
    if(!pendingFrames)return;
    const unsigned valid=pendingFrames;
    if(wavReady){
      wav.write(reinterpret_cast<const char*>(pending.data()),std::streamsize(valid*channels*sizeof(std::int16_t)));
      if(wav)waveFrames+=valid;else {wavReady=false;deviceError="Erro gravando WAV";}
    }
#ifdef _WIN32
    if(liveReady){
      // Nonblocking. If all device buffers are occupied, drop this block
      // rather than stalling the CPU or building an unlimited PCM queue.
      Buffer*chosen=nullptr;
      for(unsigned n=0;n<blocks;n++){
        auto&b=buffers[(nextSlot+n)%blocks];
        if(!b.submitted||(b.hdr.dwFlags&WHDR_DONE)){
          chosen=&b;nextSlot=(nextSlot+n+1)%blocks;break;
        }
      }
      if(chosen){
        std::copy_n(pending.begin(),valid*channels,chosen->samples.begin());
        // Padding is only necessary on shutdown; normal writes are full.
        std::fill(chosen->samples.begin()+valid*channels,chosen->samples.end(),0);
        chosen->hdr.dwBufferLength=partial?valid*4u:blockFrames*4u;
        if(waveOutWrite(device,&chosen->hdr,sizeof(chosen->hdr))==MMSYSERR_NOERROR){
          chosen->submitted=true;framesQueued+=valid;
        }else{framesDropped+=valid;deviceError="waveOutWrite falhou";}
      }else framesDropped+=valid;
    }
#else
    (void)partial;
#endif
    pendingFrames=0;
  }
  void writeWavHeader(std::uint64_t dataBytes){
    const std::uint32_t size=std::uint32_t(std::min<std::uint64_t>(dataBytes,0xFFFFFF00u));
    auto u16=[this](unsigned v){char b[2]={char(v&255),char((v>>8)&255)};wav.write(b,2);};
    auto u32=[this](std::uint32_t v){char b[4]={char(v&255),char((v>>8)&255),char((v>>16)&255),char((v>>24)&255)};wav.write(b,4);};
    wav.write("RIFF",4);u32(36+size);wav.write("WAVEfmt ",8);u32(16);u16(1);u16(channels);u32(rate);u32(rate*4);u16(4);u16(16);wav.write("data",4);u32(size);
  }
};
