#include "generated.hpp"
void sub_008A79_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008A79u: goto L_008A79;
    case 0x008A7Cu: goto L_008A7C;
    case 0x008A7Fu: goto L_008A7F;
    case 0x008A81u: goto L_008A81;
    case 0x008A84u: goto L_008A84;
    case 0x008A86u: goto L_008A86;
    case 0x008A89u: goto L_008A89;
    case 0x008A8Bu: goto L_008A8B;
    case 0x008A8Eu: goto L_008A8E;
    case 0x008A90u: goto L_008A90;
    case 0x008A93u: goto L_008A93;
    case 0x008A95u: goto L_008A95;
    case 0x008A98u: goto L_008A98;
    case 0x008A9Au: goto L_008A9A;
    case 0x008A9Cu: goto L_008A9C;
    case 0x008A9Eu: goto L_008A9E;
    case 0x008AA1u: goto L_008AA1;
    case 0x008AA4u: goto L_008AA4;
    case 0x008AA7u: goto L_008AA7;
    case 0x008AAAu: goto L_008AAA;
    case 0x008AACu: goto L_008AAC;
    case 0x008AAEu: goto L_008AAE;
    case 0x008AB0u: goto L_008AB0;
    case 0x008AB3u: goto L_008AB3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008A79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A79u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A79u, 4u, 3u, cpu.address("abs", 0x2133u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A79 STZ
    hw.write(cpu.address("abs", 0x2133u), 0, cpu.m8?8:16);
    goto L_008A7C;
L_008A7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Cu, 4u, 3u, cpu.address("abs", 0x2106u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A7C STZ
    hw.write(cpu.address("abs", 0x2106u), 0, cpu.m8?8:16);
    goto L_008A7F;
L_008A7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A7F LDA
    cpu.setA(0x23u, 8);
    goto L_008A81;
L_008A81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A81u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A81u, 4u, 3u, cpu.address("abs", 0x2107u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A81 STA
    hw.write(cpu.address("abs", 0x2107u), cpu.a, cpu.m8?8:16);
    goto L_008A84;
L_008A84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A84u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A84 LDA
    cpu.setA(0x33u, 8);
    goto L_008A86;
L_008A86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A86u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A86u, 4u, 3u, cpu.address("abs", 0x2108u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A86 STA
    hw.write(cpu.address("abs", 0x2108u), cpu.a, cpu.m8?8:16);
    goto L_008A89;
L_008A89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A89 LDA
    cpu.setA(0x53u, 8);
    goto L_008A8B;
L_008A8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Bu, 4u, 3u, cpu.address("abs", 0x2109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A8B STA
    hw.write(cpu.address("abs", 0x2109u), cpu.a, cpu.m8?8:16);
    goto L_008A8E;
L_008A8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A8E LDA
    cpu.setA(0x0u, 8);
    goto L_008A90;
L_008A90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A90u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A90u, 4u, 3u, cpu.address("abs", 0x210Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A90 STA
    hw.write(cpu.address("abs", 0x210Bu), cpu.a, cpu.m8?8:16);
    goto L_008A93;
L_008A93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A93u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A93 LDA
    cpu.setA(0x4u, 8);
    goto L_008A95;
L_008A95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A95u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A95u, 4u, 3u, cpu.address("abs", 0x210Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A95 STA
    hw.write(cpu.address("abs", 0x210Cu), cpu.a, cpu.m8?8:16);
    goto L_008A98;
L_008A98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A98u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A98u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A98 STZ
    hw.write(cpu.address("dp", 0x41u), 0, cpu.m8?8:16);
    goto L_008A9A;
L_008A9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A9A STZ
    hw.write(cpu.address("dp", 0x42u), 0, cpu.m8?8:16);
    goto L_008A9C;
L_008A9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A9C STZ
    hw.write(cpu.address("dp", 0x43u), 0, cpu.m8?8:16);
    goto L_008A9E;
L_008A9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Eu, 4u, 3u, cpu.address("abs", 0x212Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A9E STZ
    hw.write(cpu.address("abs", 0x212Au), 0, cpu.m8?8:16);
    goto L_008AA1;
L_008AA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA1u, 4u, 3u, cpu.address("abs", 0x212Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AA1 STZ
    hw.write(cpu.address("abs", 0x212Bu), 0, cpu.m8?8:16);
    goto L_008AA4;
L_008AA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA4u, 4u, 3u, cpu.address("abs", 0x212Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AA4 STZ
    hw.write(cpu.address("abs", 0x212Eu), 0, cpu.m8?8:16);
    goto L_008AA7;
L_008AA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA7u, 4u, 3u, cpu.address("abs", 0x212Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AA7 STZ
    hw.write(cpu.address("abs", 0x212Fu), 0, cpu.m8?8:16);
    goto L_008AAA;
L_008AAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AAA LDA
    cpu.setA(0x2u, 8);
    goto L_008AAC;
L_008AAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AACu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AAC STA
    hw.write(cpu.address("dp", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_008AAE;
L_008AAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AAE LDA
    cpu.setA(0x80u, 8);
    goto L_008AB0;
L_008AB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB0u, 4u, 3u, cpu.address("abs", 0x211Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AB0 STA
    hw.write(cpu.address("abs", 0x211Au), cpu.a, cpu.m8?8:16);
    goto L_008AB3;
L_008AB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008AB3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008AB3u);return;} hw.unresolvedReturn(0x008AB3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_008A79_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008A79u: goto L_008A79;
    case 0x008A7Cu: goto L_008A7C;
    case 0x008A7Fu: goto L_008A7F;
    case 0x008A81u: goto L_008A81;
    case 0x008A84u: goto L_008A84;
    case 0x008A86u: goto L_008A86;
    case 0x008A89u: goto L_008A89;
    case 0x008A8Bu: goto L_008A8B;
    case 0x008A8Eu: goto L_008A8E;
    case 0x008A90u: goto L_008A90;
    case 0x008A93u: goto L_008A93;
    case 0x008A95u: goto L_008A95;
    case 0x008A98u: goto L_008A98;
    case 0x008A9Au: goto L_008A9A;
    case 0x008A9Cu: goto L_008A9C;
    case 0x008A9Eu: goto L_008A9E;
    case 0x008AA1u: goto L_008AA1;
    case 0x008AA4u: goto L_008AA4;
    case 0x008AA7u: goto L_008AA7;
    case 0x008AAAu: goto L_008AAA;
    case 0x008AACu: goto L_008AAC;
    case 0x008AAEu: goto L_008AAE;
    case 0x008AB0u: goto L_008AB0;
    case 0x008AB3u: goto L_008AB3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008A79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A79u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A79u, 4u, 3u, cpu.address("abs", 0x2133u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A79 STZ
    hw.write(cpu.address("abs", 0x2133u), 0, cpu.m8?8:16);
    goto L_008A7C;
L_008A7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Cu, 4u, 3u, cpu.address("abs", 0x2106u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A7C STZ
    hw.write(cpu.address("abs", 0x2106u), 0, cpu.m8?8:16);
    goto L_008A7F;
L_008A7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A7F LDA
    cpu.setA(0x23u, 8);
    goto L_008A81;
L_008A81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A81u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A81u, 4u, 3u, cpu.address("abs", 0x2107u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A81 STA
    hw.write(cpu.address("abs", 0x2107u), cpu.a, cpu.m8?8:16);
    goto L_008A84;
L_008A84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A84u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A84 LDA
    cpu.setA(0x33u, 8);
    goto L_008A86;
L_008A86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A86u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A86u, 4u, 3u, cpu.address("abs", 0x2108u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A86 STA
    hw.write(cpu.address("abs", 0x2108u), cpu.a, cpu.m8?8:16);
    goto L_008A89;
L_008A89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A89 LDA
    cpu.setA(0x53u, 8);
    goto L_008A8B;
L_008A8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Bu, 4u, 3u, cpu.address("abs", 0x2109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A8B STA
    hw.write(cpu.address("abs", 0x2109u), cpu.a, cpu.m8?8:16);
    goto L_008A8E;
L_008A8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A8E LDA
    cpu.setA(0x0u, 8);
    goto L_008A90;
L_008A90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A90u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A90u, 4u, 3u, cpu.address("abs", 0x210Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A90 STA
    hw.write(cpu.address("abs", 0x210Bu), cpu.a, cpu.m8?8:16);
    goto L_008A93;
L_008A93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A93u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A93 LDA
    cpu.setA(0x4u, 8);
    goto L_008A95;
L_008A95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A95u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A95u, 4u, 3u, cpu.address("abs", 0x210Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A95 STA
    hw.write(cpu.address("abs", 0x210Cu), cpu.a, cpu.m8?8:16);
    goto L_008A98;
L_008A98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A98u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A98u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A98 STZ
    hw.write(cpu.address("dp", 0x41u), 0, cpu.m8?8:16);
    goto L_008A9A;
L_008A9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A9A STZ
    hw.write(cpu.address("dp", 0x42u), 0, cpu.m8?8:16);
    goto L_008A9C;
L_008A9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A9C STZ
    hw.write(cpu.address("dp", 0x43u), 0, cpu.m8?8:16);
    goto L_008A9E;
L_008A9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Eu, 4u, 3u, cpu.address("abs", 0x212Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A9E STZ
    hw.write(cpu.address("abs", 0x212Au), 0, cpu.m8?8:16);
    goto L_008AA1;
L_008AA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA1u, 4u, 3u, cpu.address("abs", 0x212Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AA1 STZ
    hw.write(cpu.address("abs", 0x212Bu), 0, cpu.m8?8:16);
    goto L_008AA4;
L_008AA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA4u, 4u, 3u, cpu.address("abs", 0x212Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AA4 STZ
    hw.write(cpu.address("abs", 0x212Eu), 0, cpu.m8?8:16);
    goto L_008AA7;
L_008AA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA7u, 4u, 3u, cpu.address("abs", 0x212Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AA7 STZ
    hw.write(cpu.address("abs", 0x212Fu), 0, cpu.m8?8:16);
    goto L_008AAA;
L_008AAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AAA LDA
    cpu.setA(0x2u, 8);
    goto L_008AAC;
L_008AAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AACu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AAC STA
    hw.write(cpu.address("dp", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_008AAE;
L_008AAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AAE LDA
    cpu.setA(0x80u, 8);
    goto L_008AB0;
L_008AB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB0u, 4u, 3u, cpu.address("abs", 0x211Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AB0 STA
    hw.write(cpu.address("abs", 0x211Au), cpu.a, cpu.m8?8:16);
    goto L_008AB3;
L_008AB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008AB3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008AB3u);return;} hw.unresolvedReturn(0x008AB3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_008A79_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008A79u: goto L_008A79;
    case 0x008A7Cu: goto L_008A7C;
    case 0x008A7Fu: goto L_008A7F;
    case 0x008A81u: goto L_008A81;
    case 0x008A84u: goto L_008A84;
    case 0x008A86u: goto L_008A86;
    case 0x008A89u: goto L_008A89;
    case 0x008A8Bu: goto L_008A8B;
    case 0x008A8Eu: goto L_008A8E;
    case 0x008A90u: goto L_008A90;
    case 0x008A93u: goto L_008A93;
    case 0x008A95u: goto L_008A95;
    case 0x008A98u: goto L_008A98;
    case 0x008A9Au: goto L_008A9A;
    case 0x008A9Cu: goto L_008A9C;
    case 0x008A9Eu: goto L_008A9E;
    case 0x008AA1u: goto L_008AA1;
    case 0x008AA4u: goto L_008AA4;
    case 0x008AA7u: goto L_008AA7;
    case 0x008AAAu: goto L_008AAA;
    case 0x008AACu: goto L_008AAC;
    case 0x008AAEu: goto L_008AAE;
    case 0x008AB0u: goto L_008AB0;
    case 0x008AB3u: goto L_008AB3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008A79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A79u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A79u, 4u, 3u, cpu.address("abs", 0x2133u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A79 STZ
    hw.write(cpu.address("abs", 0x2133u), 0, cpu.m8?8:16);
    goto L_008A7C;
L_008A7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Cu, 4u, 3u, cpu.address("abs", 0x2106u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A7C STZ
    hw.write(cpu.address("abs", 0x2106u), 0, cpu.m8?8:16);
    goto L_008A7F;
L_008A7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A7F LDA
    cpu.setA(0x23u, 8);
    goto L_008A81;
L_008A81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A81u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A81u, 4u, 3u, cpu.address("abs", 0x2107u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A81 STA
    hw.write(cpu.address("abs", 0x2107u), cpu.a, cpu.m8?8:16);
    goto L_008A84;
L_008A84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A84u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A84 LDA
    cpu.setA(0x33u, 8);
    goto L_008A86;
L_008A86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A86u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A86u, 4u, 3u, cpu.address("abs", 0x2108u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A86 STA
    hw.write(cpu.address("abs", 0x2108u), cpu.a, cpu.m8?8:16);
    goto L_008A89;
L_008A89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A89 LDA
    cpu.setA(0x53u, 8);
    goto L_008A8B;
L_008A8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Bu, 4u, 3u, cpu.address("abs", 0x2109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A8B STA
    hw.write(cpu.address("abs", 0x2109u), cpu.a, cpu.m8?8:16);
    goto L_008A8E;
L_008A8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A8E LDA
    cpu.setA(0x0u, 8);
    goto L_008A90;
L_008A90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A90u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A90u, 4u, 3u, cpu.address("abs", 0x210Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A90 STA
    hw.write(cpu.address("abs", 0x210Bu), cpu.a, cpu.m8?8:16);
    goto L_008A93;
L_008A93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A93u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A93 LDA
    cpu.setA(0x4u, 8);
    goto L_008A95;
L_008A95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A95u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A95u, 4u, 3u, cpu.address("abs", 0x210Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A95 STA
    hw.write(cpu.address("abs", 0x210Cu), cpu.a, cpu.m8?8:16);
    goto L_008A98;
L_008A98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A98u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A98u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A98 STZ
    hw.write(cpu.address("dp", 0x41u), 0, cpu.m8?8:16);
    goto L_008A9A;
L_008A9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A9A STZ
    hw.write(cpu.address("dp", 0x42u), 0, cpu.m8?8:16);
    goto L_008A9C;
L_008A9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A9C STZ
    hw.write(cpu.address("dp", 0x43u), 0, cpu.m8?8:16);
    goto L_008A9E;
L_008A9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Eu, 4u, 3u, cpu.address("abs", 0x212Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A9E STZ
    hw.write(cpu.address("abs", 0x212Au), 0, cpu.m8?8:16);
    goto L_008AA1;
L_008AA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA1u, 4u, 3u, cpu.address("abs", 0x212Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AA1 STZ
    hw.write(cpu.address("abs", 0x212Bu), 0, cpu.m8?8:16);
    goto L_008AA4;
L_008AA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA4u, 4u, 3u, cpu.address("abs", 0x212Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AA4 STZ
    hw.write(cpu.address("abs", 0x212Eu), 0, cpu.m8?8:16);
    goto L_008AA7;
L_008AA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA7u, 4u, 3u, cpu.address("abs", 0x212Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AA7 STZ
    hw.write(cpu.address("abs", 0x212Fu), 0, cpu.m8?8:16);
    goto L_008AAA;
L_008AAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AAA LDA
    cpu.setA(0x2u, 8);
    goto L_008AAC;
L_008AAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AACu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AAC STA
    hw.write(cpu.address("dp", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_008AAE;
L_008AAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AAE LDA
    cpu.setA(0x80u, 8);
    goto L_008AB0;
L_008AB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB0u, 4u, 3u, cpu.address("abs", 0x211Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AB0 STA
    hw.write(cpu.address("abs", 0x211Au), cpu.a, cpu.m8?8:16);
    goto L_008AB3;
L_008AB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008AB3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008AB3u);return;} hw.unresolvedReturn(0x008AB3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00961E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0093EAu: goto L_0093EA;
    case 0x0093ECu: goto L_0093EC;
    case 0x0093EFu: goto L_0093EF;
    case 0x0093F1u: goto L_0093F1;
    case 0x0093F4u: goto L_0093F4;
    case 0x0093F7u: goto L_0093F7;
    case 0x0093F9u: goto L_0093F9;
    case 0x0093FCu: goto L_0093FC;
    case 0x00961Eu: goto L_00961E;
    case 0x009620u: goto L_009620;
    case 0x009622u: goto L_009622;
    case 0x009625u: goto L_009625;
    case 0x009627u: goto L_009627;
    case 0x009629u: goto L_009629;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0093EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EA LDA
    cpu.setA(0x1u, 8);
    goto L_0093EC;
L_0093EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ECu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ECu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EC STA
    hw.write(cpu.address("abs", 0xD9Bu), cpu.a, cpu.m8?8:16);
    goto L_0093EF;
L_0093EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EF LDA
    cpu.setA(0x20u, 8);
    goto L_0093F1;
L_0093F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F1u, 6u, 3u, cpu.address("abs", 0x93FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093F1 JSR -> $0093FD stack real
    { cpu.push16Value(hw,0x93F3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93F4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x93FDu), 0x0093F1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0093F4;
L_0093F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93F4u,0x0093F4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u, 6u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F4 INC
    cpu.incMem(hw, cpu.address("abs", 0x100u), cpu.m8?8:16);
    goto L_0093F7;
L_0093F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F7 LDA
    cpu.setA(0x81u, 8);
    goto L_0093F9;
L_0093F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F9 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_0093FC;
L_0093FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093FC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0093FCu);return;} hw.unresolvedReturn(0x0093FCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00961E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x961Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x961Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x961Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00961E LDX
    cpu.setX(0x15u, 8);
    goto L_009620;
L_009620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9620u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9620u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009620 LDY
    cpu.setY(0x2u, 8);
    goto L_009622;
L_009622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9622u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9622u, 6u, 3u, cpu.address("abs", 0x9F29u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009622 JSR -> $009F29 stack real
    { cpu.push16Value(hw,0x9624u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9625u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F29u), 0x009622u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009625;
L_009625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9625u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9625u,0x009625u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9625u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9625u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009625 LDA
    cpu.setA(0x9u, 8);
    goto L_009627;
L_009627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9627u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9627u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009627 STA
    hw.write(cpu.address("dp", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_009629;
L_009629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9629u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9629u, 3u, 3u, cpu.address("abs", 0x93EAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009629 JMP -> $0093EA
    goto L_0093EA;
}

void sub_00A488_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A488u: goto L_00A488;
    case 0x00A48Bu: goto L_00A48B;
    case 0x00A48Eu: goto L_00A48E;
    case 0x00A490u: goto L_00A490;
    case 0x00A492u: goto L_00A492;
    case 0x00A494u: goto L_00A494;
    case 0x00A496u: goto L_00A496;
    case 0x00A499u: goto L_00A499;
    case 0x00A49Au: goto L_00A49A;
    case 0x00A49Du: goto L_00A49D;
    case 0x00A49Fu: goto L_00A49F;
    case 0x00A4A0u: goto L_00A4A0;
    case 0x00A4A2u: goto L_00A4A2;
    case 0x00A4A4u: goto L_00A4A4;
    case 0x00A4A7u: goto L_00A4A7;
    case 0x00A4AAu: goto L_00A4AA;
    case 0x00A4ACu: goto L_00A4AC;
    case 0x00A4AFu: goto L_00A4AF;
    case 0x00A4B0u: goto L_00A4B0;
    case 0x00A4B2u: goto L_00A4B2;
    case 0x00A4B5u: goto L_00A4B5;
    case 0x00A4B7u: goto L_00A4B7;
    case 0x00A4BAu: goto L_00A4BA;
    case 0x00A4BDu: goto L_00A4BD;
    case 0x00A4BEu: goto L_00A4BE;
    case 0x00A4BFu: goto L_00A4BF;
    case 0x00A4C2u: goto L_00A4C2;
    case 0x00A4C3u: goto L_00A4C3;
    case 0x00A4C5u: goto L_00A4C5;
    case 0x00A4C6u: goto L_00A4C6;
    case 0x00A4C8u: goto L_00A4C8;
    case 0x00A4CAu: goto L_00A4CA;
    case 0x00A4CDu: goto L_00A4CD;
    case 0x00A4CFu: goto L_00A4CF;
    case 0x00A4D1u: goto L_00A4D1;
    case 0x00A4D4u: goto L_00A4D4;
    case 0x00A4D7u: goto L_00A4D7;
    case 0x00A4D9u: goto L_00A4D9;
    case 0x00A4DCu: goto L_00A4DC;
    case 0x00A4DFu: goto L_00A4DF;
    case 0x00A4E2u: goto L_00A4E2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A488:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA488u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA488u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA488u, 4u, 3u, cpu.address("abs", 0x0680u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A488 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x680u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00A48B;
L_00A48B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Bu,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Bu, 4u + ((((0xA481u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA481u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A48B LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xA481u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00A48E;
L_00A48E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Eu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A48E STX
    hw.write(cpu.address("dp", 0x2u), cpu.x, cpu.x8?8:16);
    goto L_00A490;
L_00A490:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA490u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA490u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA490u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A490 STZ
    hw.write(cpu.address("dp", 0x1u), 0, cpu.m8?8:16);
    goto L_00A492;
L_00A492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA492u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA492u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA492u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A492 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_00A494;
L_00A494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA494u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA494u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A494 STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_00A496;
L_00A496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA496u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA496u, 4u + ((((0xA480u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA480u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A496 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA480u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A499;
L_00A499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA499u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA499u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A499 XBA
    cpu.xba();
    goto L_00A49A;
L_00A49A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Au, 4u + ((((0xA47Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA47Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A49A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA47Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A49D;
L_00A49D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A49D REP
    cpu.rep(0x10u);
    goto L_00A49F;
L_00A49F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A49F TAY
    cpu.transfer("TAY");
    goto L_00A4A0;
L_00A4A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A0u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A0u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00A4A0 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A4A2;
L_00A4A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4A2 BEQ -> $00A4CF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A4CF; }
    goto L_00A4A4;
L_00A4A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A4u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A4u, 5u, 3u, cpu.address("abs", 0x4324u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4A4 STX
    hw.write(cpu.address("abs", 0x4324u), cpu.x, cpu.x8?8:16);
    goto L_00A4A7;
L_00A4A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A7u, 4u, 3u, cpu.address("abs", 0x4325u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4A7 STA
    hw.write(cpu.address("abs", 0x4325u), cpu.a, cpu.m8?8:16);
    goto L_00A4AA;
L_00A4AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4AA STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_00A4AC;
L_00A4AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ACu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ACu, 4u, 3u, cpu.address("abs", 0x4326u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4AC STZ
    hw.write(cpu.address("abs", 0x4326u), 0, cpu.m8?8:16);
    goto L_00A4AF;
L_00A4AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4AF INY
    cpu.inc('Y');
    goto L_00A4B0;
L_00A4B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B0u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B0u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00A4B0 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A4B2;
L_00A4B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B2u, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4B2 STA
    hw.write(cpu.address("abs", 0x2121u), cpu.a, cpu.m8?8:16);
    goto L_00A4B5;
L_00A4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4B5 REP
    cpu.rep(0x20u);
    goto L_00A4B7;
L_00A4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4B7 LDA
    cpu.setA(0x2200u, 16);
    goto L_00A4BA;
L_00A4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BAu, 5u, 3u, cpu.address("abs", 0x4320u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4BA STA
    hw.write(cpu.address("abs", 0x4320u), cpu.a, cpu.m8?8:16);
    goto L_00A4BD;
L_00A4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BDu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4BD INY
    cpu.inc('Y');
    goto L_00A4BE;
L_00A4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BEu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4BE TYA
    cpu.transfer("TYA");
    goto L_00A4BF;
L_00A4BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BFu, 5u, 3u, cpu.address("abs", 0x4322u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4BF STA
    hw.write(cpu.address("abs", 0x4322u), cpu.a, cpu.m8?8:16);
    goto L_00A4C2;
L_00A4C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4C2 CLC
    cpu.setFlag('C', false);
    goto L_00A4C3;
L_00A4C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C3u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4C3 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16));
    goto L_00A4C5;
L_00A4C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C5u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4C5 TAY
    cpu.transfer("TAY");
    goto L_00A4C6;
L_00A4C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4C6 SEP
    cpu.sep(0x20u);
    goto L_00A4C8;
L_00A4C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4C8 LDA
    cpu.setA(0x4u, 8);
    goto L_00A4CA;
L_00A4CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CAu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4CA STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_00A4CD;
L_00A4CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4CD BRA -> $00A4A0
    goto L_00A4A0;
L_00A4CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4CF SEP
    cpu.sep(0x10u);
    goto L_00A4D1;
L_00A4D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D1u, 6u, 3u, cpu.address("abs", 0xAE47u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A4D1 JSR -> $00AE47 stack real
    { cpu.push16Value(hw,0xA4D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA4D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAE47u), 0x00A4D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A4D4;
L_00A4D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4D4u,0x00A4D4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D4u, 4u, 3u, cpu.address("abs", 0x0680u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4D4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x680u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A4D7;
L_00A4D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4D7 BNE -> $00A4DF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A4DF; }
    goto L_00A4D9;
L_00A4D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D9u, 4u, 3u, cpu.address("abs", 0x0681u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4D9 STZ
    hw.write(cpu.address("abs", 0x681u), 0, cpu.m8?8:16);
    goto L_00A4DC;
L_00A4DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DCu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DCu, 4u, 3u, cpu.address("abs", 0x0682u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4DC STZ
    hw.write(cpu.address("abs", 0x682u), 0, cpu.m8?8:16);
    goto L_00A4DF;
L_00A4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DFu, 4u, 3u, cpu.address("abs", 0x0680u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A4DF STZ
    hw.write(cpu.address("abs", 0x680u), 0, cpu.m8?8:16);
    goto L_00A4E2;
L_00A4E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A4E2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A4E2u);return;} hw.unresolvedReturn(0x00A4E2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00ABC4_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00ABC4u: goto L_00ABC4;
    case 0x00ABC6u: goto L_00ABC6;
    case 0x00ABC8u: goto L_00ABC8;
    case 0x00ABCAu: goto L_00ABCA;
    case 0x00ABCCu: goto L_00ABCC;
    case 0x00ABCEu: goto L_00ABCE;
    case 0x00ABD0u: goto L_00ABD0;
    case 0x00ABD2u: goto L_00ABD2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00ABC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABC4 STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_00ABC6;
L_00ABC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC6u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABC6 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xFu), cpu.m8?8:16);
    goto L_00ABC8;
L_00ABC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC8u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABC8 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_00ABCA;
L_00ABCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABCAu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABCAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABCA ROL
    cpu.rolMem(hw, cpu.address("dp", 0xFu), cpu.m8?8:16);
    goto L_00ABCC;
L_00ABCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABCCu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABCCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABCC ROL
    cpu.rolMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_00ABCE;
L_00ABCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABCEu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABCEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABCE ROL
    cpu.rolMem(hw, cpu.address("dp", 0xFu), cpu.m8?8:16);
    goto L_00ABD0;
L_00ABD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD0u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ABD0 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_00ABD2;
L_00ABD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ABD2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00ABD2u);return;} hw.unresolvedReturn(0x00ABD2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00C47E_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00C47Eu: goto L_00C47E;
    case 0x00C480u: goto L_00C480;
    case 0x00C483u: goto L_00C483;
    case 0x00C485u: goto L_00C485;
    case 0x00C489u: goto L_00C489;
    case 0x00C48Cu: goto L_00C48C;
    case 0x00C48Fu: goto L_00C48F;
    case 0x00C491u: goto L_00C491;
    case 0x00C494u: goto L_00C494;
    case 0x00C496u: goto L_00C496;
    case 0x00C499u: goto L_00C499;
    case 0x00C49Cu: goto L_00C49C;
    case 0x00C49Fu: goto L_00C49F;
    case 0x00C4A1u: goto L_00C4A1;
    case 0x00C4A2u: goto L_00C4A2;
    case 0x00C4A4u: goto L_00C4A4;
    case 0x00C4A7u: goto L_00C4A7;
    case 0x00C4A8u: goto L_00C4A8;
    case 0x00C4A9u: goto L_00C4A9;
    case 0x00C4ABu: goto L_00C4AB;
    case 0x00C4AEu: goto L_00C4AE;
    case 0x00C4B0u: goto L_00C4B0;
    case 0x00C4B2u: goto L_00C4B2;
    case 0x00C4B5u: goto L_00C4B5;
    case 0x00C4B7u: goto L_00C4B7;
    case 0x00C4BAu: goto L_00C4BA;
    case 0x00C4BCu: goto L_00C4BC;
    case 0x00C4BDu: goto L_00C4BD;
    case 0x00C4C0u: goto L_00C4C0;
    case 0x00C4C3u: goto L_00C4C3;
    case 0x00C4C5u: goto L_00C4C5;
    case 0x00C4C7u: goto L_00C4C7;
    case 0x00C4C9u: goto L_00C4C9;
    case 0x00C4CBu: goto L_00C4CB;
    case 0x00C4CEu: goto L_00C4CE;
    case 0x00C4D0u: goto L_00C4D0;
    case 0x00C4D2u: goto L_00C4D2;
    case 0x00C4D4u: goto L_00C4D4;
    case 0x00C4D6u: goto L_00C4D6;
    case 0x00C4D9u: goto L_00C4D9;
    case 0x00C4DBu: goto L_00C4DB;
    case 0x00C4DDu: goto L_00C4DD;
    case 0x00C4DFu: goto L_00C4DF;
    case 0x00C4E2u: goto L_00C4E2;
    case 0x00C4E3u: goto L_00C4E3;
    case 0x00C4E5u: goto L_00C4E5;
    case 0x00C4E6u: goto L_00C4E6;
    case 0x00C4E8u: goto L_00C4E8;
    case 0x00C4EAu: goto L_00C4EA;
    case 0x00C4EDu: goto L_00C4ED;
    case 0x00C4EEu: goto L_00C4EE;
    case 0x00C4F0u: goto L_00C4F0;
    case 0x00C4F1u: goto L_00C4F1;
    case 0x00C4F3u: goto L_00C4F3;
    case 0x00C4F5u: goto L_00C4F5;
    case 0x00C4F8u: goto L_00C4F8;
    case 0x00C4FBu: goto L_00C4FB;
    case 0x00C4FDu: goto L_00C4FD;
    case 0x00C500u: goto L_00C500;
    case 0x00C502u: goto L_00C502;
    case 0x00C504u: goto L_00C504;
    case 0x00C506u: goto L_00C506;
    case 0x00C508u: goto L_00C508;
    case 0x00C50Bu: goto L_00C50B;
    case 0x00C50Du: goto L_00C50D;
    case 0x00C510u: goto L_00C510;
    case 0x00C511u: goto L_00C511;
    case 0x00C513u: goto L_00C513;
    case 0x00C515u: goto L_00C515;
    case 0x00C517u: goto L_00C517;
    case 0x00C519u: goto L_00C519;
    case 0x00C51Cu: goto L_00C51C;
    case 0x00C51Eu: goto L_00C51E;
    case 0x00C521u: goto L_00C521;
    case 0x00C523u: goto L_00C523;
    case 0x00C525u: goto L_00C525;
    case 0x00C527u: goto L_00C527;
    case 0x00C52Au: goto L_00C52A;
    case 0x00C52Cu: goto L_00C52C;
    case 0x00C52Eu: goto L_00C52E;
    case 0x00C530u: goto L_00C530;
    case 0x00C533u: goto L_00C533;
    case 0x00C536u: goto L_00C536;
    case 0x00C539u: goto L_00C539;
    case 0x00C53Bu: goto L_00C53B;
    case 0x00C53Eu: goto L_00C53E;
    case 0x00C541u: goto L_00C541;
    case 0x00C543u: goto L_00C543;
    case 0x00C545u: goto L_00C545;
    case 0x00C547u: goto L_00C547;
    case 0x00C54Au: goto L_00C54A;
    case 0x00C54Cu: goto L_00C54C;
    case 0x00C54Fu: goto L_00C54F;
    case 0x00C551u: goto L_00C551;
    case 0x00C553u: goto L_00C553;
    case 0x00C555u: goto L_00C555;
    case 0x00C557u: goto L_00C557;
    case 0x00C559u: goto L_00C559;
    case 0x00C55Cu: goto L_00C55C;
    case 0x00C55Eu: goto L_00C55E;
    case 0x00C561u: goto L_00C561;
    case 0x00C563u: goto L_00C563;
    case 0x00C566u: goto L_00C566;
    case 0x00C567u: goto L_00C567;
    case 0x00C569u: goto L_00C569;
    case 0x00C56Cu: goto L_00C56C;
    case 0x00C56Eu: goto L_00C56E;
    case 0x00C570u: goto L_00C570;
    case 0x00C572u: goto L_00C572;
    case 0x00C574u: goto L_00C574;
    case 0x00C576u: goto L_00C576;
    case 0x00C585u: goto L_00C585;
    case 0x00C586u: goto L_00C586;
    case 0x00C588u: goto L_00C588;
    case 0x00C589u: goto L_00C589;
    case 0x00C58Au: goto L_00C58A;
    case 0x00C58Eu: goto L_00C58E;
    case 0x00C58Fu: goto L_00C58F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00C47E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC47Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC47Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC47Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C47E STZ
    hw.write(cpu.address("dp", 0x78u), 0, cpu.m8?8:16);
    goto L_00C480;
L_00C480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC480u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC480u, 4u, 3u, cpu.address("abs", 0x13CBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C480 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13CBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C483;
L_00C483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC483u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC483u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C483 BPL -> $00C48C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00C48C; }
    goto L_00C485;
L_00C485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC485u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC485u, 8u, 4u, 0x01C580u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00C485 JSL -> $01C580 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC488u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC489u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01C580u, 0x00C485u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00C489;
L_00C489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC489u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC489u,0x00C489u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC489u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC489u, 4u, 3u, cpu.address("abs", 0x13CBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C489 STZ
    hw.write(cpu.address("abs", 0x13CBu), 0, cpu.m8?8:16);
    goto L_00C48C;
L_00C48C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC48Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC48Cu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC48Cu, 4u, 3u, cpu.address("abs", 0x1434u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C48C LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1434u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00C48F;
L_00C48F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC48Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC48Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC48Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C48F BEQ -> $00C4BA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C4BA; }
    goto L_00C491;
L_00C491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC491u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC491u, 4u, 3u, cpu.address("abs", 0x13FBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C491 STY
    hw.write(cpu.address("abs", 0x13FBu), cpu.y, cpu.x8?8:16);
    goto L_00C494;
L_00C494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC494u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC494u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C494 STY
    hw.write(cpu.address("dp", 0x9Du), cpu.y, cpu.x8?8:16);
    goto L_00C496;
L_00C496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC496u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC496u, 4u, 3u, cpu.address("abs", 0x1435u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C496 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1435u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00C499;
L_00C499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC499u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC499u, 4u, 3u, cpu.address("abs", 0x1433u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C499 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1433u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C49C;
L_00C49C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC49Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Cu,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Cu, 4u + ((((0xC470u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xC470u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C49C CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0xC470u), cpu.m8?8:16));
    goto L_00C49F;
L_00C49F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC49Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC49Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C49F BNE -> $00C4BC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C4BC; }
    goto L_00C4A1;
L_00C4A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A1u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4A1 DEY
    cpu.decReg('Y');
    goto L_00C4A2;
L_00C4A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4A2 BNE -> $00C4B7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C4B7; }
    goto L_00C4A4;
L_00C4A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A4u, 6u, 3u, cpu.address("abs", 0x1435u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4A4 INC
    cpu.incMem(hw, cpu.address("abs", 0x1435u), cpu.m8?8:16);
    goto L_00C4A7;
L_00C4A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A7u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4A7 TXA
    cpu.transfer("TXA");
    goto L_00C4A8;
L_00C4A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4A8 LSR
    cpu.lsrA();
    goto L_00C4A9;
L_00C4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4A9 BCC -> $00C4F8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00C4F8; }
    goto L_00C4AB;
L_00C4AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4ABu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4ABu, 6u, 3u, cpu.address("abs", 0xFCECu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00C4AB JSR -> $00FCEC stack real
    { cpu.push16Value(hw,0xC4ADu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC4AEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFCECu), 0x00C4ABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00C4AE;
L_00C4AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4AEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4AEu,0x00C4AEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4AEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4AE LDA
    cpu.setA(0x2u, 8);
    goto L_00C4B0;
L_00C4B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4B0 LDY
    cpu.setY(0xBu, 8);
    goto L_00C4B2;
L_00C4B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B2u, 6u, 3u, cpu.address("abs", 0xC9FEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00C4B2 JSR -> $00C9FE stack real
    { cpu.push16Value(hw,0xC4B4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC4B5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC9FEu), 0x00C4B2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00C4B5;
L_00C4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4B5u,0x00C4B5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4B5 LDY
    cpu.setY(0x0u, 8);
    goto L_00C4B7;
L_00C4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B7u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4B7u, 4u, 3u, cpu.address("abs", 0x1434u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4B7 STY
    hw.write(cpu.address("abs", 0x1434u), cpu.y, cpu.x8?8:16);
    goto L_00C4BA;
L_00C4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4BA BRA -> $00C4F8
    goto L_00C4F8;
L_00C4BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4BC CLC
    cpu.setFlag('C', false);
    goto L_00C4BD;
L_00C4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BDu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4BDu, 4u + ((((0xC474u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xC474u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4BD ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xC474u), cpu.m8?8:16));
    goto L_00C4C0;
L_00C4C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C0u, 4u, 3u, cpu.address("abs", 0x1433u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4C0 STA
    hw.write(cpu.address("abs", 0x1433u), cpu.a, cpu.m8?8:16);
    goto L_00C4C3;
L_00C4C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4C3 LDA
    cpu.setA(0x22u, 8);
    goto L_00C4C5;
L_00C4C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4C5 STA
    hw.write(cpu.address("dp", 0x41u), cpu.a, cpu.m8?8:16);
    goto L_00C4C7;
L_00C4C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4C7 LDA
    cpu.setA(0x2u, 8);
    goto L_00C4C9;
L_00C4C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4C9 STA
    hw.write(cpu.address("dp", 0x42u), cpu.a, cpu.m8?8:16);
    goto L_00C4CB;
L_00C4CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CBu, 4u + ((((0xC478u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xC478u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4CB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xC478u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C4CE;
L_00C4CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4CE STA
    hw.write(cpu.address("dp", 0x43u), cpu.a, cpu.m8?8:16);
    goto L_00C4D0;
L_00C4D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4D0 LDA
    cpu.setA(0x12u, 8);
    goto L_00C4D2;
L_00C4D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4D2 STA
    hw.write(cpu.address("dp", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_00C4D4;
L_00C4D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4D4 REP
    cpu.rep(0x20u);
    goto L_00C4D6;
L_00C4D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4D6 LDA
    cpu.setA(0xCB93u, 16);
    goto L_00C4D9;
L_00C4D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4D9 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00C4DB;
L_00C4DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DBu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4DB STZ
    hw.write(cpu.address("dp", 0x6u), 0, cpu.m8?8:16);
    goto L_00C4DD;
L_00C4DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4DD SEP
    cpu.sep(0x20u);
    goto L_00C4DF;
L_00C4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DFu, 4u, 3u, cpu.address("abs", 0x1436u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4DF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1436u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C4E2;
L_00C4E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4E2 SEC
    cpu.setFlag('C', true);
    goto L_00C4E3;
L_00C4E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E3u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4E3 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_00C4E5;
L_00C4E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4E5 CLC
    cpu.setFlag('C', false);
    goto L_00C4E6;
L_00C4E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E6u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4E6 ADC
    cpu.adc(0x4u);
    goto L_00C4E8;
L_00C4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4E8 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00C4EA;
L_00C4EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EAu, 4u, 3u, cpu.address("abs", 0x1438u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4EA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1438u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C4ED;
L_00C4ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4ED SEC
    cpu.setFlag('C', true);
    goto L_00C4EE;
L_00C4EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EEu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4EE SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_00C4F0;
L_00C4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F0u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4F0 CLC
    cpu.setFlag('C', false);
    goto L_00C4F1;
L_00C4F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4F1 ADC
    cpu.adc(0x10u);
    goto L_00C4F3;
L_00C4F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4F3 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_00C4F5;
L_00C4F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F5u, 6u, 3u, cpu.address("abs", 0xCA88u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00C4F5 JSR -> $00CA88 stack real
    { cpu.push16Value(hw,0xC4F7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC4F8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCA88u), 0x00C4F5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00C4F8;
L_00C4F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC4F8u,0x00C4F8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F8u, 4u, 3u, cpu.address("abs", 0x13FBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4F8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13FBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C4FB;
L_00C4FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4FB BEQ -> $00C500
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C500; }
    goto L_00C4FD;
L_00C4FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FDu, 3u, 3u, cpu.address("abs", 0xC58Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C4FD JMP -> $00C58F
    goto L_00C58F;
L_00C500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC500u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC500u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C500 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C502;
L_00C502:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC502u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC502u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC502u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C502 BNE -> $00C569
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C569; }
    goto L_00C504;
L_00C504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC504u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC504u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C504 INC
    cpu.incMem(hw, cpu.address("dp", 0x14u), cpu.m8?8:16);
    goto L_00C506;
L_00C506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC506u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC506u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C506 LDX
    cpu.setX(0x13u, 8);
    goto L_00C508;
L_00C508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC508u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC508u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC508u, 4u + ((((0x1495u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1495u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C508 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1495u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C50B;
L_00C50B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC50Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C50B BEQ -> $00C510
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C510; }
    goto L_00C50D;
L_00C50D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC50Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Du,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Du, 7u, 3u, cpu.address("absx", 0x1495u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C50D DEC
    cpu.decMem(hw, cpu.address("absx", 0x1495u), cpu.m8?8:16);
    goto L_00C510;
L_00C510:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC510u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC510u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC510u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C510 DEX
    cpu.decReg('X');
    goto L_00C511;
L_00C511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC511u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC511u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C511 BNE -> $00C508
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C508; }
    goto L_00C513;
L_00C513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC513u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC513u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C513 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C515;
L_00C515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC515u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC515u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC515u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C515 AND
    cpu.logicAnd(0x3u);
    goto L_00C517;
L_00C517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC517u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC517u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C517 BNE -> $00C569
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C569; }
    goto L_00C519;
L_00C519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC519u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC519u, 4u, 3u, cpu.address("abs", 0x1425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C519 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1425u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C51C;
L_00C51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C51C BEQ -> $00C533
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C533; }
    goto L_00C51E;
L_00C51E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Eu, 4u, 3u, cpu.address("abs", 0x14ABu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C51E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14ABu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C521;
L_00C521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC521u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC521u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C521 CMP
    cpu.compareA(0x44u);
    goto L_00C523;
L_00C523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC523u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC523u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C523 BNE -> $00C52A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C52A; }
    goto L_00C525;
L_00C525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC525u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC525u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C525 LDY
    cpu.setY(0x14u, 8);
    goto L_00C527;
L_00C527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC527u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC527u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC527u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C527 STY
    hw.write(cpu.address("abs", 0x1DFBu), cpu.y, cpu.x8?8:16);
    goto L_00C52A;
L_00C52A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C52A CMP
    cpu.compareA(0x1u);
    goto L_00C52C;
L_00C52C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C52C BNE -> $00C533
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C533; }
    goto L_00C52E;
L_00C52E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C52E LDY
    cpu.setY(0xBu, 8);
    goto L_00C530;
L_00C530:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC530u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC530u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC530u, 4u, 3u, cpu.address("abs", 0x0100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C530 STY
    hw.write(cpu.address("abs", 0x100u), cpu.y, cpu.x8?8:16);
    goto L_00C533;
L_00C533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC533u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC533u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC533u, 4u, 3u, cpu.address("abs", 0x14ADu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C533 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x14ADu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00C536;
L_00C536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC536u,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC536u, 4u, 3u, cpu.address("abs", 0x14AEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C536 CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0x14AEu), cpu.x8?8:16));
    goto L_00C539;
L_00C539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC539u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC539u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC539u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C539 BCS -> $00C53E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00C53E; }
    goto L_00C53B;
L_00C53B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Bu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Bu, 4u, 3u, cpu.address("abs", 0x14AEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C53B LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x14AEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00C53E;
L_00C53E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Eu, 4u, 3u, cpu.address("abs", 0x0DDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C53E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDDAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C541;
L_00C541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC541u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC541u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C541 BMI -> $00C54F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00C54F; }
    goto L_00C543;
L_00C543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC543u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC543u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC543u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C543 CPY
    cpu.compareY(0x1u);
    goto L_00C545;
L_00C545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC545u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC545u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC545u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C545 BNE -> $00C54F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C54F; }
    goto L_00C547;
L_00C547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC547u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC547u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC547u, 4u, 3u, cpu.address("abs", 0x190Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C547 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x190Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00C54A;
L_00C54A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C54A BNE -> $00C54F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C54F; }
    goto L_00C54C;
L_00C54C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Cu, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C54C STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_00C54F;
L_00C54F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC54Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC54Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C54F CMP
    cpu.compareA(0xFFu);
    goto L_00C551;
L_00C551:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC551u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC551u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC551u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C551 BEQ -> $00C55C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C55C; }
    goto L_00C553;
L_00C553:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC553u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC553u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC553u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C553 CPY
    cpu.compareY(0x1Eu);
    goto L_00C555;
L_00C555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC555u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC555u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C555 BNE -> $00C55C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C55C; }
    goto L_00C557;
L_00C557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC557u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC557u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C557 LDA
    cpu.setA(0x24u, 8);
    goto L_00C559;
L_00C559:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC559u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC559u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC559u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C559 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00C55C;
L_00C55C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC55Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C55C LDX
    cpu.setX(0x6u, 8);
    goto L_00C55E;
L_00C55E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC55Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC55Eu, 4u + ((((0x14A8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C55E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C561;
L_00C561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC561u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC561u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC561u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C561 BEQ -> $00C566
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C566; }
    goto L_00C563;
L_00C563:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC563u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC563u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC563u, 7u, 3u, cpu.address("absx", 0x14A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C563 DEC
    cpu.decMem(hw, cpu.address("absx", 0x14A8u), cpu.m8?8:16);
    goto L_00C566;
L_00C566:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC566u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC566u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC566u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C566 DEX
    cpu.decReg('X');
    goto L_00C567;
L_00C567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC567u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC567u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C567 BNE -> $00C55E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C55E; }
    goto L_00C569;
L_00C569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC569u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC569u, 6u, 3u, cpu.address("abs", 0xC593u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00C569 JSR -> $00C593 stack real
    { cpu.push16Value(hw,0xC56Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC56Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC593u), 0x00C569u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00C56C;
L_00C56C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C56C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C56E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C56C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C56E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C56C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C56E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C56C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C56E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC56Cu,0x00C56Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00C56E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC56Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C56E AND
    cpu.logicAnd(0x20u);
    goto L_00C570;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C56E AND
    cpu.logicAnd(0x20u);
    goto L_00C570;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C56E AND
    cpu.logicAnd(0x20u);
    goto L_00C570;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC56Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C56E AND
    cpu.logicAnd(0x20u);
    goto L_00C570;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC56Eu,0x00C56Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00C570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC570u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC570u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC570u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C570 BEQ -> $00C58F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C58F; }
    goto L_00C572;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC570u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC570u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C570 BEQ -> $00C58F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C58F; }
    goto L_00C572;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC570u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC570u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C570 BEQ -> $00C58F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C58F; }
    goto L_00C572;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC570u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC570u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C570 BEQ -> $00C58F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00C58F; }
    goto L_00C572;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC570u,0x00C570u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00C572:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC572u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC572u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC572u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C572 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C574;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC572u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC572u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C572 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C574;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC572u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC572u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C572 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C574;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC572u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC572u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C572 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00C574;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC572u,0x00C572u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00C574:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC574u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC574u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC574u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C574 AND
    cpu.logicAnd(0x8u);
    goto L_00C576;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC574u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC574u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C574 AND
    cpu.logicAnd(0x8u);
    goto L_00C576;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC574u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC574u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C574 AND
    cpu.logicAnd(0x8u);
    goto L_00C576;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC574u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC574u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C574 AND
    cpu.logicAnd(0x8u);
    goto L_00C576;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC574u,0x00C574u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00C576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC576u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC576u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC576u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C576 BRA -> $00C585
    goto L_00C585;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC576u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC576u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C576 BRA -> $00C585
    goto L_00C585;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC576u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC576u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C576 BRA -> $00C585
    goto L_00C585;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC576u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC576u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C576 BRA -> $00C585
    goto L_00C585;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC576u,0x00C576u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00C585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC585u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00C585 PHB
    cpu.push("PHB", hw);
    goto L_00C586;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00C585 PHB
    cpu.push("PHB", hw);
    goto L_00C586;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00C585 PHB
    cpu.push("PHB", hw);
    goto L_00C586;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00C585 PHB
    cpu.push("PHB", hw);
    goto L_00C586;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC585u,0x00C585u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00C586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC586u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC586u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC586u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C586 LDA
    cpu.setA(0x2u, 8);
    goto L_00C588;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC586u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC586u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C586 LDA
    cpu.setA(0x2u, 8);
    goto L_00C588;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC586u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC586u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C586 LDA
    cpu.setA(0x2u, 8);
    goto L_00C588;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC586u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC586u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C586 LDA
    cpu.setA(0x2u, 8);
    goto L_00C588;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC586u,0x00C586u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00C588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC588u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00C588 PHA
    cpu.push("PHA", hw);
    goto L_00C589;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00C588 PHA
    cpu.push("PHA", hw);
    goto L_00C589;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00C588 PHA
    cpu.push("PHA", hw);
    goto L_00C589;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC588u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00C588 PHA
    cpu.push("PHA", hw);
    goto L_00C589;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC588u,0x00C588u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00C589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC589u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC589u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC589u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00C589 PLB
    cpu.pop("PLB", hw);
    goto L_00C58A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC589u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC589u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00C589 PLB
    cpu.pop("PLB", hw);
    goto L_00C58A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC589u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC589u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00C589 PLB
    cpu.pop("PLB", hw);
    goto L_00C58A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC589u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC589u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00C589 PLB
    cpu.pop("PLB", hw);
    goto L_00C58A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC589u,0x00C589u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00C58A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Au))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au, 8u, 4u, 0x028008u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00C58A JSL -> $028008 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC58Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC58Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x028008u, 0x00C58Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00C58E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au, 8u, 4u, 0x028008u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00C58A JSL -> $028008 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC58Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC58Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x028008u, 0x00C58Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00C58E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au, 8u, 4u, 0x028008u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00C58A JSL -> $028008 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC58Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC58Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x028008u, 0x00C58Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00C58E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au, 8u, 4u, 0x028008u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00C58A JSL -> $028008 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC58Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC58Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x028008u, 0x00C58Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00C58E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC58Au,0x00C58Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00C58E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00C58E PLB
    cpu.pop("PLB", hw);
    goto L_00C58F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00C58E PLB
    cpu.pop("PLB", hw);
    goto L_00C58F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00C58E PLB
    cpu.pop("PLB", hw);
    goto L_00C58F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00C58E PLB
    cpu.pop("PLB", hw);
    goto L_00C58F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC58Eu,0x00C58Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00C58F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Fu, 4u, 3u, cpu.address("abs", 0x1402u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C58F STZ
    hw.write(cpu.address("abs", 0x1402u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC592u,0x00C58Fu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Fu, 4u, 3u, cpu.address("abs", 0x1402u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C58F STZ
    hw.write(cpu.address("abs", 0x1402u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC592u,0x00C58Fu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Fu, 4u, 3u, cpu.address("abs", 0x1402u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C58F STZ
    hw.write(cpu.address("abs", 0x1402u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC592u,0x00C58Fu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Fu, 4u, 3u, cpu.address("abs", 0x1402u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C58F STZ
    hw.write(cpu.address("abs", 0x1402u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC592u,0x00C58Fu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC58Fu,0x00C58Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00D1F4_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00D137u: goto L_00D137;
    case 0x00D13Au: goto L_00D13A;
    case 0x00D13Cu: goto L_00D13C;
    case 0x00D13Fu: goto L_00D13F;
    case 0x00D1F4u: goto L_00D1F4;
    case 0x00D1F7u: goto L_00D1F7;
    case 0x00D1F9u: goto L_00D1F9;
    case 0x00D1FCu: goto L_00D1FC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00D137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD137u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD137u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD137u, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D137 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1496u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D13A;
L_00D13A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD13Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD13Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD13Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D13A BEQ -> $00D13F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D13F; }
    goto L_00D13C;
L_00D13C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD13Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD13Cu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD13Cu, 6u, 3u, cpu.address("abs", 0x1496u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D13C DEC
    cpu.decMem(hw, cpu.address("abs", 0x1496u), cpu.m8?8:16);
    goto L_00D13F;
L_00D13F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD13Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD13Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD13Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00D13F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00D13Fu);return;} hw.unresolvedReturn(0x00D13Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00D1F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F4u, 4u, 3u, cpu.address("abs", 0x14A2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D1F4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D1F7;
L_00D1F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D1F7 BEQ -> $00D1FC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D1FC; }
    goto L_00D1F9;
L_00D1F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F9u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F9u, 6u, 3u, cpu.address("abs", 0x14A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D1F9 DEC
    cpu.decMem(hw, cpu.address("abs", 0x14A2u), cpu.m8?8:16);
    goto L_00D1FC;
L_00D1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FCu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FCu, 3u, 3u, cpu.address("abs", 0xD137u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D1FC JMP -> $00D137
    goto L_00D137;
}

void sub_00D1F4_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00D137u: goto L_00D137;
    case 0x00D13Au: goto L_00D13A;
    case 0x00D13Cu: goto L_00D13C;
    case 0x00D13Fu: goto L_00D13F;
    case 0x00D1F4u: goto L_00D1F4;
    case 0x00D1F7u: goto L_00D1F7;
    case 0x00D1F9u: goto L_00D1F9;
    case 0x00D1FCu: goto L_00D1FC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00D137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD137u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD137u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD137u, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D137 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1496u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D13A;
L_00D13A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD13Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD13Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD13Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D13A BEQ -> $00D13F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D13F; }
    goto L_00D13C;
L_00D13C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD13Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD13Cu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD13Cu, 6u, 3u, cpu.address("abs", 0x1496u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D13C DEC
    cpu.decMem(hw, cpu.address("abs", 0x1496u), cpu.m8?8:16);
    goto L_00D13F;
L_00D13F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD13Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD13Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD13Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00D13F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00D13Fu);return;} hw.unresolvedReturn(0x00D13Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00D1F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F4u, 4u, 3u, cpu.address("abs", 0x14A2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D1F4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D1F7;
L_00D1F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D1F7 BEQ -> $00D1FC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D1FC; }
    goto L_00D1F9;
L_00D1F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F9u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F9u, 6u, 3u, cpu.address("abs", 0x14A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D1F9 DEC
    cpu.decMem(hw, cpu.address("abs", 0x14A2u), cpu.m8?8:16);
    goto L_00D1FC;
L_00D1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FCu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FCu, 3u, 3u, cpu.address("abs", 0xD137u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D1FC JMP -> $00D137
    goto L_00D137;
}

void sub_00EC46_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EC46u: goto L_00EC46;
    case 0x00EC48u: goto L_00EC48;
    case 0x00EC4Au: goto L_00EC4A;
    case 0x00EC4Cu: goto L_00EC4C;
    case 0x00EC8Au: goto L_00EC8A;
    case 0x00ECA6u: goto L_00ECA6;
    case 0x00ECA7u: goto L_00ECA7;
    case 0x00ECA9u: goto L_00ECA9;
    case 0x00ECABu: goto L_00ECAB;
    case 0x00ECAFu: goto L_00ECAF;
    case 0x00ED0Du: goto L_00ED0D;
    case 0x00ED0Fu: goto L_00ED0F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EC46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC46u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC46u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EC46 CPY
    cpu.compareY(0x11u);
    goto L_00EC48;
L_00EC48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC48u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC48u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EC48 BCC -> $00EC8A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EC8A; }
    goto L_00EC4A;
L_00EC4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Au,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EC4A CPY
    cpu.compareY(0x6Eu);
    goto L_00EC4C;
L_00EC4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EC4C BCS -> $00EC8A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EC8A; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC4Eu,0x00EC4Cu); return;
L_00EC8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC8Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC8Au,0x00EC8Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC8Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC8Au, 6u, 3u, cpu.address("abs", 0xF44Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EC8A JSR -> $00F44D stack real
    { cpu.push16Value(hw,0xEC8Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEC8Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF44Du), 0x00EC8Au); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC8Du,0x00EC8Au); return;
L_00ECA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECA6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECA6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECA6 SEC
    cpu.setFlag('C', true);
    goto L_00ECA7;
L_00ECA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECA7u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECA7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECA7 SBC
    cpu.sbc(0x4u);
    goto L_00ECA9;
L_00ECA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECA9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECA9 LDY
    cpu.setY(0x0u, 8);
    goto L_00ECAB;
L_00ECAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECABu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECABu, 8u, 4u, 0x00F17Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00ECAB JSL -> $00F17F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xECAEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xECAFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F17Fu, 0x00ECABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00ECAF;
L_00ECAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECAFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xECAFu,0x00ECAFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECAFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECAFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECAF BRA -> $00ED0D
    goto L_00ED0D;
L_00ED0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED0D LDA
    cpu.setA(0xF0u, 8);
    goto L_00ED0F;
L_00ED0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED0F CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED10u,0x00ED0Fu); return;
}

void sub_00EC46_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EC46u: goto L_00EC46;
    case 0x00EC48u: goto L_00EC48;
    case 0x00EC4Au: goto L_00EC4A;
    case 0x00EC4Cu: goto L_00EC4C;
    case 0x00EC8Au: goto L_00EC8A;
    case 0x00ECA6u: goto L_00ECA6;
    case 0x00ECA7u: goto L_00ECA7;
    case 0x00ECA9u: goto L_00ECA9;
    case 0x00ECABu: goto L_00ECAB;
    case 0x00ECAFu: goto L_00ECAF;
    case 0x00ED0Du: goto L_00ED0D;
    case 0x00ED0Fu: goto L_00ED0F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EC46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC46u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC46u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EC46 CPY
    cpu.compareY(0x11u);
    goto L_00EC48;
L_00EC48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC48u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC48u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EC48 BCC -> $00EC8A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EC8A; }
    goto L_00EC4A;
L_00EC4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Au,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EC4A CPY
    cpu.compareY(0x6Eu);
    goto L_00EC4C;
L_00EC4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EC4C BCS -> $00EC8A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EC8A; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC4Eu,0x00EC4Cu); return;
L_00EC8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC8Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC8Au,0x00EC8Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC8Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC8Au, 6u, 3u, cpu.address("abs", 0xF44Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EC8A JSR -> $00F44D stack real
    { cpu.push16Value(hw,0xEC8Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEC8Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF44Du), 0x00EC8Au); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC8Du,0x00EC8Au); return;
L_00ECA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECA6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECA6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECA6 SEC
    cpu.setFlag('C', true);
    goto L_00ECA7;
L_00ECA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECA7u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECA7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECA7 SBC
    cpu.sbc(0x4u);
    goto L_00ECA9;
L_00ECA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECA9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECA9 LDY
    cpu.setY(0x0u, 8);
    goto L_00ECAB;
L_00ECAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECABu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECABu, 8u, 4u, 0x00F17Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00ECAB JSL -> $00F17F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xECAEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xECAFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F17Fu, 0x00ECABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00ECAF;
L_00ECAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECAFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xECAFu,0x00ECAFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECAFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECAFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECAF BRA -> $00ED0D
    goto L_00ED0D;
L_00ED0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED0D LDA
    cpu.setA(0xF0u, 8);
    goto L_00ED0F;
L_00ED0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED0F CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED10u,0x00ED0Fu); return;
}

void sub_00EADB_E0M1X1CQ_part37(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF95u: goto L_00EF95;
    case 0x00EF96u: goto L_00EF96;
    case 0x00EF98u: goto L_00EF98;
    case 0x00EF99u: goto L_00EF99;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF95u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 5u, 3u, cpu.address("abs", 0x1697u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 5u, 3u, cpu.address("abs", 0x1697u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF95u,0x00EF95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF96u))return;
  // 11 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF96u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF96u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x16u) & 0xFFFFu), 3u, 0u);
    // $00EF96 STA
    hw.write(cpu.addressDpLongY(hw, 0x16u), cpu.a, cpu.m8?8:16);
    goto L_00EF98;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF96u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF96u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x16u) & 0xFFFFu), 3u, 0u);
    // $00EF96 STA
    hw.write(cpu.addressDpLongY(hw, 0x16u), cpu.a, cpu.m8?8:16);
    goto L_00EF98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF96u,0x00EF96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF98u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF98u,0x00EF98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF99u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF99u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF99u, 5u, 3u, cpu.address("abs", 0x1697u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF99 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF9Cu,0x00EF99u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF99u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF99u, 5u, 3u, cpu.address("abs", 0x1697u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF99 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF9Cu,0x00EF99u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF99u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF99u, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF99 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF9Cu,0x00EF99u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF99u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF99u, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF99 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF9Cu,0x00EF99u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF99u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF99u, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF99 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF9Cu,0x00EF99u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF99u,0x00EF99u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00F127_E0M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00F252u: goto L_00F252;
    case 0x00F254u: goto L_00F254;
    case 0x00F256u: goto L_00F256;
    case 0x00F25Au: goto L_00F25A;
    case 0x00F25Cu: goto L_00F25C;
    case 0x00F260u: goto L_00F260;
    case 0x00F261u: goto L_00F261;
    case 0x00F262u: goto L_00F262;
    case 0x00F264u: goto L_00F264;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00F252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF252u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF252u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F252 LDA
    cpu.setA(0xDu, 8);
    goto L_00F254;
L_00F254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF254u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF254u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F254 STA
    hw.write(cpu.address("dp", 0x9Cu), cpu.a, cpu.m8?8:16);
    goto L_00F256;
L_00F256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF256u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF256u, 5u, 4u, ((0x00F0F8u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F256 LDA
    cpu.loadA(hw.readW(((0xF0F8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F25A;
L_00F25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF25Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F25A STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_00F25C;
L_00F25C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF25Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Cu, 8u, 4u, 0x00BEB0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F25C JSL -> $00BEB0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF25Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF260u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00BEB0u, 0x00F25Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F260;
L_00F260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF260u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF260u,0x00F260u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF260u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF260u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00F260 PLA
    cpu.pop("PLA", hw);
    goto L_00F261;
L_00F261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF261u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF261u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F261 DEX
    cpu.decReg('X');
    goto L_00F262;
L_00F262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF262u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF262u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F262 BPL -> $00F24E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00F24Eu,0x00F262u); return; }
    goto L_00F264;
L_00F264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF264u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF264u, 3u, 3u, cpu.address("abs", 0xF1F6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F264 JMP -> $00F1F6
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xF1F6u),0x00F264u); return;
}

void sub_00FD5A_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00FD5Au: goto L_00FD5A;
    case 0x00FD5Cu: goto L_00FD5C;
    case 0x00FD5Eu: goto L_00FD5E;
    case 0x00FD60u: goto L_00FD60;
    case 0x00FD62u: goto L_00FD62;
    case 0x00FD65u: goto L_00FD65;
    case 0x00FD67u: goto L_00FD67;
    case 0x00FD68u: goto L_00FD68;
    case 0x00FD6Au: goto L_00FD6A;
    case 0x00FD6Bu: goto L_00FD6B;
    case 0x00FD6Du: goto L_00FD6D;
    case 0x00FD70u: goto L_00FD70;
    case 0x00FD72u: goto L_00FD72;
    case 0x00FD74u: goto L_00FD74;
    case 0x00FD77u: goto L_00FD77;
    case 0x00FD79u: goto L_00FD79;
    case 0x00FD7Bu: goto L_00FD7B;
    case 0x00FD7Eu: goto L_00FD7E;
    case 0x00FD81u: goto L_00FD81;
    case 0x00FD83u: goto L_00FD83;
    case 0x00FD85u: goto L_00FD85;
    case 0x00FD86u: goto L_00FD86;
    case 0x00FD88u: goto L_00FD88;
    case 0x00FD8Au: goto L_00FD8A;
    case 0x00FD8Du: goto L_00FD8D;
    case 0x00FD8Fu: goto L_00FD8F;
    case 0x00FD90u: goto L_00FD90;
    case 0x00FD92u: goto L_00FD92;
    case 0x00FD94u: goto L_00FD94;
    case 0x00FD97u: goto L_00FD97;
    case 0x00FD99u: goto L_00FD99;
    case 0x00FD9Cu: goto L_00FD9C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00FD5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD5Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD5Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD5A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD5C;
L_00FD5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD5Cu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD5Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x81u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD5C ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x81u), cpu.m8?8:16));
    goto L_00FD5E;
L_00FD5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD5Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD5E BNE -> $00FD6A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FD6A; }
    goto L_00FD60;
L_00FD60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD60u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD60 LDY
    cpu.setY(0x3u, 8);
    goto L_00FD62;
L_00FD62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD62u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD62u, 4u + ((((0x17C0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x17C0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD62 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x17C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD65;
L_00FD65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD65u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD65u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD65 BEQ -> $00FD6B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FD6B; }
    goto L_00FD67;
L_00FD67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD67u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD67u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD67 DEY
    cpu.decReg('Y');
    goto L_00FD68;
L_00FD68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD68u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD68 BPL -> $00FD62
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00FD62; }
    goto L_00FD6A;
L_00FD6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD6Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD6Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00FD6A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00FD6Au);return;} hw.unresolvedReturn(0x00FD6Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00FD6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD6Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD6B LDA
    cpu.setA(0x5u, 8);
    goto L_00FD6D;
L_00FD6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD6Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD6Du, 5u, 3u, cpu.address("absy", 0x17C0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD6D STA
    hw.write(cpu.address("absy", 0x17C0u), cpu.a, cpu.m8?8:16);
    goto L_00FD70;
L_00FD70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD70u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD70u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD70 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD72;
L_00FD72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD72u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD72 AND
    cpu.logicAnd(0xF0u);
    goto L_00FD74;
L_00FD74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD74u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD74u, 5u, 3u, cpu.address("absy", 0x17C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD74 STA
    hw.write(cpu.address("absy", 0x17C8u), cpu.a, cpu.m8?8:16);
    goto L_00FD77;
L_00FD77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD77u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD77u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD77 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD79;
L_00FD79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD79u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD79 AND
    cpu.logicAnd(0xF0u);
    goto L_00FD7B;
L_00FD7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD7Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD7Bu, 5u, 3u, cpu.address("absy", 0x17C4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD7B STA
    hw.write(cpu.address("absy", 0x17C4u), cpu.a, cpu.m8?8:16);
    goto L_00FD7E;
L_00FD7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD7Eu, 4u, 3u, cpu.address("abs", 0x1933u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1933u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD81;
L_00FD81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD81u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD81 BEQ -> $00FD97
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FD97; }
    goto L_00FD83;
L_00FD83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD83u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD83u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD83 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD85;
L_00FD85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD85u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD85u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD85 SEC
    cpu.setFlag('C', true);
    goto L_00FD86;
L_00FD86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD86u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD86u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD86 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_00FD88;
L_00FD88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD88u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD88 AND
    cpu.logicAnd(0xF0u);
    goto L_00FD8A;
L_00FD8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD8Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD8Au, 5u, 3u, cpu.address("absy", 0x17C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD8A STA
    hw.write(cpu.address("absy", 0x17C8u), cpu.a, cpu.m8?8:16);
    goto L_00FD8D;
L_00FD8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD8Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD8Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD8D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FD8F;
L_00FD8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD8Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD8Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD8F SEC
    cpu.setFlag('C', true);
    goto L_00FD90;
L_00FD90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD90u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD90u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD90 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16));
    goto L_00FD92;
L_00FD92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD92u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD92 AND
    cpu.logicAnd(0xF0u);
    goto L_00FD94;
L_00FD94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD94u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD94u, 5u, 3u, cpu.address("absy", 0x17C4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD94 STA
    hw.write(cpu.address("absy", 0x17C4u), cpu.a, cpu.m8?8:16);
    goto L_00FD97;
L_00FD97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD97u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD97 LDA
    cpu.setA(0x10u, 8);
    goto L_00FD99;
L_00FD99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD99u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD99u, 5u, 3u, cpu.address("absy", 0x17CCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD99 STA
    hw.write(cpu.address("absy", 0x17CCu), cpu.a, cpu.m8?8:16);
    goto L_00FD9C;
L_00FD9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD9Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD9Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00FD9C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00FD9Cu);return;} hw.unresolvedReturn(0x00FD9Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_019F0D_E1M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019F0Du: goto L_019F0D;
    case 0x019F0Fu: goto L_019F0F;
    case 0x019F12u: goto L_019F12;
    case 0x019F15u: goto L_019F15;
    case 0x019F17u: goto L_019F17;
    case 0x019F19u: goto L_019F19;
    case 0x019F1Cu: goto L_019F1C;
    case 0x019F1Du: goto L_019F1D;
    case 0x019F20u: goto L_019F20;
    case 0x019F23u: goto L_019F23;
    case 0x019F24u: goto L_019F24;
    case 0x019F27u: goto L_019F27;
    case 0x019F2Au: goto L_019F2A;
    case 0x019F2Du: goto L_019F2D;
    case 0x019F2Fu: goto L_019F2F;
    case 0x019F32u: goto L_019F32;
    case 0x019F34u: goto L_019F34;
    case 0x019F37u: goto L_019F37;
    case 0x019F3Au: goto L_019F3A;
    case 0x019F3Bu: goto L_019F3B;
    case 0x019F3Du: goto L_019F3D;
    case 0x019F40u: goto L_019F40;
    case 0x019F42u: goto L_019F42;
    case 0x019F44u: goto L_019F44;
    case 0x019F46u: goto L_019F46;
    case 0x019F48u: goto L_019F48;
    case 0x019F4Bu: goto L_019F4B;
    case 0x019F4Cu: goto L_019F4C;
    case 0x019F4Du: goto L_019F4D;
    case 0x019F4Eu: goto L_019F4E;
    case 0x019F4Fu: goto L_019F4F;
    case 0x019F51u: goto L_019F51;
    case 0x019F54u: goto L_019F54;
    case 0x019F57u: goto L_019F57;
    case 0x019F5Au: goto L_019F5A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019F0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F0D STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_019F0F;
L_019F0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Fu, 6u, 3u, cpu.address("abs", 0xA365u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019F0F JSR -> $01A365 stack real
    { cpu.push16Value(hw,0x9F11u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F12u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA365u), 0x019F0Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019F12;
L_019F12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F12u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F12u,0x019F12u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F12u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F12u, 4u + 1u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F12 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019F15;
L_019F15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F15u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F15 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_019F17;
L_019F17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F17u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F17u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F17 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x9Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_019F19;
L_019F19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F19u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F19u, 4u + 1u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F19 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019F1C;
L_019F1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F1C CLC
    cpu.setFlag('C', false);
    goto L_019F1D;
L_019F1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Du,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Du, 4u + 1u, 3u, cpu.address("absy", 0x9C7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F1D ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x9C7Fu), cpu.m8?8:16));
    goto L_019F20;
L_019F20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F20u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F20u, 5u + 1u, 3u, cpu.address("absx", 0x15EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F20 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_019F23;
L_019F23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F23u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F23 TAX
    cpu.transfer("TAX");
    goto L_019F24;
L_019F24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F24u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F24u, 4u + 1u, 3u, cpu.address("absx", 0x9B83u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F24 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9B83u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019F27;
L_019F27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F27u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F27u, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F27 STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_019F2A;
L_019F2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Au,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Au, 5u, 3u, cpu.address("abs", 0x15E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F2A LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_019F2D;
L_019F2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019F2F;
L_019F2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Fu, 5u, 3u, cpu.address("absy", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F2F STA
    hw.write(cpu.address("absy", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_019F32;
L_019F32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F32u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F32u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F32 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019F34;
L_019F34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F34u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F34u, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F34 STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_019F37;
L_019F37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F37u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F37u, 4u + 1u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F37 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019F3A;
L_019F3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F3A LSR
    cpu.lsrA();
    goto L_019F3B;
L_019F3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F3B LDA
    cpu.setA(0x0u, 8);
    goto L_019F3D;
L_019F3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Du,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Du, 4u + 1u, 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F3D ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16));
    goto L_019F40;
L_019F40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F40u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F40 BCS -> $019F44
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_019F44; }
    goto L_019F42;
L_019F42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F42u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F42 EOR
    cpu.logicXor(0x40u);
    goto L_019F44;
L_019F44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F44u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F44u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F44 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_019F46;
L_019F46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F46u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F46u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F46 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16));
    goto L_019F48;
L_019F48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F48u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F48u, 5u, 3u, cpu.address("absy", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F48 STA
    hw.write(cpu.address("absy", 0x303u), cpu.a, cpu.m8?8:16);
    goto L_019F4B;
L_019F4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F4B TYA
    cpu.transfer("TYA");
    goto L_019F4C;
L_019F4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F4C LSR
    cpu.lsrA();
    goto L_019F4D;
L_019F4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F4D LSR
    cpu.lsrA();
    goto L_019F4E;
L_019F4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F4E TAY
    cpu.transfer("TAY");
    goto L_019F4F;
L_019F4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F4F LDA
    cpu.setA(0x2u, 8);
    goto L_019F51;
L_019F51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F51u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F51u, 4u + 1u, 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F51 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16));
    goto L_019F54;
L_019F54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F54u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F54u, 5u, 3u, cpu.address("absy", 0x0460u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019F54 STA
    hw.write(cpu.address("absy", 0x460u), cpu.a, cpu.m8?8:16);
    goto L_019F57;
L_019F57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F57u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F57u, 6u, 3u, cpu.address("abs", 0xA3DFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019F57 JSR -> $01A3DF stack real
    { cpu.push16Value(hw,0x9F59u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F5Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA3DFu), 0x019F57u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019F5A;
L_019F5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F5Au))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F5Au,0x019F5Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019F5A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x019F5Au);return;} hw.unresolvedReturn(0x019F5Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01A5D3_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01A5D3u: goto L_01A5D3;
    case 0x01A5D4u: goto L_01A5D4;
    case 0x01A5D5u: goto L_01A5D5;
    case 0x01A5D8u: goto L_01A5D8;
    case 0x01A5D9u: goto L_01A5D9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01A5D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D3u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A5D3 PHX
    cpu.push("PHX", hw);
    goto L_01A5D4;
L_01A5D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D4u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A5D4 TYX
    cpu.transfer("TYX");
    goto L_01A5D5;
L_01A5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u, 6u, 3u, cpu.address("abs", 0xB4E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A5D5 JSR -> $01B4E2 stack real
    { cpu.push16Value(hw,0xA5D7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5D8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB4E2u), 0x01A5D5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01A5D8;
L_01A5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5D8u,0x01A5D8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A5D8 PLX
    cpu.pop("PLX", hw);
    goto L_01A5D9;
L_01A5D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A5D9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A5D9u);return;} hw.unresolvedReturn(0x01A5D9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01A77C_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01A77Cu: goto L_01A77C;
    case 0x01A77Eu: goto L_01A77E;
    case 0x01A780u: goto L_01A780;
    case 0x01A782u: goto L_01A782;
    case 0x01A785u: goto L_01A785;
    case 0x01A787u: goto L_01A787;
    case 0x01A78Au: goto L_01A78A;
    case 0x01A78Du: goto L_01A78D;
    case 0x01A78Fu: goto L_01A78F;
    case 0x01A791u: goto L_01A791;
    case 0x01A794u: goto L_01A794;
    case 0x01A796u: goto L_01A796;
    case 0x01A799u: goto L_01A799;
    case 0x01A79Cu: goto L_01A79C;
    case 0x01A79Du: goto L_01A79D;
    case 0x01A79Fu: goto L_01A79F;
    case 0x01A7A1u: goto L_01A7A1;
    case 0x01A7A2u: goto L_01A7A2;
    case 0x01A7A5u: goto L_01A7A5;
    case 0x01A7A7u: goto L_01A7A7;
    case 0x01A7AAu: goto L_01A7AA;
    case 0x01A7ADu: goto L_01A7AD;
    case 0x01A7AFu: goto L_01A7AF;
    case 0x01A7B2u: goto L_01A7B2;
    case 0x01A7B4u: goto L_01A7B4;
    case 0x01A7B7u: goto L_01A7B7;
    case 0x01A7B8u: goto L_01A7B8;
    case 0x01A7BBu: goto L_01A7BB;
    case 0x01A7BDu: goto L_01A7BD;
    case 0x01A7C0u: goto L_01A7C0;
    case 0x01A7C1u: goto L_01A7C1;
    case 0x01A7C2u: goto L_01A7C2;
    case 0x01A7C5u: goto L_01A7C5;
    case 0x01A7C8u: goto L_01A7C8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01A77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A77C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A77E;
L_01A77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A77E CMP
    cpu.compareA(0x2u);
    goto L_01A780;
L_01A780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA780u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA780u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A780 BNE -> $01A7C2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A7C2; }
    goto L_01A782;
L_01A782:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA782u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA782u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA782u, 4u + ((((0x187Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x187Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A782 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x187Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A785;
L_01A785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA785u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA785u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A785 BNE -> $01A7C2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A7C2; }
    goto L_01A787;
L_01A787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA787u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA787u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A787 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A78A;
L_01A78A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA78Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Au,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Au, 4u + ((((0x157Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A78A CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x157Cu), cpu.m8?8:16));
    goto L_01A78D;
L_01A78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A78D BEQ -> $01A7C2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A7C2; }
    goto L_01A78F;
L_01A78F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA78Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Fu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA78Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A78F STY
    hw.write(cpu.address("dp", 0x1u), cpu.y, cpu.x8?8:16);
    goto L_01A791;
L_01A791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA791u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA791u, 4u + ((((0x1534u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A791 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1534u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A794;
L_01A794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA794u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA794u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A794 BNE -> $01A7C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A7C0; }
    goto L_01A796;
L_01A796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA796u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA796u, 5u, 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A796 STZ
    hw.write(cpu.address("absx", 0x1528u), 0, cpu.m8?8:16);
    goto L_01A799;
L_01A799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA799u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA799u, 5u, 3u, cpu.address("absx", 0x163Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A799 STZ
    hw.write(cpu.address("absx", 0x163Eu), 0, cpu.m8?8:16);
    goto L_01A79C;
L_01A79C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA79Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A79C TAY
    cpu.transfer("TAY");
    goto L_01A79D;
L_01A79D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA79Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Du,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A79D STY
    hw.write(cpu.address("dp", 0x0u), cpu.y, cpu.x8?8:16);
    goto L_01A79F;
L_01A79F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA79Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA79Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A79F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A7A1;
L_01A7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7A1 CLC
    cpu.setFlag('C', false);
    goto L_01A7A2;
L_01A7A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A2u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A2u, 4u + ((((0xA778u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA778u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7A2 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xA778u), cpu.m8?8:16));
    goto L_01A7A5;
L_01A7A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A5u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7A5 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A7A7;
L_01A7A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A7u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7A7u, 5u, 3u, cpu.address("absy", 0x00E4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7A7 STA
    hw.write(cpu.address("absy", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_01A7AA;
L_01A7AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AAu, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7AA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A7AD;
L_01A7AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ADu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7AD LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A7AF;
L_01A7AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AFu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7AFu, 4u + ((((0xA77Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA77Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7AF ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xA77Au), cpu.m8?8:16));
    goto L_01A7B2;
L_01A7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B2u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7B2 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A7B4;
L_01A7B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B4u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B4u, 5u, 3u, cpu.address("absy", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7B4 STA
    hw.write(cpu.address("absy", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_01A7B7;
L_01A7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B7u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7B7 TYA
    cpu.transfer("TYA");
    goto L_01A7B8;
L_01A7B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7B8u, 5u, 3u, cpu.address("absx", 0x160Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7B8 STA
    hw.write(cpu.address("absx", 0x160Eu), cpu.a, cpu.m8?8:16);
    goto L_01A7BB;
L_01A7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7BB LDA
    cpu.setA(0x1u, 8);
    goto L_01A7BD;
L_01A7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7BDu, 5u, 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7BD STA
    hw.write(cpu.address("absx", 0x1534u), cpu.a, cpu.m8?8:16);
    goto L_01A7C0;
L_01A7C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C0u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A7C0 PLA
    cpu.pop("PLA", hw);
    goto L_01A7C1;
L_01A7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C1u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A7C1 PLA
    cpu.pop("PLA", hw);
    goto L_01A7C2;
L_01A7C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C2u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C2u, 4u, 3u, cpu.address("abs", 0x1695u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7C2 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1695u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A7C5;
L_01A7C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C5u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C5u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A7C5 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A7C8;
L_01A7C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A7C8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A7C8u);return;} hw.unresolvedReturn(0x01A7C8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01C075_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01C075u: goto L_01C075;
    case 0x01C077u: goto L_01C077;
    case 0x01C078u: goto L_01C078;
    case 0x01C07Au: goto L_01C07A;
    case 0x01C07Cu: goto L_01C07C;
    case 0x01C07Fu: goto L_01C07F;
    case 0x01C081u: goto L_01C081;
    case 0x01C084u: goto L_01C084;
    case 0x01C086u: goto L_01C086;
    case 0x01C089u: goto L_01C089;
    case 0x01C08Cu: goto L_01C08C;
    case 0x01C08Fu: goto L_01C08F;
    case 0x01C091u: goto L_01C091;
    case 0x01C094u: goto L_01C094;
    case 0x01C097u: goto L_01C097;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01C075:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC075u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC075u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC075u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C075 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01C077;
L_01C077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC077u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC077u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C077 SEC
    cpu.setFlag('C', true);
    goto L_01C078;
L_01C078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC078u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC078u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C078 SBC
    cpu.sbc(0x8u);
    goto L_01C07A;
L_01C07A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC07Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C07A STA
    hw.write(cpu.address("dpx", 0xC2u), cpu.a, cpu.m8?8:16);
    goto L_01C07C;
L_01C07C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC07Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Cu, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C07C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01C07F;
L_01C07F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC07Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C07F SBC
    cpu.sbc(0x0u);
    goto L_01C081;
L_01C081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC081u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC081u, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C081 STA
    hw.write(cpu.address("absx", 0x151Cu), cpu.a, cpu.m8?8:16);
    goto L_01C084;
L_01C084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC084u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC084u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC084u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C084 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01C086;
L_01C086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC086u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC086u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC086u, 5u, 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C086 STA
    hw.write(cpu.address("absx", 0x1528u), cpu.a, cpu.m8?8:16);
    goto L_01C089;
L_01C089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC089u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC089u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC089u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C089 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01C08C;
L_01C08C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC08Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Cu, 5u, 3u, cpu.address("absx", 0x187Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C08C STA
    hw.write(cpu.address("absx", 0x187Bu), cpu.a, cpu.m8?8:16);
    goto L_01C08F;
L_01C08F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC08Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C08F AND
    cpu.logicAnd(0x1u);
    goto L_01C091;
L_01C091:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC091u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC091u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC091u, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C091 STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_01C094;
L_01C094:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC094u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC094u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC094u, 5u, 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C094 STA
    hw.write(cpu.address("absx", 0x1534u), cpu.a, cpu.m8?8:16);
    goto L_01C097;
L_01C097:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC097u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC097u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC097u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01C097 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01C097u);return;} hw.unresolvedReturn(0x01C097u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01C075_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01C075u: goto L_01C075;
    case 0x01C077u: goto L_01C077;
    case 0x01C078u: goto L_01C078;
    case 0x01C07Au: goto L_01C07A;
    case 0x01C07Cu: goto L_01C07C;
    case 0x01C07Fu: goto L_01C07F;
    case 0x01C081u: goto L_01C081;
    case 0x01C084u: goto L_01C084;
    case 0x01C086u: goto L_01C086;
    case 0x01C089u: goto L_01C089;
    case 0x01C08Cu: goto L_01C08C;
    case 0x01C08Fu: goto L_01C08F;
    case 0x01C091u: goto L_01C091;
    case 0x01C094u: goto L_01C094;
    case 0x01C097u: goto L_01C097;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01C075:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC075u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC075u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC075u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C075 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01C077;
L_01C077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC077u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC077u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C077 SEC
    cpu.setFlag('C', true);
    goto L_01C078;
L_01C078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC078u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC078u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C078 SBC
    cpu.sbc(0x8u);
    goto L_01C07A;
L_01C07A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC07Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C07A STA
    hw.write(cpu.address("dpx", 0xC2u), cpu.a, cpu.m8?8:16);
    goto L_01C07C;
L_01C07C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC07Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Cu, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C07C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01C07F;
L_01C07F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC07Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C07F SBC
    cpu.sbc(0x0u);
    goto L_01C081;
L_01C081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC081u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC081u, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C081 STA
    hw.write(cpu.address("absx", 0x151Cu), cpu.a, cpu.m8?8:16);
    goto L_01C084;
L_01C084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC084u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC084u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC084u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C084 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01C086;
L_01C086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC086u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC086u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC086u, 5u, 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C086 STA
    hw.write(cpu.address("absx", 0x1528u), cpu.a, cpu.m8?8:16);
    goto L_01C089;
L_01C089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC089u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC089u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC089u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C089 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01C08C;
L_01C08C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC08Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Cu, 5u, 3u, cpu.address("absx", 0x187Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C08C STA
    hw.write(cpu.address("absx", 0x187Bu), cpu.a, cpu.m8?8:16);
    goto L_01C08F;
L_01C08F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC08Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C08F AND
    cpu.logicAnd(0x1u);
    goto L_01C091;
L_01C091:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC091u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC091u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC091u, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C091 STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_01C094;
L_01C094:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC094u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC094u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC094u, 5u, 3u, cpu.address("absx", 0x1534u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C094 STA
    hw.write(cpu.address("absx", 0x1534u), cpu.a, cpu.m8?8:16);
    goto L_01C097;
L_01C097:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC097u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC097u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC097u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01C097 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01C097u);return;} hw.unresolvedReturn(0x01C097u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01EE61_E1M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01EE61u: goto L_01EE61;
    case 0x01EE64u: goto L_01EE64;
    case 0x01EE65u: goto L_01EE65;
    case 0x01EE68u: goto L_01EE68;
    case 0x01EE6Au: goto L_01EE6A;
    case 0x01EE6Cu: goto L_01EE6C;
    case 0x01EE6Fu: goto L_01EE6F;
    case 0x01EE71u: goto L_01EE71;
    case 0x01EE73u: goto L_01EE73;
    case 0x01EE76u: goto L_01EE76;
    case 0x01EE78u: goto L_01EE78;
    case 0x01EE7Au: goto L_01EE7A;
    case 0x01EE7Du: goto L_01EE7D;
    case 0x01EE80u: goto L_01EE80;
    case 0x01EE82u: goto L_01EE82;
    case 0x01EE84u: goto L_01EE84;
    case 0x01EE86u: goto L_01EE86;
    case 0x01EE87u: goto L_01EE87;
    case 0x01EE8Au: goto L_01EE8A;
    case 0x01EE8Du: goto L_01EE8D;
    case 0x01EE8Fu: goto L_01EE8F;
    case 0x01EE92u: goto L_01EE92;
    case 0x01EE94u: goto L_01EE94;
    case 0x01EE96u: goto L_01EE96;
    case 0x01EE98u: goto L_01EE98;
    case 0x01EE9Bu: goto L_01EE9B;
    case 0x01EE9Eu: goto L_01EE9E;
    case 0x01EEA1u: goto L_01EEA1;
    case 0x01EEA3u: goto L_01EEA3;
    case 0x01EEA5u: goto L_01EEA5;
    case 0x01EEA7u: goto L_01EEA7;
    case 0x01EEAAu: goto L_01EEAA;
    case 0x01EEACu: goto L_01EEAC;
    case 0x01EEAEu: goto L_01EEAE;
    case 0x01EEAFu: goto L_01EEAF;
    case 0x01EEB0u: goto L_01EEB0;
    case 0x01EEB1u: goto L_01EEB1;
    case 0x01EEB2u: goto L_01EEB2;
    case 0x01EEB3u: goto L_01EEB3;
    case 0x01EEB4u: goto L_01EEB4;
    case 0x01EEB7u: goto L_01EEB7;
    case 0x01EEBAu: goto L_01EEBA;
    case 0x01EEBBu: goto L_01EEBB;
    case 0x01EEBEu: goto L_01EEBE;
    case 0x01EEC1u: goto L_01EEC1;
    case 0x01EEC3u: goto L_01EEC3;
    case 0x01EEC4u: goto L_01EEC4;
    case 0x01EEC5u: goto L_01EEC5;
    case 0x01EEC6u: goto L_01EEC6;
    case 0x01EEC7u: goto L_01EEC7;
    case 0x01EEC8u: goto L_01EEC8;
    case 0x01EEC9u: goto L_01EEC9;
    case 0x01EECCu: goto L_01EECC;
    case 0x01EECFu: goto L_01EECF;
    case 0x01EED0u: goto L_01EED0;
    case 0x01EED3u: goto L_01EED3;
    case 0x01EED6u: goto L_01EED6;
    case 0x01EED8u: goto L_01EED8;
    case 0x01EED9u: goto L_01EED9;
    case 0x01EEDCu: goto L_01EEDC;
    case 0x01EEDFu: goto L_01EEDF;
    case 0x01EEE2u: goto L_01EEE2;
    case 0x01EEE4u: goto L_01EEE4;
    case 0x01EEE6u: goto L_01EEE6;
    case 0x01EEE9u: goto L_01EEE9;
    case 0x01EEEBu: goto L_01EEEB;
    case 0x01EEEDu: goto L_01EEED;
    case 0x01EEEFu: goto L_01EEEF;
    case 0x01EEF1u: goto L_01EEF1;
    case 0x01EEF3u: goto L_01EEF3;
    case 0x01EEF5u: goto L_01EEF5;
    case 0x01EEF6u: goto L_01EEF6;
    case 0x01EEF8u: goto L_01EEF8;
    case 0x01EEFAu: goto L_01EEFA;
    case 0x01EEFCu: goto L_01EEFC;
    case 0x01EEFEu: goto L_01EEFE;
    case 0x01EF00u: goto L_01EF00;
    case 0x01EF02u: goto L_01EF02;
    case 0x01EF03u: goto L_01EF03;
    case 0x01EF04u: goto L_01EF04;
    case 0x01EF06u: goto L_01EF06;
    case 0x01EF08u: goto L_01EF08;
    case 0x01EF09u: goto L_01EF09;
    case 0x01EF0Au: goto L_01EF0A;
    case 0x01EF0Cu: goto L_01EF0C;
    case 0x01EF0Eu: goto L_01EF0E;
    case 0x01EF10u: goto L_01EF10;
    case 0x01EF11u: goto L_01EF11;
    case 0x01EF13u: goto L_01EF13;
    case 0x01EF14u: goto L_01EF14;
    case 0x01EF16u: goto L_01EF16;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01EE61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE61u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE61u, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE61 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EE64;
L_01EE64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE64u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE64u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EE64 PHA
    cpu.push("PHA", hw);
    goto L_01EE65;
L_01EE65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE65u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE65u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE65 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15ACu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EE68;
L_01EE68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE68u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE68 CPY
    cpu.compareY(0x8u);
    goto L_01EE6A;
L_01EE6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE6A BNE -> $01EE7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EE7D; }
    goto L_01EE6C;
L_01EE6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Cu, 4u, 3u, cpu.address("abs", 0x1419u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE6C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1419u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EE6F;
L_01EE6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE6Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE6F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16));
    goto L_01EE71;
L_01EE71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE71u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE71u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE71 BNE -> $01EE7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EE7D; }
    goto L_01EE73;
L_01EE73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE73u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE73u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE73 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EE76;
L_01EE76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE76u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE76u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE76 STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_01EE78;
L_01EE78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE78u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE78 EOR
    cpu.logicXor(0x1u);
    goto L_01EE7A;
L_01EE7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Au, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE7A STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_01EE7D;
L_01EE7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE7Du, 4u, 3u, cpu.address("abs", 0x1419u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE7D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1419u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EE80;
L_01EE80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE80u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE80u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE80 BMI -> $01EE8A
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_01EE8A; }
    goto L_01EE82;
L_01EE82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE82u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE82 CMP
    cpu.compareA(0x2u);
    goto L_01EE84;
L_01EE84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE84u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE84 BNE -> $01EE8A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EE8A; }
    goto L_01EE86;
L_01EE86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE86u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE86u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE86 INC
    cpu.inc('A');
    goto L_01EE87;
L_01EE87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE87u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE87u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE87 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_01EE8A;
L_01EE8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Au, 6u, 3u, cpu.address("abs", 0xEF18u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01EE8A JSR -> $01EF18 stack real
    { cpu.push16Value(hw,0xEE8Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE8Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEF18u), 0x01EE8Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01EE8D;
L_01EE8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE8D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EE8F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE8D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EE8F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE8Du,0x01EE8Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu, 4u + 1u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE8F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x302u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EE92;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu, 4u + ((((0x0302u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE8F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x302u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EE92;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,0x01EE8Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EE92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE92u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE92 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_01EE94;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE92 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_01EE94;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE92u,0x01EE92u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EE94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE94u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE94 STZ
    hw.write(cpu.address("dp", 0x1u), 0, cpu.m8?8:16);
    goto L_01EE96;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE94 STZ
    hw.write(cpu.address("dp", 0x1u), 0, cpu.m8?8:16);
    goto L_01EE96;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE94u,0x01EE94u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EE96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE96u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE96 LDA
    cpu.setA(0x6u, 8);
    goto L_01EE98;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE96 LDA
    cpu.setA(0x6u, 8);
    goto L_01EE98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE96u,0x01EE96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EE98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE98u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE98 STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_01EE9B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE98 STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_01EE9B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE98u,0x01EE98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu, 5u + 1u, 3u, cpu.address("absx", 0x15EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE9B LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EE9E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Bu, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE9B LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EE9E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Bu,0x01EE9Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EE9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu, 4u + 1u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE9E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x302u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EEA1;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Eu, 4u + ((((0x0302u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EE9E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x302u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EEA1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Eu,0x01EE9Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEA1 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_01EEA3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEA1 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_01EEA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA1u,0x01EEA1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEA3 STZ
    hw.write(cpu.address("dp", 0x3u), 0, cpu.m8?8:16);
    goto L_01EEA5;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEA3 STZ
    hw.write(cpu.address("dp", 0x3u), 0, cpu.m8?8:16);
    goto L_01EEA5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA3u,0x01EEA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEA5 LDA
    cpu.setA(0x8u, 8);
    goto L_01EEA7;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEA5 LDA
    cpu.setA(0x8u, 8);
    goto L_01EEA7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA5u,0x01EEA5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA7u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA7u, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEA7 STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_01EEAA;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA7u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA7u, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEA7 STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_01EEAA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA7u,0x01EEA7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEAAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEAA REP
    cpu.rep(0x20u);
    goto L_01EEAC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEAA REP
    cpu.rep(0x20u);
    goto L_01EEAC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEAAu,0x01EEAAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEACu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEAC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EEAE;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEAC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EEAE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEACu,0x01EEACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEAEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEAE ASL
    cpu.aslA();
    goto L_01EEAF;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEAE ASL
    cpu.aslA();
    goto L_01EEAF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEAEu,0x01EEAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEAFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEAF ASL
    cpu.aslA();
    goto L_01EEB0;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEAF ASL
    cpu.aslA();
    goto L_01EEB0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEAFu,0x01EEAFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEB0 ASL
    cpu.aslA();
    goto L_01EEB1;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEB0 ASL
    cpu.aslA();
    goto L_01EEB1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB0u,0x01EEB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEB1 ASL
    cpu.aslA();
    goto L_01EEB2;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEB1 ASL
    cpu.aslA();
    goto L_01EEB2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB1u,0x01EEB1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEB2 ASL
    cpu.aslA();
    goto L_01EEB3;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEB2 ASL
    cpu.aslA();
    goto L_01EEB3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB2u,0x01EEB2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEB3 CLC
    cpu.setFlag('C', false);
    goto L_01EEB4;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEB3 CLC
    cpu.setFlag('C', false);
    goto L_01EEB4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB3u,0x01EEB3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB4u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEB4 ADC
    cpu.adc(0x8500u);
    goto L_01EEB7;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB4u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEB4 ADC
    cpu.adc(0x8500u);
    goto L_01EEB7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB4u,0x01EEB4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB7u, 5u, 3u, cpu.address("abs", 0x0D8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEB7 STA
    hw.write(cpu.address("abs", 0xD8Bu), cpu.a, cpu.m8?8:16);
    goto L_01EEBA;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB7u, 5u, 3u, cpu.address("abs", 0x0D8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEB7 STA
    hw.write(cpu.address("abs", 0xD8Bu), cpu.a, cpu.m8?8:16);
    goto L_01EEBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB7u,0x01EEB7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEBAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBAu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEBA CLC
    cpu.setFlag('C', false);
    goto L_01EEBB;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBAu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEBA CLC
    cpu.setFlag('C', false);
    goto L_01EEBB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEBAu,0x01EEBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEBBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEBB ADC
    cpu.adc(0x200u);
    goto L_01EEBE;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEBB ADC
    cpu.adc(0x200u);
    goto L_01EEBE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEBBu,0x01EEBBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEBEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu, 5u, 3u, cpu.address("abs", 0x0D95u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEBE STA
    hw.write(cpu.address("abs", 0xD95u), cpu.a, cpu.m8?8:16);
    goto L_01EEC1;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBEu, 5u, 3u, cpu.address("abs", 0x0D95u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEBE STA
    hw.write(cpu.address("abs", 0xD95u), cpu.a, cpu.m8?8:16);
    goto L_01EEC1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEBEu,0x01EEBEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEC1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EEC3;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEC1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EEC3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC1u,0x01EEC1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEC3 ASL
    cpu.aslA();
    goto L_01EEC4;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEC3 ASL
    cpu.aslA();
    goto L_01EEC4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC3u,0x01EEC3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEC4 ASL
    cpu.aslA();
    goto L_01EEC5;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEC4 ASL
    cpu.aslA();
    goto L_01EEC5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC4u,0x01EEC4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEC5 ASL
    cpu.aslA();
    goto L_01EEC6;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEC5 ASL
    cpu.aslA();
    goto L_01EEC6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC5u,0x01EEC5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEC6 ASL
    cpu.aslA();
    goto L_01EEC7;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEC6 ASL
    cpu.aslA();
    goto L_01EEC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC6u,0x01EEC6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEC7 ASL
    cpu.aslA();
    goto L_01EEC8;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEC7 ASL
    cpu.aslA();
    goto L_01EEC8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC7u,0x01EEC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEC8 CLC
    cpu.setFlag('C', false);
    goto L_01EEC9;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEC8 CLC
    cpu.setFlag('C', false);
    goto L_01EEC9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC8u,0x01EEC8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEC9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEC9 ADC
    cpu.adc(0x8500u);
    goto L_01EECC;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEC9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEC9 ADC
    cpu.adc(0x8500u);
    goto L_01EECC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEC9u,0x01EEC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EECC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEECCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu, 5u, 3u, cpu.address("abs", 0x0D8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EECC STA
    hw.write(cpu.address("abs", 0xD8Du), cpu.a, cpu.m8?8:16);
    goto L_01EECF;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECCu, 5u, 3u, cpu.address("abs", 0x0D8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EECC STA
    hw.write(cpu.address("abs", 0xD8Du), cpu.a, cpu.m8?8:16);
    goto L_01EECF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEECCu,0x01EECCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEECFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EECF CLC
    cpu.setFlag('C', false);
    goto L_01EED0;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEECFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEECFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EECF CLC
    cpu.setFlag('C', false);
    goto L_01EED0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEECFu,0x01EECFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EED0 ADC
    cpu.adc(0x200u);
    goto L_01EED3;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EED0 ADC
    cpu.adc(0x200u);
    goto L_01EED3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED0u,0x01EED0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED3u, 5u, 3u, cpu.address("abs", 0x0D97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EED3 STA
    hw.write(cpu.address("abs", 0xD97u), cpu.a, cpu.m8?8:16);
    goto L_01EED6;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED3u, 5u, 3u, cpu.address("abs", 0x0D97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EED3 STA
    hw.write(cpu.address("abs", 0xD97u), cpu.a, cpu.m8?8:16);
    goto L_01EED6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED3u,0x01EED3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EED6 SEP
    cpu.sep(0x20u);
    goto L_01EED8;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EED6 SEP
    cpu.sep(0x20u);
    goto L_01EED8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED6u,0x01EED6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED8u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EED8 PLA
    cpu.pop("PLA", hw);
    goto L_01EED9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED8u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01EED8 PLA
    cpu.pop("PLA", hw);
    goto L_01EED9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED8u,0x01EED8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EED9 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_01EEDC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EED9 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_01EEDC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED9u,0x01EED9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEDCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDCu, 6u, 3u, cpu.address("abs", 0xF0A2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01EEDC JSR -> $01F0A2 stack real
    { cpu.push16Value(hw,0xEEDEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEDFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF0A2u), 0x01EEDCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01EEDF;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDCu, 6u, 3u, cpu.address("abs", 0xF0A2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01EEDC JSR -> $01F0A2 stack real
    { cpu.push16Value(hw,0xEEDEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEDFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF0A2u), 0x01EEDCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01EEDF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDCu,0x01EEDCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEDFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu, 4u, 3u, cpu.address("abs", 0x1410u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEDF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1410u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EEE2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDFu, 4u, 3u, cpu.address("abs", 0x1410u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEDF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1410u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EEE2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDFu,0x01EEDFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEE2 CMP
    cpu.compareA(0x2u);
    goto L_01EEE4;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEE2 CMP
    cpu.compareA(0x2u);
    goto L_01EEE4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE2u,0x01EEE2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEE4 BCC -> $01EF17
    if (!cpu.c) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x01EF17u,0x01EEE4u); return; }
    goto L_01EEE6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEE4 BCC -> $01EF17
    if (!cpu.c) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x01EF17u,0x01EEE4u); return; }
    goto L_01EEE6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE4u,0x01EEE4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEE6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EEE9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE6u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEE6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EEE9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE6u,0x01EEE6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEE9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEE9 BEQ -> $01EF13
    if (cpu.z) { hw.addCpuInternalCycles(2u); goto L_01EF13; }
    goto L_01EEEB;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEE9 BEQ -> $01EF13
    if (cpu.z) { hw.addCpuInternalCycles(2u); goto L_01EF13; }
    goto L_01EEEB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEE9u,0x01EEE9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEEB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EEED;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEEB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EEED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEBu,0x01EEEBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEED BNE -> $01EF00
    if (!cpu.z) { hw.addCpuInternalCycles(2u); goto L_01EF00; }
    goto L_01EEEF;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEED BNE -> $01EF00
    if (!cpu.z) { hw.addCpuInternalCycles(2u); goto L_01EF00; }
    goto L_01EEEF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEDu,0x01EEEDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEEFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEEF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EEF1;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEEFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEEF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EEF1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEEFu,0x01EEEFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEF1 BPL -> $01EEF6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01EEF6; }
    goto L_01EEF3;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEF1 BPL -> $01EEF6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01EEF6; }
    goto L_01EEF3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF1u,0x01EEF1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF3u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEF3 EOR
    cpu.logicXor(0xFFu);
    goto L_01EEF5;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF3u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEF3 EOR
    cpu.logicXor(0xFFu);
    goto L_01EEF5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF3u,0x01EEF3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF5u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEF5 INC
    cpu.inc('A');
    goto L_01EEF6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF5u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEF5 INC
    cpu.inc('A');
    goto L_01EEF6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF5u,0x01EEF5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEF6 CMP
    cpu.compareA(0x28u);
    goto L_01EEF8;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEF6 CMP
    cpu.compareA(0x28u);
    goto L_01EEF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF6u,0x01EEF6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEF8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEF8 LDA
    cpu.setA(0x1u, 8);
    goto L_01EEFA;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEF8 LDA
    cpu.setA(0x1u, 8);
    goto L_01EEFA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEF8u,0x01EEF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEFAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFAu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEFA BCS -> $01EF13
    if (cpu.c) { hw.addCpuInternalCycles(2u); goto L_01EF13; }
    goto L_01EEFC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFAu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEFA BCS -> $01EF13
    if (cpu.c) { hw.addCpuInternalCycles(2u); goto L_01EF13; }
    goto L_01EEFC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEFAu,0x01EEFAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEFCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEFC LDA
    cpu.setA(0x0u, 8);
    goto L_01EEFE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEFC LDA
    cpu.setA(0x0u, 8);
    goto L_01EEFE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEFCu,0x01EEFCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EEFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEFEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEFE BRA -> $01EF13
    goto L_01EF13;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEFEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EEFE BRA -> $01EF13
    goto L_01EF13;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEFEu,0x01EEFEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EF00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF00u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF00u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF00u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF00 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EF02;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF00u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF00u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF00 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01EF02;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF00u,0x01EF00u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EF02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF02u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF02u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF02 LSR
    cpu.lsrA();
    goto L_01EF03;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF02u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF02 LSR
    cpu.lsrA();
    goto L_01EF03;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF02u,0x01EF02u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EF03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF03u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF03u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF03 LSR
    cpu.lsrA();
    goto L_01EF04;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF03u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF03 LSR
    cpu.lsrA();
    goto L_01EF04;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF03u,0x01EF03u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EF04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF04u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF04u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF04u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF04 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x7Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EF06;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF04u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF04u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF04 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x7Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01EF06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF04u,0x01EF04u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EF06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF06u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF06 BMI -> $01EF0A
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_01EF0A; }
    goto L_01EF08;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF06 BMI -> $01EF0A
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_01EF0A; }
    goto L_01EF08;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF06u,0x01EF06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EF08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF08u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF08 LSR
    cpu.lsrA();
    goto L_01EF09;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF08u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF08 LSR
    cpu.lsrA();
    goto L_01EF09;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF08u,0x01EF08u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EF09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF09u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF09 LSR
    cpu.lsrA();
    goto L_01EF0A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF09 LSR
    cpu.lsrA();
    goto L_01EF0A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF09u,0x01EF09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EF0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF0A AND
    cpu.logicAnd(0x1u);
    goto L_01EF0C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF0A AND
    cpu.logicAnd(0x1u);
    goto L_01EF0C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Au,0x01EF0Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EF0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF0C BNE -> $01EF13
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EF13; }
    goto L_01EF0E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF0C BNE -> $01EF13
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01EF13; }
    goto L_01EF0E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Cu,0x01EF0Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EF0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF0Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF0E LDY
    cpu.setY(0x8C21u, 16);
    goto L_01EF11;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF0E LDY
    cpu.setY(0x21u, 8);
    goto L_01EF10;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF0Eu,0x01EF0Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EF10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF10u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF10u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF10 STY
    hw.write(cpu.address("abs", 0x1DFCu), cpu.y, cpu.x8?8:16);
    goto L_01EF13;
L_01EF11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF11u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF11u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x221Du + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $01EF11 JSR (221D,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x221Du+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0xEF13u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF14u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x01EF11u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01EF14;
L_01EF13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF13u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF13u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF13u, 8u, 4u, 0x02BB23u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01EF13 JSL -> $02BB23 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEF16u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF17u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02BB23u, 0x01EF13u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF17u,0x01EF13u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF13u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF13u, 8u, 4u, 0x02BB23u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01EF13 JSL -> $02BB23 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEF16u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF17u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02BB23u, 0x01EF13u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF17u,0x01EF13u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF13u,0x01EF13u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01EF14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF14u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF14u,0x01EF14u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF14u,cpu,0x23u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF14u, 4u, 2u, cpu.addressStack(0xBBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01EF14 AND
    cpu.logicAnd(hw.readW(cpu.addressStack(0xBBu), cpu.m8?8:16));
    goto L_01EF16;
L_01EF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF16u,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF16u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xEF18u,true);
    hw.requestDispatch(0x0082C3u,0x01EF16u);return;
}

void sub_01F0A2_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01F0A1u: goto L_01F0A1;
    case 0x01F0A2u: goto L_01F0A2;
    case 0x01F0A4u: goto L_01F0A4;
    case 0x01F0A6u: goto L_01F0A6;
    case 0x01F0A8u: goto L_01F0A8;
    case 0x01F0ACu: goto L_01F0AC;
    case 0x01F0AFu: goto L_01F0AF;
    case 0x01F0B1u: goto L_01F0B1;
    case 0x01F0B3u: goto L_01F0B3;
    case 0x01F0B6u: goto L_01F0B6;
    case 0x01F0B8u: goto L_01F0B8;
    case 0x01F0BAu: goto L_01F0BA;
    case 0x01F0BDu: goto L_01F0BD;
    case 0x01F0BFu: goto L_01F0BF;
    case 0x01F0C1u: goto L_01F0C1;
    case 0x01F0C4u: goto L_01F0C4;
    case 0x01F0C7u: goto L_01F0C7;
    case 0x01F0CBu: goto L_01F0CB;
    case 0x01F0CCu: goto L_01F0CC;
    case 0x01F0CEu: goto L_01F0CE;
    case 0x01F0D0u: goto L_01F0D0;
    case 0x01F0D2u: goto L_01F0D2;
    case 0x01F0D4u: goto L_01F0D4;
    case 0x01F0D6u: goto L_01F0D6;
    case 0x01F0D9u: goto L_01F0D9;
    case 0x01F0DAu: goto L_01F0DA;
    case 0x01F0DCu: goto L_01F0DC;
    case 0x01F0DFu: goto L_01F0DF;
    case 0x01F0E1u: goto L_01F0E1;
    case 0x01F0E4u: goto L_01F0E4;
    case 0x01F0E6u: goto L_01F0E6;
    case 0x01F0E8u: goto L_01F0E8;
    case 0x01F0EBu: goto L_01F0EB;
    case 0x01F0EEu: goto L_01F0EE;
    case 0x01F0F0u: goto L_01F0F0;
    case 0x01F0F2u: goto L_01F0F2;
    case 0x01F0F5u: goto L_01F0F5;
    case 0x01F0F7u: goto L_01F0F7;
    case 0x01F0F9u: goto L_01F0F9;
    case 0x01F0FBu: goto L_01F0FB;
    case 0x01F0FDu: goto L_01F0FD;
    case 0x01F0FFu: goto L_01F0FF;
    case 0x01F102u: goto L_01F102;
    case 0x01F105u: goto L_01F105;
    case 0x01F106u: goto L_01F106;
    case 0x01F108u: goto L_01F108;
    case 0x01F10Au: goto L_01F10A;
    case 0x01F10Cu: goto L_01F10C;
    case 0x01F10Eu: goto L_01F10E;
    case 0x01F111u: goto L_01F111;
    case 0x01F114u: goto L_01F114;
    case 0x01F116u: goto L_01F116;
    case 0x01F119u: goto L_01F119;
    case 0x01F11Cu: goto L_01F11C;
    case 0x01F11Eu: goto L_01F11E;
    case 0x01F120u: goto L_01F120;
    case 0x01F123u: goto L_01F123;
    case 0x01F125u: goto L_01F125;
    case 0x01F128u: goto L_01F128;
    case 0x01F12Au: goto L_01F12A;
    case 0x01F12Du: goto L_01F12D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01F0A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F0A1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01F0A1u);return;} hw.unresolvedReturn(0x01F0A1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01F0A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A2u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0A2 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0A4;
L_01F0A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0A4 CMP
    cpu.compareA(0x1u);
    goto L_01F0A6;
L_01F0A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0A6 BNE -> $01F0AC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F0AC; }
    goto L_01F0A8;
L_01F0A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0A8u, 8u, 4u, 0x02D0D4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01F0A8 JSL -> $02D0D4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF0ABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF0ACu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02D0D4u, 0x01F0A8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01F0AC;
L_01F0AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0ACu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF0ACu,0x01F0ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0ACu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0ACu, 4u, 3u, cpu.address("abs", 0x1410u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0AC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1410u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0AF;
L_01F0AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0AFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0AF CMP
    cpu.compareA(0x1u);
    goto L_01F0B1;
L_01F0B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0B1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0B1 BEQ -> $01F0A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F0A1; }
    goto L_01F0B3;
L_01F0B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0B3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0B3u, 4u, 3u, cpu.address("abs", 0x14A3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0B3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14A3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0B6;
L_01F0B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0B6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0B6 CMP
    cpu.compareA(0x10u);
    goto L_01F0B8;
L_01F0B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0B8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0B8 BNE -> $01F0C4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F0C4; }
    goto L_01F0BA;
L_01F0BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0BAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0BAu, 4u, 3u, cpu.address("abs", 0x18AEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0BA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18AEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0BD;
L_01F0BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0BDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0BD BNE -> $01F0C4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F0C4; }
    goto L_01F0BF;
L_01F0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0BF LDA
    cpu.setA(0x6u, 8);
    goto L_01F0C1;
L_01F0C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C1u, 4u, 3u, cpu.address("abs", 0x18AEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0C1 STA
    hw.write(cpu.address("abs", 0x18AEu), cpu.a, cpu.m8?8:16);
    goto L_01F0C4;
L_01F0C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C4u, 4u + ((((0x1594u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1594u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0C4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1594u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0C7;
L_01F0C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0C7u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01F0C7 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF0CAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF0CBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x01F0C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01F0CB;
L_01F0CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0CBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF0CBu,0x01F0CBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CBu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01F0CB PHK
    cpu.push("PHK", hw);
    goto L_01F0CC;
L_01F0CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CCu,cpu,0xF1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x14u) & 0xFFFFu), 2u, 0u);
    // $01F0CC SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectY(hw, 0x14u), cpu.m8?8:16));
    goto L_01F0CE;
L_01F0CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CEu,cpu,0xF3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0CEu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x32u) & 0xFFFFu), 2u, 0u);
    // $01F0CE SBC
    cpu.sbc(hw.readW(cpu.addressStackIndirectY(hw, 0x32u), cpu.m8?8:16));
    goto L_01F0D0;
L_01F0D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D0u,cpu,0xF3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D0u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x2Eu) & 0xFFFFu), 2u, 0u);
    // $01F0D0 SBC
    cpu.sbc(hw.readW(cpu.addressStackIndirectY(hw, 0x2Eu), cpu.m8?8:16));
    goto L_01F0D2;
L_01F0D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D2u,cpu,0xF1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xA9u) & 0xFFFFu), 2u, 0u);
    // $01F0D2 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectY(hw, 0xA9u), cpu.m8?8:16));
    goto L_01F0D4;
L_01F0D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D4u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0D4 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x8Du), cpu.m8?8:16);
    goto L_01F0D6;
L_01F0D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D6u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D6u, 4u + ((((0x221Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x221Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0D6 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x221Du), cpu.m8?8:16));
    goto L_01F0D9;
L_01F0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0D9 LSR
    cpu.lsrA();
    goto L_01F0DA;
L_01F0DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DAu,cpu,0xB3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DAu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x05u) & 0xFFFFu), 2u, 0u);
    // $01F0DA LDA
    cpu.loadA(hw.readW(cpu.addressStackIndirectY(hw, 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0DC;
L_01F0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DCu, 4u, 3u, cpu.address("abs", 0x18D6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0DC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18D6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0DF;
L_01F0DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0DF BEQ -> $01F12D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F12D; }
    goto L_01F0E1;
L_01F0E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E1u, 4u, 3u, cpu.address("abs", 0x18D6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0E1 STZ
    hw.write(cpu.address("abs", 0x18D6u), 0, cpu.m8?8:16);
    goto L_01F0E4;
L_01F0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0E4 CMP
    cpu.compareA(0x1u);
    goto L_01F0E6;
L_01F0E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0E6 BNE -> $01F0F9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F0F9; }
    goto L_01F0E8;
L_01F0E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E8u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0E8u, 6u, 3u, cpu.address("abs", 0x18D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0E8 INC
    cpu.incMem(hw, cpu.address("abs", 0x18D4u), cpu.m8?8:16);
    goto L_01F0EB;
L_01F0EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0EBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0EBu, 4u, 3u, cpu.address("abs", 0x18D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0EB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F0EE;
L_01F0EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0EEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0EE CMP
    cpu.compareA(0xAu);
    goto L_01F0F0;
L_01F0F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0F0 BNE -> $01F12D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F12D; }
    goto L_01F0F2;
L_01F0F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F2u, 4u, 3u, cpu.address("abs", 0x18D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0F2 STZ
    hw.write(cpu.address("abs", 0x18D4u), 0, cpu.m8?8:16);
    goto L_01F0F5;
L_01F0F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0F5 LDA
    cpu.setA(0x74u, 8);
    goto L_01F0F7;
L_01F0F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0F7 BRA -> $01F125
    goto L_01F125;
L_01F0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0F9 CMP
    cpu.compareA(0x3u);
    goto L_01F0FB;
L_01F0FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0FBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0FB BNE -> $01F116
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F116; }
    goto L_01F0FD;
L_01F0FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0FDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0FD LDA
    cpu.setA(0x29u, 8);
    goto L_01F0FF;
L_01F0FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF0FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF0FFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF0FFu, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F0FF STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_01F102;
L_01F102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF102u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF102u, 4u, 3u, cpu.address("abs", 0x0F32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F102 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF32u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F105;
L_01F105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF105u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF105u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F105 CLC
    cpu.setFlag('C', false);
    goto L_01F106;
L_01F106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF106u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF106u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F106 ADC
    cpu.adc(0x2u);
    goto L_01F108;
L_01F108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF108u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF108u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F108 CMP
    cpu.compareA(0xAu);
    goto L_01F10A;
L_01F10A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF10Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F10A BCC -> $01F111
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01F111; }
    goto L_01F10C;
L_01F10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF10Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F10C SBC
    cpu.sbc(0xAu);
    goto L_01F10E;
L_01F10E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF10Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Eu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Eu, 6u, 3u, cpu.address("abs", 0x0F31u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F10E INC
    cpu.incMem(hw, cpu.address("abs", 0xF31u), cpu.m8?8:16);
    goto L_01F111;
L_01F111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF111u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF111u, 4u, 3u, cpu.address("abs", 0x0F32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F111 STA
    hw.write(cpu.address("abs", 0xF32u), cpu.a, cpu.m8?8:16);
    goto L_01F114;
L_01F114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF114u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF114u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F114 BRA -> $01F12D
    goto L_01F12D;
L_01F116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF116u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF116u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF116u, 6u, 3u, cpu.address("abs", 0x18D5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F116 INC
    cpu.incMem(hw, cpu.address("abs", 0x18D5u), cpu.m8?8:16);
    goto L_01F119;
L_01F119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF119u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF119u, 4u, 3u, cpu.address("abs", 0x18D5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F119 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18D5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01F11C;
L_01F11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF11Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F11C CMP
    cpu.compareA(0x2u);
    goto L_01F11E;
L_01F11E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF11Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F11E BNE -> $01F12D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01F12D; }
    goto L_01F120;
L_01F120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF120u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF120u, 4u, 3u, cpu.address("abs", 0x18D5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F120 STZ
    hw.write(cpu.address("abs", 0x18D5u), 0, cpu.m8?8:16);
    goto L_01F123;
L_01F123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF123u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF123u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F123 LDA
    cpu.setA(0x6Au, 8);
    goto L_01F125;
L_01F125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF125u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF125u, 4u, 3u, cpu.address("abs", 0x18DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F125 STA
    hw.write(cpu.address("abs", 0x18DAu), cpu.a, cpu.m8?8:16);
    goto L_01F128;
L_01F128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF128u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF128u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F128 LDY
    cpu.setY(0x20u, 8);
    goto L_01F12A;
L_01F12A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Au,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Au, 4u, 3u, cpu.address("abs", 0x18DEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01F12A STY
    hw.write(cpu.address("abs", 0x18DEu), cpu.y, cpu.x8?8:16);
    goto L_01F12D;
L_01F12D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01F12D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01F12Du);return;} hw.unresolvedReturn(0x01F12Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_03B8FB_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x03B8FBu: goto L_03B8FB;
    case 0x03B8FEu: goto L_03B8FE;
    case 0x03B901u: goto L_03B901;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_03B8FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FBu, 4u + ((((0x15A0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B8FB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03B8FE;
L_03B8FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FEu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FEu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B8FE ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16));
    goto L_03B901;
L_03B901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $03B901 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x03B901u);return;} hw.unresolvedReturn(0x03B901u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_03B8FB_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x03B8FBu: goto L_03B8FB;
    case 0x03B8FEu: goto L_03B8FE;
    case 0x03B901u: goto L_03B901;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_03B8FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FBu, 4u + ((((0x15A0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B8FB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03B8FE;
L_03B8FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FEu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FEu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B8FE ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16));
    goto L_03B901;
L_03B901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $03B901 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x03B901u);return;} hw.unresolvedReturn(0x03B901u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_03B8FB_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x03B8FBu: goto L_03B8FB;
    case 0x03B8FEu: goto L_03B8FE;
    case 0x03B901u: goto L_03B901;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_03B8FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FBu, 4u + ((((0x15A0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B8FB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15A0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_03B8FE;
L_03B8FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FEu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FEu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03B8FE ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16));
    goto L_03B901;
L_03B901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $03B901 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x03B901u);return;} hw.unresolvedReturn(0x03B901u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04862E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04862Eu: goto L_04862E;
    case 0x048630u: goto L_048630;
    case 0x048633u: goto L_048633;
    case 0x048636u: goto L_048636;
    case 0x048637u: goto L_048637;
    case 0x048639u: goto L_048639;
    case 0x04863Cu: goto L_04863C;
    case 0x04863Eu: goto L_04863E;
    case 0x048640u: goto L_048640;
    case 0x048642u: goto L_048642;
    case 0x048645u: goto L_048645;
    case 0x048646u: goto L_048646;
    case 0x048648u: goto L_048648;
    case 0x04864Bu: goto L_04864B;
    case 0x04864Du: goto L_04864D;
    case 0x048650u: goto L_048650;
    case 0x048652u: goto L_048652;
    case 0x048654u: goto L_048654;
    case 0x048655u: goto L_048655;
    case 0x048658u: goto L_048658;
    case 0x048659u: goto L_048659;
    case 0x04865Cu: goto L_04865C;
    case 0x04865Du: goto L_04865D;
    case 0x04865Fu: goto L_04865F;
    case 0x048662u: goto L_048662;
    case 0x048664u: goto L_048664;
    case 0x048666u: goto L_048666;
    case 0x048668u: goto L_048668;
    case 0x04866Bu: goto L_04866B;
    case 0x04866Cu: goto L_04866C;
    case 0x04866Eu: goto L_04866E;
    case 0x048671u: goto L_048671;
    case 0x048673u: goto L_048673;
    case 0x048676u: goto L_048676;
    case 0x048678u: goto L_048678;
    case 0x04867Au: goto L_04867A;
    case 0x04867Cu: goto L_04867C;
    case 0x04867Eu: goto L_04867E;
    case 0x04867Fu: goto L_04867F;
    case 0x048681u: goto L_048681;
    case 0x048683u: goto L_048683;
    case 0x048685u: goto L_048685;
    case 0x048686u: goto L_048686;
    case 0x048688u: goto L_048688;
    case 0x04868Au: goto L_04868A;
    case 0x04868Cu: goto L_04868C;
    case 0x04868Du: goto L_04868D;
    case 0x04868Fu: goto L_04868F;
    case 0x048691u: goto L_048691;
    case 0x048693u: goto L_048693;
    case 0x048694u: goto L_048694;
    case 0x048696u: goto L_048696;
    case 0x048698u: goto L_048698;
    case 0x04869Au: goto L_04869A;
    case 0x04869Cu: goto L_04869C;
    case 0x04869Eu: goto L_04869E;
    case 0x0486A0u: goto L_0486A0;
    case 0x0486A2u: goto L_0486A2;
    case 0x0486A4u: goto L_0486A4;
    case 0x0486A6u: goto L_0486A6;
    case 0x0486A8u: goto L_0486A8;
    case 0x0486ABu: goto L_0486AB;
    case 0x0486ACu: goto L_0486AC;
    case 0x0486ADu: goto L_0486AD;
    case 0x0486B0u: goto L_0486B0;
    case 0x0486B2u: goto L_0486B2;
    case 0x0486B4u: goto L_0486B4;
    case 0x0486B6u: goto L_0486B6;
    case 0x0486B8u: goto L_0486B8;
    case 0x0486BAu: goto L_0486BA;
    case 0x0486BCu: goto L_0486BC;
    case 0x0486BEu: goto L_0486BE;
    case 0x0486BFu: goto L_0486BF;
    case 0x0486C1u: goto L_0486C1;
    case 0x0486C3u: goto L_0486C3;
    case 0x0486C5u: goto L_0486C5;
    case 0x0486C7u: goto L_0486C7;
    case 0x0486CAu: goto L_0486CA;
    case 0x0486CBu: goto L_0486CB;
    case 0x0486CCu: goto L_0486CC;
    case 0x0486CEu: goto L_0486CE;
    case 0x0486D1u: goto L_0486D1;
    case 0x0486D4u: goto L_0486D4;
    case 0x0486D7u: goto L_0486D7;
    case 0x0486D8u: goto L_0486D8;
    case 0x0486D9u: goto L_0486D9;
    case 0x0486DCu: goto L_0486DC;
    case 0x0486DFu: goto L_0486DF;
    case 0x0486E1u: goto L_0486E1;
    case 0x0486E4u: goto L_0486E4;
    case 0x0486E7u: goto L_0486E7;
    case 0x0486EAu: goto L_0486EA;
    case 0x0486EDu: goto L_0486ED;
    case 0x0486F0u: goto L_0486F0;
    case 0x0486F3u: goto L_0486F3;
    case 0x0486F6u: goto L_0486F6;
    case 0x0486F9u: goto L_0486F9;
    case 0x0486FBu: goto L_0486FB;
    case 0x0486FDu: goto L_0486FD;
    case 0x048700u: goto L_048700;
    case 0x048703u: goto L_048703;
    case 0x048705u: goto L_048705;
    case 0x048707u: goto L_048707;
    case 0x048709u: goto L_048709;
    case 0x04870Cu: goto L_04870C;
    case 0x04870Eu: goto L_04870E;
    case 0x048710u: goto L_048710;
    case 0x048712u: goto L_048712;
    case 0x048714u: goto L_048714;
    case 0x048716u: goto L_048716;
    case 0x048718u: goto L_048718;
    case 0x04871Au: goto L_04871A;
    case 0x04871Du: goto L_04871D;
    case 0x04871Eu: goto L_04871E;
    case 0x048720u: goto L_048720;
    case 0x048721u: goto L_048721;
    case 0x048724u: goto L_048724;
    case 0x048726u: goto L_048726;
    case 0x048728u: goto L_048728;
    case 0x04872Au: goto L_04872A;
    case 0x04872Cu: goto L_04872C;
    case 0x04872Eu: goto L_04872E;
    case 0x048730u: goto L_048730;
    case 0x048732u: goto L_048732;
    case 0x048733u: goto L_048733;
    case 0x048735u: goto L_048735;
    case 0x048737u: goto L_048737;
    case 0x048739u: goto L_048739;
    case 0x04873Bu: goto L_04873B;
    case 0x04873Eu: goto L_04873E;
    case 0x048741u: goto L_048741;
    case 0x048743u: goto L_048743;
    case 0x048745u: goto L_048745;
    case 0x048748u: goto L_048748;
    case 0x04874Au: goto L_04874A;
    case 0x04874Cu: goto L_04874C;
    case 0x04874Fu: goto L_04874F;
    case 0x048751u: goto L_048751;
    case 0x048753u: goto L_048753;
    case 0x048756u: goto L_048756;
    case 0x048758u: goto L_048758;
    case 0x04875Bu: goto L_04875B;
    case 0x04875Eu: goto L_04875E;
    case 0x048761u: goto L_048761;
    case 0x048762u: goto L_048762;
    case 0x048765u: goto L_048765;
    case 0x048766u: goto L_048766;
    case 0x048769u: goto L_048769;
    case 0x04876Cu: goto L_04876C;
    case 0x04876Eu: goto L_04876E;
    case 0x048771u: goto L_048771;
    case 0x048774u: goto L_048774;
    case 0x048777u: goto L_048777;
    case 0x04877Au: goto L_04877A;
    case 0x04877Du: goto L_04877D;
    case 0x048780u: goto L_048780;
    case 0x048783u: goto L_048783;
    case 0x048786u: goto L_048786;
    case 0x048788u: goto L_048788;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04862E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04862E REP
    cpu.rep(0x30u);
    goto L_048630;
L_048630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8630u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8630u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048630 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_048633;
L_048633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u, 5u + 1u, 3u, cpu.address("absx", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048633 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048636;
L_048636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048636 SEC
    cpu.setFlag('C', true);
    goto L_048637;
L_048637:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8637u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8637u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8637u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048637 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_048639;
L_048639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048639 CMP
    cpu.compareA(0x100u);
    goto L_04863C;
L_04863C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04863C BCS -> $04864D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_04864D; }
    goto L_04863E;
L_04863E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04863E STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_048640;
L_048640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8640u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8640u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8640u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048640 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_048642;
L_048642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u, 5u + 1u, 3u, cpu.address("absx", 0x1F19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048642 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048645;
L_048645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8645u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8645u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048645 SEC
    cpu.setFlag('C', true);
    goto L_048646;
L_048646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8646u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8646u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8646u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048646 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_048648;
L_048648:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8648u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8648u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8648u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048648 CMP
    cpu.compareA(0x100u);
    goto L_04864B;
L_04864B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04864B BCC -> $048650
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_048650; }
    goto L_04864D;
L_04864D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04864D LDA
    cpu.setA(0xF0u, 16);
    goto L_048650;
L_048650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8650u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8650u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048650 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_048652;
L_048652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8652u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8652u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048652 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_048654;
L_048654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8654u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8654u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048654 TXA
    cpu.transfer("TXA");
    goto L_048655;
L_048655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8655u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8655u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048655 EOR
    cpu.logicXor(0x4u);
    goto L_048658;
L_048658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8658u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8658u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048658 TAX
    cpu.transfer("TAX");
    goto L_048659;
L_048659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8659u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8659u, 5u + 1u, 3u, cpu.address("absx", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048659 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04865C;
L_04865C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04865C SEC
    cpu.setFlag('C', true);
    goto L_04865D;
L_04865D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Du,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04865D SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_04865F;
L_04865F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04865F CMP
    cpu.compareA(0x100u);
    goto L_048662;
L_048662:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8662u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8662u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8662u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048662 BCS -> $048673
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_048673; }
    goto L_048664;
L_048664:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8664u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8664u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8664u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048664 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_048666;
L_048666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8666u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8666u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048666 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_048668;
L_048668:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8668u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8668u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8668u, 5u + 1u, 3u, cpu.address("absx", 0x1F19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048668 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04866B;
L_04866B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04866B SEC
    cpu.setFlag('C', true);
    goto L_04866C;
L_04866C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Cu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04866C SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_04866E;
L_04866E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04866E CMP
    cpu.compareA(0x100u);
    goto L_048671;
L_048671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8671u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8671u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048671 BCC -> $048676
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_048676; }
    goto L_048673;
L_048673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8673u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8673u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048673 LDA
    cpu.setA(0xF0u, 16);
    goto L_048676;
L_048676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048676 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_048678;
L_048678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8678u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8678u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048678 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_04867A;
L_04867A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04867A SEP
    cpu.sep(0x30u);
    goto L_04867C;
L_04867C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04867C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04867E;
L_04867E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04867E SEC
    cpu.setFlag('C', true);
    goto L_04867F;
L_04867F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04867F SBC
    cpu.sbc(0x8u);
    goto L_048681;
L_048681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8681u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8681u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048681 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_048683;
L_048683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048683 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048685;
L_048685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8685u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8685u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8685u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048685 SEC
    cpu.setFlag('C', true);
    goto L_048686;
L_048686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8686u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8686u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048686 SBC
    cpu.sbc(0x9u);
    goto L_048688;
L_048688:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8688u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8688u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8688u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048688 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_04868A;
L_04868A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04868A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04868C;
L_04868C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04868C SEC
    cpu.setFlag('C', true);
    goto L_04868D;
L_04868D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04868D SBC
    cpu.sbc(0x8u);
    goto L_04868F;
L_04868F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04868F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_048691;
L_048691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8691u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8691u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8691u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048691 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048693;
L_048693:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8693u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8693u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8693u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048693 SEC
    cpu.setFlag('C', true);
    goto L_048694;
L_048694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8694u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8694u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048694 SBC
    cpu.sbc(0x9u);
    goto L_048696;
L_048696:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8696u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8696u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8696u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048696 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_048698;
L_048698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8698u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8698u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8698u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048698 LDA
    cpu.setA(0x3u, 8);
    goto L_04869A;
L_04869A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04869A STA
    hw.write(cpu.address("dp", 0x8Cu), cpu.a, cpu.m8?8:16);
    goto L_04869C;
L_04869C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04869C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04869E;
L_04869E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04869E STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_0486A0;
L_0486A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486A0 STA
    hw.write(cpu.address("dp", 0x8Au), cpu.a, cpu.m8?8:16);
    goto L_0486A2;
L_0486A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486A2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0486A4;
L_0486A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486A4 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_0486A6;
L_0486A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486A6 STA
    hw.write(cpu.address("dp", 0x8Bu), cpu.a, cpu.m8?8:16);
    goto L_0486A8;
L_0486A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A8u, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486A8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0486AB;
L_0486AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ABu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486AB LSR
    cpu.lsrA();
    goto L_0486AC;
L_0486AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486AC TAY
    cpu.transfer("TAY");
    goto L_0486AD;
L_0486AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ADu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ADu, 4u + ((((0x1F13u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486AD LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1F13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0486B0;
L_0486B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486B0 CMP
    cpu.compareA(0x12u);
    goto L_0486B2;
L_0486B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486B2 BEQ -> $0486C5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0486C5; }
    goto L_0486B4;
L_0486B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486B4 CMP
    cpu.compareA(0x7u);
    goto L_0486B6;
L_0486B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486B6 BCC -> $0486BC
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0486BC; }
    goto L_0486B8;
L_0486B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486B8 CMP
    cpu.compareA(0xFu);
    goto L_0486BA;
L_0486BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486BA BCC -> $0486C5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0486C5; }
    goto L_0486BC;
L_0486BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486BC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0486BE;
L_0486BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486BE SEC
    cpu.setFlag('C', true);
    goto L_0486BF;
L_0486BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BFu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486BF SBC
    cpu.sbc(0x5u);
    goto L_0486C1;
L_0486C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486C1 STA
    hw.write(cpu.address("dp", 0x8Bu), cpu.a, cpu.m8?8:16);
    goto L_0486C3;
L_0486C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486C3 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_0486C5;
L_0486C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486C5 REP
    cpu.rep(0x30u);
    goto L_0486C7;
L_0486C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C7u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486C7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0486CA;
L_0486CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CAu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486CA XBA
    cpu.xba();
    goto L_0486CB;
L_0486CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CBu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486CB LSR
    cpu.lsrA();
    goto L_0486CC;
L_0486CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486CC STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_0486CE;
L_0486CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486CE LDX
    cpu.setX(0x0u, 16);
    goto L_0486D1;
L_0486D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D1u, 6u, 3u, cpu.address("abs", 0x8789u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0486D1 JSR -> $048789 stack real
    { cpu.push16Value(hw,0x86D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8789u), 0x0486D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0486D4;
L_0486D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86D4u,0x0486D4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486D4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0486D7;
L_0486D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486D7 LSR
    cpu.lsrA();
    goto L_0486D8;
L_0486D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D8u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486D8 TAY
    cpu.transfer("TAY");
    goto L_0486D9;
L_0486D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486D9 LDX
    cpu.setX(0x0u, 16);
    goto L_0486DC;
L_0486DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DCu, 6u, 3u, cpu.address("abs", 0x894Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0486DC JSR -> $04894F stack real
    { cpu.push16Value(hw,0x86DEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86DFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x894Fu), 0x0486DCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0486DF;
L_0486DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86DFu,0x0486DFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486DF SEP
    cpu.sep(0x30u);
    goto L_0486E1;
L_0486E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E1u, 4u, 3u, cpu.address("abs", 0x0447u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486E1 STZ
    hw.write(cpu.address("abs", 0x447u), 0, cpu.m8?8:16);
    goto L_0486E4;
L_0486E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u, 4u, 3u, cpu.address("abs", 0x0448u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486E4 STZ
    hw.write(cpu.address("abs", 0x448u), 0, cpu.m8?8:16);
    goto L_0486E7;
L_0486E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E7u, 4u, 3u, cpu.address("abs", 0x0449u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486E7 STZ
    hw.write(cpu.address("abs", 0x449u), 0, cpu.m8?8:16);
    goto L_0486EA;
L_0486EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EAu, 4u, 3u, cpu.address("abs", 0x044Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486EA STZ
    hw.write(cpu.address("abs", 0x44Au), 0, cpu.m8?8:16);
    goto L_0486ED;
L_0486ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EDu, 4u, 3u, cpu.address("abs", 0x044Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486ED STZ
    hw.write(cpu.address("abs", 0x44Bu), 0, cpu.m8?8:16);
    goto L_0486F0;
L_0486F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F0u, 4u, 3u, cpu.address("abs", 0x044Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486F0 STZ
    hw.write(cpu.address("abs", 0x44Cu), 0, cpu.m8?8:16);
    goto L_0486F3;
L_0486F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u, 4u, 3u, cpu.address("abs", 0x044Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486F3 STZ
    hw.write(cpu.address("abs", 0x44Du), 0, cpu.m8?8:16);
    goto L_0486F6;
L_0486F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F6u, 4u, 3u, cpu.address("abs", 0x044Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486F6 STZ
    hw.write(cpu.address("abs", 0x44Eu), 0, cpu.m8?8:16);
    goto L_0486F9;
L_0486F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486F9 LDA
    cpu.setA(0x3u, 8);
    goto L_0486FB;
L_0486FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486FB STA
    hw.write(cpu.address("dp", 0x8Cu), cpu.a, cpu.m8?8:16);
    goto L_0486FD;
L_0486FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FDu, 4u, 3u, cpu.address("abs", 0x1F11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0486FD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1F11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048700;
L_048700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8700u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8700u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048700 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x13D9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_048703;
L_048703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8703u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8703u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8703u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048703 CPY
    cpu.compareY(0xAu);
    goto L_048705;
L_048705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8705u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8705u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048705 BNE -> $048709
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_048709; }
    goto L_048707;
L_048707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048707 EOR
    cpu.logicXor(0x1u);
    goto L_048709;
L_048709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8709u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8709u, 4u, 3u, cpu.address("abs", 0x1F12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048709 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1F12u), cpu.m8?8:16));
    goto L_04870C;
L_04870C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04870C BNE -> $048786
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_048786; }
    goto L_04870E;
L_04870E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04870E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048710;
L_048710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048710 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_048712;
L_048712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048712 STA
    hw.write(cpu.address("dp", 0x8Au), cpu.a, cpu.m8?8:16);
    goto L_048714;
L_048714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048714 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048716;
L_048716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8716u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8716u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048716 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_048718;
L_048718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8718u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8718u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048718 STA
    hw.write(cpu.address("dp", 0x8Bu), cpu.a, cpu.m8?8:16);
    goto L_04871A;
L_04871A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Au, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04871A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04871D;
L_04871D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04871D LSR
    cpu.lsrA();
    goto L_04871E;
L_04871E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Eu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04871E EOR
    cpu.logicXor(0x2u);
    goto L_048720;
L_048720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8720u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8720u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048720 TAY
    cpu.transfer("TAY");
    goto L_048721;
L_048721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8721u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8721u, 4u + ((((0x1F13u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048721 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1F13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048724;
L_048724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048724 CMP
    cpu.compareA(0x12u);
    goto L_048726;
L_048726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048726 BEQ -> $048739
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_048739; }
    goto L_048728;
L_048728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048728 CMP
    cpu.compareA(0x7u);
    goto L_04872A;
L_04872A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04872A BCC -> $048730
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_048730; }
    goto L_04872C;
L_04872C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04872C CMP
    cpu.compareA(0xFu);
    goto L_04872E;
L_04872E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04872E BCC -> $048739
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_048739; }
    goto L_048730;
L_048730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8730u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8730u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048730 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048732;
L_048732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048732 SEC
    cpu.setFlag('C', true);
    goto L_048733;
L_048733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8733u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8733u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048733 SBC
    cpu.sbc(0x5u);
    goto L_048735;
L_048735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8735u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8735u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048735 STA
    hw.write(cpu.address("dp", 0x8Bu), cpu.a, cpu.m8?8:16);
    goto L_048737;
L_048737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8737u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8737u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048737 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_048739;
L_048739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8739u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8739u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048739 REP
    cpu.rep(0x30u);
    goto L_04873B;
L_04873B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Bu, 5u, 3u, cpu.address("abs", 0x0DB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04873B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDB2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04873E;
L_04873E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04873E AND
    cpu.logicAnd(0xFFu);
    goto L_048741;
L_048741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8741u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8741u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048741 BEQ -> $048786
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_048786; }
    goto L_048743;
L_048743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8743u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8743u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048743 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048745;
L_048745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048745 CMP
    cpu.compareA(0xF0u);
    goto L_048748;
L_048748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8748u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8748u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048748 BCS -> $048786
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_048786; }
    goto L_04874A;
L_04874A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04874A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04874C;
L_04874C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04874C CMP
    cpu.compareA(0xF0u);
    goto L_04874F;
L_04874F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04874F BCS -> $048786
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_048786; }
    goto L_048751;
L_048751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8751u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8751u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048751 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048753;
L_048753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8753u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8753u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8753u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048753 EOR
    cpu.logicXor(0x200u);
    goto L_048756;
L_048756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8756u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8756u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048756 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_048758;
L_048758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048758 LDX
    cpu.setX(0x20u, 16);
    goto L_04875B;
L_04875B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Bu, 6u, 3u, cpu.address("abs", 0x8789u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04875B JSR -> $048789 stack real
    { cpu.push16Value(hw,0x875Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x875Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8789u), 0x04875Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04875E;
L_04875E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x875Eu,0x04875Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Eu, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04875E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048761;
L_048761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8761u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8761u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048761 LSR
    cpu.lsrA();
    goto L_048762;
L_048762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8762u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8762u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048762 EOR
    cpu.logicXor(0x2u);
    goto L_048765;
L_048765:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8765u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8765u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8765u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048765 TAY
    cpu.transfer("TAY");
    goto L_048766;
L_048766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048766 LDX
    cpu.setX(0x20u, 16);
    goto L_048769;
L_048769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8769u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8769u, 6u, 3u, cpu.address("abs", 0x894Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048769 JSR -> $04894F stack real
    { cpu.push16Value(hw,0x876Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x876Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x894Fu), 0x048769u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04876C;
L_04876C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x876Cu,0x04876Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04876C SEP
    cpu.sep(0x30u);
    goto L_04876E;
L_04876E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Eu, 4u, 3u, cpu.address("abs", 0x044Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04876E STZ
    hw.write(cpu.address("abs", 0x44Fu), 0, cpu.m8?8:16);
    goto L_048771;
L_048771:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8771u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8771u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8771u, 4u, 3u, cpu.address("abs", 0x0450u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048771 STZ
    hw.write(cpu.address("abs", 0x450u), 0, cpu.m8?8:16);
    goto L_048774;
L_048774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u, 4u, 3u, cpu.address("abs", 0x0451u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048774 STZ
    hw.write(cpu.address("abs", 0x451u), 0, cpu.m8?8:16);
    goto L_048777;
L_048777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8777u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u, 4u, 3u, cpu.address("abs", 0x0452u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048777 STZ
    hw.write(cpu.address("abs", 0x452u), 0, cpu.m8?8:16);
    goto L_04877A;
L_04877A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Au, 4u, 3u, cpu.address("abs", 0x0453u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04877A STZ
    hw.write(cpu.address("abs", 0x453u), 0, cpu.m8?8:16);
    goto L_04877D;
L_04877D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Du, 4u, 3u, cpu.address("abs", 0x0454u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04877D STZ
    hw.write(cpu.address("abs", 0x454u), 0, cpu.m8?8:16);
    goto L_048780;
L_048780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8780u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8780u, 4u, 3u, cpu.address("abs", 0x0455u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048780 STZ
    hw.write(cpu.address("abs", 0x455u), 0, cpu.m8?8:16);
    goto L_048783;
L_048783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u, 4u, 3u, cpu.address("abs", 0x0456u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048783 STZ
    hw.write(cpu.address("abs", 0x456u), 0, cpu.m8?8:16);
    goto L_048786;
L_048786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8786u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8786u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8786u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048786 SEP
    cpu.sep(0x30u);
    goto L_048788;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8786u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8786u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048786 SEP
    cpu.sep(0x30u);
    goto L_048788;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8786u,0x048786u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_048788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048788 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x048788u);return;} hw.unresolvedReturn(0x048788u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_048E55_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0480E0u: goto L_0480E0;
    case 0x0480E2u: goto L_0480E2;
    case 0x0480E4u: goto L_0480E4;
    case 0x0480E6u: goto L_0480E6;
    case 0x0480E8u: goto L_0480E8;
    case 0x0480EBu: goto L_0480EB;
    case 0x0480EDu: goto L_0480ED;
    case 0x0480EEu: goto L_0480EE;
    case 0x0480F0u: goto L_0480F0;
    case 0x0480F2u: goto L_0480F2;
    case 0x0480F4u: goto L_0480F4;
    case 0x0480F7u: goto L_0480F7;
    case 0x0480F9u: goto L_0480F9;
    case 0x0480FBu: goto L_0480FB;
    case 0x0480FEu: goto L_0480FE;
    case 0x0480FFu: goto L_0480FF;
    case 0x048101u: goto L_048101;
    case 0x048103u: goto L_048103;
    case 0x048105u: goto L_048105;
    case 0x048107u: goto L_048107;
    case 0x048109u: goto L_048109;
    case 0x04810Cu: goto L_04810C;
    case 0x04810Eu: goto L_04810E;
    case 0x048110u: goto L_048110;
    case 0x048112u: goto L_048112;
    case 0x048114u: goto L_048114;
    case 0x048117u: goto L_048117;
    case 0x048118u: goto L_048118;
    case 0x04811Bu: goto L_04811B;
    case 0x04811Cu: goto L_04811C;
    case 0x04811Eu: goto L_04811E;
    case 0x048120u: goto L_048120;
    case 0x048123u: goto L_048123;
    case 0x048125u: goto L_048125;
    case 0x048128u: goto L_048128;
    case 0x04812Au: goto L_04812A;
    case 0x04812Cu: goto L_04812C;
    case 0x04812Fu: goto L_04812F;
    case 0x048131u: goto L_048131;
    case 0x048134u: goto L_048134;
    case 0x048136u: goto L_048136;
    case 0x048139u: goto L_048139;
    case 0x04813Au: goto L_04813A;
    case 0x04813Cu: goto L_04813C;
    case 0x04813Du: goto L_04813D;
    case 0x04813Eu: goto L_04813E;
    case 0x048141u: goto L_048141;
    case 0x048143u: goto L_048143;
    case 0x048144u: goto L_048144;
    case 0x048145u: goto L_048145;
    case 0x048147u: goto L_048147;
    case 0x048148u: goto L_048148;
    case 0x04814Bu: goto L_04814B;
    case 0x04814Du: goto L_04814D;
    case 0x04814Fu: goto L_04814F;
    case 0x048151u: goto L_048151;
    case 0x048153u: goto L_048153;
    case 0x048155u: goto L_048155;
    case 0x048157u: goto L_048157;
    case 0x04815Au: goto L_04815A;
    case 0x04815Cu: goto L_04815C;
    case 0x04815Du: goto L_04815D;
    case 0x048160u: goto L_048160;
    case 0x048162u: goto L_048162;
    case 0x048164u: goto L_048164;
    case 0x048165u: goto L_048165;
    case 0x048168u: goto L_048168;
    case 0x04816Au: goto L_04816A;
    case 0x04816Du: goto L_04816D;
    case 0x04816Fu: goto L_04816F;
    case 0x048171u: goto L_048171;
    case 0x048E55u: goto L_048E55;
    case 0x048E57u: goto L_048E57;
    case 0x048E5Au: goto L_048E5A;
    case 0x048E5Du: goto L_048E5D;
    case 0x048E5Eu: goto L_048E5E;
    case 0x048E5Fu: goto L_048E5F;
    case 0x048E62u: goto L_048E62;
    case 0x048E65u: goto L_048E65;
    case 0x048E68u: goto L_048E68;
    case 0x048E6Au: goto L_048E6A;
    case 0x048E6Du: goto L_048E6D;
    case 0x048E6Fu: goto L_048E6F;
    case 0x048E70u: goto L_048E70;
    case 0x048E71u: goto L_048E71;
    case 0x048E72u: goto L_048E72;
    case 0x048E73u: goto L_048E73;
    case 0x048E76u: goto L_048E76;
    case 0x048E78u: goto L_048E78;
    case 0x048E7Au: goto L_048E7A;
    case 0x048E7Eu: goto L_048E7E;
    case 0x048E81u: goto L_048E81;
    case 0x048E82u: goto L_048E82;
    case 0x048E83u: goto L_048E83;
    case 0x048E86u: goto L_048E86;
    case 0x048E88u: goto L_048E88;
    case 0x048E8Bu: goto L_048E8B;
    case 0x048E8Du: goto L_048E8D;
    case 0x048E8Fu: goto L_048E8F;
    case 0x048E92u: goto L_048E92;
    case 0x048E94u: goto L_048E94;
    case 0x048E98u: goto L_048E98;
    case 0x048E9Bu: goto L_048E9B;
    case 0x048E9Eu: goto L_048E9E;
    case 0x048EA0u: goto L_048EA0;
    case 0x048EA3u: goto L_048EA3;
    case 0x048EA5u: goto L_048EA5;
    case 0x048EA7u: goto L_048EA7;
    case 0x048EA8u: goto L_048EA8;
    case 0x048EAAu: goto L_048EAA;
    case 0x048EABu: goto L_048EAB;
    case 0x048EAEu: goto L_048EAE;
    case 0x048EB1u: goto L_048EB1;
    case 0x048EB4u: goto L_048EB4;
    case 0x048EB6u: goto L_048EB6;
    case 0x048EB7u: goto L_048EB7;
    case 0x048EB8u: goto L_048EB8;
    case 0x048EBAu: goto L_048EBA;
    case 0x048EBDu: goto L_048EBD;
    case 0x048EC0u: goto L_048EC0;
    case 0x048EC3u: goto L_048EC3;
    case 0x048EC6u: goto L_048EC6;
    case 0x048EC9u: goto L_048EC9;
    case 0x048ECBu: goto L_048ECB;
    case 0x048ECDu: goto L_048ECD;
    case 0x048ECEu: goto L_048ECE;
    case 0x048ED1u: goto L_048ED1;
    case 0x048ED4u: goto L_048ED4;
    case 0x048ED7u: goto L_048ED7;
    case 0x048ED9u: goto L_048ED9;
    case 0x048EDCu: goto L_048EDC;
    case 0x048EDEu: goto L_048EDE;
    case 0x048EE1u: goto L_048EE1;
    case 0x048EE3u: goto L_048EE3;
    case 0x048EE6u: goto L_048EE6;
    case 0x048EE8u: goto L_048EE8;
    case 0x048EEBu: goto L_048EEB;
    case 0x048EEEu: goto L_048EEE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0480E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0480E0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0480E2;
L_0480E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0480E2 AND
    cpu.logicAnd(0x7u);
    goto L_0480E4;
L_0480E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0480E4 BNE -> $048101
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_048101; }
    goto L_0480E6;
L_0480E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0480E6 LDX
    cpu.setX(0x1Fu, 8);
    goto L_0480E8;
L_0480E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u, 4u + ((((0x0AF6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0AF6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0480E8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xAF6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0480EB;
L_0480EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0480EB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0480ED;
L_0480ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0480ED TXA
    cpu.transfer("TXA");
    goto L_0480EE;
L_0480EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0480EE AND
    cpu.logicAnd(0x8u);
    goto L_0480F0;
L_0480F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0480F0 BNE -> $0480F9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0480F9; }
    goto L_0480F2;
L_0480F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0480F2 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0480F4;
L_0480F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u,cpu,0x3Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u, 7u, 3u, cpu.address("absx", 0x0AF6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0480F4 ROL
    cpu.rolMem(hw, cpu.address("absx", 0xAF6u), cpu.m8?8:16);
    goto L_0480F7;
L_0480F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0480F7 BRA -> $0480FE
    goto L_0480FE;
L_0480F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0480F9 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0480FB;
L_0480FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu, 7u, 3u, cpu.address("absx", 0x0AF6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0480FB ROR
    cpu.rorMem(hw, cpu.address("absx", 0xAF6u), cpu.m8?8:16);
    goto L_0480FE;
L_0480FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0480FE DEX
    cpu.decReg('X');
    goto L_0480FF;
L_0480FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0480FF BPL -> $0480E8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0480E8; }
    goto L_048101;
L_048101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048101 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048103;
L_048103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048103 AND
    cpu.logicAnd(0x7u);
    goto L_048105;
L_048105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048105 BNE -> $04810C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04810C; }
    goto L_048107;
L_048107:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8107u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8107u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8107u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048107 LDX
    cpu.setX(0x20u, 8);
    goto L_048109;
L_048109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8109u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u, 6u, 3u, cpu.address("abs", 0x8172u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048109 JSR -> $048172 stack real
    { cpu.push16Value(hw,0x810Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x810Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8172u), 0x048109u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04810C;
L_04810C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x810Cu,0x04810Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04810C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04810E;
L_04810E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04810E AND
    cpu.logicAnd(0x7u);
    goto L_048110;
L_048110:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8110u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8110u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8110u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048110 BNE -> $048123
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_048123; }
    goto L_048112;
L_048112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8112u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8112u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048112 LDX
    cpu.setX(0x1Fu, 8);
    goto L_048114;
L_048114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u, 4u + ((((0x0B36u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0B36u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048114 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048117;
L_048117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8117u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8117u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048117 ASL
    cpu.aslA();
    goto L_048118;
L_048118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8118u,cpu,0x3Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8118u, 7u, 3u, cpu.address("absx", 0x0B36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048118 ROL
    cpu.rolMem(hw, cpu.address("absx", 0xB36u), cpu.m8?8:16);
    goto L_04811B;
L_04811B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04811B DEX
    cpu.decReg('X');
    goto L_04811C;
L_04811C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04811C BPL -> $048114
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_048114; }
    goto L_04811E;
L_04811E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04811E LDX
    cpu.setX(0x40u, 8);
    goto L_048120;
L_048120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u, 6u, 3u, cpu.address("abs", 0x8172u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048120 JSR -> $048172 stack real
    { cpu.push16Value(hw,0x8122u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8123u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8172u), 0x048120u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_048123;
L_048123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8123u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8123u,0x048123u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048123 REP
    cpu.rep(0x30u);
    goto L_048125;
L_048125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048125 LDA
    cpu.setA(0x60u, 16);
    goto L_048128;
L_048128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8128u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8128u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048128 STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_04812A;
L_04812A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04812A STZ
    hw.write(cpu.address("dp", 0xBu), 0, cpu.m8?8:16);
    goto L_04812C;
L_04812C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04812C LDX
    cpu.setX(0x38u, 16);
    goto L_04812F;
L_04812F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04812F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048131;
L_048131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048131 CMP
    cpu.compareA(0x20u);
    goto L_048134;
L_048134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8134u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8134u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048134 BCS -> $048139
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_048139; }
    goto L_048136;
L_048136:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8136u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8136u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8136u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048136 LDX
    cpu.setX(0x70u, 16);
    goto L_048139;
L_048139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8139u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8139u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048139 TXA
    cpu.transfer("TXA");
    goto L_04813A;
L_04813A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Au,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04813A AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_04813C;
L_04813C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04813C LSR
    cpu.lsrA();
    goto L_04813D;
L_04813D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04813D LSR
    cpu.lsrA();
    goto L_04813E;
L_04813E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Eu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04813E CPX
    cpu.compareX(0x38u);
    goto L_048141;
L_048141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8141u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8141u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048141 BEQ -> $048144
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_048144; }
    goto L_048143;
L_048143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8143u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8143u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048143 LSR
    cpu.lsrA();
    goto L_048144;
L_048144:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8144u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8144u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8144u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048144 CLC
    cpu.setFlag('C', false);
    goto L_048145;
L_048145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8145u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8145u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048145 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16));
    goto L_048147;
L_048147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8147u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8147u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048147 TAX
    cpu.transfer("TAX");
    goto L_048148;
L_048148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8148u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8148u, 5u + 1u, 3u, cpu.address("absx", 0x8006u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048148 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8006u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04814B;
L_04814B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04814B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04814D;
L_04814D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04814D SEP
    cpu.sep(0x10u);
    goto L_04814F;
L_04814F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04814F LDY
    cpu.setY(0x7Eu, 8);
    goto L_048151;
L_048151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8151u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8151u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8151u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048151 STY
    hw.write(cpu.address("dp", 0x2u), cpu.y, cpu.x8?8:16);
    goto L_048153;
L_048153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8153u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8153u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048153 REP
    cpu.rep(0x10u);
    goto L_048155;
L_048155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8155u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8155u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048155 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_048157;
L_048157:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8157u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8157u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8157u, 6u, 3u, cpu.address("abs", 0x80B9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048157 JSR -> $0480B9 stack real
    { cpu.push16Value(hw,0x8159u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x815Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80B9u), 0x048157u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04815A;
L_04815A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x815Au,0x04815Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04815A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04815C;
L_04815C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04815C CLC
    cpu.setFlag('C', false);
    goto L_04815D;
L_04815D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04815D ADC
    cpu.adc(0x20u);
    goto L_048160;
L_048160:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8160u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8160u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8160u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048160 STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_048162;
L_048162:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8162u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8162u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8162u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048162 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048164;
L_048164:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8164u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8164u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8164u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048164 CLC
    cpu.setFlag('C', false);
    goto L_048165;
L_048165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8165u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8165u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048165 ADC
    cpu.adc(0x10u);
    goto L_048168;
L_048168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8168u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8168u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048168 STA
    hw.write(cpu.address("dp", 0xBu), cpu.a, cpu.m8?8:16);
    goto L_04816A;
L_04816A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04816A CMP
    cpu.compareA(0x80u);
    goto L_04816D;
L_04816D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04816D BNE -> $04812C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04812C; }
    goto L_04816F;
L_04816F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04816F SEP
    cpu.sep(0x30u);
    goto L_048171;
L_048171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8171u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8171u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048171 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x048171u);return;} hw.unresolvedReturn(0x048171u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_048E55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E55u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E55u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E55 REP
    cpu.rep(0x30u);
    goto L_048E57;
L_048E57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E57u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E57u, 5u, 3u, cpu.address("abs", 0x0DB3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E57 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDB3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048E5A;
L_048E5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E5A AND
    cpu.logicAnd(0xFFu);
    goto L_048E5D;
L_048E5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E5D ASL
    cpu.aslA();
    goto L_048E5E;
L_048E5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E5E ASL
    cpu.aslA();
    goto L_048E5F;
L_048E5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Fu, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E5F STA
    hw.write(cpu.address("abs", 0xDD6u), cpu.a, cpu.m8?8:16);
    goto L_048E62;
L_048E62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E62u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E62u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E62 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_048E65;
L_048E65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E65u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E65u, 5u + 1u, 3u, cpu.address("absx", 0x1F1Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E65 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F1Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048E68;
L_048E68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E68u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E68u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E68 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_048E6A;
L_048E6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Au, 5u + 1u, 3u, cpu.address("absx", 0x1F21u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E6A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F21u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048E6D;
L_048E6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E6D STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_048E6F;
L_048E6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E6F TXA
    cpu.transfer("TXA");
    goto L_048E70;
L_048E70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E70u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E70u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E70 LSR
    cpu.lsrA();
    goto L_048E71;
L_048E71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E71u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E71u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E71 LSR
    cpu.lsrA();
    goto L_048E72;
L_048E72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E72u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E72u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E72 TAX
    cpu.transfer("TAX");
    goto L_048E73;
L_048E73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E73u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E73u, 6u, 3u, cpu.address("abs", 0x9885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048E73 JSR -> $049885 stack real
    { cpu.push16Value(hw,0x8E75u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E76u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9885u), 0x048E73u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_048E76;
L_048E76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E76u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E76u,0x048E76u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E76u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E76u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E76 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_048E78;
L_048E78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E78u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E78 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_048E7A;
L_048E7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Au, 6u, 4u, ((0x7ED000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E7A LDA
    cpu.loadA(hw.readW(((0x7ED000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048E7E;
L_048E7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E7E AND
    cpu.logicAnd(0xFFu);
    goto L_048E81;
L_048E81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E81u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E81u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E81 ASL
    cpu.aslA();
    goto L_048E82;
L_048E82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E82u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E82u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E82 TAX
    cpu.transfer("TAX");
    goto L_048E83;
L_048E83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E83u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E83u, 5u + 1u, 3u, cpu.address("absx", 0xA0FCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E83 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA0FCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048E86;
L_048E86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E86u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E86u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E86 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_048E88;
L_048E88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E88u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E88u, 6u, 3u, cpu.address("abs", 0x9D07u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048E88 JSR -> $049D07 stack real
    { cpu.push16Value(hw,0x8E8Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E8Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D07u), 0x048E88u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_048E8B;
L_048E8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E8Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E8Bu,0x048E8Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E8B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_048E8D;
L_048E8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E8D BMI -> $048E9E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_048E9E; }
    goto L_048E8F;
L_048E8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Fu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E8F CPX
    cpu.compareX(0x800u);
    goto L_048E92;
L_048E92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E92u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E92 BCS -> $048E9E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_048E9E; }
    goto L_048E94;
L_048E94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E94u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E94u, 6u, 4u, ((0x7EC800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E94 LDA
    cpu.loadA(hw.readW(((0x7EC800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048E98;
L_048E98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E98u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E98u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E98 AND
    cpu.logicAnd(0xFFu);
    goto L_048E9B;
L_048E9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Bu, 5u, 3u, cpu.address("abs", 0x13C1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E9B STA
    hw.write(cpu.address("abs", 0x13C1u), cpu.a, cpu.m8?8:16);
    goto L_048E9E;
L_048E9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048E9E SEP
    cpu.sep(0x30u);
    goto L_048EA0;
L_048EA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA0u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA0u, 4u, 3u, cpu.address("abs", 0x0EF7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EA0 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xEF7u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_048EA3;
L_048EA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EA3 BEQ -> $048EE1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_048EE1; }
    goto L_048EA5;
L_048EA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EA5 BPL -> $048ED9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_048ED9; }
    goto L_048EA7;
L_048EA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA7u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EA7 TXA
    cpu.transfer("TXA");
    goto L_048EA8;
L_048EA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EA8 AND
    cpu.logicAnd(0x7Fu);
    goto L_048EAA;
L_048EAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EAAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EAA TAX
    cpu.transfer("TAX");
    goto L_048EAB;
L_048EAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EABu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EABu, 5u, 3u, cpu.address("absx", 0x0DF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EAB STZ
    hw.write(cpu.address("absx", 0xDF5u), 0, cpu.m8?8:16);
    goto L_048EAE;
L_048EAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EAEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EAEu, 4u, 3u, cpu.address("abs", 0x0EF6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EAE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xEF6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048EB1;
L_048EB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB1u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB1u, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EB1 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_048EB4;
L_048EB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EB4 BPL -> $048ECD
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_048ECD; }
    goto L_048EB6;
L_048EB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EB6 ASL
    cpu.aslA();
    goto L_048EB7;
L_048EB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EB7 TAX
    cpu.transfer("TAX");
    goto L_048EB8;
L_048EB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EB8 REP
    cpu.rep(0x20u);
    goto L_048EBA;
L_048EBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBAu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBAu, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EBA LDY
    cpu.setY(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_048EBD;
L_048EBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBDu, 5u + ((((0x8E49u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8E49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EBD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8E49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048EC0;
L_048EC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC0u, 6u, 3u, cpu.address("absy", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EC0 STA
    hw.write(cpu.address("absy", 0x1F17u), cpu.a, cpu.m8?8:16);
    goto L_048EC3;
L_048EC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC3u, 5u + ((((0x8E4Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8E4Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EC3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8E4Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048EC6;
L_048EC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC6u, 6u, 3u, cpu.address("absy", 0x1F19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EC6 STA
    hw.write(cpu.address("absy", 0x1F19u), cpu.a, cpu.m8?8:16);
    goto L_048EC9;
L_048EC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EC9 SEP
    cpu.sep(0x20u);
    goto L_048ECB;
L_048ECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECBu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048ECB BRA -> $048EE1
    goto L_048EE1;
L_048ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048ECD TAX
    cpu.transfer("TAX");
    goto L_048ECE;
L_048ECE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECEu, 4u + ((((0xFB85u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xFB85u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048ECE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xFB85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048ED1;
L_048ED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED1u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED1u, 4u, 3u, cpu.address("abs", 0x0EF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048ED1 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xEF5u), cpu.m8?8:16));
    goto L_048ED4;
L_048ED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED4u, 4u, 3u, cpu.address("abs", 0x0EF5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048ED4 STA
    hw.write(cpu.address("abs", 0xEF5u), cpu.a, cpu.m8?8:16);
    goto L_048ED7;
L_048ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048ED7 BRA -> $048EE1
    goto L_048EE1;
L_048ED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED9u, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048ED9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_048EDC;
L_048EDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EDC BMI -> $048EE1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_048EE1; }
    goto L_048EDE;
L_048EDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDEu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDEu, 5u, 3u, cpu.address("absx", 0x0DE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EDE STZ
    hw.write(cpu.address("absx", 0xDE5u), 0, cpu.m8?8:16);
    goto L_048EE1;
L_048EE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EE1 REP
    cpu.rep(0x30u);
    goto L_048EE3;
L_048EE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE3u, 6u, 3u, cpu.address("abs", 0x9831u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048EE3 JSR -> $049831 stack real
    { cpu.push16Value(hw,0x8EE5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EE6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9831u), 0x048EE3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_048EE6;
L_048EE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EE6u,0x048EE6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EE6 SEP
    cpu.sep(0x30u);
    goto L_048EE8;
L_048EE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE8u, 6u, 3u, cpu.address("abs", 0x85A4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048EE8 JSR -> $0485A4 stack real
    { cpu.push16Value(hw,0x8EEAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EEBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85A4u), 0x048EE8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_048EEB;
L_048EEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EEBu,0x048EEBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEBu, 6u, 3u, cpu.address("abs", 0x8086u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $048EEB JSR -> $048086 stack real
    { cpu.push16Value(hw,0x8EEDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EEEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8086u), 0x048EEBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_048EEE;
L_048EEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EEEu,0x048EEEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEEu, 3u, 3u, cpu.address("abs", 0x80E0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $048EEE JMP -> $0480E0
    goto L_0480E0;
}

void sub_04F708_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04F708u: goto L_04F708;
    case 0x04F70Au: goto L_04F70A;
    case 0x04F70Du: goto L_04F70D;
    case 0x04F70Fu: goto L_04F70F;
    case 0x04F712u: goto L_04F712;
    case 0x04F714u: goto L_04F714;
    case 0x04F716u: goto L_04F716;
    case 0x04F717u: goto L_04F717;
    case 0x04F719u: goto L_04F719;
    case 0x04F71Cu: goto L_04F71C;
    case 0x04F71Eu: goto L_04F71E;
    case 0x04F71Fu: goto L_04F71F;
    case 0x04F722u: goto L_04F722;
    case 0x04F724u: goto L_04F724;
    case 0x04F725u: goto L_04F725;
    case 0x04F728u: goto L_04F728;
    case 0x04F72Bu: goto L_04F72B;
    case 0x04F72Eu: goto L_04F72E;
    case 0x04F731u: goto L_04F731;
    case 0x04F733u: goto L_04F733;
    case 0x04F736u: goto L_04F736;
    case 0x04F738u: goto L_04F738;
    case 0x04F73Bu: goto L_04F73B;
    case 0x04F73Eu: goto L_04F73E;
    case 0x04F740u: goto L_04F740;
    case 0x04F743u: goto L_04F743;
    case 0x04F745u: goto L_04F745;
    case 0x04F748u: goto L_04F748;
    case 0x04F749u: goto L_04F749;
    case 0x04F74Au: goto L_04F74A;
    case 0x04F74Bu: goto L_04F74B;
    case 0x04F74Eu: goto L_04F74E;
    case 0x04F750u: goto L_04F750;
    case 0x04F753u: goto L_04F753;
    case 0x04F755u: goto L_04F755;
    case 0x04F758u: goto L_04F758;
    case 0x04F75Bu: goto L_04F75B;
    case 0x04F75Eu: goto L_04F75E;
    case 0x04F761u: goto L_04F761;
    case 0x04F764u: goto L_04F764;
    case 0x04F767u: goto L_04F767;
    case 0x04F768u: goto L_04F768;
    case 0x04F769u: goto L_04F769;
    case 0x04F76Bu: goto L_04F76B;
    case 0x04F76Eu: goto L_04F76E;
    case 0x04F770u: goto L_04F770;
    case 0x04F773u: goto L_04F773;
    case 0x04F775u: goto L_04F775;
    case 0x04F777u: goto L_04F777;
    case 0x04F77Au: goto L_04F77A;
    case 0x04F77Du: goto L_04F77D;
    case 0x04F77Fu: goto L_04F77F;
    case 0x04F780u: goto L_04F780;
    case 0x04F783u: goto L_04F783;
    case 0x04F786u: goto L_04F786;
    case 0x04F787u: goto L_04F787;
    case 0x04F788u: goto L_04F788;
    case 0x04F789u: goto L_04F789;
    case 0x04F78Bu: goto L_04F78B;
    case 0x04F78Du: goto L_04F78D;
    case 0x04F78Eu: goto L_04F78E;
    case 0x04F791u: goto L_04F791;
    case 0x04F793u: goto L_04F793;
    case 0x04F796u: goto L_04F796;
    case 0x04F797u: goto L_04F797;
    case 0x04F79Au: goto L_04F79A;
    case 0x04F79Cu: goto L_04F79C;
    case 0x04F79Eu: goto L_04F79E;
    case 0x04F79Fu: goto L_04F79F;
    case 0x04F7A2u: goto L_04F7A2;
    case 0x04F7A4u: goto L_04F7A4;
    case 0x04F7A7u: goto L_04F7A7;
    case 0x04F7A8u: goto L_04F7A8;
    case 0x04F7ABu: goto L_04F7AB;
    case 0x04F7ACu: goto L_04F7AC;
    case 0x04F7AEu: goto L_04F7AE;
    case 0x04F7B0u: goto L_04F7B0;
    case 0x04F7B1u: goto L_04F7B1;
    case 0x04F7B4u: goto L_04F7B4;
    case 0x04F7B5u: goto L_04F7B5;
    case 0x04F7B7u: goto L_04F7B7;
    case 0x04F7B9u: goto L_04F7B9;
    case 0x04F7BBu: goto L_04F7BB;
    case 0x04F7BDu: goto L_04F7BD;
    case 0x04F7BFu: goto L_04F7BF;
    case 0x04F7C2u: goto L_04F7C2;
    case 0x04F7C5u: goto L_04F7C5;
    case 0x04F7C7u: goto L_04F7C7;
    case 0x04F7CAu: goto L_04F7CA;
    case 0x04F7CCu: goto L_04F7CC;
    case 0x04F7CEu: goto L_04F7CE;
    case 0x04F7D1u: goto L_04F7D1;
    case 0x04F7D4u: goto L_04F7D4;
    case 0x04F7D5u: goto L_04F7D5;
    case 0x04F7D8u: goto L_04F7D8;
    case 0x04F7DAu: goto L_04F7DA;
    case 0x04F7DCu: goto L_04F7DC;
    case 0x04F7DEu: goto L_04F7DE;
    case 0x04F7E0u: goto L_04F7E0;
    case 0x04F7E1u: goto L_04F7E1;
    case 0x04F7E3u: goto L_04F7E3;
    case 0x04F7E6u: goto L_04F7E6;
    case 0x04F7E9u: goto L_04F7E9;
    case 0x04F7EAu: goto L_04F7EA;
    case 0x04F7EDu: goto L_04F7ED;
    case 0x04F7EEu: goto L_04F7EE;
    case 0x04F7F0u: goto L_04F7F0;
    case 0x04F7F2u: goto L_04F7F2;
    case 0x04F7F3u: goto L_04F7F3;
    case 0x04F7F5u: goto L_04F7F5;
    case 0x04F7F7u: goto L_04F7F7;
    case 0x04F7FAu: goto L_04F7FA;
    case 0x04F7FDu: goto L_04F7FD;
    case 0x04F7FFu: goto L_04F7FF;
    case 0x04F801u: goto L_04F801;
    case 0x04F803u: goto L_04F803;
    case 0x04F805u: goto L_04F805;
    case 0x04F808u: goto L_04F808;
    case 0x04F80Au: goto L_04F80A;
    case 0x04F80Du: goto L_04F80D;
    case 0x04F80Fu: goto L_04F80F;
    case 0x04F811u: goto L_04F811;
    case 0x04F814u: goto L_04F814;
    case 0x04F817u: goto L_04F817;
    case 0x04F819u: goto L_04F819;
    case 0x04F81Au: goto L_04F81A;
    case 0x04F81Du: goto L_04F81D;
    case 0x04F81Eu: goto L_04F81E;
    case 0x04F821u: goto L_04F821;
    case 0x04F824u: goto L_04F824;
    case 0x04F825u: goto L_04F825;
    case 0x04F826u: goto L_04F826;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04F708:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF708u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF708u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF708u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F708 LDA
    cpu.setA(0xF7u, 8);
    goto L_04F70A;
L_04F70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Au, 6u, 3u, cpu.address("abs", 0xF882u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F70A JSR -> $04F882 stack real
    { cpu.push16Value(hw,0xF70Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF70Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF882u), 0x04F70Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F70D;
L_04F70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF70Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF70Du,0x04F70Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F70D BNE -> $04F76E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F76E; }
    goto L_04F70F;
L_04F70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Fu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Fu, 4u, 3u, cpu.address("abs", 0x1FFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F70F LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1FFBu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F712;
L_04F712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF712u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF712u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F712 BNE -> $04F73B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F73B; }
    goto L_04F714;
L_04F714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF714u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF714u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F714 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F716;
L_04F716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF716u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF716u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F716 LSR
    cpu.lsrA();
    goto L_04F717;
L_04F717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF717u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF717u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F717 BCC -> $04F76E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F76E; }
    goto L_04F719;
L_04F719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF719u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF719u, 6u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F719 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1FFCu), cpu.m8?8:16);
    goto L_04F71C;
L_04F71C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF71Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F71C BNE -> $04F76E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F76E; }
    goto L_04F71E;
L_04F71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F71E TAY
    cpu.transfer("TAY");
    goto L_04F71F;
L_04F71F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF71Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Fu, 4u + ((((0xF708u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF708u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F71F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF708u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F722;
L_04F722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF722u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF722u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F722 AND
    cpu.logicAnd(0x7u);
    goto L_04F724;
L_04F724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF724u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF724u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F724 TAX
    cpu.transfer("TAX");
    goto L_04F725;
L_04F725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF725u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF725u, 4u + ((((0xF6F8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF6F8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F725 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF6F8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F728;
L_04F728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF728u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF728u, 4u, 3u, cpu.address("abs", 0x1FFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F728 STA
    hw.write(cpu.address("abs", 0x1FFCu), cpu.a, cpu.m8?8:16);
    goto L_04F72B;
L_04F72B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF72Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Bu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Bu, 4u + ((((0xF700u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF700u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F72B LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xF700u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F72E;
L_04F72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Eu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Eu, 4u, 3u, cpu.address("abs", 0x1FFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F72E STY
    hw.write(cpu.address("abs", 0x1FFBu), cpu.y, cpu.x8?8:16);
    goto L_04F731;
L_04F731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF731u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF731u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F731 LDA
    cpu.setA(0x8u, 8);
    goto L_04F733;
L_04F733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF733u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF733u, 4u, 3u, cpu.address("abs", 0x1FFDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F733 STA
    hw.write(cpu.address("abs", 0x1FFDu), cpu.a, cpu.m8?8:16);
    goto L_04F736;
L_04F736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF736u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF736u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F736 LDA
    cpu.setA(0x18u, 8);
    goto L_04F738;
L_04F738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF738u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF738u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F738 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_04F73B;
L_04F73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF73Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Bu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Bu, 6u, 3u, cpu.address("abs", 0x1FFDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F73B DEC
    cpu.decMem(hw, cpu.address("abs", 0x1FFDu), cpu.m8?8:16);
    goto L_04F73E;
L_04F73E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF73Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F73E BPL -> $04F748
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04F748; }
    goto L_04F740;
L_04F740:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF740u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF740u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF740u, 6u, 3u, cpu.address("abs", 0x1FFBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F740 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1FFBu), cpu.m8?8:16);
    goto L_04F743;
L_04F743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF743u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF743u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F743 LDA
    cpu.setA(0x4u, 8);
    goto L_04F745;
L_04F745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF745u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF745u, 4u, 3u, cpu.address("abs", 0x1FFDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F745 STA
    hw.write(cpu.address("abs", 0x1FFDu), cpu.a, cpu.m8?8:16);
    goto L_04F748;
L_04F748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF748u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF748u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F748 TYA
    cpu.transfer("TYA");
    goto L_04F749;
L_04F749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF749u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF749u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF749u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F749 ASL
    cpu.aslA();
    goto L_04F74A;
L_04F74A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF74Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F74A TAY
    cpu.transfer("TAY");
    goto L_04F74B;
L_04F74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Bu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Bu, 4u, 3u, cpu.address("abs", 0x0681u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F74B LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x681u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F74E;
L_04F74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF74Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F74E LDA
    cpu.setA(0x2u, 8);
    goto L_04F750;
L_04F750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF750u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF750u, 5u, 3u, cpu.address("absx", 0x0682u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F750 STA
    hw.write(cpu.address("absx", 0x682u), cpu.a, cpu.m8?8:16);
    goto L_04F753;
L_04F753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF753u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF753u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF753u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F753 LDA
    cpu.setA(0x47u, 8);
    goto L_04F755;
L_04F755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF755u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF755u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF755u, 5u, 3u, cpu.address("absx", 0x0683u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F755 STA
    hw.write(cpu.address("absx", 0x683u), cpu.a, cpu.m8?8:16);
    goto L_04F758;
L_04F758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF758u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF758u, 4u + ((((0x0753u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0753u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F758 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x753u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F75B;
L_04F75B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF75Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Bu, 5u, 3u, cpu.address("absx", 0x0684u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F75B STA
    hw.write(cpu.address("absx", 0x684u), cpu.a, cpu.m8?8:16);
    goto L_04F75E;
L_04F75E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF75Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Eu, 4u + ((((0x0754u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0754u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F75E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x754u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F761;
L_04F761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF761u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF761u, 5u, 3u, cpu.address("absx", 0x0685u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F761 STA
    hw.write(cpu.address("absx", 0x685u), cpu.a, cpu.m8?8:16);
    goto L_04F764;
L_04F764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF764u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF764u, 5u, 3u, cpu.address("absx", 0x0686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F764 STZ
    hw.write(cpu.address("absx", 0x686u), 0, cpu.m8?8:16);
    goto L_04F767;
L_04F767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF767u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF767u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F767 TXA
    cpu.transfer("TXA");
    goto L_04F768;
L_04F768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF768u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF768u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F768 CLC
    cpu.setFlag('C', false);
    goto L_04F769;
L_04F769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF769u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF769u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F769 ADC
    cpu.adc(0x4u);
    goto L_04F76B;
L_04F76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Bu, 4u, 3u, cpu.address("abs", 0x0681u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F76B STA
    hw.write(cpu.address("abs", 0x681u), cpu.a, cpu.m8?8:16);
    goto L_04F76E;
L_04F76E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF76Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F76E LDX
    cpu.setX(0x2u, 8);
    goto L_04F770;
L_04F770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF770u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF770u, 4u + ((((0x0DE5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F770 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F773;
L_04F773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF773u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF773u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF773u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F773 BNE -> $04F7AB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F7AB; }
    goto L_04F775;
L_04F775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF775u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF775u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F775 LDA
    cpu.setA(0x5u, 8);
    goto L_04F777;
L_04F777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF777u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF777u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF777u, 5u, 3u, cpu.address("absx", 0x0DE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F777 STA
    hw.write(cpu.address("absx", 0xDE5u), cpu.a, cpu.m8?8:16);
    goto L_04F77A;
L_04F77A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF77Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Au, 6u, 3u, cpu.address("abs", 0xFE5Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F77A JSR -> $04FE5B stack real
    { cpu.push16Value(hw,0xF77Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF77Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFE5Bu), 0x04F77Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F77D;
L_04F77D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF77Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF77Du,0x04F77Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F77D AND
    cpu.logicAnd(0x7u);
    goto L_04F77F;
L_04F77F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF77Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F77F TAY
    cpu.transfer("TAY");
    goto L_04F780;
L_04F780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF780u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF780u, 4u + ((((0xF6D0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF6D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F780 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF6D0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F783;
L_04F783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF783u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF783u, 5u, 3u, cpu.address("absx", 0x0E55u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F783 STA
    hw.write(cpu.address("absx", 0xE55u), cpu.a, cpu.m8?8:16);
    goto L_04F786;
L_04F786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF786u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF786u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F786 TYA
    cpu.transfer("TYA");
    goto L_04F787;
L_04F787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF787u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF787u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F787 ASL
    cpu.aslA();
    goto L_04F788;
L_04F788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF788u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF788u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F788 TAY
    cpu.transfer("TAY");
    goto L_04F789;
L_04F789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF789u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF789u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F789 REP
    cpu.rep(0x20u);
    goto L_04F78B;
L_04F78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F78B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F78D;
L_04F78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F78D CLC
    cpu.setFlag('C', false);
    goto L_04F78E;
L_04F78E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Eu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Eu, 5u + ((((0xF6D8u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF6D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F78E ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xF6D8u), cpu.m8?8:16));
    goto L_04F791;
L_04F791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF791u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF791u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F791 SEP
    cpu.sep(0x20u);
    goto L_04F793;
L_04F793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF793u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF793u, 5u, 3u, cpu.address("absx", 0x0E35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F793 STA
    hw.write(cpu.address("absx", 0xE35u), cpu.a, cpu.m8?8:16);
    goto L_04F796;
L_04F796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF796u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF796u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F796 XBA
    cpu.xba();
    goto L_04F797;
L_04F797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF797u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF797u, 5u, 3u, cpu.address("absx", 0x0E65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F797 STA
    hw.write(cpu.address("absx", 0xE65u), cpu.a, cpu.m8?8:16);
    goto L_04F79A;
L_04F79A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F79A REP
    cpu.rep(0x20u);
    goto L_04F79C;
L_04F79C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F79C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F79E;
L_04F79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F79E CLC
    cpu.setFlag('C', false);
    goto L_04F79F;
L_04F79F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Fu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Fu, 5u + ((((0xF6E8u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF6E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F79F ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xF6E8u), cpu.m8?8:16));
    goto L_04F7A2;
L_04F7A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7A2 SEP
    cpu.sep(0x20u);
    goto L_04F7A4;
L_04F7A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A4u, 5u, 3u, cpu.address("absx", 0x0E45u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7A4 STA
    hw.write(cpu.address("absx", 0xE45u), cpu.a, cpu.m8?8:16);
    goto L_04F7A7;
L_04F7A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A7u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7A7 XBA
    cpu.xba();
    goto L_04F7A8;
L_04F7A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A8u, 5u, 3u, cpu.address("absx", 0x0E75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7A8 STA
    hw.write(cpu.address("absx", 0xE75u), cpu.a, cpu.m8?8:16);
    goto L_04F7AB;
L_04F7AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7ABu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7AB DEX
    cpu.decReg('X');
    goto L_04F7AC;
L_04F7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7ACu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7AC BPL -> $04F770
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04F770; }
    goto L_04F7AE;
L_04F7AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7AEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7AE LDX
    cpu.setX(0x4u, 8);
    goto L_04F7B0;
L_04F7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B0u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7B0 TXA
    cpu.transfer("TXA");
    goto L_04F7B1;
L_04F7B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B1u, 5u, 3u, cpu.address("absx", 0x0DE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7B1 STA
    hw.write(cpu.address("absx", 0xDE0u), cpu.a, cpu.m8?8:16);
    goto L_04F7B4;
L_04F7B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B4u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7B4 DEX
    cpu.decReg('X');
    goto L_04F7B5;
L_04F7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7B5 BPL -> $04F7B0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04F7B0; }
    goto L_04F7B7;
L_04F7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7B7 LDX
    cpu.setX(0x4u, 8);
    goto L_04F7B9;
L_04F7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B9u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7B9 STX
    hw.write(cpu.address("dp", 0x0u), cpu.x, cpu.x8?8:16);
    goto L_04F7BB;
L_04F7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BBu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7BB STX
    hw.write(cpu.address("dp", 0x1u), cpu.x, cpu.x8?8:16);
    goto L_04F7BD;
L_04F7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BDu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7BD LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F7BF;
L_04F7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BFu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BFu, 4u + ((((0x0DE0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7BF LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xDE0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F7C2;
L_04F7C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C2u, 4u + ((((0x0E45u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0E45u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7C2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F7C5;
L_04F7C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7C5 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04F7C7;
L_04F7C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C7u, 4u + ((((0x0E75u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0E75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7C7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F7CA;
L_04F7CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7CA STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_04F7CC;
L_04F7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CCu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7CC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F7CE;
L_04F7CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CEu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CEu, 4u + ((((0x0DDFu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7CE LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xDDFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F7D1;
L_04F7D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D1u, 4u + ((((0x0E75u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0E75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7D1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F7D4;
L_04F7D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D4u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7D4 XBA
    cpu.xba();
    goto L_04F7D5;
L_04F7D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D5u, 4u + ((((0x0E45u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0E45u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7D5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F7D8;
L_04F7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7D8 REP
    cpu.rep(0x20u);
    goto L_04F7DA;
L_04F7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7DA CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_04F7DC;
L_04F7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7DC SEP
    cpu.sep(0x20u);
    goto L_04F7DE;
L_04F7DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7DE BPL -> $04F7ED
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04F7ED; }
    goto L_04F7E0;
L_04F7E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E0u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F7E0 PHY
    cpu.push("PHY", hw);
    goto L_04F7E1;
L_04F7E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E1u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7E1 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F7E3;
L_04F7E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E3u, 4u + ((((0x0DE0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0DE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7E3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F7E6;
L_04F7E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E6u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E6u, 5u, 3u, cpu.address("absx", 0x0DDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7E6 STA
    hw.write(cpu.address("absx", 0xDDFu), cpu.a, cpu.m8?8:16);
    goto L_04F7E9;
L_04F7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E9u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F7E9 PLA
    cpu.pop("PLA", hw);
    goto L_04F7EA;
L_04F7EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EAu, 5u, 3u, cpu.address("absy", 0x0DE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7EA STA
    hw.write(cpu.address("absy", 0xDE0u), cpu.a, cpu.m8?8:16);
    goto L_04F7ED;
L_04F7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EDu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7ED DEX
    cpu.decReg('X');
    goto L_04F7EE;
L_04F7EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7EE BNE -> $04F7BB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F7BB; }
    goto L_04F7F0;
L_04F7F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7F0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F7F2;
L_04F7F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F2u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7F2 DEX
    cpu.decReg('X');
    goto L_04F7F3;
L_04F7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7F3 BNE -> $04F7B9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F7B9; }
    goto L_04F7F5;
L_04F7F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7F5 LDA
    cpu.setA(0x30u, 8);
    goto L_04F7F7;
L_04F7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F7u, 4u, 3u, cpu.address("abs", 0x0DDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7F7 STA
    hw.write(cpu.address("abs", 0xDDFu), cpu.a, cpu.m8?8:16);
    goto L_04F7FA;
L_04F7FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FAu, 4u, 3u, cpu.address("abs", 0x0EF7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7FA STZ
    hw.write(cpu.address("abs", 0xEF7u), 0, cpu.m8?8:16);
    goto L_04F7FD;
L_04F7FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7FD LDX
    cpu.setX(0xFu, 8);
    goto L_04F7FF;
L_04F7FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7FF LDY
    cpu.setY(0x2Du, 8);
    goto L_04F801;
L_04F801:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF801u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF801u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF801u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F801 CPX
    cpu.compareX(0xDu);
    goto L_04F803;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF801u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF801u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F801 CPX
    cpu.compareX(0xDu);
    goto L_04F803;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF801u,0x04F801u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF803u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF803u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF803u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F803 BCS -> $04F80D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F80D; }
    goto L_04F805;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF803u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF803u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F803 BCS -> $04F80D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F80D; }
    goto L_04F805;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF803u,0x04F803u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F805:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF805u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF805u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF805u, 4u + ((((0x0E25u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E25u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F805 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE25u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F808;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF805u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF805u, 4u + ((((0x0E25u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E25u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F805 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE25u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F808;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF805u,0x04F805u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF808u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF808u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF808u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F808 BEQ -> $04F80D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F80D; }
    goto L_04F80A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF808u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF808u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F808 BEQ -> $04F80D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F80D; }
    goto L_04F80A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF808u,0x04F808u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F80A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF80Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Au,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Au, 7u, 3u, cpu.address("absx", 0x0E25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F80A DEC
    cpu.decMem(hw, cpu.address("absx", 0xE25u), cpu.m8?8:16);
    goto L_04F80D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Au,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Au, 7u, 3u, cpu.address("absx", 0x0E25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F80A DEC
    cpu.decMem(hw, cpu.address("absx", 0xE25u), cpu.m8?8:16);
    goto L_04F80D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF80Au,0x04F80Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F80D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF80Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Du,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F80D CPX
    cpu.compareX(0x5u);
    goto L_04F80F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Du,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F80D CPX
    cpu.compareX(0x5u);
    goto L_04F80F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF80Du,0x04F80Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF80Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F80F BCC -> $04F819
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F819; }
    goto L_04F811;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F80F BCC -> $04F819
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F819; }
    goto L_04F811;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF80Fu,0x04F80Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF811u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF811u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF811u, 4u, 3u, cpu.address("abs", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F811 STX
    hw.write(cpu.address("abs", 0xDDEu), cpu.x, cpu.x8?8:16);
    goto L_04F814;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF811u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF811u, 4u, 3u, cpu.address("abs", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F811 STX
    hw.write(cpu.address("abs", 0xDDEu), cpu.x, cpu.x8?8:16);
    goto L_04F814;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF811u,0x04F811u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF814u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF814u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF814u, 6u, 3u, cpu.address("abs", 0xF853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F814 JSR -> $04F853 stack real
    { cpu.push16Value(hw,0xF816u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF817u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF853u), 0x04F814u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F817;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF814u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF814u, 6u, 3u, cpu.address("abs", 0xF853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F814 JSR -> $04F853 stack real
    { cpu.push16Value(hw,0xF816u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF817u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF853u), 0x04F814u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F817;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF814u,0x04F814u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF817u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF817u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF817u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F817 BRA -> $04F825
    goto L_04F825;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF817u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF817u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F817 BRA -> $04F825
    goto L_04F825;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF817u,0x04F817u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF819u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF819u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF819u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F819 PHX
    cpu.push("PHX", hw);
    goto L_04F81A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF819u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF819u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F819 PHX
    cpu.push("PHX", hw);
    goto L_04F81A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF819u,0x04F819u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF81Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Au, 4u + ((((0x0DE0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F81A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F81D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Au, 4u + ((((0x0DE0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F81A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F81D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF81Au,0x04F81Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F81D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF81Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F81D TAX
    cpu.transfer("TAX");
    goto L_04F81E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F81D TAX
    cpu.transfer("TAX");
    goto L_04F81E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF81Du,0x04F81Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F81E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF81Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Eu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Eu, 4u, 3u, cpu.address("abs", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F81E STX
    hw.write(cpu.address("abs", 0xDDEu), cpu.x, cpu.x8?8:16);
    goto L_04F821;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Eu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Eu, 4u, 3u, cpu.address("abs", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F81E STX
    hw.write(cpu.address("abs", 0xDDEu), cpu.x, cpu.x8?8:16);
    goto L_04F821;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF81Eu,0x04F81Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F821:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF821u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF821u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF821u, 6u, 3u, cpu.address("abs", 0xF853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F821 JSR -> $04F853 stack real
    { cpu.push16Value(hw,0xF823u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF824u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF853u), 0x04F821u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F824;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF821u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF821u, 6u, 3u, cpu.address("abs", 0xF853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F821 JSR -> $04F853 stack real
    { cpu.push16Value(hw,0xF823u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF824u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF853u), 0x04F821u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F824;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF821u,0x04F821u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F824:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF824u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF824u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF824u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F824 PLX
    cpu.pop("PLX", hw);
    goto L_04F825;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF824u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF824u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F824 PLX
    cpu.pop("PLX", hw);
    goto L_04F825;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF824u,0x04F824u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF825u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F825 DEX
    cpu.decReg('X');
    goto L_04F826;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F825 DEX
    cpu.decReg('X');
    goto L_04F826;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF825u,0x04F825u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF826u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF826u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF826u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F826 BPL -> $04F801
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04F801; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF828u,0x04F826u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF826u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF826u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F826 BPL -> $04F801
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04F801; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF828u,0x04F826u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF826u,0x04F826u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_04F708_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04F708u: goto L_04F708;
    case 0x04F70Au: goto L_04F70A;
    case 0x04F70Du: goto L_04F70D;
    case 0x04F70Fu: goto L_04F70F;
    case 0x04F712u: goto L_04F712;
    case 0x04F714u: goto L_04F714;
    case 0x04F716u: goto L_04F716;
    case 0x04F717u: goto L_04F717;
    case 0x04F719u: goto L_04F719;
    case 0x04F71Cu: goto L_04F71C;
    case 0x04F71Eu: goto L_04F71E;
    case 0x04F71Fu: goto L_04F71F;
    case 0x04F722u: goto L_04F722;
    case 0x04F724u: goto L_04F724;
    case 0x04F725u: goto L_04F725;
    case 0x04F728u: goto L_04F728;
    case 0x04F72Bu: goto L_04F72B;
    case 0x04F72Eu: goto L_04F72E;
    case 0x04F731u: goto L_04F731;
    case 0x04F733u: goto L_04F733;
    case 0x04F736u: goto L_04F736;
    case 0x04F738u: goto L_04F738;
    case 0x04F73Bu: goto L_04F73B;
    case 0x04F73Eu: goto L_04F73E;
    case 0x04F740u: goto L_04F740;
    case 0x04F743u: goto L_04F743;
    case 0x04F745u: goto L_04F745;
    case 0x04F748u: goto L_04F748;
    case 0x04F749u: goto L_04F749;
    case 0x04F74Au: goto L_04F74A;
    case 0x04F74Bu: goto L_04F74B;
    case 0x04F74Eu: goto L_04F74E;
    case 0x04F750u: goto L_04F750;
    case 0x04F753u: goto L_04F753;
    case 0x04F755u: goto L_04F755;
    case 0x04F758u: goto L_04F758;
    case 0x04F75Bu: goto L_04F75B;
    case 0x04F75Eu: goto L_04F75E;
    case 0x04F761u: goto L_04F761;
    case 0x04F764u: goto L_04F764;
    case 0x04F767u: goto L_04F767;
    case 0x04F768u: goto L_04F768;
    case 0x04F769u: goto L_04F769;
    case 0x04F76Bu: goto L_04F76B;
    case 0x04F76Eu: goto L_04F76E;
    case 0x04F770u: goto L_04F770;
    case 0x04F773u: goto L_04F773;
    case 0x04F775u: goto L_04F775;
    case 0x04F777u: goto L_04F777;
    case 0x04F77Au: goto L_04F77A;
    case 0x04F77Du: goto L_04F77D;
    case 0x04F77Fu: goto L_04F77F;
    case 0x04F780u: goto L_04F780;
    case 0x04F783u: goto L_04F783;
    case 0x04F786u: goto L_04F786;
    case 0x04F787u: goto L_04F787;
    case 0x04F788u: goto L_04F788;
    case 0x04F789u: goto L_04F789;
    case 0x04F78Bu: goto L_04F78B;
    case 0x04F78Du: goto L_04F78D;
    case 0x04F78Eu: goto L_04F78E;
    case 0x04F791u: goto L_04F791;
    case 0x04F793u: goto L_04F793;
    case 0x04F796u: goto L_04F796;
    case 0x04F797u: goto L_04F797;
    case 0x04F79Au: goto L_04F79A;
    case 0x04F79Cu: goto L_04F79C;
    case 0x04F79Eu: goto L_04F79E;
    case 0x04F79Fu: goto L_04F79F;
    case 0x04F7A2u: goto L_04F7A2;
    case 0x04F7A4u: goto L_04F7A4;
    case 0x04F7A7u: goto L_04F7A7;
    case 0x04F7A8u: goto L_04F7A8;
    case 0x04F7ABu: goto L_04F7AB;
    case 0x04F7ACu: goto L_04F7AC;
    case 0x04F7AEu: goto L_04F7AE;
    case 0x04F7B0u: goto L_04F7B0;
    case 0x04F7B1u: goto L_04F7B1;
    case 0x04F7B4u: goto L_04F7B4;
    case 0x04F7B5u: goto L_04F7B5;
    case 0x04F7B7u: goto L_04F7B7;
    case 0x04F7B9u: goto L_04F7B9;
    case 0x04F7BBu: goto L_04F7BB;
    case 0x04F7BDu: goto L_04F7BD;
    case 0x04F7BFu: goto L_04F7BF;
    case 0x04F7C2u: goto L_04F7C2;
    case 0x04F7C5u: goto L_04F7C5;
    case 0x04F7C7u: goto L_04F7C7;
    case 0x04F7CAu: goto L_04F7CA;
    case 0x04F7CCu: goto L_04F7CC;
    case 0x04F7CEu: goto L_04F7CE;
    case 0x04F7D1u: goto L_04F7D1;
    case 0x04F7D4u: goto L_04F7D4;
    case 0x04F7D5u: goto L_04F7D5;
    case 0x04F7D8u: goto L_04F7D8;
    case 0x04F7DAu: goto L_04F7DA;
    case 0x04F7DCu: goto L_04F7DC;
    case 0x04F7DEu: goto L_04F7DE;
    case 0x04F7E0u: goto L_04F7E0;
    case 0x04F7E1u: goto L_04F7E1;
    case 0x04F7E3u: goto L_04F7E3;
    case 0x04F7E6u: goto L_04F7E6;
    case 0x04F7E9u: goto L_04F7E9;
    case 0x04F7EAu: goto L_04F7EA;
    case 0x04F7EDu: goto L_04F7ED;
    case 0x04F7EEu: goto L_04F7EE;
    case 0x04F7F0u: goto L_04F7F0;
    case 0x04F7F2u: goto L_04F7F2;
    case 0x04F7F3u: goto L_04F7F3;
    case 0x04F7F5u: goto L_04F7F5;
    case 0x04F7F7u: goto L_04F7F7;
    case 0x04F7FAu: goto L_04F7FA;
    case 0x04F7FDu: goto L_04F7FD;
    case 0x04F7FFu: goto L_04F7FF;
    case 0x04F801u: goto L_04F801;
    case 0x04F803u: goto L_04F803;
    case 0x04F805u: goto L_04F805;
    case 0x04F808u: goto L_04F808;
    case 0x04F80Au: goto L_04F80A;
    case 0x04F80Du: goto L_04F80D;
    case 0x04F80Fu: goto L_04F80F;
    case 0x04F811u: goto L_04F811;
    case 0x04F814u: goto L_04F814;
    case 0x04F817u: goto L_04F817;
    case 0x04F819u: goto L_04F819;
    case 0x04F81Au: goto L_04F81A;
    case 0x04F81Du: goto L_04F81D;
    case 0x04F81Eu: goto L_04F81E;
    case 0x04F821u: goto L_04F821;
    case 0x04F824u: goto L_04F824;
    case 0x04F825u: goto L_04F825;
    case 0x04F826u: goto L_04F826;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04F708:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF708u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF708u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF708u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F708 LDA
    cpu.setA(0xF7u, 8);
    goto L_04F70A;
L_04F70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Au, 6u, 3u, cpu.address("abs", 0xF882u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F70A JSR -> $04F882 stack real
    { cpu.push16Value(hw,0xF70Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF70Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF882u), 0x04F70Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F70D;
L_04F70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF70Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF70Du,0x04F70Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F70D BNE -> $04F76E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F76E; }
    goto L_04F70F;
L_04F70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Fu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Fu, 4u, 3u, cpu.address("abs", 0x1FFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F70F LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1FFBu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F712;
L_04F712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF712u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF712u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F712 BNE -> $04F73B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F73B; }
    goto L_04F714;
L_04F714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF714u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF714u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F714 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F716;
L_04F716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF716u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF716u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F716 LSR
    cpu.lsrA();
    goto L_04F717;
L_04F717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF717u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF717u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F717 BCC -> $04F76E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F76E; }
    goto L_04F719;
L_04F719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF719u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF719u, 6u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F719 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1FFCu), cpu.m8?8:16);
    goto L_04F71C;
L_04F71C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF71Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F71C BNE -> $04F76E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F76E; }
    goto L_04F71E;
L_04F71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F71E TAY
    cpu.transfer("TAY");
    goto L_04F71F;
L_04F71F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF71Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Fu, 4u + ((((0xF708u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF708u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F71F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF708u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F722;
L_04F722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF722u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF722u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F722 AND
    cpu.logicAnd(0x7u);
    goto L_04F724;
L_04F724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF724u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF724u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F724 TAX
    cpu.transfer("TAX");
    goto L_04F725;
L_04F725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF725u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF725u, 4u + ((((0xF6F8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF6F8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F725 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF6F8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F728;
L_04F728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF728u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF728u, 4u, 3u, cpu.address("abs", 0x1FFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F728 STA
    hw.write(cpu.address("abs", 0x1FFCu), cpu.a, cpu.m8?8:16);
    goto L_04F72B;
L_04F72B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF72Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Bu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Bu, 4u + ((((0xF700u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xF700u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F72B LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xF700u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F72E;
L_04F72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Eu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Eu, 4u, 3u, cpu.address("abs", 0x1FFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F72E STY
    hw.write(cpu.address("abs", 0x1FFBu), cpu.y, cpu.x8?8:16);
    goto L_04F731;
L_04F731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF731u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF731u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F731 LDA
    cpu.setA(0x8u, 8);
    goto L_04F733;
L_04F733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF733u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF733u, 4u, 3u, cpu.address("abs", 0x1FFDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F733 STA
    hw.write(cpu.address("abs", 0x1FFDu), cpu.a, cpu.m8?8:16);
    goto L_04F736;
L_04F736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF736u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF736u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F736 LDA
    cpu.setA(0x18u, 8);
    goto L_04F738;
L_04F738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF738u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF738u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F738 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_04F73B;
L_04F73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF73Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Bu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Bu, 6u, 3u, cpu.address("abs", 0x1FFDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F73B DEC
    cpu.decMem(hw, cpu.address("abs", 0x1FFDu), cpu.m8?8:16);
    goto L_04F73E;
L_04F73E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF73Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F73E BPL -> $04F748
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04F748; }
    goto L_04F740;
L_04F740:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF740u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF740u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF740u, 6u, 3u, cpu.address("abs", 0x1FFBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F740 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1FFBu), cpu.m8?8:16);
    goto L_04F743;
L_04F743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF743u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF743u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F743 LDA
    cpu.setA(0x4u, 8);
    goto L_04F745;
L_04F745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF745u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF745u, 4u, 3u, cpu.address("abs", 0x1FFDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F745 STA
    hw.write(cpu.address("abs", 0x1FFDu), cpu.a, cpu.m8?8:16);
    goto L_04F748;
L_04F748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF748u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF748u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F748 TYA
    cpu.transfer("TYA");
    goto L_04F749;
L_04F749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF749u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF749u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF749u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F749 ASL
    cpu.aslA();
    goto L_04F74A;
L_04F74A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF74Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F74A TAY
    cpu.transfer("TAY");
    goto L_04F74B;
L_04F74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Bu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Bu, 4u, 3u, cpu.address("abs", 0x0681u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F74B LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x681u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F74E;
L_04F74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF74Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F74E LDA
    cpu.setA(0x2u, 8);
    goto L_04F750;
L_04F750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF750u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF750u, 5u, 3u, cpu.address("absx", 0x0682u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F750 STA
    hw.write(cpu.address("absx", 0x682u), cpu.a, cpu.m8?8:16);
    goto L_04F753;
L_04F753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF753u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF753u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF753u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F753 LDA
    cpu.setA(0x47u, 8);
    goto L_04F755;
L_04F755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF755u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF755u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF755u, 5u, 3u, cpu.address("absx", 0x0683u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F755 STA
    hw.write(cpu.address("absx", 0x683u), cpu.a, cpu.m8?8:16);
    goto L_04F758;
L_04F758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF758u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF758u, 4u + ((((0x0753u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0753u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F758 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x753u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F75B;
L_04F75B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF75Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Bu, 5u, 3u, cpu.address("absx", 0x0684u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F75B STA
    hw.write(cpu.address("absx", 0x684u), cpu.a, cpu.m8?8:16);
    goto L_04F75E;
L_04F75E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF75Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Eu, 4u + ((((0x0754u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0754u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F75E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x754u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F761;
L_04F761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF761u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF761u, 5u, 3u, cpu.address("absx", 0x0685u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F761 STA
    hw.write(cpu.address("absx", 0x685u), cpu.a, cpu.m8?8:16);
    goto L_04F764;
L_04F764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF764u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF764u, 5u, 3u, cpu.address("absx", 0x0686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F764 STZ
    hw.write(cpu.address("absx", 0x686u), 0, cpu.m8?8:16);
    goto L_04F767;
L_04F767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF767u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF767u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F767 TXA
    cpu.transfer("TXA");
    goto L_04F768;
L_04F768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF768u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF768u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F768 CLC
    cpu.setFlag('C', false);
    goto L_04F769;
L_04F769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF769u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF769u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F769 ADC
    cpu.adc(0x4u);
    goto L_04F76B;
L_04F76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Bu, 4u, 3u, cpu.address("abs", 0x0681u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F76B STA
    hw.write(cpu.address("abs", 0x681u), cpu.a, cpu.m8?8:16);
    goto L_04F76E;
L_04F76E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF76Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F76E LDX
    cpu.setX(0x2u, 8);
    goto L_04F770;
L_04F770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF770u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF770u, 4u + ((((0x0DE5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F770 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDE5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F773;
L_04F773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF773u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF773u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF773u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F773 BNE -> $04F7AB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F7AB; }
    goto L_04F775;
L_04F775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF775u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF775u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F775 LDA
    cpu.setA(0x5u, 8);
    goto L_04F777;
L_04F777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF777u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF777u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF777u, 5u, 3u, cpu.address("absx", 0x0DE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F777 STA
    hw.write(cpu.address("absx", 0xDE5u), cpu.a, cpu.m8?8:16);
    goto L_04F77A;
L_04F77A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF77Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Au, 6u, 3u, cpu.address("abs", 0xFE5Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F77A JSR -> $04FE5B stack real
    { cpu.push16Value(hw,0xF77Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF77Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFE5Bu), 0x04F77Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F77D;
L_04F77D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF77Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF77Du,0x04F77Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F77D AND
    cpu.logicAnd(0x7u);
    goto L_04F77F;
L_04F77F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF77Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F77F TAY
    cpu.transfer("TAY");
    goto L_04F780;
L_04F780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF780u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF780u, 4u + ((((0xF6D0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF6D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F780 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF6D0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F783;
L_04F783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF783u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF783u, 5u, 3u, cpu.address("absx", 0x0E55u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F783 STA
    hw.write(cpu.address("absx", 0xE55u), cpu.a, cpu.m8?8:16);
    goto L_04F786;
L_04F786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF786u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF786u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F786 TYA
    cpu.transfer("TYA");
    goto L_04F787;
L_04F787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF787u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF787u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F787 ASL
    cpu.aslA();
    goto L_04F788;
L_04F788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF788u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF788u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F788 TAY
    cpu.transfer("TAY");
    goto L_04F789;
L_04F789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF789u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF789u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F789 REP
    cpu.rep(0x20u);
    goto L_04F78B;
L_04F78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F78B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F78D;
L_04F78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F78D CLC
    cpu.setFlag('C', false);
    goto L_04F78E;
L_04F78E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Eu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Eu, 5u + ((((0xF6D8u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF6D8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F78E ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xF6D8u), cpu.m8?8:16));
    goto L_04F791;
L_04F791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF791u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF791u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F791 SEP
    cpu.sep(0x20u);
    goto L_04F793;
L_04F793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF793u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF793u, 5u, 3u, cpu.address("absx", 0x0E35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F793 STA
    hw.write(cpu.address("absx", 0xE35u), cpu.a, cpu.m8?8:16);
    goto L_04F796;
L_04F796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF796u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF796u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F796 XBA
    cpu.xba();
    goto L_04F797;
L_04F797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF797u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF797u, 5u, 3u, cpu.address("absx", 0x0E65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F797 STA
    hw.write(cpu.address("absx", 0xE65u), cpu.a, cpu.m8?8:16);
    goto L_04F79A;
L_04F79A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F79A REP
    cpu.rep(0x20u);
    goto L_04F79C;
L_04F79C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F79C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F79E;
L_04F79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F79E CLC
    cpu.setFlag('C', false);
    goto L_04F79F;
L_04F79F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Fu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Fu, 5u + ((((0xF6E8u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF6E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F79F ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xF6E8u), cpu.m8?8:16));
    goto L_04F7A2;
L_04F7A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7A2 SEP
    cpu.sep(0x20u);
    goto L_04F7A4;
L_04F7A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A4u, 5u, 3u, cpu.address("absx", 0x0E45u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7A4 STA
    hw.write(cpu.address("absx", 0xE45u), cpu.a, cpu.m8?8:16);
    goto L_04F7A7;
L_04F7A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A7u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7A7 XBA
    cpu.xba();
    goto L_04F7A8;
L_04F7A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A8u, 5u, 3u, cpu.address("absx", 0x0E75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7A8 STA
    hw.write(cpu.address("absx", 0xE75u), cpu.a, cpu.m8?8:16);
    goto L_04F7AB;
L_04F7AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7ABu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7AB DEX
    cpu.decReg('X');
    goto L_04F7AC;
L_04F7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7ACu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7AC BPL -> $04F770
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04F770; }
    goto L_04F7AE;
L_04F7AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7AEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7AE LDX
    cpu.setX(0x4u, 8);
    goto L_04F7B0;
L_04F7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B0u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7B0 TXA
    cpu.transfer("TXA");
    goto L_04F7B1;
L_04F7B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B1u, 5u, 3u, cpu.address("absx", 0x0DE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7B1 STA
    hw.write(cpu.address("absx", 0xDE0u), cpu.a, cpu.m8?8:16);
    goto L_04F7B4;
L_04F7B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B4u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7B4 DEX
    cpu.decReg('X');
    goto L_04F7B5;
L_04F7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7B5 BPL -> $04F7B0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04F7B0; }
    goto L_04F7B7;
L_04F7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7B7 LDX
    cpu.setX(0x4u, 8);
    goto L_04F7B9;
L_04F7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B9u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7B9 STX
    hw.write(cpu.address("dp", 0x0u), cpu.x, cpu.x8?8:16);
    goto L_04F7BB;
L_04F7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BBu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7BB STX
    hw.write(cpu.address("dp", 0x1u), cpu.x, cpu.x8?8:16);
    goto L_04F7BD;
L_04F7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BDu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7BD LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F7BF;
L_04F7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BFu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BFu, 4u + ((((0x0DE0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7BF LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xDE0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F7C2;
L_04F7C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C2u, 4u + ((((0x0E45u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0E45u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7C2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F7C5;
L_04F7C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7C5 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04F7C7;
L_04F7C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C7u, 4u + ((((0x0E75u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0E75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7C7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F7CA;
L_04F7CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7CA STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_04F7CC;
L_04F7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CCu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7CC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F7CE;
L_04F7CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CEu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CEu, 4u + ((((0x0DDFu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7CE LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xDDFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F7D1;
L_04F7D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D1u, 4u + ((((0x0E75u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0E75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7D1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F7D4;
L_04F7D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D4u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7D4 XBA
    cpu.xba();
    goto L_04F7D5;
L_04F7D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D5u, 4u + ((((0x0E45u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0E45u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7D5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE45u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F7D8;
L_04F7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7D8 REP
    cpu.rep(0x20u);
    goto L_04F7DA;
L_04F7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7DA CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_04F7DC;
L_04F7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7DC SEP
    cpu.sep(0x20u);
    goto L_04F7DE;
L_04F7DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7DE BPL -> $04F7ED
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04F7ED; }
    goto L_04F7E0;
L_04F7E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E0u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F7E0 PHY
    cpu.push("PHY", hw);
    goto L_04F7E1;
L_04F7E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E1u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7E1 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F7E3;
L_04F7E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E3u, 4u + ((((0x0DE0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0DE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7E3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F7E6;
L_04F7E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E6u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E6u, 5u, 3u, cpu.address("absx", 0x0DDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7E6 STA
    hw.write(cpu.address("absx", 0xDDFu), cpu.a, cpu.m8?8:16);
    goto L_04F7E9;
L_04F7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E9u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F7E9 PLA
    cpu.pop("PLA", hw);
    goto L_04F7EA;
L_04F7EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EAu, 5u, 3u, cpu.address("absy", 0x0DE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7EA STA
    hw.write(cpu.address("absy", 0xDE0u), cpu.a, cpu.m8?8:16);
    goto L_04F7ED;
L_04F7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EDu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7ED DEX
    cpu.decReg('X');
    goto L_04F7EE;
L_04F7EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7EE BNE -> $04F7BB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F7BB; }
    goto L_04F7F0;
L_04F7F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7F0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F7F2;
L_04F7F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F2u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7F2 DEX
    cpu.decReg('X');
    goto L_04F7F3;
L_04F7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7F3 BNE -> $04F7B9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F7B9; }
    goto L_04F7F5;
L_04F7F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7F5 LDA
    cpu.setA(0x30u, 8);
    goto L_04F7F7;
L_04F7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F7u, 4u, 3u, cpu.address("abs", 0x0DDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7F7 STA
    hw.write(cpu.address("abs", 0xDDFu), cpu.a, cpu.m8?8:16);
    goto L_04F7FA;
L_04F7FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FAu, 4u, 3u, cpu.address("abs", 0x0EF7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7FA STZ
    hw.write(cpu.address("abs", 0xEF7u), 0, cpu.m8?8:16);
    goto L_04F7FD;
L_04F7FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7FD LDX
    cpu.setX(0xFu, 8);
    goto L_04F7FF;
L_04F7FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F7FF LDY
    cpu.setY(0x2Du, 8);
    goto L_04F801;
L_04F801:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF801u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF801u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF801u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F801 CPX
    cpu.compareX(0xDu);
    goto L_04F803;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF801u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF801u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F801 CPX
    cpu.compareX(0xDu);
    goto L_04F803;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF801u,0x04F801u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF803u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF803u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF803u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F803 BCS -> $04F80D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F80D; }
    goto L_04F805;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF803u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF803u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F803 BCS -> $04F80D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F80D; }
    goto L_04F805;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF803u,0x04F803u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F805:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF805u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF805u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF805u, 4u + ((((0x0E25u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E25u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F805 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE25u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F808;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF805u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF805u, 4u + ((((0x0E25u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E25u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F805 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE25u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F808;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF805u,0x04F805u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF808u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF808u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF808u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F808 BEQ -> $04F80D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F80D; }
    goto L_04F80A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF808u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF808u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F808 BEQ -> $04F80D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F80D; }
    goto L_04F80A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF808u,0x04F808u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F80A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF80Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Au,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Au, 7u, 3u, cpu.address("absx", 0x0E25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F80A DEC
    cpu.decMem(hw, cpu.address("absx", 0xE25u), cpu.m8?8:16);
    goto L_04F80D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Au,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Au, 7u, 3u, cpu.address("absx", 0x0E25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F80A DEC
    cpu.decMem(hw, cpu.address("absx", 0xE25u), cpu.m8?8:16);
    goto L_04F80D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF80Au,0x04F80Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F80D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF80Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Du,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F80D CPX
    cpu.compareX(0x5u);
    goto L_04F80F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Du,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F80D CPX
    cpu.compareX(0x5u);
    goto L_04F80F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF80Du,0x04F80Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF80Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F80F BCC -> $04F819
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F819; }
    goto L_04F811;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F80F BCC -> $04F819
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_04F819; }
    goto L_04F811;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF80Fu,0x04F80Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF811u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF811u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF811u, 4u, 3u, cpu.address("abs", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F811 STX
    hw.write(cpu.address("abs", 0xDDEu), cpu.x, cpu.x8?8:16);
    goto L_04F814;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF811u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF811u, 4u, 3u, cpu.address("abs", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F811 STX
    hw.write(cpu.address("abs", 0xDDEu), cpu.x, cpu.x8?8:16);
    goto L_04F814;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF811u,0x04F811u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF814u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF814u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF814u, 6u, 3u, cpu.address("abs", 0xF853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F814 JSR -> $04F853 stack real
    { cpu.push16Value(hw,0xF816u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF817u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF853u), 0x04F814u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F817;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF814u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF814u, 6u, 3u, cpu.address("abs", 0xF853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F814 JSR -> $04F853 stack real
    { cpu.push16Value(hw,0xF816u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF817u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF853u), 0x04F814u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F817;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF814u,0x04F814u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF817u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF817u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF817u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F817 BRA -> $04F825
    goto L_04F825;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF817u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF817u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F817 BRA -> $04F825
    goto L_04F825;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF817u,0x04F817u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF819u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF819u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF819u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F819 PHX
    cpu.push("PHX", hw);
    goto L_04F81A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF819u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF819u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F819 PHX
    cpu.push("PHX", hw);
    goto L_04F81A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF819u,0x04F819u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF81Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Au, 4u + ((((0x0DE0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F81A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F81D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Au, 4u + ((((0x0DE0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F81A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F81D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF81Au,0x04F81Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F81D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF81Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F81D TAX
    cpu.transfer("TAX");
    goto L_04F81E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F81D TAX
    cpu.transfer("TAX");
    goto L_04F81E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF81Du,0x04F81Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F81E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF81Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Eu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Eu, 4u, 3u, cpu.address("abs", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F81E STX
    hw.write(cpu.address("abs", 0xDDEu), cpu.x, cpu.x8?8:16);
    goto L_04F821;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Eu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Eu, 4u, 3u, cpu.address("abs", 0x0DDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F81E STX
    hw.write(cpu.address("abs", 0xDDEu), cpu.x, cpu.x8?8:16);
    goto L_04F821;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF81Eu,0x04F81Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F821:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF821u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF821u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF821u, 6u, 3u, cpu.address("abs", 0xF853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F821 JSR -> $04F853 stack real
    { cpu.push16Value(hw,0xF823u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF824u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF853u), 0x04F821u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F824;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF821u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF821u, 6u, 3u, cpu.address("abs", 0xF853u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F821 JSR -> $04F853 stack real
    { cpu.push16Value(hw,0xF823u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF824u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF853u), 0x04F821u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04F824;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF821u,0x04F821u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F824:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF824u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF824u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF824u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F824 PLX
    cpu.pop("PLX", hw);
    goto L_04F825;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF824u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF824u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04F824 PLX
    cpu.pop("PLX", hw);
    goto L_04F825;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF824u,0x04F824u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF825u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F825 DEX
    cpu.decReg('X');
    goto L_04F826;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F825 DEX
    cpu.decReg('X');
    goto L_04F826;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF825u,0x04F825u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04F826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF826u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF826u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF826u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F826 BPL -> $04F801
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04F801; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF828u,0x04F826u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF826u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF826u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F826 BPL -> $04F801
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04F801; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF828u,0x04F826u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF826u,0x04F826u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_04F87C_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04F87Cu: goto L_04F87C;
    case 0x04F87Fu: goto L_04F87F;
    case 0x04F882u: goto L_04F882;
    case 0x04F884u: goto L_04F884;
    case 0x04F887u: goto L_04F887;
    case 0x04F889u: goto L_04F889;
    case 0x04F88Bu: goto L_04F88B;
    case 0x04F88Eu: goto L_04F88E;
    case 0x04F890u: goto L_04F890;
    case 0x04F892u: goto L_04F892;
    case 0x04F895u: goto L_04F895;
    case 0x04F896u: goto L_04F896;
    case 0x04F897u: goto L_04F897;
    case 0x04F898u: goto L_04F898;
    case 0x04F89Bu: goto L_04F89B;
    case 0x04F89Cu: goto L_04F89C;
    case 0x04F89Fu: goto L_04F89F;
    case 0x04F8A1u: goto L_04F8A1;
    case 0x04F8A3u: goto L_04F8A3;
    case 0x04F8A5u: goto L_04F8A5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04F87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Cu, 4u + ((((0x0DE5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DE5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F87C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xDE5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F87F;
L_04F87F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF87Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Fu, 4u + ((((0xF828u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF828u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F87F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF828u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F882;
L_04F882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF882u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF882u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F882 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04F884;
L_04F884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF884u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF884u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F884 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x13D9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F887;
L_04F887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF887u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF887u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F887 CPY
    cpu.compareY(0xAu);
    goto L_04F889;
L_04F889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF889u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF889u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF889u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F889 BNE -> $04F892
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F892; }
    goto L_04F88B;
L_04F88B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF88Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Bu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Bu, 4u, 3u, cpu.address("abs", 0x1DE8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F88B LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1DE8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04F88E;
L_04F88E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF88Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F88E CPY
    cpu.compareY(0x1u);
    goto L_04F890;
L_04F890:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF890u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF890u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF890u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F890 BNE -> $04F8A3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F8A3; }
    goto L_04F892;
L_04F892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF892u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF892u, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F892 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F895;
L_04F895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF895u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF895u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF895u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F895 LSR
    cpu.lsrA();
    goto L_04F896;
L_04F896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF896u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF896u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F896 LSR
    cpu.lsrA();
    goto L_04F897;
L_04F897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF897u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF897u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F897 TAY
    cpu.transfer("TAY");
    goto L_04F898;
L_04F898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF898u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF898u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF898u, 4u + ((((0x1F11u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1F11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F898 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1F11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F89B;
L_04F89B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF89Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F89B TAY
    cpu.transfer("TAY");
    goto L_04F89C;
L_04F89C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF89Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Cu, 4u + ((((0xF875u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xF875u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F89C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF875u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04F89F;
L_04F89F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF89Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Fu,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F89F AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_04F8A1;
L_04F8A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8A1 BEQ -> $04F8A5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04F8A5; }
    goto L_04F8A3;
L_04F8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04F8A3 LDA
    cpu.setA(0x1u, 8);
    goto L_04F8A5;
L_04F8A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04F8A5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04F8A5u);return;} hw.unresolvedReturn(0x04F8A5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_05B34A_E1M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05B34Au: goto L_05B34A;
    case 0x05B34Du: goto L_05B34D;
    case 0x05B34Fu: goto L_05B34F;
    case 0x05B352u: goto L_05B352;
    case 0x05B355u: goto L_05B355;
    case 0x05B357u: goto L_05B357;
    case 0x05B35Au: goto L_05B35A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05B34A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Au, 6u, 3u, cpu.address("abs", 0x13CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B34A INC
    cpu.incMem(hw, cpu.address("abs", 0x13CCu), cpu.m8?8:16);
    goto L_05B34D;
L_05B34D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B34D LDA
    cpu.setA(0x1u, 8);
    goto L_05B34F;
L_05B34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B34F STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_05B352;
L_05B352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB352u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB352u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB352u, 4u, 3u, cpu.address("abs", 0x0DC0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B352 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDC0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05B355;
L_05B355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB355u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB355u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B355 BEQ -> $05B35A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05B35A; }
    goto L_05B357;
L_05B357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB357u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB357u, 6u, 3u, cpu.address("abs", 0x0DC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B357 DEC
    cpu.decMem(hw, cpu.address("abs", 0xDC0u), cpu.m8?8:16);
    goto L_05B35A;
L_05B35A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05B35A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x05B35Au);return;} hw.unresolvedReturn(0x05B35Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_07F78B_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x07F78Bu: goto L_07F78B;
    case 0x07F78Cu: goto L_07F78C;
    case 0x07F78Du: goto L_07F78D;
    case 0x07F78Fu: goto L_07F78F;
    case 0x07F790u: goto L_07F790;
    case 0x07F794u: goto L_07F794;
    case 0x07F796u: goto L_07F796;
    case 0x07F797u: goto L_07F797;
    case 0x07F79Au: goto L_07F79A;
    case 0x07F79Eu: goto L_07F79E;
    case 0x07F79Fu: goto L_07F79F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_07F78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Bu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F78B PHY
    cpu.push("PHY", hw);
    goto L_07F78C;
L_07F78C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Cu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F78C PHX
    cpu.push("PHX", hw);
    goto L_07F78D;
L_07F78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F78D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F78F;
L_07F78F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F78F TAX
    cpu.transfer("TAX");
    goto L_07F790;
L_07F790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF790u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF790u, 5u, 4u, ((0x07F3FEu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F790 LDA
    cpu.loadA(hw.readW(((0x7F3FEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F794;
L_07F794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF794u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF794u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F794 AND
    cpu.logicAnd(0xFu);
    goto L_07F796;
L_07F796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF796u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF796u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F796 PLX
    cpu.pop("PLX", hw);
    goto L_07F797;
L_07F797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF797u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF797u, 5u, 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F797 STA
    hw.write(cpu.address("absx", 0x15F6u), cpu.a, cpu.m8?8:16);
    goto L_07F79A;
L_07F79A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Au, 8u, 4u, 0x07F7A0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F79A JSL -> $07F7A0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF79Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF79Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F7A0u, 0x07F79Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_07F79E;
L_07F79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF79Eu,0x07F79Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Eu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F79E PLY
    cpu.pop("PLY", hw);
    goto L_07F79F;
L_07F79F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F79F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x07F79Fu);return;} hw.unresolvedReturn(0x07F79Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_07F78B_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x07F78Bu: goto L_07F78B;
    case 0x07F78Cu: goto L_07F78C;
    case 0x07F78Du: goto L_07F78D;
    case 0x07F78Fu: goto L_07F78F;
    case 0x07F790u: goto L_07F790;
    case 0x07F794u: goto L_07F794;
    case 0x07F796u: goto L_07F796;
    case 0x07F797u: goto L_07F797;
    case 0x07F79Au: goto L_07F79A;
    case 0x07F79Eu: goto L_07F79E;
    case 0x07F79Fu: goto L_07F79F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_07F78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Bu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F78B PHY
    cpu.push("PHY", hw);
    goto L_07F78C;
L_07F78C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Cu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F78C PHX
    cpu.push("PHX", hw);
    goto L_07F78D;
L_07F78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F78D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F78F;
L_07F78F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F78F TAX
    cpu.transfer("TAX");
    goto L_07F790;
L_07F790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF790u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF790u, 5u, 4u, ((0x07F3FEu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F790 LDA
    cpu.loadA(hw.readW(((0x7F3FEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F794;
L_07F794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF794u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF794u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F794 AND
    cpu.logicAnd(0xFu);
    goto L_07F796;
L_07F796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF796u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF796u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F796 PLX
    cpu.pop("PLX", hw);
    goto L_07F797;
L_07F797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF797u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF797u, 5u, 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F797 STA
    hw.write(cpu.address("absx", 0x15F6u), cpu.a, cpu.m8?8:16);
    goto L_07F79A;
L_07F79A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Au, 8u, 4u, 0x07F7A0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F79A JSL -> $07F7A0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF79Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF79Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F7A0u, 0x07F79Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_07F79E;
L_07F79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF79Eu,0x07F79Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Eu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F79E PLY
    cpu.pop("PLY", hw);
    goto L_07F79F;
L_07F79F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F79F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x07F79Fu);return;} hw.unresolvedReturn(0x07F79Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_07F78B_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x07F78Bu: goto L_07F78B;
    case 0x07F78Cu: goto L_07F78C;
    case 0x07F78Du: goto L_07F78D;
    case 0x07F78Fu: goto L_07F78F;
    case 0x07F790u: goto L_07F790;
    case 0x07F794u: goto L_07F794;
    case 0x07F796u: goto L_07F796;
    case 0x07F797u: goto L_07F797;
    case 0x07F79Au: goto L_07F79A;
    case 0x07F79Eu: goto L_07F79E;
    case 0x07F79Fu: goto L_07F79F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_07F78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Bu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F78B PHY
    cpu.push("PHY", hw);
    goto L_07F78C;
L_07F78C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Cu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F78C PHX
    cpu.push("PHX", hw);
    goto L_07F78D;
L_07F78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F78D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F78F;
L_07F78F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F78F TAX
    cpu.transfer("TAX");
    goto L_07F790;
L_07F790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF790u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF790u, 5u, 4u, ((0x07F3FEu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F790 LDA
    cpu.loadA(hw.readW(((0x7F3FEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F794;
L_07F794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF794u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF794u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F794 AND
    cpu.logicAnd(0xFu);
    goto L_07F796;
L_07F796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF796u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF796u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F796 PLX
    cpu.pop("PLX", hw);
    goto L_07F797;
L_07F797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF797u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF797u, 5u, 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F797 STA
    hw.write(cpu.address("absx", 0x15F6u), cpu.a, cpu.m8?8:16);
    goto L_07F79A;
L_07F79A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Au, 8u, 4u, 0x07F7A0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F79A JSL -> $07F7A0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF79Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF79Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F7A0u, 0x07F79Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_07F79E;
L_07F79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF79Eu,0x07F79Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Eu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F79E PLY
    cpu.pop("PLY", hw);
    goto L_07F79F;
L_07F79F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F79F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x07F79Fu);return;} hw.unresolvedReturn(0x07F79Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0DADA3_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DADA3u: goto L_0DADA3;
    case 0x0DADA5u: goto L_0DADA5;
    case 0x0DADA7u: goto L_0DADA7;
    case 0x0DADA9u: goto L_0DADA9;
    case 0x0DADABu: goto L_0DADAB;
    case 0x0DADAEu: goto L_0DADAE;
    case 0x0DADB0u: goto L_0DADB0;
    case 0x0DADB1u: goto L_0DADB1;
    case 0x0DADB2u: goto L_0DADB2;
    case 0x0DADB3u: goto L_0DADB3;
    case 0x0DADB4u: goto L_0DADB4;
    case 0x0DADB6u: goto L_0DADB6;
    case 0x0DADB8u: goto L_0DADB8;
    case 0x0DADBBu: goto L_0DADBB;
    case 0x0DADBEu: goto L_0DADBE;
    case 0x0DADC0u: goto L_0DADC0;
    case 0x0DADC3u: goto L_0DADC3;
    case 0x0DADC4u: goto L_0DADC4;
    case 0x0DADC6u: goto L_0DADC6;
    case 0x0DADC8u: goto L_0DADC8;
    case 0x0DADCBu: goto L_0DADCB;
    case 0x0DADCDu: goto L_0DADCD;
    case 0x0DADD0u: goto L_0DADD0;
    case 0x0DADD2u: goto L_0DADD2;
    case 0x0DADD4u: goto L_0DADD4;
    case 0x0DADD7u: goto L_0DADD7;
    case 0x0DADD9u: goto L_0DADD9;
    case 0x0DADDCu: goto L_0DADDC;
    case 0x0DADDFu: goto L_0DADDF;
    case 0x0DADE2u: goto L_0DADE2;
    case 0x0DADE4u: goto L_0DADE4;
    case 0x0DADE6u: goto L_0DADE6;
    case 0x0DADE8u: goto L_0DADE8;
    case 0x0DADEAu: goto L_0DADEA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DADA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA3u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADA3 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DADA5;
L_0DADA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADA5 LDX
    cpu.setX(0x0u, 8);
    goto L_0DADA7;
L_0DADA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADA7 STX
    hw.write(cpu.address("dp", 0x2u), cpu.x, cpu.x8?8:16);
    goto L_0DADA9;
L_0DADA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADA9 STX
    hw.write(cpu.address("dp", 0x0u), cpu.x, cpu.x8?8:16);
    goto L_0DADAB;
L_0DADAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADABu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADABu, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DADAB JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xADADu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADAEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DADABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DADAE;
L_0DADAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADAEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADAEu,0x0DADAEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DADB0;
L_0DADB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADB0 LSR
    cpu.lsrA();
    goto L_0DADB1;
L_0DADB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADB1 LSR
    cpu.lsrA();
    goto L_0DADB2;
L_0DADB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADB2 LSR
    cpu.lsrA();
    goto L_0DADB3;
L_0DADB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADB3 LSR
    cpu.lsrA();
    goto L_0DADB4;
L_0DADB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADB4 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DADB6;
L_0DADB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADB6 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DADB8;
L_0DADB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB8u, 3u, 3u, cpu.address("abs", 0xADD0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADB8 JMP -> $0DADD0
    goto L_0DADD0;
L_0DADBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBBu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DADBB JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xADBDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADBEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DADBBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DADBE;
L_0DADBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADBEu,0x0DADBEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADBE LDA
    cpu.setA(0x3Fu, 8);
    goto L_0DADC0;
L_0DADC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC0u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DADC0 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xADC2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADC3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DADC0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DADC3;
L_0DADC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADC3u,0x0DADC3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC3u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADC3 DEX
    cpu.decReg('X');
    goto L_0DADC4;
L_0DADC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC4u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADC4 CPX
    cpu.compareX(0x1u);
    goto L_0DADC6;
L_0DADC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADC6 BNE -> $0DADBB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DADBB; }
    goto L_0DADC8;
L_0DADC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC8u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DADC8 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xADCAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADCBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DADC8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DADCB;
L_0DADCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADCBu,0x0DADCBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADCB LDA
    cpu.setA(0xE4u, 8);
    goto L_0DADCD;
L_0DADCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCDu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DADCD JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xADCFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADD0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DADCDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DADD0;
L_0DADD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADD0u,0x0DADD0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADD0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DADD2;
L_0DADD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADD2 BEQ -> $0DADEA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DADEA; }
    goto L_0DADD4;
L_0DADD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD4u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DADD4 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xADD6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADD7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DADD4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DADD7;
L_0DADD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADD7u,0x0DADD7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADD7 LDA
    cpu.setA(0xAFu, 8);
    goto L_0DADD9;
L_0DADD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD9u, 6u, 3u, cpu.address("abs", 0xABFDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DADD9 JSR -> $0DABFD stack real
    { cpu.push16Value(hw,0xADDBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADDCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABFDu), 0x0DADD9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DADDC;
L_0DADDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADDCu,0x0DADDCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DADDC JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xADDEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADDFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DADDCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DADDF;
L_0DADDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADDFu,0x0DADDFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDFu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DADDF JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xADE1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADE2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DADDFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DADE2;
L_0DADE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADE2u,0x0DADE2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE2u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADE2 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DADE4;
L_0DADE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE4u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADE4 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DADE6;
L_0DADE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE6u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADE6 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DADE8;
L_0DADE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DADE8 BPL -> $0DADC4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DADC4; }
    goto L_0DADEA;
L_0DADEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADEAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADEAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DADEA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DADEAu);return;} hw.unresolvedReturn(0x0DADEAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DF02B_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DF02Bu: goto L_0DF02B;
    case 0x0DF02Du: goto L_0DF02D;
    case 0x0DF02Fu: goto L_0DF02F;
    case 0x0DF031u: goto L_0DF031;
    case 0x0DF033u: goto L_0DF033;
    case 0x0DF035u: goto L_0DF035;
    case 0x0DF036u: goto L_0DF036;
    case 0x0DF037u: goto L_0DF037;
    case 0x0DF038u: goto L_0DF038;
    case 0x0DF039u: goto L_0DF039;
    case 0x0DF03Bu: goto L_0DF03B;
    case 0x0DF03Eu: goto L_0DF03E;
    case 0x0DF040u: goto L_0DF040;
    case 0x0DF043u: goto L_0DF043;
    case 0x0DF045u: goto L_0DF045;
    case 0x0DF048u: goto L_0DF048;
    case 0x0DF049u: goto L_0DF049;
    case 0x0DF04Bu: goto L_0DF04B;
    case 0x0DF04Eu: goto L_0DF04E;
    case 0x0DF050u: goto L_0DF050;
    case 0x0DF053u: goto L_0DF053;
    case 0x0DF055u: goto L_0DF055;
    case 0x0DF058u: goto L_0DF058;
    case 0x0DF059u: goto L_0DF059;
    case 0x0DF05Bu: goto L_0DF05B;
    case 0x0DF05Eu: goto L_0DF05E;
    case 0x0DF061u: goto L_0DF061;
    case 0x0DF063u: goto L_0DF063;
    case 0x0DF065u: goto L_0DF065;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DF02B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF02Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF02Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF02Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF02B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DF02D;
L_0DF02D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF02Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF02Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF02Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF02D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DF02F;
L_0DF02F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF02Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF02Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF02Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF02F AND
    cpu.logicAnd(0xFu);
    goto L_0DF031;
L_0DF031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF031u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF031u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF031 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DF033;
L_0DF033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF033u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF033u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF033 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DF035;
L_0DF035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF035u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF035u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF035 LSR
    cpu.lsrA();
    goto L_0DF036;
L_0DF036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF036u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF036u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF036 LSR
    cpu.lsrA();
    goto L_0DF037;
L_0DF037:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF037u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF037u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF037u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF037 LSR
    cpu.lsrA();
    goto L_0DF038;
L_0DF038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF038u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF038u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF038 LSR
    cpu.lsrA();
    goto L_0DF039;
L_0DF039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF039u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF039u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF039 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DF03B;
L_0DF03B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF03Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Bu, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DF03B JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xF03Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF03Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DF03Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DF03E;
L_0DF03E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF03Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF03Eu,0x0DF03Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF03Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF03E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DF040;
L_0DF040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF040u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF040u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DF040 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xF042u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF043u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DF040u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DF043;
L_0DF043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF043u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF043u,0x0DF043u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF043u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF043u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF043 LDA
    cpu.setA(0xFu, 8);
    goto L_0DF045;
L_0DF045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF045u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF045u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DF045 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xF047u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF048u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DF045u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DF048;
L_0DF048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF048u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF048u,0x0DF048u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF048u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF048u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF048 DEX
    cpu.decReg('X');
    goto L_0DF049;
L_0DF049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF049u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF049u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF049 BPL -> $0DF040
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DF040; }
    goto L_0DF04B;
L_0DF04B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF04Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Bu, 3u, 3u, cpu.address("abs", 0xF05Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF04B JMP -> $0DF05B
    goto L_0DF05B;
L_0DF04E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF04Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF04Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF04E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DF050;
L_0DF050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF050u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF050u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DF050 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xF052u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF053u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DF050u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DF053;
L_0DF053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF053u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF053u,0x0DF053u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF053u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF053u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF053 LDA
    cpu.setA(0xEAu, 8);
    goto L_0DF055;
L_0DF055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF055u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF055u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DF055 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xF057u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF058u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DF055u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DF058;
L_0DF058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF058u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF058u,0x0DF058u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF058u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF058u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF058 DEX
    cpu.decReg('X');
    goto L_0DF059;
L_0DF059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF059u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF059u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF059u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF059 BPL -> $0DF050
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DF050; }
    goto L_0DF05B;
L_0DF05B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF05Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Bu, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DF05B JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xF05Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF05Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DF05Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DF05E;
L_0DF05E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF05Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF05Eu,0x0DF05Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF05Eu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DF05E JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xF060u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF061u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DF05Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DF061;
L_0DF061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF061u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF061u,0x0DF061u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF061u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF061u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF061 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DF063;
L_0DF063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF063u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF063u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF063u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DF063 BPL -> $0DF04E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DF04E; }
    goto L_0DF065;
L_0DF065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF065u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF065u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF065u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DF065 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DF065u);return;} hw.unresolvedReturn(0x0DF065u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1A4E2_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A4E2u: goto L_B1A4E2;
    case 0xB1A4E5u: goto L_B1A4E5;
    case 0xB1A4E7u: goto L_B1A4E7;
    case 0xB1A4E9u: goto L_B1A4E9;
    case 0xB1A4ECu: goto L_B1A4EC;
    case 0xB1A4EEu: goto L_B1A4EE;
    case 0xB1A4F0u: goto L_B1A4F0;
    case 0xB1A4F2u: goto L_B1A4F2;
    case 0xB1A4F5u: goto L_B1A4F5;
    case 0xB1A4F7u: goto L_B1A4F7;
    case 0xB1A4F9u: goto L_B1A4F9;
    case 0xB1A4FBu: goto L_B1A4FB;
    case 0xB1A4FDu: goto L_B1A4FD;
    case 0xB1A4FFu: goto L_B1A4FF;
    case 0xB1A501u: goto L_B1A501;
    case 0xB1A503u: goto L_B1A503;
    case 0xB1A505u: goto L_B1A505;
    case 0xB1A506u: goto L_B1A506;
    case 0xB1A509u: goto L_B1A509;
    case 0xB1A50Bu: goto L_B1A50B;
    case 0xB1A50Du: goto L_B1A50D;
    case 0xB1A50Fu: goto L_B1A50F;
    case 0xB1A511u: goto L_B1A511;
    case 0xB1A513u: goto L_B1A513;
    case 0xB1A515u: goto L_B1A515;
    case 0xB1A517u: goto L_B1A517;
    case 0xB1A519u: goto L_B1A519;
    case 0xB1A52Eu: goto L_B1A52E;
    case 0xB1A531u: goto L_B1A531;
    case 0xB1A534u: goto L_B1A534;
    case 0xB1A53Au: goto L_B1A53A;
    case 0xB1A540u: goto L_B1A540;
    case 0xB1A543u: goto L_B1A543;
    case 0xB1A544u: goto L_B1A544;
    case 0xB1A545u: goto L_B1A545;
    case 0xB1A546u: goto L_B1A546;
    case 0xB1A547u: goto L_B1A547;
    case 0xB1A548u: goto L_B1A548;
    case 0xB1A54Bu: goto L_B1A54B;
    case 0xB1A54Cu: goto L_B1A54C;
    case 0xB1A54Du: goto L_B1A54D;
    case 0xB1A550u: goto L_B1A550;
    case 0xB1A553u: goto L_B1A553;
    case 0xB1A555u: goto L_B1A555;
    case 0xB1A558u: goto L_B1A558;
    case 0xB1A55Au: goto L_B1A55A;
    case 0xB1A55Cu: goto L_B1A55C;
    case 0xB1A55Fu: goto L_B1A55F;
    case 0xB1A561u: goto L_B1A561;
    case 0xB1A563u: goto L_B1A563;
    case 0xB1A565u: goto L_B1A565;
    case 0xB1A567u: goto L_B1A567;
    case 0xB1A56Au: goto L_B1A56A;
    case 0xB1A56Du: goto L_B1A56D;
    case 0xB1A56Fu: goto L_B1A56F;
    case 0xB1A570u: goto L_B1A570;
    case 0xB1A573u: goto L_B1A573;
    case 0xB1A576u: goto L_B1A576;
    case 0xB1A579u: goto L_B1A579;
    case 0xB1A57Au: goto L_B1A57A;
    case 0xB1A57Cu: goto L_B1A57C;
    case 0xB1A57Eu: goto L_B1A57E;
    case 0xB1A581u: goto L_B1A581;
    case 0xB1A583u: goto L_B1A583;
    case 0xB1A585u: goto L_B1A585;
    case 0xB1A588u: goto L_B1A588;
    case 0xB1A58Bu: goto L_B1A58B;
    case 0xB1A58Cu: goto L_B1A58C;
    case 0xB1A58Eu: goto L_B1A58E;
    case 0xB1A591u: goto L_B1A591;
    case 0xB1A592u: goto L_B1A592;
    case 0xB1A595u: goto L_B1A595;
    case 0xB1A597u: goto L_B1A597;
    case 0xB1A59Au: goto L_B1A59A;
    case 0xB1A59Cu: goto L_B1A59C;
    case 0xB1A59Eu: goto L_B1A59E;
    case 0xB1A5A1u: goto L_B1A5A1;
    case 0xB1A5A4u: goto L_B1A5A4;
    case 0xB1A5A6u: goto L_B1A5A6;
    case 0xB1A5A8u: goto L_B1A5A8;
    case 0xB1A5ABu: goto L_B1A5AB;
    case 0xB1A5ACu: goto L_B1A5AC;
    case 0xB1A5AEu: goto L_B1A5AE;
    case 0xB1A5B0u: goto L_B1A5B0;
    case 0xB1A5B3u: goto L_B1A5B3;
    case 0xB1A5B4u: goto L_B1A5B4;
    case 0xB1A5B7u: goto L_B1A5B7;
    case 0xB1A5B9u: goto L_B1A5B9;
    case 0xB1A5BCu: goto L_B1A5BC;
    case 0xB1A5BEu: goto L_B1A5BE;
    case 0xB1A5C0u: goto L_B1A5C0;
    case 0xB1A5C3u: goto L_B1A5C3;
    case 0xB1A5C4u: goto L_B1A5C4;
    case 0xB1A5C7u: goto L_B1A5C7;
    case 0xB1A5C8u: goto L_B1A5C8;
    case 0xB1A5CAu: goto L_B1A5CA;
    case 0xB1A5CCu: goto L_B1A5CC;
    case 0xB1A5CEu: goto L_B1A5CE;
    case 0xB1A5D1u: goto L_B1A5D1;
    case 0xB1A5D3u: goto L_B1A5D3;
    case 0xB1A5D4u: goto L_B1A5D4;
    case 0xB1A5D5u: goto L_B1A5D5;
    case 0xB1A5D8u: goto L_B1A5D8;
    case 0xB1A5D9u: goto L_B1A5D9;
    case 0xB1A5DAu: goto L_B1A5DA;
    case 0xB1A5DDu: goto L_B1A5DD;
    case 0xB1A5E0u: goto L_B1A5E0;
    case 0xB1A5E3u: goto L_B1A5E3;
    case 0xB1A5E5u: goto L_B1A5E5;
    case 0xB1A5E8u: goto L_B1A5E8;
    case 0xB1A5E9u: goto L_B1A5E9;
    case 0xB1A5EAu: goto L_B1A5EA;
    case 0xB1A5EEu: goto L_B1A5EE;
    case 0xB1A5EFu: goto L_B1A5EF;
    case 0xB1A5F1u: goto L_B1A5F1;
    case 0xB1A5F2u: goto L_B1A5F2;
    case 0xB1A5F4u: goto L_B1A5F4;
    case 0xB1A5F6u: goto L_B1A5F6;
    case 0xB1A5F8u: goto L_B1A5F8;
    case 0xB1A5FBu: goto L_B1A5FB;
    case 0xB1A5FDu: goto L_B1A5FD;
    case 0xB1A600u: goto L_B1A600;
    case 0xB1A601u: goto L_B1A601;
    case 0xB1A604u: goto L_B1A604;
    case 0xB1A607u: goto L_B1A607;
    case 0xB1A609u: goto L_B1A609;
    case 0xB1A60Bu: goto L_B1A60B;
    case 0xB1A60Eu: goto L_B1A60E;
    case 0xB1A611u: goto L_B1A611;
    case 0xB1A612u: goto L_B1A612;
    case 0xB1A614u: goto L_B1A614;
    case 0xB1A616u: goto L_B1A616;
    case 0xB1A618u: goto L_B1A618;
    case 0xB1A619u: goto L_B1A619;
    case 0xB1A61Du: goto L_B1A61D;
    case 0xB1A625u: goto L_B1A625;
    case 0xB1A627u: goto L_B1A627;
    case 0xB1A628u: goto L_B1A628;
    case 0xB1A62Au: goto L_B1A62A;
    case 0xB1A62Cu: goto L_B1A62C;
    case 0xB1A62Eu: goto L_B1A62E;
    case 0xB1A62Fu: goto L_B1A62F;
    case 0xB1A630u: goto L_B1A630;
    case 0xB1A633u: goto L_B1A633;
    case 0xB1A634u: goto L_B1A634;
    case 0xB1A636u: goto L_B1A636;
    case 0xB1A639u: goto L_B1A639;
    case 0xB1A63Cu: goto L_B1A63C;
    case 0xB1A63Du: goto L_B1A63D;
    case 0xB1A640u: goto L_B1A640;
    case 0xB1A642u: goto L_B1A642;
    case 0xB1A645u: goto L_B1A645;
    case 0xB1A647u: goto L_B1A647;
    case 0xB1A64Au: goto L_B1A64A;
    case 0xB1A64Bu: goto L_B1A64B;
    case 0xB1A64Eu: goto L_B1A64E;
    case 0xB1A64Fu: goto L_B1A64F;
    case 0xB1A652u: goto L_B1A652;
    case 0xB1A655u: goto L_B1A655;
    case 0xB1A657u: goto L_B1A657;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A4E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E2u, 4u + ((((0x1588u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4E2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A4E5;
L_B1A4E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4E5 AND
    cpu.logicAnd(0x4u);
    goto L_B1A4E7;
L_B1A4E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4E7 BNE -> $B1A4F2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A4F2; }
    goto L_B1A4E9;
L_B1A4E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E9u, 4u + ((((0x009Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x009Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4E9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A4EC;
L_B1A4EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ECu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4EC CMP
    cpu.compareA(0xFu);
    goto L_B1A4EE;
L_B1A4EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4EE BEQ -> $B1A534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A534; }
    goto L_B1A4F0;
L_B1A4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4F0 BRA -> $B1A506
    goto L_B1A506;
L_B1A4F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F2u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4F2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A4F5;
L_B1A4F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4F5 CMP
    cpu.compareA(0x8u);
    goto L_B1A4F7;
L_B1A4F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4F7 BEQ -> $B1A540
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A540; }
    goto L_B1A4F9;
L_B1A4F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4F9 CMP
    cpu.compareA(0x9u);
    goto L_B1A4FB;
L_B1A4FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4FB BEQ -> $B1A555
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A555; }
    goto L_B1A4FD;
L_B1A4FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4FD CMP
    cpu.compareA(0xAu);
    goto L_B1A4FF;
L_B1A4FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A4FF BEQ -> $B1A53A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A53A; }
    goto L_B1A501;
L_B1A501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA501u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA501u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A501 CMP
    cpu.compareA(0xBu);
    goto L_B1A503;
L_B1A503:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA503u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA503u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA503u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A503 BEQ -> $B1A534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A534; }
    goto L_B1A505;
L_B1A505:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA505u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA505u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA505u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A505 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A505u);return;} hw.unresolvedReturn(0xB1A505u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA506u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA506u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A506 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A509;
L_B1A509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA509u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA509u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A509 CMP
    cpu.compareA(0x8u);
    goto L_B1A50B;
L_B1A50B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A50B BEQ -> $B1A52E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A52E; }
    goto L_B1A50D;
L_B1A50D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A50D CMP
    cpu.compareA(0x9u);
    goto L_B1A50F;
L_B1A50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A50F BEQ -> $B1A531
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A531; }
    goto L_B1A511;
L_B1A511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA511u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA511u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A511 CMP
    cpu.compareA(0xAu);
    goto L_B1A513;
L_B1A513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA513u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA513u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A513 BEQ -> $B1A534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A534; }
    goto L_B1A515;
L_B1A515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA515u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA515u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA515u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A515 CMP
    cpu.compareA(0xBu);
    goto L_B1A517;
L_B1A517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA517u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA517u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A517 BEQ -> $B1A534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A534; }
    goto L_B1A519;
L_B1A519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA519u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA519u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A519 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A519u);return;} hw.unresolvedReturn(0xB1A519u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A52E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA52Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Eu, 3u, 3u, cpu.address("abs", 0xA625u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A52E JMP -> $B1A625
    goto L_B1A625;
L_B1A531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA531u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u, 3u, 3u, cpu.address("abs", 0xA642u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A531 JMP -> $B1A642
    goto L_B1A642;
L_B1A534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA534u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u, 3u, 3u, cpu.address("abs", 0xA685u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A534 JMP -> $B1A685
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xA685u),0xB1A534u); return;
L_B1A53A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Au, 3u, 3u, cpu.address("abs", 0xA5C4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A53A JMP -> $B1A5C4
    goto L_B1A5C4;
L_B1A540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA540u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA540u, 6u, 3u, cpu.address("abs", 0xA6D9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A540 JSR -> $B1A6D9 stack real
    { cpu.push16Value(hw,0xA542u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA543u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6D9u), 0xB1A540u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A543;
L_B1A543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA543u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA543u,0xB1A543u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA543u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA543u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A543 PHX
    cpu.push("PHX", hw);
    goto L_B1A544;
L_B1A544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA544u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA544u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A544 PHY
    cpu.push("PHY", hw);
    goto L_B1A545;
L_B1A545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA545u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA545u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA545u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A545 TYA
    cpu.transfer("TYA");
    goto L_B1A546;
L_B1A546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA546u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA546u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A546 TXY
    cpu.transfer("TXY");
    goto L_B1A547;
L_B1A547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA547u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA547u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA547u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A547 TAX
    cpu.transfer("TAX");
    goto L_B1A548;
L_B1A548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA548u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA548u, 6u, 3u, cpu.address("abs", 0xA6D9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A548 JSR -> $B1A6D9 stack real
    { cpu.push16Value(hw,0xA54Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA54Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6D9u), 0xB1A548u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A54B;
L_B1A54B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA54Bu,0xB1A54Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Bu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A54B PLY
    cpu.pop("PLY", hw);
    goto L_B1A54C;
L_B1A54C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Cu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A54C PLX
    cpu.pop("PLX", hw);
    goto L_B1A54D;
L_B1A54D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Du, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A54D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A550;
L_B1A550:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA550u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA550u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA550u, 4u + ((((0x1558u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A550 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x1558u), cpu.m8?8:16));
    goto L_B1A553;
L_B1A553:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA553u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA553u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA553u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A553 BNE -> $B1A5C3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A5C3; }
    goto L_B1A555;
L_B1A555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA555u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA555u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A555 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A558;
L_B1A558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA558u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA558u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A558 CMP
    cpu.compareA(0x9u);
    goto L_B1A55A;
L_B1A55A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A55A BNE -> $B1A56D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A56D; }
    goto L_B1A55C;
L_B1A55C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Cu, 6u, 3u, cpu.address("abs", 0x800Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A55C JSR -> $B1800E stack real
    { cpu.push16Value(hw,0xA55Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA55Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x800Eu), 0xB1A55Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A55F;
L_B1A55F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA55Fu,0xB1A55Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A55F BNE -> $B1A56D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A56D; }
    goto L_B1A561;
L_B1A561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA561u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA561u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA561u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A561 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A563;
L_B1A563:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA563u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA563u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA563u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A563 CMP
    cpu.compareA(0xFu);
    goto L_B1A565;
L_B1A565:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA565u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA565u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA565u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A565 BNE -> $B1A56A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A56A; }
    goto L_B1A567;
L_B1A567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u, 3u, 3u, cpu.address("abs", 0xA685u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A567 JMP -> $B1A685
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xA685u),0xB1A567u); return;
L_B1A56A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Au, 3u, 3u, cpu.address("abs", 0xA5C4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A56A JMP -> $B1A5C4
    goto L_B1A5C4;
L_B1A56D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A56D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A56F;
L_B1A56F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A56F SEC
    cpu.setFlag('C', true);
    goto L_B1A570;
L_B1A570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA570u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u, 4u + ((((0x00E4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x00E4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A570 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0xE4u), cpu.m8?8:16));
    goto L_B1A573;
L_B1A573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA573u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA573u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A573 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A576;
L_B1A576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA576u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA576u, 4u + ((((0x14E0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A576 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x14E0u), cpu.m8?8:16));
    goto L_B1A579;
L_B1A579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA579u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA579u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A579 ROL
    cpu.rolA();
    goto L_B1A57A;
L_B1A57A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A57A AND
    cpu.logicAnd(0x1u);
    goto L_B1A57C;
L_B1A57C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A57C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_B1A57E;
L_B1A57E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Eu, 4u + ((((0x1686u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A57E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1686u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A581;
L_B1A581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA581u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA581u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A581 AND
    cpu.logicAnd(0x10u);
    goto L_B1A583;
L_B1A583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA583u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA583u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA583u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A583 BNE -> $B1A5A1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A5A1; }
    goto L_B1A585;
L_B1A585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA585u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA585u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA585u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A585 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A588;
L_B1A588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA588u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA588u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA588u, 4u + ((((0x157Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A588 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A58B;
L_B1A58B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A58B PHA
    cpu.push("PHA", hw);
    goto L_B1A58C;
L_B1A58C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A58C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A58E;
L_B1A58E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Eu, 5u, 3u, cpu.address("absy", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A58E STA
    hw.write(cpu.address("absy", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_B1A591;
L_B1A591:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA591u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A591 PLA
    cpu.pop("PLA", hw);
    goto L_B1A592;
L_B1A592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA592u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA592u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA592u, 4u + ((((0x157Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A592 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x157Cu), cpu.m8?8:16));
    goto L_B1A595;
L_B1A595:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA595u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA595u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA595u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A595 BEQ -> $B1A5A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A5A1; }
    goto L_B1A597;
L_B1A597:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA597u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA597u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA597u, 4u + ((((0x15ACu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A597 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x15ACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A59A;
L_B1A59A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A59A BNE -> $B1A5A1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A5A1; }
    goto L_B1A59C;
L_B1A59C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A59C LDA
    cpu.setA(0x8u, 8);
    goto L_B1A59E;
L_B1A59E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Eu, 5u, 3u, cpu.address("absy", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A59E STA
    hw.write(cpu.address("absy", 0x15ACu), cpu.a, cpu.m8?8:16);
    goto L_B1A5A1;
L_B1A5A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A1u, 4u + ((((0x1686u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1686u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5A1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1686u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A5A4;
L_B1A5A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5A4 AND
    cpu.logicAnd(0x10u);
    goto L_B1A5A6;
L_B1A5A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5A6 BNE -> $B1A5C3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A5C3; }
    goto L_B1A5A8;
L_B1A5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5A8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A5AB;
L_B1A5AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A5AB PHA
    cpu.push("PHA", hw);
    goto L_B1A5AC;
L_B1A5AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A5AE;
L_B1A5AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AEu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5AE EOR
    cpu.logicXor(0x1u);
    goto L_B1A5B0;
L_B1A5B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B0u, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5B0 STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_B1A5B3;
L_B1A5B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B3u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A5B3 PLA
    cpu.pop("PLA", hw);
    goto L_B1A5B4;
L_B1A5B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B4u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B4u, 4u + ((((0x157Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5B4 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x157Cu), cpu.m8?8:16));
    goto L_B1A5B7;
L_B1A5B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5B7 BEQ -> $B1A5C3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A5C3; }
    goto L_B1A5B9;
L_B1A5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5B9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15ACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A5BC;
L_B1A5BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5BC BNE -> $B1A5C3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A5C3; }
    goto L_B1A5BE;
L_B1A5BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5BE LDA
    cpu.setA(0x8u, 8);
    goto L_B1A5C0;
L_B1A5C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C0u, 5u, 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5C0 STA
    hw.write(cpu.address("absx", 0x15ACu), cpu.a, cpu.m8?8:16);
    goto L_B1A5C3;
L_B1A5C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A5C3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A5C3u);return;} hw.unresolvedReturn(0xB1A5C3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A5C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C4u, 4u + ((((0x009Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x009Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5C4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A5C7;
L_B1A5C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C7u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5C7 SEC
    cpu.setFlag('C', true);
    goto L_B1A5C8;
L_B1A5C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C8u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5C8 SBC
    cpu.sbc(0x83u);
    goto L_B1A5CA;
L_B1A5CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5CA CMP
    cpu.compareA(0x2u);
    goto L_B1A5CC;
L_B1A5CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CCu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5CC BCS -> $B1A5DA
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A5DA; }
    goto L_B1A5CE;
L_B1A5CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CEu, 6u, 3u, cpu.address("abs", 0x9098u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A5CE JSR -> $B19098 stack real
    { cpu.push16Value(hw,0xA5D0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5D1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9098u), 0xB1A5CEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A5D1;
L_B1A5D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5D1u,0xB1A5D1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D1u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5D1 STZ
    hw.write(cpu.address("dpx", 0xAAu), 0, cpu.m8?8:16);
    goto L_B1A5D3;
L_B1A5D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D3u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A5D3 PHX
    cpu.push("PHX", hw);
    goto L_B1A5D4;
L_B1A5D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D4u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5D4 TYX
    cpu.transfer("TYX");
    goto L_B1A5D5;
L_B1A5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u, 6u, 3u, cpu.address("abs", 0xB4E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A5D5 JSR -> $B1B4E2 stack real
    { cpu.push16Value(hw,0xA5D7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5D8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB4E2u), 0xB1A5D5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A5D8;
L_B1A5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5D8u,0xB1A5D8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A5D8 PLX
    cpu.pop("PLX", hw);
    goto L_B1A5D9;
L_B1A5D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A5D9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A5D9u);return;} hw.unresolvedReturn(0xB1A5D9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DAu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DAu, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5DA LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A5DD;
L_B1A5DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DDu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DDu, 4u, 3u, cpu.address("abs", 0x1695u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5DD LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1695u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A5E0;
L_B1A5E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E0u, 6u, 3u, cpu.address("abs", 0xA77Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A5E0 JSR -> $B1A77C stack real
    { cpu.push16Value(hw,0xA5E2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5E3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA77Cu), 0xB1A5E0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A5E3;
L_B1A5E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5E3u,0xB1A5E3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5E3 LDA
    cpu.setA(0x2u, 8);
    goto L_B1A5E5;
L_B1A5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E5u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E5u, 5u, 3u, cpu.address("absy", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5E5 STA
    hw.write(cpu.address("absy", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1A5E8;
L_B1A5E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E8u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A5E8 PHX
    cpu.push("PHX", hw);
    goto L_B1A5E9;
L_B1A5E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E9u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5E9 TYX
    cpu.transfer("TYX");
    goto L_B1A5EA;
L_B1A5EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EAu, 8u, 4u, 0x01AB72u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A5EA JSL -> $01AB72 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA5EDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5EEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB72u, 0xB1A5EAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A5EE;
L_B1A5EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5EEu,0xB1A5EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EEu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A5EE PLX
    cpu.pop("PLX", hw);
    goto L_B1A5EF;
L_B1A5EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EFu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5EF LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A5F1;
L_B1A5F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5F1 ASL
    cpu.aslA();
    goto L_B1A5F2;
L_B1A5F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5F2 LDA
    cpu.setA(0x10u, 8);
    goto L_B1A5F4;
L_B1A5F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F4u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5F4 BCC -> $B1A5F8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A5F8; }
    goto L_B1A5F6;
L_B1A5F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5F6 LDA
    cpu.setA(0xF0u, 8);
    goto L_B1A5F8;
L_B1A5F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F8u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F8u, 5u, 3u, cpu.address("absy", 0x00B6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5F8 STA
    hw.write(cpu.address("absy", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_B1A5FB;
L_B1A5FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5FB LDA
    cpu.setA(0xD0u, 8);
    goto L_B1A5FD;
L_B1A5FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FDu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FDu, 5u, 3u, cpu.address("absy", 0x00AAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5FD STA
    hw.write(cpu.address("absy", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B1A600;
L_B1A600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA600u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA600u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A600 PHY
    cpu.push("PHY", hw);
    goto L_B1A601;
L_B1A601:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA601u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA601u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA601u, 7u, 3u, cpu.address("absx", 0x1626u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A601 INC
    cpu.incMem(hw, cpu.address("absx", 0x1626u), cpu.m8?8:16);
    goto L_B1A604;
L_B1A604:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA604u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA604u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA604u, 4u + ((((0x1626u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A604 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1626u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A607;
L_B1A607:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA607u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA607u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA607u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A607 CPY
    cpu.compareY(0x8u);
    goto L_B1A609;
L_B1A609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA609u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA609u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A609 BCS -> $B1A611
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A611; }
    goto L_B1A60B;
L_B1A60B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Bu, 4u + ((((0xA61Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA61Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A60B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA61Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A60E;
L_B1A60E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Eu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A60E STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_B1A611;
L_B1A611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA611u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA611u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA611u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A611 TYA
    cpu.transfer("TYA");
    goto L_B1A612;
L_B1A612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA612u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA612u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A612 CMP
    cpu.compareA(0x8u);
    goto L_B1A614;
L_B1A614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA614u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA614u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A614 BCC -> $B1A618
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A618; }
    goto L_B1A616;
L_B1A616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA616u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA616u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A616 LDA
    cpu.setA(0x8u, 8);
    goto L_B1A618;
L_B1A618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA618u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA618u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A618 PLY
    cpu.pop("PLY", hw);
    goto L_B1A619;
L_B1A619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u, 8u, 4u, 0x02ACE1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A619 JSL -> $02ACE1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA61Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA61Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACE1u, 0xB1A619u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A61D;
L_B1A61D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA61Du,0xB1A61Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A61D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A61Du);return;} hw.unresolvedReturn(0xB1A61Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A625 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A627;
L_B1A627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA627u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA627u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A627 SEC
    cpu.setFlag('C', true);
    goto L_B1A628;
L_B1A628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA628u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA628u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA628u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A628 SBC
    cpu.sbc(0x83u);
    goto L_B1A62A;
L_B1A62A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A62A CMP
    cpu.compareA(0x2u);
    goto L_B1A62C;
L_B1A62C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A62C BCS -> $B1A63D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A63D; }
    goto L_B1A62E;
L_B1A62E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Eu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A62E PHX
    cpu.push("PHX", hw);
    goto L_B1A62F;
L_B1A62F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Fu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A62F TYX
    cpu.transfer("TYX");
    goto L_B1A630;
L_B1A630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA630u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA630u, 6u, 3u, cpu.address("abs", 0x9098u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A630 JSR -> $B19098 stack real
    { cpu.push16Value(hw,0xA632u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA633u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9098u), 0xB1A630u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A633;
L_B1A633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA633u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA633u,0xB1A633u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA633u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA633u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A633 PLX
    cpu.pop("PLX", hw);
    goto L_B1A634;
L_B1A634:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA634u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA634u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA634u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A634 LDA
    cpu.setA(0x0u, 8);
    goto L_B1A636;
L_B1A636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA636u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA636u, 5u, 3u, cpu.address("absy", 0x00AAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A636 STA
    hw.write(cpu.address("absy", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B1A639;
L_B1A639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA639u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA639u, 6u, 3u, cpu.address("abs", 0xB4E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A639 JSR -> $B1B4E2 stack real
    { cpu.push16Value(hw,0xA63Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA63Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB4E2u), 0xB1A639u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A63C;
L_B1A63C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA63Cu,0xB1A63Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A63C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A63Cu);return;} hw.unresolvedReturn(0xB1A63Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B1A63D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Du, 6u, 3u, cpu.address("abs", 0xA77Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A63D JSR -> $B1A77C stack real
    { cpu.push16Value(hw,0xA63Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA640u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA77Cu), 0xB1A63Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A640;
L_B1A640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA640u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA640u,0xB1A640u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA640u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA640u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A640 BRA -> $B1A64A
    goto L_B1A64A;
L_B1A642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA642u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA642u, 6u, 3u, cpu.address("abs", 0x800Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A642 JSR -> $B1800E stack real
    { cpu.push16Value(hw,0xA644u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA645u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x800Eu), 0xB1A642u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A645;
L_B1A645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA645u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA645u,0xB1A645u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA645u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA645u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A645 BNE -> $B1A64A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B1A64A; }
    goto L_B1A647;
L_B1A647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA647u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA647u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA647u, 3u, 3u, cpu.address("abs", 0xA685u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A647 JMP -> $B1A685
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xA685u),0xB1A647u); return;
L_B1A64A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Au,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A64A PHX
    cpu.push("PHX", hw);
    goto L_B1A64B;
L_B1A64B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Bu, 4u + ((((0x1626u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A64B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1626u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A64E;
L_B1A64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A64E INC
    cpu.inc('A');
    goto L_B1A64F;
L_B1A64F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Fu, 5u, 3u, cpu.address("absy", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A64F STA
    hw.write(cpu.address("absy", 0x1626u), cpu.a, cpu.m8?8:16);
    goto L_B1A652;
L_B1A652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u, 4u + ((((0x1626u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A652 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x1626u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A655;
L_B1A655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA655u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA655u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A655 CPX
    cpu.compareX(0x8u);
    goto L_B1A657;
L_B1A657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA657u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA657u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA657u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A657 BCS -> $B1A65F
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0xB1A65Fu,0xB1A657u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA659u,0xB1A657u); return;
}

