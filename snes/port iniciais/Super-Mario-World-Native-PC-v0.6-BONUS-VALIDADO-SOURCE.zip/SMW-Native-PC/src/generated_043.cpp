#include "generated.hpp"
void sub_00816A_E0M1X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00816Au: goto L_00816A;
    case 0x00816Bu: goto L_00816B;
    case 0x00816Cu: goto L_00816C;
    case 0x00816Eu: goto L_00816E;
    case 0x00816Fu: goto L_00816F;
    case 0x008170u: goto L_008170;
    case 0x008171u: goto L_008171;
    case 0x008172u: goto L_008172;
    case 0x008173u: goto L_008173;
    case 0x008174u: goto L_008174;
    case 0x008176u: goto L_008176;
    case 0x008179u: goto L_008179;
    case 0x00817Cu: goto L_00817C;
    case 0x00817Eu: goto L_00817E;
    case 0x008181u: goto L_008181;
    case 0x008184u: goto L_008184;
    case 0x008186u: goto L_008186;
    case 0x008189u: goto L_008189;
    case 0x00818Cu: goto L_00818C;
    case 0x00818Fu: goto L_00818F;
    case 0x008192u: goto L_008192;
    case 0x008195u: goto L_008195;
    case 0x008198u: goto L_008198;
    case 0x00819Bu: goto L_00819B;
    case 0x00819Eu: goto L_00819E;
    case 0x0081A1u: goto L_0081A1;
    case 0x0081A4u: goto L_0081A4;
    case 0x0081A7u: goto L_0081A7;
    case 0x0081AAu: goto L_0081AA;
    case 0x0081ACu: goto L_0081AC;
    case 0x0081AFu: goto L_0081AF;
    case 0x0081B2u: goto L_0081B2;
    case 0x0081B4u: goto L_0081B4;
    case 0x0081B7u: goto L_0081B7;
    case 0x0081B9u: goto L_0081B9;
    case 0x0081BCu: goto L_0081BC;
    case 0x0081BEu: goto L_0081BE;
    case 0x0081C1u: goto L_0081C1;
    case 0x0081C3u: goto L_0081C3;
    case 0x0081C6u: goto L_0081C6;
    case 0x0081C9u: goto L_0081C9;
    case 0x0081CBu: goto L_0081CB;
    case 0x0081CEu: goto L_0081CE;
    case 0x0081D0u: goto L_0081D0;
    case 0x0081D2u: goto L_0081D2;
    case 0x0081D5u: goto L_0081D5;
    case 0x0081D7u: goto L_0081D7;
    case 0x0081DAu: goto L_0081DA;
    case 0x0081DCu: goto L_0081DC;
    case 0x0081DEu: goto L_0081DE;
    case 0x0081E1u: goto L_0081E1;
    case 0x0081E2u: goto L_0081E2;
    case 0x0081E4u: goto L_0081E4;
    case 0x0081E7u: goto L_0081E7;
    case 0x0081E9u: goto L_0081E9;
    case 0x0081ECu: goto L_0081EC;
    case 0x0081EFu: goto L_0081EF;
    case 0x0081F0u: goto L_0081F0;
    case 0x0081F2u: goto L_0081F2;
    case 0x0081F4u: goto L_0081F4;
    case 0x0081F7u: goto L_0081F7;
    case 0x0081FAu: goto L_0081FA;
    case 0x0081FCu: goto L_0081FC;
    case 0x0081FEu: goto L_0081FE;
    case 0x008201u: goto L_008201;
    case 0x008203u: goto L_008203;
    case 0x008207u: goto L_008207;
    case 0x008209u: goto L_008209;
    case 0x00820Du: goto L_00820D;
    case 0x008210u: goto L_008210;
    case 0x008212u: goto L_008212;
    case 0x008215u: goto L_008215;
    case 0x008217u: goto L_008217;
    case 0x00821Au: goto L_00821A;
    case 0x00821Du: goto L_00821D;
    case 0x008220u: goto L_008220;
    case 0x008222u: goto L_008222;
    case 0x008225u: goto L_008225;
    case 0x008227u: goto L_008227;
    case 0x008229u: goto L_008229;
    case 0x00822Cu: goto L_00822C;
    case 0x00822Du: goto L_00822D;
    case 0x00822Eu: goto L_00822E;
    case 0x008230u: goto L_008230;
    case 0x008232u: goto L_008232;
    case 0x008235u: goto L_008235;
    case 0x008237u: goto L_008237;
    case 0x00823Au: goto L_00823A;
    case 0x00823Du: goto L_00823D;
    case 0x008240u: goto L_008240;
    case 0x008243u: goto L_008243;
    case 0x008246u: goto L_008246;
    case 0x008248u: goto L_008248;
    case 0x00824Bu: goto L_00824B;
    case 0x00824Du: goto L_00824D;
    case 0x008250u: goto L_008250;
    case 0x008252u: goto L_008252;
    case 0x008253u: goto L_008253;
    case 0x008256u: goto L_008256;
    case 0x008259u: goto L_008259;
    case 0x00825Bu: goto L_00825B;
    case 0x00825Eu: goto L_00825E;
    case 0x008261u: goto L_008261;
    case 0x008263u: goto L_008263;
    case 0x008266u: goto L_008266;
    case 0x008268u: goto L_008268;
    case 0x00826Bu: goto L_00826B;
    case 0x00826Du: goto L_00826D;
    case 0x008270u: goto L_008270;
    case 0x008272u: goto L_008272;
    case 0x008275u: goto L_008275;
    case 0x008278u: goto L_008278;
    case 0x00827Au: goto L_00827A;
    case 0x00827Cu: goto L_00827C;
    case 0x00827Fu: goto L_00827F;
    case 0x008281u: goto L_008281;
    case 0x008283u: goto L_008283;
    case 0x008286u: goto L_008286;
    case 0x008289u: goto L_008289;
    case 0x00828Cu: goto L_00828C;
    case 0x00828Fu: goto L_00828F;
    case 0x008292u: goto L_008292;
    case 0x008294u: goto L_008294;
    case 0x008297u: goto L_008297;
    case 0x00829Au: goto L_00829A;
    case 0x00829Du: goto L_00829D;
    case 0x00829Fu: goto L_00829F;
    case 0x0082A1u: goto L_0082A1;
    case 0x0082A4u: goto L_0082A4;
    case 0x0082A7u: goto L_0082A7;
    case 0x0082AAu: goto L_0082AA;
    case 0x0082ADu: goto L_0082AD;
    case 0x0082B0u: goto L_0082B0;
    case 0x0082B3u: goto L_0082B3;
    case 0x0082B6u: goto L_0082B6;
    case 0x0082B9u: goto L_0082B9;
    case 0x0082BCu: goto L_0082BC;
    case 0x0082BEu: goto L_0082BE;
    case 0x0082BFu: goto L_0082BF;
    case 0x0082C0u: goto L_0082C0;
    case 0x0082C1u: goto L_0082C1;
    case 0x0082C2u: goto L_0082C2;
    case 0x0082C3u: goto L_0082C3;
    case 0x0082C4u: goto L_0082C4;
    case 0x0082C6u: goto L_0082C6;
    case 0x0082C8u: goto L_0082C8;
    case 0x0082CAu: goto L_0082CA;
    case 0x0082CDu: goto L_0082CD;
    case 0x0082CFu: goto L_0082CF;
    case 0x0082D2u: goto L_0082D2;
    case 0x0082D4u: goto L_0082D4;
    case 0x0082D7u: goto L_0082D7;
    case 0x0082DAu: goto L_0082DA;
    case 0x0082DDu: goto L_0082DD;
    case 0x0082DFu: goto L_0082DF;
    case 0x0082E2u: goto L_0082E2;
    case 0x0082E5u: goto L_0082E5;
    case 0x0082E6u: goto L_0082E6;
    case 0x0082E8u: goto L_0082E8;
    case 0x0082EBu: goto L_0082EB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00816A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Au,cpu,0x78u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00816A SEI
    cpu.setFlag('I', true);
    goto L_00816B;
L_00816B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Bu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00816B PHP
    cpu.push("PHP", hw);
    goto L_00816C;
L_00816C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00816C REP
    cpu.rep(0x30u);
    goto L_00816E;
L_00816E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Eu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00816E PHA
    cpu.push("PHA", hw);
    goto L_00816F;
L_00816F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Fu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00816F PHX
    cpu.push("PHX", hw);
    goto L_008170;
L_008170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8170u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8170u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008170 PHY
    cpu.push("PHY", hw);
    goto L_008171;
L_008171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8171u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8171u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008171 PHB
    cpu.push("PHB", hw);
    goto L_008172;
L_008172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8172u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8172u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008172 PHK
    cpu.push("PHK", hw);
    goto L_008173;
L_008173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8173u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8173u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008173 PLB
    cpu.pop("PLB", hw);
    goto L_008174;
L_008174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8174u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8174u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008174 SEP
    cpu.sep(0x30u);
    goto L_008176;
L_008176:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8176u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8176u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8176u, 4u, 3u, cpu.address("abs", 0x4210u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008176 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008179;
L_008179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8179u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8179u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008179 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DFBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00817C;
L_00817C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00817C BNE -> $008186
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008186; }
    goto L_00817E;
L_00817E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Eu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Eu, 4u, 3u, cpu.address("abs", 0x2142u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00817E LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x2142u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008181;
L_008181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8181u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8181u,cpu,0xCCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8181u, 4u, 3u, cpu.address("abs", 0x1DFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008181 CPY
    cpu.compareY(hw.readW(cpu.address("abs", 0x1DFFu), cpu.x8?8:16));
    goto L_008184;
L_008184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8184u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8184u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008184 BNE -> $00818F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00818F; }
    goto L_008186;
L_008186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8186u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8186u, 4u, 3u, cpu.address("abs", 0x2142u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008186 STA
    hw.write(cpu.address("abs", 0x2142u), cpu.a, cpu.m8?8:16);
    goto L_008189;
L_008189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8189u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8189u, 4u, 3u, cpu.address("abs", 0x1DFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008189 STA
    hw.write(cpu.address("abs", 0x1DFFu), cpu.a, cpu.m8?8:16);
    goto L_00818C;
L_00818C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Cu, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00818C STZ
    hw.write(cpu.address("abs", 0x1DFBu), 0, cpu.m8?8:16);
    goto L_00818F;
L_00818F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Fu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00818F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DF9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008192;
L_008192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8192u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8192u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008192 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_008195;
L_008195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8195u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8195u, 4u, 3u, cpu.address("abs", 0x1DFAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008195 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DFAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008198;
L_008198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8198u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8198u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008198 STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_00819B;
L_00819B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x819Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x819Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x819Bu, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00819B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DFCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00819E;
L_00819E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x819Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x819Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x819Eu, 4u, 3u, cpu.address("abs", 0x2143u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00819E STA
    hw.write(cpu.address("abs", 0x2143u), cpu.a, cpu.m8?8:16);
    goto L_0081A1;
L_0081A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A1u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081A1 STZ
    hw.write(cpu.address("abs", 0x1DF9u), 0, cpu.m8?8:16);
    goto L_0081A4;
L_0081A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A4u, 4u, 3u, cpu.address("abs", 0x1DFAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081A4 STZ
    hw.write(cpu.address("abs", 0x1DFAu), 0, cpu.m8?8:16);
    goto L_0081A7;
L_0081A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A7u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081A7 STZ
    hw.write(cpu.address("abs", 0x1DFCu), 0, cpu.m8?8:16);
    goto L_0081AA;
L_0081AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81AAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081AA LDA
    cpu.setA(0x80u, 8);
    goto L_0081AC;
L_0081AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81ACu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81ACu, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081AC STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_0081AF;
L_0081AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81AFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81AFu, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081AF STZ
    hw.write(cpu.address("abs", 0x420Cu), 0, cpu.m8?8:16);
    goto L_0081B2;
L_0081B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081B2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x41u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081B4;
L_0081B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B4u, 4u, 3u, cpu.address("abs", 0x2123u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081B4 STA
    hw.write(cpu.address("abs", 0x2123u), cpu.a, cpu.m8?8:16);
    goto L_0081B7;
L_0081B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081B7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081B9;
L_0081B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B9u, 4u, 3u, cpu.address("abs", 0x2124u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081B9 STA
    hw.write(cpu.address("abs", 0x2124u), cpu.a, cpu.m8?8:16);
    goto L_0081BC;
L_0081BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081BC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x43u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081BE;
L_0081BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BEu, 4u, 3u, cpu.address("abs", 0x2125u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081BE STA
    hw.write(cpu.address("abs", 0x2125u), cpu.a, cpu.m8?8:16);
    goto L_0081C1;
L_0081C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x44u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081C3;
L_0081C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C3u, 4u, 3u, cpu.address("abs", 0x2130u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081C3 STA
    hw.write(cpu.address("abs", 0x2130u), cpu.a, cpu.m8?8:16);
    goto L_0081C6;
L_0081C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C6u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081C6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081C9;
L_0081C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081C9 BPL -> $0081CE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0081CE; }
    goto L_0081CB;
L_0081CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CBu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CBu, 3u, 3u, cpu.address("abs", 0x82C4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081CB JMP -> $0082C4
    goto L_0082C4;
L_0081CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x40u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081CE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x40u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081D0;
L_0081D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081D0 AND
    cpu.logicAnd(0xFBu);
    goto L_0081D2;
L_0081D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D2u, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081D2 STA
    hw.write(cpu.address("abs", 0x2131u), cpu.a, cpu.m8?8:16);
    goto L_0081D5;
L_0081D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081D5 LDA
    cpu.setA(0x9u, 8);
    goto L_0081D7;
L_0081D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D7u, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081D7 STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_0081DA;
L_0081DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081DC;
L_0081DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081DC BEQ -> $0081E7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0081E7; }
    goto L_0081DE;
L_0081DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DEu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081DE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081E1;
L_0081E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081E1 LSR
    cpu.lsrA();
    goto L_0081E2;
L_0081E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081E2 BEQ -> $008246
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008246; }
    goto L_0081E4;
L_0081E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E4u, 3u, 3u, cpu.address("abs", 0x827Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081E4 JMP -> $00827A
    goto L_00827A;
L_0081E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081E7 INC
    cpu.incMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_0081E9;
L_0081E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E9u, 6u, 3u, cpu.address("abs", 0xA488u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0081E9 JSR -> $00A488 stack real
    { cpu.push16Value(hw,0x81EBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x81ECu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA488u), 0x0081E9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0081EC;
L_0081EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81ECu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x81ECu,0x0081ECu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81ECu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81ECu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081EC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081EF;
L_0081EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81EFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081EF LSR
    cpu.lsrA();
    goto L_0081F0;
L_0081F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081F0 BNE -> $008222
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008222; }
    goto L_0081F2;
L_0081F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081F2 BCS -> $0081F7
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_0081F7; }
    goto L_0081F4;
L_0081F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F4u, 6u, 3u, cpu.address("abs", 0x8DACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0081F4 JSR -> $008DAC stack real
    { cpu.push16Value(hw,0x81F6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x81F7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8DACu), 0x0081F4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0081F7;
L_0081F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x81F7u,0x0081F7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F7u, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081F7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081FA;
L_0081FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081FA CMP
    cpu.compareA(0x8u);
    goto L_0081FC;
L_0081FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081FC BNE -> $008209
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008209; }
    goto L_0081FE;
L_0081FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FEu, 4u, 3u, cpu.address("abs", 0x1FFEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FFEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008201;
L_008201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8201u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8201u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008201 BEQ -> $00821A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00821A; }
    goto L_008203;
L_008203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8203u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8203u, 8u, 4u, 0x0C9567u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $008203 JSL -> $0C9567 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8206u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8207u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0C9567u, 0x008203u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008207;
L_008207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8207u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8207u,0x008207u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8207u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8207u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008207 BRA -> $00821A
    goto L_00821A;
L_008209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8209u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8209u, 8u, 4u, 0x0087ADu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $008209 JSL -> $0087AD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x820Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x820Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0087ADu, 0x008209u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00820D;
L_00820D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x820Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x820Du,0x00820Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x820Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x820Du, 4u, 3u, cpu.address("abs", 0x143Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00820D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x143Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008210;
L_008210:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8210u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8210u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8210u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008210 BEQ -> $008217
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008217; }
    goto L_008212;
L_008212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8212u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8212u, 6u, 3u, cpu.address("abs", 0xA7C2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008212 JSR -> $00A7C2 stack real
    { cpu.push16Value(hw,0x8214u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8215u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA7C2u), 0x008212u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008215;
L_008215:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8215u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8215u,0x008215u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8215u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8215u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008215 BRA -> $00823D
    goto L_00823D;
L_008217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8217u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8217u, 6u, 3u, cpu.address("abs", 0xA390u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008217 JSR -> $00A390 stack real
    { cpu.push16Value(hw,0x8219u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x821Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA390u), 0x008217u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00821A;
L_00821A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x821Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x821Au,0x00821Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x821Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x821Au, 6u, 3u, cpu.address("abs", 0xA436u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00821A JSR -> $00A436 stack real
    { cpu.push16Value(hw,0x821Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x821Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA436u), 0x00821Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00821D;
L_00821D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x821Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x821Du,0x00821Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x821Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x821Du, 6u, 3u, cpu.address("abs", 0xA300u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00821D JSR -> $00A300 stack real
    { cpu.push16Value(hw,0x821Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8220u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA300u), 0x00821Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008220;
L_008220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8220u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8220u,0x008220u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8220u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8220u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008220 BRA -> $00823D
    goto L_00823D;
L_008222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8222u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8222u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008222 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13D9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008225;
L_008225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8225u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8225u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8225u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008225 CMP
    cpu.compareA(0xAu);
    goto L_008227;
L_008227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8227u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8227u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008227 BNE -> $008237
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008237; }
    goto L_008229;
L_008229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8229u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8229u, 4u, 3u, cpu.address("abs", 0x1DE8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008229 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1DE8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00822C;
L_00822C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00822C DEY
    cpu.decReg('Y');
    goto L_00822D;
L_00822D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00822D DEY
    cpu.decReg('Y');
    goto L_00822E;
L_00822E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00822E CPY
    cpu.compareY(0x4u);
    goto L_008230;
L_008230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8230u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8230u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008230 BCS -> $008237
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_008237; }
    goto L_008232;
L_008232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8232u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8232u, 6u, 3u, cpu.address("abs", 0xA529u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008232 JSR -> $00A529 stack real
    { cpu.push16Value(hw,0x8234u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8235u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA529u), 0x008232u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008235;
L_008235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8235u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8235u,0x008235u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8235u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8235u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008235 BRA -> $008243
    goto L_008243;
L_008237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8237u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8237u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8237u, 6u, 3u, cpu.address("abs", 0xA4E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008237 JSR -> $00A4E3 stack real
    { cpu.push16Value(hw,0x8239u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x823Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA4E3u), 0x008237u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00823A;
L_00823A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x823Au,0x00823Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Au, 6u, 3u, cpu.address("abs", 0xA300u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00823A JSR -> $00A300 stack real
    { cpu.push16Value(hw,0x823Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x823Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA300u), 0x00823Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00823D;
L_00823D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x823Du,0x00823Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Du, 6u, 3u, cpu.address("abs", 0x85D2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00823D JSR -> $0085D2 stack real
    { cpu.push16Value(hw,0x823Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8240u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85D2u), 0x00823Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008240;
L_008240:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8240u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8240u,0x008240u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8240u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8240u, 6u, 3u, cpu.address("abs", 0x8449u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008240 JSR -> $008449 stack real
    { cpu.push16Value(hw,0x8242u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8243u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8449u), 0x008240u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008243;
L_008243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8243u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8243u,0x008243u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8243u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8243u, 6u, 3u, cpu.address("abs", 0x8650u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008243 JSR -> $008650 stack real
    { cpu.push16Value(hw,0x8245u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8246u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8650u), 0x008243u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008246;
L_008246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8246u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8246u,0x008246u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8246u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8246u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008246 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008248;
L_008248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8248u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8248u, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008248 STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_00824B;
L_00824B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x824Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x824Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x824Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00824B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00824D;
L_00824D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x824Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x824Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x824Du, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00824D STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_008250;
L_008250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8250u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8250u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008250 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008252;
L_008252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8252u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8252u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008252 CLC
    cpu.setFlag('C', false);
    goto L_008253;
L_008253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8253u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8253u, 4u, 3u, cpu.address("abs", 0x1888u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008253 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1888u), cpu.m8?8:16));
    goto L_008256;
L_008256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8256u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8256u, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008256 STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_008259;
L_008259:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8259u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8259u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8259u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008259 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00825B;
L_00825B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x825Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x825Bu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x825Bu, 4u, 3u, cpu.address("abs", 0x1889u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00825B ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1889u), cpu.m8?8:16));
    goto L_00825E;
L_00825E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x825Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x825Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x825Eu, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00825E STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_008261;
L_008261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8261u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8261u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008261 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008263;
L_008263:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8263u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8263u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8263u, 4u, 3u, cpu.address("abs", 0x210Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008263 STA
    hw.write(cpu.address("abs", 0x210Fu), cpu.a, cpu.m8?8:16);
    goto L_008266;
L_008266:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8266u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8266u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8266u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008266 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008268;
L_008268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8268u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8268u, 4u, 3u, cpu.address("abs", 0x210Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008268 STA
    hw.write(cpu.address("abs", 0x210Fu), cpu.a, cpu.m8?8:16);
    goto L_00826B;
L_00826B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00826B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00826D;
L_00826D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x826Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x826Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x826Du, 4u, 3u, cpu.address("abs", 0x2110u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00826D STA
    hw.write(cpu.address("abs", 0x2110u), cpu.a, cpu.m8?8:16);
    goto L_008270;
L_008270:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8270u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8270u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8270u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x21u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008270 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x21u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008272;
L_008272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8272u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8272u, 4u, 3u, cpu.address("abs", 0x2110u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008272 STA
    hw.write(cpu.address("abs", 0x2110u), cpu.a, cpu.m8?8:16);
    goto L_008275;
L_008275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8275u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8275u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008275 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008278;
L_008278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8278u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8278u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008278 BEQ -> $008292
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008292; }
    goto L_00827A;
L_00827A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00827A LDA
    cpu.setA(0x81u, 8);
    goto L_00827C;
L_00827C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Cu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Cu, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00827C LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x13C6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00827F;
L_00827F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x827Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x827Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x827Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00827F CPY
    cpu.compareY(0x8u);
    goto L_008281;
L_008281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8281u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8281u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008281 BNE -> $0082A1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0082A1; }
    goto L_008283;
L_008283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8283u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8283u, 4u, 3u, cpu.address("abs", 0x0DAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008283 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0xDAEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008286;
L_008286:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8286u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8286u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8286u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008286 STY
    hw.write(cpu.address("abs", 0x2100u), cpu.y, cpu.x8?8:16);
    goto L_008289;
L_008289:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8289u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8289u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8289u, 4u, 3u, cpu.address("abs", 0x0D9Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008289 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0xD9Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00828C;
L_00828C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x828Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x828Cu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x828Cu, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00828C STY
    hw.write(cpu.address("abs", 0x420Cu), cpu.y, cpu.x8?8:16);
    goto L_00828F;
L_00828F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x828Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x828Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x828Fu, 3u, 3u, cpu.address("abs", 0x838Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00828F JMP -> $00838C
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x838Cu),0x00828Fu); return;
L_008292:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8292u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8292u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8292u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008292 LDY
    cpu.setY(0x24u, 8);
    goto L_008294;
L_008294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8294u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8294u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8294u, 4u, 3u, cpu.address("abs", 0x4211u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008294 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4211u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008297;
L_008297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8297u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8297u, 4u, 3u, cpu.address("abs", 0x4209u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008297 STY
    hw.write(cpu.address("abs", 0x4209u), cpu.y, cpu.x8?8:16);
    goto L_00829A;
L_00829A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Au, 4u, 3u, cpu.address("abs", 0x420Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00829A STZ
    hw.write(cpu.address("abs", 0x420Au), 0, cpu.m8?8:16);
    goto L_00829D;
L_00829D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00829D STZ
    hw.write(cpu.address("dp", 0x11u), 0, cpu.m8?8:16);
    goto L_00829F;
L_00829F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x829Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x829Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x829Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00829F LDA
    cpu.setA(0xA1u, 8);
    goto L_0082A1;
L_0082A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A1u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082A1 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_0082A4;
L_0082A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A4u, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082A4 STZ
    hw.write(cpu.address("abs", 0x2111u), 0, cpu.m8?8:16);
    goto L_0082A7;
L_0082A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A7u, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082A7 STZ
    hw.write(cpu.address("abs", 0x2111u), 0, cpu.m8?8:16);
    goto L_0082AA;
L_0082AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082AA STZ
    hw.write(cpu.address("abs", 0x2112u), 0, cpu.m8?8:16);
    goto L_0082AD;
L_0082AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82ADu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82ADu, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082AD STZ
    hw.write(cpu.address("abs", 0x2112u), 0, cpu.m8?8:16);
    goto L_0082B0;
L_0082B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u, 4u, 3u, cpu.address("abs", 0x0DAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082B0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDAEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0082B3;
L_0082B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B3u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082B3 STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_0082B6;
L_0082B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B6u, 4u, 3u, cpu.address("abs", 0x0D9Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082B6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0082B9;
L_0082B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B9u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082B9 STA
    hw.write(cpu.address("abs", 0x420Cu), cpu.a, cpu.m8?8:16);
    goto L_0082BC;
L_0082BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BCu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082BC REP
    cpu.rep(0x30u);
    goto L_0082BE;
L_0082BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BEu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0082BE PLB
    cpu.pop("PLB", hw);
    goto L_0082BF;
L_0082BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BFu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BFu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082BF PLY
    cpu.pop("PLY", hw);
    goto L_0082C0;
L_0082C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C0u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082C0 PLX
    cpu.pop("PLX", hw);
    goto L_0082C1;
L_0082C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C1u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C1u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082C1 PLA
    cpu.pop("PLA", hw);
    goto L_0082C2;
L_0082C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C2u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0082C2 PLP
    cpu.pop("PLP", hw);
    goto L_0082C3;
L_0082C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82C3u,0x0082C3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0082C3 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x0082C3u);return;}
L_0082C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082C4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0082C6;
L_0082C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082C6 BNE -> $0082F7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x0082F7u,0x0082C6u); return; }
    goto L_0082C8;
L_0082C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C8u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082C8 INC
    cpu.incMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_0082CA;
L_0082CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CAu, 4u, 3u, cpu.address("abs", 0x143Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082CA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x143Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0082CD;
L_0082CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082CD BEQ -> $0082D4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0082D4; }
    goto L_0082CF;
L_0082CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CFu, 6u, 3u, cpu.address("abs", 0xA7C2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082CF JSR -> $00A7C2 stack real
    { cpu.push16Value(hw,0x82D1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82D2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA7C2u), 0x0082CFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082D2;
L_0082D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82D2u,0x0082D2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082D2 BRA -> $0082E8
    goto L_0082E8;
L_0082D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D4u, 6u, 3u, cpu.address("abs", 0xA436u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082D4 JSR -> $00A436 stack real
    { cpu.push16Value(hw,0x82D6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82D7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA436u), 0x0082D4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082D7;
L_0082D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82D7u,0x0082D7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D7u, 6u, 3u, cpu.address("abs", 0xA300u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082D7 JSR -> $00A300 stack real
    { cpu.push16Value(hw,0x82D9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82DAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA300u), 0x0082D7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082DA;
L_0082DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82DAu,0x0082DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DAu,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DAu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082DA BIT
    cpu.bit(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), false);
    goto L_0082DD;
L_0082DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DDu,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082DD BVC -> $0082E8
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_0082E8; }
    goto L_0082DF;
L_0082DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DFu, 6u, 3u, cpu.address("abs", 0x98A9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082DF JSR -> $0098A9 stack real
    { cpu.push16Value(hw,0x82E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82E2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x98A9u), 0x0082DFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082E2;
L_0082E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82E2u,0x0082E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E2u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082E2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0082E5;
L_0082E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082E5 LSR
    cpu.lsrA();
    goto L_0082E6;
L_0082E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0082E6 BCS -> $0082EB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_0082EB; }
    goto L_0082E8;
L_0082E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E8u, 6u, 3u, cpu.address("abs", 0x8DACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082E8 JSR -> $008DAC stack real
    { cpu.push16Value(hw,0x82EAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82EBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8DACu), 0x0082E8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0082EB;
L_0082EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82EBu,0x0082EBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu, 6u, 3u, cpu.address("abs", 0xA488u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0082EB JSR -> $00A488 stack real
    { cpu.push16Value(hw,0x82EDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x82EEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA488u), 0x0082EBu); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x82EEu,0x0082EBu); return;
}

void sub_0092B2_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0092B2u: goto L_0092B2;
    case 0x0092B4u: goto L_0092B4;
    case 0x0092B7u: goto L_0092B7;
    case 0x0092BAu: goto L_0092BA;
    case 0x0092BDu: goto L_0092BD;
    case 0x0092C0u: goto L_0092C0;
    case 0x0092C3u: goto L_0092C3;
    case 0x0092C6u: goto L_0092C6;
    case 0x0092C8u: goto L_0092C8;
    case 0x0092CBu: goto L_0092CB;
    case 0x0092CEu: goto L_0092CE;
    case 0x0092D1u: goto L_0092D1;
    case 0x0092D4u: goto L_0092D4;
    case 0x0092D7u: goto L_0092D7;
    case 0x0092DAu: goto L_0092DA;
    case 0x0092DBu: goto L_0092DB;
    case 0x0092DDu: goto L_0092DD;
    case 0x0092DFu: goto L_0092DF;
    case 0x0092E2u: goto L_0092E2;
    case 0x0092E5u: goto L_0092E5;
    case 0x0092E8u: goto L_0092E8;
    case 0x0092EAu: goto L_0092EA;
    case 0x0092EDu: goto L_0092ED;
    case 0x0092EFu: goto L_0092EF;
    case 0x0092F2u: goto L_0092F2;
    case 0x0092F5u: goto L_0092F5;
    case 0x0092F8u: goto L_0092F8;
    case 0x0092FBu: goto L_0092FB;
    case 0x0092FEu: goto L_0092FE;
    case 0x009301u: goto L_009301;
    case 0x009304u: goto L_009304;
    case 0x009305u: goto L_009305;
    case 0x009306u: goto L_009306;
    case 0x009309u: goto L_009309;
    case 0x00930Au: goto L_00930A;
    case 0x00930Bu: goto L_00930B;
    case 0x00930Cu: goto L_00930C;
    case 0x00930Du: goto L_00930D;
    case 0x00930Eu: goto L_00930E;
    case 0x009310u: goto L_009310;
    case 0x009312u: goto L_009312;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0092B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092B2 LDA
    cpu.setA(0x58u, 8);
    goto L_0092B4;
L_0092B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B4u, 4u, 3u, cpu.address("abs", 0x04A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092B4 STA
    hw.write(cpu.address("abs", 0x4A0u), cpu.a, cpu.m8?8:16);
    goto L_0092B7;
L_0092B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92B7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92B7u, 4u, 3u, cpu.address("abs", 0x04AAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092B7 STA
    hw.write(cpu.address("abs", 0x4AAu), cpu.a, cpu.m8?8:16);
    goto L_0092BA;
L_0092BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92BAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92BAu, 4u, 3u, cpu.address("abs", 0x04B4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092BA STA
    hw.write(cpu.address("abs", 0x4B4u), cpu.a, cpu.m8?8:16);
    goto L_0092BD;
L_0092BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92BDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92BDu, 4u, 3u, cpu.address("abs", 0x04A9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092BD STZ
    hw.write(cpu.address("abs", 0x4A9u), 0, cpu.m8?8:16);
    goto L_0092C0;
L_0092C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C0u, 4u, 3u, cpu.address("abs", 0x04B3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092C0 STZ
    hw.write(cpu.address("abs", 0x4B3u), 0, cpu.m8?8:16);
    goto L_0092C3;
L_0092C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C3u, 4u, 3u, cpu.address("abs", 0x04BDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092C3 STZ
    hw.write(cpu.address("abs", 0x4BDu), 0, cpu.m8?8:16);
    goto L_0092C6;
L_0092C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092C6 LDX
    cpu.setX(0x4u, 8);
    goto L_0092C8;
L_0092C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92C8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92C8u, 4u + ((((0x9313u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9313u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092C8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9313u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0092CB;
L_0092CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92CBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92CBu, 5u, 3u, cpu.address("absx", 0x4350u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092CB STA
    hw.write(cpu.address("absx", 0x4350u), cpu.a, cpu.m8?8:16);
    goto L_0092CE;
L_0092CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92CEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92CEu, 4u + ((((0x9318u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9318u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092CE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9318u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0092D1;
L_0092D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D1u, 5u, 3u, cpu.address("absx", 0x4360u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092D1 STA
    hw.write(cpu.address("absx", 0x4360u), cpu.a, cpu.m8?8:16);
    goto L_0092D4;
L_0092D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D4u, 4u + ((((0x931Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x931Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092D4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x931Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0092D7;
L_0092D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D7u, 5u, 3u, cpu.address("absx", 0x4370u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092D7 STA
    hw.write(cpu.address("absx", 0x4370u), cpu.a, cpu.m8?8:16);
    goto L_0092DA;
L_0092DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92DAu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092DA DEX
    cpu.decReg('X');
    goto L_0092DB;
L_0092DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92DBu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092DB BPL -> $0092C8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0092C8; }
    goto L_0092DD;
L_0092DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92DDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092DD LDA
    cpu.setA(0x0u, 8);
    goto L_0092DF;
L_0092DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92DFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92DFu, 4u, 3u, cpu.address("abs", 0x4357u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092DF STA
    hw.write(cpu.address("abs", 0x4357u), cpu.a, cpu.m8?8:16);
    goto L_0092E2;
L_0092E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E2u, 4u, 3u, cpu.address("abs", 0x4367u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092E2 STA
    hw.write(cpu.address("abs", 0x4367u), cpu.a, cpu.m8?8:16);
    goto L_0092E5;
L_0092E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E5u, 4u, 3u, cpu.address("abs", 0x4377u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092E5 STA
    hw.write(cpu.address("abs", 0x4377u), cpu.a, cpu.m8?8:16);
    goto L_0092E8;
L_0092E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092E8 LDA
    cpu.setA(0xE0u, 8);
    goto L_0092EA;
L_0092EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92EAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92EAu, 4u, 3u, cpu.address("abs", 0x0D9Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092EA STA
    hw.write(cpu.address("abs", 0xD9Fu), cpu.a, cpu.m8?8:16);
    goto L_0092ED;
L_0092ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92EDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92EDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092ED REP
    cpu.rep(0x30u);
    goto L_0092EF;
L_0092EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92EFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092EF LDY
    cpu.setY(0x8u, 16);
    goto L_0092F2;
L_0092F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092F2 LDX
    cpu.setX(0x14u, 16);
    goto L_0092F5;
L_0092F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F5u, 5u + 1u, 3u, cpu.address("absy", 0x001Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092F5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0092F8;
L_0092F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F8u, 6u, 3u, cpu.address("absx", 0x04A1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092F8 STA
    hw.write(cpu.address("absx", 0x4A1u), cpu.a, cpu.m8?8:16);
    goto L_0092FB;
L_0092FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FBu, 6u, 3u, cpu.address("absx", 0x04A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092FB STA
    hw.write(cpu.address("absx", 0x4A4u), cpu.a, cpu.m8?8:16);
    goto L_0092FE;
L_0092FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FEu, 5u + 1u, 3u, cpu.address("absy", 0x1462u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092FE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1462u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009301;
L_009301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9301u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9301u, 6u, 3u, cpu.address("absx", 0x04A7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009301 STA
    hw.write(cpu.address("absx", 0x4A7u), cpu.a, cpu.m8?8:16);
    goto L_009304;
L_009304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9304u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9304u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9304u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009304 TXA
    cpu.transfer("TXA");
    goto L_009305;
L_009305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009305 SEC
    cpu.setFlag('C', true);
    goto L_009306;
L_009306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9306u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9306u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009306 SBC
    cpu.sbc(0xAu);
    goto L_009309;
L_009309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9309u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9309u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009309 TAX
    cpu.transfer("TAX");
    goto L_00930A;
L_00930A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00930A DEY
    cpu.decReg('Y');
    goto L_00930B;
L_00930B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00930B DEY
    cpu.decReg('Y');
    goto L_00930C;
L_00930C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00930C DEY
    cpu.decReg('Y');
    goto L_00930D;
L_00930D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00930D DEY
    cpu.decReg('Y');
    goto L_00930E;
L_00930E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00930E BPL -> $0092F5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0092F5; }
    goto L_009310;
L_009310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9310u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9310u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009310 SEP
    cpu.sep(0x30u);
    goto L_009312;
L_009312:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9312u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9312u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9312u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009312 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009312u);return;} hw.unresolvedReturn(0x009312u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00DC2D_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00DC2Du: goto L_00DC2D;
    case 0x00DC2Fu: goto L_00DC2F;
    case 0x00DC31u: goto L_00DC31;
    case 0x00DC34u: goto L_00DC34;
    case 0x00DC36u: goto L_00DC36;
    case 0x00DC37u: goto L_00DC37;
    case 0x00DC39u: goto L_00DC39;
    case 0x00DC3Bu: goto L_00DC3B;
    case 0x00DC3Du: goto L_00DC3D;
    case 0x00DC3Eu: goto L_00DC3E;
    case 0x00DC40u: goto L_00DC40;
    case 0x00DC42u: goto L_00DC42;
    case 0x00DC45u: goto L_00DC45;
    case 0x00DC47u: goto L_00DC47;
    case 0x00DC4Au: goto L_00DC4A;
    case 0x00DC4Cu: goto L_00DC4C;
    case 0x00DC4Eu: goto L_00DC4E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00DC2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC2F;
L_00DC2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC2F STA
    hw.write(cpu.address("dp", 0x8Au), cpu.a, cpu.m8?8:16);
    goto L_00DC31;
L_00DC31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC31u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC31u, 4u, 3u, cpu.address("abs", 0x13E3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC31 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13E3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC34;
L_00DC34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC34u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC34u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC34 BEQ -> $00DC40
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00DC40; }
    goto L_00DC36;
L_00DC36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC36u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC36u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC36 LSR
    cpu.lsrA();
    goto L_00DC37;
L_00DC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC37u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC37u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC37 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC39;
L_00DC39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC39u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC39 BCC -> $00DC3E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00DC3E; }
    goto L_00DC3B;
L_00DC3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC3B EOR
    cpu.logicXor(0xFFu);
    goto L_00DC3D;
L_00DC3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC3D INC
    cpu.inc('A');
    goto L_00DC3E;
L_00DC3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC3E STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00DC40;
L_00DC40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC40u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC40 LDX
    cpu.setX(0x0u, 8);
    goto L_00DC42;
L_00DC42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC42u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC42u, 6u, 3u, cpu.address("abs", 0xDC4Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC42 JSR -> $00DC4F stack real
    { cpu.push16Value(hw,0xDC44u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC45u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDC4Fu), 0x00DC42u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00DC45;
L_00DC45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC45u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC45u,0x00DC45u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC45u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC45u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC45 LDX
    cpu.setX(0x2u, 8);
    goto L_00DC47;
L_00DC47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC47u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC47u, 6u, 3u, cpu.address("abs", 0xDC4Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC47 JSR -> $00DC4F stack real
    { cpu.push16Value(hw,0xDC49u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC4Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDC4Fu), 0x00DC47u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00DC4A;
L_00DC4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Au))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC4Au,0x00DC4Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC4A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC4C;
L_00DC4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC4C STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00DC4E;
L_00DC4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC4E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DC4Eu);return;} hw.unresolvedReturn(0x00DC4Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00ECB1_E0M1X1C1_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00ECB1u: goto L_00ECB1;
    case 0x00ECB3u: goto L_00ECB3;
    case 0x00ECB5u: goto L_00ECB5;
    case 0x00ECB7u: goto L_00ECB7;
    case 0x00ECB9u: goto L_00ECB9;
    case 0x00ECBBu: goto L_00ECBB;
    case 0x00ECBDu: goto L_00ECBD;
    case 0x00ECBFu: goto L_00ECBF;
    case 0x00ECC1u: goto L_00ECC1;
    case 0x00ECC2u: goto L_00ECC2;
    case 0x00ECC5u: goto L_00ECC5;
    case 0x00ECC7u: goto L_00ECC7;
    case 0x00ECCAu: goto L_00ECCA;
    case 0x00ECCCu: goto L_00ECCC;
    case 0x00ECCEu: goto L_00ECCE;
    case 0x00ECD0u: goto L_00ECD0;
    case 0x00ECD2u: goto L_00ECD2;
    case 0x00ECD4u: goto L_00ECD4;
    case 0x00ECD6u: goto L_00ECD6;
    case 0x00ECD8u: goto L_00ECD8;
    case 0x00ECDAu: goto L_00ECDA;
    case 0x00ECDBu: goto L_00ECDB;
    case 0x00ECDCu: goto L_00ECDC;
    case 0x00ECDEu: goto L_00ECDE;
    case 0x00ECDFu: goto L_00ECDF;
    case 0x00ECE1u: goto L_00ECE1;
    case 0x00ECE3u: goto L_00ECE3;
    case 0x00ECE6u: goto L_00ECE6;
    case 0x00ECE7u: goto L_00ECE7;
    case 0x00ECE8u: goto L_00ECE8;
    case 0x00ECE9u: goto L_00ECE9;
    case 0x00ECEAu: goto L_00ECEA;
    case 0x00ECECu: goto L_00ECEC;
    case 0x00ECEEu: goto L_00ECEE;
    case 0x00ECF0u: goto L_00ECF0;
    case 0x00ECF1u: goto L_00ECF1;
    case 0x00ECF4u: goto L_00ECF4;
    case 0x00ECF6u: goto L_00ECF6;
    case 0x00ECF8u: goto L_00ECF8;
    case 0x00ECFAu: goto L_00ECFA;
    case 0x00ECFCu: goto L_00ECFC;
    case 0x00ECFFu: goto L_00ECFF;
    case 0x00ED00u: goto L_00ED00;
    case 0x00ED02u: goto L_00ED02;
    case 0x00ED06u: goto L_00ED06;
    case 0x00ED09u: goto L_00ED09;
    case 0x00ED0Bu: goto L_00ED0B;
    case 0x00ED0Du: goto L_00ED0D;
    case 0x00ED0Fu: goto L_00ED0F;
    case 0x00ED10u: goto L_00ED10;
    case 0x00ED12u: goto L_00ED12;
    case 0x00ED14u: goto L_00ED14;
    case 0x00ED16u: goto L_00ED16;
    case 0x00ED18u: goto L_00ED18;
    case 0x00ED1Au: goto L_00ED1A;
    case 0x00ED1Cu: goto L_00ED1C;
    case 0x00ED1Eu: goto L_00ED1E;
    case 0x00ED20u: goto L_00ED20;
    case 0x00ED22u: goto L_00ED22;
    case 0x00ED24u: goto L_00ED24;
    case 0x00ED26u: goto L_00ED26;
    case 0x00ED28u: goto L_00ED28;
    case 0x00ED2Au: goto L_00ED2A;
    case 0x00ED2Cu: goto L_00ED2C;
    case 0x00ED2Eu: goto L_00ED2E;
    case 0x00ED2Fu: goto L_00ED2F;
    case 0x00ED31u: goto L_00ED31;
    case 0x00ED33u: goto L_00ED33;
    case 0x00ED35u: goto L_00ED35;
    case 0x00ED37u: goto L_00ED37;
    case 0x00ED39u: goto L_00ED39;
    case 0x00ED3Bu: goto L_00ED3B;
    case 0x00ED3Du: goto L_00ED3D;
    case 0x00ED3Fu: goto L_00ED3F;
    case 0x00ED41u: goto L_00ED41;
    case 0x00ED44u: goto L_00ED44;
    case 0x00ED46u: goto L_00ED46;
    case 0x00ED47u: goto L_00ED47;
    case 0x00ED76u: goto L_00ED76;
    case 0x00ED78u: goto L_00ED78;
    case 0x00ED7Au: goto L_00ED7A;
    case 0x00ED7Cu: goto L_00ED7C;
    case 0x00ED7Eu: goto L_00ED7E;
    case 0x00ED80u: goto L_00ED80;
    case 0x00ED82u: goto L_00ED82;
    case 0x00ED84u: goto L_00ED84;
    case 0x00ED86u: goto L_00ED86;
    case 0x00ED89u: goto L_00ED89;
    case 0x00ED8Bu: goto L_00ED8B;
    case 0x00ED8Du: goto L_00ED8D;
    case 0x00ED8Fu: goto L_00ED8F;
    case 0x00ED91u: goto L_00ED91;
    case 0x00ED93u: goto L_00ED93;
    case 0x00ED95u: goto L_00ED95;
    case 0x00ED96u: goto L_00ED96;
    case 0x00ED97u: goto L_00ED97;
    case 0x00ED99u: goto L_00ED99;
    case 0x00ED9Au: goto L_00ED9A;
    case 0x00ED9Cu: goto L_00ED9C;
    case 0x00ED9Du: goto L_00ED9D;
    case 0x00ED9Fu: goto L_00ED9F;
    case 0x00EDA2u: goto L_00EDA2;
    case 0x00EDA3u: goto L_00EDA3;
    case 0x00EDA4u: goto L_00EDA4;
    case 0x00EDA5u: goto L_00EDA5;
    case 0x00EDA6u: goto L_00EDA6;
    case 0x00EDA8u: goto L_00EDA8;
    case 0x00EDAAu: goto L_00EDAA;
    case 0x00EDABu: goto L_00EDAB;
    case 0x00EDADu: goto L_00EDAD;
    case 0x00EDAEu: goto L_00EDAE;
    case 0x00EDB0u: goto L_00EDB0;
    case 0x00EDB1u: goto L_00EDB1;
    case 0x00EDB4u: goto L_00EDB4;
    case 0x00EDB6u: goto L_00EDB6;
    case 0x00EDB9u: goto L_00EDB9;
    case 0x00EDBBu: goto L_00EDBB;
    case 0x00EDBCu: goto L_00EDBC;
    case 0x00EDBDu: goto L_00EDBD;
    case 0x00EDC0u: goto L_00EDC0;
    case 0x00EDC2u: goto L_00EDC2;
    case 0x00EDC4u: goto L_00EDC4;
    case 0x00EDC6u: goto L_00EDC6;
    case 0x00EDC9u: goto L_00EDC9;
    case 0x00EDCBu: goto L_00EDCB;
    case 0x00EDCDu: goto L_00EDCD;
    case 0x00EDCFu: goto L_00EDCF;
    case 0x00EDD2u: goto L_00EDD2;
    case 0x00EDD5u: goto L_00EDD5;
    case 0x00EDD8u: goto L_00EDD8;
    case 0x00EE1Du: goto L_00EE1D;
    case 0x00EE20u: goto L_00EE20;
    case 0x00EE22u: goto L_00EE22;
    case 0x00EE24u: goto L_00EE24;
    case 0x00EE26u: goto L_00EE26;
    case 0x00EE28u: goto L_00EE28;
    case 0x00EE2Au: goto L_00EE2A;
    case 0x00EE2Du: goto L_00EE2D;
    case 0x00EE2Fu: goto L_00EE2F;
    case 0x00EE31u: goto L_00EE31;
    case 0x00EE33u: goto L_00EE33;
    case 0x00EE35u: goto L_00EE35;
    case 0x00EE37u: goto L_00EE37;
    case 0x00EE39u: goto L_00EE39;
    case 0x00EE76u: goto L_00EE76;
    case 0x00EE83u: goto L_00EE83;
    case 0x00EE85u: goto L_00EE85;
    case 0x00EE87u: goto L_00EE87;
    case 0x00EE89u: goto L_00EE89;
    case 0x00EE8Bu: goto L_00EE8B;
    case 0x00EE8Fu: goto L_00EE8F;
    case 0x00EE92u: goto L_00EE92;
    case 0x00EE94u: goto L_00EE94;
    case 0x00EE95u: goto L_00EE95;
    case 0x00EE96u: goto L_00EE96;
    case 0x00EE98u: goto L_00EE98;
    case 0x00EE9Au: goto L_00EE9A;
    case 0x00EEAAu: goto L_00EEAA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00ECB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECB1u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECB1 CPY
    cpu.compareY(0x11u);
    goto L_00ECB3;
L_00ECB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECB3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECB3 BCC -> $00ECA3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ECA3u,0x00ECB3u); return; }
    goto L_00ECB5;
L_00ECB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECB5u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECB5 CPY
    cpu.compareY(0x6Eu);
    goto L_00ECB7;
L_00ECB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECB7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECB7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECB7 BCC -> $00ECFA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00ECFA; }
    goto L_00ECB9;
L_00ECB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECB9u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECB9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECB9 CPY
    cpu.compareY(0xD8u);
    goto L_00ECBB;
L_00ECBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECBBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECBBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECBB BCC -> $00ECDA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00ECDA; }
    goto L_00ECBD;
L_00ECBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECBDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECBDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECBD REP
    cpu.rep(0x20u);
    goto L_00ECBF;
L_00ECBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECBFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECBFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECBF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ECC1;
L_00ECC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECC1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECC1 CLC
    cpu.setFlag('C', false);
    goto L_00ECC2;
L_00ECC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECC2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECC2 ADC
    cpu.adc(0x10u);
    goto L_00ECC5;
L_00ECC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECC5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECC5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECC5 STA
    hw.write(cpu.address("dp", 0x98u), cpu.a, cpu.m8?8:16);
    goto L_00ECC7;
L_00ECC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECC7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECC7u, 6u, 3u, cpu.address("abs", 0xF461u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ECC7 JSR -> $00F461 stack real
    { cpu.push16Value(hw,0xECC9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xECCAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF461u), 0x00ECC7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00ECCA;
L_00ECCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECCAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xECCAu,0x00ECCAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECCAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECCAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECCA BEQ -> $00ECF8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00ECF8; }
    goto L_00ECCC;
L_00ECCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECCCu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECCC CPY
    cpu.compareY(0x6Eu);
    goto L_00ECCE;
L_00ECCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECCEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECCE BCC -> $00ED4A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ED4Au,0x00ECCEu); return; }
    goto L_00ECD0;
L_00ECD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECD0u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECD0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECD0 CPY
    cpu.compareY(0xD8u);
    goto L_00ECD2;
L_00ECD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECD2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECD2 BCS -> $00ED4A
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ED4Au,0x00ECD2u); return; }
    goto L_00ECD4;
L_00ECD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECD4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECD4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECD4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ECD6;
L_00ECD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECD6u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECD6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECD6 SBC
    cpu.sbc(0xFu);
    goto L_00ECD8;
L_00ECD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECD8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECD8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECD8 STA
    hw.write(cpu.address("dp", 0x91u), cpu.a, cpu.m8?8:16);
    goto L_00ECDA;
L_00ECDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECDAu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECDA TYA
    cpu.transfer("TYA");
    goto L_00ECDB;
L_00ECDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECDBu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECDB SEC
    cpu.setFlag('C', true);
    goto L_00ECDC;
L_00ECDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECDCu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECDC SBC
    cpu.sbc(0x6Eu);
    goto L_00ECDE;
L_00ECDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECDEu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECDEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECDE TAY
    cpu.transfer("TAY");
    goto L_00ECDF;
L_00ECDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECDFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECDFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECDF REP
    cpu.rep(0x20u);
    goto L_00ECE1;
L_00ECE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECE1u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECE1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x82u) & 0xFFFFu), 3u, 0u);
    // $00ECE1 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ECE3;
L_00ECE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECE3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECE3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECE3 AND
    cpu.logicAnd(0xFFu);
    goto L_00ECE6;
L_00ECE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECE6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECE6 ASL
    cpu.aslA();
    goto L_00ECE7;
L_00ECE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECE7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECE7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECE7 ASL
    cpu.aslA();
    goto L_00ECE8;
L_00ECE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECE8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECE8 ASL
    cpu.aslA();
    goto L_00ECE9;
L_00ECE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECE9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECE9 ASL
    cpu.aslA();
    goto L_00ECEA;
L_00ECEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECEAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECEAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECEA SEP
    cpu.sep(0x20u);
    goto L_00ECEC;
L_00ECEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECECu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECEC ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x92u), cpu.m8?8:16));
    goto L_00ECEE;
L_00ECEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECEEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECEEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECEE REP
    cpu.rep(0x10u);
    goto L_00ECF0;
L_00ECF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECF0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECF0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECF0 TAY
    cpu.transfer("TAY");
    goto L_00ECF1;
L_00ECF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECF1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECF1u, 4u + 1u, 3u, cpu.address("absy", 0xE632u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECF1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE632u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ECF4;
L_00ECF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECF4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECF4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECF4 SEP
    cpu.sep(0x10u);
    goto L_00ECF6;
L_00ECF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECF6u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECF6 BMI -> $00ED0F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00ED0F; }
    goto L_00ECF8;
L_00ECF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECF8u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECF8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECF8 BRA -> $00ED4A
    hw.requestDispatch(0x00ED4Au,0x00ECF8u); return;
L_00ECFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECFAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECFA LDA
    cpu.setA(0x2u, 8);
    goto L_00ECFC;
L_00ECFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECFCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECFCu, 6u, 3u, cpu.address("abs", 0xF3E9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ECFC JSR -> $00F3E9 stack real
    { cpu.push16Value(hw,0xECFEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xECFFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF3E9u), 0x00ECFCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00ECFF;
L_00ECFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECFFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xECFFu,0x00ECFFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECFFu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECFFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECFF TYA
    cpu.transfer("TYA");
    goto L_00ED00;
L_00ED00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED00u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED00 LDY
    cpu.setY(0x0u, 8);
    goto L_00ED02;
L_00ED02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED02u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED02u, 8u, 4u, 0x00F127u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00ED02 JSL -> $00F127 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xED05u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xED06u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F127u, 0x00ED02u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00ED06;
L_00ED06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED06u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED06u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED06u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED06 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED09;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED06u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED06u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED06 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED09;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED06u,0x00ED06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED09u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED09u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED09 CMP
    cpu.compareA(0x1Eu);
    goto L_00ED0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED09u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED09 CMP
    cpu.compareA(0x1Eu);
    goto L_00ED0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED09u,0x00ED09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED0B BEQ -> $00ED3B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00ED3B; }
    goto L_00ED0D;
L_00ED0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED0D LDA
    cpu.setA(0xF0u, 8);
    goto L_00ED0F;
L_00ED0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED0F CLC
    cpu.setFlag('C', false);
    goto L_00ED10;
L_00ED10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED10u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED10u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED10 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00ED12;
L_00ED12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED12u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED12 BPL -> $00ED4A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ED4Au,0x00ED12u); return; }
    goto L_00ED14;
L_00ED14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED14u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED14u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED14 CMP
    cpu.compareA(0xF9u);
    goto L_00ED16;
L_00ED16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED16u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED16 BCS -> $00ED28
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00ED28; }
    goto L_00ED18;
L_00ED18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED18u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED18u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED18 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x72u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00ED1A;
L_00ED1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED1A BNE -> $00ED28
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00ED28; }
    goto L_00ED1C;
L_00ED1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED1C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED1E;
L_00ED1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED1E AND
    cpu.logicAnd(0xFCu);
    goto L_00ED20;
L_00ED20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED20u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED20 ORA
    cpu.logicOr(0x9u);
    goto L_00ED22;
L_00ED22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED22u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED22u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED22 STA
    hw.write(cpu.address("dp", 0x77u), cpu.a, cpu.m8?8:16);
    goto L_00ED24;
L_00ED24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED24u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED24u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED24 STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00ED26;
L_00ED26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED26u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED26u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED26 BRA -> $00ED3B
    goto L_00ED3B;
L_00ED28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED28u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED28u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED28 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x72u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00ED2A;
L_00ED2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED2A BEQ -> $00ED37
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00ED37; }
    goto L_00ED2C;
L_00ED2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Cu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED2C EOR
    cpu.logicXor(0xFFu);
    goto L_00ED2E;
L_00ED2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED2E CLC
    cpu.setFlag('C', false);
    goto L_00ED2F;
L_00ED2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Fu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED2F ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16));
    goto L_00ED31;
L_00ED31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED31u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED31u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED31 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00ED33;
L_00ED33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED33u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED33 BCC -> $00ED37
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00ED37; }
    goto L_00ED35;
L_00ED35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED35u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED35u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED35 INC
    cpu.incMem(hw, cpu.address("dp", 0x97u), cpu.m8?8:16);
    goto L_00ED37;
L_00ED37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED37u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED37 LDA
    cpu.setA(0x8u, 8);
    goto L_00ED39;
L_00ED39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED39u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED39u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED39 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00ED3B;
L_00ED3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED3Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED3B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED3D;
L_00ED3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED3Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED3D BPL -> $00ED4A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ED4Au,0x00ED3Du); return; }
    goto L_00ED3F;
L_00ED3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED3Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED3Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED3F STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    goto L_00ED41;
L_00ED41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED41u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED41u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED41 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DF9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED44;
L_00ED44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED44u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED44 BNE -> $00ED4A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ED4Au,0x00ED44u); return; }
    goto L_00ED46;
L_00ED46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED46u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED46 INC
    cpu.inc('A');
    goto L_00ED47;
L_00ED47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED47u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED47u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED47 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED4Au,0x00ED47u); return;
L_00ED76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED76u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED76u,0x00ED76u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED76u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED76 BEQ -> $00EDE9
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED76u); return; }
    goto L_00ED78;
L_00ED78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED78u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED78 CPY
    cpu.compareY(0x6Eu);
    goto L_00ED7A;
L_00ED7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED7A BCC -> $00EDE9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED7Au); return; }
    goto L_00ED7C;
L_00ED7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Cu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED7C CPY
    cpu.compareY(0xD8u);
    goto L_00ED7E;
L_00ED7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED7E BCS -> $00EDE9
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED7Eu); return; }
    goto L_00ED80;
L_00ED80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED80u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED80u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED80 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED82;
L_00ED82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED82u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED82 ADC
    cpu.adc(0x10u);
    goto L_00ED84;
L_00ED84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED84u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED84u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED84 STA
    hw.write(cpu.address("dp", 0x90u), cpu.a, cpu.m8?8:16);
    goto L_00ED86;
L_00ED86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED86u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED86u, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED86 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED89;
L_00ED89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED89u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED89 CMP
    cpu.compareA(0x3u);
    goto L_00ED8B;
L_00ED8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED8B BEQ -> $00ED91
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00ED91; }
    goto L_00ED8D;
L_00ED8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED8D CMP
    cpu.compareA(0xEu);
    goto L_00ED8F;
L_00ED8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED8F BNE -> $00ED95
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00ED95; }
    goto L_00ED91;
L_00ED91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED91u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED91 CPY
    cpu.compareY(0xD2u);
    goto L_00ED93;
L_00ED93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED93u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED93 BCS -> $00EDE9
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED93u); return; }
    goto L_00ED95;
L_00ED95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED95u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED95 TYA
    cpu.transfer("TYA");
    goto L_00ED96;
L_00ED96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED96u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED96 SEC
    cpu.setFlag('C', true);
    goto L_00ED97;
L_00ED97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED97u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED97 SBC
    cpu.sbc(0x6Eu);
    goto L_00ED99;
L_00ED99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED99u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED99u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED99 TAY
    cpu.transfer("TAY");
    goto L_00ED9A;
L_00ED9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Au,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x82u) & 0xFFFFu), 3u, 0u);
    // $00ED9A LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED9C;
L_00ED9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00ED9C PHA
    cpu.push("PHA", hw);
    goto L_00ED9D;
L_00ED9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED9D REP
    cpu.rep(0x20u);
    goto L_00ED9F;
L_00ED9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED9F AND
    cpu.logicAnd(0xFFu);
    goto L_00EDA2;
L_00EDA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA2 ASL
    cpu.aslA();
    goto L_00EDA3;
L_00EDA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA3 ASL
    cpu.aslA();
    goto L_00EDA4;
L_00EDA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA4 ASL
    cpu.aslA();
    goto L_00EDA5;
L_00EDA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA5 ASL
    cpu.aslA();
    goto L_00EDA6;
L_00EDA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA6 SEP
    cpu.sep(0x20u);
    goto L_00EDA8;
L_00EDA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA8u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA8 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x92u), cpu.m8?8:16));
    goto L_00EDAA;
L_00EDAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAAu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EDAA PHX
    cpu.push("PHX", hw);
    goto L_00EDAB;
L_00EDAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDABu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDABu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDAB REP
    cpu.rep(0x10u);
    goto L_00EDAD;
L_00EDAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDADu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDAD TAX
    cpu.transfer("TAX");
    goto L_00EDAE;
L_00EDAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EDB0;
L_00EDB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDB0 SEC
    cpu.setFlag('C', true);
    goto L_00EDB1;
L_00EDB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB1u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB1u, 4u + 1u, 3u, cpu.address("absx", 0xE632u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDB1 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0xE632u), cpu.m8?8:16));
    goto L_00EDB4;
L_00EDB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDB4 BPL -> $00EDB9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EDB9; }
    goto L_00EDB6;
L_00EDB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB6u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB6u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDB6 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EDB9;
L_00EDB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDB9 SEP
    cpu.sep(0x10u);
    goto L_00EDBB;
L_00EDBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBBu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EDBB PLX
    cpu.pop("PLX", hw);
    goto L_00EDBC;
L_00EDBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBCu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EDBC PLY
    cpu.pop("PLY", hw);
    goto L_00EDBD;
L_00EDBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBDu,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBDu, 4u + ((((0xE51Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE51Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDBD CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE51Cu), cpu.m8?8:16));
    goto L_00EDC0;
L_00EDC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDC0 BCS -> $00EDE9
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00EDC0u); return; }
    goto L_00EDC2;
L_00EDC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDC2 STA
    hw.write(cpu.address("dp", 0x91u), cpu.a, cpu.m8?8:16);
    goto L_00EDC4;
L_00EDC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDC4 STZ
    hw.write(cpu.address("dp", 0x90u), 0, cpu.m8?8:16);
    goto L_00EDC6;
L_00EDC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC6u, 6u, 3u, cpu.address("abs", 0xF005u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDC6 JSR -> $00F005 stack real
    { cpu.push16Value(hw,0xEDC8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDC9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF005u), 0x00EDC6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDC9;
L_00EDC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDC9u,0x00EDC9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC9u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDC9 CPY
    cpu.compareY(0x1Cu);
    goto L_00EDCB;
L_00EDCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDCB BCC -> $00EDD5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EDD5; }
    goto L_00EDCD;
L_00EDCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDCD LDA
    cpu.setA(0x8u, 8);
    goto L_00EDCF;
L_00EDCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCFu, 4u, 3u, cpu.address("abs", 0x14A1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDCF STA
    hw.write(cpu.address("abs", 0x14A1u), cpu.a, cpu.m8?8:16);
    goto L_00EDD2;
L_00EDD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD2u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD2u, 3u, 3u, cpu.address("abs", 0xEED1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDD2 JMP -> $00EED1
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xEED1u),0x00EDD2u); return;
L_00EDD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD5u, 6u, 3u, cpu.address("abs", 0xEFBCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDD5 JSR -> $00EFBC stack real
    { cpu.push16Value(hw,0xEDD7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDD8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEFBCu), 0x00EDD5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDD8;
L_00EDD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDD8u,0x00EDD8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD8u, 3u, 3u, cpu.address("abs", 0xEE85u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDD8 JMP -> $00EE85
    goto L_00EE85;
L_00EE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE20;
L_00EE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE20 BEQ -> $00EE2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE2D; }
    goto L_00EE22;
L_00EE22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE24;
L_00EE24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE24 BMI -> $00EE2D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EE2D; }
    goto L_00EE26;
L_00EE26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE26 STZ
    hw.write(cpu.address("dp", 0x8Eu), 0, cpu.m8?8:16);
    goto L_00EE28;
L_00EE28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE28u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE28 LDY
    cpu.setY(0x20u, 8);
    goto L_00EE2A;
L_00EE2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Au, 3u, 3u, cpu.address("abs", 0xEEE1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2A JMP -> $00EEE1
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xEEE1u),0x00EE2Au); return;
L_00EE2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE2F;
L_00EE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2F AND
    cpu.logicAnd(0x4u);
    goto L_00EE31;
L_00EE31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE31u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE31u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE31 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16));
    goto L_00EE33;
L_00EE33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE33u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE33 BNE -> $00EE39
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE39; }
    goto L_00EE35;
L_00EE35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE35u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE35 LDA
    cpu.setA(0x24u, 8);
    goto L_00EE37;
L_00EE37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE37u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE37u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE37 STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00EE39;
L_00EE39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE39u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE39u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE39 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EE39u);return;} hw.unresolvedReturn(0x00EE39u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00EE76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE76u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE76u,0x00EE76u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE76u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE76u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE76 BRA -> $00EE1D
    goto L_00EE1D;
L_00EE83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE83u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE83u,0x00EE83u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE83u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE83 LDY
    cpu.setY(0x20u, 8);
    goto L_00EE85;
L_00EE85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE85u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE85u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE85 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE87;
L_00EE87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE87u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE87 BPL -> $00EE8F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EE8F; }
    goto L_00EE89;
L_00EE89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE89 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE8B;
L_00EE8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8B CMP
    cpu.compareA(0x2u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE8Du,0x00EE8Bu); return;
L_00EE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu, 4u, 3u, cpu.address("abs", 0x1423u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1423u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE92;
L_00EE92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE92 BEQ -> $00EED1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EED1u,0x00EE92u); return; }
    goto L_00EE94;
L_00EE94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE94 DEX
    cpu.decReg('X');
    goto L_00EE95;
L_00EE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE95 TXA
    cpu.transfer("TXA");
    goto L_00EE96;
L_00EE96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0x3u);
    goto L_00EE98;
L_00EE98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE98 BEQ -> $00EEAA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EEAA; }
    goto L_00EE9A;
L_00EE9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9A CMP
    cpu.compareA(0x2u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,0x00EE9Au); return;
L_00EEAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAA TXA
    cpu.transfer("TXA");
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEABu,0x00EEAAu); return;
}

void sub_00ECB1_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00ECB1u: goto L_00ECB1;
    case 0x00ECB3u: goto L_00ECB3;
    case 0x00ECB5u: goto L_00ECB5;
    case 0x00ECB7u: goto L_00ECB7;
    case 0x00ECB9u: goto L_00ECB9;
    case 0x00ECBBu: goto L_00ECBB;
    case 0x00ECBDu: goto L_00ECBD;
    case 0x00ECBFu: goto L_00ECBF;
    case 0x00ECC1u: goto L_00ECC1;
    case 0x00ECC2u: goto L_00ECC2;
    case 0x00ECC5u: goto L_00ECC5;
    case 0x00ECC7u: goto L_00ECC7;
    case 0x00ECCAu: goto L_00ECCA;
    case 0x00ECCCu: goto L_00ECCC;
    case 0x00ECCEu: goto L_00ECCE;
    case 0x00ECD0u: goto L_00ECD0;
    case 0x00ECD2u: goto L_00ECD2;
    case 0x00ECD4u: goto L_00ECD4;
    case 0x00ECD6u: goto L_00ECD6;
    case 0x00ECD8u: goto L_00ECD8;
    case 0x00ECDAu: goto L_00ECDA;
    case 0x00ECDBu: goto L_00ECDB;
    case 0x00ECDCu: goto L_00ECDC;
    case 0x00ECDEu: goto L_00ECDE;
    case 0x00ECDFu: goto L_00ECDF;
    case 0x00ECE1u: goto L_00ECE1;
    case 0x00ECE3u: goto L_00ECE3;
    case 0x00ECE6u: goto L_00ECE6;
    case 0x00ECE7u: goto L_00ECE7;
    case 0x00ECE8u: goto L_00ECE8;
    case 0x00ECE9u: goto L_00ECE9;
    case 0x00ECEAu: goto L_00ECEA;
    case 0x00ECECu: goto L_00ECEC;
    case 0x00ECEEu: goto L_00ECEE;
    case 0x00ECF0u: goto L_00ECF0;
    case 0x00ECF1u: goto L_00ECF1;
    case 0x00ECF4u: goto L_00ECF4;
    case 0x00ECF6u: goto L_00ECF6;
    case 0x00ECF8u: goto L_00ECF8;
    case 0x00ECFAu: goto L_00ECFA;
    case 0x00ECFCu: goto L_00ECFC;
    case 0x00ECFFu: goto L_00ECFF;
    case 0x00ED00u: goto L_00ED00;
    case 0x00ED02u: goto L_00ED02;
    case 0x00ED06u: goto L_00ED06;
    case 0x00ED09u: goto L_00ED09;
    case 0x00ED0Bu: goto L_00ED0B;
    case 0x00ED0Du: goto L_00ED0D;
    case 0x00ED0Fu: goto L_00ED0F;
    case 0x00ED10u: goto L_00ED10;
    case 0x00ED12u: goto L_00ED12;
    case 0x00ED14u: goto L_00ED14;
    case 0x00ED16u: goto L_00ED16;
    case 0x00ED18u: goto L_00ED18;
    case 0x00ED1Au: goto L_00ED1A;
    case 0x00ED1Cu: goto L_00ED1C;
    case 0x00ED1Eu: goto L_00ED1E;
    case 0x00ED20u: goto L_00ED20;
    case 0x00ED22u: goto L_00ED22;
    case 0x00ED24u: goto L_00ED24;
    case 0x00ED26u: goto L_00ED26;
    case 0x00ED28u: goto L_00ED28;
    case 0x00ED2Au: goto L_00ED2A;
    case 0x00ED2Cu: goto L_00ED2C;
    case 0x00ED2Eu: goto L_00ED2E;
    case 0x00ED2Fu: goto L_00ED2F;
    case 0x00ED31u: goto L_00ED31;
    case 0x00ED33u: goto L_00ED33;
    case 0x00ED35u: goto L_00ED35;
    case 0x00ED37u: goto L_00ED37;
    case 0x00ED39u: goto L_00ED39;
    case 0x00ED3Bu: goto L_00ED3B;
    case 0x00ED3Du: goto L_00ED3D;
    case 0x00ED3Fu: goto L_00ED3F;
    case 0x00ED41u: goto L_00ED41;
    case 0x00ED44u: goto L_00ED44;
    case 0x00ED46u: goto L_00ED46;
    case 0x00ED47u: goto L_00ED47;
    case 0x00ED76u: goto L_00ED76;
    case 0x00ED78u: goto L_00ED78;
    case 0x00ED7Au: goto L_00ED7A;
    case 0x00ED7Cu: goto L_00ED7C;
    case 0x00ED7Eu: goto L_00ED7E;
    case 0x00ED80u: goto L_00ED80;
    case 0x00ED82u: goto L_00ED82;
    case 0x00ED84u: goto L_00ED84;
    case 0x00ED86u: goto L_00ED86;
    case 0x00ED89u: goto L_00ED89;
    case 0x00ED8Bu: goto L_00ED8B;
    case 0x00ED8Du: goto L_00ED8D;
    case 0x00ED8Fu: goto L_00ED8F;
    case 0x00ED91u: goto L_00ED91;
    case 0x00ED93u: goto L_00ED93;
    case 0x00ED95u: goto L_00ED95;
    case 0x00ED96u: goto L_00ED96;
    case 0x00ED97u: goto L_00ED97;
    case 0x00ED99u: goto L_00ED99;
    case 0x00ED9Au: goto L_00ED9A;
    case 0x00ED9Cu: goto L_00ED9C;
    case 0x00ED9Du: goto L_00ED9D;
    case 0x00ED9Fu: goto L_00ED9F;
    case 0x00EDA2u: goto L_00EDA2;
    case 0x00EDA3u: goto L_00EDA3;
    case 0x00EDA4u: goto L_00EDA4;
    case 0x00EDA5u: goto L_00EDA5;
    case 0x00EDA6u: goto L_00EDA6;
    case 0x00EDA8u: goto L_00EDA8;
    case 0x00EDAAu: goto L_00EDAA;
    case 0x00EDABu: goto L_00EDAB;
    case 0x00EDADu: goto L_00EDAD;
    case 0x00EDAEu: goto L_00EDAE;
    case 0x00EDB0u: goto L_00EDB0;
    case 0x00EDB1u: goto L_00EDB1;
    case 0x00EDB4u: goto L_00EDB4;
    case 0x00EDB6u: goto L_00EDB6;
    case 0x00EDB9u: goto L_00EDB9;
    case 0x00EDBBu: goto L_00EDBB;
    case 0x00EDBCu: goto L_00EDBC;
    case 0x00EDBDu: goto L_00EDBD;
    case 0x00EDC0u: goto L_00EDC0;
    case 0x00EDC2u: goto L_00EDC2;
    case 0x00EDC4u: goto L_00EDC4;
    case 0x00EDC6u: goto L_00EDC6;
    case 0x00EDC9u: goto L_00EDC9;
    case 0x00EDCBu: goto L_00EDCB;
    case 0x00EDCDu: goto L_00EDCD;
    case 0x00EDCFu: goto L_00EDCF;
    case 0x00EDD2u: goto L_00EDD2;
    case 0x00EDD5u: goto L_00EDD5;
    case 0x00EDD8u: goto L_00EDD8;
    case 0x00EE1Du: goto L_00EE1D;
    case 0x00EE20u: goto L_00EE20;
    case 0x00EE22u: goto L_00EE22;
    case 0x00EE24u: goto L_00EE24;
    case 0x00EE26u: goto L_00EE26;
    case 0x00EE28u: goto L_00EE28;
    case 0x00EE2Au: goto L_00EE2A;
    case 0x00EE2Du: goto L_00EE2D;
    case 0x00EE2Fu: goto L_00EE2F;
    case 0x00EE31u: goto L_00EE31;
    case 0x00EE33u: goto L_00EE33;
    case 0x00EE35u: goto L_00EE35;
    case 0x00EE37u: goto L_00EE37;
    case 0x00EE39u: goto L_00EE39;
    case 0x00EE76u: goto L_00EE76;
    case 0x00EE83u: goto L_00EE83;
    case 0x00EE85u: goto L_00EE85;
    case 0x00EE87u: goto L_00EE87;
    case 0x00EE89u: goto L_00EE89;
    case 0x00EE8Bu: goto L_00EE8B;
    case 0x00EE8Fu: goto L_00EE8F;
    case 0x00EE92u: goto L_00EE92;
    case 0x00EE94u: goto L_00EE94;
    case 0x00EE95u: goto L_00EE95;
    case 0x00EE96u: goto L_00EE96;
    case 0x00EE98u: goto L_00EE98;
    case 0x00EE9Au: goto L_00EE9A;
    case 0x00EEAAu: goto L_00EEAA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00ECB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECB1u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECB1 CPY
    cpu.compareY(0x11u);
    goto L_00ECB3;
L_00ECB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECB3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECB3 BCC -> $00ECA3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ECA3u,0x00ECB3u); return; }
    goto L_00ECB5;
L_00ECB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECB5u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECB5 CPY
    cpu.compareY(0x6Eu);
    goto L_00ECB7;
L_00ECB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECB7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECB7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECB7 BCC -> $00ECFA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00ECFA; }
    goto L_00ECB9;
L_00ECB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECB9u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECB9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECB9 CPY
    cpu.compareY(0xD8u);
    goto L_00ECBB;
L_00ECBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECBBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECBBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECBB BCC -> $00ECDA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00ECDA; }
    goto L_00ECBD;
L_00ECBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECBDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECBDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECBD REP
    cpu.rep(0x20u);
    goto L_00ECBF;
L_00ECBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECBFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECBFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECBF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ECC1;
L_00ECC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECC1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECC1 CLC
    cpu.setFlag('C', false);
    goto L_00ECC2;
L_00ECC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECC2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECC2 ADC
    cpu.adc(0x10u);
    goto L_00ECC5;
L_00ECC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECC5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECC5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECC5 STA
    hw.write(cpu.address("dp", 0x98u), cpu.a, cpu.m8?8:16);
    goto L_00ECC7;
L_00ECC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECC7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECC7u, 6u, 3u, cpu.address("abs", 0xF461u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ECC7 JSR -> $00F461 stack real
    { cpu.push16Value(hw,0xECC9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xECCAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF461u), 0x00ECC7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00ECCA;
L_00ECCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECCAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xECCAu,0x00ECCAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECCAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECCAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECCA BEQ -> $00ECF8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00ECF8; }
    goto L_00ECCC;
L_00ECCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECCCu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECCC CPY
    cpu.compareY(0x6Eu);
    goto L_00ECCE;
L_00ECCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECCEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECCE BCC -> $00ED4A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ED4Au,0x00ECCEu); return; }
    goto L_00ECD0;
L_00ECD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECD0u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECD0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECD0 CPY
    cpu.compareY(0xD8u);
    goto L_00ECD2;
L_00ECD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECD2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECD2 BCS -> $00ED4A
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ED4Au,0x00ECD2u); return; }
    goto L_00ECD4;
L_00ECD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECD4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECD4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECD4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ECD6;
L_00ECD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECD6u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECD6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECD6 SBC
    cpu.sbc(0xFu);
    goto L_00ECD8;
L_00ECD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECD8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECD8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECD8 STA
    hw.write(cpu.address("dp", 0x91u), cpu.a, cpu.m8?8:16);
    goto L_00ECDA;
L_00ECDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECDAu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECDA TYA
    cpu.transfer("TYA");
    goto L_00ECDB;
L_00ECDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECDBu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECDB SEC
    cpu.setFlag('C', true);
    goto L_00ECDC;
L_00ECDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECDCu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECDC SBC
    cpu.sbc(0x6Eu);
    goto L_00ECDE;
L_00ECDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECDEu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECDEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECDE TAY
    cpu.transfer("TAY");
    goto L_00ECDF;
L_00ECDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECDFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECDFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECDF REP
    cpu.rep(0x20u);
    goto L_00ECE1;
L_00ECE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECE1u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECE1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x82u) & 0xFFFFu), 3u, 0u);
    // $00ECE1 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ECE3;
L_00ECE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECE3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECE3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECE3 AND
    cpu.logicAnd(0xFFu);
    goto L_00ECE6;
L_00ECE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECE6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECE6 ASL
    cpu.aslA();
    goto L_00ECE7;
L_00ECE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECE7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECE7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECE7 ASL
    cpu.aslA();
    goto L_00ECE8;
L_00ECE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECE8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECE8 ASL
    cpu.aslA();
    goto L_00ECE9;
L_00ECE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECE9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECE9 ASL
    cpu.aslA();
    goto L_00ECEA;
L_00ECEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECEAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECEAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECEA SEP
    cpu.sep(0x20u);
    goto L_00ECEC;
L_00ECEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECECu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECEC ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x92u), cpu.m8?8:16));
    goto L_00ECEE;
L_00ECEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECEEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECEEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECEE REP
    cpu.rep(0x10u);
    goto L_00ECF0;
L_00ECF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECF0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECF0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECF0 TAY
    cpu.transfer("TAY");
    goto L_00ECF1;
L_00ECF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECF1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECF1u, 4u + 1u, 3u, cpu.address("absy", 0xE632u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECF1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE632u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ECF4;
L_00ECF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECF4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECF4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECF4 SEP
    cpu.sep(0x10u);
    goto L_00ECF6;
L_00ECF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECF6u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECF6 BMI -> $00ED0F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00ED0F; }
    goto L_00ECF8;
L_00ECF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECF8u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECF8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECF8 BRA -> $00ED4A
    hw.requestDispatch(0x00ED4Au,0x00ECF8u); return;
L_00ECFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECFAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECFA LDA
    cpu.setA(0x2u, 8);
    goto L_00ECFC;
L_00ECFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECFCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECFCu, 6u, 3u, cpu.address("abs", 0xF3E9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ECFC JSR -> $00F3E9 stack real
    { cpu.push16Value(hw,0xECFEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xECFFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF3E9u), 0x00ECFCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00ECFF;
L_00ECFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECFFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xECFFu,0x00ECFFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECFFu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECFFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ECFF TYA
    cpu.transfer("TYA");
    goto L_00ED00;
L_00ED00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED00u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED00 LDY
    cpu.setY(0x0u, 8);
    goto L_00ED02;
L_00ED02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED02u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED02u, 8u, 4u, 0x00F127u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00ED02 JSL -> $00F127 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xED05u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xED06u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F127u, 0x00ED02u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00ED06;
L_00ED06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED06u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED06u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED06u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED06 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED09;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED06u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED06u, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED06 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1693u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED09;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED06u,0x00ED06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED09u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED09u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED09 CMP
    cpu.compareA(0x1Eu);
    goto L_00ED0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED09u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED09 CMP
    cpu.compareA(0x1Eu);
    goto L_00ED0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED09u,0x00ED09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED0B BEQ -> $00ED3B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00ED3B; }
    goto L_00ED0D;
L_00ED0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED0D LDA
    cpu.setA(0xF0u, 8);
    goto L_00ED0F;
L_00ED0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED0Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED0F CLC
    cpu.setFlag('C', false);
    goto L_00ED10;
L_00ED10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED10u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED10u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED10 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00ED12;
L_00ED12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED12u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED12 BPL -> $00ED4A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ED4Au,0x00ED12u); return; }
    goto L_00ED14;
L_00ED14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED14u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED14u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED14 CMP
    cpu.compareA(0xF9u);
    goto L_00ED16;
L_00ED16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED16u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED16 BCS -> $00ED28
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00ED28; }
    goto L_00ED18;
L_00ED18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED18u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED18u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED18 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x72u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00ED1A;
L_00ED1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED1A BNE -> $00ED28
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00ED28; }
    goto L_00ED1C;
L_00ED1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED1C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED1E;
L_00ED1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED1E AND
    cpu.logicAnd(0xFCu);
    goto L_00ED20;
L_00ED20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED20u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED20 ORA
    cpu.logicOr(0x9u);
    goto L_00ED22;
L_00ED22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED22u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED22u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED22 STA
    hw.write(cpu.address("dp", 0x77u), cpu.a, cpu.m8?8:16);
    goto L_00ED24;
L_00ED24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED24u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED24u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED24 STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00ED26;
L_00ED26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED26u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED26u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED26 BRA -> $00ED3B
    goto L_00ED3B;
L_00ED28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED28u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED28u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED28 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x72u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00ED2A;
L_00ED2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED2A BEQ -> $00ED37
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00ED37; }
    goto L_00ED2C;
L_00ED2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Cu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED2C EOR
    cpu.logicXor(0xFFu);
    goto L_00ED2E;
L_00ED2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED2E CLC
    cpu.setFlag('C', false);
    goto L_00ED2F;
L_00ED2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Fu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED2Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED2F ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16));
    goto L_00ED31;
L_00ED31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED31u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED31u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED31 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00ED33;
L_00ED33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED33u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED33 BCC -> $00ED37
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00ED37; }
    goto L_00ED35;
L_00ED35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED35u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED35u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED35 INC
    cpu.incMem(hw, cpu.address("dp", 0x97u), cpu.m8?8:16);
    goto L_00ED37;
L_00ED37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED37u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED37 LDA
    cpu.setA(0x8u, 8);
    goto L_00ED39;
L_00ED39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED39u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED39u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED39 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00ED3B;
L_00ED3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED3Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED3B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED3D;
L_00ED3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED3Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED3D BPL -> $00ED4A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ED4Au,0x00ED3Du); return; }
    goto L_00ED3F;
L_00ED3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED3Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED3Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED3F STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    goto L_00ED41;
L_00ED41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED41u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED41u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED41 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DF9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED44;
L_00ED44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED44u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED44 BNE -> $00ED4A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00ED4Au,0x00ED44u); return; }
    goto L_00ED46;
L_00ED46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED46u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED46 INC
    cpu.inc('A');
    goto L_00ED47;
L_00ED47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED47u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED47u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED47 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED4Au,0x00ED47u); return;
L_00ED76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED76u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED76u,0x00ED76u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED76u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED76 BEQ -> $00EDE9
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED76u); return; }
    goto L_00ED78;
L_00ED78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED78u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED78 CPY
    cpu.compareY(0x6Eu);
    goto L_00ED7A;
L_00ED7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED7A BCC -> $00EDE9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED7Au); return; }
    goto L_00ED7C;
L_00ED7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Cu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED7C CPY
    cpu.compareY(0xD8u);
    goto L_00ED7E;
L_00ED7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED7E BCS -> $00EDE9
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED7Eu); return; }
    goto L_00ED80;
L_00ED80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED80u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED80u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED80 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED82;
L_00ED82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED82u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED82 ADC
    cpu.adc(0x10u);
    goto L_00ED84;
L_00ED84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED84u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED84u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED84 STA
    hw.write(cpu.address("dp", 0x90u), cpu.a, cpu.m8?8:16);
    goto L_00ED86;
L_00ED86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED86u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED86u, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED86 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED89;
L_00ED89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED89u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED89 CMP
    cpu.compareA(0x3u);
    goto L_00ED8B;
L_00ED8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED8B BEQ -> $00ED91
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00ED91; }
    goto L_00ED8D;
L_00ED8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED8D CMP
    cpu.compareA(0xEu);
    goto L_00ED8F;
L_00ED8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED8F BNE -> $00ED95
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00ED95; }
    goto L_00ED91;
L_00ED91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED91u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED91 CPY
    cpu.compareY(0xD2u);
    goto L_00ED93;
L_00ED93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED93u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED93 BCS -> $00EDE9
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED93u); return; }
    goto L_00ED95;
L_00ED95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED95u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED95 TYA
    cpu.transfer("TYA");
    goto L_00ED96;
L_00ED96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED96u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED96 SEC
    cpu.setFlag('C', true);
    goto L_00ED97;
L_00ED97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED97u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED97 SBC
    cpu.sbc(0x6Eu);
    goto L_00ED99;
L_00ED99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED99u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED99u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED99 TAY
    cpu.transfer("TAY");
    goto L_00ED9A;
L_00ED9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Au,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x82u) & 0xFFFFu), 3u, 0u);
    // $00ED9A LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED9C;
L_00ED9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00ED9C PHA
    cpu.push("PHA", hw);
    goto L_00ED9D;
L_00ED9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED9D REP
    cpu.rep(0x20u);
    goto L_00ED9F;
L_00ED9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED9F AND
    cpu.logicAnd(0xFFu);
    goto L_00EDA2;
L_00EDA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA2 ASL
    cpu.aslA();
    goto L_00EDA3;
L_00EDA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA3 ASL
    cpu.aslA();
    goto L_00EDA4;
L_00EDA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA4 ASL
    cpu.aslA();
    goto L_00EDA5;
L_00EDA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA5 ASL
    cpu.aslA();
    goto L_00EDA6;
L_00EDA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA6 SEP
    cpu.sep(0x20u);
    goto L_00EDA8;
L_00EDA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA8u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA8 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x92u), cpu.m8?8:16));
    goto L_00EDAA;
L_00EDAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAAu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EDAA PHX
    cpu.push("PHX", hw);
    goto L_00EDAB;
L_00EDAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDABu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDABu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDAB REP
    cpu.rep(0x10u);
    goto L_00EDAD;
L_00EDAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDADu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDAD TAX
    cpu.transfer("TAX");
    goto L_00EDAE;
L_00EDAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EDB0;
L_00EDB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDB0 SEC
    cpu.setFlag('C', true);
    goto L_00EDB1;
L_00EDB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB1u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB1u, 4u + 1u, 3u, cpu.address("absx", 0xE632u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDB1 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0xE632u), cpu.m8?8:16));
    goto L_00EDB4;
L_00EDB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDB4 BPL -> $00EDB9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EDB9; }
    goto L_00EDB6;
L_00EDB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB6u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB6u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDB6 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EDB9;
L_00EDB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDB9 SEP
    cpu.sep(0x10u);
    goto L_00EDBB;
L_00EDBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBBu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EDBB PLX
    cpu.pop("PLX", hw);
    goto L_00EDBC;
L_00EDBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBCu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EDBC PLY
    cpu.pop("PLY", hw);
    goto L_00EDBD;
L_00EDBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBDu,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBDu, 4u + ((((0xE51Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE51Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDBD CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE51Cu), cpu.m8?8:16));
    goto L_00EDC0;
L_00EDC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDC0 BCS -> $00EDE9
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00EDC0u); return; }
    goto L_00EDC2;
L_00EDC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDC2 STA
    hw.write(cpu.address("dp", 0x91u), cpu.a, cpu.m8?8:16);
    goto L_00EDC4;
L_00EDC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDC4 STZ
    hw.write(cpu.address("dp", 0x90u), 0, cpu.m8?8:16);
    goto L_00EDC6;
L_00EDC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC6u, 6u, 3u, cpu.address("abs", 0xF005u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDC6 JSR -> $00F005 stack real
    { cpu.push16Value(hw,0xEDC8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDC9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF005u), 0x00EDC6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDC9;
L_00EDC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDC9u,0x00EDC9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC9u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDC9 CPY
    cpu.compareY(0x1Cu);
    goto L_00EDCB;
L_00EDCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDCB BCC -> $00EDD5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EDD5; }
    goto L_00EDCD;
L_00EDCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDCD LDA
    cpu.setA(0x8u, 8);
    goto L_00EDCF;
L_00EDCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCFu, 4u, 3u, cpu.address("abs", 0x14A1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDCF STA
    hw.write(cpu.address("abs", 0x14A1u), cpu.a, cpu.m8?8:16);
    goto L_00EDD2;
L_00EDD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD2u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD2u, 3u, 3u, cpu.address("abs", 0xEED1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDD2 JMP -> $00EED1
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xEED1u),0x00EDD2u); return;
L_00EDD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD5u, 6u, 3u, cpu.address("abs", 0xEFBCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDD5 JSR -> $00EFBC stack real
    { cpu.push16Value(hw,0xEDD7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDD8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEFBCu), 0x00EDD5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDD8;
L_00EDD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDD8u,0x00EDD8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD8u, 3u, 3u, cpu.address("abs", 0xEE85u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDD8 JMP -> $00EE85
    goto L_00EE85;
L_00EE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE1Du, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE20;
L_00EE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE20 BEQ -> $00EE2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE2D; }
    goto L_00EE22;
L_00EE22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE22u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE24;
L_00EE24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE24 BMI -> $00EE2D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EE2D; }
    goto L_00EE26;
L_00EE26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE26 STZ
    hw.write(cpu.address("dp", 0x8Eu), 0, cpu.m8?8:16);
    goto L_00EE28;
L_00EE28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE28u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE28 LDY
    cpu.setY(0x20u, 8);
    goto L_00EE2A;
L_00EE2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Au, 3u, 3u, cpu.address("abs", 0xEEE1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2A JMP -> $00EEE1
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xEEE1u),0x00EE2Au); return;
L_00EE2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE2F;
L_00EE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE2F AND
    cpu.logicAnd(0x4u);
    goto L_00EE31;
L_00EE31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE31u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE31u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE31 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16));
    goto L_00EE33;
L_00EE33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE33u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE33 BNE -> $00EE39
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EE39; }
    goto L_00EE35;
L_00EE35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE35u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE35 LDA
    cpu.setA(0x24u, 8);
    goto L_00EE37;
L_00EE37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE37u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE37u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE37 STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00EE39;
L_00EE39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE39u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE39u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EE39 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EE39u);return;} hw.unresolvedReturn(0x00EE39u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00EE76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE76u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE76u,0x00EE76u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE76u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE76u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE76 BRA -> $00EE1D
    goto L_00EE1D;
L_00EE83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE83u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE83u,0x00EE83u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE83u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE83 LDY
    cpu.setY(0x20u, 8);
    goto L_00EE85;
L_00EE85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE85u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE85u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE85 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE87;
L_00EE87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE87u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE87 BPL -> $00EE8F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EE8F; }
    goto L_00EE89;
L_00EE89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE89 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EE8B;
L_00EE8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8B CMP
    cpu.compareA(0x2u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE8Du,0x00EE8Bu); return;
L_00EE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu, 4u, 3u, cpu.address("abs", 0x1423u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE8F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1423u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EE92;
L_00EE92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE92 BEQ -> $00EED1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EED1u,0x00EE92u); return; }
    goto L_00EE94;
L_00EE94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE94 DEX
    cpu.decReg('X');
    goto L_00EE95;
L_00EE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE95 TXA
    cpu.transfer("TXA");
    goto L_00EE96;
L_00EE96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE96 AND
    cpu.logicAnd(0x3u);
    goto L_00EE98;
L_00EE98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE98 BEQ -> $00EEAA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EEAA; }
    goto L_00EE9A;
L_00EE9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EE9A CMP
    cpu.compareA(0x2u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,0x00EE9Au); return;
L_00EEAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEAA TXA
    cpu.transfer("TXA");
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEABu,0x00EEAAu); return;
}

void sub_00EADB_E0M1X1CQ_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EDC2u: goto L_00EDC2;
    case 0x00EDC4u: goto L_00EDC4;
    case 0x00EDC6u: goto L_00EDC6;
    case 0x00EDC9u: goto L_00EDC9;
    case 0x00EDCBu: goto L_00EDCB;
    case 0x00EDCDu: goto L_00EDCD;
    case 0x00EDCFu: goto L_00EDCF;
    case 0x00EDD2u: goto L_00EDD2;
    case 0x00EDD5u: goto L_00EDD5;
    case 0x00EDD8u: goto L_00EDD8;
    case 0x00EDDBu: goto L_00EDDB;
    case 0x00EDDDu: goto L_00EDDD;
    case 0x00EDDFu: goto L_00EDDF;
    case 0x00EDE1u: goto L_00EDE1;
    case 0x00EDE2u: goto L_00EDE2;
    case 0x00EDE3u: goto L_00EDE3;
    case 0x00EDE4u: goto L_00EDE4;
    case 0x00EDE5u: goto L_00EDE5;
    case 0x00EDE6u: goto L_00EDE6;
    case 0x00EDE7u: goto L_00EDE7;
    case 0x00EDE9u: goto L_00EDE9;
    case 0x00EDECu: goto L_00EDEC;
    case 0x00EDEEu: goto L_00EDEE;
    case 0x00EDF1u: goto L_00EDF1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EDC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC2u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDC2 STA
    hw.write(cpu.address("dp", 0x91u), cpu.a, cpu.m8?8:16);
    goto L_00EDC4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDC2u,0x00EDC2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC4u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDC4 STZ
    hw.write(cpu.address("dp", 0x90u), 0, cpu.m8?8:16);
    goto L_00EDC6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDC4u,0x00EDC4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC6u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC6u, 6u, 3u, cpu.address("abs", 0xF005u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDC6 JSR -> $00F005 stack real
    { cpu.push16Value(hw,0xEDC8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDC9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF005u), 0x00EDC6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDC9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDC6u,0x00EDC6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC9u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC9u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDC9 CPY
    cpu.compareY(0x1Cu);
    goto L_00EDCB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDC9u,0x00EDC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDCBu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDCB BCC -> $00EDD5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EDD5; }
    goto L_00EDCD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDCBu,0x00EDCBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDCDu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDCD LDA
    cpu.setA(0x8u, 8);
    goto L_00EDCF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDCDu,0x00EDCDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDCFu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDCFu, 4u, 3u, cpu.address("abs", 0x14A1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDCF STA
    hw.write(cpu.address("abs", 0x14A1u), cpu.a, cpu.m8?8:16);
    goto L_00EDD2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDCFu,0x00EDCFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD2u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD2u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD2u, 3u, 3u, cpu.address("abs", 0xEED1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDD2 JMP -> $00EED1
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xEED1u),0x00EDD2u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDD2u,0x00EDD2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD5u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD5u, 6u, 3u, cpu.address("abs", 0xEFBCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDD5 JSR -> $00EFBC stack real
    { cpu.push16Value(hw,0xEDD7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDD8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEFBCu), 0x00EDD5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDD8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDD5u,0x00EDD5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDD8u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDD8u, 3u, 3u, cpu.address("abs", 0xEE85u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDD8 JMP -> $00EE85
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xEE85u),0x00EDD8u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDD8u,0x00EDD8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDDBu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDBu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDDB CPY
    cpu.compareY(0x5u);
    goto L_00EDDD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDBu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDDB CPY
    cpu.compareY(0x5u);
    goto L_00EDDD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDDBu,0x00EDDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDDDu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDDD BNE -> $00EDE4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EDE4; }
    goto L_00EDDF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDDD BNE -> $00EDE4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EDE4; }
    goto L_00EDDF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDDDu,0x00EDDDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDDFu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDFu, 6u, 3u, cpu.address("abs", 0xF629u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDDF JSR -> $00F629 stack real
    { cpu.push16Value(hw,0xEDE1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDE2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF629u), 0x00EDDFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDE2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDDFu, 6u, 3u, cpu.address("abs", 0xF629u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDDF JSR -> $00F629 stack real
    { cpu.push16Value(hw,0xEDE1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDE2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF629u), 0x00EDDFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDE2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDDFu,0x00EDDFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE1u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE1u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE1u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x80u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDE1 INC
    cpu.incMem(hw, cpu.address("dpx", 0x80u), cpu.m8?8:16);
    goto L_00EDE3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDE1u,0x00EDE1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE2u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDE2 BRA -> $00EDE9
    goto L_00EDE9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDE2 BRA -> $00EDE9
    goto L_00EDE9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDE2u,0x00EDE2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE3u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE3u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDE3 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xA9u), cpu.m8?8:16));
    goto L_00EDE5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDE3u,0x00EDE3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE4u))return;
  // 4 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDE4 LDA
    cpu.setA(0x2004u, 16);
    goto L_00EDE7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDE4 LDA
    cpu.setA(0x4u, 8);
    goto L_00EDE6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDE4u,0x00EDE4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE5u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE5u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDE5 TSB
    cpu.tsb(hw, cpu.address("dp", 0x20u), cpu.m8?8:16);
    goto L_00EDE7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDE5u,0x00EDE5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE6u, 6u, 3u, cpu.address("abs", 0xF2C2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDE6 JSR -> $00F2C2 stack real
    { cpu.push16Value(hw,0xEDE8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDE9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF2C2u), 0x00EDE6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDE9;
L_00EDE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE7u))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDE7 REP
    cpu.rep(0xF2u);
    goto L_00EDE9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDE7u,0x00EDE7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDE9u))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE9u, 6u, 3u, cpu.address("abs", 0xF44Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDE9 JSR -> $00F44D stack real
    { cpu.push16Value(hw,0xEDEBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDECu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF44Du), 0x00EDE9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDEC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE9u, 6u, 3u, cpu.address("abs", 0xF44Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDE9 JSR -> $00F44D stack real
    { cpu.push16Value(hw,0xEDEBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDECu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF44Du), 0x00EDE9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDEC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDE9u, 6u, 3u, cpu.address("abs", 0xF44Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDE9 JSR -> $00F44D stack real
    { cpu.push16Value(hw,0xEDEBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDECu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF44Du), 0x00EDE9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDEC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDE9u,0x00EDE9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDECu))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDECu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDEC BNE -> $00EDF3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDF3u,0x00EDECu); return; }
    goto L_00EDEE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDECu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDEC BNE -> $00EDF3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDF3u,0x00EDECu); return; }
    goto L_00EDEE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDECu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDEC BNE -> $00EDF3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDF3u,0x00EDECu); return; }
    goto L_00EDEE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDECu,0x00EDECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDEEu))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu, 6u, 3u, cpu.address("abs", 0xF309u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDEE JSR -> $00F309 stack real
    { cpu.push16Value(hw,0xEDF0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDF1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF309u), 0x00EDEEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDF1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu, 6u, 3u, cpu.address("abs", 0xF309u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDEE JSR -> $00F309 stack real
    { cpu.push16Value(hw,0xEDF0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDF1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF309u), 0x00EDEEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDF1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDEEu, 6u, 3u, cpu.address("abs", 0xF309u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EDEE JSR -> $00F309 stack real
    { cpu.push16Value(hw,0xEDF0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEDF1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF309u), 0x00EDEEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EDF1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDEEu,0x00EDEEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDF1u))return;
  // 14 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF1 BRA -> $00EE1D
    hw.requestDispatch(0x00EE1Du,0x00EDF1u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF1 BRA -> $00EE1D
    hw.requestDispatch(0x00EE1Du,0x00EDF1u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDF1 BRA -> $00EE1D
    hw.requestDispatch(0x00EE1Du,0x00EDF1u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDF1u,0x00EDF1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EADB_E1M1X1CQ_part22(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF50u: goto L_00EF50;
    case 0x00EF51u: goto L_00EF51;
    case 0x00EF54u: goto L_00EF54;
    case 0x00EF55u: goto L_00EF55;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF50u))return;
  // 37 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF50u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF50u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF50 XBA
    cpu.xba();
    goto L_00EF51;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF50u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF50u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF50 XBA
    cpu.xba();
    goto L_00EF51;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF50u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF50u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF50 XBA
    cpu.xba();
    goto L_00EF51;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF50u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF50u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF50 XBA
    cpu.xba();
    goto L_00EF51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF50u,0x00EF50u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF51u))return;
  // 37 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF51u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF51u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF51 EOR
    cpu.logicXor(0xFFFFu);
    goto L_00EF54;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF51u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF51u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF51 EOR
    cpu.logicXor(0xFFFFu);
    goto L_00EF54;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF51u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF51u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF51 EOR
    cpu.logicXor(0xFFFFu);
    goto L_00EF54;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF51u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF51u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF51 EOR
    cpu.logicXor(0xFFFFu);
    goto L_00EF54;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF51u,0x00EF51u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF54u))return;
  // 37 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF54 INC
    cpu.inc('A');
    goto L_00EF55;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF54 INC
    cpu.inc('A');
    goto L_00EF55;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF54 INC
    cpu.inc('A');
    goto L_00EF55;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF54 INC
    cpu.inc('A');
    goto L_00EF55;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF54u,0x00EF54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF55u))return;
  // 37 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF55 CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF56u,0x00EF55u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF55 CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF56u,0x00EF55u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF55 CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF56u,0x00EF55u); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF55 CLC
    cpu.setFlag('C', false);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF56u,0x00EF55u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF55u,0x00EF55u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_01800E_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01800Eu: goto L_01800E;
    case 0x018011u: goto L_018011;
    case 0x018013u: goto L_018013;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01800E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Eu, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01800E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018011;
L_018011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8011u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8011u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018011 AND
    cpu.logicAnd(0x4u);
    goto L_018013;
L_018013:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8013u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8013u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8013u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018013 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018013u);return;} hw.unresolvedReturn(0x018013u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01800E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01800Eu: goto L_01800E;
    case 0x018011u: goto L_018011;
    case 0x018013u: goto L_018013;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01800E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Eu, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01800E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018011;
L_018011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8011u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8011u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018011 AND
    cpu.logicAnd(0x4u);
    goto L_018013;
L_018013:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8013u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8013u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8013u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018013 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018013u);return;} hw.unresolvedReturn(0x018013u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01B457_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01B457u: goto L_01B457;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01B457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB457u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB457u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB457u, 6u, 3u, cpu.address("abs", 0xA7F7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01B457 JSR -> $01A7F7 stack real
    { cpu.push16Value(hw,0xB459u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB45Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA7F7u), 0x01B457u); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB45Au,0x01B457u); return;
}

void sub_01B457_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01B457u: goto L_01B457;
    case 0x01B45Au: goto L_01B45A;
    case 0x01B45Cu: goto L_01B45C;
    case 0x01B45Eu: goto L_01B45E;
    case 0x01B45Fu: goto L_01B45F;
    case 0x01B461u: goto L_01B461;
    case 0x01B463u: goto L_01B463;
    case 0x01B465u: goto L_01B465;
    case 0x01B466u: goto L_01B466;
    case 0x01B468u: goto L_01B468;
    case 0x01B46Au: goto L_01B46A;
    case 0x01B46Cu: goto L_01B46C;
    case 0x01B46Eu: goto L_01B46E;
    case 0x01B470u: goto L_01B470;
    case 0x01B472u: goto L_01B472;
    case 0x01B474u: goto L_01B474;
    case 0x01B476u: goto L_01B476;
    case 0x01B478u: goto L_01B478;
    case 0x01B47Au: goto L_01B47A;
    case 0x01B47Cu: goto L_01B47C;
    case 0x01B47Fu: goto L_01B47F;
    case 0x01B481u: goto L_01B481;
    case 0x01B484u: goto L_01B484;
    case 0x01B486u: goto L_01B486;
    case 0x01B488u: goto L_01B488;
    case 0x01B48Au: goto L_01B48A;
    case 0x01B48Cu: goto L_01B48C;
    case 0x01B48Du: goto L_01B48D;
    case 0x01B48Fu: goto L_01B48F;
    case 0x01B491u: goto L_01B491;
    case 0x01B494u: goto L_01B494;
    case 0x01B496u: goto L_01B496;
    case 0x01B498u: goto L_01B498;
    case 0x01B49Au: goto L_01B49A;
    case 0x01B49Cu: goto L_01B49C;
    case 0x01B49Eu: goto L_01B49E;
    case 0x01B4A0u: goto L_01B4A0;
    case 0x01B4A3u: goto L_01B4A3;
    case 0x01B4A5u: goto L_01B4A5;
    case 0x01B4A6u: goto L_01B4A6;
    case 0x01B4A7u: goto L_01B4A7;
    case 0x01B4A9u: goto L_01B4A9;
    case 0x01B4ABu: goto L_01B4AB;
    case 0x01B4ACu: goto L_01B4AC;
    case 0x01B4AEu: goto L_01B4AE;
    case 0x01B4B0u: goto L_01B4B0;
    case 0x01B4B1u: goto L_01B4B1;
    case 0x01B4B2u: goto L_01B4B2;
    case 0x01B4B3u: goto L_01B4B3;
    case 0x01B4B4u: goto L_01B4B4;
    case 0x01B4B7u: goto L_01B4B7;
    case 0x01B4B8u: goto L_01B4B8;
    case 0x01B4BAu: goto L_01B4BA;
    case 0x01B4BCu: goto L_01B4BC;
    case 0x01B4BEu: goto L_01B4BE;
    case 0x01B4C0u: goto L_01B4C0;
    case 0x01B4C2u: goto L_01B4C2;
    case 0x01B4C4u: goto L_01B4C4;
    case 0x01B4C6u: goto L_01B4C6;
    case 0x01B4C9u: goto L_01B4C9;
    case 0x01B4CBu: goto L_01B4CB;
    case 0x01B4CDu: goto L_01B4CD;
    case 0x01B4CEu: goto L_01B4CE;
    case 0x01B4D0u: goto L_01B4D0;
    case 0x01B4D2u: goto L_01B4D2;
    case 0x01B4D4u: goto L_01B4D4;
    case 0x01B4D6u: goto L_01B4D6;
    case 0x01B4D8u: goto L_01B4D8;
    case 0x01B4DAu: goto L_01B4DA;
    case 0x01B4DCu: goto L_01B4DC;
    case 0x01B4DEu: goto L_01B4DE;
    case 0x01B4E0u: goto L_01B4E0;
    case 0x01B4E2u: goto L_01B4E2;
    case 0x01B4E4u: goto L_01B4E4;
    case 0x01B4E7u: goto L_01B4E7;
    case 0x01B4E9u: goto L_01B4E9;
    case 0x01B4EBu: goto L_01B4EB;
    case 0x01B4EDu: goto L_01B4ED;
    case 0x01B4EFu: goto L_01B4EF;
    case 0x01B4F2u: goto L_01B4F2;
    case 0x01B4F4u: goto L_01B4F4;
    case 0x01B4F7u: goto L_01B4F7;
    case 0x01B4F8u: goto L_01B4F8;
    case 0x01B505u: goto L_01B505;
    case 0x01B508u: goto L_01B508;
    case 0x01B50Au: goto L_01B50A;
    case 0x01B50Cu: goto L_01B50C;
    case 0x01B50Eu: goto L_01B50E;
    case 0x01B510u: goto L_01B510;
    case 0x01B512u: goto L_01B512;
    case 0x01B514u: goto L_01B514;
    case 0x01B516u: goto L_01B516;
    case 0x01B518u: goto L_01B518;
    case 0x01B51Au: goto L_01B51A;
    case 0x01B51Cu: goto L_01B51C;
    case 0x01B51Eu: goto L_01B51E;
    case 0x01B51Fu: goto L_01B51F;
    case 0x01B520u: goto L_01B520;
    case 0x01B521u: goto L_01B521;
    case 0x01B522u: goto L_01B522;
    case 0x01B525u: goto L_01B525;
    case 0x01B526u: goto L_01B526;
    case 0x01B528u: goto L_01B528;
    case 0x01B52Au: goto L_01B52A;
    case 0x01B52Du: goto L_01B52D;
    case 0x01B530u: goto L_01B530;
    case 0x01B532u: goto L_01B532;
    case 0x01B534u: goto L_01B534;
    case 0x01B535u: goto L_01B535;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01B457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB457u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB457u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB457u, 6u, 3u, cpu.address("abs", 0xA7F7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01B457 JSR -> $01A7F7 stack real
    { cpu.push16Value(hw,0xB459u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB45Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA7F7u), 0x01B457u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01B45A;
L_01B45A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB45Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B45A BCC -> $01B4B2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01B4B2; }
    goto L_01B45C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B45A BCC -> $01B4B2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01B4B2; }
    goto L_01B45C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B45A BCC -> $01B4B2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01B4B2; }
    goto L_01B45C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB45Au,0x01B45Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01B45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB45Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B45C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B45E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B45C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B45E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B45C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B45E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB45Cu,0x01B45Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01B45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB45Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B45E SEC
    cpu.setFlag('C', true);
    goto L_01B45F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B45E SEC
    cpu.setFlag('C', true);
    goto L_01B45F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B45E SEC
    cpu.setFlag('C', true);
    goto L_01B45F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB45Eu,0x01B45Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01B45F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB45Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Fu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB45Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B45F SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_01B461;
L_01B461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB461u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB461u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B461 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_01B463;
L_01B463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB463u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB463u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB463u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B463 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B465;
L_01B465:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB465u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB465u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB465u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B465 CLC
    cpu.setFlag('C', false);
    goto L_01B466;
L_01B466:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB466u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB466u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB466u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B466 ADC
    cpu.adc(0x18u);
    goto L_01B468;
L_01B468:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB468u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB468u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB468u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B468 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_01B46A;
L_01B46A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB46Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B46A BPL -> $01B4B4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01B4B4; }
    goto L_01B46C;
L_01B46C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB46Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B46C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B46E;
L_01B46E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB46Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB46Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B46E BMI -> $01B4B2
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_01B4B2; }
    goto L_01B470;
L_01B470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB470u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB470u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B470 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B472;
L_01B472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB472u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB472u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B472 AND
    cpu.logicAnd(0x8u);
    goto L_01B474;
L_01B474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB474u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB474u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B474 BNE -> $01B4B2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01B4B2; }
    goto L_01B476;
L_01B476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB476u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB476u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B476 LDA
    cpu.setA(0x10u, 8);
    goto L_01B478;
L_01B478:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB478u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB478u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB478u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B478 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_01B47A;
L_01B47A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B47A LDA
    cpu.setA(0x1u, 8);
    goto L_01B47C;
L_01B47C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Cu, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B47C STA
    hw.write(cpu.address("abs", 0x1471u), cpu.a, cpu.m8?8:16);
    goto L_01B47F;
L_01B47F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B47F LDA
    cpu.setA(0x1Fu, 8);
    goto L_01B481;
L_01B481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB481u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB481u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B481 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x187Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01B484;
L_01B484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB484u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB484u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B484 BEQ -> $01B488
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01B488; }
    goto L_01B486;
L_01B486:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB486u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB486u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB486u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B486 LDA
    cpu.setA(0x2Fu, 8);
    goto L_01B488;
L_01B488:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB488u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB488u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB488u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B488 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_01B48A;
L_01B48A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B48A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B48C;
L_01B48C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B48C SEC
    cpu.setFlag('C', true);
    goto L_01B48D;
L_01B48D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Du,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B48D SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16));
    goto L_01B48F;
L_01B48F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B48F STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_01B491;
L_01B491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB491u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB491u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B491 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B494;
L_01B494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB494u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB494u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B494 SBC
    cpu.sbc(0x0u);
    goto L_01B496;
L_01B496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB496u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB496u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B496 STA
    hw.write(cpu.address("dp", 0x97u), cpu.a, cpu.m8?8:16);
    goto L_01B498;
L_01B498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB498u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB498u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B498 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B49A;
L_01B49A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B49A AND
    cpu.logicAnd(0x3u);
    goto L_01B49C;
L_01B49C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B49C BNE -> $01B4B0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01B4B0; }
    goto L_01B49E;
L_01B49E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB49Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB49Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B49E LDY
    cpu.setY(0x0u, 8);
    goto L_01B4A0;
L_01B4A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A0u, 4u + ((((0x1528u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1528u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4A0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1528u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B4A3;
L_01B4A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A3u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4A3 BPL -> $01B4A6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01B4A6; }
    goto L_01B4A5;
L_01B4A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A5u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4A5 DEY
    cpu.decReg('Y');
    goto L_01B4A6;
L_01B4A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4A6 CLC
    cpu.setFlag('C', false);
    goto L_01B4A7;
L_01B4A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A7u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4A7 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_01B4A9;
L_01B4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4A9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4A9 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_01B4AB;
L_01B4AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ABu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4AB TYA
    cpu.transfer("TYA");
    goto L_01B4AC;
L_01B4AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ACu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4AC ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x95u), cpu.m8?8:16));
    goto L_01B4AE;
L_01B4AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4AEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4AEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4AE STA
    hw.write(cpu.address("dp", 0x95u), cpu.a, cpu.m8?8:16);
    goto L_01B4B0;
L_01B4B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4B0 SEC
    cpu.setFlag('C', true);
    goto L_01B4B1;
L_01B4B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01B4B1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01B4B1u);return;} hw.unresolvedReturn(0x01B4B1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01B4B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4B2 CLC
    cpu.setFlag('C', false);
    goto L_01B4B3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4B2 CLC
    cpu.setFlag('C', false);
    goto L_01B4B3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4B2 CLC
    cpu.setFlag('C', false);
    goto L_01B4B3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4B2u,0x01B4B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01B4B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01B4B3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01B4B3u);return;} hw.unresolvedReturn(0x01B4B3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01B4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4B4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B4B7;
L_01B4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4B7 LSR
    cpu.lsrA();
    goto L_01B4B8;
L_01B4B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4B8 BCS -> $01B4B2
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_01B4B2; }
    goto L_01B4BA;
L_01B4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4BA LDA
    cpu.setA(0x0u, 8);
    goto L_01B4BC;
L_01B4BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BCu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4BC LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x73u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01B4BE;
L_01B4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4BE BNE -> $01B4C4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01B4C4; }
    goto L_01B4C0;
L_01B4C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C0u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4C0 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01B4C2;
L_01B4C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4C2 BNE -> $01B4C6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01B4C6; }
    goto L_01B4C4;
L_01B4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4C4 LDA
    cpu.setA(0x8u, 8);
    goto L_01B4C6;
L_01B4C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C6u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C6u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4C6 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x187Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01B4C9;
L_01B4C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4C9 BEQ -> $01B4CD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01B4CD; }
    goto L_01B4CB;
L_01B4CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CBu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4CB ADC
    cpu.adc(0x8u);
    goto L_01B4CD;
L_01B4CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4CD CLC
    cpu.setFlag('C', false);
    goto L_01B4CE;
L_01B4CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CEu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4CEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4CE ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16));
    goto L_01B4D0;
L_01B4D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D0u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4D0 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_01B4D2;
L_01B4D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D2u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4D2 BCC -> $01B505
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01B505; }
    goto L_01B4D4;
L_01B4D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4D4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B4D6;
L_01B4D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4D6 BPL -> $01B4F7
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01B4F7; }
    goto L_01B4D8;
L_01B4D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4D8 LDA
    cpu.setA(0x10u, 8);
    goto L_01B4DA;
L_01B4DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4DA STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_01B4DC;
L_01B4DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DCu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4DC LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B4DE;
L_01B4DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4DE CMP
    cpu.compareA(0x83u);
    goto L_01B4E0;
L_01B4E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4E0 BCC -> $01B4F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01B4F2; }
    goto L_01B4E2;
L_01B4E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4E2 LDA
    cpu.setA(0xFu, 8);
    goto L_01B4E4;
L_01B4E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E4u, 5u, 3u, cpu.address("absx", 0x1564u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4E4 STA
    hw.write(cpu.address("absx", 0x1564u), cpu.a, cpu.m8?8:16);
    goto L_01B4E7;
L_01B4E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4E7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B4E9;
L_01B4E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4E9 BNE -> $01B4F2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01B4F2; }
    goto L_01B4EB;
L_01B4EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EBu,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EBu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4EB INC
    cpu.incMem(hw, cpu.address("dpx", 0xC2u), cpu.m8?8:16);
    goto L_01B4ED;
L_01B4ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4ED LDA
    cpu.setA(0x10u, 8);
    goto L_01B4EF;
L_01B4EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EFu, 5u, 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4EF STA
    hw.write(cpu.address("absx", 0x1558u), cpu.a, cpu.m8?8:16);
    goto L_01B4F2;
L_01B4F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4F2 LDA
    cpu.setA(0x1u, 8);
    goto L_01B4F4;
L_01B4F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F4u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4F4 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_01B4F7;
L_01B4F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B4F7 CLC
    cpu.setFlag('C', false);
    goto L_01B4F8;
L_01B4F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01B4F8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01B4F8u);return;} hw.unresolvedReturn(0x01B4F8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01B505:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB505u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB505u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB505u, 6u, 3u, cpu.address("abs", 0xAD30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01B505 JSR -> $01AD30 stack real
    { cpu.push16Value(hw,0xB507u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB508u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAD30u), 0x01B505u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01B508;
L_01B508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB508u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB508u,0x01B508u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB508u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB508u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B508 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B50A;
L_01B50A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B50A CMP
    cpu.compareA(0xA9u);
    goto L_01B50C;
L_01B50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B50C BEQ -> $01B520
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01B520; }
    goto L_01B50E;
L_01B50E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B50E CMP
    cpu.compareA(0x9Cu);
    goto L_01B510;
L_01B510:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB510u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB510u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB510u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B510 BEQ -> $01B51E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01B51E; }
    goto L_01B512;
L_01B512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B512 CMP
    cpu.compareA(0xBBu);
    goto L_01B514;
L_01B514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B514 BEQ -> $01B51E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01B51E; }
    goto L_01B516;
L_01B516:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB516u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB516u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB516u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B516 CMP
    cpu.compareA(0x60u);
    goto L_01B518;
L_01B518:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB518u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB518u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB518u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B518 BEQ -> $01B51E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01B51E; }
    goto L_01B51A;
L_01B51A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB51Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B51A CMP
    cpu.compareA(0x49u);
    goto L_01B51C;
L_01B51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB51Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B51C BNE -> $01B522
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01B522; }
    goto L_01B51E;
L_01B51E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB51Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B51E INY
    cpu.inc('Y');
    goto L_01B51F;
L_01B51F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB51Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B51F INY
    cpu.inc('Y');
    goto L_01B520;
L_01B520:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB520u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB520u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB520u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B520 INY
    cpu.inc('Y');
    goto L_01B521;
L_01B521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB521u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB521u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B521 INY
    cpu.inc('Y');
    goto L_01B522;
L_01B522:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB522u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB522u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB522u, 4u + ((((0xB4F9u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xB4F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B522 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB4F9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B525;
L_01B525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB525u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB525u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B525 CLC
    cpu.setFlag('C', false);
    goto L_01B526;
L_01B526:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB526u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB526u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB526u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B526 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16));
    goto L_01B528;
L_01B528:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB528u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB528u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB528u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B528 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_01B52A;
L_01B52A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB52Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Au, 4u + ((((0xB4FFu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xB4FFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B52A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xB4FFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01B52D;
L_01B52D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB52Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Du,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Du, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B52D ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16));
    goto L_01B530;
L_01B530:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB530u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB530u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB530u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B530 STA
    hw.write(cpu.address("dp", 0x95u), cpu.a, cpu.m8?8:16);
    goto L_01B532;
L_01B532:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB532u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB532u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB532u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B532 STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_01B534;
L_01B534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB534u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB534u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB534u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01B534 CLC
    cpu.setFlag('C', false);
    goto L_01B535;
L_01B535:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB535u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB535u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB535u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01B535 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01B535u);return;} hw.unresolvedReturn(0x01B535u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_038D6F_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x038D6Fu: goto L_038D6F;
    case 0x038D73u: goto L_038D73;
    case 0x038D76u: goto L_038D76;
    case 0x038D79u: goto L_038D79;
    case 0x038D7Bu: goto L_038D7B;
    case 0x038D7Du: goto L_038D7D;
    case 0x038D7Fu: goto L_038D7F;
    case 0x038D82u: goto L_038D82;
    case 0x038D85u: goto L_038D85;
    case 0x038D87u: goto L_038D87;
    case 0x038D89u: goto L_038D89;
    case 0x038D8Au: goto L_038D8A;
    case 0x038D8Bu: goto L_038D8B;
    case 0x038D8Cu: goto L_038D8C;
    case 0x038D8Du: goto L_038D8D;
    case 0x038D8Fu: goto L_038D8F;
    case 0x038D90u: goto L_038D90;
    case 0x038D93u: goto L_038D93;
    case 0x038D96u: goto L_038D96;
    case 0x038D97u: goto L_038D97;
    case 0x038D98u: goto L_038D98;
    case 0x038D9Au: goto L_038D9A;
    case 0x038D9Bu: goto L_038D9B;
    case 0x038D9Cu: goto L_038D9C;
    case 0x038D9Fu: goto L_038D9F;
    case 0x038DA1u: goto L_038DA1;
    case 0x038DA3u: goto L_038DA3;
    case 0x038DA4u: goto L_038DA4;
    case 0x038DA6u: goto L_038DA6;
    case 0x038DA8u: goto L_038DA8;
    case 0x038DACu: goto L_038DAC;
    case 0x038DAFu: goto L_038DAF;
    case 0x038DB1u: goto L_038DB1;
    case 0x038DB4u: goto L_038DB4;
    case 0x038DB5u: goto L_038DB5;
    case 0x038DB7u: goto L_038DB7;
    case 0x038DB8u: goto L_038DB8;
    case 0x038DBAu: goto L_038DBA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_038D6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Fu, 8u, 4u, 0x01B44Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $038D6F JSL -> $01B44F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8D72u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D73u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01B44Fu, 0x038D6Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_038D73;
L_038D73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D73u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u, 6u, 3u, cpu.address("abs", 0xB85Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $038D73 JSR -> $03B85D stack real
    { cpu.push16Value(hw,0x8D75u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D76u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB85Du), 0x038D73u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_038D76;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u, 6u, 3u, cpu.address("abs", 0xB85Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $038D73 JSR -> $03B85D stack real
    { cpu.push16Value(hw,0x8D75u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D76u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB85Du), 0x038D73u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_038D76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D73u,0x038D73u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_038D76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D76u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D76 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_038D79;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D76 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_038D79;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D76 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_038D79;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D76u,0x038D76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_038D79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D79u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D79u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D79 CMP
    cpu.compareA(0x1u);
    goto L_038D7B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D79u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D79 CMP
    cpu.compareA(0x1u);
    goto L_038D7B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D79u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D79 CMP
    cpu.compareA(0x1u);
    goto L_038D7B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D79u,0x038D79u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_038D7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D7B BNE -> $038D93
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_038D93; }
    goto L_038D7D;
L_038D7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D7D LDA
    cpu.setA(0x22u, 8);
    goto L_038D7F;
L_038D7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D7F STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_038D82;
L_038D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u, 5u, 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D82 STZ
    hw.write(cpu.address("absx", 0x1558u), 0, cpu.m8?8:16);
    goto L_038D85;
L_038D85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D85 STZ
    hw.write(cpu.address("dpx", 0xC2u), 0, cpu.m8?8:16);
    goto L_038D87;
L_038D87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D87 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_038D89;
L_038D89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D89 LSR
    cpu.lsrA();
    goto L_038D8A;
L_038D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D8A LSR
    cpu.lsrA();
    goto L_038D8B;
L_038D8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D8B LSR
    cpu.lsrA();
    goto L_038D8C;
L_038D8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D8C LSR
    cpu.lsrA();
    goto L_038D8D;
L_038D8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D8D AND
    cpu.logicAnd(0x1u);
    goto L_038D8F;
L_038D8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D8F INC
    cpu.inc('A');
    goto L_038D90;
L_038D90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D90u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D90u, 4u, 3u, cpu.address("abs", 0x1426u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D90 STA
    hw.write(cpu.address("abs", 0x1426u), cpu.a, cpu.m8?8:16);
    goto L_038D93;
L_038D93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D93u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D93u, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D93 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_038D96;
L_038D96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D96u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D96 LSR
    cpu.lsrA();
    goto L_038D97;
L_038D97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D97u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D97u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D97 TAY
    cpu.transfer("TAY");
    goto L_038D98;
L_038D98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D98u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D98u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D98 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_038D9A;
L_038D9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $038D9A PHA
    cpu.push("PHA", hw);
    goto L_038D9B;
L_038D9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D9B CLC
    cpu.setFlag('C', false);
    goto L_038D9C;
L_038D9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Cu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Cu, 4u + ((((0x8D66u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8D66u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D9C ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x8D66u), cpu.m8?8:16));
    goto L_038D9F;
L_038D9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D9F STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_038DA1;
L_038DA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038DA1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_038DA3;
L_038DA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA3u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $038DA3 PHA
    cpu.push("PHA", hw);
    goto L_038DA4;
L_038DA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA4u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038DA4 ADC
    cpu.adc(0x0u);
    goto L_038DA6;
L_038DA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038DA6 STA
    hw.write(cpu.address("dp", 0x1Du), cpu.a, cpu.m8?8:16);
    goto L_038DA8;
L_038DA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA8u, 8u, 4u, 0x0190B2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $038DA8 JSL -> $0190B2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8DABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8DACu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0190B2u, 0x038DA8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_038DAC;
L_038DAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DACu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DACu,0x038DACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DACu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DACu, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038DAC LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_038DAF;
L_038DAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038DAF LDA
    cpu.setA(0xC0u, 8);
    goto L_038DB1;
L_038DB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB1u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB1u, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038DB1 STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_038DB4;
L_038DB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB4u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $038DB4 PLA
    cpu.pop("PLA", hw);
    goto L_038DB5;
L_038DB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038DB5 STA
    hw.write(cpu.address("dp", 0x1Du), cpu.a, cpu.m8?8:16);
    goto L_038DB7;
L_038DB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB7u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $038DB7 PLA
    cpu.pop("PLA", hw);
    goto L_038DB8;
L_038DB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038DB8 STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_038DBA;
L_038DBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $038DBA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x038DBAu);return;} hw.unresolvedReturn(0x038DBAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_038D6F_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x038D6Fu: goto L_038D6F;
    case 0x038D73u: goto L_038D73;
    case 0x038D76u: goto L_038D76;
    case 0x038D79u: goto L_038D79;
    case 0x038D7Bu: goto L_038D7B;
    case 0x038D7Du: goto L_038D7D;
    case 0x038D7Fu: goto L_038D7F;
    case 0x038D82u: goto L_038D82;
    case 0x038D85u: goto L_038D85;
    case 0x038D87u: goto L_038D87;
    case 0x038D89u: goto L_038D89;
    case 0x038D8Au: goto L_038D8A;
    case 0x038D8Bu: goto L_038D8B;
    case 0x038D8Cu: goto L_038D8C;
    case 0x038D8Du: goto L_038D8D;
    case 0x038D8Fu: goto L_038D8F;
    case 0x038D90u: goto L_038D90;
    case 0x038D93u: goto L_038D93;
    case 0x038D96u: goto L_038D96;
    case 0x038D97u: goto L_038D97;
    case 0x038D98u: goto L_038D98;
    case 0x038D9Au: goto L_038D9A;
    case 0x038D9Bu: goto L_038D9B;
    case 0x038D9Cu: goto L_038D9C;
    case 0x038D9Fu: goto L_038D9F;
    case 0x038DA1u: goto L_038DA1;
    case 0x038DA3u: goto L_038DA3;
    case 0x038DA4u: goto L_038DA4;
    case 0x038DA6u: goto L_038DA6;
    case 0x038DA8u: goto L_038DA8;
    case 0x038DACu: goto L_038DAC;
    case 0x038DAFu: goto L_038DAF;
    case 0x038DB1u: goto L_038DB1;
    case 0x038DB4u: goto L_038DB4;
    case 0x038DB5u: goto L_038DB5;
    case 0x038DB7u: goto L_038DB7;
    case 0x038DB8u: goto L_038DB8;
    case 0x038DBAu: goto L_038DBA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_038D6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Fu, 8u, 4u, 0x01B44Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $038D6F JSL -> $01B44F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8D72u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D73u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01B44Fu, 0x038D6Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_038D73;
L_038D73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D73u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u, 6u, 3u, cpu.address("abs", 0xB85Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $038D73 JSR -> $03B85D stack real
    { cpu.push16Value(hw,0x8D75u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D76u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB85Du), 0x038D73u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_038D76;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u, 6u, 3u, cpu.address("abs", 0xB85Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $038D73 JSR -> $03B85D stack real
    { cpu.push16Value(hw,0x8D75u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D76u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB85Du), 0x038D73u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_038D76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D73u,0x038D73u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_038D76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D76u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D76 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_038D79;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D76 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_038D79;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D76 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_038D79;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D76u,0x038D76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_038D79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D79u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D79u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D79 CMP
    cpu.compareA(0x1u);
    goto L_038D7B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D79u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D79 CMP
    cpu.compareA(0x1u);
    goto L_038D7B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D79u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D79 CMP
    cpu.compareA(0x1u);
    goto L_038D7B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D79u,0x038D79u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_038D7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D7B BNE -> $038D93
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_038D93; }
    goto L_038D7D;
L_038D7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D7D LDA
    cpu.setA(0x22u, 8);
    goto L_038D7F;
L_038D7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D7F STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_038D82;
L_038D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u, 5u, 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D82 STZ
    hw.write(cpu.address("absx", 0x1558u), 0, cpu.m8?8:16);
    goto L_038D85;
L_038D85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D85 STZ
    hw.write(cpu.address("dpx", 0xC2u), 0, cpu.m8?8:16);
    goto L_038D87;
L_038D87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D87 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_038D89;
L_038D89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D89 LSR
    cpu.lsrA();
    goto L_038D8A;
L_038D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D8A LSR
    cpu.lsrA();
    goto L_038D8B;
L_038D8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D8B LSR
    cpu.lsrA();
    goto L_038D8C;
L_038D8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D8C LSR
    cpu.lsrA();
    goto L_038D8D;
L_038D8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D8D AND
    cpu.logicAnd(0x1u);
    goto L_038D8F;
L_038D8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D8F INC
    cpu.inc('A');
    goto L_038D90;
L_038D90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D90u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D90u, 4u, 3u, cpu.address("abs", 0x1426u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D90 STA
    hw.write(cpu.address("abs", 0x1426u), cpu.a, cpu.m8?8:16);
    goto L_038D93;
L_038D93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D93u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D93u, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D93 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_038D96;
L_038D96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D96u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D96 LSR
    cpu.lsrA();
    goto L_038D97;
L_038D97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D97u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D97u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D97 TAY
    cpu.transfer("TAY");
    goto L_038D98;
L_038D98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D98u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D98u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D98 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_038D9A;
L_038D9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $038D9A PHA
    cpu.push("PHA", hw);
    goto L_038D9B;
L_038D9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D9B CLC
    cpu.setFlag('C', false);
    goto L_038D9C;
L_038D9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Cu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Cu, 4u + ((((0x8D66u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8D66u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D9C ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x8D66u), cpu.m8?8:16));
    goto L_038D9F;
L_038D9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038D9F STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_038DA1;
L_038DA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038DA1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_038DA3;
L_038DA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA3u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $038DA3 PHA
    cpu.push("PHA", hw);
    goto L_038DA4;
L_038DA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA4u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038DA4 ADC
    cpu.adc(0x0u);
    goto L_038DA6;
L_038DA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038DA6 STA
    hw.write(cpu.address("dp", 0x1Du), cpu.a, cpu.m8?8:16);
    goto L_038DA8;
L_038DA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA8u, 8u, 4u, 0x0190B2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $038DA8 JSL -> $0190B2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8DABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8DACu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0190B2u, 0x038DA8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_038DAC;
L_038DAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DACu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DACu,0x038DACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DACu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DACu, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038DAC LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_038DAF;
L_038DAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038DAF LDA
    cpu.setA(0xC0u, 8);
    goto L_038DB1;
L_038DB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB1u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB1u, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038DB1 STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_038DB4;
L_038DB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB4u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $038DB4 PLA
    cpu.pop("PLA", hw);
    goto L_038DB5;
L_038DB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038DB5 STA
    hw.write(cpu.address("dp", 0x1Du), cpu.a, cpu.m8?8:16);
    goto L_038DB7;
L_038DB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB7u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $038DB7 PLA
    cpu.pop("PLA", hw);
    goto L_038DB8;
L_038DB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $038DB8 STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_038DBA;
L_038DBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $038DBA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x038DBAu);return;} hw.unresolvedReturn(0x038DBAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04E76C_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04E76Cu: goto L_04E76C;
    case 0x04E76Fu: goto L_04E76F;
    case 0x04E771u: goto L_04E771;
    case 0x04E775u: goto L_04E775;
    case 0x04E776u: goto L_04E776;
    case 0x04E778u: goto L_04E778;
    case 0x04E77Cu: goto L_04E77C;
    case 0x04E77Du: goto L_04E77D;
    case 0x04E77Eu: goto L_04E77E;
    case 0x04E781u: goto L_04E781;
    case 0x04E783u: goto L_04E783;
    case 0x04E786u: goto L_04E786;
    case 0x04E788u: goto L_04E788;
    case 0x04E78Bu: goto L_04E78B;
    case 0x04E78Cu: goto L_04E78C;
    case 0x04E78Eu: goto L_04E78E;
    case 0x04E790u: goto L_04E790;
    case 0x04E793u: goto L_04E793;
    case 0x04E795u: goto L_04E795;
    case 0x04E797u: goto L_04E797;
    case 0x04E798u: goto L_04E798;
    case 0x04E799u: goto L_04E799;
    case 0x04E79Au: goto L_04E79A;
    case 0x04E79Bu: goto L_04E79B;
    case 0x04E79Cu: goto L_04E79C;
    case 0x04E7A0u: goto L_04E7A0;
    case 0x04E7A1u: goto L_04E7A1;
    case 0x04E7A2u: goto L_04E7A2;
    case 0x04E7A5u: goto L_04E7A5;
    case 0x04E7A7u: goto L_04E7A7;
    case 0x04E7A9u: goto L_04E7A9;
    case 0x04E7ABu: goto L_04E7AB;
    case 0x04E7ADu: goto L_04E7AD;
    case 0x04E7B1u: goto L_04E7B1;
    case 0x04E7B2u: goto L_04E7B2;
    case 0x04E7B3u: goto L_04E7B3;
    case 0x04E7B4u: goto L_04E7B4;
    case 0x04E7B5u: goto L_04E7B5;
    case 0x04E7B6u: goto L_04E7B6;
    case 0x04E7B9u: goto L_04E7B9;
    case 0x04E7BBu: goto L_04E7BB;
    case 0x04E7BDu: goto L_04E7BD;
    case 0x04E7BFu: goto L_04E7BF;
    case 0x04E7C0u: goto L_04E7C0;
    case 0x04E7C1u: goto L_04E7C1;
    case 0x04E7C4u: goto L_04E7C4;
    case 0x04E7C5u: goto L_04E7C5;
    case 0x04E7C8u: goto L_04E7C8;
    case 0x04E7C9u: goto L_04E7C9;
    case 0x04E7CBu: goto L_04E7CB;
    case 0x04E7CCu: goto L_04E7CC;
    case 0x04E7CFu: goto L_04E7CF;
    case 0x04E7D0u: goto L_04E7D0;
    case 0x04E7D3u: goto L_04E7D3;
    case 0x04E7D4u: goto L_04E7D4;
    case 0x04E7D8u: goto L_04E7D8;
    case 0x04E7D9u: goto L_04E7D9;
    case 0x04E7DAu: goto L_04E7DA;
    case 0x04E7DCu: goto L_04E7DC;
    case 0x04E7DDu: goto L_04E7DD;
    case 0x04E7DEu: goto L_04E7DE;
    case 0x04E7DFu: goto L_04E7DF;
    case 0x04E7E3u: goto L_04E7E3;
    case 0x04E7E4u: goto L_04E7E4;
    case 0x04E7E5u: goto L_04E7E5;
    case 0x04E7E7u: goto L_04E7E7;
    case 0x04E7E9u: goto L_04E7E9;
    case 0x04E7EBu: goto L_04E7EB;
    case 0x04E7ECu: goto L_04E7EC;
    case 0x04E7EDu: goto L_04E7ED;
    case 0x04E7F0u: goto L_04E7F0;
    case 0x04E7F1u: goto L_04E7F1;
    case 0x04E7F3u: goto L_04E7F3;
    case 0x04E7F5u: goto L_04E7F5;
    case 0x04E7F6u: goto L_04E7F6;
    case 0x04E7F7u: goto L_04E7F7;
    case 0x04E7FAu: goto L_04E7FA;
    case 0x04E7FCu: goto L_04E7FC;
    case 0x04E7FFu: goto L_04E7FF;
    case 0x04E801u: goto L_04E801;
    case 0x04E802u: goto L_04E802;
    case 0x04E805u: goto L_04E805;
    case 0x04E806u: goto L_04E806;
    case 0x04E809u: goto L_04E809;
    case 0x04E80Bu: goto L_04E80B;
    case 0x04E80Du: goto L_04E80D;
    case 0x04E80Eu: goto L_04E80E;
    case 0x04E80Fu: goto L_04E80F;
    case 0x04E812u: goto L_04E812;
    case 0x04E815u: goto L_04E815;
    case 0x04E816u: goto L_04E816;
    case 0x04E819u: goto L_04E819;
    case 0x04E81Au: goto L_04E81A;
    case 0x04E81Cu: goto L_04E81C;
    case 0x04E81Eu: goto L_04E81E;
    case 0x04E820u: goto L_04E820;
    case 0x04E823u: goto L_04E823;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04E76C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE76Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E76C LDA
    cpu.setA(0x1u, 16);
    goto L_04E76F;
L_04E76F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE76Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E76F STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_04E771;
L_04E771:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE771u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE771u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE771u, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E771 LDA
    cpu.loadA(hw.readW(0x7F837Bu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E775;
L_04E775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE775u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE775u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E775 TAX
    cpu.transfer("TAX");
    goto L_04E776;
L_04E776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE776u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE776u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE776u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E776 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E778;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE776u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE776u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E776 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E778;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE776u,0x04E776u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04E778:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE778u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE778u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE778u, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E778 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04E77C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE778u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE778u, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E778 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04E77C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE778u,0x04E778u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04E77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE77Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E77C INX
    cpu.inc('X');
    goto L_04E77D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E77C INX
    cpu.inc('X');
    goto L_04E77D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE77Cu,0x04E77Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04E77D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE77Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E77D INX
    cpu.inc('X');
    goto L_04E77E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E77D INX
    cpu.inc('X');
    goto L_04E77E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE77Du,0x04E77Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04E77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE77Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E77E LDY
    cpu.setY(0x300u, 16);
    goto L_04E781;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E77E LDY
    cpu.setY(0x300u, 16);
    goto L_04E781;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE77Eu,0x04E77Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04E781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE781u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE781u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE781u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E781 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E783;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE781u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE781u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E781 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E783;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE781u,0x04E781u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04E783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE783u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE783u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE783u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E783 AND
    cpu.logicAnd(0x1Fu);
    goto L_04E786;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE783u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE783u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E783 AND
    cpu.logicAnd(0x1Fu);
    goto L_04E786;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE783u,0x04E783u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04E786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE786u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE786u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE786u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E786 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_04E788;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE786u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE786u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E786 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_04E788;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE786u,0x04E786u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04E788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE788u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE788u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE788u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E788 LDA
    cpu.setA(0x20u, 16);
    goto L_04E78B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE788u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE788u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E788 LDA
    cpu.setA(0x20u, 16);
    goto L_04E78B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE788u,0x04E788u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04E78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE78Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E78B SEC
    cpu.setFlag('C', true);
    goto L_04E78C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E78B SEC
    cpu.setFlag('C', true);
    goto L_04E78C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE78Bu,0x04E78Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04E78C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE78Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Cu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E78C SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_04E78E;
L_04E78E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE78Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E78E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_04E790;
L_04E790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE790u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE790u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E790 CMP
    cpu.compareA(0x1u);
    goto L_04E793;
L_04E793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE793u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE793u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E793 BNE -> $04E79B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04E79B; }
    goto L_04E795;
L_04E795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE795u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE795u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E795 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E797;
L_04E797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE797u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE797u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E797 ASL
    cpu.aslA();
    goto L_04E798;
L_04E798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE798u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE798u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E798 DEC
    cpu.decReg('A');
    goto L_04E799;
L_04E799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE799u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE799u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E799 XBA
    cpu.xba();
    goto L_04E79A;
L_04E79A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE79Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E79A TAY
    cpu.transfer("TAY");
    goto L_04E79B;
L_04E79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE79Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E79B TYA
    cpu.transfer("TYA");
    goto L_04E79C;
L_04E79C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE79Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Cu, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E79C STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04E7A0;
L_04E7A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7A0 INX
    cpu.inc('X');
    goto L_04E7A1;
L_04E7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7A1 INX
    cpu.inc('X');
    goto L_04E7A2;
L_04E7A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7A2 LDA
    cpu.setA(0x1u, 16);
    goto L_04E7A5;
L_04E7A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7A5 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_04E7A7;
L_04E7A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A7u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7A7 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04E7A9;
L_04E7A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A9u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Cu) & 0xFFFFu), 3u, 0u);
    // $04E7A9 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E7AB;
L_04E7AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7ABu,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7AB AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_04E7AD;
L_04E7AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7ADu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7ADu, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7AD STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04E7B1;
L_04E7B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7B1 INX
    cpu.inc('X');
    goto L_04E7B2;
L_04E7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7B2 INX
    cpu.inc('X');
    goto L_04E7B3;
L_04E7B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7B3 INY
    cpu.inc('Y');
    goto L_04E7B4;
L_04E7B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B4u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7B4 INY
    cpu.inc('Y');
    goto L_04E7B5;
L_04E7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B5u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7B5 TYA
    cpu.transfer("TYA");
    goto L_04E7B6;
L_04E7B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7B6 AND
    cpu.logicAnd(0x3Fu);
    goto L_04E7B9;
L_04E7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7B9 BNE -> $04E7E5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04E7E5; }
    goto L_04E7BB;
L_04E7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7BB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E7BD;
L_04E7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7BD BEQ -> $04E7E5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04E7E5; }
    goto L_04E7BF;
L_04E7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BFu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7BF DEY
    cpu.decReg('Y');
    goto L_04E7C0;
L_04E7C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C0u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7C0 TYA
    cpu.transfer("TYA");
    goto L_04E7C1;
L_04E7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7C1 AND
    cpu.logicAnd(0xFFC0u);
    goto L_04E7C4;
L_04E7C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7C4 CLC
    cpu.setFlag('C', false);
    goto L_04E7C5;
L_04E7C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7C5 ADC
    cpu.adc(0x800u);
    goto L_04E7C8;
L_04E7C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C8u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7C8 TAY
    cpu.transfer("TAY");
    goto L_04E7C9;
L_04E7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7C9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E7CB;
L_04E7CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CBu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7CB XBA
    cpu.xba();
    goto L_04E7CC;
L_04E7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7CC AND
    cpu.logicAnd(0x3BE0u);
    goto L_04E7CF;
L_04E7CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7CF CLC
    cpu.setFlag('C', false);
    goto L_04E7D0;
L_04E7D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7D0 ADC
    cpu.adc(0x400u);
    goto L_04E7D3;
L_04E7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D3u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7D3 XBA
    cpu.xba();
    goto L_04E7D4;
L_04E7D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D4u, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7D4 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04E7D8;
L_04E7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D8u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7D8 INX
    cpu.inc('X');
    goto L_04E7D9;
L_04E7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7D9 INX
    cpu.inc('X');
    goto L_04E7DA;
L_04E7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E7DC;
L_04E7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7DC ASL
    cpu.aslA();
    goto L_04E7DD;
L_04E7DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DDu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7DD DEC
    cpu.decReg('A');
    goto L_04E7DE;
L_04E7DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DEu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7DE XBA
    cpu.xba();
    goto L_04E7DF;
L_04E7DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DFu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DFu, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7DF STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04E7E3;
L_04E7E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7E3 INX
    cpu.inc('X');
    goto L_04E7E4;
L_04E7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7E4 INX
    cpu.inc('X');
    goto L_04E7E5;
L_04E7E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E5u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7E5 DEC
    cpu.decMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_04E7E7;
L_04E7E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7E7 BPL -> $04E7A9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04E7A9; }
    goto L_04E7E9;
L_04E7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E7EB;
L_04E7EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7EBu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7EBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7EB XBA
    cpu.xba();
    goto L_04E7EC;
L_04E7EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7ECu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7EC CLC
    cpu.setFlag('C', false);
    goto L_04E7ED;
L_04E7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7EDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7EDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7ED ADC
    cpu.adc(0x20u);
    goto L_04E7F0;
L_04E7F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F0u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7F0 XBA
    cpu.xba();
    goto L_04E7F1;
L_04E7F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7F1 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04E7F3;
L_04E7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7F3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E7F5;
L_04E7F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F5u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7F5 TAY
    cpu.transfer("TAY");
    goto L_04E7F6;
L_04E7F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7F6 CLC
    cpu.setFlag('C', false);
    goto L_04E7F7;
L_04E7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7F7 ADC
    cpu.adc(0x40u);
    goto L_04E7FA;
L_04E7FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7FAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7FAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7FA STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04E7FC;
L_04E7FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7FCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7FC AND
    cpu.logicAnd(0x7C0u);
    goto L_04E7FF;
L_04E7FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7FFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7FF BNE -> $04E81C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04E81C; }
    goto L_04E801;
L_04E801:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE801u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE801u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE801u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E801 TYA
    cpu.transfer("TYA");
    goto L_04E802;
L_04E802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE802u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE802u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E802 AND
    cpu.logicAnd(0xF83Fu);
    goto L_04E805;
L_04E805:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE805u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE805u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE805u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E805 CLC
    cpu.setFlag('C', false);
    goto L_04E806;
L_04E806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE806u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE806u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E806 ADC
    cpu.adc(0x1000u);
    goto L_04E809;
L_04E809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE809u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE809u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E809 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04E80B;
L_04E80B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE80Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE80Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE80Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E80B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E80D;
L_04E80D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE80Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE80Du,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE80Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E80D XBA
    cpu.xba();
    goto L_04E80E;
L_04E80E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE80Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE80Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE80Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E80E SEC
    cpu.setFlag('C', true);
    goto L_04E80F;
L_04E80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE80Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE80Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE80Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E80F SBC
    cpu.sbc(0x20u);
    goto L_04E812;
L_04E812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE812u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE812u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E812 AND
    cpu.logicAnd(0x341Fu);
    goto L_04E815;
L_04E815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE815u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE815u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E815 CLC
    cpu.setFlag('C', false);
    goto L_04E816;
L_04E816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE816u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE816u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E816 ADC
    cpu.adc(0x800u);
    goto L_04E819;
L_04E819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE819u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE819u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE819u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E819 XBA
    cpu.xba();
    goto L_04E81A;
L_04E81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE81Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE81Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE81Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E81A STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04E81C;
L_04E81C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE81Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE81Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE81Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E81C DEC
    cpu.decMem(hw, cpu.address("dp", 0x6u), cpu.m8?8:16);
    goto L_04E81E;
L_04E81E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE81Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE81Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE81Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E81E BMI -> $04E823
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_04E823; }
    goto L_04E820;
L_04E820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE820u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE820u, 3u, 3u, cpu.address("abs", 0xE776u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E820 JMP -> $04E776
    goto L_04E776;
L_04E823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE823u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE823u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04E823 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04E823u);return;} hw.unresolvedReturn(0x04E823u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04E76C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04E76Cu: goto L_04E76C;
    case 0x04E76Fu: goto L_04E76F;
    case 0x04E771u: goto L_04E771;
    case 0x04E775u: goto L_04E775;
    case 0x04E776u: goto L_04E776;
    case 0x04E778u: goto L_04E778;
    case 0x04E77Cu: goto L_04E77C;
    case 0x04E77Du: goto L_04E77D;
    case 0x04E77Eu: goto L_04E77E;
    case 0x04E781u: goto L_04E781;
    case 0x04E783u: goto L_04E783;
    case 0x04E786u: goto L_04E786;
    case 0x04E788u: goto L_04E788;
    case 0x04E78Bu: goto L_04E78B;
    case 0x04E78Cu: goto L_04E78C;
    case 0x04E78Eu: goto L_04E78E;
    case 0x04E790u: goto L_04E790;
    case 0x04E793u: goto L_04E793;
    case 0x04E795u: goto L_04E795;
    case 0x04E797u: goto L_04E797;
    case 0x04E798u: goto L_04E798;
    case 0x04E799u: goto L_04E799;
    case 0x04E79Au: goto L_04E79A;
    case 0x04E79Bu: goto L_04E79B;
    case 0x04E79Cu: goto L_04E79C;
    case 0x04E7A0u: goto L_04E7A0;
    case 0x04E7A1u: goto L_04E7A1;
    case 0x04E7A2u: goto L_04E7A2;
    case 0x04E7A5u: goto L_04E7A5;
    case 0x04E7A7u: goto L_04E7A7;
    case 0x04E7A9u: goto L_04E7A9;
    case 0x04E7ABu: goto L_04E7AB;
    case 0x04E7ADu: goto L_04E7AD;
    case 0x04E7B1u: goto L_04E7B1;
    case 0x04E7B2u: goto L_04E7B2;
    case 0x04E7B3u: goto L_04E7B3;
    case 0x04E7B4u: goto L_04E7B4;
    case 0x04E7B5u: goto L_04E7B5;
    case 0x04E7B6u: goto L_04E7B6;
    case 0x04E7B9u: goto L_04E7B9;
    case 0x04E7BBu: goto L_04E7BB;
    case 0x04E7BDu: goto L_04E7BD;
    case 0x04E7BFu: goto L_04E7BF;
    case 0x04E7C0u: goto L_04E7C0;
    case 0x04E7C1u: goto L_04E7C1;
    case 0x04E7C4u: goto L_04E7C4;
    case 0x04E7C5u: goto L_04E7C5;
    case 0x04E7C8u: goto L_04E7C8;
    case 0x04E7C9u: goto L_04E7C9;
    case 0x04E7CBu: goto L_04E7CB;
    case 0x04E7CCu: goto L_04E7CC;
    case 0x04E7CFu: goto L_04E7CF;
    case 0x04E7D0u: goto L_04E7D0;
    case 0x04E7D3u: goto L_04E7D3;
    case 0x04E7D4u: goto L_04E7D4;
    case 0x04E7D8u: goto L_04E7D8;
    case 0x04E7D9u: goto L_04E7D9;
    case 0x04E7DAu: goto L_04E7DA;
    case 0x04E7DCu: goto L_04E7DC;
    case 0x04E7DDu: goto L_04E7DD;
    case 0x04E7DEu: goto L_04E7DE;
    case 0x04E7DFu: goto L_04E7DF;
    case 0x04E7E3u: goto L_04E7E3;
    case 0x04E7E4u: goto L_04E7E4;
    case 0x04E7E5u: goto L_04E7E5;
    case 0x04E7E7u: goto L_04E7E7;
    case 0x04E7E9u: goto L_04E7E9;
    case 0x04E7EBu: goto L_04E7EB;
    case 0x04E7ECu: goto L_04E7EC;
    case 0x04E7EDu: goto L_04E7ED;
    case 0x04E7F0u: goto L_04E7F0;
    case 0x04E7F1u: goto L_04E7F1;
    case 0x04E7F3u: goto L_04E7F3;
    case 0x04E7F5u: goto L_04E7F5;
    case 0x04E7F6u: goto L_04E7F6;
    case 0x04E7F7u: goto L_04E7F7;
    case 0x04E7FAu: goto L_04E7FA;
    case 0x04E7FCu: goto L_04E7FC;
    case 0x04E7FFu: goto L_04E7FF;
    case 0x04E801u: goto L_04E801;
    case 0x04E802u: goto L_04E802;
    case 0x04E805u: goto L_04E805;
    case 0x04E806u: goto L_04E806;
    case 0x04E809u: goto L_04E809;
    case 0x04E80Bu: goto L_04E80B;
    case 0x04E80Du: goto L_04E80D;
    case 0x04E80Eu: goto L_04E80E;
    case 0x04E80Fu: goto L_04E80F;
    case 0x04E812u: goto L_04E812;
    case 0x04E815u: goto L_04E815;
    case 0x04E816u: goto L_04E816;
    case 0x04E819u: goto L_04E819;
    case 0x04E81Au: goto L_04E81A;
    case 0x04E81Cu: goto L_04E81C;
    case 0x04E81Eu: goto L_04E81E;
    case 0x04E820u: goto L_04E820;
    case 0x04E823u: goto L_04E823;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04E76C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE76Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E76C LDA
    cpu.setA(0x1u, 16);
    goto L_04E76F;
L_04E76F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE76Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E76F STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_04E771;
L_04E771:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE771u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE771u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE771u, 6u, 4u, 0x7F837Bu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E771 LDA
    cpu.loadA(hw.readW(0x7F837Bu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E775;
L_04E775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE775u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE775u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E775 TAX
    cpu.transfer("TAX");
    goto L_04E776;
L_04E776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE776u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE776u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E776 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E778;
L_04E778:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE778u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE778u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE778u, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E778 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04E77C;
L_04E77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE77Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E77C INX
    cpu.inc('X');
    goto L_04E77D;
L_04E77D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE77Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E77D INX
    cpu.inc('X');
    goto L_04E77E;
L_04E77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE77Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E77E LDY
    cpu.setY(0x300u, 16);
    goto L_04E781;
L_04E781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE781u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE781u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E781 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E783;
L_04E783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE783u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE783u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E783 AND
    cpu.logicAnd(0x1Fu);
    goto L_04E786;
L_04E786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE786u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE786u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E786 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_04E788;
L_04E788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE788u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE788u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E788 LDA
    cpu.setA(0x20u, 16);
    goto L_04E78B;
L_04E78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E78B SEC
    cpu.setFlag('C', true);
    goto L_04E78C;
L_04E78C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE78Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Cu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E78C SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_04E78E;
L_04E78E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE78Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE78Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E78E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_04E790;
L_04E790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE790u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE790u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E790 CMP
    cpu.compareA(0x1u);
    goto L_04E793;
L_04E793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE793u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE793u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E793 BNE -> $04E79B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04E79B; }
    goto L_04E795;
L_04E795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE795u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE795u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E795 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E797;
L_04E797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE797u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE797u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E797 ASL
    cpu.aslA();
    goto L_04E798;
L_04E798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE798u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE798u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E798 DEC
    cpu.decReg('A');
    goto L_04E799;
L_04E799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE799u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE799u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E799 XBA
    cpu.xba();
    goto L_04E79A;
L_04E79A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE79Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E79A TAY
    cpu.transfer("TAY");
    goto L_04E79B;
L_04E79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE79Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E79B TYA
    cpu.transfer("TYA");
    goto L_04E79C;
L_04E79C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE79Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE79Cu, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E79C STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04E7A0;
L_04E7A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7A0 INX
    cpu.inc('X');
    goto L_04E7A1;
L_04E7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7A1 INX
    cpu.inc('X');
    goto L_04E7A2;
L_04E7A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7A2 LDA
    cpu.setA(0x1u, 16);
    goto L_04E7A5;
L_04E7A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7A5 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_04E7A7;
L_04E7A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A7u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7A7 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04E7A9;
L_04E7A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A9u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7A9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Cu) & 0xFFFFu), 3u, 0u);
    // $04E7A9 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E7AB;
L_04E7AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7ABu,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7AB AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_04E7AD;
L_04E7AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7ADu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7ADu, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7AD STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04E7B1;
L_04E7B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7B1 INX
    cpu.inc('X');
    goto L_04E7B2;
L_04E7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7B2 INX
    cpu.inc('X');
    goto L_04E7B3;
L_04E7B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7B3 INY
    cpu.inc('Y');
    goto L_04E7B4;
L_04E7B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B4u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7B4 INY
    cpu.inc('Y');
    goto L_04E7B5;
L_04E7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B5u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7B5 TYA
    cpu.transfer("TYA");
    goto L_04E7B6;
L_04E7B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7B6 AND
    cpu.logicAnd(0x3Fu);
    goto L_04E7B9;
L_04E7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7B9 BNE -> $04E7E5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04E7E5; }
    goto L_04E7BB;
L_04E7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7BB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E7BD;
L_04E7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7BD BEQ -> $04E7E5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04E7E5; }
    goto L_04E7BF;
L_04E7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BFu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7BFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7BF DEY
    cpu.decReg('Y');
    goto L_04E7C0;
L_04E7C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C0u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7C0 TYA
    cpu.transfer("TYA");
    goto L_04E7C1;
L_04E7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7C1 AND
    cpu.logicAnd(0xFFC0u);
    goto L_04E7C4;
L_04E7C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7C4 CLC
    cpu.setFlag('C', false);
    goto L_04E7C5;
L_04E7C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7C5 ADC
    cpu.adc(0x800u);
    goto L_04E7C8;
L_04E7C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C8u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7C8 TAY
    cpu.transfer("TAY");
    goto L_04E7C9;
L_04E7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7C9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7C9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E7CB;
L_04E7CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CBu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7CB XBA
    cpu.xba();
    goto L_04E7CC;
L_04E7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7CC AND
    cpu.logicAnd(0x3BE0u);
    goto L_04E7CF;
L_04E7CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7CF CLC
    cpu.setFlag('C', false);
    goto L_04E7D0;
L_04E7D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7D0 ADC
    cpu.adc(0x400u);
    goto L_04E7D3;
L_04E7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D3u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7D3 XBA
    cpu.xba();
    goto L_04E7D4;
L_04E7D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D4u, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7D4 STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04E7D8;
L_04E7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D8u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7D8 INX
    cpu.inc('X');
    goto L_04E7D9;
L_04E7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7D9 INX
    cpu.inc('X');
    goto L_04E7DA;
L_04E7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E7DC;
L_04E7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7DC ASL
    cpu.aslA();
    goto L_04E7DD;
L_04E7DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DDu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7DD DEC
    cpu.decReg('A');
    goto L_04E7DE;
L_04E7DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DEu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7DE XBA
    cpu.xba();
    goto L_04E7DF;
L_04E7DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DFu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7DFu, 6u, 4u, ((0x7F837Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7DF STA
    hw.write(((0x7F837Du + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_04E7E3;
L_04E7E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7E3 INX
    cpu.inc('X');
    goto L_04E7E4;
L_04E7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7E4 INX
    cpu.inc('X');
    goto L_04E7E5;
L_04E7E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E5u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7E5 DEC
    cpu.decMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_04E7E7;
L_04E7E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7E7 BPL -> $04E7A9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04E7A9; }
    goto L_04E7E9;
L_04E7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E7EB;
L_04E7EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7EBu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7EBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7EB XBA
    cpu.xba();
    goto L_04E7EC;
L_04E7EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7ECu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7EC CLC
    cpu.setFlag('C', false);
    goto L_04E7ED;
L_04E7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7EDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7EDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7ED ADC
    cpu.adc(0x20u);
    goto L_04E7F0;
L_04E7F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F0u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7F0 XBA
    cpu.xba();
    goto L_04E7F1;
L_04E7F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7F1 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04E7F3;
L_04E7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7F3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E7F5;
L_04E7F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F5u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7F5 TAY
    cpu.transfer("TAY");
    goto L_04E7F6;
L_04E7F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7F6 CLC
    cpu.setFlag('C', false);
    goto L_04E7F7;
L_04E7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F7u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7F7 ADC
    cpu.adc(0x40u);
    goto L_04E7FA;
L_04E7FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7FAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7FAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7FA STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04E7FC;
L_04E7FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7FCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7FC AND
    cpu.logicAnd(0x7C0u);
    goto L_04E7FF;
L_04E7FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE7FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE7FFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE7FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E7FF BNE -> $04E81C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04E81C; }
    goto L_04E801;
L_04E801:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE801u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE801u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE801u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E801 TYA
    cpu.transfer("TYA");
    goto L_04E802;
L_04E802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE802u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE802u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E802 AND
    cpu.logicAnd(0xF83Fu);
    goto L_04E805;
L_04E805:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE805u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE805u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE805u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E805 CLC
    cpu.setFlag('C', false);
    goto L_04E806;
L_04E806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE806u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE806u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E806 ADC
    cpu.adc(0x1000u);
    goto L_04E809;
L_04E809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE809u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE809u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E809 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04E80B;
L_04E80B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE80Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE80Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE80Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E80B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E80D;
L_04E80D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE80Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE80Du,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE80Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E80D XBA
    cpu.xba();
    goto L_04E80E;
L_04E80E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE80Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE80Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE80Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E80E SEC
    cpu.setFlag('C', true);
    goto L_04E80F;
L_04E80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE80Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE80Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE80Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E80F SBC
    cpu.sbc(0x20u);
    goto L_04E812;
L_04E812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE812u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE812u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E812 AND
    cpu.logicAnd(0x341Fu);
    goto L_04E815;
L_04E815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE815u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE815u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E815 CLC
    cpu.setFlag('C', false);
    goto L_04E816;
L_04E816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE816u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE816u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E816 ADC
    cpu.adc(0x800u);
    goto L_04E819;
L_04E819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE819u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE819u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE819u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E819 XBA
    cpu.xba();
    goto L_04E81A;
L_04E81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE81Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE81Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE81Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E81A STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04E81C;
L_04E81C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE81Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE81Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE81Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E81C DEC
    cpu.decMem(hw, cpu.address("dp", 0x6u), cpu.m8?8:16);
    goto L_04E81E;
L_04E81E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE81Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE81Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE81Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E81E BMI -> $04E823
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_04E823; }
    goto L_04E820;
L_04E820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE820u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE820u, 3u, 3u, cpu.address("abs", 0xE776u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E820 JMP -> $04E776
    goto L_04E776;
L_04E823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE823u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE823u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04E823 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04E823u);return;} hw.unresolvedReturn(0x04E823u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DA8C3_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DA8C3u: goto L_0DA8C3;
    case 0x0DA8C5u: goto L_0DA8C5;
    case 0x0DA8C7u: goto L_0DA8C7;
    case 0x0DA8C9u: goto L_0DA8C9;
    case 0x0DA8CBu: goto L_0DA8CB;
    case 0x0DA8CDu: goto L_0DA8CD;
    case 0x0DA8CFu: goto L_0DA8CF;
    case 0x0DA8D0u: goto L_0DA8D0;
    case 0x0DA8D1u: goto L_0DA8D1;
    case 0x0DA8D2u: goto L_0DA8D2;
    case 0x0DA8D3u: goto L_0DA8D3;
    case 0x0DA8D5u: goto L_0DA8D5;
    case 0x0DA8D8u: goto L_0DA8D8;
    case 0x0DA8DAu: goto L_0DA8DA;
    case 0x0DA8DCu: goto L_0DA8DC;
    case 0x0DA8DDu: goto L_0DA8DD;
    case 0x0DA8DEu: goto L_0DA8DE;
    case 0x0DA8DFu: goto L_0DA8DF;
    case 0x0DA8E0u: goto L_0DA8E0;
    case 0x0DA8E3u: goto L_0DA8E3;
    case 0x0DA8E5u: goto L_0DA8E5;
    case 0x0DA8E6u: goto L_0DA8E6;
    case 0x0DA8EAu: goto L_0DA8EA;
    case 0x0DA8ECu: goto L_0DA8EC;
    case 0x0DA8EEu: goto L_0DA8EE;
    case 0x0DA8F2u: goto L_0DA8F2;
    case 0x0DA8F4u: goto L_0DA8F4;
    case 0x0DA8F7u: goto L_0DA8F7;
    case 0x0DA8F8u: goto L_0DA8F8;
    case 0x0DA8F9u: goto L_0DA8F9;
    case 0x0DA8FBu: goto L_0DA8FB;
    case 0x0DA8FDu: goto L_0DA8FD;
    case 0x0DA8FFu: goto L_0DA8FF;
    case 0x0DA901u: goto L_0DA901;
    case 0x0DA903u: goto L_0DA903;
    case 0x0DA905u: goto L_0DA905;
    case 0x0DA907u: goto L_0DA907;
    case 0x0DA908u: goto L_0DA908;
    case 0x0DA90Au: goto L_0DA90A;
    case 0x0DA90Cu: goto L_0DA90C;
    case 0x0DA90Eu: goto L_0DA90E;
    case 0x0DA910u: goto L_0DA910;
    case 0x0DA912u: goto L_0DA912;
    case 0x0DA913u: goto L_0DA913;
    case 0x0DA915u: goto L_0DA915;
    case 0x0DA916u: goto L_0DA916;
    case 0x0DA918u: goto L_0DA918;
    case 0x0DA91Au: goto L_0DA91A;
    case 0x0DA91Eu: goto L_0DA91E;
    case 0x0DA920u: goto L_0DA920;
    case 0x0DA921u: goto L_0DA921;
    case 0x0DA922u: goto L_0DA922;
    case 0x0DA923u: goto L_0DA923;
    case 0x0DA924u: goto L_0DA924;
    case 0x0DA926u: goto L_0DA926;
    case 0x0DA928u: goto L_0DA928;
    case 0x0DA92Bu: goto L_0DA92B;
    case 0x0DA92Eu: goto L_0DA92E;
    case 0x0DA932u: goto L_0DA932;
    case 0x0DA934u: goto L_0DA934;
    case 0x0DA937u: goto L_0DA937;
    case 0x0DA939u: goto L_0DA939;
    case 0x0DA93Bu: goto L_0DA93B;
    case 0x0DA93Eu: goto L_0DA93E;
    case 0x0DA940u: goto L_0DA940;
    case 0x0DA943u: goto L_0DA943;
    case 0x0DA945u: goto L_0DA945;
    case 0x0DA947u: goto L_0DA947;
    case 0x0DA949u: goto L_0DA949;
    case 0x0DA94Cu: goto L_0DA94C;
    case 0x0DA94Fu: goto L_0DA94F;
    case 0x0DA951u: goto L_0DA951;
    case 0x0DA953u: goto L_0DA953;
    case 0x0DA955u: goto L_0DA955;
    case 0x0DA957u: goto L_0DA957;
    case 0x0DA95Au: goto L_0DA95A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DA8C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C3u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8C3 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DA8C5;
L_0DA8C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8C5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA8C7;
L_0DA8C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8C7 AND
    cpu.logicAnd(0xFu);
    goto L_0DA8C9;
L_0DA8C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8C9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DA8CB;
L_0DA8CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8CB STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DA8CD;
L_0DA8CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8CD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA8CF;
L_0DA8CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8CF LSR
    cpu.lsrA();
    goto L_0DA8D0;
L_0DA8D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8D0 LSR
    cpu.lsrA();
    goto L_0DA8D1;
L_0DA8D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8D1 LSR
    cpu.lsrA();
    goto L_0DA8D2;
L_0DA8D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8D2 LSR
    cpu.lsrA();
    goto L_0DA8D3;
L_0DA8D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8D3 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DA8D5;
L_0DA8D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D5u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA8D5 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xA8D7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8D8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DA8D5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA8D8;
L_0DA8D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8D8u,0x0DA8D8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D8u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8D8 CPX
    cpu.compareX(0x4u);
    goto L_0DA8DA;
L_0DA8DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8DA BNE -> $0DA92E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA92E; }
    goto L_0DA8DC;
L_0DA8DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DCu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8DC TXA
    cpu.transfer("TXA");
    goto L_0DA8DD;
L_0DA8DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DDu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DDu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0DA8DD PHA
    cpu.push("PHA", hw);
    goto L_0DA8DE;
L_0DA8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DEu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8DE TYA
    cpu.transfer("TYA");
    goto L_0DA8DF;
L_0DA8DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DFu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0DA8DF PHA
    cpu.push("PHA", hw);
    goto L_0DA8E0;
L_0DA8E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E0u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E0u, 4u, 3u, cpu.address("abs", 0x13BEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8E0 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13BEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DA8E3;
L_0DA8E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8E3 LDA
    cpu.setA(0xF8u, 8);
    goto L_0DA8E5;
L_0DA8E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8E5 CLC
    cpu.setFlag('C', false);
    goto L_0DA8E6;
L_0DA8E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E6u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E6u, 5u, 4u, ((0x0DA8AEu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8E6 ADC
    cpu.adc(hw.readW(((0xDA8AEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DA8EA;
L_0DA8EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8EA STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_0DA8EC;
L_0DA8EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8EC LDA
    cpu.setA(0x19u, 8);
    goto L_0DA8EE;
L_0DA8EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu, 5u, 4u, ((0x0DA8B1u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8EE ADC
    cpu.adc(hw.readW(((0xDA8B1u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DA8F2;
L_0DA8F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8F2 STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_0DA8F4;
L_0DA8F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F4u, 4u, 3u, cpu.address("abs", 0x1BA1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8F4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA8F7;
L_0DA8F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8F7 ASL
    cpu.aslA();
    goto L_0DA8F8;
L_0DA8F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8F8 ASL
    cpu.aslA();
    goto L_0DA8F9;
L_0DA8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8F9 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0DA8FB;
L_0DA8FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA8FD;
L_0DA8FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8FD AND
    cpu.logicAnd(0x10u);
    goto L_0DA8FF;
L_0DA8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8FF BEQ -> $0DA907
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA907; }
    goto L_0DA901;
L_0DA901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA901u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA901u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA901 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA903;
L_0DA903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA903 ORA
    cpu.logicOr(0x2u);
    goto L_0DA905;
L_0DA905:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA905u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA905u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA905u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA905 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0DA907;
L_0DA907:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA907u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA907u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA907u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA907 TYA
    cpu.transfer("TYA");
    goto L_0DA908;
L_0DA908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA908 AND
    cpu.logicAnd(0x8u);
    goto L_0DA90A;
L_0DA90A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA90A BEQ -> $0DA912
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA912; }
    goto L_0DA90C;
L_0DA90C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA90C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA90E;
L_0DA90E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA90E ORA
    cpu.logicOr(0x1u);
    goto L_0DA910;
L_0DA910:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA910u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA910u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA910u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA910 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0DA912;
L_0DA912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA912u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA912u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA912 TYA
    cpu.transfer("TYA");
    goto L_0DA913;
L_0DA913:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA913u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA913u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA913u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA913 AND
    cpu.logicAnd(0x7u);
    goto L_0DA915;
L_0DA915:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA915u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA915u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA915u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA915 TAX
    cpu.transfer("TAX");
    goto L_0DA916;
L_0DA916:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA916u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA916u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA916u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA916 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DA918;
L_0DA918:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA918u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA918u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA918u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x08u) & 0xFFFFu), 2u, 0u);
    // $0DA918 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA91A;
L_0DA91A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Au,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Au, 5u, 4u, ((0x0DA8A6u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA91A AND
    cpu.logicAnd(hw.readW(((0xDA8A6u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DA91E;
L_0DA91E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA91E STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_0DA920;
L_0DA920:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA920u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA920u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA920u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0DA920 PLA
    cpu.pop("PLA", hw);
    goto L_0DA921;
L_0DA921:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA921u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA921u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA921u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA921 TAY
    cpu.transfer("TAY");
    goto L_0DA922;
L_0DA922:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA922u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA922u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA922u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0DA922 PLA
    cpu.pop("PLA", hw);
    goto L_0DA923;
L_0DA923:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA923u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA923u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA923u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA923 TAX
    cpu.transfer("TAX");
    goto L_0DA924;
L_0DA924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA924u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA924u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA924u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA924 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA926;
L_0DA926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA926u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA926u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA926 BEQ -> $0DA92E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA92E; }
    goto L_0DA928;
L_0DA928:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA928u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA928u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA928u, 6u, 3u, cpu.address("abs", 0xA95Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA928 JSR -> $0DA95D stack real
    { cpu.push16Value(hw,0xA92Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA92Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Du), 0x0DA928u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA92B;
L_0DA92B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA92Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA92Bu,0x0DA92Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Bu, 3u, 3u, cpu.address("abs", 0xA943u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA92B JMP -> $0DA943
    goto L_0DA943;
L_0DA92E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA92Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Eu, 5u, 4u, ((0x0DA8B4u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA92E LDA
    cpu.loadA(hw.readW(((0xDA8B4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA932;
L_0DA932:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA932u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA932u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA932u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA932 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_0DA934;
L_0DA934:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA934u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA934u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA934u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA934 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xA936u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA937u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DA934u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA937;
L_0DA937:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA937u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA937u,0x0DA937u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA937u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA937u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA937 CPX
    cpu.compareX(0x7u);
    goto L_0DA939;
L_0DA939:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA939u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA939u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA939u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA939 BMI -> $0DA93E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DA93E; }
    goto L_0DA93B;
L_0DA93B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA93Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Bu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA93B JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xA93Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA93Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DA93Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA93E;
L_0DA93E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA93Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA93Eu,0x0DA93Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA93E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA940;
L_0DA940:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA940u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA940u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA940u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA940 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xA942u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA943u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DA940u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA943;
L_0DA943:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA943u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA943u,0x0DA943u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA943u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA943u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA943 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DA945;
L_0DA945:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA945u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA945u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA945u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA945 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA947;
L_0DA947:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA947u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA947u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA947u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA947 BPL -> $0DA8D8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DA8D8; }
    goto L_0DA949;
L_0DA949:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA949u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA949u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA949u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA949 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xA94Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA94Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DA949u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA94C;
L_0DA94C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA94Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA94Cu,0x0DA94Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Cu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA94C JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xA94Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA94Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DA94Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA94F;
L_0DA94F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA94Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA94Fu,0x0DA94Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA94F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA951;
L_0DA951:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA951u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA951u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA951u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA951 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DA953;
L_0DA953:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA953u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA953u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA953u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA953 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DA955;
L_0DA955:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA955u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA955u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA955u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA955 BMI -> $0DA95A
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DA95A; }
    goto L_0DA957;
L_0DA957:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA957u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA957u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA957u, 3u, 3u, cpu.address("abs", 0xA8D8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA957 JMP -> $0DA8D8
    goto L_0DA8D8;
L_0DA95A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA95A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA95Au);return;} hw.unresolvedReturn(0x0DA95Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DA8C3_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DA8C3u: goto L_0DA8C3;
    case 0x0DA8C5u: goto L_0DA8C5;
    case 0x0DA8C7u: goto L_0DA8C7;
    case 0x0DA8C9u: goto L_0DA8C9;
    case 0x0DA8CBu: goto L_0DA8CB;
    case 0x0DA8CDu: goto L_0DA8CD;
    case 0x0DA8CFu: goto L_0DA8CF;
    case 0x0DA8D0u: goto L_0DA8D0;
    case 0x0DA8D1u: goto L_0DA8D1;
    case 0x0DA8D2u: goto L_0DA8D2;
    case 0x0DA8D3u: goto L_0DA8D3;
    case 0x0DA8D5u: goto L_0DA8D5;
    case 0x0DA8D8u: goto L_0DA8D8;
    case 0x0DA8DAu: goto L_0DA8DA;
    case 0x0DA8DCu: goto L_0DA8DC;
    case 0x0DA8DDu: goto L_0DA8DD;
    case 0x0DA8DEu: goto L_0DA8DE;
    case 0x0DA8DFu: goto L_0DA8DF;
    case 0x0DA8E0u: goto L_0DA8E0;
    case 0x0DA8E3u: goto L_0DA8E3;
    case 0x0DA8E5u: goto L_0DA8E5;
    case 0x0DA8E6u: goto L_0DA8E6;
    case 0x0DA8EAu: goto L_0DA8EA;
    case 0x0DA8ECu: goto L_0DA8EC;
    case 0x0DA8EEu: goto L_0DA8EE;
    case 0x0DA8F2u: goto L_0DA8F2;
    case 0x0DA8F4u: goto L_0DA8F4;
    case 0x0DA8F7u: goto L_0DA8F7;
    case 0x0DA8F8u: goto L_0DA8F8;
    case 0x0DA8F9u: goto L_0DA8F9;
    case 0x0DA8FBu: goto L_0DA8FB;
    case 0x0DA8FDu: goto L_0DA8FD;
    case 0x0DA8FFu: goto L_0DA8FF;
    case 0x0DA901u: goto L_0DA901;
    case 0x0DA903u: goto L_0DA903;
    case 0x0DA905u: goto L_0DA905;
    case 0x0DA907u: goto L_0DA907;
    case 0x0DA908u: goto L_0DA908;
    case 0x0DA90Au: goto L_0DA90A;
    case 0x0DA90Cu: goto L_0DA90C;
    case 0x0DA90Eu: goto L_0DA90E;
    case 0x0DA910u: goto L_0DA910;
    case 0x0DA912u: goto L_0DA912;
    case 0x0DA913u: goto L_0DA913;
    case 0x0DA915u: goto L_0DA915;
    case 0x0DA916u: goto L_0DA916;
    case 0x0DA918u: goto L_0DA918;
    case 0x0DA91Au: goto L_0DA91A;
    case 0x0DA91Eu: goto L_0DA91E;
    case 0x0DA920u: goto L_0DA920;
    case 0x0DA921u: goto L_0DA921;
    case 0x0DA922u: goto L_0DA922;
    case 0x0DA923u: goto L_0DA923;
    case 0x0DA924u: goto L_0DA924;
    case 0x0DA926u: goto L_0DA926;
    case 0x0DA928u: goto L_0DA928;
    case 0x0DA92Bu: goto L_0DA92B;
    case 0x0DA92Eu: goto L_0DA92E;
    case 0x0DA932u: goto L_0DA932;
    case 0x0DA934u: goto L_0DA934;
    case 0x0DA937u: goto L_0DA937;
    case 0x0DA939u: goto L_0DA939;
    case 0x0DA93Bu: goto L_0DA93B;
    case 0x0DA93Eu: goto L_0DA93E;
    case 0x0DA940u: goto L_0DA940;
    case 0x0DA943u: goto L_0DA943;
    case 0x0DA945u: goto L_0DA945;
    case 0x0DA947u: goto L_0DA947;
    case 0x0DA949u: goto L_0DA949;
    case 0x0DA94Cu: goto L_0DA94C;
    case 0x0DA94Fu: goto L_0DA94F;
    case 0x0DA951u: goto L_0DA951;
    case 0x0DA953u: goto L_0DA953;
    case 0x0DA955u: goto L_0DA955;
    case 0x0DA957u: goto L_0DA957;
    case 0x0DA95Au: goto L_0DA95A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DA8C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C3u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8C3 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DA8C5;
L_0DA8C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8C5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA8C7;
L_0DA8C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8C7 AND
    cpu.logicAnd(0xFu);
    goto L_0DA8C9;
L_0DA8C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8C9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8C9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DA8CB;
L_0DA8CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8CB STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DA8CD;
L_0DA8CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8CD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA8CF;
L_0DA8CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8CF LSR
    cpu.lsrA();
    goto L_0DA8D0;
L_0DA8D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8D0 LSR
    cpu.lsrA();
    goto L_0DA8D1;
L_0DA8D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8D1 LSR
    cpu.lsrA();
    goto L_0DA8D2;
L_0DA8D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8D2 LSR
    cpu.lsrA();
    goto L_0DA8D3;
L_0DA8D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8D3 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DA8D5;
L_0DA8D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D5u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA8D5 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xA8D7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8D8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DA8D5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA8D8;
L_0DA8D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8D8u,0x0DA8D8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D8u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8D8 CPX
    cpu.compareX(0x4u);
    goto L_0DA8DA;
L_0DA8DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8DA BNE -> $0DA92E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA92E; }
    goto L_0DA8DC;
L_0DA8DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DCu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8DC TXA
    cpu.transfer("TXA");
    goto L_0DA8DD;
L_0DA8DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DDu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DDu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0DA8DD PHA
    cpu.push("PHA", hw);
    goto L_0DA8DE;
L_0DA8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DEu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8DE TYA
    cpu.transfer("TYA");
    goto L_0DA8DF;
L_0DA8DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DFu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0DA8DF PHA
    cpu.push("PHA", hw);
    goto L_0DA8E0;
L_0DA8E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E0u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E0u, 4u, 3u, cpu.address("abs", 0x13BEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8E0 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13BEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DA8E3;
L_0DA8E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8E3 LDA
    cpu.setA(0xF8u, 8);
    goto L_0DA8E5;
L_0DA8E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8E5 CLC
    cpu.setFlag('C', false);
    goto L_0DA8E6;
L_0DA8E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E6u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E6u, 5u, 4u, ((0x0DA8AEu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8E6 ADC
    cpu.adc(hw.readW(((0xDA8AEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DA8EA;
L_0DA8EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8EA STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_0DA8EC;
L_0DA8EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8EC LDA
    cpu.setA(0x19u, 8);
    goto L_0DA8EE;
L_0DA8EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu, 5u, 4u, ((0x0DA8B1u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8EE ADC
    cpu.adc(hw.readW(((0xDA8B1u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DA8F2;
L_0DA8F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8F2 STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_0DA8F4;
L_0DA8F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F4u, 4u, 3u, cpu.address("abs", 0x1BA1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8F4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA8F7;
L_0DA8F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8F7 ASL
    cpu.aslA();
    goto L_0DA8F8;
L_0DA8F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8F8 ASL
    cpu.aslA();
    goto L_0DA8F9;
L_0DA8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8F9 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0DA8FB;
L_0DA8FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA8FD;
L_0DA8FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8FD AND
    cpu.logicAnd(0x10u);
    goto L_0DA8FF;
L_0DA8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA8FF BEQ -> $0DA907
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA907; }
    goto L_0DA901;
L_0DA901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA901u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA901u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA901 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA903;
L_0DA903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA903 ORA
    cpu.logicOr(0x2u);
    goto L_0DA905;
L_0DA905:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA905u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA905u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA905u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA905 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0DA907;
L_0DA907:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA907u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA907u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA907u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA907 TYA
    cpu.transfer("TYA");
    goto L_0DA908;
L_0DA908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA908 AND
    cpu.logicAnd(0x8u);
    goto L_0DA90A;
L_0DA90A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA90A BEQ -> $0DA912
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA912; }
    goto L_0DA90C;
L_0DA90C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA90C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA90E;
L_0DA90E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA90E ORA
    cpu.logicOr(0x1u);
    goto L_0DA910;
L_0DA910:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA910u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA910u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA910u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA910 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0DA912;
L_0DA912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA912u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA912u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA912 TYA
    cpu.transfer("TYA");
    goto L_0DA913;
L_0DA913:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA913u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA913u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA913u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA913 AND
    cpu.logicAnd(0x7u);
    goto L_0DA915;
L_0DA915:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA915u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA915u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA915u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA915 TAX
    cpu.transfer("TAX");
    goto L_0DA916;
L_0DA916:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA916u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA916u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA916u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA916 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DA918;
L_0DA918:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA918u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA918u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA918u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x08u) & 0xFFFFu), 2u, 0u);
    // $0DA918 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA91A;
L_0DA91A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Au,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Au, 5u, 4u, ((0x0DA8A6u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA91A AND
    cpu.logicAnd(hw.readW(((0xDA8A6u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DA91E;
L_0DA91E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA91E STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_0DA920;
L_0DA920:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA920u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA920u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA920u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0DA920 PLA
    cpu.pop("PLA", hw);
    goto L_0DA921;
L_0DA921:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA921u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA921u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA921u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA921 TAY
    cpu.transfer("TAY");
    goto L_0DA922;
L_0DA922:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA922u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA922u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA922u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0DA922 PLA
    cpu.pop("PLA", hw);
    goto L_0DA923;
L_0DA923:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA923u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA923u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA923u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA923 TAX
    cpu.transfer("TAX");
    goto L_0DA924;
L_0DA924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA924u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA924u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA924u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA924 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA926;
L_0DA926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA926u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA926u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA926 BEQ -> $0DA92E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DA92E; }
    goto L_0DA928;
L_0DA928:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA928u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA928u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA928u, 6u, 3u, cpu.address("abs", 0xA95Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA928 JSR -> $0DA95D stack real
    { cpu.push16Value(hw,0xA92Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA92Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Du), 0x0DA928u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA92B;
L_0DA92B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA92Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA92Bu,0x0DA92Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Bu, 3u, 3u, cpu.address("abs", 0xA943u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA92B JMP -> $0DA943
    goto L_0DA943;
L_0DA92E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA92Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Eu, 5u, 4u, ((0x0DA8B4u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA92E LDA
    cpu.loadA(hw.readW(((0xDA8B4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA932;
L_0DA932:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA932u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA932u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA932u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA932 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_0DA934;
L_0DA934:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA934u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA934u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA934u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA934 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xA936u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA937u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DA934u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA937;
L_0DA937:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA937u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA937u,0x0DA937u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA937u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA937u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA937 CPX
    cpu.compareX(0x7u);
    goto L_0DA939;
L_0DA939:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA939u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA939u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA939u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA939 BMI -> $0DA93E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DA93E; }
    goto L_0DA93B;
L_0DA93B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA93Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Bu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA93B JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xA93Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA93Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DA93Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA93E;
L_0DA93E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA93Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA93Eu,0x0DA93Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA93E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA940;
L_0DA940:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA940u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA940u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA940u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA940 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xA942u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA943u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DA940u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA943;
L_0DA943:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA943u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA943u,0x0DA943u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA943u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA943u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA943 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DA945;
L_0DA945:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA945u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA945u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA945u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA945 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA947;
L_0DA947:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA947u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA947u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA947u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA947 BPL -> $0DA8D8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DA8D8; }
    goto L_0DA949;
L_0DA949:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA949u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA949u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA949u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA949 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xA94Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA94Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DA949u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA94C;
L_0DA94C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA94Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA94Cu,0x0DA94Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Cu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA94C JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xA94Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA94Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DA94Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DA94F;
L_0DA94F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA94Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA94Fu,0x0DA94Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA94F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA951;
L_0DA951:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA951u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA951u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA951u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA951 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DA953;
L_0DA953:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA953u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA953u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA953u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA953 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DA955;
L_0DA955:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA955u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA955u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA955u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA955 BMI -> $0DA95A
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DA95A; }
    goto L_0DA957;
L_0DA957:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA957u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA957u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA957u, 3u, 3u, cpu.address("abs", 0xA8D8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA957 JMP -> $0DA8D8
    goto L_0DA8D8;
L_0DA95A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA95A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA95Au);return;} hw.unresolvedReturn(0x0DA95Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DD1A5_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DD1A5u: goto L_0DD1A5;
    case 0x0DD1A7u: goto L_0DD1A7;
    case 0x0DD1A9u: goto L_0DD1A9;
    case 0x0DD1AAu: goto L_0DD1AA;
    case 0x0DD1ABu: goto L_0DD1AB;
    case 0x0DD1ACu: goto L_0DD1AC;
    case 0x0DD1ADu: goto L_0DD1AD;
    case 0x0DD1AEu: goto L_0DD1AE;
    case 0x0DD1B1u: goto L_0DD1B1;
    case 0x0DD1B3u: goto L_0DD1B3;
    case 0x0DD1B6u: goto L_0DD1B6;
    case 0x0DD1B9u: goto L_0DD1B9;
    case 0x0DD1BBu: goto L_0DD1BB;
    case 0x0DD1BDu: goto L_0DD1BD;
    case 0x0DD1C0u: goto L_0DD1C0;
    case 0x0DD1C1u: goto L_0DD1C1;
    case 0x0DD1C3u: goto L_0DD1C3;
    case 0x0DD1C6u: goto L_0DD1C6;
    case 0x0DD1C8u: goto L_0DD1C8;
    case 0x0DD1CAu: goto L_0DD1CA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DD1A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A5u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD1A5 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DD1A7;
L_0DD1A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD1A7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DD1A9;
L_0DD1A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD1A9 LSR
    cpu.lsrA();
    goto L_0DD1AA;
L_0DD1AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1AAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD1AA LSR
    cpu.lsrA();
    goto L_0DD1AB;
L_0DD1AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ABu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD1AB LSR
    cpu.lsrA();
    goto L_0DD1AC;
L_0DD1AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ACu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD1AC LSR
    cpu.lsrA();
    goto L_0DD1AD;
L_0DD1AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ADu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD1AD TAX
    cpu.transfer("TAX");
    goto L_0DD1AE;
L_0DD1AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1AEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1AEu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD1AE JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xD1B0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1B1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DD1AEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD1B1;
L_0DD1B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1B1u,0x0DD1B1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD1B1 LDA
    cpu.setA(0x5Cu, 8);
    goto L_0DD1B3;
L_0DD1B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B3u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B3u, 3u, 3u, cpu.address("abs", 0xD1BBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD1B3 JMP -> $0DD1BB
    goto L_0DD1BB;
L_0DD1B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B6u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD1B6 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xD1B8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1B9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DD1B6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD1B9;
L_0DD1B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1B9u,0x0DD1B9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD1B9 LDA
    cpu.setA(0x5Du, 8);
    goto L_0DD1BB;
L_0DD1BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BBu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BBu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DD1BB STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DD1BD;
L_0DD1BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BDu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD1BD JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xD1BFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1C0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DD1BDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD1C0;
L_0DD1C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1C0u,0x0DD1C0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD1C0 DEX
    cpu.decReg('X');
    goto L_0DD1C1;
L_0DD1C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD1C1 BNE -> $0DD1B6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DD1B6; }
    goto L_0DD1C3;
L_0DD1C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C3u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD1C3 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xD1C5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1C6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DD1C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD1C6;
L_0DD1C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1C6u,0x0DD1C6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD1C6 LDA
    cpu.setA(0x5Eu, 8);
    goto L_0DD1C8;
L_0DD1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C8u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DD1C8 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DD1CA;
L_0DD1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD1CA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DD1CAu);return;} hw.unresolvedReturn(0x0DD1CAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0F8D0E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0F8D0Eu: goto L_0F8D0E;
    case 0x0F8D11u: goto L_0F8D11;
    case 0x0F8D14u: goto L_0F8D14;
    case 0x0F8D17u: goto L_0F8D17;
    case 0x0F8D19u: goto L_0F8D19;
    case 0x0F8D1Au: goto L_0F8D1A;
    case 0x0F8D1Du: goto L_0F8D1D;
    case 0x0F8D20u: goto L_0F8D20;
    case 0x0F8D22u: goto L_0F8D22;
    case 0x0F8D25u: goto L_0F8D25;
    case 0x0F8D27u: goto L_0F8D27;
    case 0x0F8D29u: goto L_0F8D29;
    case 0x0F8D3Au: goto L_0F8D3A;
    case 0x0F8D3Cu: goto L_0F8D3C;
    case 0x0F8D3Fu: goto L_0F8D3F;
    case 0x0F8D42u: goto L_0F8D42;
    case 0x0F8D44u: goto L_0F8D44;
    case 0x0F8D46u: goto L_0F8D46;
    case 0x0F8D4Au: goto L_0F8D4A;
    case 0x0F8D6Fu: goto L_0F8D6F;
    case 0x0F8D71u: goto L_0F8D71;
    case 0x0F8D73u: goto L_0F8D73;
    case 0x0F8D75u: goto L_0F8D75;
    case 0x0F8D78u: goto L_0F8D78;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0F8D0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Eu,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Eu, 4u + ((((0x0FEDu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0FEDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D0E SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0xFEDu), cpu.m8?8:16));
    goto L_0F8D11;
L_0F8D11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D11u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D11u, 7u, 3u, cpu.address("absx", 0xF08Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D11 DEC
    cpu.decMem(hw, cpu.address("absx", 0xF08Eu), cpu.m8?8:16);
    goto L_0F8D14;
L_0F8D14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D14u,cpu,0x0Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D14u, 6u, 3u, cpu.address("abs", 0xFFE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D14 ASL
    cpu.aslMem(hw, cpu.address("abs", 0xFFE0u), cpu.m8?8:16);
    goto L_0F8D17;
L_0F8D17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D17u,cpu,0x21u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D17u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x31u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $0F8D17 AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirectX(hw, 0x31u), cpu.m8?8:16));
    goto L_0F8D19;
L_0F8D19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D19u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D19u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D19 XBA
    cpu.xba();
    goto L_0F8D1A;
L_0F8D1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au, 6u, 3u, cpu.address("abs", 0x118Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D1A DEC
    cpu.decMem(hw, cpu.address("abs", 0x118Eu), cpu.m8?8:16);
    goto L_0F8D1D;
L_0F8D1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Du,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Du, 7u, 3u, cpu.address("absx", 0xFFECu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D1D INC
    cpu.incMem(hw, cpu.address("absx", 0xFFECu), cpu.m8?8:16);
    goto L_0F8D20;
L_0F8D20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D20u,cpu,0xF1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D20u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Eu) & 0xFFFFu), 2u, 0u);
    // $0F8D20 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectY(hw, 0x1Eu), cpu.m8?8:16));
    goto L_0F8D22;
L_0F8D22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D22u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D22u, 4u, 3u, cpu.address("abs", 0x8601u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D22 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x8601u), cpu.m8?8:16));
    goto L_0F8D25;
L_0F8D25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D25u,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D25u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D25 TRB
    cpu.trb(hw, cpu.address("dp", 0x52u), cpu.m8?8:16);
    goto L_0F8D27;
L_0F8D27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D27u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D27u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D27 BPL -> $0F8D3A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0F8D3A; }
    goto L_0F8D29;
L_0F8D29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D29u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D29u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0F8D29 BRK
    hw.partial(0x0F8D29u, "BRK"); return;
L_0F8D3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D3A BEQ -> $0F8D6F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0F8D6F; }
    goto L_0F8D3C;
L_0F8D3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Cu,cpu,0x44u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8D3Cu, (std::uint32_t(cpu.a)+1u), 0x30u, 0x33u);
    // $0F8D3C MVP
    cpu.blockMove(hw, 0x33u, 0x30u, true);
    goto L_0F8D3F;
L_0F8D3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu, 7u, 3u, cpu.address("absx", 0xDE0Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D3F ROR
    cpu.rorMem(hw, cpu.address("absx", 0xDE0Bu), cpu.m8?8:16);
    goto L_0F8D42;
L_0F8D42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D42u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D42u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x21u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D42 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x21u), cpu.m8?8:16), false);
    goto L_0F8D44;
L_0F8D44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x41u) & 0xFFFFu), 2u, 0u);
    // $0F8D44 AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0x41u), cpu.m8?8:16));
    goto L_0F8D46;
L_0F8D46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D46u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D46u, 5u, 4u, ((0x416E10u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D46 ORA
    cpu.logicOr(hw.readW(((0x416E10u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0F8D4A;
L_0F8D4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Au,cpu,0xDCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Au, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, 0x0EF1u, 3u, 0u);
    // $0F8D4A JMP [0EF1] -> dispatcher C++ dinamico
    hw.requestDispatch(hw.read24(0x0EF1u),0x0F8D4Au); return;
L_0F8D6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Fu,cpu,0x13u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Fu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x10u) & 0xFFFFu), 2u, 0u);
    // $0F8D6F ORA
    cpu.logicOr(hw.readW(cpu.addressStackIndirectY(hw, 0x10u), cpu.m8?8:16));
    goto L_0F8D71;
L_0F8D71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D71u,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D71u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x12u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $0F8D71 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0x12u), cpu.m8?8:16));
    goto L_0F8D73;
L_0F8D73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u,cpu,0x32u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $0F8D73 AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirect(hw, 0x0u), cpu.m8?8:16));
    goto L_0F8D75;
L_0F8D75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D75u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D75u, 7u, 3u, cpu.address("absx", 0x1F20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0F8D75 ROR
    cpu.rorMem(hw, cpu.address("absx", 0x1F20u), cpu.m8?8:16);
    goto L_0F8D78;
L_0F8D78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0F8D78 BRK
    hw.partial(0x0F8D78u, "BRK"); return;
}

void sub_22CD2D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x22CD2Du: goto L_22CD2D;
    case 0x22CD2Eu: goto L_22CD2E;
    case 0x22CD2Fu: goto L_22CD2F;
    case 0x22CD30u: goto L_22CD30;
    case 0x22CD33u: goto L_22CD33;
    case 0x22CD34u: goto L_22CD34;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_22CD2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Du,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $22CD2D PHB
    cpu.push("PHB", hw);
    goto L_22CD2E;
L_22CD2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Eu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $22CD2E PHK
    cpu.push("PHK", hw);
    goto L_22CD2F;
L_22CD2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $22CD2F PLB
    cpu.pop("PLB", hw);
    goto L_22CD30;
L_22CD30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD30u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD30u, 6u, 3u, cpu.address("abs", 0xCD59u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $22CD30 JSR -> $22CD59 stack real
    { cpu.push16Value(hw,0xCD32u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD33u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCD59u), 0x22CD30u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_22CD33;
L_22CD33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD33u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD33u,0x22CD33u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD33u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD33u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $22CD33 PLB
    cpu.pop("PLB", hw);
    goto L_22CD34;
L_22CD34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD34u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD34u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $22CD34 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x22CD34u);return;} hw.unresolvedReturn(0x22CD34u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_B18D2E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB18D2Eu: goto L_B18D2E;
    case 0xB18D31u: goto L_B18D31;
    case 0xB18D33u: goto L_B18D33;
    case 0xB18D35u: goto L_B18D35;
    case 0xB18D38u: goto L_B18D38;
    case 0xB18D39u: goto L_B18D39;
    case 0xB18D3Cu: goto L_B18D3C;
    case 0xB18D3Fu: goto L_B18D3F;
    case 0xB18D41u: goto L_B18D41;
    case 0xB18D43u: goto L_B18D43;
    case 0xB18D44u: goto L_B18D44;
    case 0xB18D45u: goto L_B18D45;
    case 0xB18D46u: goto L_B18D46;
    case 0xB18D48u: goto L_B18D48;
    case 0xB18D4Bu: goto L_B18D4B;
    case 0xB18D4Eu: goto L_B18D4E;
    case 0xB18D50u: goto L_B18D50;
    case 0xB18D53u: goto L_B18D53;
    case 0xB18D55u: goto L_B18D55;
    case 0xB18D57u: goto L_B18D57;
    case 0xB18D59u: goto L_B18D59;
    case 0xB18D5Cu: goto L_B18D5C;
    case 0xB18D5Fu: goto L_B18D5F;
    case 0xB18D62u: goto L_B18D62;
    case 0xB18D65u: goto L_B18D65;
    case 0xB18D67u: goto L_B18D67;
    case 0xB18D69u: goto L_B18D69;
    case 0xB18D6Cu: goto L_B18D6C;
    case 0xB18D6Eu: goto L_B18D6E;
    case 0xB18D70u: goto L_B18D70;
    case 0xB18D72u: goto L_B18D72;
    case 0xB18D74u: goto L_B18D74;
    case 0xB18D77u: goto L_B18D77;
    case 0xB18D7Au: goto L_B18D7A;
    case 0xB18D7Du: goto L_B18D7D;
    case 0xB18D7Fu: goto L_B18D7F;
    case 0xB18D82u: goto L_B18D82;
    case 0xB18D85u: goto L_B18D85;
    case 0xB18D87u: goto L_B18D87;
    case 0xB18D8Au: goto L_B18D8A;
    case 0xB18D8Cu: goto L_B18D8C;
    case 0xB18D8Fu: goto L_B18D8F;
    case 0xB18D91u: goto L_B18D91;
    case 0xB18D93u: goto L_B18D93;
    case 0xB18D96u: goto L_B18D96;
    case 0xB18D9Au: goto L_B18D9A;
    case 0xB18D9Cu: goto L_B18D9C;
    case 0xB18D9Eu: goto L_B18D9E;
    case 0xB18DA1u: goto L_B18DA1;
    case 0xB18DA3u: goto L_B18DA3;
    case 0xB18DA5u: goto L_B18DA5;
    case 0xB18DA8u: goto L_B18DA8;
    case 0xB18DABu: goto L_B18DAB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B18D2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Eu, 6u, 3u, cpu.address("abs", 0xAC31u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D2E JSR -> $B1AC31 stack real
    { cpu.push16Value(hw,0x8D30u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D31u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC31u), 0xB18D2Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D31;
L_B18D31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D31u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D31u,0xB18D31u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D31u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D31u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D31 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18D33;
L_B18D33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D33u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D33 BEQ -> $B18D39
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18D39; }
    goto L_B18D35;
L_B18D35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D35u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D35u, 6u, 3u, cpu.address("abs", 0x8DACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D35 JSR -> $B18DAC stack real
    { cpu.push16Value(hw,0x8D37u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D38u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8DACu), 0xB18D35u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D38;
L_B18D38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D38u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D38u,0xB18D38u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D38u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D38u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D38 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB18D38u);return;} hw.unresolvedReturn(0xB18D38u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_B18D39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D39u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D39u, 6u, 3u, cpu.address("abs", 0x8DBBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D39 JSR -> $B18DBB stack real
    { cpu.push16Value(hw,0x8D3Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D3Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8DBBu), 0xB18D39u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D3C;
L_B18D3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D3Cu,0xB18D3Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Cu, 6u, 3u, cpu.address("abs", 0x9032u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D3C JSR -> $B19032 stack real
    { cpu.push16Value(hw,0x8D3Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D3Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9032u), 0xB18D3Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D3F;
L_B18D3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D3F DEC
    cpu.decMem(hw, cpu.address("dpx", 0xAAu), cpu.m8?8:16);
    goto L_B18D41;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D3F DEC
    cpu.decMem(hw, cpu.address("dpx", 0xAAu), cpu.m8?8:16);
    goto L_B18D41;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D3Fu,0xB18D3Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18D41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D41u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D41u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D41u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D41 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18D43;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D41u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D41u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D41 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18D43;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D41u,0xB18D41u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18D43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D43u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D43u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D43u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D43 LSR
    cpu.lsrA();
    goto L_B18D44;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D43u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D43u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D43 LSR
    cpu.lsrA();
    goto L_B18D44;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D43u,0xB18D43u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18D44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D44 LSR
    cpu.lsrA();
    goto L_B18D45;
L_B18D45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D45u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D45 LSR
    cpu.lsrA();
    goto L_B18D46;
L_B18D46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D46u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D46u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D46 AND
    cpu.logicAnd(0x1u);
    goto L_B18D48;
L_B18D48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D48u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D48u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D48 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_B18D4B;
L_B18D4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Bu, 6u, 3u, cpu.address("abs", 0x8DACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D4B JSR -> $B18DAC stack real
    { cpu.push16Value(hw,0x8D4Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D4Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8DACu), 0xB18D4Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D4E;
L_B18D4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D4Eu,0xB18D4Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D4E INC
    cpu.incMem(hw, cpu.address("dpx", 0xC2u), cpu.m8?8:16);
    goto L_B18D50;
L_B18D50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D50u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D50u, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D50 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18D53;
L_B18D53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D53u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D53 BNE -> $B18D5F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18D5F; }
    goto L_B18D55;
L_B18D55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D55u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D55u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D55 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18D57;
L_B18D57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D57u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D57 BPL -> $B18D5F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_B18D5F; }
    goto L_B18D59;
L_B18D59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D59u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D59u, 7u, 3u, cpu.address("absx", 0x1570u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D59 INC
    cpu.incMem(hw, cpu.address("absx", 0x1570u), cpu.m8?8:16);
    goto L_B18D5C;
L_B18D5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Cu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Cu, 7u, 3u, cpu.address("absx", 0x1570u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D5C INC
    cpu.incMem(hw, cpu.address("absx", 0x1570u), cpu.m8?8:16);
    goto L_B18D5F;
L_B18D5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Fu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Fu, 7u, 3u, cpu.address("absx", 0x1570u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D5F INC
    cpu.incMem(hw, cpu.address("absx", 0x1570u), cpu.m8?8:16);
    goto L_B18D62;
L_B18D62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D62u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D62u, 6u, 3u, cpu.address("abs", 0x8014u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D62 JSR -> $B18014 stack real
    { cpu.push16Value(hw,0x8D64u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D65u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8014u), 0xB18D62u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D65;
L_B18D65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D65u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D65u,0xB18D65u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D65u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D65u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D65 BEQ -> $B18D69
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18D69; }
    goto L_B18D67;
L_B18D67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D67u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D67u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D67 STZ
    hw.write(cpu.address("dpx", 0xAAu), 0, cpu.m8?8:16);
    goto L_B18D69;
L_B18D69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D69u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D69u, 6u, 3u, cpu.address("abs", 0x800Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D69 JSR -> $B1800E stack real
    { cpu.push16Value(hw,0x8D6Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D6Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x800Eu), 0xB18D69u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D6C;
L_B18D6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D6Cu,0xB18D6Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D6C BEQ -> $B18DA5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18DA5; }
    goto L_B18D6E;
L_B18D6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Eu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D6E LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18D70;
L_B18D70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D70u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D70 AND
    cpu.logicAnd(0x3Fu);
    goto L_B18D72;
L_B18D72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D72u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D72 BNE -> $B18D77
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18D77; }
    goto L_B18D74;
L_B18D74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D74u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D74u, 6u, 3u, cpu.address("abs", 0x857Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D74 JSR -> $B1857C stack real
    { cpu.push16Value(hw,0x8D76u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D77u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x857Cu), 0xB18D74u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D77;
L_B18D77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D77u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D77u,0xB18D77u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D77u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D77u, 6u, 3u, cpu.address("abs", 0x9A04u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D77 JSR -> $B19A04 stack real
    { cpu.push16Value(hw,0x8D79u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D7Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9A04u), 0xB18D77u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D7A;
L_B18D7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D7Au,0xB18D7Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D7A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18D7D;
L_B18D7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D7D BNE -> $B18D82
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18D82; }
    goto L_B18D7F;
L_B18D7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu, 5u, 3u, cpu.address("absx", 0x1570u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D7F STZ
    hw.write(cpu.address("absx", 0x1570u), 0, cpu.m8?8:16);
    goto L_B18D82;
L_B18D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D82 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18D85;
L_B18D85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D85 BNE -> $B18DA5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18DA5; }
    goto L_B18D87;
L_B18D87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u, 7u, 3u, cpu.address("absx", 0x151Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D87 INC
    cpu.incMem(hw, cpu.address("absx", 0x151Cu), cpu.m8?8:16);
    goto L_B18D8A;
L_B18D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D8A LDY
    cpu.setY(0xF0u, 8);
    goto L_B18D8C;
L_B18D8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu, 4u + ((((0x151Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D8C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x151Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18D8F;
L_B18D8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D8F CMP
    cpu.compareA(0x4u);
    goto L_B18D91;
L_B18D91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D91u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D91 BNE -> $B18DA3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18DA3; }
    goto L_B18D93;
L_B18D93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D93u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D93u, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D93 STZ
    hw.write(cpu.address("absx", 0x151Cu), 0, cpu.m8?8:16);
    goto L_B18D96;
L_B18D96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D96u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D96u, 8u, 4u, 0x01ACF9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B18D96 JSL -> $01ACF9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8D99u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D9Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01ACF9u, 0xB18D96u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D9A;
L_B18D9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D9Au,0xB18D9Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D9A AND
    cpu.logicAnd(0x3Fu);
    goto L_B18D9C;
L_B18D9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Cu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D9C ORA
    cpu.logicOr(0x50u);
    goto L_B18D9E;
L_B18D9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D9Eu, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D9E STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_B18DA1;
L_B18DA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA1u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18DA1 LDY
    cpu.setY(0xD0u, 8);
    goto L_B18DA3;
L_B18DA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA3u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18DA3 STY
    hw.write(cpu.address("dpx", 0xAAu), cpu.y, cpu.x8?8:16);
    goto L_B18DA5;
L_B18DA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA5u, 6u, 3u, cpu.address("abs", 0x9089u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18DA5 JSR -> $B19089 stack real
    { cpu.push16Value(hw,0x8DA7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8DA8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9089u), 0xB18DA5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18DA8;
L_B18DA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DA8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DA8u,0xB18DA8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DA8u, 6u, 3u, cpu.address("abs", 0x8FC1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18DA8 JSR -> $B18FC1 stack real
    { cpu.push16Value(hw,0x8DAAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8DABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8FC1u), 0xB18DA8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18DAB;
L_B18DAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DABu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18DAB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB18DABu);return;} hw.unresolvedReturn(0xB18DABu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18DAB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB18DABu);return;} hw.unresolvedReturn(0xB18DABu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DABu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18DAB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB18DABu);return;} hw.unresolvedReturn(0xB18DABu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8DABu,0xB18DABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

