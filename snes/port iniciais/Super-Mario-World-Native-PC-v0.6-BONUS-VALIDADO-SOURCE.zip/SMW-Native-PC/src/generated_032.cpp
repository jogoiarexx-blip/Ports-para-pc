#include "generated.hpp"
void sub_008079_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008079u: goto L_008079;
    case 0x00807Au: goto L_00807A;
    case 0x00807Cu: goto L_00807C;
    case 0x00807Fu: goto L_00807F;
    case 0x008082u: goto L_008082;
    case 0x008085u: goto L_008085;
    case 0x008087u: goto L_008087;
    case 0x008089u: goto L_008089;
    case 0x00808Bu: goto L_00808B;
    case 0x00808Du: goto L_00808D;
    case 0x00808Fu: goto L_00808F;
    case 0x008090u: goto L_008090;
    case 0x008091u: goto L_008091;
    case 0x008093u: goto L_008093;
    case 0x008095u: goto L_008095;
    case 0x008096u: goto L_008096;
    case 0x008098u: goto L_008098;
    case 0x008099u: goto L_008099;
    case 0x00809Au: goto L_00809A;
    case 0x00809Du: goto L_00809D;
    case 0x00809Fu: goto L_00809F;
    case 0x0080A0u: goto L_0080A0;
    case 0x0080A2u: goto L_0080A2;
    case 0x0080A5u: goto L_0080A5;
    case 0x0080A7u: goto L_0080A7;
    case 0x0080A8u: goto L_0080A8;
    case 0x0080AAu: goto L_0080AA;
    case 0x0080ADu: goto L_0080AD;
    case 0x0080AFu: goto L_0080AF;
    case 0x0080B1u: goto L_0080B1;
    case 0x0080B3u: goto L_0080B3;
    case 0x0080B4u: goto L_0080B4;
    case 0x0080B6u: goto L_0080B6;
    case 0x0080B8u: goto L_0080B8;
    case 0x0080B9u: goto L_0080B9;
    case 0x0080BAu: goto L_0080BA;
    case 0x0080BBu: goto L_0080BB;
    case 0x0080BDu: goto L_0080BD;
    case 0x0080BEu: goto L_0080BE;
    case 0x0080BFu: goto L_0080BF;
    case 0x0080C2u: goto L_0080C2;
    case 0x0080C4u: goto L_0080C4;
    case 0x0080C7u: goto L_0080C7;
    case 0x0080C9u: goto L_0080C9;
    case 0x0080CAu: goto L_0080CA;
    case 0x0080CDu: goto L_0080CD;
    case 0x0080CFu: goto L_0080CF;
    case 0x0080D0u: goto L_0080D0;
    case 0x0080D3u: goto L_0080D3;
    case 0x0080D6u: goto L_0080D6;
    case 0x0080D8u: goto L_0080D8;
    case 0x0080DAu: goto L_0080DA;
    case 0x0080DDu: goto L_0080DD;
    case 0x0080E0u: goto L_0080E0;
    case 0x0080E3u: goto L_0080E3;
    case 0x0080E6u: goto L_0080E6;
    case 0x0080E7u: goto L_0080E7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8079u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8079u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8079u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008079 PHP
    cpu.push("PHP", hw);
    goto L_00807A;
L_00807A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00807A REP
    cpu.rep(0x30u);
    goto L_00807C;
L_00807C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00807C LDY
    cpu.setY(0x0u, 16);
    goto L_00807F;
L_00807F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00807F LDA
    cpu.setA(0xBBAAu, 16);
    goto L_008082;
L_008082:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8082u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8082u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8082u, 5u, 3u, cpu.address("abs", 0x2140u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008082 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_008085;
L_008085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008085 BNE -> $008082
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008082; }
    goto L_008087;
L_008087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8087u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8087u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008087 SEP
    cpu.sep(0x20u);
    goto L_008089;
L_008089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8089u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008089 LDA
    cpu.setA(0xCCu, 8);
    goto L_00808B;
L_00808B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00808B BRA -> $0080B3
    goto L_0080B3;
L_00808D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00808D LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00808F;
L_00808F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00808F INY
    cpu.inc('Y');
    goto L_008090;
L_008090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8090u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008090 XBA
    cpu.xba();
    goto L_008091;
L_008091:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8091u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8091u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8091u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008091 LDA
    cpu.setA(0x0u, 8);
    goto L_008093;
L_008093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8093u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008093 BRA -> $0080A0
    goto L_0080A0;
L_008095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008095 XBA
    cpu.xba();
    goto L_008096;
L_008096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8096u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8096u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8096u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $008096 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008098;
L_008098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8098u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8098u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8098u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008098 INY
    cpu.inc('Y');
    goto L_008099;
L_008099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8099u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008099 XBA
    cpu.xba();
    goto L_00809A;
L_00809A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Au,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Au, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00809A CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_00809D;
L_00809D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00809D BNE -> $00809A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00809A; }
    goto L_00809F;
L_00809F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Fu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00809F INC
    cpu.inc('A');
    goto L_0080A0;
L_0080A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080A0 REP
    cpu.rep(0x20u);
    goto L_0080A2;
L_0080A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A2u, 5u, 3u, cpu.address("abs", 0x2140u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080A2 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_0080A5;
L_0080A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080A5 SEP
    cpu.sep(0x20u);
    goto L_0080A7;
L_0080A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A7u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080A7 DEX
    cpu.decReg('X');
    goto L_0080A8;
L_0080A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080A8 BNE -> $008095
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008095; }
    goto L_0080AA;
L_0080AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080AA CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_0080AD;
L_0080AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080AD BNE -> $0080AA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0080AA; }
    goto L_0080AF;
L_0080AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080AF ADC
    cpu.adc(0x3u);
    goto L_0080B1;
L_0080B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080B1 BEQ -> $0080AF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0080AF; }
    goto L_0080B3;
L_0080B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B3u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0080B3 PHA
    cpu.push("PHA", hw);
    goto L_0080B4;
L_0080B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080B4 REP
    cpu.rep(0x20u);
    goto L_0080B6;
L_0080B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $0080B6 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0080B8;
L_0080B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080B8 INY
    cpu.inc('Y');
    goto L_0080B9;
L_0080B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080B9 INY
    cpu.inc('Y');
    goto L_0080BA;
L_0080BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080BA TAX
    cpu.transfer("TAX");
    goto L_0080BB;
L_0080BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BBu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $0080BB LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0080BD;
L_0080BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080BD INY
    cpu.inc('Y');
    goto L_0080BE;
L_0080BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080BE INY
    cpu.inc('Y');
    goto L_0080BF;
L_0080BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu, 5u, 3u, cpu.address("abs", 0x2142u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080BF STA
    hw.write(cpu.address("abs", 0x2142u), cpu.a, cpu.m8?8:16);
    goto L_0080C2;
L_0080C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080C2 SEP
    cpu.sep(0x20u);
    goto L_0080C4;
L_0080C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C4u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080C4 CPX
    cpu.compareX(0x1u);
    goto L_0080C7;
L_0080C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080C7 LDA
    cpu.setA(0x0u, 8);
    goto L_0080C9;
L_0080C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C9u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080C9 ROL
    cpu.rolA();
    goto L_0080CA;
L_0080CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CAu, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080CA STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_0080CD;
L_0080CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080CD ADC
    cpu.adc(0x7Fu);
    goto L_0080CF;
L_0080CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0080CF PLA
    cpu.pop("PLA", hw);
    goto L_0080D0;
L_0080D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D0u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080D0 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_0080D3;
L_0080D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080D3 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_0080D6;
L_0080D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080D6 BNE -> $0080D3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0080D3; }
    goto L_0080D8;
L_0080D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080D8 BVS -> $00808D
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_00808D; }
    goto L_0080DA;
L_0080DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080DA STZ
    hw.write(cpu.address("abs", 0x2140u), 0, cpu.m8?8:16);
    goto L_0080DD;
L_0080DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080DD STZ
    hw.write(cpu.address("abs", 0x2141u), 0, cpu.m8?8:16);
    goto L_0080E0;
L_0080E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E0u, 4u, 3u, cpu.address("abs", 0x2142u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080E0 STZ
    hw.write(cpu.address("abs", 0x2142u), 0, cpu.m8?8:16);
    goto L_0080E3;
L_0080E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E3u, 4u, 3u, cpu.address("abs", 0x2143u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080E3 STZ
    hw.write(cpu.address("abs", 0x2143u), 0, cpu.m8?8:16);
    goto L_0080E6;
L_0080E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E6u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0080E6 PLP
    cpu.pop("PLP", hw);
    goto L_0080E7;
L_0080E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E7u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80E7u,0x0080E7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0080E7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0080E7u);return;} hw.unresolvedReturn(0x0080E7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_008DAC_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008DACu: goto L_008DAC;
    case 0x008DAFu: goto L_008DAF;
    case 0x008DB1u: goto L_008DB1;
    case 0x008DB4u: goto L_008DB4;
    case 0x008DB6u: goto L_008DB6;
    case 0x008DB9u: goto L_008DB9;
    case 0x008DBBu: goto L_008DBB;
    case 0x008DBEu: goto L_008DBE;
    case 0x008DC1u: goto L_008DC1;
    case 0x008DC2u: goto L_008DC2;
    case 0x008DC4u: goto L_008DC4;
    case 0x008DC6u: goto L_008DC6;
    case 0x008DC9u: goto L_008DC9;
    case 0x008DCCu: goto L_008DCC;
    case 0x008DCEu: goto L_008DCE;
    case 0x008DD1u: goto L_008DD1;
    case 0x008DD3u: goto L_008DD3;
    case 0x008DD6u: goto L_008DD6;
    case 0x008DD8u: goto L_008DD8;
    case 0x008DDBu: goto L_008DDB;
    case 0x008DDEu: goto L_008DDE;
    case 0x008DDFu: goto L_008DDF;
    case 0x008DE1u: goto L_008DE1;
    case 0x008DE3u: goto L_008DE3;
    case 0x008DE6u: goto L_008DE6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008DAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DACu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DACu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DAC STZ
    hw.write(cpu.address("abs", 0x2115u), 0, cpu.m8?8:16);
    goto L_008DAF;
L_008DAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DAF LDA
    cpu.setA(0x42u, 8);
    goto L_008DB1;
L_008DB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB1u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DB1 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008DB4;
L_008DB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DB4 LDA
    cpu.setA(0x50u, 8);
    goto L_008DB6;
L_008DB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB6u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DB6 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008DB9;
L_008DB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DB9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DB9 LDX
    cpu.setX(0x6u, 8);
    goto L_008DBB;
L_008DBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBBu, 4u + ((((0x8DE7u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8DE7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DBB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8DE7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008DBE;
L_008DBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DBEu, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DBE STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008DC1;
L_008DC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC1u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DC1 DEX
    cpu.decReg('X');
    goto L_008DC2;
L_008DC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DC2 BPL -> $008DBB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008DBB; }
    goto L_008DC4;
L_008DC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DC4 LDA
    cpu.setA(0x2u, 8);
    goto L_008DC6;
L_008DC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC6u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DC6 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008DC9;
L_008DC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DC9u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DC9 STZ
    hw.write(cpu.address("abs", 0x2115u), 0, cpu.m8?8:16);
    goto L_008DCC;
L_008DCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DCC LDA
    cpu.setA(0x63u, 8);
    goto L_008DCE;
L_008DCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DCEu, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DCE STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008DD1;
L_008DD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DD1 LDA
    cpu.setA(0x50u, 8);
    goto L_008DD3;
L_008DD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD3u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DD3 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008DD6;
L_008DD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DD6 LDX
    cpu.setX(0x6u, 8);
    goto L_008DD8;
L_008DD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DD8u, 4u + ((((0x8DEEu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8DEEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DD8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8DEEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008DDB;
L_008DDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDBu, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DDB STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008DDE;
L_008DDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDEu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DDE DEX
    cpu.decReg('X');
    goto L_008DDF;
L_008DDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DDFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DDF BPL -> $008DD8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008DD8; }
    goto L_008DE1;
L_008DE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DE1 LDA
    cpu.setA(0x2u, 8);
    goto L_008DE3;
L_008DE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE3u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008DE3 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008DE6;
L_008DE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8DE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8DE6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008DE6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008DE6u);return;} hw.unresolvedReturn(0x008DE6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_008E1A_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008E1Au: goto L_008E1A;
    case 0x008E1Du: goto L_008E1D;
    case 0x008E1Fu: goto L_008E1F;
    case 0x008E21u: goto L_008E21;
    case 0x008E24u: goto L_008E24;
    case 0x008E26u: goto L_008E26;
    case 0x008E28u: goto L_008E28;
    case 0x008E2Bu: goto L_008E2B;
    case 0x008E2Du: goto L_008E2D;
    case 0x008E2Fu: goto L_008E2F;
    case 0x008E32u: goto L_008E32;
    case 0x008E35u: goto L_008E35;
    case 0x008E38u: goto L_008E38;
    case 0x008E3Bu: goto L_008E3B;
    case 0x008E3Du: goto L_008E3D;
    case 0x008E3Fu: goto L_008E3F;
    case 0x008E42u: goto L_008E42;
    case 0x008E44u: goto L_008E44;
    case 0x008E46u: goto L_008E46;
    case 0x008E49u: goto L_008E49;
    case 0x008E4Au: goto L_008E4A;
    case 0x008E4Cu: goto L_008E4C;
    case 0x008E4Fu: goto L_008E4F;
    case 0x008E51u: goto L_008E51;
    case 0x008E54u: goto L_008E54;
    case 0x008E57u: goto L_008E57;
    case 0x008E59u: goto L_008E59;
    case 0x008E5Bu: goto L_008E5B;
    case 0x008E5Du: goto L_008E5D;
    case 0x008E60u: goto L_008E60;
    case 0x008E63u: goto L_008E63;
    case 0x008E66u: goto L_008E66;
    case 0x008E69u: goto L_008E69;
    case 0x008E6Bu: goto L_008E6B;
    case 0x008E6Fu: goto L_008E6F;
    case 0x008E72u: goto L_008E72;
    case 0x008E75u: goto L_008E75;
    case 0x008E78u: goto L_008E78;
    case 0x008E7Bu: goto L_008E7B;
    case 0x008E7Eu: goto L_008E7E;
    case 0x008E81u: goto L_008E81;
    case 0x008E83u: goto L_008E83;
    case 0x008E85u: goto L_008E85;
    case 0x008E88u: goto L_008E88;
    case 0x008E8Au: goto L_008E8A;
    case 0x008E8Cu: goto L_008E8C;
    case 0x008E8Fu: goto L_008E8F;
    case 0x008E90u: goto L_008E90;
    case 0x008E91u: goto L_008E91;
    case 0x008E93u: goto L_008E93;
    case 0x008E95u: goto L_008E95;
    case 0x008E97u: goto L_008E97;
    case 0x008E9Au: goto L_008E9A;
    case 0x008E9Cu: goto L_008E9C;
    case 0x008E9Eu: goto L_008E9E;
    case 0x008EA0u: goto L_008EA0;
    case 0x008EA3u: goto L_008EA3;
    case 0x008EA4u: goto L_008EA4;
    case 0x008EA7u: goto L_008EA7;
    case 0x008EA9u: goto L_008EA9;
    case 0x008EACu: goto L_008EAC;
    case 0x008EAEu: goto L_008EAE;
    case 0x008EB0u: goto L_008EB0;
    case 0x008EB2u: goto L_008EB2;
    case 0x008EB5u: goto L_008EB5;
    case 0x008EB7u: goto L_008EB7;
    case 0x008EBAu: goto L_008EBA;
    case 0x008EBCu: goto L_008EBC;
    case 0x008EBFu: goto L_008EBF;
    case 0x008EC1u: goto L_008EC1;
    case 0x008EC2u: goto L_008EC2;
    case 0x008EC3u: goto L_008EC3;
    case 0x008EC4u: goto L_008EC4;
    case 0x008EC6u: goto L_008EC6;
    case 0x008EC9u: goto L_008EC9;
    case 0x008ECBu: goto L_008ECB;
    case 0x008ECDu: goto L_008ECD;
    case 0x008ED0u: goto L_008ED0;
    case 0x008ED2u: goto L_008ED2;
    case 0x008ED5u: goto L_008ED5;
    case 0x008ED7u: goto L_008ED7;
    case 0x008ED9u: goto L_008ED9;
    case 0x008EDBu: goto L_008EDB;
    case 0x008EDEu: goto L_008EDE;
    case 0x008EE0u: goto L_008EE0;
    case 0x008EE3u: goto L_008EE3;
    case 0x008EE5u: goto L_008EE5;
    case 0x008EE7u: goto L_008EE7;
    case 0x008EEAu: goto L_008EEA;
    case 0x008EEBu: goto L_008EEB;
    case 0x008EEDu: goto L_008EED;
    case 0x008EEFu: goto L_008EEF;
    case 0x008EF2u: goto L_008EF2;
    case 0x008EF4u: goto L_008EF4;
    case 0x008EF7u: goto L_008EF7;
    case 0x008EF9u: goto L_008EF9;
    case 0x008EFBu: goto L_008EFB;
    case 0x008EFEu: goto L_008EFE;
    case 0x008F00u: goto L_008F00;
    case 0x008F03u: goto L_008F03;
    case 0x008F05u: goto L_008F05;
    case 0x008F07u: goto L_008F07;
    case 0x008F09u: goto L_008F09;
    case 0x008F0Cu: goto L_008F0C;
    case 0x008F0Eu: goto L_008F0E;
    case 0x008F11u: goto L_008F11;
    case 0x008F13u: goto L_008F13;
    case 0x008F15u: goto L_008F15;
    case 0x008F18u: goto L_008F18;
    case 0x008F19u: goto L_008F19;
    case 0x008F1Bu: goto L_008F1B;
    case 0x008F1Du: goto L_008F1D;
    case 0x008F20u: goto L_008F20;
    case 0x008F22u: goto L_008F22;
    case 0x008F25u: goto L_008F25;
    case 0x008F28u: goto L_008F28;
    case 0x008F2Bu: goto L_008F2B;
    case 0x008F2Du: goto L_008F2D;
    case 0x008F2Fu: goto L_008F2F;
    case 0x008F32u: goto L_008F32;
    case 0x008F35u: goto L_008F35;
    case 0x008F36u: goto L_008F36;
    case 0x008F38u: goto L_008F38;
    case 0x008F3Bu: goto L_008F3B;
    case 0x008F3Eu: goto L_008F3E;
    case 0x008F40u: goto L_008F40;
    case 0x008F42u: goto L_008F42;
    case 0x008F44u: goto L_008F44;
    case 0x008F46u: goto L_008F46;
    case 0x008F49u: goto L_008F49;
    case 0x008F4Cu: goto L_008F4C;
    case 0x008F4Du: goto L_008F4D;
    case 0x008F50u: goto L_008F50;
    case 0x008F51u: goto L_008F51;
    case 0x008F53u: goto L_008F53;
    case 0x008F55u: goto L_008F55;
    case 0x008F58u: goto L_008F58;
    case 0x008F5Bu: goto L_008F5B;
    case 0x008F5Eu: goto L_008F5E;
    case 0x008F61u: goto L_008F61;
    case 0x008F63u: goto L_008F63;
    case 0x008F65u: goto L_008F65;
    case 0x008F67u: goto L_008F67;
    case 0x008F6Au: goto L_008F6A;
    case 0x008F6Du: goto L_008F6D;
    case 0x008F6Eu: goto L_008F6E;
    case 0x008F70u: goto L_008F70;
    case 0x008F73u: goto L_008F73;
    case 0x008F76u: goto L_008F76;
    case 0x008F79u: goto L_008F79;
    case 0x008F7Au: goto L_008F7A;
    case 0x008F7Cu: goto L_008F7C;
    case 0x008F7Eu: goto L_008F7E;
    case 0x008F81u: goto L_008F81;
    case 0x008F84u: goto L_008F84;
    case 0x008F86u: goto L_008F86;
    case 0x008F89u: goto L_008F89;
    case 0x008F8Bu: goto L_008F8B;
    case 0x008F8Du: goto L_008F8D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008E1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Au, 4u, 3u, cpu.address("abs", 0x1493u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E1A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1493u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008E1D;
L_008E1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Du,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E1D ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Du), cpu.m8?8:16));
    goto L_008E1F;
L_008E1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E1Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E1F BNE -> $008E6F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008E6F; }
    goto L_008E21;
L_008E21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E21u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E21u, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E21 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008E24;
L_008E24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E24u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E24 CMP
    cpu.compareA(0xC1u);
    goto L_008E26;
L_008E26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E26u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E26 BEQ -> $008E6F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008E6F; }
    goto L_008E28;
L_008E28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E28u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E28u, 6u, 3u, cpu.address("abs", 0x0F30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E28 DEC
    cpu.decMem(hw, cpu.address("abs", 0xF30u), cpu.m8?8:16);
    goto L_008E2B;
L_008E2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E2B BPL -> $008E6F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008E6F; }
    goto L_008E2D;
L_008E2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E2D LDA
    cpu.setA(0x28u, 8);
    goto L_008E2F;
L_008E2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E2Fu, 4u, 3u, cpu.address("abs", 0x0F30u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E2F STA
    hw.write(cpu.address("abs", 0xF30u), cpu.a, cpu.m8?8:16);
    goto L_008E32;
L_008E32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E32u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E32u, 4u, 3u, cpu.address("abs", 0x0F31u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E32 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF31u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008E35;
L_008E35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E35u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E35u, 4u, 3u, cpu.address("abs", 0x0F32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E35 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xF32u), cpu.m8?8:16));
    goto L_008E38;
L_008E38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E38u, 4u, 3u, cpu.address("abs", 0x0F33u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E38 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xF33u), cpu.m8?8:16));
    goto L_008E3B;
L_008E3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E3B BEQ -> $008E6F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008E6F; }
    goto L_008E3D;
L_008E3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E3D LDX
    cpu.setX(0x2u, 8);
    goto L_008E3F;
L_008E3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Fu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E3Fu, 7u, 3u, cpu.address("absx", 0x0F31u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E3F DEC
    cpu.decMem(hw, cpu.address("absx", 0xF31u), cpu.m8?8:16);
    goto L_008E42;
L_008E42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E42u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E42 BPL -> $008E4C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008E4C; }
    goto L_008E44;
L_008E44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E44 LDA
    cpu.setA(0x9u, 8);
    goto L_008E46;
L_008E46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E46u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E46u, 5u, 3u, cpu.address("absx", 0x0F31u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E46 STA
    hw.write(cpu.address("absx", 0xF31u), cpu.a, cpu.m8?8:16);
    goto L_008E49;
L_008E49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E49u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E49 DEX
    cpu.decReg('X');
    goto L_008E4A;
L_008E4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E4A BPL -> $008E3F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008E3F; }
    goto L_008E4C;
L_008E4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Cu, 4u, 3u, cpu.address("abs", 0x0F31u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E4C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF31u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008E4F;
L_008E4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E4F BNE -> $008E60
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008E60; }
    goto L_008E51;
L_008E51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E51u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E51u, 4u, 3u, cpu.address("abs", 0x0F32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E51 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF32u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008E54;
L_008E54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E54u,cpu,0x2Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E54u, 4u, 3u, cpu.address("abs", 0x0F33u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E54 AND
    cpu.logicAnd(hw.readW(cpu.address("abs", 0xF33u), cpu.m8?8:16));
    goto L_008E57;
L_008E57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E57u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E57 CMP
    cpu.compareA(0x9u);
    goto L_008E59;
L_008E59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E59u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E59 BNE -> $008E60
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008E60; }
    goto L_008E5B;
L_008E5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E5B LDA
    cpu.setA(0xFFu, 8);
    goto L_008E5D;
L_008E5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E5Du, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E5D STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_008E60;
L_008E60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E60u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E60u, 4u, 3u, cpu.address("abs", 0x0F31u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E60 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF31u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008E63;
L_008E63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E63u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E63u, 4u, 3u, cpu.address("abs", 0x0F32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E63 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xF32u), cpu.m8?8:16));
    goto L_008E66;
L_008E66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E66u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E66u, 4u, 3u, cpu.address("abs", 0x0F33u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E66 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xF33u), cpu.m8?8:16));
    goto L_008E69;
L_008E69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E69u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E69u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E69 BNE -> $008E6F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008E6F; }
    goto L_008E6B;
L_008E6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Bu, 8u, 4u, 0x00F606u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $008E6B JSL -> $00F606 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8E6Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8E6Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F606u, 0x008E6Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008E6F;
L_008E6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E6Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8E6Fu,0x008E6Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E6Fu, 4u, 3u, cpu.address("abs", 0x0F31u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E6F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF31u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008E72;
L_008E72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E72u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E72u, 4u, 3u, cpu.address("abs", 0x0F25u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E72 STA
    hw.write(cpu.address("abs", 0xF25u), cpu.a, cpu.m8?8:16);
    goto L_008E75;
L_008E75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E75u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E75u, 4u, 3u, cpu.address("abs", 0x0F32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E75 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF32u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008E78;
L_008E78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E78u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E78u, 4u, 3u, cpu.address("abs", 0x0F26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E78 STA
    hw.write(cpu.address("abs", 0xF26u), cpu.a, cpu.m8?8:16);
    goto L_008E7B;
L_008E7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Bu, 4u, 3u, cpu.address("abs", 0x0F33u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E7B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF33u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008E7E;
L_008E7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E7Eu, 4u, 3u, cpu.address("abs", 0x0F27u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E7E STA
    hw.write(cpu.address("abs", 0xF27u), cpu.a, cpu.m8?8:16);
    goto L_008E81;
L_008E81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E81u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E81 LDX
    cpu.setX(0x10u, 8);
    goto L_008E83;
L_008E83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E83u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E83 LDY
    cpu.setY(0x0u, 8);
    goto L_008E85;
L_008E85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E85u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E85u, 4u + ((((0x0F31u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0F31u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E85 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF31u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008E88;
L_008E88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E88u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E88 BNE -> $008E95
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008E95; }
    goto L_008E8A;
L_008E8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E8A LDA
    cpu.setA(0xFCu, 8);
    goto L_008E8C;
L_008E8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Cu, 5u, 3u, cpu.address("absx", 0x0F15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E8C STA
    hw.write(cpu.address("absx", 0xF15u), cpu.a, cpu.m8?8:16);
    goto L_008E8F;
L_008E8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E8Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E8F INY
    cpu.inc('Y');
    goto L_008E90;
L_008E90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E90u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E90u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E90 INX
    cpu.inc('X');
    goto L_008E91;
L_008E91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E91u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E91 CPY
    cpu.compareY(0x2u);
    goto L_008E93;
L_008E93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E93u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E93 BNE -> $008E85
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008E85; }
    goto L_008E95;
L_008E95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E95u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E95u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E95 LDX
    cpu.setX(0x3u, 8);
    goto L_008E97;
L_008E97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E97u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E97u, 4u + ((((0x0F36u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F36u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E97 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008E9A;
L_008E9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E9A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_008E9C;
L_008E9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E9C STZ
    hw.write(cpu.address("dp", 0x1u), 0, cpu.m8?8:16);
    goto L_008E9E;
L_008E9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8E9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8E9Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008E9E REP
    cpu.rep(0x20u);
    goto L_008EA0;
L_008EA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA0u, 5u + ((((0x0F34u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EA0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF34u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008EA3;
L_008EA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA3u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EA3 SEC
    cpu.setFlag('C', true);
    goto L_008EA4;
L_008EA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA4u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EA4 SBC
    cpu.sbc(0x423Fu);
    goto L_008EA7;
L_008EA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EA7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008EA9;
L_008EA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA9u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EA9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EA9 SBC
    cpu.sbc(0xFu);
    goto L_008EAC;
L_008EAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EACu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EAC BCC -> $008EBF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_008EBF; }
    goto L_008EAE;
L_008EAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EAEu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EAEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EAE SEP
    cpu.sep(0x20u);
    goto L_008EB0;
L_008EB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EB0 LDA
    cpu.setA(0xFu, 8);
    goto L_008EB2;
L_008EB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB2u, 5u, 3u, cpu.address("absx", 0x0F36u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EB2 STA
    hw.write(cpu.address("absx", 0xF36u), cpu.a, cpu.m8?8:16);
    goto L_008EB5;
L_008EB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EB5 LDA
    cpu.setA(0x42u, 8);
    goto L_008EB7;
L_008EB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB7u, 5u, 3u, cpu.address("absx", 0x0F35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EB7 STA
    hw.write(cpu.address("absx", 0xF35u), cpu.a, cpu.m8?8:16);
    goto L_008EBA;
L_008EBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EBA LDA
    cpu.setA(0x3Fu, 8);
    goto L_008EBC;
L_008EBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBCu, 5u, 3u, cpu.address("absx", 0x0F34u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EBC STA
    hw.write(cpu.address("absx", 0xF34u), cpu.a, cpu.m8?8:16);
    goto L_008EBF;
L_008EBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EBFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EBF SEP
    cpu.sep(0x20u);
    goto L_008EC1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EBF SEP
    cpu.sep(0x20u);
    goto L_008EC1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EBFu,0x008EBFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_008EC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC1u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EC1 DEX
    cpu.decReg('X');
    goto L_008EC2;
L_008EC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC2u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EC2 DEX
    cpu.decReg('X');
    goto L_008EC3;
L_008EC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC3u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EC3 DEX
    cpu.decReg('X');
    goto L_008EC4;
L_008EC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EC4 BPL -> $008E97
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008E97; }
    goto L_008EC6;
L_008EC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC6u, 4u, 3u, cpu.address("abs", 0x0F36u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EC6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008EC9;
L_008EC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EC9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_008ECB;
L_008ECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECBu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008ECB STZ
    hw.write(cpu.address("dp", 0x1u), 0, cpu.m8?8:16);
    goto L_008ECD;
L_008ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu, 4u, 3u, cpu.address("abs", 0x0F35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008ECD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF35u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008ED0;
L_008ED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008ED0 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_008ED2;
L_008ED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED2u, 4u, 3u, cpu.address("abs", 0x0F34u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008ED2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF34u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008ED5;
L_008ED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008ED5 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_008ED7;
L_008ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008ED7 LDX
    cpu.setX(0x14u, 8);
    goto L_008ED9;
L_008ED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008ED9 LDY
    cpu.setY(0x0u, 8);
    goto L_008EDB;
L_008EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDBu, 6u, 3u, cpu.address("abs", 0x9012u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008EDB JSR -> $009012 stack real
    { cpu.push16Value(hw,0x8EDDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EDEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9012u), 0x008EDBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008EDE;
L_008EDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EDEu,0x008EDEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EDE LDX
    cpu.setX(0x0u, 8);
    goto L_008EE0;
L_008EE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE0u, 4u + ((((0x0F29u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EE0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF29u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008EE3;
L_008EE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EE3 BNE -> $008EEF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008EEF; }
    goto L_008EE5;
L_008EE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EE5 LDA
    cpu.setA(0xFCu, 8);
    goto L_008EE7;
L_008EE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE7u, 5u, 3u, cpu.address("absx", 0x0F29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EE7 STA
    hw.write(cpu.address("absx", 0xF29u), cpu.a, cpu.m8?8:16);
    goto L_008EEA;
L_008EEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EEA INX
    cpu.inc('X');
    goto L_008EEB;
L_008EEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEBu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EEB CPX
    cpu.compareX(0x6u);
    goto L_008EED;
L_008EED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EED BNE -> $008EE0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008EE0; }
    goto L_008EEF;
L_008EEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEFu, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EEF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDB3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008EF2;
L_008EF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EF2 BEQ -> $008F1D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F1D; }
    goto L_008EF4;
L_008EF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF4u, 4u, 3u, cpu.address("abs", 0x0F39u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EF4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF39u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008EF7;
L_008EF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EF7 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_008EF9;
L_008EF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF9u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EF9 STZ
    hw.write(cpu.address("dp", 0x1u), 0, cpu.m8?8:16);
    goto L_008EFB;
L_008EFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFBu, 4u, 3u, cpu.address("abs", 0x0F38u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EFB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008EFE;
L_008EFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008EFE STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_008F00;
L_008F00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F00u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F00u, 4u, 3u, cpu.address("abs", 0x0F37u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F00 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xF37u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F03;
L_008F03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F03u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F03u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F03 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_008F05;
L_008F05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F05u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F05u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F05 LDX
    cpu.setX(0x14u, 8);
    goto L_008F07;
L_008F07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F07 LDY
    cpu.setY(0x0u, 8);
    goto L_008F09;
L_008F09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F09u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F09u, 6u, 3u, cpu.address("abs", 0x9012u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008F09 JSR -> $009012 stack real
    { cpu.push16Value(hw,0x8F0Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F0Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9012u), 0x008F09u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008F0C;
L_008F0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F0Cu,0x008F0Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F0C LDX
    cpu.setX(0x0u, 8);
    goto L_008F0E;
L_008F0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Eu, 4u + ((((0x0F29u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F0E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF29u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F11;
L_008F11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F11u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F11 BNE -> $008F1D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F1D; }
    goto L_008F13;
L_008F13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F13u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F13u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F13 LDA
    cpu.setA(0xFCu, 8);
    goto L_008F15;
L_008F15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F15u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F15u, 5u, 3u, cpu.address("absx", 0x0F29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F15 STA
    hw.write(cpu.address("absx", 0xF29u), cpu.a, cpu.m8?8:16);
    goto L_008F18;
L_008F18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F18u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F18 INX
    cpu.inc('X');
    goto L_008F19;
L_008F19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F19u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F19 CPX
    cpu.compareX(0x6u);
    goto L_008F1B;
L_008F1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F1B BNE -> $008F0E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F0E; }
    goto L_008F1D;
L_008F1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Du, 4u, 3u, cpu.address("abs", 0x13CCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13CCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F20;
L_008F20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F20 BEQ -> $008F3B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F3B; }
    goto L_008F22;
L_008F22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F22u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F22u, 6u, 3u, cpu.address("abs", 0x13CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F22 DEC
    cpu.decMem(hw, cpu.address("abs", 0x13CCu), cpu.m8?8:16);
    goto L_008F25;
L_008F25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F25u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F25u, 6u, 3u, cpu.address("abs", 0x0DBFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F25 INC
    cpu.incMem(hw, cpu.address("abs", 0xDBFu), cpu.m8?8:16);
    goto L_008F28;
L_008F28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F28u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F28u, 4u, 3u, cpu.address("abs", 0x0DBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F28 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F2B;
L_008F2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F2B CMP
    cpu.compareA(0x64u);
    goto L_008F2D;
L_008F2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F2D BCC -> $008F3B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_008F3B; }
    goto L_008F2F;
L_008F2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Fu, 6u, 3u, cpu.address("abs", 0x18E4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F2F INC
    cpu.incMem(hw, cpu.address("abs", 0x18E4u), cpu.m8?8:16);
    goto L_008F32;
L_008F32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F32u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F32u, 4u, 3u, cpu.address("abs", 0x0DBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F32 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F35;
L_008F35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F35u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F35 SEC
    cpu.setFlag('C', true);
    goto L_008F36;
L_008F36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F36u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F36 SBC
    cpu.sbc(0x64u);
    goto L_008F38;
L_008F38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F38u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F38u, 4u, 3u, cpu.address("abs", 0x0DBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F38 STA
    hw.write(cpu.address("abs", 0xDBFu), cpu.a, cpu.m8?8:16);
    goto L_008F3B;
L_008F3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Bu, 4u, 3u, cpu.address("abs", 0x0DBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F3B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F3E;
L_008F3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F3E BMI -> $008F49
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_008F49; }
    goto L_008F40;
L_008F40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F40u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F40 CMP
    cpu.compareA(0x62u);
    goto L_008F42;
L_008F42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F42u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F42 BCC -> $008F49
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_008F49; }
    goto L_008F44;
L_008F44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F44u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F44 LDA
    cpu.setA(0x62u, 8);
    goto L_008F46;
L_008F46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F46u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F46u, 4u, 3u, cpu.address("abs", 0x0DBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F46 STA
    hw.write(cpu.address("abs", 0xDBEu), cpu.a, cpu.m8?8:16);
    goto L_008F49;
L_008F49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F49u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F49u, 4u, 3u, cpu.address("abs", 0x0DBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F49 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F4C;
L_008F4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Cu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F4C INC
    cpu.inc('A');
    goto L_008F4D;
L_008F4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F4Du, 6u, 3u, cpu.address("abs", 0x9045u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008F4D JSR -> $009045 stack real
    { cpu.push16Value(hw,0x8F4Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F50u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9045u), 0x008F4Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008F50;
L_008F50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F50u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F50u,0x008F50u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F50u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F50 TXY
    cpu.transfer("TXY");
    goto L_008F51;
L_008F51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F51u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F51u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F51 BNE -> $008F55
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F55; }
    goto L_008F53;
L_008F53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F53u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F53 LDX
    cpu.setX(0xFCu, 8);
    goto L_008F55;
L_008F55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F55u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F55u, 4u, 3u, cpu.address("abs", 0x0F16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F55 STX
    hw.write(cpu.address("abs", 0xF16u), cpu.x, cpu.x8?8:16);
    goto L_008F58;
L_008F58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F58u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F58u, 4u, 3u, cpu.address("abs", 0x0F17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F58 STA
    hw.write(cpu.address("abs", 0xF17u), cpu.a, cpu.m8?8:16);
    goto L_008F5B;
L_008F5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Bu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Bu, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F5B LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDB3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008F5E;
L_008F5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F5Eu, 4u + ((((0x0F48u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F5E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F61;
L_008F61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F61u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F61 CMP
    cpu.compareA(0x64u);
    goto L_008F63;
L_008F63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F63u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F63 BCC -> $008F73
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_008F73; }
    goto L_008F65;
L_008F65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F65u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F65u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F65 LDA
    cpu.setA(0xFFu, 8);
    goto L_008F67;
L_008F67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F67u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F67u, 4u, 3u, cpu.address("abs", 0x1425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F67 STA
    hw.write(cpu.address("abs", 0x1425u), cpu.a, cpu.m8?8:16);
    goto L_008F6A;
L_008F6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Au, 4u + ((((0x0F48u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0F48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F6A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xF48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F6D;
L_008F6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F6D SEC
    cpu.setFlag('C', true);
    goto L_008F6E;
L_008F6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F6Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F6E SBC
    cpu.sbc(0x64u);
    goto L_008F70;
L_008F70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F70u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F70u, 5u, 3u, cpu.address("absx", 0x0F48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F70 STA
    hw.write(cpu.address("absx", 0xF48u), cpu.a, cpu.m8?8:16);
    goto L_008F73;
L_008F73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F73u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F73u, 4u, 3u, cpu.address("abs", 0x0DBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F73 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDBFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008F76;
L_008F76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F76u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F76u, 6u, 3u, cpu.address("abs", 0x9045u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008F76 JSR -> $009045 stack real
    { cpu.push16Value(hw,0x8F78u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F79u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9045u), 0x008F76u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008F79;
L_008F79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F79u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F79u,0x008F79u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F79u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F79u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F79 TXY
    cpu.transfer("TXY");
    goto L_008F7A;
L_008F7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F7A BNE -> $008F7E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008F7E; }
    goto L_008F7C;
L_008F7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F7C LDX
    cpu.setX(0xFCu, 8);
    goto L_008F7E;
L_008F7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Eu, 4u, 3u, cpu.address("abs", 0x0F14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F7E STA
    hw.write(cpu.address("abs", 0xF14u), cpu.a, cpu.m8?8:16);
    goto L_008F81;
L_008F81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F81u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F81u, 4u, 3u, cpu.address("abs", 0x0F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F81 STX
    hw.write(cpu.address("abs", 0xF13u), cpu.x, cpu.x8?8:16);
    goto L_008F84;
L_008F84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F84u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F84u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F84 SEP
    cpu.sep(0x20u);
    goto L_008F86;
L_008F86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F86u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F86u, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F86 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDB3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008F89;
L_008F89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F89u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F89u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F89 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_008F8B;
L_008F8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F8B STZ
    hw.write(cpu.address("dp", 0x1u), 0, cpu.m8?8:16);
    goto L_008F8D;
L_008F8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008F8D STZ
    hw.write(cpu.address("dp", 0x3u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F8Fu,0x008F8Du); return;
}

void sub_009021_E0M0X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x009012u: goto L_009012;
    case 0x009021u: goto L_009021;
    case 0x009023u: goto L_009023;
    case 0x009026u: goto L_009026;
    case 0x009028u: goto L_009028;
    case 0x00902Au: goto L_00902A;
    case 0x00902Cu: goto L_00902C;
    case 0x00902Eu: goto L_00902E;
    case 0x009030u: goto L_009030;
    case 0x009032u: goto L_009032;
    case 0x009034u: goto L_009034;
    case 0x009037u: goto L_009037;
    case 0x009039u: goto L_009039;
    case 0x00903Au: goto L_00903A;
    case 0x00903Bu: goto L_00903B;
    case 0x00903Cu: goto L_00903C;
    case 0x00903Du: goto L_00903D;
    case 0x00903Eu: goto L_00903E;
    case 0x009040u: goto L_009040;
    case 0x009042u: goto L_009042;
    case 0x009044u: goto L_009044;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_009012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009012 SEP
    cpu.sep(0x20u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9014u,0x009012u); return;
L_009021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9021u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9021u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9021u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009021 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009023;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9021u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9021u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009021 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009023;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9021u,0x009021u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9023u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u, 5u + ((((0x8FFAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8FFAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009023 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x8FFAu), cpu.m8?8:16));
    goto L_009026;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u, 5u + ((((0x8FFAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8FFAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009023 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x8FFAu), cpu.m8?8:16));
    goto L_009026;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9023u,0x009023u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_009026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009026 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_009028;
L_009028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9028u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9028u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009028 BCC -> $009039
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_009039; }
    goto L_00902A;
L_00902A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00902A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00902C;
L_00902C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00902C STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_00902E;
L_00902E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00902E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009030;
L_009030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9030u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9030u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009030 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_009032;
L_009032:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9032u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9032u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9032u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009032 SEP
    cpu.sep(0x20u);
    goto L_009034;
L_009034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9034u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9034u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9034u, 7u, 3u, cpu.address("absx", 0x0F15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009034 INC
    cpu.incMem(hw, cpu.address("absx", 0xF15u), cpu.m8?8:16);
    goto L_009037;
L_009037:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9037u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9037u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9037u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009037 BRA -> $009017
    hw.requestDispatch(0x009017u,0x009037u); return;
L_009039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9039u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9039u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009039 INX
    cpu.inc('X');
    goto L_00903A;
L_00903A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00903A INY
    cpu.inc('Y');
    goto L_00903B;
L_00903B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00903B INY
    cpu.inc('Y');
    goto L_00903C;
L_00903C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00903C INY
    cpu.inc('Y');
    goto L_00903D;
L_00903D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00903D INY
    cpu.inc('Y');
    goto L_00903E;
L_00903E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00903E CPY
    cpu.compareY(0x18u);
    goto L_009040;
L_009040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9040u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9040u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009040 BNE -> $009012
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009012; }
    goto L_009042;
L_009042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9042u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9042u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009042 SEP
    cpu.sep(0x20u);
    goto L_009044;
L_009044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9044u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9044u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9044u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009044 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009044u);return;} hw.unresolvedReturn(0x009044u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_009021_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x009012u: goto L_009012;
    case 0x009021u: goto L_009021;
    case 0x009023u: goto L_009023;
    case 0x009026u: goto L_009026;
    case 0x009028u: goto L_009028;
    case 0x00902Au: goto L_00902A;
    case 0x00902Cu: goto L_00902C;
    case 0x00902Eu: goto L_00902E;
    case 0x009030u: goto L_009030;
    case 0x009032u: goto L_009032;
    case 0x009034u: goto L_009034;
    case 0x009037u: goto L_009037;
    case 0x009039u: goto L_009039;
    case 0x00903Au: goto L_00903A;
    case 0x00903Bu: goto L_00903B;
    case 0x00903Cu: goto L_00903C;
    case 0x00903Du: goto L_00903D;
    case 0x00903Eu: goto L_00903E;
    case 0x009040u: goto L_009040;
    case 0x009042u: goto L_009042;
    case 0x009044u: goto L_009044;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_009012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009012 SEP
    cpu.sep(0x20u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9014u,0x009012u); return;
L_009021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9021u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9021u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009021 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009023;
L_009023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u, 5u + ((((0x8FFAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8FFAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009023 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x8FFAu), cpu.m8?8:16));
    goto L_009026;
L_009026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009026 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_009028;
L_009028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9028u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9028u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009028 BCC -> $009039
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_009039; }
    goto L_00902A;
L_00902A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00902A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00902C;
L_00902C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00902C STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_00902E;
L_00902E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00902E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009030;
L_009030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9030u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9030u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009030 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_009032;
L_009032:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9032u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9032u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9032u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009032 SEP
    cpu.sep(0x20u);
    goto L_009034;
L_009034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9034u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9034u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9034u, 7u, 3u, cpu.address("absx", 0x0F15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009034 INC
    cpu.incMem(hw, cpu.address("absx", 0xF15u), cpu.m8?8:16);
    goto L_009037;
L_009037:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9037u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9037u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9037u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009037 BRA -> $009017
    hw.requestDispatch(0x009017u,0x009037u); return;
L_009039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9039u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9039u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009039 INX
    cpu.inc('X');
    goto L_00903A;
L_00903A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00903A INY
    cpu.inc('Y');
    goto L_00903B;
L_00903B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00903B INY
    cpu.inc('Y');
    goto L_00903C;
L_00903C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00903C INY
    cpu.inc('Y');
    goto L_00903D;
L_00903D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00903D INY
    cpu.inc('Y');
    goto L_00903E;
L_00903E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00903E CPY
    cpu.compareY(0x18u);
    goto L_009040;
L_009040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9040u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9040u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009040 BNE -> $009012
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009012; }
    goto L_009042;
L_009042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9042u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9042u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009042 SEP
    cpu.sep(0x20u);
    goto L_009044;
L_009044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9044u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9044u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9044u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009044 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009044u);return;} hw.unresolvedReturn(0x009044u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00955E_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00955Eu: goto L_00955E;
    case 0x009560u: goto L_009560;
    case 0x009564u: goto L_009564;
    case 0x009566u: goto L_009566;
    case 0x009569u: goto L_009569;
    case 0x00956Bu: goto L_00956B;
    case 0x00956Eu: goto L_00956E;
    case 0x009571u: goto L_009571;
    case 0x009574u: goto L_009574;
    case 0x009576u: goto L_009576;
    case 0x009579u: goto L_009579;
    case 0x00957Bu: goto L_00957B;
    case 0x00957Du: goto L_00957D;
    case 0x00957Eu: goto L_00957E;
    case 0x009580u: goto L_009580;
    case 0x009582u: goto L_009582;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00955E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x955Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x955Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x955Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00955E LDY
    cpu.setY(0x2Fu, 8);
    goto L_009560;
L_009560:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9560u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9560u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9560u, 8u, 4u, 0x00BA28u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $009560 JSL -> $00BA28 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9563u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9564u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00BA28u, 0x009560u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009564;
L_009564:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9564u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9564u,0x009564u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9564u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9564u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009564 LDA
    cpu.setA(0x80u, 8);
    goto L_009566;
L_009566:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9566u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9566u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9566u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009566 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_009569;
L_009569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9569u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9569u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009569 REP
    cpu.rep(0x30u);
    goto L_00956B;
L_00956B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x956Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x956Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x956Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00956B LDA
    cpu.setA(0x4600u, 16);
    goto L_00956E;
L_00956E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x956Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x956Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x956Eu, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00956E STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_009571;
L_009571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9571u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9571u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9571u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009571 LDX
    cpu.setX(0x200u, 16);
    goto L_009574;
L_009574:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9574u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9574u,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9574u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $009574 LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009576;
L_009576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9576u, 5u, 3u, cpu.address("abs", 0x2118u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009576 STA
    hw.write(cpu.address("abs", 0x2118u), cpu.a, cpu.m8?8:16);
    goto L_009579;
L_009579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9579u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9579u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009579 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_00957B;
L_00957B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x957Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x957Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x957Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00957B INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_00957D;
L_00957D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x957Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x957Du,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x957Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00957D DEX
    cpu.decReg('X');
    goto L_00957E;
L_00957E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x957Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x957Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x957Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00957E BNE -> $009574
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009574; }
    goto L_009580;
L_009580:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9580u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9580u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9580u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009580 SEP
    cpu.sep(0x30u);
    goto L_009582;
L_009582:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9582u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9582u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9582u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009582 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009582u);return;} hw.unresolvedReturn(0x009582u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_009750_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0093CAu: goto L_0093CA;
    case 0x0093CCu: goto L_0093CC;
    case 0x0093CFu: goto L_0093CF;
    case 0x0093D1u: goto L_0093D1;
    case 0x0093D4u: goto L_0093D4;
    case 0x0093D7u: goto L_0093D7;
    case 0x0093DAu: goto L_0093DA;
    case 0x0093DDu: goto L_0093DD;
    case 0x0093E0u: goto L_0093E0;
    case 0x0093E3u: goto L_0093E3;
    case 0x0093E6u: goto L_0093E6;
    case 0x0093E8u: goto L_0093E8;
    case 0x0093EAu: goto L_0093EA;
    case 0x0093ECu: goto L_0093EC;
    case 0x0093EFu: goto L_0093EF;
    case 0x0093F1u: goto L_0093F1;
    case 0x0093F4u: goto L_0093F4;
    case 0x0093F7u: goto L_0093F7;
    case 0x0093F9u: goto L_0093F9;
    case 0x0093FCu: goto L_0093FC;
    case 0x009750u: goto L_009750;
    case 0x009753u: goto L_009753;
    case 0x009756u: goto L_009756;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0093CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093CA LDA
    cpu.setA(0xFu, 8);
    goto L_0093CC;
L_0093CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CCu, 4u, 3u, cpu.address("abs", 0x0DAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093CC STA
    hw.write(cpu.address("abs", 0xDAEu), cpu.a, cpu.m8?8:16);
    goto L_0093CF;
L_0093CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093CF LDA
    cpu.setA(0x1u, 8);
    goto L_0093D1;
L_0093D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D1u, 4u, 3u, cpu.address("abs", 0x0DAFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093D1 STA
    hw.write(cpu.address("abs", 0xDAFu), cpu.a, cpu.m8?8:16);
    goto L_0093D4;
L_0093D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D4u, 4u, 3u, cpu.address("abs", 0x192Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093D4 STZ
    hw.write(cpu.address("abs", 0x192Eu), 0, cpu.m8?8:16);
    goto L_0093D7;
L_0093D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D7u, 6u, 3u, cpu.address("abs", 0xABEDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093D7 JSR -> $00ABED stack real
    { cpu.push16Value(hw,0x93D9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93DAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABEDu), 0x0093D7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0093DA;
L_0093DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93DAu,0x0093DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DAu, 4u, 3u, cpu.address("abs", 0x0701u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093DA STZ
    hw.write(cpu.address("abs", 0x701u), 0, cpu.m8?8:16);
    goto L_0093DD;
L_0093DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DDu, 4u, 3u, cpu.address("abs", 0x0702u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093DD STZ
    hw.write(cpu.address("abs", 0x702u), 0, cpu.m8?8:16);
    goto L_0093E0;
L_0093E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E0u, 6u, 3u, cpu.address("abs", 0x922Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093E0 JSR -> $00922F stack real
    { cpu.push16Value(hw,0x93E2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93E3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x922Fu), 0x0093E0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0093E3;
L_0093E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93E3u,0x0093E3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E3u, 4u, 3u, cpu.address("abs", 0x1B92u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093E3 STZ
    hw.write(cpu.address("abs", 0x1B92u), 0, cpu.m8?8:16);
    goto L_0093E6;
L_0093E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093E6 LDX
    cpu.setX(0x10u, 8);
    goto L_0093E8;
L_0093E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093E8 LDY
    cpu.setY(0x4u, 8);
    goto L_0093EA;
L_0093EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EA LDA
    cpu.setA(0x1u, 8);
    goto L_0093EC;
L_0093EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ECu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ECu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EC STA
    hw.write(cpu.address("abs", 0xD9Bu), cpu.a, cpu.m8?8:16);
    goto L_0093EF;
L_0093EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EF LDA
    cpu.setA(0x20u, 8);
    goto L_0093F1;
L_0093F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F1u, 6u, 3u, cpu.address("abs", 0x93FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093F1 JSR -> $0093FD stack real
    { cpu.push16Value(hw,0x93F3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93F4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x93FDu), 0x0093F1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0093F4;
L_0093F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93F4u,0x0093F4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u, 6u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F4 INC
    cpu.incMem(hw, cpu.address("abs", 0x100u), cpu.m8?8:16);
    goto L_0093F7;
L_0093F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F7 LDA
    cpu.setA(0x81u, 8);
    goto L_0093F9;
L_0093F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F9 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_0093FC;
L_0093FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093FC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0093FCu);return;} hw.unresolvedReturn(0x0093FCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_009750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9750u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9750u, 6u, 3u, cpu.address("abs", 0x85FAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009750 JSR -> $0085FA stack real
    { cpu.push16Value(hw,0x9752u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9753u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85FAu), 0x009750u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009753;
L_009753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9753u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9753u,0x009753u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9753u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9753u, 6u, 3u, cpu.address("abs", 0xA82Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009753 JSR -> $00A82D stack real
    { cpu.push16Value(hw,0x9755u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9756u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA82Du), 0x009753u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009756;
L_009756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9756u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9756u,0x009756u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9756u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9756u, 3u, 3u, cpu.address("abs", 0x93CAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009756 JMP -> $0093CA
    goto L_0093CA;
}

void sub_00CC68_E0M1X1CQ_part3(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CDC6u: goto L_00CDC6;
    case 0x00CDC7u: goto L_00CDC7;
    case 0x00CDC8u: goto L_00CDC8;
    case 0x00CDC9u: goto L_00CDC9;
    case 0x00CDCAu: goto L_00CDCA;
    case 0x00CDCCu: goto L_00CDCC;
    case 0x00CDCDu: goto L_00CDCD;
    case 0x00CDCEu: goto L_00CDCE;
    case 0x00CDCFu: goto L_00CDCF;
    case 0x00CDD0u: goto L_00CDD0;
    case 0x00CDD2u: goto L_00CDD2;
    case 0x00CDD4u: goto L_00CDD4;
    case 0x00CDD6u: goto L_00CDD6;
    case 0x00CDD7u: goto L_00CDD7;
    case 0x00CDD9u: goto L_00CDD9;
    case 0x00CDDCu: goto L_00CDDC;
    case 0x00DB17u: goto L_00DB17;
    case 0x00DB19u: goto L_00DB19;
    case 0x00DB1Bu: goto L_00DB1B;
    case 0x00DB1Eu: goto L_00DB1E;
    case 0x00DB21u: goto L_00DB21;
    case 0x00DB24u: goto L_00DB24;
    case 0x00DB26u: goto L_00DB26;
    case 0x00DB29u: goto L_00DB29;
    case 0x00DB2Bu: goto L_00DB2B;
    case 0x00DB2Du: goto L_00DB2D;
    case 0x00DB2Eu: goto L_00DB2E;
    case 0x00DB2Fu: goto L_00DB2F;
    case 0x00DB31u: goto L_00DB31;
    case 0x00DB32u: goto L_00DB32;
    case 0x00DB33u: goto L_00DB33;
    case 0x00DB34u: goto L_00DB34;
    case 0x00DB36u: goto L_00DB36;
    case 0x00DB38u: goto L_00DB38;
    case 0x00DB39u: goto L_00DB39;
    case 0x00DB3Bu: goto L_00DB3B;
    case 0x00DB3Du: goto L_00DB3D;
    case 0x00DB3Eu: goto L_00DB3E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CDC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC6u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC6u, 5u, 3u, cpu.address("abs", 0x13E0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC6 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00CDC9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC6u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC6 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00CDC9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC6u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC6 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00CDC9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC6u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC6 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_00CDC9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDC6u,0x00CDC6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC7u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC7 CPX
    cpu.compareX(0x13u);
    goto L_00CDC9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDC7u,0x00CDC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC8u,cpu,0x13u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC8u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xADu) & 0xFFFFu), 2u, 0u);
    // $00CDC8 ORA
    cpu.logicOr(hw.readW(cpu.addressStackIndirectY(hw, 0xADu), cpu.m8?8:16));
    goto L_00CDCA;
L_00CDC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC9u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u, 5u, 3u, cpu.address("abs", 0x141Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CDCC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u, 4u, 3u, cpu.address("abs", 0x141Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CDCC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u, 4u, 3u, cpu.address("abs", 0x141Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CDCC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u, 4u, 3u, cpu.address("abs", 0x141Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDC9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CDCC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDC9u,0x00CDC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCAu,cpu,0x1Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCAu, 7u, 3u, cpu.address("absx", 0xC914u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCA ASL
    cpu.aslMem(hw, cpu.address("absx", 0xC914u), cpu.m8?8:16);
    goto L_00CDCD;
L_00CDCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDCCu))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCC CMP
    cpu.compareA(0xD001u);
    goto L_00CDCF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCC CMP
    cpu.compareA(0x1u);
    goto L_00CDCE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCC CMP
    cpu.compareA(0x1u);
    goto L_00CDCE;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCC CMP
    cpu.compareA(0x1u);
    goto L_00CDCE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDCCu,0x00CDCCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCDu,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCDu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xD0u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $00CDCD ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0xD0u), cpu.m8?8:16));
    goto L_00CDCF;
L_00CDCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDCEu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCE BNE -> $00CDDC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CDDC; }
    goto L_00CDD0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCE BNE -> $00CDDC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CDDC; }
    goto L_00CDD0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCE BNE -> $00CDDC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CDDC; }
    goto L_00CDD0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDCEu,0x00CDCEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDCFu))return;
  // 3 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCFu,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCFu, 8u, 3u, cpu.address("abs", 0x1624u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCF TSB
    cpu.tsb(hw, cpu.address("abs", 0x1624u), cpu.m8?8:16);
    goto L_00CDD2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCFu,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCFu, 6u, 3u, cpu.address("abs", 0x1624u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDCF TSB
    cpu.tsb(hw, cpu.address("abs", 0x1624u), cpu.m8?8:16);
    goto L_00CDD2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDCFu,0x00CDCFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDD0u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD0u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD0 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), false);
    goto L_00CDD2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD0u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD0 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), false);
    goto L_00CDD2;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD0u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD0 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), false);
    goto L_00CDD2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDD0u,0x00CDD0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDD2u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD2u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD2 BVC -> $00CDDC
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_00CDDC; }
    goto L_00CDD4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD2u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD2 BVC -> $00CDDC
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_00CDDC; }
    goto L_00CDD4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD2u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD2 BVC -> $00CDDC
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_00CDDC; }
    goto L_00CDD4;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD2u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD2 BVC -> $00CDDC
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_00CDDC; }
    goto L_00CDD4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDD2u,0x00CDD2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDD4u))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD4 LDA
    cpu.setA(0x8D08u, 16);
    goto L_00CDD7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD4 LDA
    cpu.setA(0x8u, 8);
    goto L_00CDD6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD4 LDA
    cpu.setA(0x8u, 8);
    goto L_00CDD6;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD4 LDA
    cpu.setA(0x8u, 8);
    goto L_00CDD6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDD4u,0x00CDD4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDD6u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD6u, 4u, 3u, cpu.address("abs", 0x18DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD6 STA
    hw.write(cpu.address("abs", 0x18DBu), cpu.a, cpu.m8?8:16);
    goto L_00CDD9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD6u, 4u, 3u, cpu.address("abs", 0x18DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD6 STA
    hw.write(cpu.address("abs", 0x18DBu), cpu.a, cpu.m8?8:16);
    goto L_00CDD9;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD6u, 4u, 3u, cpu.address("abs", 0x18DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD6 STA
    hw.write(cpu.address("abs", 0x18DBu), cpu.a, cpu.m8?8:16);
    goto L_00CDD9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDD6u,0x00CDD6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDD7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD7u,cpu,0xDBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CDD7 STP
    hw.stopped=true; return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDD7u,0x00CDD7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDD9u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD9u, 6u, 3u, cpu.address("abs", 0xFEA8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CDD9 JSR -> $00FEA8 stack real
    { cpu.push16Value(hw,0xCDDBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCDDCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFEA8u), 0x00CDD9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CDDC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD9u, 6u, 3u, cpu.address("abs", 0xFEA8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CDD9 JSR -> $00FEA8 stack real
    { cpu.push16Value(hw,0xCDDBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCDDCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFEA8u), 0x00CDD9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CDDC;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDD9u, 6u, 3u, cpu.address("abs", 0xFEA8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CDD9 JSR -> $00FEA8 stack real
    { cpu.push16Value(hw,0xCDDBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCDDCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFEA8u), 0x00CDD9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CDDC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDD9u,0x00CDD9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00CDDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDDCu))return;
  // 5 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CDDC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CDDCu);return;} hw.unresolvedReturn(0x00CDDCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CDDC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CDDCu);return;} hw.unresolvedReturn(0x00CDDCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CDDC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CDDCu);return;} hw.unresolvedReturn(0x00CDDCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDDCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CDDC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CDDCu);return;} hw.unresolvedReturn(0x00CDDCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCDDCu,0x00CDDCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB17u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB17u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB17 STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_00DB19;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB17u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB17u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB17 STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_00DB19;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB17u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB17u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB17 STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_00DB19;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB17u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB17u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB17 STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_00DB19;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB17u,0x00DB17u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB19u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB19u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB19u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB19 STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    goto L_00DB1B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB19u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB19u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB19 STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    goto L_00DB1B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB19u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB19u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB19 STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    goto L_00DB1B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB19u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB19u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB19 STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    goto L_00DB1B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB19u,0x00DB19u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB1Bu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu, 5u, 3u, cpu.address("abs", 0x13DFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB1B STZ
    hw.write(cpu.address("abs", 0x13DFu), 0, cpu.m8?8:16);
    goto L_00DB1E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu, 4u, 3u, cpu.address("abs", 0x13DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB1B STZ
    hw.write(cpu.address("abs", 0x13DFu), 0, cpu.m8?8:16);
    goto L_00DB1E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu, 4u, 3u, cpu.address("abs", 0x13DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB1B STZ
    hw.write(cpu.address("abs", 0x13DFu), 0, cpu.m8?8:16);
    goto L_00DB1E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu, 4u, 3u, cpu.address("abs", 0x13DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB1B STZ
    hw.write(cpu.address("abs", 0x13DFu), 0, cpu.m8?8:16);
    goto L_00DB1E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB1Bu,0x00DB1Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB1Eu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu, 5u, 3u, cpu.address("abs", 0x140Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB1E STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    goto L_00DB21;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB1E STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    goto L_00DB21;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB1E STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    goto L_00DB21;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB1E STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    goto L_00DB21;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB1Eu,0x00DB1Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB21u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u, 4u, 3u, cpu.address("abs", 0x149Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB21 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x149Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DB24;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u, 5u, 3u, cpu.address("abs", 0x149Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB21 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x149Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DB24;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u, 4u, 3u, cpu.address("abs", 0x149Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB21 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x149Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DB24;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u, 4u, 3u, cpu.address("abs", 0x149Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB21 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x149Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DB24;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB21u,0x00DB21u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB24u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB24 BEQ -> $00DB7D
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB7Du,0x00DB24u); return; }
    goto L_00DB26;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB24 BEQ -> $00DB7D
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB7Du,0x00DB24u); return; }
    goto L_00DB26;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB24 BEQ -> $00DB7D
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB7Du,0x00DB24u); return; }
    goto L_00DB26;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB24 BEQ -> $00DB7D
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB7Du,0x00DB24u); return; }
    goto L_00DB26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB24u,0x00DB24u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB26u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u, 5u, 3u, cpu.address("abs", 0x1878u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB26 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB29;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB26 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB29;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB26 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB29;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB26 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB29;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB26u,0x00DB26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB29u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB29 BPL -> $00DB2E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB2E; }
    goto L_00DB2B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB29 BPL -> $00DB2E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB2E; }
    goto L_00DB2B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB29 BPL -> $00DB2E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB2E; }
    goto L_00DB2B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB29 BPL -> $00DB2E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB2E; }
    goto L_00DB2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB29u,0x00DB29u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB2Bu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2B EOR
    cpu.logicXor(0x1AFFu);
    goto L_00DB2E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2B EOR
    cpu.logicXor(0xFFu);
    goto L_00DB2D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2B EOR
    cpu.logicXor(0xFFu);
    goto L_00DB2D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2B EOR
    cpu.logicXor(0xFFu);
    goto L_00DB2D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB2Bu,0x00DB2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB2Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2D INC
    cpu.inc('A');
    goto L_00DB2E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2D INC
    cpu.inc('A');
    goto L_00DB2E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2D INC
    cpu.inc('A');
    goto L_00DB2E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB2Du,0x00DB2Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB2Eu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2E TAX
    cpu.transfer("TAX");
    goto L_00DB2F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2E TAX
    cpu.transfer("TAX");
    goto L_00DB2F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2E TAX
    cpu.transfer("TAX");
    goto L_00DB2F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2E TAX
    cpu.transfer("TAX");
    goto L_00DB2F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB2Eu,0x00DB2Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB2Fu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2F CPY
    cpu.compareY(0x1Eu);
    goto L_00DB31;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2F CPY
    cpu.compareY(0x901Eu);
    goto L_00DB32;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2F CPY
    cpu.compareY(0x1Eu);
    goto L_00DB31;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2F CPY
    cpu.compareY(0x1Eu);
    goto L_00DB31;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB2Fu,0x00DB2Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB31u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB31u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB31 BCC -> $00DB45
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB45u,0x00DB31u); return; }
    goto L_00DB33;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB31u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB31 BCC -> $00DB45
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB45u,0x00DB31u); return; }
    goto L_00DB33;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB31u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB31 BCC -> $00DB45
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB45u,0x00DB31u); return; }
    goto L_00DB33;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB31u,0x00DB31u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB32u,cpu,0x12u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB32u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xBDu) & 0xFFFFu), 2u, 0u);
    // $00DB32 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirect(hw, 0xBDu), cpu.m8?8:16));
    goto L_00DB34;
L_00DB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB33u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB33u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB33u, 5u + ((((0xDADFu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDADFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB33 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDADFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB36;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB33u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB33u, 4u + ((((0xDADFu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDADFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB33 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDADFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB36;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB33u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB33u, 4u + ((((0xDADFu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDADFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB33 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDADFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB36;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB33u,0x00DB33u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB34u,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB34u, 5u, 4u, ((0x782CDAu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB34 CMP
    cpu.compareA(hw.readW(((0x782CDAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00DB38;
L_00DB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB36u))return;
  // 5 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB36u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB36u, 5u, 3u, cpu.address("abs", 0x1878u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB36 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), false);
    goto L_00DB39;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB36u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB36u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB36 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), false);
    goto L_00DB39;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB36u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB36u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB36 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), false);
    goto L_00DB39;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB36u,0x00DB36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB38u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB38 CLC
    cpu.setFlag('C', false);
    goto L_00DB39;
L_00DB39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB39u))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB39 BPL -> $00DB3E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB3E; }
    goto L_00DB3B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB39 BPL -> $00DB3E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB3E; }
    goto L_00DB3B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB39 BPL -> $00DB3E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB3E; }
    goto L_00DB3B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB39 BPL -> $00DB3E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB3E; }
    goto L_00DB3B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB39u,0x00DB39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB3Bu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3B EOR
    cpu.logicXor(0xFFu);
    goto L_00DB3D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3B EOR
    cpu.logicXor(0x1AFFu);
    goto L_00DB3E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3B EOR
    cpu.logicXor(0xFFu);
    goto L_00DB3D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3B EOR
    cpu.logicXor(0xFFu);
    goto L_00DB3D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB3Bu,0x00DB3Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB3Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3D INC
    cpu.inc('A');
    goto L_00DB3E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3D INC
    cpu.inc('A');
    goto L_00DB3E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3D INC
    cpu.inc('A');
    goto L_00DB3E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB3Du,0x00DB3Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB3Eu))return;
  // 6 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3E STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB40u,0x00DB3Eu); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3E STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB40u,0x00DB3Eu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3E STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB40u,0x00DB3Eu); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3E STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB40u,0x00DB3Eu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB3Eu,0x00DB3Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00CC68_E0M1X1C0_part9(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00DC00u: goto L_00DC00;
    case 0x00DC02u: goto L_00DC02;
    case 0x00DC03u: goto L_00DC03;
    case 0x00DC04u: goto L_00DC04;
    case 0x00DC05u: goto L_00DC05;
    case 0x00DC07u: goto L_00DC07;
    case 0x00DC09u: goto L_00DC09;
    case 0x00DC0Au: goto L_00DC0A;
    case 0x00DC0Bu: goto L_00DC0B;
    case 0x00DC0Du: goto L_00DC0D;
    case 0x00DC0Fu: goto L_00DC0F;
    case 0x00DC11u: goto L_00DC11;
    case 0x00DC14u: goto L_00DC14;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00DC00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC00u))return;
  // 16 variantes de decodificacao M/X para este endereco; 6 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC00u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC00u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC00 STZ
    hw.write(cpu.address("dp", 0x74u), 0, cpu.m8?8:16);
    goto L_00DC02;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC00u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC00u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC00 STZ
    hw.write(cpu.address("dp", 0x74u), 0, cpu.m8?8:16);
    goto L_00DC02;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC00u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC00u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC00 STZ
    hw.write(cpu.address("dp", 0x74u), 0, cpu.m8?8:16);
    goto L_00DC02;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC00u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC00u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC00 STZ
    hw.write(cpu.address("dp", 0x74u), 0, cpu.m8?8:16);
    goto L_00DC02;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC00u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC00u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC00 STZ
    hw.write(cpu.address("dp", 0x74u), 0, cpu.m8?8:16);
    goto L_00DC02;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC00u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC00u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC00 STZ
    hw.write(cpu.address("dp", 0x74u), 0, cpu.m8?8:16);
    goto L_00DC02;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC00u,0x00DC00u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC02u))return;
  // 16 variantes de decodificacao M/X para este endereco; 6 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC02u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC02u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC02 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DC02u);return;} hw.unresolvedReturn(0x00DC02u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC02u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC02u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC02 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DC02u);return;} hw.unresolvedReturn(0x00DC02u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC02u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC02u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC02 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DC02u);return;} hw.unresolvedReturn(0x00DC02u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC02u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC02u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC02 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DC02u);return;} hw.unresolvedReturn(0x00DC02u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC02u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC02u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC02 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DC02u);return;} hw.unresolvedReturn(0x00DC02u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC02u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC02u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC02 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00DC02u);return;} hw.unresolvedReturn(0x00DC02u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC02u,0x00DC02u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC03u))return;
  // 10 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC03u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC03 INY
    cpu.inc('Y');
    goto L_00DC04;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC03u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC03 INY
    cpu.inc('Y');
    goto L_00DC04;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC03u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC03 INY
    cpu.inc('Y');
    goto L_00DC04;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC03u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC03 INY
    cpu.inc('Y');
    goto L_00DC04;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC03u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC03 INY
    cpu.inc('Y');
    goto L_00DC04;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC03u,0x00DC03u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC04u))return;
  // 10 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC04u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC04 INY
    cpu.inc('Y');
    goto L_00DC05;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC04u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC04 INY
    cpu.inc('Y');
    goto L_00DC05;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC04u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC04 INY
    cpu.inc('Y');
    goto L_00DC05;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC04u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC04 INY
    cpu.inc('Y');
    goto L_00DC05;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC04u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC04 INY
    cpu.inc('Y');
    goto L_00DC05;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC04u,0x00DC04u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC05u))return;
  // 10 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC05u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC05u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC05 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC07;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC05u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC05u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC05 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC07;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC05u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC05u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC05 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC07;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC05u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC05u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC05 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC07;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC05u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC05u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC05 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC07;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC05u,0x00DC05u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC07u))return;
  // 10 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC07u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC07 AND
    cpu.logicAnd(0x2u);
    goto L_00DC09;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC07u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC07 AND
    cpu.logicAnd(0xF002u);
    goto L_00DC0A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC07u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC07 AND
    cpu.logicAnd(0x2u);
    goto L_00DC09;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC07u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC07 AND
    cpu.logicAnd(0x2u);
    goto L_00DC09;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC07u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC07 AND
    cpu.logicAnd(0x2u);
    goto L_00DC09;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC07u,0x00DC07u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC09u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC09u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC09 BEQ -> $00DC16
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC16u,0x00DC09u); return; }
    goto L_00DC0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC09u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC09 BEQ -> $00DC16
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC16u,0x00DC09u); return; }
    goto L_00DC0B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC09u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC09 BEQ -> $00DC16
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC16u,0x00DC09u); return; }
    goto L_00DC0B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC09u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC09 BEQ -> $00DC16
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DC16u,0x00DC09u); return; }
    goto L_00DC0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC09u,0x00DC09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC0Au))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Au,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DC0A PHD
    cpu.push("PHD", hw);
    goto L_00DC0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC0Au,0x00DC0Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC0Bu))return;
  // 15 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC0B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC0D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC0B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC0D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC0B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC0D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC0B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC0D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC0B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC0D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC0Bu,0x00DC0Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC0Du))return;
  // 15 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC0D BMI -> $00DC11
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DC11; }
    goto L_00DC0F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC0D BMI -> $00DC11
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DC11; }
    goto L_00DC0F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC0D BMI -> $00DC11
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DC11; }
    goto L_00DC0F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC0D BMI -> $00DC11
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DC11; }
    goto L_00DC0F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC0D BMI -> $00DC11
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DC11; }
    goto L_00DC0F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC0Du,0x00DC0Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC0Fu))return;
  // 15 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC0F STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00DC11;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC0F STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00DC11;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC0F STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00DC11;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC0F STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00DC11;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC0F STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00DC11;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC0Fu,0x00DC0Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC11u))return;
  // 15 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u, 4u + ((((0xDAB7u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDAB7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC11 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDAB7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC14;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u, 5u + ((((0xDAB7u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDAB7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC11 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDAB7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC14;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u, 4u + 1u, 3u, cpu.address("absy", 0xDAB7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC11 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDAB7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC14;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u, 4u + ((((0xDAB7u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDAB7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC11 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDAB7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC14;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u, 4u + ((((0xDAB7u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDAB7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC11 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDAB7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DC14;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC11u,0x00DC11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DC14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC14u))return;
  // 15 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC14u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC14u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC14 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC16u,0x00DC14u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC14u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC14u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC14 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC16u,0x00DC14u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC14u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC14u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC14 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC16u,0x00DC14u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC14u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC14u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC14 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC16u,0x00DC14u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC14u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC14u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DC14 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC16u,0x00DC14u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC14u,0x00DC14u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00E92B_E1M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00E92Bu: goto L_00E92B;
    case 0x00E92Eu: goto L_00E92E;
    case 0x00E931u: goto L_00E931;
    case 0x00E933u: goto L_00E933;
    case 0x00E936u: goto L_00E936;
    case 0x00E938u: goto L_00E938;
    case 0x00E93Bu: goto L_00E93B;
    case 0x00E93Du: goto L_00E93D;
    case 0x00E940u: goto L_00E940;
    case 0x00E942u: goto L_00E942;
    case 0x00E944u: goto L_00E944;
    case 0x00E946u: goto L_00E946;
    case 0x00E948u: goto L_00E948;
    case 0x00E94Au: goto L_00E94A;
    case 0x00E94Cu: goto L_00E94C;
    case 0x00E94Eu: goto L_00E94E;
    case 0x00E951u: goto L_00E951;
    case 0x00E953u: goto L_00E953;
    case 0x00E955u: goto L_00E955;
    case 0x00E956u: goto L_00E956;
    case 0x00E958u: goto L_00E958;
    case 0x00E95Au: goto L_00E95A;
    case 0x00E95Cu: goto L_00E95C;
    case 0x00E95Du: goto L_00E95D;
    case 0x00E95Fu: goto L_00E95F;
    case 0x00E961u: goto L_00E961;
    case 0x00E963u: goto L_00E963;
    case 0x00E966u: goto L_00E966;
    case 0x00E968u: goto L_00E968;
    case 0x00E96Au: goto L_00E96A;
    case 0x00E96Bu: goto L_00E96B;
    case 0x00E96Du: goto L_00E96D;
    case 0x00E96Fu: goto L_00E96F;
    case 0x00E971u: goto L_00E971;
    case 0x00E972u: goto L_00E972;
    case 0x00E974u: goto L_00E974;
    case 0x00E976u: goto L_00E976;
    case 0x00E978u: goto L_00E978;
    case 0x00E97Bu: goto L_00E97B;
    case 0x00E97Du: goto L_00E97D;
    case 0x00E97Fu: goto L_00E97F;
    case 0x00E981u: goto L_00E981;
    case 0x00E982u: goto L_00E982;
    case 0x00E984u: goto L_00E984;
    case 0x00E987u: goto L_00E987;
    case 0x00E989u: goto L_00E989;
    case 0x00E98Cu: goto L_00E98C;
    case 0x00E98Fu: goto L_00E98F;
    case 0x00E991u: goto L_00E991;
    case 0x00E993u: goto L_00E993;
    case 0x00E995u: goto L_00E995;
    case 0x00E998u: goto L_00E998;
    case 0x00E99Au: goto L_00E99A;
    case 0x00E99Cu: goto L_00E99C;
    case 0x00E9A0u: goto L_00E9A0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00E92B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE92Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE92Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE92Bu, 6u, 3u, cpu.address("abs", 0xEAA6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E92B JSR -> $00EAA6 stack real
    { cpu.push16Value(hw,0xE92Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE92Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEAA6u), 0x00E92Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E92E;
L_00E92E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE92Eu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE92Eu,0x00E92Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE92Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE92Eu, 4u, 3u, cpu.address("abs", 0x185Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E92E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x185Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E931;
L_00E931:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE931u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE931u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE931u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E931 BEQ -> $00E938
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00E938; }
    goto L_00E933;
L_00E933:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE933u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE933u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE933u, 6u, 3u, cpu.address("abs", 0xEE1Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E933 JSR -> $00EE1D stack real
    { cpu.push16Value(hw,0xE935u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE936u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEE1Du), 0x00E933u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E936;
L_00E936:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE936u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE936u,0x00E936u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE936u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE936u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E936 BRA -> $00E98C
    goto L_00E98C;
L_00E938:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE938u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE938u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE938u, 4u, 3u, cpu.address("abs", 0x13EFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E938 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13EFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E93B;
L_00E93B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE93Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE93Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE93Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E93B STA
    hw.write(cpu.address("dp", 0x8Du), cpu.a, cpu.m8?8:16);
    goto L_00E93D;
L_00E93D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE93Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE93Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE93Du, 4u, 3u, cpu.address("abs", 0x13EFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E93D STZ
    hw.write(cpu.address("abs", 0x13EFu), 0, cpu.m8?8:16);
    goto L_00E940;
L_00E940:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE940u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE940u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE940u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E940 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E942;
L_00E942:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE942u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE942u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE942u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E942 STA
    hw.write(cpu.address("dp", 0x8Fu), cpu.a, cpu.m8?8:16);
    goto L_00E944;
L_00E944:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE944u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE944u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE944u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E944 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E946;
L_00E946:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE946u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE946u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE946u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E946 BPL -> $00E978
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E978; }
    goto L_00E948;
L_00E948:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE948u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE948u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE948u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E948 AND
    cpu.logicAnd(0x82u);
    goto L_00E94A;
L_00E94A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE94Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE94Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE94Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E94A STA
    hw.write(cpu.address("dp", 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_00E94C;
L_00E94C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE94Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE94Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE94Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E94C LDA
    cpu.setA(0x1u, 8);
    goto L_00E94E;
L_00E94E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE94Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE94Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE94Eu, 4u, 3u, cpu.address("abs", 0x1933u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E94E STA
    hw.write(cpu.address("abs", 0x1933u), cpu.a, cpu.m8?8:16);
    goto L_00E951;
L_00E951:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE951u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE951u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE951u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E951 REP
    cpu.rep(0x20u);
    goto L_00E953;
L_00E953:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE953u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE953u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE953u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E953 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E955;
L_00E955:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE955u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE955u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE955u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E955 CLC
    cpu.setFlag('C', false);
    goto L_00E956;
L_00E956:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE956u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE956u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE956u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E956 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_00E958;
L_00E958:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE958u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE958u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE958u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E958 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00E95A;
L_00E95A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE95Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE95Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE95Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E95A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E95C;
L_00E95C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE95Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE95Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE95Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E95C CLC
    cpu.setFlag('C', false);
    goto L_00E95D;
L_00E95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE95Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE95Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E95D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16));
    goto L_00E95F;
L_00E95F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE95Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE95Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE95Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E95F STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00E961;
L_00E961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE961u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE961u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE961u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E961 SEP
    cpu.sep(0x20u);
    goto L_00E963;
L_00E963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE963u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE963u, 6u, 3u, cpu.address("abs", 0xEADBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E963 JSR -> $00EADB stack real
    { cpu.push16Value(hw,0xE965u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE966u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEADBu), 0x00E963u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E966;
L_00E966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE966u))return;
  // 8 variantes de decodificacao M/X para este endereco; 8 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E966 REP
    cpu.rep(0x20u);
    goto L_00E968;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E966 REP
    cpu.rep(0x20u);
    goto L_00E968;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E966 REP
    cpu.rep(0x20u);
    goto L_00E968;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E966 REP
    cpu.rep(0x20u);
    goto L_00E968;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E966 REP
    cpu.rep(0x20u);
    goto L_00E968;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E966 REP
    cpu.rep(0x20u);
    goto L_00E968;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E966 REP
    cpu.rep(0x20u);
    goto L_00E968;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE966u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E966 REP
    cpu.rep(0x20u);
    goto L_00E968;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE966u,0x00E966u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E968:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE968u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE968u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE968u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E968 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E96A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE968u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE968u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E968 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E96A;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE968u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE968u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E968 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E96A;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE968u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE968u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E968 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E96A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE968u,0x00E968u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E96A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE96Au))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E96A SEC
    cpu.setFlag('C', true);
    goto L_00E96B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E96A SEC
    cpu.setFlag('C', true);
    goto L_00E96B;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E96A SEC
    cpu.setFlag('C', true);
    goto L_00E96B;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E96A SEC
    cpu.setFlag('C', true);
    goto L_00E96B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE96Au,0x00E96Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E96B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE96Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Bu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E96B SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_00E96D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Bu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E96B SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_00E96D;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Bu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E96B SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_00E96D;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Bu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E96B SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_00E96D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE96Bu,0x00E96Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E96D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE96Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E96D STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00E96F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E96D STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00E96F;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E96D STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00E96F;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E96D STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00E96F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE96Du,0x00E96Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E96F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE96Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E96F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E971;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E96F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E971;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E96F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E971;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE96Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E96F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E971;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE96Fu,0x00E96Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E971:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE971u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE971u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE971u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E971 SEC
    cpu.setFlag('C', true);
    goto L_00E972;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE971u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE971u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E971 SEC
    cpu.setFlag('C', true);
    goto L_00E972;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE971u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE971u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E971 SEC
    cpu.setFlag('C', true);
    goto L_00E972;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE971u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE971u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E971 SEC
    cpu.setFlag('C', true);
    goto L_00E972;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE971u,0x00E971u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E972:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE972u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE972u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE972u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E972 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16));
    goto L_00E974;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE972u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE972u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E972 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16));
    goto L_00E974;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE972u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE972u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E972 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16));
    goto L_00E974;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE972u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE972u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E972 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16));
    goto L_00E974;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE972u,0x00E972u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE974u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE974u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE974u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E974 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00E976;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE974u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE974u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E974 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00E976;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE974u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE974u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E974 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00E976;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE974u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE974u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E974 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00E976;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE974u,0x00E974u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E976:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE976u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE976u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE976u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E976 SEP
    cpu.sep(0x20u);
    goto L_00E978;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE976u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE976u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E976 SEP
    cpu.sep(0x20u);
    goto L_00E978;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE976u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE976u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E976 SEP
    cpu.sep(0x20u);
    goto L_00E978;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE976u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE976u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E976 SEP
    cpu.sep(0x20u);
    goto L_00E978;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE976u,0x00E976u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E978:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE978u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE978u,cpu,0x0Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE978u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E978 ASL
    cpu.aslMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00E97B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE978u,cpu,0x0Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE978u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E978 ASL
    cpu.aslMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00E97B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE978u,cpu,0x0Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE978u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E978 ASL
    cpu.aslMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00E97B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE978u,cpu,0x0Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE978u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E978 ASL
    cpu.aslMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00E97B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE978u,0x00E978u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E97B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE97Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E97B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E97D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E97B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E97D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E97B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E97D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E97B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E97D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE97Bu,0x00E97Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E97D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE97Du))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E97D AND
    cpu.logicAnd(0x41u);
    goto L_00E97F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E97D AND
    cpu.logicAnd(0x41u);
    goto L_00E97F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E97D AND
    cpu.logicAnd(0x41u);
    goto L_00E97F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E97D AND
    cpu.logicAnd(0x41u);
    goto L_00E97F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE97Du,0x00E97Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E97F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE97Fu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E97F STA
    hw.write(cpu.address("dp", 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_00E981;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E97F STA
    hw.write(cpu.address("dp", 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_00E981;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E97F STA
    hw.write(cpu.address("dp", 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_00E981;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE97Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E97F STA
    hw.write(cpu.address("dp", 0x8Eu), cpu.a, cpu.m8?8:16);
    goto L_00E981;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE97Fu,0x00E97Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E981:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE981u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE981u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE981u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E981 ASL
    cpu.aslA();
    goto L_00E982;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE981u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE981u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E981 ASL
    cpu.aslA();
    goto L_00E982;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE981u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE981u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E981 ASL
    cpu.aslA();
    goto L_00E982;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE981u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE981u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E981 ASL
    cpu.aslA();
    goto L_00E982;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE981u,0x00E981u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E982:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE982u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE982u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE982u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E982 BMI -> $00E98C
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E98C; }
    goto L_00E984;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE982u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE982u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E982 BMI -> $00E98C
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E98C; }
    goto L_00E984;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE982u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE982u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E982 BMI -> $00E98C
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E98C; }
    goto L_00E984;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE982u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE982u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E982 BMI -> $00E98C
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E98C; }
    goto L_00E984;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE982u,0x00E982u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E984:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE984u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE984u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE984u, 4u, 3u, cpu.address("abs", 0x1933u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E984 STZ
    hw.write(cpu.address("abs", 0x1933u), 0, cpu.m8?8:16);
    goto L_00E987;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE984u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE984u, 4u, 3u, cpu.address("abs", 0x1933u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E984 STZ
    hw.write(cpu.address("abs", 0x1933u), 0, cpu.m8?8:16);
    goto L_00E987;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE984u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE984u, 4u, 3u, cpu.address("abs", 0x1933u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E984 STZ
    hw.write(cpu.address("abs", 0x1933u), 0, cpu.m8?8:16);
    goto L_00E987;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE984u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE984u, 4u, 3u, cpu.address("abs", 0x1933u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E984 STZ
    hw.write(cpu.address("abs", 0x1933u), 0, cpu.m8?8:16);
    goto L_00E987;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE984u,0x00E984u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E987:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE987u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE987u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE987u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E987 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x8Du), cpu.m8?8:16);
    goto L_00E989;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE987u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE987u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E987 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x8Du), cpu.m8?8:16);
    goto L_00E989;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE987u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE987u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E987 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x8Du), cpu.m8?8:16);
    goto L_00E989;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE987u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE987u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E987 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x8Du), cpu.m8?8:16);
    goto L_00E989;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE987u,0x00E987u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E989:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE989u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE989u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE989u, 6u, 3u, cpu.address("abs", 0xEADBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E989 JSR -> $00EADB stack real
    { cpu.push16Value(hw,0xE98Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE98Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEADBu), 0x00E989u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E98C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE989u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE989u, 6u, 3u, cpu.address("abs", 0xEADBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E989 JSR -> $00EADB stack real
    { cpu.push16Value(hw,0xE98Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE98Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEADBu), 0x00E989u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E98C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE989u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE989u, 6u, 3u, cpu.address("abs", 0xEADBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E989 JSR -> $00EADB stack real
    { cpu.push16Value(hw,0xE98Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE98Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEADBu), 0x00E989u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E98C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE989u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE989u, 6u, 3u, cpu.address("abs", 0xEADBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E989 JSR -> $00EADB stack real
    { cpu.push16Value(hw,0xE98Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE98Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEADBu), 0x00E989u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E98C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE989u,0x00E989u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E98C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE98Cu))return;
  // 8 variantes de decodificacao M/X para este endereco; 8 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu, 5u, 3u, cpu.address("abs", 0x1B96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E98C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E98F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu, 5u, 3u, cpu.address("abs", 0x1B96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E98C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E98F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu, 4u, 3u, cpu.address("abs", 0x1B96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E98C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E98F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu, 4u, 3u, cpu.address("abs", 0x1B96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E98C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E98F;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu, 5u, 3u, cpu.address("abs", 0x1B96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E98C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E98F;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu, 5u, 3u, cpu.address("abs", 0x1B96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E98C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E98F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu, 4u, 3u, cpu.address("abs", 0x1B96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E98C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E98F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Cu, 4u, 3u, cpu.address("abs", 0x1B96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E98C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E98F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE98Cu,0x00E98Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E98F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE98Fu))return;
  // 8 variantes de decodificacao M/X para este endereco; 8 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E98F BEQ -> $00E9A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00E9A1u,0x00E98Fu); return; }
    goto L_00E991;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E98F BEQ -> $00E9A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00E9A1u,0x00E98Fu); return; }
    goto L_00E991;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E98F BEQ -> $00E9A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00E9A1u,0x00E98Fu); return; }
    goto L_00E991;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E98F BEQ -> $00E9A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00E9A1u,0x00E98Fu); return; }
    goto L_00E991;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E98F BEQ -> $00E9A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00E9A1u,0x00E98Fu); return; }
    goto L_00E991;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E98F BEQ -> $00E9A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00E9A1u,0x00E98Fu); return; }
    goto L_00E991;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E98F BEQ -> $00E9A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00E9A1u,0x00E98Fu); return; }
    goto L_00E991;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE98Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E98F BEQ -> $00E9A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00E9A1u,0x00E98Fu); return; }
    goto L_00E991;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE98Fu,0x00E98Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E991:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE991u))return;
  // 8 variantes de decodificacao M/X para este endereco; 8 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE991u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE991u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E991 REP
    cpu.rep(0x20u);
    goto L_00E993;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE991u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE991u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E991 REP
    cpu.rep(0x20u);
    goto L_00E993;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE991u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE991u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E991 REP
    cpu.rep(0x20u);
    goto L_00E993;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE991u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE991u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E991 REP
    cpu.rep(0x20u);
    goto L_00E993;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE991u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE991u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E991 REP
    cpu.rep(0x20u);
    goto L_00E993;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE991u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE991u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E991 REP
    cpu.rep(0x20u);
    goto L_00E993;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE991u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE991u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E991 REP
    cpu.rep(0x20u);
    goto L_00E993;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE991u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE991u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E991 REP
    cpu.rep(0x20u);
    goto L_00E993;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE991u,0x00E991u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E993:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE993u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE993u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE993u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E993 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E995;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE993u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE993u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E993 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E995;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE993u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE993u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E993 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E995;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE993u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE993u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E993 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E995;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE993u,0x00E993u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E995:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE995u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE995u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE995u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E995 CMP
    cpu.compareA(0xFAu);
    goto L_00E998;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE995u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE995u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E995 CMP
    cpu.compareA(0xFAu);
    goto L_00E998;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE995u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE995u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E995 CMP
    cpu.compareA(0xFAu);
    goto L_00E998;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE995u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE995u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E995 CMP
    cpu.compareA(0xFAu);
    goto L_00E998;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE995u,0x00E995u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E998:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE998u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE998u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE998u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E998 SEP
    cpu.sep(0x20u);
    goto L_00E99A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE998u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE998u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E998 SEP
    cpu.sep(0x20u);
    goto L_00E99A;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE998u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE998u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E998 SEP
    cpu.sep(0x20u);
    goto L_00E99A;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE998u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE998u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E998 SEP
    cpu.sep(0x20u);
    goto L_00E99A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE998u,0x00E998u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E99A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE99Au))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE99Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE99Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E99A BCC -> $00E9FB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00E9FBu,0x00E99Au); return; }
    goto L_00E99C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE99Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE99Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E99A BCC -> $00E9FB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00E9FBu,0x00E99Au); return; }
    goto L_00E99C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE99Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE99Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E99A BCC -> $00E9FB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00E9FBu,0x00E99Au); return; }
    goto L_00E99C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE99Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE99Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E99A BCC -> $00E9FB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00E9FBu,0x00E99Au); return; }
    goto L_00E99C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE99Au,0x00E99Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E99C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE99Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE99Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE99Cu, 8u, 4u, 0x05B160u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00E99C JSL -> $05B160 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE99Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE9A0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05B160u, 0x00E99Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E9A0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE99Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE99Cu, 8u, 4u, 0x05B160u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00E99C JSL -> $05B160 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE99Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE9A0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05B160u, 0x00E99Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E9A0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE99Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE99Cu, 8u, 4u, 0x05B160u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00E99C JSL -> $05B160 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE99Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE9A0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05B160u, 0x00E99Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E9A0;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE99Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE99Cu, 8u, 4u, 0x05B160u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00E99C JSL -> $05B160 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE99Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE9A0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05B160u, 0x00E99Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00E9A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE99Cu,0x00E99Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00E9A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE9A0u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9A0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9A0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E9A0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00E9A0u);return;} hw.unresolvedReturn(0x00E9A0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9A0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9A0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E9A0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00E9A0u);return;} hw.unresolvedReturn(0x00E9A0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9A0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9A0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E9A0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00E9A0u);return;} hw.unresolvedReturn(0x00E9A0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE9A0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE9A0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E9A0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00E9A0u);return;} hw.unresolvedReturn(0x00E9A0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE9A0u,0x00E9A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EAA6_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EAA6u: goto L_00EAA6;
    case 0x00EAA9u: goto L_00EAA9;
    case 0x00EAABu: goto L_00EAAB;
    case 0x00EAAEu: goto L_00EAAE;
    case 0x00EAB1u: goto L_00EAB1;
    case 0x00EAB3u: goto L_00EAB3;
    case 0x00EAB5u: goto L_00EAB5;
    case 0x00EAB8u: goto L_00EAB8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EAA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA6u, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EAA6 STZ
    hw.write(cpu.address("abs", 0x13E5u), 0, cpu.m8?8:16);
    goto L_00EAA9;
L_00EAA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA9u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAA9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EAA9 STZ
    hw.write(cpu.address("dp", 0x77u), 0, cpu.m8?8:16);
    goto L_00EAAB;
L_00EAAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAABu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAABu, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EAAB STZ
    hw.write(cpu.address("abs", 0x13E1u), 0, cpu.m8?8:16);
    goto L_00EAAE;
L_00EAAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAAEu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAAEu, 4u, 3u, cpu.address("abs", 0x13EEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EAAE STZ
    hw.write(cpu.address("abs", 0x13EEu), 0, cpu.m8?8:16);
    goto L_00EAB1;
L_00EAB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB1u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EAB1 STZ
    hw.write(cpu.address("dp", 0x8Au), 0, cpu.m8?8:16);
    goto L_00EAB3;
L_00EAB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EAB3 STZ
    hw.write(cpu.address("dp", 0x8Bu), 0, cpu.m8?8:16);
    goto L_00EAB5;
L_00EAB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB5u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB5u, 4u, 3u, cpu.address("abs", 0x140Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EAB5 STZ
    hw.write(cpu.address("abs", 0x140Eu), 0, cpu.m8?8:16);
    goto L_00EAB8;
L_00EAB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEAB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEAB8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EAB8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EAB8u);return;} hw.unresolvedReturn(0x00EAB8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00EBDD_E0M1X1C1_part33(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF8Au: goto L_00EF8A;
    case 0x00EF8Cu: goto L_00EF8C;
    case 0x00EF90u: goto L_00EF90;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF8Au))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF8A BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF8Au); return; }
    goto L_00EF8C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF8A BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF8Au); return; }
    goto L_00EF8C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF8A BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF8Au); return; }
    goto L_00EF8C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF8A BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF8Au); return; }
    goto L_00EF8C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF8A BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF8Au); return; }
    goto L_00EF8C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF8Au,0x00EF8Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF8Cu))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu, 8u, 4u, 0x0286BFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EF8C JSL -> $0286BF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEF8Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF90u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0286BFu, 0x00EF8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF90;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu, 8u, 4u, 0x0286BFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EF8C JSL -> $0286BF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEF8Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF90u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0286BFu, 0x00EF8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF90;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu, 8u, 4u, 0x0286BFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EF8C JSL -> $0286BF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEF8Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF90u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0286BFu, 0x00EF8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF90;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu, 8u, 4u, 0x0286BFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EF8C JSL -> $0286BF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEF8Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF90u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0286BFu, 0x00EF8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF90;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu, 8u, 4u, 0x0286BFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EF8C JSL -> $0286BF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEF8Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF90u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0286BFu, 0x00EF8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF90;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF8Cu,0x00EF8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF90u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF90 LDA
    cpu.setA(0x8D25u, 16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF93u,0x00EF90u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF90 LDA
    cpu.setA(0x8D25u, 16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF93u,0x00EF90u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF90 LDA
    cpu.setA(0x25u, 8);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF92u,0x00EF90u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF90 LDA
    cpu.setA(0x25u, 8);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF92u,0x00EF90u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF90 LDA
    cpu.setA(0x25u, 8);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF92u,0x00EF90u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF90u,0x00EF90u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part33(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF8Au: goto L_00EF8A;
    case 0x00EF8Cu: goto L_00EF8C;
    case 0x00EF90u: goto L_00EF90;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF8Au))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF8A BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF8Au); return; }
    goto L_00EF8C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF8A BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF8Au); return; }
    goto L_00EF8C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF8A BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF8Au); return; }
    goto L_00EF8C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF8A BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF8Au); return; }
    goto L_00EF8C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF8A BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF95u,0x00EF8Au); return; }
    goto L_00EF8C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF8Au,0x00EF8Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF8Cu))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu, 8u, 4u, 0x0286BFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EF8C JSL -> $0286BF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEF8Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF90u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0286BFu, 0x00EF8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF90;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu, 8u, 4u, 0x0286BFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EF8C JSL -> $0286BF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEF8Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF90u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0286BFu, 0x00EF8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF90;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu, 8u, 4u, 0x0286BFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EF8C JSL -> $0286BF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEF8Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF90u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0286BFu, 0x00EF8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF90;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu, 8u, 4u, 0x0286BFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EF8C JSL -> $0286BF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEF8Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF90u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0286BFu, 0x00EF8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF90;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu, 8u, 4u, 0x0286BFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EF8C JSL -> $0286BF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEF8Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF90u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0286BFu, 0x00EF8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF90;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF8Cu,0x00EF8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF90u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF90 LDA
    cpu.setA(0x8D25u, 16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF93u,0x00EF90u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF90 LDA
    cpu.setA(0x8D25u, 16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF93u,0x00EF90u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF90 LDA
    cpu.setA(0x25u, 8);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF92u,0x00EF90u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF90 LDA
    cpu.setA(0x25u, 8);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF92u,0x00EF90u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF90 LDA
    cpu.setA(0x25u, 8);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF92u,0x00EF90u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF90u,0x00EF90u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00F595_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00C95Bu: goto L_00C95B;
    case 0x00C95Du: goto L_00C95D;
    case 0x00C95Fu: goto L_00C95F;
    case 0x00C9FEu: goto L_00C9FE;
    case 0x00CA01u: goto L_00CA01;
    case 0x00CA04u: goto L_00CA04;
    case 0x00CA06u: goto L_00CA06;
    case 0x00CA08u: goto L_00CA08;
    case 0x00CA0Bu: goto L_00CA0B;
    case 0x00CA0Du: goto L_00CA0D;
    case 0x00CA0Fu: goto L_00CA0F;
    case 0x00CA12u: goto L_00CA12;
    case 0x00CA14u: goto L_00CA14;
    case 0x00CA16u: goto L_00CA16;
    case 0x00CA19u: goto L_00CA19;
    case 0x00CA1Bu: goto L_00CA1B;
    case 0x00CA1Cu: goto L_00CA1C;
    case 0x00CA1Eu: goto L_00CA1E;
    case 0x00CA20u: goto L_00CA20;
    case 0x00CA23u: goto L_00CA23;
    case 0x00CA25u: goto L_00CA25;
    case 0x00CA28u: goto L_00CA28;
    case 0x00CA2Bu: goto L_00CA2B;
    case 0x00CA2Du: goto L_00CA2D;
    case 0x00CA30u: goto L_00CA30;
    case 0x00F595u: goto L_00F595;
    case 0x00F597u: goto L_00F597;
    case 0x00F59Au: goto L_00F59A;
    case 0x00F59Bu: goto L_00F59B;
    case 0x00F59Du: goto L_00F59D;
    case 0x00F59Fu: goto L_00F59F;
    case 0x00F5A1u: goto L_00F5A1;
    case 0x00F5A3u: goto L_00F5A3;
    case 0x00F5A5u: goto L_00F5A5;
    case 0x00F5A7u: goto L_00F5A7;
    case 0x00F5A8u: goto L_00F5A8;
    case 0x00F5AAu: goto L_00F5AA;
    case 0x00F5ADu: goto L_00F5AD;
    case 0x00F5AFu: goto L_00F5AF;
    case 0x00F5B2u: goto L_00F5B2;
    case 0x00F5B6u: goto L_00F5B6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00C95B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC95Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C95B LDY
    cpu.setY(0xBu, 8);
    goto L_00C95D;
L_00C95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C95D LDA
    cpu.setA(0x1u, 8);
    goto L_00C95F;
L_00C95F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC95Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Fu, 3u, 3u, cpu.address("abs", 0xC9FEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C95F JMP -> $00C9FE
    goto L_00C9FE;
L_00C9FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9FEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9FEu, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00C9FE STA
    hw.write(cpu.address("abs", 0xDD5u), cpu.a, cpu.m8?8:16);
    goto L_00CA01;
L_00CA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA01u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA01u, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA01 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CA04;
L_00CA04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA04u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA04 BEQ -> $00CA25
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CA25; }
    goto L_00CA06;
L_00CA06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA06u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA06 LDX
    cpu.setX(0x8u, 8);
    goto L_00CA08;
L_00CA08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA08u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA08u, 4u, 3u, cpu.address("abs", 0x13BFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA08 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13BFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CA0B;
L_00CA0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA0B CMP
    cpu.compareA(0x13u);
    goto L_00CA0D;
L_00CA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA0D BNE -> $00CA12
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CA12; }
    goto L_00CA0F;
L_00CA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA0Fu, 6u, 3u, cpu.address("abs", 0x0DD5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA0F INC
    cpu.incMem(hw, cpu.address("abs", 0xDD5u), cpu.m8?8:16);
    goto L_00CA12;
L_00CA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA12u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA12 CMP
    cpu.compareA(0x31u);
    goto L_00CA14;
L_00CA14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA14u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA14u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA14 BEQ -> $00CA20
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CA20; }
    goto L_00CA16;
L_00CA16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA16u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA16u, 4u + ((((0xC9A6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xC9A6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA16 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0xC9A6u), cpu.m8?8:16));
    goto L_00CA19;
L_00CA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA19u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA19 BEQ -> $00CA20
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CA20; }
    goto L_00CA1B;
L_00CA1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA1B DEX
    cpu.decReg('X');
    goto L_00CA1C;
L_00CA1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA1C BNE -> $00CA16
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CA16; }
    goto L_00CA1E;
L_00CA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA1E BRA -> $00CA25
    goto L_00CA25;
L_00CA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA20u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA20u, 4u, 3u, cpu.address("abs", 0x13C6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA20 STX
    hw.write(cpu.address("abs", 0x13C6u), cpu.x, cpu.x8?8:16);
    goto L_00CA23;
L_00CA23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA23u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA23 LDY
    cpu.setY(0x18u, 8);
    goto L_00CA25;
L_00CA25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA25u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA25u, 4u, 3u, cpu.address("abs", 0x0100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA25 STY
    hw.write(cpu.address("abs", 0x100u), cpu.y, cpu.x8?8:16);
    goto L_00CA28;
L_00CA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA28u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA28u, 6u, 3u, cpu.address("abs", 0x1DE9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA28 INC
    cpu.incMem(hw, cpu.address("abs", 0x1DE9u), cpu.m8?8:16);
    goto L_00CA2B;
L_00CA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA2B LDA
    cpu.setA(0x1u, 8);
    goto L_00CA2D;
L_00CA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Du, 4u, 3u, cpu.address("abs", 0x13CEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CA2D STA
    hw.write(cpu.address("abs", 0x13CEu), cpu.a, cpu.m8?8:16);
    goto L_00CA30;
L_00CA30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA30u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA30u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CA30 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00CA30u);return;} hw.unresolvedReturn(0x00CA30u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00F595:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF595u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF595u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF595u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F595 REP
    cpu.rep(0x20u);
    goto L_00F597;
L_00F597:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF597u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF597u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF597u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F597 LDA
    cpu.setA(0xFF80u, 16);
    goto L_00F59A;
L_00F59A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF59Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF59Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF59Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F59A CLC
    cpu.setFlag('C', false);
    goto L_00F59B;
L_00F59B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF59Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF59Bu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF59Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F59B ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_00F59D;
L_00F59D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF59Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF59Du,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF59Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F59D CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16));
    goto L_00F59F;
L_00F59F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF59Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF59Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF59Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F59F BMI -> $00F5A3
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00F5A3; }
    goto L_00F5A1;
L_00F5A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5A1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5A1 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00F5A3;
L_00F5A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5A3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5A3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5A3 SEP
    cpu.sep(0x20u);
    goto L_00F5A5;
L_00F5A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5A5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5A5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x81u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5A5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x81u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F5A7;
L_00F5A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5A7u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5A7 DEC
    cpu.decReg('A');
    goto L_00F5A8;
L_00F5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5A8u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5A8 BMI -> $00F5B6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00F5B6; }
    goto L_00F5AA;
L_00F5AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5AAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5AAu, 4u, 3u, cpu.address("abs", 0x1B95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5AA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00F5AD;
L_00F5AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5ADu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5AD BEQ -> $00F5B2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00F5B2; }
    goto L_00F5AF;
L_00F5AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5AFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5AFu, 3u, 3u, cpu.address("abs", 0xC95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5AF JMP -> $00C95B
    goto L_00C95B;
L_00F5B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5B2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5B2u, 8u, 4u, 0x00F60Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F5B2 JSL -> $00F60A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF5B5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF5B6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F60Au, 0x00F5B2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F5B6;
L_00F5B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5B6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF5B6u,0x00F5B6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5B6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5B6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F5B6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F5B6u);return;} hw.unresolvedReturn(0x00F5B6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0183DA_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0183DAu: goto L_0183DA;
    case 0x0183DCu: goto L_0183DC;
    case 0x0183DFu: goto L_0183DF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0183DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0183DA LDA
    cpu.setA(0x28u, 8);
    goto L_0183DC;
L_0183DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DCu, 5u, 3u, cpu.address("absx", 0x1564u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0183DC STA
    hw.write(cpu.address("absx", 0x1564u), cpu.a, cpu.m8?8:16);
    goto L_0183DF;
L_0183DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0183DF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0183DFu);return;} hw.unresolvedReturn(0x0183DFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0183DA_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0183DAu: goto L_0183DA;
    case 0x0183DCu: goto L_0183DC;
    case 0x0183DFu: goto L_0183DF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0183DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0183DA LDA
    cpu.setA(0x28u, 8);
    goto L_0183DC;
L_0183DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DCu, 5u, 3u, cpu.address("absx", 0x1564u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0183DC STA
    hw.write(cpu.address("absx", 0x1564u), cpu.a, cpu.m8?8:16);
    goto L_0183DF;
L_0183DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0183DF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0183DFu);return;} hw.unresolvedReturn(0x0183DFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0184CE_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0184CEu: goto L_0184CE;
    case 0x0184D0u: goto L_0184D0;
    case 0x0184D2u: goto L_0184D2;
    case 0x0184D5u: goto L_0184D5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0184CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CEu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0184CE LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0184D0;
L_0184D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0184D0 AND
    cpu.logicAnd(0x10u);
    goto L_0184D2;
L_0184D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D2u, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0184D2 STA
    hw.write(cpu.address("absx", 0x151Cu), cpu.a, cpu.m8?8:16);
    goto L_0184D5;
L_0184D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0184D5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0184D5u);return;} hw.unresolvedReturn(0x0184D5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0184CE_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0184CEu: goto L_0184CE;
    case 0x0184D0u: goto L_0184D0;
    case 0x0184D2u: goto L_0184D2;
    case 0x0184D5u: goto L_0184D5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0184CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CEu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0184CE LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0184D0;
L_0184D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0184D0 AND
    cpu.logicAnd(0x10u);
    goto L_0184D2;
L_0184D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D2u, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0184D2 STA
    hw.write(cpu.address("absx", 0x151Cu), cpu.a, cpu.m8?8:16);
    goto L_0184D5;
L_0184D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0184D5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0184D5u);return;} hw.unresolvedReturn(0x0184D5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0185C2_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0185C2u: goto L_0185C2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0185C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0185C2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0185C2u);return;} hw.unresolvedReturn(0x0185C2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0185C2_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0185C2u: goto L_0185C2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0185C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0185C2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0185C2u);return;} hw.unresolvedReturn(0x0185C2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_018904_E0M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x018A8Eu: goto L_018A8E;
    case 0x018A90u: goto L_018A90;
    case 0x018A92u: goto L_018A92;
    case 0x018A94u: goto L_018A94;
    case 0x018A96u: goto L_018A96;
    case 0x018A99u: goto L_018A99;
    case 0x018A9Bu: goto L_018A9B;
    case 0x018A9Eu: goto L_018A9E;
    case 0x018AA0u: goto L_018AA0;
    case 0x018AA2u: goto L_018AA2;
    case 0x018AA5u: goto L_018AA5;
    case 0x018AA8u: goto L_018AA8;
    case 0x018AAAu: goto L_018AAA;
    case 0x018AACu: goto L_018AAC;
    case 0x018AAFu: goto L_018AAF;
    case 0x018AB1u: goto L_018AB1;
    case 0x018AB4u: goto L_018AB4;
    case 0x018AB6u: goto L_018AB6;
    case 0x018AB8u: goto L_018AB8;
    case 0x018ABCu: goto L_018ABC;
    case 0x018ABDu: goto L_018ABD;
    case 0x018ABEu: goto L_018ABE;
    case 0x018AC2u: goto L_018AC2;
    case 0x018AC3u: goto L_018AC3;
    case 0x018AC7u: goto L_018AC7;
    case 0x018AC9u: goto L_018AC9;
    case 0x018ACCu: goto L_018ACC;
    case 0x018ACFu: goto L_018ACF;
    case 0x018AD1u: goto L_018AD1;
    case 0x018AD4u: goto L_018AD4;
    case 0x018AD6u: goto L_018AD6;
    case 0x018AD9u: goto L_018AD9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_018A8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018A8E CMP
    cpu.compareA(0x8u);
    goto L_018A90;
L_018A90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A90u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018A90 LDA
    cpu.setA(0x4u, 8);
    goto L_018A92;
L_018A92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A92u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018A92 BCS -> $018A96
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_018A96; }
    goto L_018A94;
L_018A94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A94u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018A94 LDA
    cpu.setA(0x0u, 8);
    goto L_018A96;
L_018A96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A96u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A96u, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018A96 STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_018A99;
L_018A99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A99u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A99u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018A99 BRA -> $018B00
    hw.requestDispatch(0x018B00u,0x018A99u); return;
L_018A9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Bu, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018A9B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018A9E;
L_018A9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018A9E CMP
    cpu.compareA(0x1u);
    goto L_018AA0;
L_018AA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AA0 BNE -> $018B0A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x018B0Au,0x018AA0u); return; }
    goto L_018AA2;
L_018AA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA2u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA2u, 4u + ((((0x1594u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1594u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AA2 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1594u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018AA5;
L_018AA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA5u, 4u + ((((0x14C8u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AA5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018AA8;
L_018AA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AA8 CMP
    cpu.compareA(0x8u);
    goto L_018AAA;
L_018AAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AAA BCC -> $018AD9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_018AD9; }
    goto L_018AAC;
L_018AAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AACu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AACu, 4u + ((((0x00AAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x00AAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AAC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018AAF;
L_018AAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAFu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AAF BMI -> $018AD9
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_018AD9; }
    goto L_018AB1;
L_018AB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB1u, 4u + ((((0x009Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x009Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AB1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018AB4;
L_018AB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AB4 CMP
    cpu.compareA(0x21u);
    goto L_018AB6;
L_018AB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AB6 BEQ -> $018AD9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_018AD9; }
    goto L_018AB8;
L_018AB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB8u, 8u, 4u, 0x03B69Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $018AB8 JSL -> $03B69F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8ABBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8ABCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x03B69Fu, 0x018AB8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018ABC;
L_018ABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ABCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8ABCu,0x018ABCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABCu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018ABC PHX
    cpu.push("PHX", hw);
    goto L_018ABD;
L_018ABD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ABDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABDu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018ABD TYX
    cpu.transfer("TYX");
    goto L_018ABE;
L_018ABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABEu, 8u, 4u, 0x03B6E5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $018ABE JSL -> $03B6E5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AC1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AC2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x03B6E5u, 0x018ABEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018AC2;
L_018AC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AC2u,0x018AC2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC2u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018AC2 PLX
    cpu.pop("PLX", hw);
    goto L_018AC3;
L_018AC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC3u, 8u, 4u, 0x03B72Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $018AC3 JSL -> $03B72B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AC6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AC7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x03B72Bu, 0x018AC3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018AC7;
L_018AC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AC7u,0x018AC7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AC7 BCC -> $018AD9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_018AD9; }
    goto L_018AC9;
L_018AC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC9u, 6u, 3u, cpu.address("abs", 0xAC80u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018AC9 JSR -> $01AC80 stack real
    { cpu.push16Value(hw,0x8ACBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8ACCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC80u), 0x018AC9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018ACC;
L_018ACC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8ACCu,0x018ACCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACCu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACCu, 4u + ((((0x1594u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1594u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018ACC LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1594u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_018ACF;
L_018ACF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018ACF LDA
    cpu.setA(0x10u, 8);
    goto L_018AD1;
L_018AD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD1u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD1u, 5u, 3u, cpu.address("absy", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AD1 STA
    hw.write(cpu.address("absy", 0x1558u), cpu.a, cpu.m8?8:16);
    goto L_018AD4;
L_018AD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD4u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AD4 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_018AD6;
L_018AD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD6u, 5u, 3u, cpu.address("absy", 0x160Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $018AD6 STA
    hw.write(cpu.address("absy", 0x160Eu), cpu.a, cpu.m8?8:16);
    goto L_018AD9;
L_018AD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $018AD9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x018AD9u);return;} hw.unresolvedReturn(0x018AD9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_019F9B_E0M1X1C0_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01A0D9u: goto L_01A0D9;
    case 0x01A0DCu: goto L_01A0DC;
    case 0x01A0DEu: goto L_01A0DE;
    case 0x01A0E0u: goto L_01A0E0;
    case 0x01A0E2u: goto L_01A0E2;
    case 0x01A0E5u: goto L_01A0E5;
    case 0x01A0E7u: goto L_01A0E7;
    case 0x01A0EAu: goto L_01A0EA;
    case 0x01A0ECu: goto L_01A0EC;
    case 0x01A0EFu: goto L_01A0EF;
    case 0x01A0F1u: goto L_01A0F1;
    case 0x01A0F4u: goto L_01A0F4;
    case 0x01A0F6u: goto L_01A0F6;
    case 0x01A0F7u: goto L_01A0F7;
    case 0x01A0F9u: goto L_01A0F9;
    case 0x01A0FAu: goto L_01A0FA;
    case 0x01A0FDu: goto L_01A0FD;
    case 0x01A0FFu: goto L_01A0FF;
    case 0x01A101u: goto L_01A101;
    case 0x01A104u: goto L_01A104;
    case 0x01A107u: goto L_01A107;
    case 0x01A109u: goto L_01A109;
    case 0x01A10Bu: goto L_01A10B;
    case 0x01A10Du: goto L_01A10D;
    case 0x01A10Fu: goto L_01A10F;
    case 0x01A111u: goto L_01A111;
    case 0x01A113u: goto L_01A113;
    case 0x01A116u: goto L_01A116;
    case 0x01A118u: goto L_01A118;
    case 0x01A11Au: goto L_01A11A;
    case 0x01A11Bu: goto L_01A11B;
    case 0x01A11Du: goto L_01A11D;
    case 0x01A11Fu: goto L_01A11F;
    case 0x01A121u: goto L_01A121;
    case 0x01A123u: goto L_01A123;
    case 0x01A126u: goto L_01A126;
    case 0x01A128u: goto L_01A128;
    case 0x01A12Bu: goto L_01A12B;
    case 0x01A12Eu: goto L_01A12E;
    case 0x01AC80u: goto L_01AC80;
    case 0x01AC82u: goto L_01AC82;
    case 0x01AC84u: goto L_01AC84;
    case 0x01AC86u: goto L_01AC86;
    case 0x01AC89u: goto L_01AC89;
    case 0x01AC8Bu: goto L_01AC8B;
    case 0x01AC8Eu: goto L_01AC8E;
    case 0x01AC91u: goto L_01AC91;
    case 0x01AC93u: goto L_01AC93;
    case 0x01AC95u: goto L_01AC95;
    case 0x01AC98u: goto L_01AC98;
    case 0x01AC9Au: goto L_01AC9A;
    case 0x01AC9Cu: goto L_01AC9C;
    case 0x01AC9Eu: goto L_01AC9E;
    case 0x01ACA1u: goto L_01ACA1;
    case 0x01ACA4u: goto L_01ACA4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01A0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D9u, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0D9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A0DC;
L_01A0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0DC CMP
    cpu.compareA(0x3u);
    goto L_01A0DE;
L_01A0DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0DE BEQ -> $01A0E2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A0E2; }
    goto L_01A0E0;
L_01A0E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0E0 LDY
    cpu.setY(0x3Du, 8);
    goto L_01A0E2;
L_01A0E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E2u, 4u + ((((0x0094u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0094u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0E2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A0E5;
L_01A0E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0E5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_01A0E7;
L_01A0E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E7u, 4u + ((((0x0095u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0095u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0E7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A0EA;
L_01A0EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0EA STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_01A0EC;
L_01A0EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ECu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ECu, 4u + ((((0x0096u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0096u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0EC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A0EF;
L_01A0EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0EF STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_01A0F1;
L_01A0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F1u, 4u + ((((0x0097u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0097u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0F1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A0F4;
L_01A0F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0F4 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_01A0F6;
L_01A0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F6u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A0F6 PLY
    cpu.pop("PLY", hw);
    goto L_01A0F7;
L_01A0F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0F7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A0F9;
L_01A0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0F9 CLC
    cpu.setFlag('C', false);
    goto L_01A0FA;
L_01A0FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FAu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FAu, 4u + ((((0x9F5Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9F5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0FA ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x9F5Bu), cpu.m8?8:16));
    goto L_01A0FD;
L_01A0FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FDu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0FD STA
    hw.write(cpu.address("dpx", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_01A0FF;
L_01A0FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0FF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A101;
L_01A101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA101u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA101u, 4u + ((((0x9F61u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9F61u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A101 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x9F61u), cpu.m8?8:16));
    goto L_01A104;
L_01A104:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA104u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA104u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA104u, 5u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A104 STA
    hw.write(cpu.address("absx", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_01A107;
L_01A107:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA107u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA107u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA107u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A107 LDA
    cpu.setA(0xDu, 8);
    goto L_01A109;
L_01A109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA109u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA109u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA109u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A109 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x73u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A10B;
L_01A10B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A10B BNE -> $01A111
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A111; }
    goto L_01A10D;
L_01A10D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A10D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A10F;
L_01A10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A10F BNE -> $01A113
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A113; }
    goto L_01A111;
L_01A111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA111u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA111u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A111 LDA
    cpu.setA(0xFu, 8);
    goto L_01A113;
L_01A113:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA113u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA113u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA113u, 4u, 3u, cpu.address("abs", 0x1498u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A113 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1498u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A116;
L_01A116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA116u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA116u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA116u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A116 BEQ -> $01A11A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A11A; }
    goto L_01A118;
L_01A118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA118u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA118u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A118 LDA
    cpu.setA(0xFu, 8);
    goto L_01A11A;
L_01A11A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A11A CLC
    cpu.setFlag('C', false);
    goto L_01A11B;
L_01A11B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Bu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A11B ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_01A11D;
L_01A11D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A11D STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_01A11F;
L_01A11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A11F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A121;
L_01A121:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA121u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA121u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA121u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A121 ADC
    cpu.adc(0x0u);
    goto L_01A123;
L_01A123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA123u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA123u, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A123 STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_01A126;
L_01A126:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA126u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA126u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA126u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A126 LDA
    cpu.setA(0x1u, 8);
    goto L_01A128;
L_01A128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA128u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA128u, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A128 STA
    hw.write(cpu.address("abs", 0x148Fu), cpu.a, cpu.m8?8:16);
    goto L_01A12B;
L_01A12B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA12Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Bu, 4u, 3u, cpu.address("abs", 0x1470u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A12B STA
    hw.write(cpu.address("abs", 0x1470u), cpu.a, cpu.m8?8:16);
    goto L_01A12E;
L_01A12E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA12Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A12E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A12Eu);return;} hw.unresolvedReturn(0x01A12Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01AC80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC80u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC80u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC80 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AC82;
L_01AC82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC82u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC82 CMP
    cpu.compareA(0x1Fu);
    goto L_01AC84;
L_01AC84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC84u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC84 BNE -> $01AC8E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AC8E; }
    goto L_01AC86;
L_01AC86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC86u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC86u, 4u, 3u, cpu.address("abs", 0x18C1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC86 STA
    hw.write(cpu.address("abs", 0x18C1u), cpu.a, cpu.m8?8:16);
    goto L_01AC89;
L_01AC89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC89 LDA
    cpu.setA(0xFFu, 8);
    goto L_01AC8B;
L_01AC8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Bu, 4u, 3u, cpu.address("abs", 0x18C0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC8B STA
    hw.write(cpu.address("abs", 0x18C0u), cpu.a, cpu.m8?8:16);
    goto L_01AC8E;
L_01AC8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Eu, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC8E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AC91;
L_01AC91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC91u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC91 CMP
    cpu.compareA(0x8u);
    goto L_01AC93;
L_01AC93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC93u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC93 BCC -> $01ACA1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01ACA1; }
    goto L_01AC95;
L_01AC95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC95u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC95u, 4u + ((((0x161Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x161Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC95 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x161Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01AC98;
L_01AC98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC98u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC98 CPY
    cpu.compareY(0xFFu);
    goto L_01AC9A;
L_01AC9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC9A BEQ -> $01ACA1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ACA1; }
    goto L_01AC9C;
L_01AC9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC9C LDA
    cpu.setA(0x0u, 8);
    goto L_01AC9E;
L_01AC9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Eu, 5u, 3u, cpu.address("absy", 0x1938u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC9E STA
    hw.write(cpu.address("absy", 0x1938u), cpu.a, cpu.m8?8:16);
    goto L_01ACA1;
L_01ACA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA1u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA1u, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ACA1 STZ
    hw.write(cpu.address("absx", 0x14C8u), 0, cpu.m8?8:16);
    goto L_01ACA4;
L_01ACA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ACA4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01ACA4u);return;} hw.unresolvedReturn(0x01ACA4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_019F9B_E0M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01A0D9u: goto L_01A0D9;
    case 0x01A0DCu: goto L_01A0DC;
    case 0x01A0DEu: goto L_01A0DE;
    case 0x01A0E0u: goto L_01A0E0;
    case 0x01A0E2u: goto L_01A0E2;
    case 0x01A0E5u: goto L_01A0E5;
    case 0x01A0E7u: goto L_01A0E7;
    case 0x01A0EAu: goto L_01A0EA;
    case 0x01A0ECu: goto L_01A0EC;
    case 0x01A0EFu: goto L_01A0EF;
    case 0x01A0F1u: goto L_01A0F1;
    case 0x01A0F4u: goto L_01A0F4;
    case 0x01A0F6u: goto L_01A0F6;
    case 0x01A0F7u: goto L_01A0F7;
    case 0x01A0F9u: goto L_01A0F9;
    case 0x01A0FAu: goto L_01A0FA;
    case 0x01A0FDu: goto L_01A0FD;
    case 0x01A0FFu: goto L_01A0FF;
    case 0x01A101u: goto L_01A101;
    case 0x01A104u: goto L_01A104;
    case 0x01A107u: goto L_01A107;
    case 0x01A109u: goto L_01A109;
    case 0x01A10Bu: goto L_01A10B;
    case 0x01A10Du: goto L_01A10D;
    case 0x01A10Fu: goto L_01A10F;
    case 0x01A111u: goto L_01A111;
    case 0x01A113u: goto L_01A113;
    case 0x01A116u: goto L_01A116;
    case 0x01A118u: goto L_01A118;
    case 0x01A11Au: goto L_01A11A;
    case 0x01A11Bu: goto L_01A11B;
    case 0x01A11Du: goto L_01A11D;
    case 0x01A11Fu: goto L_01A11F;
    case 0x01A121u: goto L_01A121;
    case 0x01A123u: goto L_01A123;
    case 0x01A126u: goto L_01A126;
    case 0x01A128u: goto L_01A128;
    case 0x01A12Bu: goto L_01A12B;
    case 0x01A12Eu: goto L_01A12E;
    case 0x01AC80u: goto L_01AC80;
    case 0x01AC82u: goto L_01AC82;
    case 0x01AC84u: goto L_01AC84;
    case 0x01AC86u: goto L_01AC86;
    case 0x01AC89u: goto L_01AC89;
    case 0x01AC8Bu: goto L_01AC8B;
    case 0x01AC8Eu: goto L_01AC8E;
    case 0x01AC91u: goto L_01AC91;
    case 0x01AC93u: goto L_01AC93;
    case 0x01AC95u: goto L_01AC95;
    case 0x01AC98u: goto L_01AC98;
    case 0x01AC9Au: goto L_01AC9A;
    case 0x01AC9Cu: goto L_01AC9C;
    case 0x01AC9Eu: goto L_01AC9E;
    case 0x01ACA1u: goto L_01ACA1;
    case 0x01ACA4u: goto L_01ACA4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01A0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D9u, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0D9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A0DC;
L_01A0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0DC CMP
    cpu.compareA(0x3u);
    goto L_01A0DE;
L_01A0DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0DE BEQ -> $01A0E2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A0E2; }
    goto L_01A0E0;
L_01A0E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0E0 LDY
    cpu.setY(0x3Du, 8);
    goto L_01A0E2;
L_01A0E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E2u, 4u + ((((0x0094u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0094u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0E2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A0E5;
L_01A0E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0E5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_01A0E7;
L_01A0E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E7u, 4u + ((((0x0095u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0095u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0E7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A0EA;
L_01A0EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0EA STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_01A0EC;
L_01A0EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ECu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ECu, 4u + ((((0x0096u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0096u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0EC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A0EF;
L_01A0EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0EF STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_01A0F1;
L_01A0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F1u, 4u + ((((0x0097u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0097u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0F1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A0F4;
L_01A0F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0F4 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_01A0F6;
L_01A0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F6u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A0F6 PLY
    cpu.pop("PLY", hw);
    goto L_01A0F7;
L_01A0F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0F7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A0F9;
L_01A0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0F9 CLC
    cpu.setFlag('C', false);
    goto L_01A0FA;
L_01A0FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FAu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FAu, 4u + ((((0x9F5Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9F5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0FA ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x9F5Bu), cpu.m8?8:16));
    goto L_01A0FD;
L_01A0FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FDu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0FD STA
    hw.write(cpu.address("dpx", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_01A0FF;
L_01A0FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A0FF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A101;
L_01A101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA101u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA101u, 4u + ((((0x9F61u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9F61u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A101 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x9F61u), cpu.m8?8:16));
    goto L_01A104;
L_01A104:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA104u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA104u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA104u, 5u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A104 STA
    hw.write(cpu.address("absx", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_01A107;
L_01A107:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA107u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA107u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA107u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A107 LDA
    cpu.setA(0xDu, 8);
    goto L_01A109;
L_01A109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA109u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA109u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA109u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A109 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x73u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A10B;
L_01A10B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A10B BNE -> $01A111
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A111; }
    goto L_01A10D;
L_01A10D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A10D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A10F;
L_01A10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A10F BNE -> $01A113
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A113; }
    goto L_01A111;
L_01A111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA111u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA111u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A111 LDA
    cpu.setA(0xFu, 8);
    goto L_01A113;
L_01A113:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA113u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA113u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA113u, 4u, 3u, cpu.address("abs", 0x1498u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A113 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1498u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A116;
L_01A116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA116u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA116u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA116u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A116 BEQ -> $01A11A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A11A; }
    goto L_01A118;
L_01A118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA118u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA118u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A118 LDA
    cpu.setA(0xFu, 8);
    goto L_01A11A;
L_01A11A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A11A CLC
    cpu.setFlag('C', false);
    goto L_01A11B;
L_01A11B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Bu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A11B ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_01A11D;
L_01A11D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A11D STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_01A11F;
L_01A11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A11F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A121;
L_01A121:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA121u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA121u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA121u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A121 ADC
    cpu.adc(0x0u);
    goto L_01A123;
L_01A123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA123u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA123u, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A123 STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_01A126;
L_01A126:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA126u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA126u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA126u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A126 LDA
    cpu.setA(0x1u, 8);
    goto L_01A128;
L_01A128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA128u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA128u, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A128 STA
    hw.write(cpu.address("abs", 0x148Fu), cpu.a, cpu.m8?8:16);
    goto L_01A12B;
L_01A12B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA12Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Bu, 4u, 3u, cpu.address("abs", 0x1470u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A12B STA
    hw.write(cpu.address("abs", 0x1470u), cpu.a, cpu.m8?8:16);
    goto L_01A12E;
L_01A12E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA12Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A12E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A12Eu);return;} hw.unresolvedReturn(0x01A12Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_01AC80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC80u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC80u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC80 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AC82;
L_01AC82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC82u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC82 CMP
    cpu.compareA(0x1Fu);
    goto L_01AC84;
L_01AC84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC84u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC84 BNE -> $01AC8E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01AC8E; }
    goto L_01AC86;
L_01AC86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC86u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC86u, 4u, 3u, cpu.address("abs", 0x18C1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC86 STA
    hw.write(cpu.address("abs", 0x18C1u), cpu.a, cpu.m8?8:16);
    goto L_01AC89;
L_01AC89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC89 LDA
    cpu.setA(0xFFu, 8);
    goto L_01AC8B;
L_01AC8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Bu, 4u, 3u, cpu.address("abs", 0x18C0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC8B STA
    hw.write(cpu.address("abs", 0x18C0u), cpu.a, cpu.m8?8:16);
    goto L_01AC8E;
L_01AC8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Eu, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC8E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01AC91;
L_01AC91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC91u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC91 CMP
    cpu.compareA(0x8u);
    goto L_01AC93;
L_01AC93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC93u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC93 BCC -> $01ACA1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01ACA1; }
    goto L_01AC95;
L_01AC95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC95u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC95u, 4u + ((((0x161Au & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x161Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC95 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x161Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01AC98;
L_01AC98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC98u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC98 CPY
    cpu.compareY(0xFFu);
    goto L_01AC9A;
L_01AC9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC9A BEQ -> $01ACA1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01ACA1; }
    goto L_01AC9C;
L_01AC9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC9C LDA
    cpu.setA(0x0u, 8);
    goto L_01AC9E;
L_01AC9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Eu, 5u, 3u, cpu.address("absy", 0x1938u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01AC9E STA
    hw.write(cpu.address("absy", 0x1938u), cpu.a, cpu.m8?8:16);
    goto L_01ACA1;
L_01ACA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA1u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA1u, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01ACA1 STZ
    hw.write(cpu.address("absx", 0x14C8u), 0, cpu.m8?8:16);
    goto L_01ACA4;
L_01ACA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01ACA4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01ACA4u);return;} hw.unresolvedReturn(0x01ACA4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01A365_E1M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01A365u: goto L_01A365;
    case 0x01A368u: goto L_01A368;
    case 0x01A36Bu: goto L_01A36B;
    case 0x01A36Du: goto L_01A36D;
    case 0x01A36Fu: goto L_01A36F;
    case 0x01A372u: goto L_01A372;
    case 0x01A374u: goto L_01A374;
    case 0x01A376u: goto L_01A376;
    case 0x01A379u: goto L_01A379;
    case 0x01A37Cu: goto L_01A37C;
    case 0x01A37Du: goto L_01A37D;
    case 0x01A37Fu: goto L_01A37F;
    case 0x01A381u: goto L_01A381;
    case 0x01A382u: goto L_01A382;
    case 0x01A384u: goto L_01A384;
    case 0x01A385u: goto L_01A385;
    case 0x01A388u: goto L_01A388;
    case 0x01A38Bu: goto L_01A38B;
    case 0x01A38Du: goto L_01A38D;
    case 0x01A38Eu: goto L_01A38E;
    case 0x01A390u: goto L_01A390;
    case 0x01A393u: goto L_01A393;
    case 0x01A395u: goto L_01A395;
    case 0x01A398u: goto L_01A398;
    case 0x01A399u: goto L_01A399;
    case 0x01A39Bu: goto L_01A39B;
    case 0x01A39Du: goto L_01A39D;
    case 0x01A39Eu: goto L_01A39E;
    case 0x01A3A1u: goto L_01A3A1;
    case 0x01A3A3u: goto L_01A3A3;
    case 0x01A3A5u: goto L_01A3A5;
    case 0x01A3A6u: goto L_01A3A6;
    case 0x01A3A8u: goto L_01A3A8;
    case 0x01A3A9u: goto L_01A3A9;
    case 0x01A3ACu: goto L_01A3AC;
    case 0x01A3ADu: goto L_01A3AD;
    case 0x01A3AFu: goto L_01A3AF;
    case 0x01A3B1u: goto L_01A3B1;
    case 0x01A3B2u: goto L_01A3B2;
    case 0x01A3B5u: goto L_01A3B5;
    case 0x01A3B7u: goto L_01A3B7;
    case 0x01A3B9u: goto L_01A3B9;
    case 0x01A3BBu: goto L_01A3BB;
    case 0x01A3BDu: goto L_01A3BD;
    case 0x01A3C0u: goto L_01A3C0;
    case 0x01A3C3u: goto L_01A3C3;
    case 0x01A3C6u: goto L_01A3C6;
    case 0x01A3C7u: goto L_01A3C7;
    case 0x01A3C9u: goto L_01A3C9;
    case 0x01A3CBu: goto L_01A3CB;
    case 0x01A3CCu: goto L_01A3CC;
    case 0x01A3CDu: goto L_01A3CD;
    case 0x01A3D0u: goto L_01A3D0;
    case 0x01A3D2u: goto L_01A3D2;
    case 0x01A3D3u: goto L_01A3D3;
    case 0x01A3D5u: goto L_01A3D5;
    case 0x01A3D7u: goto L_01A3D7;
    case 0x01A3D9u: goto L_01A3D9;
    case 0x01A3DAu: goto L_01A3DA;
    case 0x01A3DCu: goto L_01A3DC;
    case 0x01A3DEu: goto L_01A3DE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01A365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA365u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA365u, 5u, 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A365 STZ
    hw.write(cpu.address("absx", 0x186Cu), 0, cpu.m8?8:16);
    goto L_01A368;
L_01A368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u, 5u, 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A368 STZ
    hw.write(cpu.address("absx", 0x15A0u), 0, cpu.m8?8:16);
    goto L_01A36B;
L_01A36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A36B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A36D;
L_01A36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Du,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A36D CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_01A36F;
L_01A36F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Fu, 4u + 1u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A36F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A372;
L_01A372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA372u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA372u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA372u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A372 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Bu), cpu.m8?8:16));
    goto L_01A374;
L_01A374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA374u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA374u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A374 BEQ -> $01A379
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A379; }
    goto L_01A376;
L_01A376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA376u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA376u, 7u, 3u, cpu.address("absx", 0x15A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A376 INC
    cpu.incMem(hw, cpu.address("absx", 0x15A0u), cpu.m8?8:16);
    goto L_01A379;
L_01A379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA379u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA379u, 4u + 1u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A379 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A37C;
L_01A37C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A37C XBA
    cpu.xba();
    goto L_01A37D;
L_01A37D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A37D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A37F;
L_01A37F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A37F REP
    cpu.rep(0x20u);
    goto L_01A381;
L_01A381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA381u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA381u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A381 SEC
    cpu.setFlag('C', true);
    goto L_01A382;
L_01A382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA382u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA382u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A382 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_01A384;
L_01A384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA384u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA384u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A384 CLC
    cpu.setFlag('C', false);
    goto L_01A385;
L_01A385:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA385u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA385u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA385u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A385 ADC
    cpu.adc(0x40u);
    goto L_01A388;
L_01A388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA388u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA388u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA388u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A388 CMP
    cpu.compareA(0x180u);
    goto L_01A38B;
L_01A38B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A38B SEP
    cpu.sep(0x20u);
    goto L_01A38D;
L_01A38D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Du,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A38D ROL
    cpu.rolA();
    goto L_01A38E;
L_01A38E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A38E AND
    cpu.logicAnd(0x1u);
    goto L_01A390;
L_01A390:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA390u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA390u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA390u, 5u, 3u, cpu.address("absx", 0x15C4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A390 STA
    hw.write(cpu.address("absx", 0x15C4u), cpu.a, cpu.m8?8:16);
    goto L_01A393;
L_01A393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA393u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA393u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A393 BNE -> $01A3CB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A3CB; }
    goto L_01A395;
L_01A395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA395u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA395u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A395 LDY
    cpu.setY(0xBD00u, 16);
    goto L_01A398;
L_01A398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA398u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA398u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A398 INY
    cpu.inc('Y');
    goto L_01A399;
L_01A399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA399u,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA399u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A399 TRB
    cpu.trb(hw, cpu.address("dp", 0xC9u), cpu.m8?8:16);
    goto L_01A39B;
L_01A39B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Bu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A39B ORA
    cpu.logicOr(0xF0u);
    goto L_01A39D;
L_01A39D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Du,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A39D PHP
    cpu.push("PHP", hw);
    goto L_01A39E;
L_01A39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Eu, 4u + 1u, 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A39E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3A1;
L_01A3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A1 AND
    cpu.logicAnd(0x20u);
    goto L_01A3A3;
L_01A3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A3 BEQ -> $01A3A6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A3A6; }
    goto L_01A3A5;
L_01A3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A5 INY
    cpu.inc('Y');
    goto L_01A3A6;
L_01A3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3A8;
L_01A3A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A8 CLC
    cpu.setFlag('C', false);
    goto L_01A3A9;
L_01A3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A9u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A9u, 4u + 1u, 3u, cpu.address("absy", 0xA361u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A9 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xA361u), cpu.m8?8:16));
    goto L_01A3AC;
L_01A3AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ACu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ACu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A3AC PHP
    cpu.push("PHP", hw);
    goto L_01A3AD;
L_01A3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ADu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3AD CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_01A3AF;
L_01A3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3AFu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3AF ROL
    cpu.rolMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_01A3B1;
L_01A3B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B1u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A3B1 PLP
    cpu.pop("PLP", hw);
    goto L_01A3B2;
L_01A3B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B2u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3B2u,0x01A3B2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B2u, 4u + 1u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3B2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3B5;
L_01A3B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3B5 ADC
    cpu.adc(0x0u);
    goto L_01A3B7;
L_01A3B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B7u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3B7 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_01A3B9;
L_01A3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B9u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3B9 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Du), cpu.m8?8:16));
    goto L_01A3BB;
L_01A3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3BB BEQ -> $01A3C6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A3C6; }
    goto L_01A3BD;
L_01A3BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BDu, 4u + 1u, 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3BD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3C0;
L_01A3C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C0u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C0u, 4u + 1u, 3u, cpu.address("absy", 0xA363u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3C0 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xA363u), cpu.m8?8:16));
    goto L_01A3C3;
L_01A3C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C3u, 5u, 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3C3 STA
    hw.write(cpu.address("absx", 0x186Cu), cpu.a, cpu.m8?8:16);
    goto L_01A3C6;
L_01A3C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C6u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3C6 DEY
    cpu.decReg('Y');
    goto L_01A3C7;
L_01A3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3C7 BPL -> $01A3A6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01A3A6; }
    goto L_01A3C9;
L_01A3C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3C9 BRA -> $01A3CD
    goto L_01A3CD;
L_01A3CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CBu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A3CB PLA
    cpu.pop("PLA", hw);
    goto L_01A3CC;
L_01A3CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CCu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A3CC PLA
    cpu.pop("PLA", hw);
    goto L_01A3CD;
L_01A3CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CDu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CDu, 5u + 1u, 3u, cpu.address("absx", 0x15EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3CD LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A3D0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3CDu,0x01A3CDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01A3D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3D2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3D0u,0x01A3D0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01A3D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D2 SEC
    cpu.setFlag('C', true);
    goto L_01A3D3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3D2u,0x01A3D2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01A3D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D3u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D3 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_01A3D5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3D3u,0x01A3D3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01A3D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_01A3D7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3D5u,0x01A3D5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01A3D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3D9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3D7u,0x01A3D7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01A3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D9 SEC
    cpu.setFlag('C', true);
    goto L_01A3DA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3D9u,0x01A3D9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01A3DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DAu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3DA SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_01A3DC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3DAu,0x01A3DAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01A3DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3DC STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_01A3DE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3DCu,0x01A3DCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01A3DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A3DE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A3DEu);return;} hw.unresolvedReturn(0x01A3DEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3DEu,0x01A3DEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_01A3DF_E1M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01A3DFu: goto L_01A3DF;
    case 0x01A3E2u: goto L_01A3E2;
    case 0x01A3E4u: goto L_01A3E4;
    case 0x01A3E5u: goto L_01A3E5;
    case 0x01A3E6u: goto L_01A3E6;
    case 0x01A3E8u: goto L_01A3E8;
    case 0x01A3E9u: goto L_01A3E9;
    case 0x01A3EBu: goto L_01A3EB;
    case 0x01A3EEu: goto L_01A3EE;
    case 0x01A3EFu: goto L_01A3EF;
    case 0x01A3F0u: goto L_01A3F0;
    case 0x01A3F1u: goto L_01A3F1;
    case 0x01A3F2u: goto L_01A3F2;
    case 0x01A3F4u: goto L_01A3F4;
    case 0x01A3F7u: goto L_01A3F7;
    case 0x01A3F8u: goto L_01A3F8;
    case 0x01A3F9u: goto L_01A3F9;
    case 0x01A3FBu: goto L_01A3FB;
    case 0x01A3FDu: goto L_01A3FD;
    case 0x01A400u: goto L_01A400;
    case 0x01A401u: goto L_01A401;
    case 0x01A402u: goto L_01A402;
    case 0x01A403u: goto L_01A403;
    case 0x01A404u: goto L_01A404;
    case 0x01A406u: goto L_01A406;
    case 0x01A409u: goto L_01A409;
    case 0x01A40Au: goto L_01A40A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01A3DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DFu, 4u + 1u, 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3DF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3E2;
L_01A3E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3E2 BEQ -> $01A40A
    if (cpu.z) { hw.addCpuInternalCycles(2u); goto L_01A40A; }
    goto L_01A3E4;
L_01A3E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E4u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A3E4 PHX
    cpu.push("PHX", hw);
    goto L_01A3E5;
L_01A3E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3E5 LSR
    cpu.lsrA();
    goto L_01A3E6;
L_01A3E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3E6 BCC -> $01A3F8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_01A3F8; }
    goto L_01A3E8;
L_01A3E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E8u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A3E8 PHA
    cpu.push("PHA", hw);
    goto L_01A3E9;
L_01A3E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3E9 LDA
    cpu.setA(0x1u, 8);
    goto L_01A3EB;
L_01A3EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EBu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EBu, 5u, 3u, cpu.address("absy", 0x0460u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3EB STA
    hw.write(cpu.address("absy", 0x460u), cpu.a, cpu.m8?8:16);
    goto L_01A3EE;
L_01A3EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EEu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3EE TYA
    cpu.transfer("TYA");
    goto L_01A3EF;
L_01A3EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3EF ASL
    cpu.aslA();
    goto L_01A3F0;
L_01A3F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3F0 ASL
    cpu.aslA();
    goto L_01A3F1;
L_01A3F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3F1 TAX
    cpu.transfer("TAX");
    goto L_01A3F2;
L_01A3F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3F2 LDA
    cpu.setA(0x80u, 8);
    goto L_01A3F4;
L_01A3F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F4u, 5u, 3u, cpu.address("absx", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3F4 STA
    hw.write(cpu.address("absx", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_01A3F7;
L_01A3F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F7u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A3F7 PLA
    cpu.pop("PLA", hw);
    goto L_01A3F8;
L_01A3F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3F8 LSR
    cpu.lsrA();
    goto L_01A3F9;
L_01A3F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3F9 BCC -> $01A409
    if (!cpu.c) { hw.addCpuInternalCycles(2u); goto L_01A409; }
    goto L_01A3FB;
L_01A3FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3FB LDA
    cpu.setA(0x1u, 8);
    goto L_01A3FD;
L_01A3FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FDu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FDu, 5u, 3u, cpu.address("absy", 0x0461u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3FD STA
    hw.write(cpu.address("absy", 0x461u), cpu.a, cpu.m8?8:16);
    goto L_01A400;
L_01A400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA400u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA400u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA400u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A400 TYA
    cpu.transfer("TYA");
    goto L_01A401;
L_01A401:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA401u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA401u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA401u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A401 ASL
    cpu.aslA();
    goto L_01A402;
L_01A402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA402u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA402u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA402u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A402 ASL
    cpu.aslA();
    goto L_01A403;
L_01A403:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA403u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA403u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA403u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A403 TAX
    cpu.transfer("TAX");
    goto L_01A404;
L_01A404:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA404u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA404u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA404u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A404 LDA
    cpu.setA(0x80u, 8);
    goto L_01A406;
L_01A406:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA406u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA406u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA406u, 5u, 3u, cpu.address("absx", 0x0304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A406 STA
    hw.write(cpu.address("absx", 0x304u), cpu.a, cpu.m8?8:16);
    goto L_01A409;
L_01A409:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA409u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA409u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA409u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A409 PLX
    cpu.pop("PLX", hw);
    goto L_01A40A;
L_01A40A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA40Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A40A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A40Au);return;} hw.unresolvedReturn(0x01A40Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04945D_E0M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04959Du: goto L_04959D;
    case 0x0495A0u: goto L_0495A0;
    case 0x0495A2u: goto L_0495A2;
    case 0x0495A5u: goto L_0495A5;
    case 0x0495A6u: goto L_0495A6;
    case 0x0495A7u: goto L_0495A7;
    case 0x0495A8u: goto L_0495A8;
    case 0x0495ABu: goto L_0495AB;
    case 0x0495AEu: goto L_0495AE;
    case 0x0495B0u: goto L_0495B0;
    case 0x0495B2u: goto L_0495B2;
    case 0x0495B5u: goto L_0495B5;
    case 0x0495B6u: goto L_0495B6;
    case 0x0495B9u: goto L_0495B9;
    case 0x0495BCu: goto L_0495BC;
    case 0x0495BEu: goto L_0495BE;
    case 0x0495C0u: goto L_0495C0;
    case 0x0495C3u: goto L_0495C3;
    case 0x0495C6u: goto L_0495C6;
    case 0x0495C9u: goto L_0495C9;
    case 0x0495CCu: goto L_0495CC;
    case 0x0495CEu: goto L_0495CE;
    case 0x0495D0u: goto L_0495D0;
    case 0x0495D2u: goto L_0495D2;
    case 0x0495D5u: goto L_0495D5;
    case 0x0495D7u: goto L_0495D7;
    case 0x0495DBu: goto L_0495DB;
    case 0x0495DEu: goto L_0495DE;
    case 0x0495E1u: goto L_0495E1;
    case 0x0495E3u: goto L_0495E3;
    case 0x0495E6u: goto L_0495E6;
    case 0x0495E8u: goto L_0495E8;
    case 0x0495E9u: goto L_0495E9;
    case 0x0495EAu: goto L_0495EA;
    case 0x0495EBu: goto L_0495EB;
    case 0x0495ECu: goto L_0495EC;
    case 0x0495EFu: goto L_0495EF;
    case 0x0495F2u: goto L_0495F2;
    case 0x0495F4u: goto L_0495F4;
    case 0x0495F7u: goto L_0495F7;
    case 0x0495FAu: goto L_0495FA;
    case 0x0495FCu: goto L_0495FC;
    case 0x0495FFu: goto L_0495FF;
    case 0x049602u: goto L_049602;
    case 0x049605u: goto L_049605;
    case 0x049607u: goto L_049607;
    case 0x04960Au: goto L_04960A;
    case 0x04960Cu: goto L_04960C;
    case 0x04960Fu: goto L_04960F;
    case 0x049610u: goto L_049610;
    case 0x049611u: goto L_049611;
    case 0x049612u: goto L_049612;
    case 0x049614u: goto L_049614;
    case 0x049616u: goto L_049616;
    case 0x049619u: goto L_049619;
    case 0x04961Bu: goto L_04961B;
    case 0x04961Cu: goto L_04961C;
    case 0x04961Fu: goto L_04961F;
    case 0x049620u: goto L_049620;
    case 0x049622u: goto L_049622;
    case 0x049625u: goto L_049625;
    case 0x049628u: goto L_049628;
    case 0x04962Bu: goto L_04962B;
    case 0x04962Du: goto L_04962D;
    case 0x049630u: goto L_049630;
    case 0x049633u: goto L_049633;
    case 0x049636u: goto L_049636;
    case 0x049639u: goto L_049639;
    case 0x04963Cu: goto L_04963C;
    case 0x04963Eu: goto L_04963E;
    case 0x049640u: goto L_049640;
    case 0x049643u: goto L_049643;
    case 0x049645u: goto L_049645;
    case 0x049646u: goto L_049646;
    case 0x049648u: goto L_049648;
    case 0x04964Au: goto L_04964A;
    case 0x04964Bu: goto L_04964B;
    case 0x04964Cu: goto L_04964C;
    case 0x04964Fu: goto L_04964F;
    case 0x049651u: goto L_049651;
    case 0x049654u: goto L_049654;
    case 0x049657u: goto L_049657;
    case 0x049659u: goto L_049659;
    case 0x04965Cu: goto L_04965C;
    case 0x04965Eu: goto L_04965E;
    case 0x049661u: goto L_049661;
    case 0x049663u: goto L_049663;
    case 0x049666u: goto L_049666;
    case 0x049667u: goto L_049667;
    case 0x04966Au: goto L_04966A;
    case 0x04966Bu: goto L_04966B;
    case 0x04966Eu: goto L_04966E;
    case 0x049671u: goto L_049671;
    case 0x049674u: goto L_049674;
    case 0x049676u: goto L_049676;
    case 0x049679u: goto L_049679;
    case 0x04967Au: goto L_04967A;
    case 0x04967Du: goto L_04967D;
    case 0x04967Eu: goto L_04967E;
    case 0x049681u: goto L_049681;
    case 0x049684u: goto L_049684;
    case 0x049687u: goto L_049687;
    case 0x04968Au: goto L_04968A;
    case 0x04968Du: goto L_04968D;
    case 0x049690u: goto L_049690;
    case 0x049693u: goto L_049693;
    case 0x049695u: goto L_049695;
    case 0x049698u: goto L_049698;
    case 0x04969Au: goto L_04969A;
    case 0x04969Du: goto L_04969D;
    case 0x04969Fu: goto L_04969F;
    case 0x0496A2u: goto L_0496A2;
    case 0x0496A5u: goto L_0496A5;
    case 0x0496A6u: goto L_0496A6;
    case 0x0496A7u: goto L_0496A7;
    case 0x0496A8u: goto L_0496A8;
    case 0x0496ABu: goto L_0496AB;
    case 0x0496AEu: goto L_0496AE;
    case 0x0496B1u: goto L_0496B1;
    case 0x0496B3u: goto L_0496B3;
    case 0x0496B4u: goto L_0496B4;
    case 0x0496B5u: goto L_0496B5;
    case 0x0496B8u: goto L_0496B8;
    case 0x0496BBu: goto L_0496BB;
    case 0x0496BCu: goto L_0496BC;
    case 0x0496BEu: goto L_0496BE;
    case 0x0496C0u: goto L_0496C0;
    case 0x0496C4u: goto L_0496C4;
    case 0x0496C7u: goto L_0496C7;
    case 0x0496C8u: goto L_0496C8;
    case 0x0496CBu: goto L_0496CB;
    case 0x0496CEu: goto L_0496CE;
    case 0x0496D1u: goto L_0496D1;
    case 0x0496D2u: goto L_0496D2;
    case 0x0496D5u: goto L_0496D5;
    case 0x0496D6u: goto L_0496D6;
    case 0x0496D9u: goto L_0496D9;
    case 0x0496DAu: goto L_0496DA;
    case 0x0496DDu: goto L_0496DD;
    case 0x0496E0u: goto L_0496E0;
    case 0x0496E2u: goto L_0496E2;
    case 0x0496E5u: goto L_0496E5;
    case 0x0496E7u: goto L_0496E7;
    case 0x0496EAu: goto L_0496EA;
    case 0x0496EDu: goto L_0496ED;
    case 0x0496EFu: goto L_0496EF;
    case 0x0496F2u: goto L_0496F2;
    case 0x0496F5u: goto L_0496F5;
    case 0x0496F8u: goto L_0496F8;
    case 0x0496FAu: goto L_0496FA;
    case 0x0496FCu: goto L_0496FC;
    case 0x0496FDu: goto L_0496FD;
    case 0x0496FEu: goto L_0496FE;
    case 0x0496FFu: goto L_0496FF;
    case 0x049702u: goto L_049702;
    case 0x049704u: goto L_049704;
    case 0x049705u: goto L_049705;
    case 0x049707u: goto L_049707;
    case 0x04970Au: goto L_04970A;
    case 0x04970Du: goto L_04970D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04959D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Du,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Du, 5u + 1u, 3u, cpu.address("absy", 0x9058u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04959D ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x9058u), cpu.m8?8:16));
    goto L_0495A0;
L_0495A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A0u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495A0 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0495A2;
L_0495A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A2u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495A2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0495A5;
L_0495A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495A5 LSR
    cpu.lsrA();
    goto L_0495A6;
L_0495A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495A6 LSR
    cpu.lsrA();
    goto L_0495A7;
L_0495A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495A7 TAX
    cpu.transfer("TAX");
    goto L_0495A8;
L_0495A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A8u, 6u, 3u, cpu.address("abs", 0x9885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0495A8 JSR -> $049885 stack real
    { cpu.push16Value(hw,0x95AAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x95ABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9885u), 0x0495A8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0495AB;
L_0495AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95ABu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x95ABu,0x0495ABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95ABu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95ABu, 5u, 3u, cpu.address("abs", 0x1B78u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495AB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0495AE;
L_0495AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95AEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495AE BEQ -> $0495CE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0495CE; }
    goto L_0495B0;
L_0495B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B0u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495B0 STY
    hw.write(cpu.address("dp", 0x6u), cpu.y, cpu.x8?8:16);
    goto L_0495B2;
L_0495B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B2u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B2u, 5u, 3u, cpu.address("abs", 0x1B7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495B2 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1B7Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0495B5;
L_0495B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495B5 INX
    cpu.inc('X');
    goto L_0495B6;
L_0495B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B6u, 5u + 1u, 3u, cpu.address("absx", 0x90CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495B6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x90CAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0495B9;
L_0495B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495B9 AND
    cpu.logicAnd(0xFFu);
    goto L_0495BC;
L_0495BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BCu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495BC CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16));
    goto L_0495BE;
L_0495BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495BE BNE -> $049575
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x049575u,0x0495BEu); return; }
    goto L_0495C0;
L_0495C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C0u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C0u, 5u, 3u, cpu.address("abs", 0x1B7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495C0 STX
    hw.write(cpu.address("abs", 0x1B7Au), cpu.x, cpu.x8?8:16);
    goto L_0495C3;
L_0495C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C3u, 5u + 1u, 3u, cpu.address("absx", 0x9086u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495C3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9086u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0495C6;
L_0495C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495C6 AND
    cpu.logicAnd(0xFFu);
    goto L_0495C9;
L_0495C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495C9 CMP
    cpu.compareA(0x58u);
    goto L_0495CC;
L_0495CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95CCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495CC BNE -> $0495DE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0495DE; }
    goto L_0495CE;
L_0495CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95CEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495CE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0495D0;
L_0495D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D0u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495D0 BMI -> $049575
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x049575u,0x0495D0u); return; }
    goto L_0495D2;
L_0495D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495D2 CMP
    cpu.compareA(0x800u);
    goto L_0495D5;
L_0495D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495D5 BCS -> $049575
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x049575u,0x0495D5u); return; }
    goto L_0495D7;
L_0495D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D7u, 6u, 4u, ((0x7EC800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495D7 LDA
    cpu.loadA(hw.readW(((0x7EC800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0495DB;
L_0495DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95DBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495DB AND
    cpu.logicAnd(0xFFu);
    goto L_0495DE;
L_0495DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95DEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95DEu, 5u, 3u, cpu.address("abs", 0x13C1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495DE STA
    hw.write(cpu.address("abs", 0x13C1u), cpu.a, cpu.m8?8:16);
    goto L_0495E1;
L_0495E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495E1 BEQ -> $049575
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x049575u,0x0495E1u); return; }
    goto L_0495E3;
L_0495E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495E3 CMP
    cpu.compareA(0x87u);
    goto L_0495E6;
L_0495E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495E6 BCS -> $049575
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x049575u,0x0495E6u); return; }
    goto L_0495E8;
L_0495E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E8u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0495E8 PHA
    cpu.push("PHA", hw);
    goto L_0495E9;
L_0495E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E9u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0495E9 PHY
    cpu.push("PHY", hw);
    goto L_0495EA;
L_0495EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95EAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495EA TAX
    cpu.transfer("TAX");
    goto L_0495EB;
L_0495EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95EBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495EB DEX
    cpu.decReg('X');
    goto L_0495EC;
L_0495EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95ECu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95ECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495EC LDY
    cpu.setY(0x0u, 16);
    goto L_0495EF;
L_0495EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95EFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95EFu, 5u + 1u, 3u, cpu.address("absx", 0x9FEBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495EF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9FEBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0495F2;
L_0495F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495F2 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0495F4;
L_0495F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495F4 AND
    cpu.logicAnd(0xFFu);
    goto L_0495F7;
L_0495F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495F7 CMP
    cpu.compareA(0x14u);
    goto L_0495FA;
L_0495FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95FAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495FA BNE -> $0495FF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0495FF; }
    goto L_0495FC;
L_0495FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95FCu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495FC LDY
    cpu.setY(0x1u, 16);
    goto L_0495FF;
L_0495FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95FFu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95FFu, 5u, 3u, cpu.address("abs", 0x1B80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0495FF STY
    hw.write(cpu.address("abs", 0x1B80u), cpu.y, cpu.x8?8:16);
    goto L_049602;
L_049602:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9602u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9602u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9602u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049602 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049605;
L_049605:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9605u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9605u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9605u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049605 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049607;
L_049607:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9607u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9607u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9607u, 6u, 3u, cpu.address("absx", 0x1F1Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049607 STA
    hw.write(cpu.address("absx", 0x1F1Fu), cpu.a, cpu.m8?8:16);
    goto L_04960A;
L_04960A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x960Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x960Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x960Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04960A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04960C;
L_04960C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x960Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x960Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x960Cu, 6u, 3u, cpu.address("absx", 0x1F21u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04960C STA
    hw.write(cpu.address("absx", 0x1F21u), cpu.a, cpu.m8?8:16);
    goto L_04960F;
L_04960F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x960Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x960Fu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x960Fu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04960F PLY
    cpu.pop("PLY", hw);
    goto L_049610;
L_049610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9610u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9610u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049610 PLA
    cpu.pop("PLA", hw);
    goto L_049611;
L_049611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9611u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9611u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9611u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049611 PHA
    cpu.push("PHA", hw);
    goto L_049612;
L_049612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9612u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9612u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049612 SEP
    cpu.sep(0x30u);
    goto L_049614;
L_049614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9614u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9614u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049614 LDX
    cpu.setX(0x9u, 8);
    goto L_049616;
L_049616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9616u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9616u, 4u + ((((0x9426u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9426u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049616 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x9426u), cpu.m8?8:16));
    goto L_049619;
L_049619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9619u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9619u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049619 BNE -> $049645
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049645; }
    goto L_04961B;
L_04961B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x961Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x961Bu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x961Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04961B PHY
    cpu.push("PHY", hw);
    goto L_04961C;
L_04961C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x961Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x961Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x961Cu, 6u, 3u, cpu.address("abs", 0x9A24u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04961C JSR -> $049A24 stack real
    { cpu.push16Value(hw,0x961Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x961Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9A24u), 0x04961Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04961F;
L_04961F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x961Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x961Fu,0x04961Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x961Fu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x961Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04961F PLY
    cpu.pop("PLY", hw);
    goto L_049620;
L_049620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9620u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9620u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049620 LDA
    cpu.setA(0x1u, 8);
    goto L_049622;
L_049622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9622u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9622u, 4u, 3u, cpu.address("abs", 0x1B9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049622 STA
    hw.write(cpu.address("abs", 0x1B9Eu), cpu.a, cpu.m8?8:16);
    goto L_049625;
L_049625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9625u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9625u, 6u, 3u, cpu.address("abs", 0xF407u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049625 JSR -> $04F407 stack real
    { cpu.push16Value(hw,0x9627u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9628u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF407u), 0x049625u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_049628;
L_049628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9628u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9628u,0x049628u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9628u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9628u, 4u, 3u, cpu.address("abs", 0x1B8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049628 STZ
    hw.write(cpu.address("abs", 0x1B8Cu), 0, cpu.m8?8:16);
    goto L_04962B;
L_04962B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x962Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x962Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x962Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04962B REP
    cpu.rep(0x20u);
    goto L_04962D;
L_04962D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x962Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x962Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x962Du, 5u, 3u, cpu.address("abs", 0x0701u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04962D STZ
    hw.write(cpu.address("abs", 0x701u), 0, cpu.m8?8:16);
    goto L_049630;
L_049630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9630u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9630u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049630 LDA
    cpu.setA(0x7000u, 16);
    goto L_049633;
L_049633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9633u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9633u, 5u, 3u, cpu.address("abs", 0x1B8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049633 STA
    hw.write(cpu.address("abs", 0x1B8Du), cpu.a, cpu.m8?8:16);
    goto L_049636;
L_049636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9636u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9636u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049636 LDA
    cpu.setA(0x5400u, 16);
    goto L_049639;
L_049639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9639u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9639u, 5u, 3u, cpu.address("abs", 0x1B8Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049639 STA
    hw.write(cpu.address("abs", 0x1B8Fu), cpu.a, cpu.m8?8:16);
    goto L_04963C;
L_04963C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x963Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x963Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x963Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04963C SEP
    cpu.sep(0x20u);
    goto L_04963E;
L_04963E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x963Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x963Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x963Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04963E LDA
    cpu.setA(0xAu, 8);
    goto L_049640;
L_049640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9640u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9640u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9640u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049640 STA
    hw.write(cpu.address("abs", 0x13D9u), cpu.a, cpu.m8?8:16);
    goto L_049643;
L_049643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9643u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9643u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9643u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049643 BRA -> $049648
    goto L_049648;
L_049645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9645u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9645u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049645 DEX
    cpu.decReg('X');
    goto L_049646;
L_049646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9646u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9646u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9646u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049646 BPL -> $049616
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_049616; }
    goto L_049648;
L_049648:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9648u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9648u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9648u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049648 REP
    cpu.rep(0x30u);
    goto L_04964A;
L_04964A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x964Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x964Au,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x964Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04964A PLA
    cpu.pop("PLA", hw);
    goto L_04964B;
L_04964B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x964Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x964Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x964Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04964B PHA
    cpu.push("PHA", hw);
    goto L_04964C;
L_04964C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x964Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x964Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x964Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04964C CMP
    cpu.compareA(0x56u);
    goto L_04964F;
L_04964F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x964Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x964Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x964Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04964F BCS -> $049654
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_049654; }
    goto L_049651;
L_049651:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9651u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9651u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9651u, 3u, 3u, cpu.address("abs", 0x971Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049651 JMP -> $04971D
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x971Du),0x049651u); return;
L_049654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9654u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9654u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049654 CMP
    cpu.compareA(0x80u);
    goto L_049657;
L_049657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9657u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9657u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9657u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049657 BEQ -> $049663
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_049663; }
    goto L_049659;
L_049659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9659u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9659u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049659 CMP
    cpu.compareA(0x6Au);
    goto L_04965C;
L_04965C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x965Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x965Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x965Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04965C BCC -> $049676
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_049676; }
    goto L_04965E;
L_04965E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x965Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x965Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x965Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04965E CMP
    cpu.compareA(0x6Eu);
    goto L_049661;
L_049661:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9661u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9661u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9661u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049661 BCS -> $049676
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_049676; }
    goto L_049663;
L_049663:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9663u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9663u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9663u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049663 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049666;
L_049666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9666u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9666u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049666 LSR
    cpu.lsrA();
    goto L_049667;
L_049667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9667u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9667u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9667u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049667 AND
    cpu.logicAnd(0x2u);
    goto L_04966A;
L_04966A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x966Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x966Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x966Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04966A TAX
    cpu.transfer("TAX");
    goto L_04966B;
L_04966B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x966Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x966Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x966Bu, 5u + 1u, 3u, cpu.address("absx", 0x1F13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04966B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04966E;
L_04966E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x966Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x966Eu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x966Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04966E ORA
    cpu.logicOr(0x8u);
    goto L_049671;
L_049671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9671u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9671u, 6u, 3u, cpu.address("absx", 0x1F13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049671 STA
    hw.write(cpu.address("absx", 0x1F13u), cpu.a, cpu.m8?8:16);
    goto L_049674;
L_049674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9674u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9674u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9674u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049674 BRA -> $049687
    goto L_049687;
L_049676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9676u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9676u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049676 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049679;
L_049679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9679u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9679u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049679 LSR
    cpu.lsrA();
    goto L_04967A;
L_04967A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x967Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x967Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x967Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04967A AND
    cpu.logicAnd(0x2u);
    goto L_04967D;
L_04967D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x967Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x967Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x967Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04967D TAX
    cpu.transfer("TAX");
    goto L_04967E;
L_04967E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x967Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x967Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x967Eu, 5u + 1u, 3u, cpu.address("absx", 0x1F13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04967E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049681;
L_049681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9681u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9681u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049681 AND
    cpu.logicAnd(0xF7u);
    goto L_049684;
L_049684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9684u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9684u, 6u, 3u, cpu.address("absx", 0x1F13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049684 STA
    hw.write(cpu.address("absx", 0x1F13u), cpu.a, cpu.m8?8:16);
    goto L_049687;
L_049687:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9687u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9687u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9687u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049687 LDA
    cpu.setA(0x1u, 16);
    goto L_04968A;
L_04968A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x968Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x968Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x968Au, 5u, 3u, cpu.address("abs", 0x1444u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04968A STA
    hw.write(cpu.address("abs", 0x1444u), cpu.a, cpu.m8?8:16);
    goto L_04968D;
L_04968D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x968Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x968Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x968Du, 5u, 3u, cpu.address("abs", 0x13C1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04968D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049690;
L_049690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9690u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9690u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049690 CMP
    cpu.compareA(0x5Fu);
    goto L_049693;
L_049693:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9693u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9693u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9693u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049693 BEQ -> $0496A5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0496A5; }
    goto L_049695;
L_049695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9695u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9695u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049695 CMP
    cpu.compareA(0x5Bu);
    goto L_049698;
L_049698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9698u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9698u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9698u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049698 BEQ -> $0496A5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0496A5; }
    goto L_04969A;
L_04969A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04969A CMP
    cpu.compareA(0x82u);
    goto L_04969D;
L_04969D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04969D BEQ -> $0496A5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0496A5; }
    goto L_04969F;
L_04969F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04969F LDA
    cpu.setA(0x23u, 16);
    goto L_0496A2;
L_0496A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A2u, 5u, 3u, cpu.address("abs", 0x1DFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496A2 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_0496A5;
L_0496A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496A5 NOP
    ;
    goto L_0496A6;
L_0496A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A6u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496A6 NOP
    ;
    goto L_0496A7;
L_0496A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496A7 NOP
    ;
    goto L_0496A8;
L_0496A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u, 5u, 3u, cpu.address("abs", 0x13C1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496A8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0496AB;
L_0496AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96ABu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96ABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496AB AND
    cpu.logicAnd(0xFFu);
    goto L_0496AE;
L_0496AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496AE CMP
    cpu.compareA(0x82u);
    goto L_0496B1;
L_0496B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496B1 BEQ -> $0496D2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0496D2; }
    goto L_0496B3;
L_0496B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0496B3 PHY
    cpu.push("PHY", hw);
    goto L_0496B4;
L_0496B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B4u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496B4 TYA
    cpu.transfer("TYA");
    goto L_0496B5;
L_0496B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496B5 AND
    cpu.logicAnd(0xFFu);
    goto L_0496B8;
L_0496B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B8u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496B8 EOR
    cpu.logicXor(0x2u);
    goto L_0496BB;
L_0496BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496BB TAY
    cpu.transfer("TAY");
    goto L_0496BC;
L_0496BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BCu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496BC STZ
    hw.write(cpu.address("dp", 0x6u), 0, cpu.m8?8:16);
    goto L_0496BE;
L_0496BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496BE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0496C0;
L_0496C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C0u, 6u, 4u, ((0x7ED000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496C0 LDA
    cpu.loadA(hw.readW(((0x7ED000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0496C4;
L_0496C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496C4 AND
    cpu.logicAnd(0xFFu);
    goto L_0496C7;
L_0496C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496C7 TAX
    cpu.transfer("TAX");
    goto L_0496C8;
L_0496C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C8u, 5u + 1u, 3u, cpu.address("absy", 0x941Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496C8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x941Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0496CB;
L_0496CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CBu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CBu, 5u + 1u, 3u, cpu.address("absx", 0x1EA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496CB ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1EA2u), cpu.m8?8:16));
    goto L_0496CE;
L_0496CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CEu, 6u, 3u, cpu.address("absx", 0x1EA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496CE STA
    hw.write(cpu.address("absx", 0x1EA2u), cpu.a, cpu.m8?8:16);
    goto L_0496D1;
L_0496D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D1u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D1u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0496D1 PLY
    cpu.pop("PLY", hw);
    goto L_0496D2;
L_0496D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D2u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496D2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0496D5;
L_0496D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496D5 LSR
    cpu.lsrA();
    goto L_0496D6;
L_0496D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496D6 AND
    cpu.logicAnd(0x2u);
    goto L_0496D9;
L_0496D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496D9 TAX
    cpu.transfer("TAX");
    goto L_0496DA;
L_0496DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96DAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96DAu, 5u + 1u, 3u, cpu.address("absx", 0x1F13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496DA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0496DD;
L_0496DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96DDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96DDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496DD AND
    cpu.logicAnd(0xCu);
    goto L_0496E0;
L_0496E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496E0 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0496E2;
L_0496E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496E2 LDA
    cpu.setA(0x1u, 16);
    goto L_0496E5;
L_0496E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496E5 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_0496E7;
L_0496E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96E7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96E7u, 5u, 3u, cpu.address("abs", 0x1B7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496E7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B7Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0496EA;
L_0496EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96EAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496EA AND
    cpu.logicAnd(0xFFu);
    goto L_0496ED;
L_0496ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96EDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496ED STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0496EF;
L_0496EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96EFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496EF LDX
    cpu.setX(0x17u, 16);
    goto L_0496F2;
L_0496F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F2u, 5u + 1u, 3u, cpu.address("absx", 0xA03Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496F2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA03Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0496F5;
L_0496F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496F5 AND
    cpu.logicAnd(0xFFu);
    goto L_0496F8;
L_0496F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496F8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_0496FA;
L_0496FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496FA BNE -> $049704
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049704; }
    goto L_0496FC;
L_0496FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FCu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496FC TXA
    cpu.transfer("TXA");
    goto L_0496FD;
L_0496FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496FD ASL
    cpu.aslA();
    goto L_0496FE;
L_0496FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FEu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496FE TAX
    cpu.transfer("TAX");
    goto L_0496FF;
L_0496FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FFu, 5u + 1u, 3u, cpu.address("absx", 0xA054u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0496FF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA054u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049702;
L_049702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9702u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9702u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049702 BRA -> $049718
    hw.requestDispatch(0x049718u,0x049702u); return;
L_049704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9704u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9704u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049704 DEX
    cpu.decReg('X');
    goto L_049705;
L_049705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9705u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9705u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049705 BPL -> $0496F2
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0496F2; }
    goto L_049707;
L_049707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9707u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9707u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049707 LDA
    cpu.setA(0x0u, 16);
    goto L_04970A;
L_04970A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x970Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x970Au,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x970Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04970A ORA
    cpu.logicOr(0x800u);
    goto L_04970D;
L_04970D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x970Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x970Du,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x970Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04970D CPY
    cpu.compareY(0x4u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9710u,0x04970Du); return;
}

void sub_04E761_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04E761u: goto L_04E761;
    case 0x04E763u: goto L_04E763;
    case 0x04E765u: goto L_04E765;
    case 0x04E768u: goto L_04E768;
    case 0x04E76Bu: goto L_04E76B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04E761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE761u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE761u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E761 SEP
    cpu.sep(0x30u);
    goto L_04E763;
L_04E763:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE763u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE763u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE763u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E763 LDA
    cpu.setA(0x15u, 8);
    goto L_04E765;
L_04E765:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE765u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE765u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE765u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E765 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_04E768;
L_04E768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE768u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE768u, 6u, 3u, cpu.address("abs", 0x1B86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E768 INC
    cpu.incMem(hw, cpu.address("abs", 0x1B86u), cpu.m8?8:16);
    goto L_04E76B;
L_04E76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE76Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04E76B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04E76Bu);return;} hw.unresolvedReturn(0x04E76Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04E761_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04E761u: goto L_04E761;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04E761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE761u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE761u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E761 SEP
    cpu.sep(0x30u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE763u,0x04E761u); return;
}

void sub_0DB9C0_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB9C0u: goto L_0DB9C0;
    case 0x0DB9C2u: goto L_0DB9C2;
    case 0x0DB9C4u: goto L_0DB9C4;
    case 0x0DB9C5u: goto L_0DB9C5;
    case 0x0DB9C6u: goto L_0DB9C6;
    case 0x0DB9C7u: goto L_0DB9C7;
    case 0x0DB9C8u: goto L_0DB9C8;
    case 0x0DB9CAu: goto L_0DB9CA;
    case 0x0DB9CDu: goto L_0DB9CD;
    case 0x0DB9CFu: goto L_0DB9CF;
    case 0x0DB9D2u: goto L_0DB9D2;
    case 0x0DB9D5u: goto L_0DB9D5;
    case 0x0DB9D8u: goto L_0DB9D8;
    case 0x0DB9DAu: goto L_0DB9DA;
    case 0x0DB9DCu: goto L_0DB9DC;
    case 0x0DB9DFu: goto L_0DB9DF;
    case 0x0DB9E1u: goto L_0DB9E1;
    case 0x0DB9E4u: goto L_0DB9E4;
    case 0x0DB9E7u: goto L_0DB9E7;
    case 0x0DB9E9u: goto L_0DB9E9;
    case 0x0DB9EBu: goto L_0DB9EB;
    case 0x0DB9EEu: goto L_0DB9EE;
    case 0x0DB9F1u: goto L_0DB9F1;
    case 0x0DB9F3u: goto L_0DB9F3;
    case 0x0DB9F5u: goto L_0DB9F5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB9C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C0u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB9C0 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB9C2;
L_0DB9C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB9C2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB9C4;
L_0DB9C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB9C4 LSR
    cpu.lsrA();
    goto L_0DB9C5;
L_0DB9C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB9C5 LSR
    cpu.lsrA();
    goto L_0DB9C6;
L_0DB9C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB9C6 LSR
    cpu.lsrA();
    goto L_0DB9C7;
L_0DB9C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB9C7 LSR
    cpu.lsrA();
    goto L_0DB9C8;
L_0DB9C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB9C8 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DB9CA;
L_0DB9CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CAu, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB9CA JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xB9CCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB9CDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DB9CAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB9CD;
L_0DB9CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9CDu,0x0DB9CDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB9CD LDX
    cpu.setX(0xB9u, 8);
    goto L_0DB9CF;
L_0DB9CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CFu, 6u, 3u, cpu.address("abs", 0xB9F6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB9CF JSR -> $0DB9F6 stack real
    { cpu.push16Value(hw,0xB9D1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB9D2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB9F6u), 0x0DB9CFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB9D2;
L_0DB9D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9D2u,0x0DB9D2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D2u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB9D2 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xB9D4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB9D5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DB9D2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB9D5;
L_0DB9D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9D5u,0x0DB9D5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D5u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB9D5 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xB9D7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB9D8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DB9D5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB9D8;
L_0DB9D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9D8u,0x0DB9D8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D8u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB9D8 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DB9DA;
L_0DB9DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB9DA BMI -> $0DB9F5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB9F5; }
    goto L_0DB9DC;
L_0DB9DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DCu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB9DC JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB9DEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB9DFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB9DCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB9DF;
L_0DB9DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9DFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9DFu,0x0DB9DFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB9DF LDA
    cpu.setA(0xBBu, 8);
    goto L_0DB9E1;
L_0DB9E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E1u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB9E1 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB9E3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB9E4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB9E1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB9E4;
L_0DB9E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9E4u,0x0DB9E4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E4u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB9E4 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB9E6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB9E7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB9E4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB9E7;
L_0DB9E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9E7u,0x0DB9E7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB9E7 LDA
    cpu.setA(0xBCu, 8);
    goto L_0DB9E9;
L_0DB9E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E9u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E9u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DB9E9 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DB9EB;
L_0DB9EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EBu, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB9EB JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xB9EDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB9EEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DB9EBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB9EE;
L_0DB9EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9EEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9EEu,0x0DB9EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EEu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB9EE JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xB9F0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB9F1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DB9EEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB9F1;
L_0DB9F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9F1u,0x0DB9F1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F1u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB9F1 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DB9F3;
L_0DB9F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F3u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB9F3 BPL -> $0DB9CA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB9CA; }
    goto L_0DB9F5;
L_0DB9F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB9F5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB9F5u);return;} hw.unresolvedReturn(0x0DB9F5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DCE67_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DCE67u: goto L_0DCE67;
    case 0x0DCE69u: goto L_0DCE69;
    case 0x0DCE6Bu: goto L_0DCE6B;
    case 0x0DCE6Cu: goto L_0DCE6C;
    case 0x0DCE6Eu: goto L_0DCE6E;
    case 0x0DCE6Fu: goto L_0DCE6F;
    case 0x0DCE70u: goto L_0DCE70;
    case 0x0DCE71u: goto L_0DCE71;
    case 0x0DCE74u: goto L_0DCE74;
    case 0x0DCE77u: goto L_0DCE77;
    case 0x0DCE7Bu: goto L_0DCE7B;
    case 0x0DCE7Eu: goto L_0DCE7E;
    case 0x0DCE7Fu: goto L_0DCE7F;
    case 0x0DCE80u: goto L_0DCE80;
    case 0x0DCE82u: goto L_0DCE82;
    case 0x0DCE84u: goto L_0DCE84;
    case 0x0DCE87u: goto L_0DCE87;
    case 0x0DCE8Au: goto L_0DCE8A;
    case 0x0DCE8Bu: goto L_0DCE8B;
    case 0x0DCE8Du: goto L_0DCE8D;
    case 0x0DCE8Fu: goto L_0DCE8F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DCE67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE67u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE67u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE67 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DCE69;
L_0DCE69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE69u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE69u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE69 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCE6B;
L_0DCE6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE6Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE6Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE6B SEC
    cpu.setFlag('C', true);
    goto L_0DCE6C;
L_0DCE6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE6Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE6Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE6C SBC
    cpu.sbc(0x4Du);
    goto L_0DCE6E;
L_0DCE6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE6Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE6Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE6E ASL
    cpu.aslA();
    goto L_0DCE6F;
L_0DCE6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE6Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE6F ASL
    cpu.aslA();
    goto L_0DCE70;
L_0DCE70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE70u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE70u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE70 TAX
    cpu.transfer("TAX");
    goto L_0DCE71;
L_0DCE71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE71u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE71u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCE71 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xCE73u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCE74u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DCE71u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCE74;
L_0DCE74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE74u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCE74u,0x0DCE74u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE74u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE74u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCE74 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xCE76u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCE77u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DCE74u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCE77;
L_0DCE77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE77u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCE77u,0x0DCE77u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE77u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE77u, 5u, 4u, ((0x0DCE57u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE77 LDA
    cpu.loadA(hw.readW(((0xDCE57u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCE7B;
L_0DCE7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Bu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCE7B JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xCE7Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCE7Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DCE7Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCE7E;
L_0DCE7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE7Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCE7Eu,0x0DCE7Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE7E INX
    cpu.inc('X');
    goto L_0DCE7F;
L_0DCE7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE7F TXA
    cpu.transfer("TXA");
    goto L_0DCE80;
L_0DCE80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE80u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE80u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE80 AND
    cpu.logicAnd(0x1u);
    goto L_0DCE82;
L_0DCE82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE82u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE82 BNE -> $0DCE74
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DCE74; }
    goto L_0DCE84;
L_0DCE84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE84u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE84u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCE84 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xCE86u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCE87u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DCE84u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCE87;
L_0DCE87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE87u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCE87u,0x0DCE87u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE87u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE87u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCE87 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xCE89u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCE8Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DCE87u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCE8A;
L_0DCE8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE8Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCE8Au,0x0DCE8Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE8A TXA
    cpu.transfer("TXA");
    goto L_0DCE8B;
L_0DCE8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE8B AND
    cpu.logicAnd(0x3u);
    goto L_0DCE8D;
L_0DCE8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCE8D BNE -> $0DCE74
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DCE74; }
    goto L_0DCE8F;
L_0DCE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCE8F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DCE8Fu);return;} hw.unresolvedReturn(0x0DCE8Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DCEDA_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DCEDAu: goto L_0DCEDA;
    case 0x0DCEDCu: goto L_0DCEDC;
    case 0x0DCEDEu: goto L_0DCEDE;
    case 0x0DCEE0u: goto L_0DCEE0;
    case 0x0DCEE3u: goto L_0DCEE3;
    case 0x0DCEE7u: goto L_0DCEE7;
    case 0x0DCEEAu: goto L_0DCEEA;
    case 0x0DCEEBu: goto L_0DCEEB;
    case 0x0DCEEDu: goto L_0DCEED;
    case 0x0DCEEFu: goto L_0DCEEF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DCEDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDAu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCEDA LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DCEDC;
L_0DCEDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCEDC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCEDE;
L_0DCEDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCEDE LDX
    cpu.setX(0x0u, 8);
    goto L_0DCEE0;
L_0DCEE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE0u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCEE0 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xCEE2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCEE3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DCEE0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCEE3;
L_0DCEE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCEE3u,0x0DCEE3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE3u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE3u, 5u, 4u, ((0x0DCED8u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCEE3 LDA
    cpu.loadA(hw.readW(((0xDCED8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCEE7;
L_0DCEE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE7u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCEE7 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xCEE9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCEEAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DCEE7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCEEA;
L_0DCEEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEEAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCEEAu,0x0DCEEAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCEEA INX
    cpu.inc('X');
    goto L_0DCEEB;
L_0DCEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEBu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCEEB CPX
    cpu.compareX(0x2u);
    goto L_0DCEED;
L_0DCEED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCEED BNE -> $0DCEE0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DCEE0; }
    goto L_0DCEEF;
L_0DCEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCEEF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DCEEFu);return;} hw.unresolvedReturn(0x0DCEEFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DCF53_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DCF53u: goto L_0DCF53;
    case 0x0DCF55u: goto L_0DCF55;
    case 0x0DCF57u: goto L_0DCF57;
    case 0x0DCF58u: goto L_0DCF58;
    case 0x0DCF5Cu: goto L_0DCF5C;
    case 0x0DCF5Fu: goto L_0DCF5F;
    case 0x0DCF61u: goto L_0DCF61;
    case 0x0DCF64u: goto L_0DCF64;
    case 0x0DCF67u: goto L_0DCF67;
    case 0x0DCF6Au: goto L_0DCF6A;
    case 0x0DCF6Du: goto L_0DCF6D;
    case 0x0DCF70u: goto L_0DCF70;
    case 0x0DCF72u: goto L_0DCF72;
    case 0x0DCF73u: goto L_0DCF73;
    case 0x0DCF74u: goto L_0DCF74;
    case 0x0DCF75u: goto L_0DCF75;
    case 0x0DCF76u: goto L_0DCF76;
    case 0x0DCF77u: goto L_0DCF77;
    case 0x0DCF7Au: goto L_0DCF7A;
    case 0x0DCF7Du: goto L_0DCF7D;
    case 0x0DCF7Fu: goto L_0DCF7F;
    case 0x0DCF82u: goto L_0DCF82;
    case 0x0DCF85u: goto L_0DCF85;
    case 0x0DCF87u: goto L_0DCF87;
    case 0x0DCF89u: goto L_0DCF89;
    case 0x0DCF8Cu: goto L_0DCF8C;
    case 0x0DCF8Eu: goto L_0DCF8E;
    case 0x0DCF8Fu: goto L_0DCF8F;
    case 0x0DCF91u: goto L_0DCF91;
    case 0x0DCF92u: goto L_0DCF92;
    case 0x0DCF94u: goto L_0DCF94;
    case 0x0DCF97u: goto L_0DCF97;
    case 0x0DCF98u: goto L_0DCF98;
    case 0x0DCF9Au: goto L_0DCF9A;
    case 0x0DCF9Cu: goto L_0DCF9C;
    case 0x0DCF9Eu: goto L_0DCF9E;
    case 0x0DCF9Fu: goto L_0DCF9F;
    case 0x0DCFA0u: goto L_0DCFA0;
    case 0x0DCFA2u: goto L_0DCFA2;
    case 0x0DCFA3u: goto L_0DCFA3;
    case 0x0DCFA5u: goto L_0DCFA5;
    case 0x0DCFA8u: goto L_0DCFA8;
    case 0x0DCFABu: goto L_0DCFAB;
    case 0x0DCFADu: goto L_0DCFAD;
    case 0x0DCFAEu: goto L_0DCFAE;
    case 0x0DCFB0u: goto L_0DCFB0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DCF53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF53u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF53u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF53 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCF55;
L_0DCF55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF55u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF55 AND
    cpu.logicAnd(0xFu);
    goto L_0DCF57;
L_0DCF57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF57u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF57u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF57 TAX
    cpu.transfer("TAX");
    goto L_0DCF58;
L_0DCF58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF58u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF58u, 8u, 4u, 0x0086FAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0DCF58 JSL -> $0086FA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCF5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF5Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086FAu, 0x0DCF58u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCF5C;
L_0DCF5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF5Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF5Cu,0x0DCF5Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Cu,cpu,0x6Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Cu, 6u, 3u, cpu.address("abs", 0x0DCFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF5C ROR
    cpu.rorMem(hw, cpu.address("abs", 0xDCFu), cpu.m8?8:16);
    goto L_0DCF5F;
L_0DCF5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Fu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xCFu) & 0xFFFFu), 2u, 0u);
    // $0DCF5F LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0xCFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCF61;
L_0DCF61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF61u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF61u, 4u, 3u, cpu.address("abs", 0xCFF0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF61 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xCFF0u), cpu.m8?8:16));
    goto L_0DCF64;
L_0DCF64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF64u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF64u, 4u, 3u, cpu.address("abs", 0xD034u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF64 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xD034u), cpu.m8?8:16));
    goto L_0DCF67;
L_0DCF67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF67u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF67u, 4u, 3u, cpu.address("abs", 0xCFB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF67 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xCFB1u), cpu.m8?8:16));
    goto L_0DCF6A;
L_0DCF6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Au,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Au, 4u, 3u, cpu.address("abs", 0xD034u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF6A ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0xD034u), cpu.m8?8:16));
    goto L_0DCF6D;
L_0DCF6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Du,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Du, 4u, 3u, cpu.address("abs", 0x57A4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF6D ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x57A4u), cpu.m8?8:16));
    goto L_0DCF70;
L_0DCF70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF70u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF70u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF70 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCF72;
L_0DCF72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF72u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF72u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF72 LSR
    cpu.lsrA();
    goto L_0DCF73;
L_0DCF73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF73u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF73u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF73 LSR
    cpu.lsrA();
    goto L_0DCF74;
L_0DCF74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF74u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF74u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF74 LSR
    cpu.lsrA();
    goto L_0DCF75;
L_0DCF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF75u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF75u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF75 LSR
    cpu.lsrA();
    goto L_0DCF76;
L_0DCF76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF76u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF76u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF76 TAX
    cpu.transfer("TAX");
    goto L_0DCF77;
L_0DCF77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF77u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF77u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCF77 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xCF79u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF7Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DCF77u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCF7A;
L_0DCF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF7Au,0x0DCF7Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Au, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCF7A JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xCF7Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF7Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DCF7Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCF7D;
L_0DCF7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF7Du,0x0DCF7Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF7D LDA
    cpu.setA(0x8Cu, 8);
    goto L_0DCF7F;
L_0DCF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCF7F JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xCF81u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF82u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DCF7Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCF82;
L_0DCF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF82u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF82u,0x0DCF82u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCF82 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xCF84u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF85u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DCF82u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCF85;
L_0DCF85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF85u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF85u,0x0DCF85u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF85u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF85 LDA
    cpu.setA(0x8Du, 8);
    goto L_0DCF87;
L_0DCF87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF87u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF87u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DCF87 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DCF89;
L_0DCF89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF89u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF89u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCF89 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xCF8Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF8Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DCF89u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCF8C;
L_0DCF8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF8Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF8Cu,0x0DCF8Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF8C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x57u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCF8E;
L_0DCF8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF8E CLC
    cpu.setFlag('C', false);
    goto L_0DCF8F;
L_0DCF8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF8F ADC
    cpu.adc(0xEu);
    goto L_0DCF91;
L_0DCF91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF91u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF91u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF91 TAY
    cpu.transfer("TAY");
    goto L_0DCF92;
L_0DCF92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF92u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF92 BCC -> $0DCF97
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DCF97; }
    goto L_0DCF94;
L_0DCF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF94u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF94u, 6u, 3u, cpu.address("abs", 0xA987u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCF94 JSR -> $0DA987 stack real
    { cpu.push16Value(hw,0xCF96u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF97u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA987u), 0x0DCF94u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCF97;
L_0DCF97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF97u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF97u,0x0DCF97u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF97u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF97u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF97 TYA
    cpu.transfer("TYA");
    goto L_0DCF98;
L_0DCF98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF98u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF98 AND
    cpu.logicAnd(0xFu);
    goto L_0DCF9A;
L_0DCF9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF9A CMP
    cpu.compareA(0xEu);
    goto L_0DCF9C;
L_0DCF9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF9C BMI -> $0DCFAB
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DCFAB; }
    goto L_0DCF9E;
L_0DCF9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Eu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF9E TYA
    cpu.transfer("TYA");
    goto L_0DCF9F;
L_0DCF9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF9F CLC
    cpu.setFlag('C', false);
    goto L_0DCFA0;
L_0DCFA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFA0 ADC
    cpu.adc(0x10u);
    goto L_0DCFA2;
L_0DCFA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA2u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFA2 TAY
    cpu.transfer("TAY");
    goto L_0DCFA3;
L_0DCFA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFA3 BCC -> $0DCFA8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DCFA8; }
    goto L_0DCFA5;
L_0DCFA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA5u, 6u, 3u, cpu.address("abs", 0xA987u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCFA5 JSR -> $0DA987 stack real
    { cpu.push16Value(hw,0xCFA7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCFA8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA987u), 0x0DCFA5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCFA8;
L_0DCFA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCFA8u,0x0DCFA8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA8u, 6u, 3u, cpu.address("abs", 0xA9D6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCFA8 JSR -> $0DA9D6 stack real
    { cpu.push16Value(hw,0xCFAAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCFABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA9D6u), 0x0DCFA8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCFAB;
L_0DCFAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFABu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCFABu,0x0DCFABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFABu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFABu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFAB STY
    hw.write(cpu.address("dp", 0x57u), cpu.y, cpu.x8?8:16);
    goto L_0DCFAD;
L_0DCFAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFADu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFAD DEX
    cpu.decReg('X');
    goto L_0DCFAE;
L_0DCFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFAEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFAEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFAE BPL -> $0DCF7A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DCF7A; }
    goto L_0DCFB0;
L_0DCFB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCFB0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DCFB0u);return;} hw.unresolvedReturn(0x0DCFB0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_808123_E0M0X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808123u: goto L_808123;
    case 0x808125u: goto L_808125;
    case 0x808127u: goto L_808127;
    case 0x80812Au: goto L_80812A;
    case 0x80812Du: goto L_80812D;
    case 0x808130u: goto L_808130;
    case 0x808131u: goto L_808131;
    case 0x808133u: goto L_808133;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u,cpu,0xF7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x80u) & 0xFFFFu), 3u, 0u);
    // $808123 SBC
    cpu.sbc(hw.readW(cpu.addressDpLongY(hw, 0x80u), cpu.m8?8:16));
    goto L_808125;
L_808125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808125 LDX
    cpu.setX(0x3u, 8);
    goto L_808127;
L_808127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u, 6u, 3u, cpu.address("absx", 0x2140u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808127 STZ
    hw.write(cpu.address("absx", 0x2140u), 0, cpu.m8?8:16);
    goto L_80812A;
L_80812A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au, 6u, 3u, cpu.address("absx", 0x1DF9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80812A STZ
    hw.write(cpu.address("absx", 0x1DF9u), 0, cpu.m8?8:16);
    goto L_80812D;
L_80812D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du, 6u, 3u, cpu.address("absx", 0x1DFDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80812D STZ
    hw.write(cpu.address("absx", 0x1DFDu), 0, cpu.m8?8:16);
    goto L_808130;
L_808130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808130 DEX
    cpu.decReg('X');
    goto L_808131;
L_808131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808131 BPL -> $808127
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808127; }
    goto L_808133;
L_808133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8133u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8133u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8133u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808133 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x808133u);return;} hw.unresolvedReturn(0x808133u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_808123_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808123u: goto L_808123;
    case 0x808125u: goto L_808125;
    case 0x808127u: goto L_808127;
    case 0x80812Au: goto L_80812A;
    case 0x80812Du: goto L_80812D;
    case 0x808130u: goto L_808130;
    case 0x808131u: goto L_808131;
    case 0x808133u: goto L_808133;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u,cpu,0xF7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x80u) & 0xFFFFu), 3u, 0u);
    // $808123 SBC
    cpu.sbc(hw.readW(cpu.addressDpLongY(hw, 0x80u), cpu.m8?8:16));
    goto L_808125;
L_808125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808125 LDX
    cpu.setX(0x3u, 8);
    goto L_808127;
L_808127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u, 6u, 3u, cpu.address("absx", 0x2140u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808127 STZ
    hw.write(cpu.address("absx", 0x2140u), 0, cpu.m8?8:16);
    goto L_80812A;
L_80812A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au, 6u, 3u, cpu.address("absx", 0x1DF9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80812A STZ
    hw.write(cpu.address("absx", 0x1DF9u), 0, cpu.m8?8:16);
    goto L_80812D;
L_80812D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du, 6u, 3u, cpu.address("absx", 0x1DFDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80812D STZ
    hw.write(cpu.address("absx", 0x1DFDu), 0, cpu.m8?8:16);
    goto L_808130;
L_808130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808130 DEX
    cpu.decReg('X');
    goto L_808131;
L_808131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808131 BPL -> $808127
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808127; }
    goto L_808133;
L_808133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8133u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8133u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8133u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808133 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x808133u);return;} hw.unresolvedReturn(0x808133u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1AD42_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1AD42u: goto L_B1AD42;
    case 0xB1AD44u: goto L_B1AD44;
    case 0xB1AD46u: goto L_B1AD46;
    case 0xB1AD47u: goto L_B1AD47;
    case 0xB1AD49u: goto L_B1AD49;
    case 0xB1AD4Bu: goto L_B1AD4B;
    case 0xB1AD4Du: goto L_B1AD4D;
    case 0xB1AD50u: goto L_B1AD50;
    case 0xB1AD52u: goto L_B1AD52;
    case 0xB1AD53u: goto L_B1AD53;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1AD42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD42u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD42 LDY
    cpu.setY(0x0u, 8);
    goto L_B1AD44;
L_B1AD44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD44u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD44u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD44 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xD3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1AD46;
L_B1AD46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD46u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD46 SEC
    cpu.setFlag('C', true);
    goto L_B1AD47;
L_B1AD47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD47u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD47u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD47 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16));
    goto L_B1AD49;
L_B1AD49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD49u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD49u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD49 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_B1AD4B;
L_B1AD4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD4B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xD4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1AD4D;
L_B1AD4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Du,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD4Du, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD4D SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16));
    goto L_B1AD50;
L_B1AD50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD50u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD50u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD50 BPL -> $B1AD53
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_B1AD53; }
    goto L_B1AD52;
L_B1AD52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD52u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD52u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD52 INY
    cpu.inc('Y');
    goto L_B1AD53;
L_B1AD53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD53u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD53u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1AD53 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1AD53u);return;} hw.unresolvedReturn(0xB1AD53u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_E4862E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xE4862Eu: goto L_E4862E;
    case 0xE48630u: goto L_E48630;
    case 0xE48633u: goto L_E48633;
    case 0xE48636u: goto L_E48636;
    case 0xE48637u: goto L_E48637;
    case 0xE48639u: goto L_E48639;
    case 0xE4863Cu: goto L_E4863C;
    case 0xE4863Eu: goto L_E4863E;
    case 0xE48640u: goto L_E48640;
    case 0xE48642u: goto L_E48642;
    case 0xE48645u: goto L_E48645;
    case 0xE48646u: goto L_E48646;
    case 0xE48648u: goto L_E48648;
    case 0xE4864Bu: goto L_E4864B;
    case 0xE4864Du: goto L_E4864D;
    case 0xE48650u: goto L_E48650;
    case 0xE48652u: goto L_E48652;
    case 0xE48654u: goto L_E48654;
    case 0xE48655u: goto L_E48655;
    case 0xE48658u: goto L_E48658;
    case 0xE48659u: goto L_E48659;
    case 0xE4865Cu: goto L_E4865C;
    case 0xE4865Du: goto L_E4865D;
    case 0xE4865Fu: goto L_E4865F;
    case 0xE48662u: goto L_E48662;
    case 0xE48664u: goto L_E48664;
    case 0xE48666u: goto L_E48666;
    case 0xE48668u: goto L_E48668;
    case 0xE4866Bu: goto L_E4866B;
    case 0xE4866Cu: goto L_E4866C;
    case 0xE4866Eu: goto L_E4866E;
    case 0xE48671u: goto L_E48671;
    case 0xE48673u: goto L_E48673;
    case 0xE48676u: goto L_E48676;
    case 0xE48678u: goto L_E48678;
    case 0xE4867Au: goto L_E4867A;
    case 0xE4867Cu: goto L_E4867C;
    case 0xE4867Eu: goto L_E4867E;
    case 0xE4867Fu: goto L_E4867F;
    case 0xE48681u: goto L_E48681;
    case 0xE48683u: goto L_E48683;
    case 0xE48685u: goto L_E48685;
    case 0xE48686u: goto L_E48686;
    case 0xE48688u: goto L_E48688;
    case 0xE4868Au: goto L_E4868A;
    case 0xE4868Cu: goto L_E4868C;
    case 0xE4868Du: goto L_E4868D;
    case 0xE4868Fu: goto L_E4868F;
    case 0xE48691u: goto L_E48691;
    case 0xE48693u: goto L_E48693;
    case 0xE48694u: goto L_E48694;
    case 0xE48696u: goto L_E48696;
    case 0xE48698u: goto L_E48698;
    case 0xE4869Au: goto L_E4869A;
    case 0xE4869Cu: goto L_E4869C;
    case 0xE4869Eu: goto L_E4869E;
    case 0xE486A0u: goto L_E486A0;
    case 0xE486A2u: goto L_E486A2;
    case 0xE486A4u: goto L_E486A4;
    case 0xE486A6u: goto L_E486A6;
    case 0xE486A8u: goto L_E486A8;
    case 0xE486ABu: goto L_E486AB;
    case 0xE486ACu: goto L_E486AC;
    case 0xE486ADu: goto L_E486AD;
    case 0xE486B0u: goto L_E486B0;
    case 0xE486B2u: goto L_E486B2;
    case 0xE486B4u: goto L_E486B4;
    case 0xE486B6u: goto L_E486B6;
    case 0xE486B8u: goto L_E486B8;
    case 0xE486BAu: goto L_E486BA;
    case 0xE486BCu: goto L_E486BC;
    case 0xE486BEu: goto L_E486BE;
    case 0xE486BFu: goto L_E486BF;
    case 0xE486C1u: goto L_E486C1;
    case 0xE486C3u: goto L_E486C3;
    case 0xE486C5u: goto L_E486C5;
    case 0xE486C7u: goto L_E486C7;
    case 0xE486CAu: goto L_E486CA;
    case 0xE486CBu: goto L_E486CB;
    case 0xE486CCu: goto L_E486CC;
    case 0xE486CEu: goto L_E486CE;
    case 0xE486D1u: goto L_E486D1;
    case 0xE486D4u: goto L_E486D4;
    case 0xE486D7u: goto L_E486D7;
    case 0xE486D8u: goto L_E486D8;
    case 0xE486D9u: goto L_E486D9;
    case 0xE486DCu: goto L_E486DC;
    case 0xE486DFu: goto L_E486DF;
    case 0xE486E1u: goto L_E486E1;
    case 0xE486E4u: goto L_E486E4;
    case 0xE486E7u: goto L_E486E7;
    case 0xE486EAu: goto L_E486EA;
    case 0xE486EDu: goto L_E486ED;
    case 0xE486F0u: goto L_E486F0;
    case 0xE486F3u: goto L_E486F3;
    case 0xE486F6u: goto L_E486F6;
    case 0xE486F9u: goto L_E486F9;
    case 0xE486FBu: goto L_E486FB;
    case 0xE486FDu: goto L_E486FD;
    case 0xE48700u: goto L_E48700;
    case 0xE48703u: goto L_E48703;
    case 0xE48705u: goto L_E48705;
    case 0xE48707u: goto L_E48707;
    case 0xE48709u: goto L_E48709;
    case 0xE4870Cu: goto L_E4870C;
    case 0xE4870Eu: goto L_E4870E;
    case 0xE48710u: goto L_E48710;
    case 0xE48712u: goto L_E48712;
    case 0xE48714u: goto L_E48714;
    case 0xE48716u: goto L_E48716;
    case 0xE48718u: goto L_E48718;
    case 0xE4871Au: goto L_E4871A;
    case 0xE4871Du: goto L_E4871D;
    case 0xE4871Eu: goto L_E4871E;
    case 0xE48720u: goto L_E48720;
    case 0xE48721u: goto L_E48721;
    case 0xE48724u: goto L_E48724;
    case 0xE48726u: goto L_E48726;
    case 0xE48728u: goto L_E48728;
    case 0xE4872Au: goto L_E4872A;
    case 0xE4872Cu: goto L_E4872C;
    case 0xE4872Eu: goto L_E4872E;
    case 0xE48730u: goto L_E48730;
    case 0xE48732u: goto L_E48732;
    case 0xE48733u: goto L_E48733;
    case 0xE48735u: goto L_E48735;
    case 0xE48737u: goto L_E48737;
    case 0xE48739u: goto L_E48739;
    case 0xE4873Bu: goto L_E4873B;
    case 0xE4873Eu: goto L_E4873E;
    case 0xE48741u: goto L_E48741;
    case 0xE48743u: goto L_E48743;
    case 0xE48745u: goto L_E48745;
    case 0xE48748u: goto L_E48748;
    case 0xE4874Au: goto L_E4874A;
    case 0xE4874Cu: goto L_E4874C;
    case 0xE4874Fu: goto L_E4874F;
    case 0xE48751u: goto L_E48751;
    case 0xE48753u: goto L_E48753;
    case 0xE48756u: goto L_E48756;
    case 0xE48758u: goto L_E48758;
    case 0xE4875Bu: goto L_E4875B;
    case 0xE4875Eu: goto L_E4875E;
    case 0xE48761u: goto L_E48761;
    case 0xE48762u: goto L_E48762;
    case 0xE48765u: goto L_E48765;
    case 0xE48766u: goto L_E48766;
    case 0xE48769u: goto L_E48769;
    case 0xE4876Cu: goto L_E4876C;
    case 0xE4876Eu: goto L_E4876E;
    case 0xE48771u: goto L_E48771;
    case 0xE48774u: goto L_E48774;
    case 0xE48777u: goto L_E48777;
    case 0xE4877Au: goto L_E4877A;
    case 0xE4877Du: goto L_E4877D;
    case 0xE48780u: goto L_E48780;
    case 0xE48783u: goto L_E48783;
    case 0xE48786u: goto L_E48786;
    case 0xE48788u: goto L_E48788;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_E4862E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4862E REP
    cpu.rep(0x30u);
    goto L_E48630;
L_E48630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8630u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8630u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48630 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_E48633;
L_E48633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u, 5u + 1u, 3u, cpu.address("absx", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48633 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48636;
L_E48636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48636 SEC
    cpu.setFlag('C', true);
    goto L_E48637;
L_E48637:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8637u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8637u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8637u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48637 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_E48639;
L_E48639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48639 CMP
    cpu.compareA(0x100u);
    goto L_E4863C;
L_E4863C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4863C BCS -> $E4864D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_E4864D; }
    goto L_E4863E;
L_E4863E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4863E STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_E48640;
L_E48640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8640u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8640u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8640u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48640 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_E48642;
L_E48642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u, 5u + 1u, 3u, cpu.address("absx", 0x1F19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48642 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48645;
L_E48645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8645u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8645u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48645 SEC
    cpu.setFlag('C', true);
    goto L_E48646;
L_E48646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8646u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8646u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8646u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48646 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_E48648;
L_E48648:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8648u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8648u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8648u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48648 CMP
    cpu.compareA(0x100u);
    goto L_E4864B;
L_E4864B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4864B BCC -> $E48650
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_E48650; }
    goto L_E4864D;
L_E4864D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4864D LDA
    cpu.setA(0xF0u, 16);
    goto L_E48650;
L_E48650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8650u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8650u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48650 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_E48652;
L_E48652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8652u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8652u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48652 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_E48654;
L_E48654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8654u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8654u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48654 TXA
    cpu.transfer("TXA");
    goto L_E48655;
L_E48655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8655u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8655u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48655 EOR
    cpu.logicXor(0x4u);
    goto L_E48658;
L_E48658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8658u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8658u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48658 TAX
    cpu.transfer("TAX");
    goto L_E48659;
L_E48659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8659u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8659u, 5u + 1u, 3u, cpu.address("absx", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48659 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4865C;
L_E4865C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4865C SEC
    cpu.setFlag('C', true);
    goto L_E4865D;
L_E4865D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Du,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4865D SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_E4865F;
L_E4865F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4865F CMP
    cpu.compareA(0x100u);
    goto L_E48662;
L_E48662:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8662u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8662u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8662u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48662 BCS -> $E48673
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_E48673; }
    goto L_E48664;
L_E48664:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8664u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8664u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8664u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48664 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_E48666;
L_E48666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8666u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8666u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48666 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_E48668;
L_E48668:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8668u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8668u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8668u, 5u + 1u, 3u, cpu.address("absx", 0x1F19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48668 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4866B;
L_E4866B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4866B SEC
    cpu.setFlag('C', true);
    goto L_E4866C;
L_E4866C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Cu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4866C SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_E4866E;
L_E4866E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4866E CMP
    cpu.compareA(0x100u);
    goto L_E48671;
L_E48671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8671u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8671u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48671 BCC -> $E48676
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_E48676; }
    goto L_E48673;
L_E48673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8673u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8673u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48673 LDA
    cpu.setA(0xF0u, 16);
    goto L_E48676;
L_E48676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48676 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_E48678;
L_E48678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8678u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8678u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48678 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_E4867A;
L_E4867A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4867A SEP
    cpu.sep(0x30u);
    goto L_E4867C;
L_E4867C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4867C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4867E;
L_E4867E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4867E SEC
    cpu.setFlag('C', true);
    goto L_E4867F;
L_E4867F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4867F SBC
    cpu.sbc(0x8u);
    goto L_E48681;
L_E48681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8681u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8681u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48681 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_E48683;
L_E48683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48683 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48685;
L_E48685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8685u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8685u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8685u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48685 SEC
    cpu.setFlag('C', true);
    goto L_E48686;
L_E48686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8686u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8686u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48686 SBC
    cpu.sbc(0x9u);
    goto L_E48688;
L_E48688:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8688u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8688u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8688u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48688 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_E4868A;
L_E4868A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4868A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4868C;
L_E4868C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4868C SEC
    cpu.setFlag('C', true);
    goto L_E4868D;
L_E4868D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4868D SBC
    cpu.sbc(0x8u);
    goto L_E4868F;
L_E4868F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4868F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_E48691;
L_E48691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8691u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8691u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8691u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48691 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48693;
L_E48693:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8693u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8693u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8693u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48693 SEC
    cpu.setFlag('C', true);
    goto L_E48694;
L_E48694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8694u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8694u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48694 SBC
    cpu.sbc(0x9u);
    goto L_E48696;
L_E48696:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8696u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8696u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8696u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48696 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_E48698;
L_E48698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8698u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8698u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8698u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48698 LDA
    cpu.setA(0x3u, 8);
    goto L_E4869A;
L_E4869A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4869A STA
    hw.write(cpu.address("dp", 0x8Cu), cpu.a, cpu.m8?8:16);
    goto L_E4869C;
L_E4869C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4869C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4869E;
L_E4869E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4869E STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_E486A0;
L_E486A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486A0 STA
    hw.write(cpu.address("dp", 0x8Au), cpu.a, cpu.m8?8:16);
    goto L_E486A2;
L_E486A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486A2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E486A4;
L_E486A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486A4 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_E486A6;
L_E486A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486A6 STA
    hw.write(cpu.address("dp", 0x8Bu), cpu.a, cpu.m8?8:16);
    goto L_E486A8;
L_E486A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A8u, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486A8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E486AB;
L_E486AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ABu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486AB LSR
    cpu.lsrA();
    goto L_E486AC;
L_E486AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486AC TAY
    cpu.transfer("TAY");
    goto L_E486AD;
L_E486AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ADu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ADu, 4u + ((((0x1F13u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486AD LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1F13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E486B0;
L_E486B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486B0 CMP
    cpu.compareA(0x12u);
    goto L_E486B2;
L_E486B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486B2 BEQ -> $E486C5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_E486C5; }
    goto L_E486B4;
L_E486B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486B4 CMP
    cpu.compareA(0x7u);
    goto L_E486B6;
L_E486B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486B6 BCC -> $E486BC
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_E486BC; }
    goto L_E486B8;
L_E486B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486B8 CMP
    cpu.compareA(0xFu);
    goto L_E486BA;
L_E486BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486BA BCC -> $E486C5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_E486C5; }
    goto L_E486BC;
L_E486BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486BC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E486BE;
L_E486BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486BE SEC
    cpu.setFlag('C', true);
    goto L_E486BF;
L_E486BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BFu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486BF SBC
    cpu.sbc(0x5u);
    goto L_E486C1;
L_E486C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486C1 STA
    hw.write(cpu.address("dp", 0x8Bu), cpu.a, cpu.m8?8:16);
    goto L_E486C3;
L_E486C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486C3 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_E486C5;
L_E486C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486C5 REP
    cpu.rep(0x30u);
    goto L_E486C7;
L_E486C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C7u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486C7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E486CA;
L_E486CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CAu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486CA XBA
    cpu.xba();
    goto L_E486CB;
L_E486CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CBu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486CB LSR
    cpu.lsrA();
    goto L_E486CC;
L_E486CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486CC STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_E486CE;
L_E486CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486CE LDX
    cpu.setX(0x0u, 16);
    goto L_E486D1;
L_E486D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D1u, 6u, 3u, cpu.address("abs", 0x8789u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E486D1 JSR -> $E48789 stack real
    { cpu.push16Value(hw,0x86D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8789u), 0xE486D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_E486D4;
L_E486D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86D4u,0xE486D4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486D4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E486D7;
L_E486D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486D7 LSR
    cpu.lsrA();
    goto L_E486D8;
L_E486D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D8u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486D8 TAY
    cpu.transfer("TAY");
    goto L_E486D9;
L_E486D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486D9 LDX
    cpu.setX(0x0u, 16);
    goto L_E486DC;
L_E486DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DCu, 6u, 3u, cpu.address("abs", 0x894Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E486DC JSR -> $E4894F stack real
    { cpu.push16Value(hw,0x86DEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86DFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x894Fu), 0xE486DCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_E486DF;
L_E486DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86DFu,0xE486DFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486DF SEP
    cpu.sep(0x30u);
    goto L_E486E1;
L_E486E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E1u, 4u, 3u, cpu.address("abs", 0x0447u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486E1 STZ
    hw.write(cpu.address("abs", 0x447u), 0, cpu.m8?8:16);
    goto L_E486E4;
L_E486E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u, 4u, 3u, cpu.address("abs", 0x0448u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486E4 STZ
    hw.write(cpu.address("abs", 0x448u), 0, cpu.m8?8:16);
    goto L_E486E7;
L_E486E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E7u, 4u, 3u, cpu.address("abs", 0x0449u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486E7 STZ
    hw.write(cpu.address("abs", 0x449u), 0, cpu.m8?8:16);
    goto L_E486EA;
L_E486EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EAu, 4u, 3u, cpu.address("abs", 0x044Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486EA STZ
    hw.write(cpu.address("abs", 0x44Au), 0, cpu.m8?8:16);
    goto L_E486ED;
L_E486ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EDu, 4u, 3u, cpu.address("abs", 0x044Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486ED STZ
    hw.write(cpu.address("abs", 0x44Bu), 0, cpu.m8?8:16);
    goto L_E486F0;
L_E486F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F0u, 4u, 3u, cpu.address("abs", 0x044Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486F0 STZ
    hw.write(cpu.address("abs", 0x44Cu), 0, cpu.m8?8:16);
    goto L_E486F3;
L_E486F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u, 4u, 3u, cpu.address("abs", 0x044Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486F3 STZ
    hw.write(cpu.address("abs", 0x44Du), 0, cpu.m8?8:16);
    goto L_E486F6;
L_E486F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F6u, 4u, 3u, cpu.address("abs", 0x044Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486F6 STZ
    hw.write(cpu.address("abs", 0x44Eu), 0, cpu.m8?8:16);
    goto L_E486F9;
L_E486F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486F9 LDA
    cpu.setA(0x3u, 8);
    goto L_E486FB;
L_E486FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486FB STA
    hw.write(cpu.address("dp", 0x8Cu), cpu.a, cpu.m8?8:16);
    goto L_E486FD;
L_E486FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FDu, 4u, 3u, cpu.address("abs", 0x1F11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E486FD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1F11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48700;
L_E48700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8700u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8700u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48700 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x13D9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_E48703;
L_E48703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8703u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8703u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8703u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48703 CPY
    cpu.compareY(0xAu);
    goto L_E48705;
L_E48705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8705u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8705u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48705 BNE -> $E48709
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_E48709; }
    goto L_E48707;
L_E48707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48707 EOR
    cpu.logicXor(0x1u);
    goto L_E48709;
L_E48709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8709u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8709u, 4u, 3u, cpu.address("abs", 0x1F12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48709 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1F12u), cpu.m8?8:16));
    goto L_E4870C;
L_E4870C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4870C BNE -> $E48786
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_E48786; }
    goto L_E4870E;
L_E4870E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4870E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48710;
L_E48710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48710 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_E48712;
L_E48712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48712 STA
    hw.write(cpu.address("dp", 0x8Au), cpu.a, cpu.m8?8:16);
    goto L_E48714;
L_E48714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48714 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48716;
L_E48716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8716u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8716u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48716 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_E48718;
L_E48718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8718u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8718u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48718 STA
    hw.write(cpu.address("dp", 0x8Bu), cpu.a, cpu.m8?8:16);
    goto L_E4871A;
L_E4871A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Au, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4871A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4871D;
L_E4871D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4871D LSR
    cpu.lsrA();
    goto L_E4871E;
L_E4871E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Eu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4871E EOR
    cpu.logicXor(0x2u);
    goto L_E48720;
L_E48720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8720u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8720u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48720 TAY
    cpu.transfer("TAY");
    goto L_E48721;
L_E48721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8721u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8721u, 4u + ((((0x1F13u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48721 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1F13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48724;
L_E48724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48724 CMP
    cpu.compareA(0x12u);
    goto L_E48726;
L_E48726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48726 BEQ -> $E48739
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_E48739; }
    goto L_E48728;
L_E48728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48728 CMP
    cpu.compareA(0x7u);
    goto L_E4872A;
L_E4872A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4872A BCC -> $E48730
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_E48730; }
    goto L_E4872C;
L_E4872C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4872C CMP
    cpu.compareA(0xFu);
    goto L_E4872E;
L_E4872E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4872E BCC -> $E48739
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_E48739; }
    goto L_E48730;
L_E48730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8730u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8730u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48730 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48732;
L_E48732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48732 SEC
    cpu.setFlag('C', true);
    goto L_E48733;
L_E48733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8733u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8733u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48733 SBC
    cpu.sbc(0x5u);
    goto L_E48735;
L_E48735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8735u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8735u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48735 STA
    hw.write(cpu.address("dp", 0x8Bu), cpu.a, cpu.m8?8:16);
    goto L_E48737;
L_E48737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8737u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8737u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48737 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_E48739;
L_E48739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8739u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8739u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48739 REP
    cpu.rep(0x30u);
    goto L_E4873B;
L_E4873B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Bu, 5u, 3u, cpu.address("abs", 0x0DB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4873B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDB2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4873E;
L_E4873E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4873E AND
    cpu.logicAnd(0xFFu);
    goto L_E48741;
L_E48741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8741u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8741u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48741 BEQ -> $E48786
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_E48786; }
    goto L_E48743;
L_E48743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8743u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8743u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48743 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48745;
L_E48745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48745 CMP
    cpu.compareA(0xF0u);
    goto L_E48748;
L_E48748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8748u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8748u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48748 BCS -> $E48786
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_E48786; }
    goto L_E4874A;
L_E4874A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4874A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E4874C;
L_E4874C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4874C CMP
    cpu.compareA(0xF0u);
    goto L_E4874F;
L_E4874F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4874F BCS -> $E48786
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_E48786; }
    goto L_E48751;
L_E48751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8751u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8751u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48751 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48753;
L_E48753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8753u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8753u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8753u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48753 EOR
    cpu.logicXor(0x200u);
    goto L_E48756;
L_E48756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8756u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8756u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48756 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_E48758;
L_E48758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48758 LDX
    cpu.setX(0x20u, 16);
    goto L_E4875B;
L_E4875B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Bu, 6u, 3u, cpu.address("abs", 0x8789u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E4875B JSR -> $E48789 stack real
    { cpu.push16Value(hw,0x875Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x875Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8789u), 0xE4875Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_E4875E;
L_E4875E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x875Eu,0xE4875Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Eu, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4875E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_E48761;
L_E48761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8761u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8761u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48761 LSR
    cpu.lsrA();
    goto L_E48762;
L_E48762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8762u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8762u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48762 EOR
    cpu.logicXor(0x2u);
    goto L_E48765;
L_E48765:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8765u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8765u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8765u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48765 TAY
    cpu.transfer("TAY");
    goto L_E48766;
L_E48766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48766 LDX
    cpu.setX(0x20u, 16);
    goto L_E48769;
L_E48769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8769u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8769u, 6u, 3u, cpu.address("abs", 0x894Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E48769 JSR -> $E4894F stack real
    { cpu.push16Value(hw,0x876Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x876Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x894Fu), 0xE48769u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_E4876C;
L_E4876C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x876Cu,0xE4876Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4876C SEP
    cpu.sep(0x30u);
    goto L_E4876E;
L_E4876E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Eu, 4u, 3u, cpu.address("abs", 0x044Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4876E STZ
    hw.write(cpu.address("abs", 0x44Fu), 0, cpu.m8?8:16);
    goto L_E48771;
L_E48771:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8771u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8771u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8771u, 4u, 3u, cpu.address("abs", 0x0450u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48771 STZ
    hw.write(cpu.address("abs", 0x450u), 0, cpu.m8?8:16);
    goto L_E48774;
L_E48774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u, 4u, 3u, cpu.address("abs", 0x0451u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48774 STZ
    hw.write(cpu.address("abs", 0x451u), 0, cpu.m8?8:16);
    goto L_E48777;
L_E48777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8777u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u, 4u, 3u, cpu.address("abs", 0x0452u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48777 STZ
    hw.write(cpu.address("abs", 0x452u), 0, cpu.m8?8:16);
    goto L_E4877A;
L_E4877A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Au, 4u, 3u, cpu.address("abs", 0x0453u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4877A STZ
    hw.write(cpu.address("abs", 0x453u), 0, cpu.m8?8:16);
    goto L_E4877D;
L_E4877D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Du, 4u, 3u, cpu.address("abs", 0x0454u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E4877D STZ
    hw.write(cpu.address("abs", 0x454u), 0, cpu.m8?8:16);
    goto L_E48780;
L_E48780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8780u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8780u, 4u, 3u, cpu.address("abs", 0x0455u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48780 STZ
    hw.write(cpu.address("abs", 0x455u), 0, cpu.m8?8:16);
    goto L_E48783;
L_E48783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u, 4u, 3u, cpu.address("abs", 0x0456u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48783 STZ
    hw.write(cpu.address("abs", 0x456u), 0, cpu.m8?8:16);
    goto L_E48786;
L_E48786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8786u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8786u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8786u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48786 SEP
    cpu.sep(0x30u);
    goto L_E48788;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8786u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8786u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $E48786 SEP
    cpu.sep(0x30u);
    goto L_E48788;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8786u,0xE48786u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_E48788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $E48788 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xE48788u);return;} hw.unresolvedReturn(0xE48788u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

