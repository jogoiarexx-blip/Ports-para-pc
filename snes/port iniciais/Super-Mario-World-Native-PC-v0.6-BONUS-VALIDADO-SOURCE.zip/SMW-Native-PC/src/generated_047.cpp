#include "generated.hpp"
void sub_008159_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00811Du: goto L_00811D;
    case 0x00811Fu: goto L_00811F;
    case 0x008122u: goto L_008122;
    case 0x008125u: goto L_008125;
    case 0x008127u: goto L_008127;
    case 0x008128u: goto L_008128;
    case 0x00812Au: goto L_00812A;
    case 0x00812Du: goto L_00812D;
    case 0x008130u: goto L_008130;
    case 0x008131u: goto L_008131;
    case 0x008133u: goto L_008133;
    case 0x008159u: goto L_008159;
    case 0x00815Bu: goto L_00815B;
    case 0x00815Eu: goto L_00815E;
    case 0x008160u: goto L_008160;
    case 0x008163u: goto L_008163;
    case 0x008165u: goto L_008165;
    case 0x008168u: goto L_008168;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00811D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00811D LDA
    cpu.setA(0xFFu, 8);
    goto L_00811F;
L_00811F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00811F STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_008122;
L_008122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u, 6u, 3u, cpu.address("abs", 0x80F7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008122 JSR -> $0080F7 stack real
    { cpu.push16Value(hw,0x8124u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8125u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80F7u), 0x008122u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008125;
L_008125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008125 LDX
    cpu.setX(0x9E03u, 16);
    goto L_008128;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008125 LDX
    cpu.setX(0x3u, 8);
    goto L_008127;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8125u,0x008125u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_008127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u, 5u, 3u, cpu.address("absx", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008127 STZ
    hw.write(cpu.address("absx", 0x2140u), 0, cpu.m8?8:16);
    goto L_00812A;
L_008128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8128u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8128u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $008128 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x008128u);return;}
L_00812A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au, 5u, 3u, cpu.address("absx", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00812A STZ
    hw.write(cpu.address("absx", 0x1DF9u), 0, cpu.m8?8:16);
    goto L_00812D;
L_00812D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Du, 5u, 3u, cpu.address("absx", 0x1DFDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00812D STZ
    hw.write(cpu.address("absx", 0x1DFDu), 0, cpu.m8?8:16);
    goto L_008130;
L_008130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008130 DEX
    cpu.decReg('X');
    goto L_008131;
L_008131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8131u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008131 BPL -> $008127
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008127; }
    goto L_008133;
L_008133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8133u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8133u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8133u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008133 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008133u);return;} hw.unresolvedReturn(0x008133u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_008159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8159u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8159u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8159u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008159 LDA
    cpu.setA(0x0u, 8);
    goto L_00815B;
L_00815B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Bu, 4u, 3u, cpu.address("abs", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00815B STA
    hw.write(cpu.address("abs", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00815E;
L_00815E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00815E LDA
    cpu.setA(0xE4u, 8);
    goto L_008160;
L_008160:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8160u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8160u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8160u, 4u, 3u, cpu.address("abs", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008160 STA
    hw.write(cpu.address("abs", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_008163;
L_008163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8163u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8163u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8163u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008163 LDA
    cpu.setA(0x3u, 8);
    goto L_008165;
L_008165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8165u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8165u, 4u, 3u, cpu.address("abs", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008165 STA
    hw.write(cpu.address("abs", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_008168;
L_008168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8168u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8168u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008168 BRA -> $00811D
    goto L_00811D;
}

void sub_0086DF_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0086DFu: goto L_0086DF;
    case 0x0086E1u: goto L_0086E1;
    case 0x0086E2u: goto L_0086E2;
    case 0x0086E4u: goto L_0086E4;
    case 0x0086E6u: goto L_0086E6;
    case 0x0086E9u: goto L_0086E9;
    case 0x0086EAu: goto L_0086EA;
    case 0x0086EBu: goto L_0086EB;
    case 0x0086ECu: goto L_0086EC;
    case 0x0086EEu: goto L_0086EE;
    case 0x0086EFu: goto L_0086EF;
    case 0x0086F1u: goto L_0086F1;
    case 0x0086F3u: goto L_0086F3;
    case 0x0086F5u: goto L_0086F5;
    case 0x0086F7u: goto L_0086F7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0086DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DFu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086DF STY
    hw.write(cpu.address("dp", 0x3u), cpu.y, cpu.x8?8:16);
    goto L_0086E1;
L_0086E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E1u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0086E1 PLY
    cpu.pop("PLY", hw);
    goto L_0086E2;
L_0086E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E2u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086E2 STY
    hw.write(cpu.address("dp", 0x0u), cpu.y, cpu.x8?8:16);
    goto L_0086E4;
L_0086E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086E4 REP
    cpu.rep(0x30u);
    goto L_0086E6;
L_0086E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086E6 AND
    cpu.logicAnd(0xFFu);
    goto L_0086E9;
L_0086E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086E9 ASL
    cpu.aslA();
    goto L_0086EA;
L_0086EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086EA TAY
    cpu.transfer("TAY");
    goto L_0086EB;
L_0086EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EBu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EBu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0086EB PLA
    cpu.pop("PLA", hw);
    goto L_0086EC;
L_0086EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ECu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086EC STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0086EE;
L_0086EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086EE INY
    cpu.inc('Y');
    goto L_0086EF;
L_0086EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EFu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $0086EF LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0086F1;
L_0086F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086F1 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0086F3;
L_0086F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086F3 SEP
    cpu.sep(0x30u);
    goto L_0086F5;
L_0086F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F5u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0086F5 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0086F7;
L_0086F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F7u,cpu,0xDCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F7u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, 0x0000u, 3u, 0u);
    // $0086F7 JMP [0000] -> dispatcher C++ dinamico
    hw.requestDispatch(hw.read24(0x0000u),0x0086F7u); return;
}

void sub_008D80_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008D7Fu: goto L_008D7F;
    case 0x008D80u: goto L_008D80;
    case 0x008D82u: goto L_008D82;
    case 0x008D85u: goto L_008D85;
    case 0x008D86u: goto L_008D86;
    case 0x008D87u: goto L_008D87;
    case 0x008D88u: goto L_008D88;
    case 0x008D8Au: goto L_008D8A;
    case 0x008D8Cu: goto L_008D8C;
    case 0x008D8Fu: goto L_008D8F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008D7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu, 4u + ((((0x8C89u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8C89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D7F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8C89u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008D82;
L_008D80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D80u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D80u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D80 BIT
    cpu.bit(0x8Cu, true);
    goto L_008D82;
L_008D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u, 5u, 3u, cpu.address("absx", 0x0EF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D82 STA
    hw.write(cpu.address("absx", 0xEF9u), cpu.a, cpu.m8?8:16);
    goto L_008D85;
L_008D85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D85 DEY
    cpu.decReg('Y');
    goto L_008D86;
L_008D86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D86u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D86u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D86 DEY
    cpu.decReg('Y');
    goto L_008D87;
L_008D87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D87 DEX
    cpu.decReg('X');
    goto L_008D88;
L_008D88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D88 BPL -> $008D7F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008D7F; }
    goto L_008D8A;
L_008D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D8A LDA
    cpu.setA(0x28u, 8);
    goto L_008D8C;
L_008D8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu, 4u, 3u, cpu.address("abs", 0x0F30u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D8C STA
    hw.write(cpu.address("abs", 0xF30u), cpu.a, cpu.m8?8:16);
    goto L_008D8F;
L_008D8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008D8F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008D8Fu);return;} hw.unresolvedReturn(0x008D8Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00A5F9_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A5F9u: goto L_00A5F9;
    case 0x00A5FBu: goto L_00A5FB;
    case 0x00A5FDu: goto L_00A5FD;
    case 0x00A601u: goto L_00A601;
    case 0x00A604u: goto L_00A604;
    case 0x00A606u: goto L_00A606;
    case 0x00A608u: goto L_00A608;
    case 0x00A60Au: goto L_00A60A;
    case 0x00A60Cu: goto L_00A60C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A5F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5F9 LDA
    cpu.setA(0xE7u, 8);
    goto L_00A5FB;
L_00A5FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FBu,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A5FB TRB
    cpu.trb(hw, cpu.address("dp", 0x14u), cpu.m8?8:16);
    goto L_00A5FD;
L_00A5FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FDu, 8u, 4u, 0x05BB39u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00A5FD JSL -> $05BB39 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA600u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA601u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x05BB39u, 0x00A5FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A601;
L_00A601:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA601u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA601u,0x00A601u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA601u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA601u, 6u, 3u, cpu.address("abs", 0xA390u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A601 JSR -> $00A390 stack real
    { cpu.push16Value(hw,0xA603u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA604u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA390u), 0x00A601u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00A604;
L_00A604:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA604u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA604u,0x00A604u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA604u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA604u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A604 INC
    cpu.incMem(hw, cpu.address("dp", 0x14u), cpu.m8?8:16);
    goto L_00A606;
L_00A606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA606u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA606u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A606 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A608;
L_00A608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA608u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA608u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A608 AND
    cpu.logicAnd(0x7u);
    goto L_00A60A;
L_00A60A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A60A BNE -> $00A5FD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00A5FD; }
    goto L_00A60C;
L_00A60C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00A60C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00A60Cu);return;} hw.unresolvedReturn(0x00A60Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00ADA6_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00ADA6u: goto L_00ADA6;
    case 0x00ADA8u: goto L_00ADA8;
    case 0x00ADABu: goto L_00ADAB;
    case 0x00ADADu: goto L_00ADAD;
    case 0x00ADB0u: goto L_00ADB0;
    case 0x00ADB2u: goto L_00ADB2;
    case 0x00ADB5u: goto L_00ADB5;
    case 0x00ADB7u: goto L_00ADB7;
    case 0x00ADBAu: goto L_00ADBA;
    case 0x00ADBCu: goto L_00ADBC;
    case 0x00ADBFu: goto L_00ADBF;
    case 0x00ADC2u: goto L_00ADC2;
    case 0x00ADC4u: goto L_00ADC4;
    case 0x00ADC7u: goto L_00ADC7;
    case 0x00ADC9u: goto L_00ADC9;
    case 0x00ADCCu: goto L_00ADCC;
    case 0x00ADCEu: goto L_00ADCE;
    case 0x00ADD1u: goto L_00ADD1;
    case 0x00ADD3u: goto L_00ADD3;
    case 0x00ADD6u: goto L_00ADD6;
    case 0x00ADD8u: goto L_00ADD8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00ADA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADA6 REP
    cpu.rep(0x30u);
    goto L_00ADA8;
L_00ADA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADA8 LDA
    cpu.setA(0xB63Cu, 16);
    goto L_00ADAB;
L_00ADAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADABu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADAB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00ADAD;
L_00ADAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADADu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADAD LDA
    cpu.setA(0x10u, 16);
    goto L_00ADB0;
L_00ADB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADB0 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00ADB2;
L_00ADB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADB2 LDA
    cpu.setA(0x7u, 16);
    goto L_00ADB5;
L_00ADB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADB5 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_00ADB7;
L_00ADB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADB7 LDA
    cpu.setA(0x0u, 16);
    goto L_00ADBA;
L_00ADBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADBA STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_00ADBC;
L_00ADBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBCu, 6u, 3u, cpu.address("abs", 0xACFFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ADBC JSR -> $00ACFF stack real
    { cpu.push16Value(hw,0xADBEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADBFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xACFFu), 0x00ADBCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00ADBF;
L_00ADBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADBFu,0x00ADBFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADBF LDA
    cpu.setA(0xB62Cu, 16);
    goto L_00ADC2;
L_00ADC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADC2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00ADC4;
L_00ADC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADC4 LDA
    cpu.setA(0x30u, 16);
    goto L_00ADC7;
L_00ADC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADC7 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00ADC9;
L_00ADC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADC9 LDA
    cpu.setA(0x7u, 16);
    goto L_00ADCC;
L_00ADCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADCC STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_00ADCE;
L_00ADCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADCE LDA
    cpu.setA(0x0u, 16);
    goto L_00ADD1;
L_00ADD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADD1 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_00ADD3;
L_00ADD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD3u, 6u, 3u, cpu.address("abs", 0xACFFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ADD3 JSR -> $00ACFF stack real
    { cpu.push16Value(hw,0xADD5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADD6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xACFFu), 0x00ADD3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00ADD6;
L_00ADD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADD6u,0x00ADD6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADD6 SEP
    cpu.sep(0x30u);
    goto L_00ADD8;
L_00ADD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ADD8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00ADD8u);return;} hw.unresolvedReturn(0x00ADD8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00ADA6_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00ADA6u: goto L_00ADA6;
    case 0x00ADA8u: goto L_00ADA8;
    case 0x00ADABu: goto L_00ADAB;
    case 0x00ADADu: goto L_00ADAD;
    case 0x00ADB0u: goto L_00ADB0;
    case 0x00ADB2u: goto L_00ADB2;
    case 0x00ADB5u: goto L_00ADB5;
    case 0x00ADB7u: goto L_00ADB7;
    case 0x00ADBAu: goto L_00ADBA;
    case 0x00ADBCu: goto L_00ADBC;
    case 0x00ADBFu: goto L_00ADBF;
    case 0x00ADC2u: goto L_00ADC2;
    case 0x00ADC4u: goto L_00ADC4;
    case 0x00ADC7u: goto L_00ADC7;
    case 0x00ADC9u: goto L_00ADC9;
    case 0x00ADCCu: goto L_00ADCC;
    case 0x00ADCEu: goto L_00ADCE;
    case 0x00ADD1u: goto L_00ADD1;
    case 0x00ADD3u: goto L_00ADD3;
    case 0x00ADD6u: goto L_00ADD6;
    case 0x00ADD8u: goto L_00ADD8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00ADA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADA6 REP
    cpu.rep(0x30u);
    goto L_00ADA8;
L_00ADA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADA8 LDA
    cpu.setA(0xB63Cu, 16);
    goto L_00ADAB;
L_00ADAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADABu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADAB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00ADAD;
L_00ADAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADADu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADAD LDA
    cpu.setA(0x10u, 16);
    goto L_00ADB0;
L_00ADB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADB0 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00ADB2;
L_00ADB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADB2 LDA
    cpu.setA(0x7u, 16);
    goto L_00ADB5;
L_00ADB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADB5 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_00ADB7;
L_00ADB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADB7 LDA
    cpu.setA(0x0u, 16);
    goto L_00ADBA;
L_00ADBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADBA STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_00ADBC;
L_00ADBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBCu, 6u, 3u, cpu.address("abs", 0xACFFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ADBC JSR -> $00ACFF stack real
    { cpu.push16Value(hw,0xADBEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADBFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xACFFu), 0x00ADBCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00ADBF;
L_00ADBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADBFu,0x00ADBFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADBF LDA
    cpu.setA(0xB62Cu, 16);
    goto L_00ADC2;
L_00ADC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADC2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00ADC4;
L_00ADC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADC4 LDA
    cpu.setA(0x30u, 16);
    goto L_00ADC7;
L_00ADC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADC7 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00ADC9;
L_00ADC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADC9 LDA
    cpu.setA(0x7u, 16);
    goto L_00ADCC;
L_00ADCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADCC STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_00ADCE;
L_00ADCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADCE LDA
    cpu.setA(0x0u, 16);
    goto L_00ADD1;
L_00ADD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADD1 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_00ADD3;
L_00ADD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD3u, 6u, 3u, cpu.address("abs", 0xACFFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ADD3 JSR -> $00ACFF stack real
    { cpu.push16Value(hw,0xADD5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADD6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xACFFu), 0x00ADD3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00ADD6;
L_00ADD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADD6u,0x00ADD6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ADD6 SEP
    cpu.sep(0x30u);
    goto L_00ADD8;
L_00ADD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ADD8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00ADD8u);return;} hw.unresolvedReturn(0x00ADD8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00B8DE_E1M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00B8DEu: goto L_00B8DE;
    case 0x00B8E0u: goto L_00B8E0;
    case 0x00B8E3u: goto L_00B8E3;
    case 0x00B8E6u: goto L_00B8E6;
    case 0x00B8E8u: goto L_00B8E8;
    case 0x00B8EAu: goto L_00B8EA;
    case 0x00B8ECu: goto L_00B8EC;
    case 0x00B8EDu: goto L_00B8ED;
    case 0x00B8EFu: goto L_00B8EF;
    case 0x00B8F1u: goto L_00B8F1;
    case 0x00B8F3u: goto L_00B8F3;
    case 0x00B8F5u: goto L_00B8F5;
    case 0x00B8F6u: goto L_00B8F6;
    case 0x00B8F8u: goto L_00B8F8;
    case 0x00B8FAu: goto L_00B8FA;
    case 0x00B8FDu: goto L_00B8FD;
    case 0x00B8FFu: goto L_00B8FF;
    case 0x00B901u: goto L_00B901;
    case 0x00B902u: goto L_00B902;
    case 0x00B903u: goto L_00B903;
    case 0x00B904u: goto L_00B904;
    case 0x00B906u: goto L_00B906;
    case 0x00B907u: goto L_00B907;
    case 0x00B909u: goto L_00B909;
    case 0x00B90Bu: goto L_00B90B;
    case 0x00B90Cu: goto L_00B90C;
    case 0x00B90Fu: goto L_00B90F;
    case 0x00B911u: goto L_00B911;
    case 0x00B912u: goto L_00B912;
    case 0x00B914u: goto L_00B914;
    case 0x00B916u: goto L_00B916;
    case 0x00B917u: goto L_00B917;
    case 0x00B919u: goto L_00B919;
    case 0x00B91Bu: goto L_00B91B;
    case 0x00B91Cu: goto L_00B91C;
    case 0x00B91Eu: goto L_00B91E;
    case 0x00B91Fu: goto L_00B91F;
    case 0x00B921u: goto L_00B921;
    case 0x00B924u: goto L_00B924;
    case 0x00B926u: goto L_00B926;
    case 0x00B928u: goto L_00B928;
    case 0x00B929u: goto L_00B929;
    case 0x00B92Au: goto L_00B92A;
    case 0x00B92Bu: goto L_00B92B;
    case 0x00B92Du: goto L_00B92D;
    case 0x00B930u: goto L_00B930;
    case 0x00B933u: goto L_00B933;
    case 0x00B935u: goto L_00B935;
    case 0x00B936u: goto L_00B936;
    case 0x00B938u: goto L_00B938;
    case 0x00B939u: goto L_00B939;
    case 0x00B93Bu: goto L_00B93B;
    case 0x00B93Du: goto L_00B93D;
    case 0x00B93Fu: goto L_00B93F;
    case 0x00B942u: goto L_00B942;
    case 0x00B944u: goto L_00B944;
    case 0x00B946u: goto L_00B946;
    case 0x00B947u: goto L_00B947;
    case 0x00B948u: goto L_00B948;
    case 0x00B94Au: goto L_00B94A;
    case 0x00B94Cu: goto L_00B94C;
    case 0x00B94Fu: goto L_00B94F;
    case 0x00B950u: goto L_00B950;
    case 0x00B953u: goto L_00B953;
    case 0x00B955u: goto L_00B955;
    case 0x00B956u: goto L_00B956;
    case 0x00B958u: goto L_00B958;
    case 0x00B959u: goto L_00B959;
    case 0x00B95Au: goto L_00B95A;
    case 0x00B95Cu: goto L_00B95C;
    case 0x00B95Du: goto L_00B95D;
    case 0x00B95Fu: goto L_00B95F;
    case 0x00B960u: goto L_00B960;
    case 0x00B961u: goto L_00B961;
    case 0x00B963u: goto L_00B963;
    case 0x00B966u: goto L_00B966;
    case 0x00B969u: goto L_00B969;
    case 0x00B96Au: goto L_00B96A;
    case 0x00B96Du: goto L_00B96D;
    case 0x00B96Eu: goto L_00B96E;
    case 0x00B96Fu: goto L_00B96F;
    case 0x00B970u: goto L_00B970;
    case 0x00B972u: goto L_00B972;
    case 0x00B973u: goto L_00B973;
    case 0x00B974u: goto L_00B974;
    case 0x00B976u: goto L_00B976;
    case 0x00B977u: goto L_00B977;
    case 0x00B978u: goto L_00B978;
    case 0x00B97Au: goto L_00B97A;
    case 0x00B97Cu: goto L_00B97C;
    case 0x00B97Eu: goto L_00B97E;
    case 0x00B980u: goto L_00B980;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00B8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8DE REP
    cpu.rep(0x10u);
    goto L_00B8E0;
L_00B8E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8E0 LDY
    cpu.setY(0x0u, 16);
    goto L_00B8E3;
L_00B8E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E3u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B8E3 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB8E5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB8E6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B8E3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B8E6;
L_00B8E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E6u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB8E6u,0x00B8E6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8E6 CMP
    cpu.compareA(0xFFu);
    goto L_00B8E8;
L_00B8E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8E8 BNE -> $00B8ED
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B8ED; }
    goto L_00B8EA;
L_00B8EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8EA SEP
    cpu.sep(0x10u);
    goto L_00B8EC;
L_00B8EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ECu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ECu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B8EC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00B8ECu);return;} hw.unresolvedReturn(0x00B8ECu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00B8ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8ED STA
    hw.write(cpu.address("dp", 0x8Fu), cpu.a, cpu.m8?8:16);
    goto L_00B8EF;
L_00B8EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8EF AND
    cpu.logicAnd(0xE0u);
    goto L_00B8F1;
L_00B8F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8F1 CMP
    cpu.compareA(0xE0u);
    goto L_00B8F3;
L_00B8F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8F3 BEQ -> $00B8FF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B8FF; }
    goto L_00B8F5;
L_00B8F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F5u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F5u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B8F5 PHA
    cpu.push("PHA", hw);
    goto L_00B8F6;
L_00B8F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8F6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B8F8;
L_00B8F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8F8 REP
    cpu.rep(0x20u);
    goto L_00B8FA;
L_00B8FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8FA AND
    cpu.logicAnd(0x1Fu);
    goto L_00B8FD;
L_00B8FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8FD BRA -> $00B911
    hw.addCpuInternalCycles(1u); // penalidade de page-cross em emulacao
    goto L_00B911;
L_00B8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B8FF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B901;
L_00B901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B901 ASL
    cpu.aslA();
    goto L_00B902;
L_00B902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB902u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB902u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B902 ASL
    cpu.aslA();
    goto L_00B903;
L_00B903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB903u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB903u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B903 ASL
    cpu.aslA();
    goto L_00B904;
L_00B904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB904u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB904u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B904 AND
    cpu.logicAnd(0xE0u);
    goto L_00B906;
L_00B906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB906u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB906u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B906 PHA
    cpu.push("PHA", hw);
    goto L_00B907;
L_00B907:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB907u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB907u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB907u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B907 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B909;
L_00B909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB909u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB909u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B909 AND
    cpu.logicAnd(0x3u);
    goto L_00B90B;
L_00B90B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B90B XBA
    cpu.xba();
    goto L_00B90C;
L_00B90C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Cu, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B90C JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB90Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB90Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B90Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B90F;
L_00B90F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Fu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB90Fu,0x00B90Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B90F REP
    cpu.rep(0x20u);
    goto L_00B911;
L_00B911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB911u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB911u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B911 INC
    cpu.inc('A');
    goto L_00B912;
L_00B912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB912u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB912u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B912 STA
    hw.write(cpu.address("dp", 0x8Du), cpu.a, cpu.m8?8:16);
    goto L_00B914;
L_00B914:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB914u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB914u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB914u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B914 SEP
    cpu.sep(0x20u);
    goto L_00B916;
L_00B916:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB916u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB916u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB916u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00B916 PLA
    cpu.pop("PLA", hw);
    goto L_00B917;
L_00B917:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB917u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB917u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB917u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B917 BEQ -> $00B930
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B930; }
    goto L_00B919;
L_00B919:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB919u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB919u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB919u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B919 BMI -> $00B966
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00B966; }
    goto L_00B91B;
L_00B91B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B91B ASL
    cpu.aslA();
    goto L_00B91C;
L_00B91C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B91C BPL -> $00B93F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00B93F; }
    goto L_00B91E;
L_00B91E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B91E ASL
    cpu.aslA();
    goto L_00B91F;
L_00B91F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B91F BPL -> $00B94C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00B94C; }
    goto L_00B921;
L_00B921:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB921u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB921u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB921u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B921 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB923u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB924u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B921u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B924;
L_00B924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB924u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB924u,0x00B924u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B924 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B926;
L_00B926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB926u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB926u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B926 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B928;
L_00B928:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB928u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB928u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB928u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B928 INC
    cpu.inc('A');
    goto L_00B929;
L_00B929:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB929u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB929u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB929u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B929 INY
    cpu.inc('Y');
    goto L_00B92A;
L_00B92A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Au,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B92A DEX
    cpu.decReg('X');
    goto L_00B92B;
L_00B92B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B92B BNE -> $00B926
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B926; }
    goto L_00B92D;
L_00B92D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Du, 3u, 3u, cpu.address("abs", 0xB8E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B92D JMP -> $00B8E3
    goto L_00B8E3;
L_00B930:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB930u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB930u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB930u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B930 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB932u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB933u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B930u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B933;
L_00B933:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB933u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB933u,0x00B933u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB933u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB933u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B933 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B935;
L_00B935:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB935u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB935u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB935u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B935 INY
    cpu.inc('Y');
    goto L_00B936;
L_00B936:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB936u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB936u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB936u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B936 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B938;
L_00B938:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB938u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB938u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB938u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B938 DEX
    cpu.decReg('X');
    goto L_00B939;
L_00B939:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB939u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB939u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB939u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B939 STX
    hw.write(cpu.address("dp", 0x8Du), cpu.x, cpu.x8?8:16);
    goto L_00B93B;
L_00B93B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B93B BNE -> $00B930
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B930; }
    goto L_00B93D;
L_00B93D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B93D BRA -> $00B8E3
    hw.addCpuInternalCycles(1u); // penalidade de page-cross em emulacao
    goto L_00B8E3;
L_00B93F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Fu, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B93F JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB941u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB942u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B93Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B942;
L_00B942:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB942u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB942u,0x00B942u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB942u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB942u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B942 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B944;
L_00B944:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB944u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB944u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB944u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B944 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B946;
L_00B946:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB946u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB946u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB946u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B946 INY
    cpu.inc('Y');
    goto L_00B947;
L_00B947:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB947u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB947u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB947u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B947 DEX
    cpu.decReg('X');
    goto L_00B948;
L_00B948:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB948u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB948u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB948u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B948 BNE -> $00B944
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B944; }
    goto L_00B94A;
L_00B94A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B94A BRA -> $00B8E3
    hw.addCpuInternalCycles(1u); // penalidade de page-cross em emulacao
    goto L_00B8E3;
L_00B94C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Cu, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B94C JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB94Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB94Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B94Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B94F;
L_00B94F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Fu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB94Fu,0x00B94Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Fu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B94F XBA
    cpu.xba();
    goto L_00B950;
L_00B950:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB950u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB950u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB950u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B950 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB952u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB953u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B950u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B953;
L_00B953:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB953u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB953u,0x00B953u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB953u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB953u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B953 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Du), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00B955;
L_00B955:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB955u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB955u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB955u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B955 XBA
    cpu.xba();
    goto L_00B956;
L_00B956:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB956u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB956u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB956u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B956 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B958;
L_00B958:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB958u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB958u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB958u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B958 INY
    cpu.inc('Y');
    goto L_00B959;
L_00B959:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB959u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB959u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB959u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B959 DEX
    cpu.decReg('X');
    goto L_00B95A;
L_00B95A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B95A BEQ -> $00B963
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B963; }
    goto L_00B95C;
L_00B95C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B95C XBA
    cpu.xba();
    goto L_00B95D;
L_00B95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Du,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B95D STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B95F;
L_00B95F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B95F INY
    cpu.inc('Y');
    goto L_00B960;
L_00B960:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB960u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB960u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB960u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B960 DEX
    cpu.decReg('X');
    goto L_00B961;
L_00B961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB961u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B961 BNE -> $00B955
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B955; }
    goto L_00B963;
L_00B963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB963u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB963u, 3u, 3u, cpu.address("abs", 0xB8E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B963 JMP -> $00B8E3
    goto L_00B8E3;
L_00B966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB966u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB966u, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B966 JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB968u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB969u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B966u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B969;
L_00B969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB969u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB969u,0x00B969u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB969u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB969u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B969 XBA
    cpu.xba();
    goto L_00B96A;
L_00B96A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Au, 6u, 3u, cpu.address("abs", 0xB983u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B96A JSR -> $00B983 stack real
    { cpu.push16Value(hw,0xB96Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB96Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB983u), 0x00B96Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00B96D;
L_00B96D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Du))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB96Du,0x00B96Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B96D TAX
    cpu.transfer("TAX");
    goto L_00B96E;
L_00B96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B96E PHY
    cpu.push("PHY", hw);
    goto L_00B96F;
L_00B96F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Fu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B96F TXY
    cpu.transfer("TXY");
    goto L_00B970;
L_00B970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB970u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB970u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B970 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00B972;
L_00B972:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB972u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB972u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB972u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B972 TYX
    cpu.transfer("TYX");
    goto L_00B973;
L_00B973:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB973u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB973u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB973u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00B973 PLY
    cpu.pop("PLY", hw);
    goto L_00B974;
L_00B974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB974u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB974u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $00B974 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_00B976;
L_00B976:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB976u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB976u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB976u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B976 INY
    cpu.inc('Y');
    goto L_00B977;
L_00B977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB977u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB977u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B977 INX
    cpu.inc('X');
    goto L_00B978;
L_00B978:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB978u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB978u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB978u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B978 REP
    cpu.rep(0x20u);
    goto L_00B97A;
L_00B97A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Au,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B97A DEC
    cpu.decMem(hw, cpu.address("dp", 0x8Du), cpu.m8?8:16);
    goto L_00B97C;
L_00B97C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B97C SEP
    cpu.sep(0x20u);
    goto L_00B97E;
L_00B97E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B97E BNE -> $00B96E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00B96E; }
    goto L_00B980;
L_00B980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB980u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB980u, 3u, 3u, cpu.address("abs", 0xB8E3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00B980 JMP -> $00B8E3
    goto L_00B8E3;
}

void sub_00D96A_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00D96Au: goto L_00D96A;
    case 0x00D96Du: goto L_00D96D;
    case 0x00D96Eu: goto L_00D96E;
    case 0x00D971u: goto L_00D971;
    case 0x00D973u: goto L_00D973;
    case 0x00D975u: goto L_00D975;
    case 0x00D977u: goto L_00D977;
    case 0x00D979u: goto L_00D979;
    case 0x00D97Au: goto L_00D97A;
    case 0x00D97Cu: goto L_00D97C;
    case 0x00D97Fu: goto L_00D97F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00D96A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD96Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD96Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD96Au, 4u, 3u, cpu.address("abs", 0x13E4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D96A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13E4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D96D;
L_00D96D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD96Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD96Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD96Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D96D CLC
    cpu.setFlag('C', false);
    goto L_00D96E;
L_00D96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD96Eu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD96Eu, 4u + ((((0xD5EBu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD5EBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D96E ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD5EBu), cpu.m8?8:16));
    goto L_00D971;
L_00D971:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD971u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD971u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD971u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D971 BPL -> $00D975
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00D975; }
    goto L_00D973;
L_00D973:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD973u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD973u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD973u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D973 LDA
    cpu.setA(0x0u, 8);
    goto L_00D975;
L_00D975:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD975u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD975u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD975u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D975 CMP
    cpu.compareA(0x70u);
    goto L_00D977;
L_00D977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD977u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD977u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D977 BCC -> $00D97C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00D97C; }
    goto L_00D979;
L_00D979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD979u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD979u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D979 INY
    cpu.inc('Y');
    goto L_00D97A;
L_00D97A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD97Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD97Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD97Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D97A LDA
    cpu.setA(0x70u, 8);
    goto L_00D97C;
L_00D97C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD97Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD97Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD97Cu, 4u, 3u, cpu.address("abs", 0x13E4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D97C STA
    hw.write(cpu.address("abs", 0x13E4u), cpu.a, cpu.m8?8:16);
    goto L_00D97F;
L_00D97F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD97Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD97Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD97Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00D97F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00D97Fu);return;} hw.unresolvedReturn(0x00D97Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00EADB_E0M1X1CQ_part26(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF43u: goto L_00EF43;
    case 0x00EF45u: goto L_00EF45;
    case 0x00EF48u: goto L_00EF48;
    case 0x00EF4Bu: goto L_00EF4B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF43u))return;
  // 42 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF43u,0x00EF43u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF45u))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u, 5u, 3u, cpu.address("abs", 0x17BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF45 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF48;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u, 5u, 3u, cpu.address("abs", 0x17BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF45 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF48;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u, 5u, 3u, cpu.address("abs", 0x17BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF45 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF48;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF45u,0x00EF45u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF48u))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF48 AND
    cpu.logicAnd(0xFF00u);
    goto L_00EF4B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF48 AND
    cpu.logicAnd(0xFF00u);
    goto L_00EF4B;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF48 AND
    cpu.logicAnd(0xFF00u);
    goto L_00EF4B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF48u,0x00EF48u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF4Bu))return;
  // 38 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF4B BPL -> $00EF50
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF50u,0x00EF4Bu); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF4Du,0x00EF4Bu); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF4B BPL -> $00EF50
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF50u,0x00EF4Bu); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF4Du,0x00EF4Bu); return;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF4B BPL -> $00EF50
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EF50u,0x00EF4Bu); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF4Du,0x00EF4Bu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF4Bu,0x00EF4Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00FC7A_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00FC7Au: goto L_00FC7A;
    case 0x00FC7Cu: goto L_00FC7C;
    case 0x00FC7Fu: goto L_00FC7F;
    case 0x00FC81u: goto L_00FC81;
    case 0x00FC84u: goto L_00FC84;
    case 0x00FC86u: goto L_00FC86;
    case 0x00FC88u: goto L_00FC88;
    case 0x00FC8Bu: goto L_00FC8B;
    case 0x00FC8Du: goto L_00FC8D;
    case 0x00FC8Fu: goto L_00FC8F;
    case 0x00FC93u: goto L_00FC93;
    case 0x00FC94u: goto L_00FC94;
    case 0x00FC96u: goto L_00FC96;
    case 0x00FC98u: goto L_00FC98;
    case 0x00FC9Au: goto L_00FC9A;
    case 0x00FC9Du: goto L_00FC9D;
    case 0x00FC9Fu: goto L_00FC9F;
    case 0x00FCA1u: goto L_00FCA1;
    case 0x00FCA3u: goto L_00FCA3;
    case 0x00FCA5u: goto L_00FCA5;
    case 0x00FCA7u: goto L_00FCA7;
    case 0x00FCAAu: goto L_00FCAA;
    case 0x00FCACu: goto L_00FCAC;
    case 0x00FCADu: goto L_00FCAD;
    case 0x00FCAFu: goto L_00FCAF;
    case 0x00FCB1u: goto L_00FCB1;
    case 0x00FCB3u: goto L_00FCB3;
    case 0x00FCB5u: goto L_00FCB5;
    case 0x00FCB7u: goto L_00FCB7;
    case 0x00FCB9u: goto L_00FCB9;
    case 0x00FCBCu: goto L_00FCBC;
    case 0x00FCC0u: goto L_00FCC0;
    case 0x00FCC2u: goto L_00FCC2;
    case 0x00FCC5u: goto L_00FCC5;
    case 0x00FCC8u: goto L_00FCC8;
    case 0x00FCCBu: goto L_00FCCB;
    case 0x00FCCEu: goto L_00FCCE;
    case 0x00FCD0u: goto L_00FCD0;
    case 0x00FCD2u: goto L_00FCD2;
    case 0x00FCD5u: goto L_00FCD5;
    case 0x00FCD8u: goto L_00FCD8;
    case 0x00FCDAu: goto L_00FCDA;
    case 0x00FCDCu: goto L_00FCDC;
    case 0x00FCDEu: goto L_00FCDE;
    case 0x00FCE1u: goto L_00FCE1;
    case 0x00FCE4u: goto L_00FCE4;
    case 0x00FCE5u: goto L_00FCE5;
    case 0x00FCE8u: goto L_00FCE8;
    case 0x00FCEBu: goto L_00FCEB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00FC7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC7Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC7A LDA
    cpu.setA(0x2u, 8);
    goto L_00FC7C;
L_00FC7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC7Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC7Cu, 4u, 3u, cpu.address("abs", 0x1DFAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC7C STA
    hw.write(cpu.address("abs", 0x1DFAu), cpu.a, cpu.m8?8:16);
    goto L_00FC7F;
L_00FC7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC7Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC7F LDX
    cpu.setX(0x0u, 8);
    goto L_00FC81;
L_00FC81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC81u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC81u, 4u, 3u, cpu.address("abs", 0x1B94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC81 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FC84;
L_00FC84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC84u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC84 BNE -> $00FC98
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FC98; }
    goto L_00FC86;
L_00FC86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC86u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC86u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC86 LDX
    cpu.setX(0x5u, 8);
    goto L_00FC88;
L_00FC88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC88u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC88u, 4u, 3u, cpu.address("abs", 0x1692u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC88 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1692u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FC8B;
L_00FC8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC8Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC8Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC8B CMP
    cpu.compareA(0xAu);
    goto L_00FC8D;
L_00FC8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC8Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC8D BEQ -> $00FC98
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FC98; }
    goto L_00FC8F;
L_00FC8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC8Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC8Fu, 8u, 4u, 0x02A9E4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00FC8F JSL -> $02A9E4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xFC92u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFC93u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02A9E4u, 0x00FC8Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00FC93;
L_00FC93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC93u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFC93u,0x00FC93u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC93u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC93u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC93 TYX
    cpu.transfer("TYX");
    goto L_00FC94;
L_00FC94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC94u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC94 BPL -> $00FC98
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00FC98; }
    goto L_00FC96;
L_00FC96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC96u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC96 LDX
    cpu.setX(0x3u, 8);
    goto L_00FC98;
L_00FC98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC98u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC98 LDA
    cpu.setA(0x8u, 8);
    goto L_00FC9A;
L_00FC9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC9Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC9Au, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC9A STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_00FC9D;
L_00FC9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC9Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC9D LDA
    cpu.setA(0x35u, 8);
    goto L_00FC9F;
L_00FC9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC9Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC9Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC9F STA
    hw.write(cpu.address("dpx", 0x9Eu), cpu.a, cpu.m8?8:16);
    goto L_00FCA1;
L_00FCA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCA1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FCA3;
L_00FCA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA3u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCA3 STA
    hw.write(cpu.address("dpx", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_00FCA5;
L_00FCA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCA5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FCA7;
L_00FCA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA7u, 5u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCA7 STA
    hw.write(cpu.address("absx", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_00FCAA;
L_00FCAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCAAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCAAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCAA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FCAC;
L_00FCAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCACu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCAC SEC
    cpu.setFlag('C', true);
    goto L_00FCAD;
L_00FCAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCADu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCAD SBC
    cpu.sbc(0x10u);
    goto L_00FCAF;
L_00FCAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCAFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCAFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCAF STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00FCB1;
L_00FCB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB1u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCB1 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_00FCB3;
L_00FCB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCB3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FCB5;
L_00FCB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB5u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCB5 SBC
    cpu.sbc(0x0u);
    goto L_00FCB7;
L_00FCB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCB7 STA
    hw.write(cpu.address("dp", 0x97u), cpu.a, cpu.m8?8:16);
    goto L_00FCB9;
L_00FCB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB9u, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCB9 STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_00FCBC;
L_00FCBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCBCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCBCu, 8u, 4u, 0x07F7D2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00FCBC JSL -> $07F7D2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xFCBFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFCC0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F7D2u, 0x00FCBCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00FCC0;
L_00FCC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCC0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFCC0u,0x00FCC0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCC0 LDA
    cpu.setA(0x4u, 8);
    goto L_00FCC2;
L_00FCC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC2u, 5u, 3u, cpu.address("absx", 0x1FE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCC2 STA
    hw.write(cpu.address("absx", 0x1FE2u), cpu.a, cpu.m8?8:16);
    goto L_00FCC5;
L_00FCC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC5u, 4u, 3u, cpu.address("abs", 0x13C7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCC5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FCC8;
L_00FCC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC8u, 5u, 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCC8 STA
    hw.write(cpu.address("absx", 0x15F6u), cpu.a, cpu.m8?8:16);
    goto L_00FCCB;
L_00FCCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCCBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCCBu, 4u, 3u, cpu.address("abs", 0x1B95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCCB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FCCE;
L_00FCCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCCEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCCE BEQ -> $00FCD5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FCD5; }
    goto L_00FCD0;
L_00FCD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCD0 LDA
    cpu.setA(0x6u, 8);
    goto L_00FCD2;
L_00FCD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD2u, 5u, 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCD2 STA
    hw.write(cpu.address("absx", 0x15F6u), cpu.a, cpu.m8?8:16);
    goto L_00FCD5;
L_00FCD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD5u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD5u, 6u, 3u, cpu.address("abs", 0x187Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCD5 INC
    cpu.incMem(hw, cpu.address("abs", 0x187Au), cpu.m8?8:16);
    goto L_00FCD8;
L_00FCD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD8u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCD8 INC
    cpu.incMem(hw, cpu.address("dpx", 0xC2u), cpu.m8?8:16);
    goto L_00FCDA;
L_00FCDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCDAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCDAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCDA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FCDC;
L_00FCDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCDCu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCDC EOR
    cpu.logicXor(0x1u);
    goto L_00FCDE;
L_00FCDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCDEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCDEu, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCDE STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_00FCE1;
L_00FCE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE1u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE1u, 7u, 3u, cpu.address("absx", 0x160Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCE1 DEC
    cpu.decMem(hw, cpu.address("absx", 0x160Eu), cpu.m8?8:16);
    goto L_00FCE4;
L_00FCE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCE4 INX
    cpu.inc('X');
    goto L_00FCE5;
L_00FCE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE5u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE5u, 4u, 3u, cpu.address("abs", 0x18DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCE5 STX
    hw.write(cpu.address("abs", 0x18DFu), cpu.x, cpu.x8?8:16);
    goto L_00FCE8;
L_00FCE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE8u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE8u, 4u, 3u, cpu.address("abs", 0x18E2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCE8 STX
    hw.write(cpu.address("abs", 0x18E2u), cpu.x, cpu.x8?8:16);
    goto L_00FCEB;
L_00FCEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCEBu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCEBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00FCEB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x00FCEBu);return;} hw.unresolvedReturn(0x00FCEBu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_00FDA5_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00FDA5u: goto L_00FDA5;
    case 0x00FDA7u: goto L_00FDA7;
    case 0x00FDA9u: goto L_00FDA9;
    case 0x00FDABu: goto L_00FDAB;
    case 0x00FDAEu: goto L_00FDAE;
    case 0x00FDB0u: goto L_00FDB0;
    case 0x00FDB1u: goto L_00FDB1;
    case 0x00FDB3u: goto L_00FDB3;
    case 0x00FDB4u: goto L_00FDB4;
    case 0x00FDB5u: goto L_00FDB5;
    case 0x00FDB7u: goto L_00FDB7;
    case 0x00FDB9u: goto L_00FDB9;
    case 0x00FDBBu: goto L_00FDBB;
    case 0x00FDBCu: goto L_00FDBC;
    case 0x00FDBFu: goto L_00FDBF;
    case 0x00FDC1u: goto L_00FDC1;
    case 0x00FDC2u: goto L_00FDC2;
    case 0x00FDC3u: goto L_00FDC3;
    case 0x00FDC5u: goto L_00FDC5;
    case 0x00FDC6u: goto L_00FDC6;
    case 0x00FDC9u: goto L_00FDC9;
    case 0x00FDCAu: goto L_00FDCA;
    case 0x00FDCCu: goto L_00FDCC;
    case 0x00FDCDu: goto L_00FDCD;
    case 0x00FDCFu: goto L_00FDCF;
    case 0x00FDD2u: goto L_00FDD2;
    case 0x00FDD4u: goto L_00FDD4;
    case 0x00FDD6u: goto L_00FDD6;
    case 0x00FDD7u: goto L_00FDD7;
    case 0x00FDDAu: goto L_00FDDA;
    case 0x00FDDDu: goto L_00FDDD;
    case 0x00FDDEu: goto L_00FDDE;
    case 0x00FDE0u: goto L_00FDE0;
    case 0x00FDE3u: goto L_00FDE3;
    case 0x00FDE5u: goto L_00FDE5;
    case 0x00FDE8u: goto L_00FDE8;
    case 0x00FDEAu: goto L_00FDEA;
    case 0x00FDEDu: goto L_00FDED;
    case 0x00FDEFu: goto L_00FDEF;
    case 0x00FDF2u: goto L_00FDF2;
    case 0x00FDF4u: goto L_00FDF4;
    case 0x00FDF6u: goto L_00FDF6;
    case 0x00FDF8u: goto L_00FDF8;
    case 0x00FDFAu: goto L_00FDFA;
    case 0x00FDFCu: goto L_00FDFC;
    case 0x00FDFEu: goto L_00FDFE;
    case 0x00FE00u: goto L_00FE00;
    case 0x00FE02u: goto L_00FE02;
    case 0x00FE04u: goto L_00FE04;
    case 0x00FE05u: goto L_00FE05;
    case 0x00FE08u: goto L_00FE08;
    case 0x00FE0Au: goto L_00FE0A;
    case 0x00FE0Bu: goto L_00FE0B;
    case 0x00FE0Du: goto L_00FE0D;
    case 0x00FE16u: goto L_00FE16;
    case 0x00FE18u: goto L_00FE18;
    case 0x00FE1Bu: goto L_00FE1B;
    case 0x00FE1Cu: goto L_00FE1C;
    case 0x00FE1Du: goto L_00FE1D;
    case 0x00FE1Eu: goto L_00FE1E;
    case 0x00FE1Fu: goto L_00FE1F;
    case 0x00FE21u: goto L_00FE21;
    case 0x00FE24u: goto L_00FE24;
    case 0x00FE26u: goto L_00FE26;
    case 0x00FE29u: goto L_00FE29;
    case 0x00FE2Cu: goto L_00FE2C;
    case 0x00FE2Eu: goto L_00FE2E;
    case 0x00FE30u: goto L_00FE30;
    case 0x00FE33u: goto L_00FE33;
    case 0x00FE35u: goto L_00FE35;
    case 0x00FE38u: goto L_00FE38;
    case 0x00FE3Bu: goto L_00FE3B;
    case 0x00FE3Du: goto L_00FE3D;
    case 0x00FE3Fu: goto L_00FE3F;
    case 0x00FE42u: goto L_00FE42;
    case 0x00FE44u: goto L_00FE44;
    case 0x00FE47u: goto L_00FE47;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00FDA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDA5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDA5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDA5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FDA7;
L_00FDA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDA7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDA7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDA7 BEQ -> $00FDB3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FDB3; }
    goto L_00FDA9;
L_00FDA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDA9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDA9 LDY
    cpu.setY(0xBu, 8);
    goto L_00FDAB;
L_00FDAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDABu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDABu, 4u + ((((0x17F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x17F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDAB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x17F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FDAE;
L_00FDAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDAEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDAEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDAE BEQ -> $00FDB4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FDB4; }
    goto L_00FDB0;
L_00FDB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB0u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDB0 DEY
    cpu.decReg('Y');
    goto L_00FDB1;
L_00FDB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDB1 BPL -> $00FDAB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00FDAB; }
    goto L_00FDB3;
L_00FDB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDB3 INY
    cpu.inc('Y');
    goto L_00FDB4;
L_00FDB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB4u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00FDB4 PHX
    cpu.push("PHX", hw);
    goto L_00FDB5;
L_00FDB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDB5 LDX
    cpu.setX(0x0u, 8);
    goto L_00FDB7;
L_00FDB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDB7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FDB9;
L_00FDB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDB9 BEQ -> $00FDBC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FDBC; }
    goto L_00FDBB;
L_00FDBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDBBu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDBBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDBB INX
    cpu.inc('X');
    goto L_00FDBC;
L_00FDBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDBCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDBCu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDBC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FDBF;
L_00FDBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDBFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDBFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDBF BEQ -> $00FDC3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FDC3; }
    goto L_00FDC1;
L_00FDC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDC1 INX
    cpu.inc('X');
    goto L_00FDC2;
L_00FDC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDC2 INX
    cpu.inc('X');
    goto L_00FDC3;
L_00FDC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDC3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FDC5;
L_00FDC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDC5 CLC
    cpu.setFlag('C', false);
    goto L_00FDC6;
L_00FDC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC6u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC6u, 4u + ((((0xFD9Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xFD9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDC6 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xFD9Du), cpu.m8?8:16));
    goto L_00FDC9;
L_00FDC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC9u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00FDC9 PHP
    cpu.push("PHP", hw);
    goto L_00FDCA;
L_00FDCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDCAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDCAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDCA AND
    cpu.logicAnd(0xF0u);
    goto L_00FDCC;
L_00FDCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDCCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDCCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDCC CLC
    cpu.setFlag('C', false);
    goto L_00FDCD;
L_00FDCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDCDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDCDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDCD ADC
    cpu.adc(0x3u);
    goto L_00FDCF;
L_00FDCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDCFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDCFu, 5u, 3u, cpu.address("absy", 0x17FCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDCF STA
    hw.write(cpu.address("absy", 0x17FCu), cpu.a, cpu.m8?8:16);
    goto L_00FDD2;
L_00FDD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDD2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDD2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDD2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FDD4;
L_00FDD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDD4u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDD4 ADC
    cpu.adc(0x0u);
    goto L_00FDD6;
L_00FDD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDD6u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDD6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00FDD6 PLP
    cpu.pop("PLP", hw);
    goto L_00FDD7;
L_00FDD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDD7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFDD7u,0x00FDD7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDD7u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDD7u, 4u + ((((0xFDA1u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xFDA1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDD7 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xFDA1u), cpu.m8?8:16));
    goto L_00FDDA;
L_00FDDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDDAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDDAu, 5u, 3u, cpu.address("absy", 0x1814u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDDA STA
    hw.write(cpu.address("absy", 0x1814u), cpu.a, cpu.m8?8:16);
    goto L_00FDDD;
L_00FDDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDDDu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDDDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00FDDD PLX
    cpu.pop("PLX", hw);
    goto L_00FDDE;
L_00FDDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDDEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDDEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDDE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FDE0;
L_00FDE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDE0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDE0u, 5u, 3u, cpu.address("absy", 0x1808u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDE0 STA
    hw.write(cpu.address("absy", 0x1808u), cpu.a, cpu.m8?8:16);
    goto L_00FDE3;
L_00FDE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDE3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDE3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDE3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FDE5;
L_00FDE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDE5u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDE5u, 5u, 3u, cpu.address("absy", 0x18EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDE5 STA
    hw.write(cpu.address("absy", 0x18EAu), cpu.a, cpu.m8?8:16);
    goto L_00FDE8;
L_00FDE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDE8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDE8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDE8 LDA
    cpu.setA(0x7u, 8);
    goto L_00FDEA;
L_00FDEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDEAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDEAu, 5u, 3u, cpu.address("absy", 0x17F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDEA STA
    hw.write(cpu.address("absy", 0x17F0u), cpu.a, cpu.m8?8:16);
    goto L_00FDED;
L_00FDED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDEDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDED LDA
    cpu.setA(0x0u, 8);
    goto L_00FDEF;
L_00FDEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDEFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDEFu, 5u, 3u, cpu.address("absy", 0x1850u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDEF STA
    hw.write(cpu.address("absy", 0x1850u), cpu.a, cpu.m8?8:16);
    goto L_00FDF2;
L_00FDF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDF2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDF2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDF2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FDF4;
L_00FDF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDF4u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDF4 BMI -> $00FE0D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00FE0D; }
    goto L_00FDF6;
L_00FDF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDF6u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDF6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDF6 STZ
    hw.write(cpu.address("dp", 0x7Du), 0, cpu.m8?8:16);
    goto L_00FDF8;
L_00FDF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDF8u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDF8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDF8 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x72u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00FDFA;
L_00FDFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDFAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDFA BEQ -> $00FDFE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FDFE; }
    goto L_00FDFC;
L_00FDFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDFCu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDFCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDFC STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00FDFE;
L_00FDFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDFEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDFE LDY
    cpu.setY(0x3u, 8);
    goto L_00FE00;
L_00FE00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE00u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE00u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE00 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FE02;
L_00FE02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE02u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE02 BNE -> $00FE05
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FE05; }
    goto L_00FE04;
L_00FE04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE04u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE04 DEY
    cpu.decReg('Y');
    goto L_00FE05;
L_00FE05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE05u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE05u, 4u + ((((0x170Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE05 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x170Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FE08;
L_00FE08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE08u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE08 BEQ -> $00FE16
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00FE16; }
    goto L_00FE0A;
L_00FE0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE0Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE0A DEY
    cpu.decReg('Y');
    goto L_00FE0B;
L_00FE0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE0Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE0B BPL -> $00FE05
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00FE05; }
    goto L_00FE0D;
L_00FE0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE0Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE0Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00FE0D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00FE0Du);return;} hw.unresolvedReturn(0x00FE0Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00FE16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE16u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE16 LDA
    cpu.setA(0x12u, 8);
    goto L_00FE18;
L_00FE18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE18u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE18u, 5u, 3u, cpu.address("absy", 0x170Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE18 STA
    hw.write(cpu.address("absy", 0x170Bu), cpu.a, cpu.m8?8:16);
    goto L_00FE1B;
L_00FE1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE1Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE1Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE1B TYA
    cpu.transfer("TYA");
    goto L_00FE1C;
L_00FE1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE1Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE1C ASL
    cpu.aslA();
    goto L_00FE1D;
L_00FE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE1Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE1Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE1D ASL
    cpu.aslA();
    goto L_00FE1E;
L_00FE1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE1Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE1Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE1E ASL
    cpu.aslA();
    goto L_00FE1F;
L_00FE1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE1Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE1Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE1F ADC
    cpu.adc(0xF7u);
    goto L_00FE21;
L_00FE21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE21u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE21u, 5u, 3u, cpu.address("absy", 0x1765u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE21 STA
    hw.write(cpu.address("absy", 0x1765u), cpu.a, cpu.m8?8:16);
    goto L_00FE24;
L_00FE24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE24u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE24u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE24 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FE26;
L_00FE26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE26u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE26u, 4u + ((((0xFE0Eu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xFE0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE26 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xFE0Eu), cpu.m8?8:16));
    goto L_00FE29;
L_00FE29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE29u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE29u, 5u, 3u, cpu.address("absy", 0x1715u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE29 STA
    hw.write(cpu.address("absy", 0x1715u), cpu.a, cpu.m8?8:16);
    goto L_00FE2C;
L_00FE2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE2Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE2Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE2C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FE2E;
L_00FE2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE2Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE2Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE2E ADC
    cpu.adc(0x0u);
    goto L_00FE30;
L_00FE30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE30u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE30u, 5u, 3u, cpu.address("absy", 0x1729u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE30 STA
    hw.write(cpu.address("absy", 0x1729u), cpu.a, cpu.m8?8:16);
    goto L_00FE33;
L_00FE33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE33u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE33u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE33 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FE35;
L_00FE35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE35u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE35u, 4u + ((((0xFE12u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xFE12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE35 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xFE12u), cpu.m8?8:16));
    goto L_00FE38;
L_00FE38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE38u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE38u, 5u, 3u, cpu.address("absy", 0x171Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE38 STA
    hw.write(cpu.address("absy", 0x171Fu), cpu.a, cpu.m8?8:16);
    goto L_00FE3B;
L_00FE3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE3Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE3B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00FE3D;
L_00FE3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE3Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE3D ADC
    cpu.adc(0x0u);
    goto L_00FE3F;
L_00FE3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE3Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE3Fu, 5u, 3u, cpu.address("absy", 0x1733u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE3F STA
    hw.write(cpu.address("absy", 0x1733u), cpu.a, cpu.m8?8:16);
    goto L_00FE42;
L_00FE42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE42u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE42 LDA
    cpu.setA(0x0u, 8);
    goto L_00FE44;
L_00FE44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE44u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE44u, 5u, 3u, cpu.address("absy", 0x176Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE44 STA
    hw.write(cpu.address("absy", 0x176Fu), cpu.a, cpu.m8?8:16);
    goto L_00FE47;
L_00FE47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE47u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE47u, 3u, 3u, cpu.address("abs", 0xFE0Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE47 JMP -> $00FE0A
    goto L_00FE0A;
}

void sub_01803A_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01803Au: goto L_01803A;
    case 0x01803Bu: goto L_01803B;
    case 0x01803Cu: goto L_01803C;
    case 0x01803Du: goto L_01803D;
    case 0x018040u: goto L_018040;
    case 0x018041u: goto L_018041;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01803A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Au,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01803A PHB
    cpu.push("PHB", hw);
    goto L_01803B;
L_01803B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Bu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01803B PHK
    cpu.push("PHK", hw);
    goto L_01803C;
L_01803C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01803C PLB
    cpu.pop("PLB", hw);
    goto L_01803D;
L_01803D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Du, 6u, 3u, cpu.address("abs", 0x8FC1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01803D JSR -> $018FC1 stack real
    { cpu.push16Value(hw,0x803Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8040u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8FC1u), 0x01803Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_018040;
L_018040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8040u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8040u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8040u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018040 PLB
    cpu.pop("PLB", hw);
    goto L_018041;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8040u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8040u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018040 PLB
    cpu.pop("PLB", hw);
    goto L_018041;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8040u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8040u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $018040 PLB
    cpu.pop("PLB", hw);
    goto L_018041;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8040u,0x018040u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_018041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8041u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8041u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8041u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $018041 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x018041u);return;} hw.unresolvedReturn(0x018041u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8041u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8041u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $018041 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x018041u);return;} hw.unresolvedReturn(0x018041u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8041u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8041u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $018041 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x018041u);return;} hw.unresolvedReturn(0x018041u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8041u,0x018041u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_028008_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x028008u: goto L_028008;
    case 0x028009u: goto L_028009;
    case 0x02800Cu: goto L_02800C;
    case 0x02800Eu: goto L_02800E;
    case 0x028011u: goto L_028011;
    case 0x028012u: goto L_028012;
    case 0x028014u: goto L_028014;
    case 0x028017u: goto L_028017;
    case 0x028019u: goto L_028019;
    case 0x02801Cu: goto L_02801C;
    case 0x02801Eu: goto L_02801E;
    case 0x02801Fu: goto L_02801F;
    case 0x028021u: goto L_028021;
    case 0x028024u: goto L_028024;
    case 0x028026u: goto L_028026;
    case 0x028028u: goto L_028028;
    case 0x02802Bu: goto L_02802B;
    case 0x02802Eu: goto L_02802E;
    case 0x02802Fu: goto L_02802F;
    case 0x028031u: goto L_028031;
    case 0x028032u: goto L_028032;
    case 0x028034u: goto L_028034;
    case 0x028036u: goto L_028036;
    case 0x028038u: goto L_028038;
    case 0x02803Bu: goto L_02803B;
    case 0x02803Du: goto L_02803D;
    case 0x02803Fu: goto L_02803F;
    case 0x028042u: goto L_028042;
    case 0x028044u: goto L_028044;
    case 0x028047u: goto L_028047;
    case 0x028048u: goto L_028048;
    case 0x028049u: goto L_028049;
    case 0x02804Bu: goto L_02804B;
    case 0x02804Du: goto L_02804D;
    case 0x028051u: goto L_028051;
    case 0x028053u: goto L_028053;
    case 0x028054u: goto L_028054;
    case 0x028056u: goto L_028056;
    case 0x028058u: goto L_028058;
    case 0x02805Au: goto L_02805A;
    case 0x02805Cu: goto L_02805C;
    case 0x02805Fu: goto L_02805F;
    case 0x028061u: goto L_028061;
    case 0x028062u: goto L_028062;
    case 0x028064u: goto L_028064;
    case 0x028066u: goto L_028066;
    case 0x028068u: goto L_028068;
    case 0x02806Au: goto L_02806A;
    case 0x02806Du: goto L_02806D;
    case 0x028070u: goto L_028070;
    case 0x028071u: goto L_028071;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_028008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8008u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8008u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $028008 PHX
    cpu.push("PHX", hw);
    goto L_028009;
L_028009:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8009u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8009u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8009u, 4u, 3u, cpu.address("abs", 0x0DC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028009 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDC2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02800C;
L_02800C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02800C BEQ -> $028070
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_028070; }
    goto L_02800E;
L_02800E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Eu, 4u, 3u, cpu.address("abs", 0x0DC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02800E STZ
    hw.write(cpu.address("abs", 0xDC2u), 0, cpu.m8?8:16);
    goto L_028011;
L_028011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8011u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8011u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $028011 PHA
    cpu.push("PHA", hw);
    goto L_028012;
L_028012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8012u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8012u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028012 LDA
    cpu.setA(0xCu, 8);
    goto L_028014;
L_028014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8014u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8014u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028014 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_028017;
L_028017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8017u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8017u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028017 LDX
    cpu.setX(0xBu, 8);
    goto L_028019;
L_028019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8019u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8019u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028019 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02801C;
L_02801C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x801Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x801Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x801Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02801C BEQ -> $028042
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_028042; }
    goto L_02801E;
L_02801E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x801Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x801Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x801Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02801E DEX
    cpu.decReg('X');
    goto L_02801F;
L_02801F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x801Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x801Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x801Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02801F BPL -> $028019
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_028019; }
    goto L_028021;
L_028021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8021u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8021u, 6u, 3u, cpu.address("abs", 0x1861u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028021 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1861u), cpu.m8?8:16);
    goto L_028024;
L_028024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8024u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8024u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028024 BPL -> $02802B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_02802B; }
    goto L_028026;
L_028026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8026u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8026u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028026 LDA
    cpu.setA(0x1u, 8);
    goto L_028028;
L_028028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8028u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8028u, 4u, 3u, cpu.address("abs", 0x1861u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028028 STA
    hw.write(cpu.address("abs", 0x1861u), cpu.a, cpu.m8?8:16);
    goto L_02802B;
L_02802B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Bu, 4u, 3u, cpu.address("abs", 0x1861u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02802B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1861u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02802E;
L_02802E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02802E CLC
    cpu.setFlag('C', false);
    goto L_02802F;
L_02802F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02802F ADC
    cpu.adc(0xAu);
    goto L_028031;
L_028031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8031u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8031u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028031 TAX
    cpu.transfer("TAX");
    goto L_028032;
L_028032:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8032u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8032u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8032u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028032 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028034;
L_028034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8034u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8034u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8034u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028034 CMP
    cpu.compareA(0x7Du);
    goto L_028036;
L_028036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8036u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8036u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028036 BNE -> $028042
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_028042; }
    goto L_028038;
L_028038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8038u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8038u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028038 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02803B;
L_02803B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02803B CMP
    cpu.compareA(0xBu);
    goto L_02803D;
L_02803D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02803D BNE -> $028042
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_028042; }
    goto L_02803F;
L_02803F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Fu, 4u, 3u, cpu.address("abs", 0x13F3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02803F STZ
    hw.write(cpu.address("abs", 0x13F3u), 0, cpu.m8?8:16);
    goto L_028042;
L_028042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8042u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8042u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028042 LDA
    cpu.setA(0x8u, 8);
    goto L_028044;
L_028044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8044u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8044u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8044u, 5u, 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028044 STA
    hw.write(cpu.address("absx", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_028047;
L_028047:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8047u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8047u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8047u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $028047 PLA
    cpu.pop("PLA", hw);
    goto L_028048;
L_028048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8048u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8048u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028048 CLC
    cpu.setFlag('C', false);
    goto L_028049;
L_028049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8049u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8049u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028049 ADC
    cpu.adc(0x73u);
    goto L_02804B;
L_02804B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02804B STA
    hw.write(cpu.address("dpx", 0x9Eu), cpu.a, cpu.m8?8:16);
    goto L_02804D;
L_02804D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Du, 8u, 4u, 0x07F7D2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02804D JSL -> $07F7D2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8050u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8051u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F7D2u, 0x02804Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_028051;
L_028051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8051u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8051u,0x028051u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8051u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8051u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028051 LDA
    cpu.setA(0x78u, 8);
    goto L_028053;
L_028053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8053u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8053u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028053 CLC
    cpu.setFlag('C', false);
    goto L_028054;
L_028054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8054u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8054u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028054 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_028056;
L_028056:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8056u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8056u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8056u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028056 STA
    hw.write(cpu.address("dpx", 0xE4u), cpu.a, cpu.m8?8:16);
    goto L_028058;
L_028058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8058u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8058u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028058 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02805A;
L_02805A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x805Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x805Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x805Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02805A ADC
    cpu.adc(0x0u);
    goto L_02805C;
L_02805C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x805Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x805Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x805Cu, 5u, 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02805C STA
    hw.write(cpu.address("absx", 0x14E0u), cpu.a, cpu.m8?8:16);
    goto L_02805F;
L_02805F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x805Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x805Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x805Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02805F LDA
    cpu.setA(0x20u, 8);
    goto L_028061;
L_028061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8061u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8061u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8061u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028061 CLC
    cpu.setFlag('C', false);
    goto L_028062;
L_028062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8062u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8062u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028062 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_028064;
L_028064:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8064u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8064u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8064u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028064 STA
    hw.write(cpu.address("dpx", 0xD8u), cpu.a, cpu.m8?8:16);
    goto L_028066;
L_028066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8066u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8066u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8066u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028066 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028068;
L_028068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8068u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8068u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8068u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028068 ADC
    cpu.adc(0x0u);
    goto L_02806A;
L_02806A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Au, 5u, 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02806A STA
    hw.write(cpu.address("absx", 0x14D4u), cpu.a, cpu.m8?8:16);
    goto L_02806D;
L_02806D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Du,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Du, 7u, 3u, cpu.address("absx", 0x1534u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02806D INC
    cpu.incMem(hw, cpu.address("absx", 0x1534u), cpu.m8?8:16);
    goto L_028070;
L_028070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8070u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8070u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8070u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $028070 PLX
    cpu.pop("PLX", hw);
    goto L_028071;
L_028071:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8071u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8071u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8071u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $028071 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x028071u);return;} hw.unresolvedReturn(0x028071u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0286ED_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0286EDu: goto L_0286ED;
    case 0x0286EFu: goto L_0286EF;
    case 0x0286F2u: goto L_0286F2;
    case 0x0286F4u: goto L_0286F4;
    case 0x0286F5u: goto L_0286F5;
    case 0x0286F7u: goto L_0286F7;
    case 0x0286F8u: goto L_0286F8;
    case 0x0286FAu: goto L_0286FA;
    case 0x0286FDu: goto L_0286FD;
    case 0x0286FFu: goto L_0286FF;
    case 0x028702u: goto L_028702;
    case 0x028704u: goto L_028704;
    case 0x028707u: goto L_028707;
    case 0x028709u: goto L_028709;
    case 0x02870Cu: goto L_02870C;
    case 0x02870Fu: goto L_02870F;
    case 0x028711u: goto L_028711;
    case 0x028713u: goto L_028713;
    case 0x028714u: goto L_028714;
    case 0x028716u: goto L_028716;
    case 0x028719u: goto L_028719;
    case 0x02871Bu: goto L_02871B;
    case 0x02871Du: goto L_02871D;
    case 0x028720u: goto L_028720;
    case 0x028722u: goto L_028722;
    case 0x028723u: goto L_028723;
    case 0x028725u: goto L_028725;
    case 0x028728u: goto L_028728;
    case 0x02872Au: goto L_02872A;
    case 0x02872Cu: goto L_02872C;
    case 0x02872Fu: goto L_02872F;
    case 0x028731u: goto L_028731;
    case 0x028734u: goto L_028734;
    case 0x028736u: goto L_028736;
    case 0x028739u: goto L_028739;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0286ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EDu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0286ED LDY
    cpu.setY(0x3u, 8);
    goto L_0286EF;
L_0286EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EFu, 4u + ((((0x16CDu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x16CDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0286EF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x16CDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0286F2;
L_0286F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0286F2 BEQ -> $0286F8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0286F8; }
    goto L_0286F4;
L_0286F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F4u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0286F4 DEY
    cpu.decReg('Y');
    goto L_0286F5;
L_0286F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0286F5 BPL -> $0286EF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0286EF; }
    goto L_0286F7;
L_0286F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F7u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0286F7 INY
    cpu.inc('Y');
    goto L_0286F8;
L_0286F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0286F8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0286FA;
L_0286FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FAu, 5u, 3u, cpu.address("absy", 0x16D1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0286FA STA
    hw.write(cpu.address("absy", 0x16D1u), cpu.a, cpu.m8?8:16);
    goto L_0286FD;
L_0286FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0286FD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0286FF;
L_0286FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FFu, 5u, 3u, cpu.address("absy", 0x16D5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0286FF STA
    hw.write(cpu.address("absy", 0x16D5u), cpu.a, cpu.m8?8:16);
    goto L_028702;
L_028702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8702u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8702u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028702 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028704;
L_028704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8704u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8704u, 5u, 3u, cpu.address("absy", 0x16D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028704 STA
    hw.write(cpu.address("absy", 0x16D9u), cpu.a, cpu.m8?8:16);
    goto L_028707;
L_028707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028707 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x99u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028709;
L_028709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8709u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8709u, 5u, 3u, cpu.address("absy", 0x16DDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028709 STA
    hw.write(cpu.address("absy", 0x16DDu), cpu.a, cpu.m8?8:16);
    goto L_02870C;
L_02870C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Cu, 4u, 3u, cpu.address("abs", 0x1933u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02870C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1933u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02870F;
L_02870F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02870F BEQ -> $02872F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02872F; }
    goto L_028711;
L_028711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8711u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8711u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028711 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028713;
L_028713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8713u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8713u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028713 SEC
    cpu.setFlag('C', true);
    goto L_028714;
L_028714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028714 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_028716;
L_028716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8716u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8716u, 5u, 3u, cpu.address("absy", 0x16D1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028716 STA
    hw.write(cpu.address("absy", 0x16D1u), cpu.a, cpu.m8?8:16);
    goto L_028719;
L_028719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8719u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8719u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028719 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02871B;
L_02871B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x27u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02871B SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x27u), cpu.m8?8:16));
    goto L_02871D;
L_02871D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Du, 5u, 3u, cpu.address("absy", 0x16D5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02871D STA
    hw.write(cpu.address("absy", 0x16D5u), cpu.a, cpu.m8?8:16);
    goto L_028720;
L_028720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8720u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8720u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028720 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028722;
L_028722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8722u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8722u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028722 SEC
    cpu.setFlag('C', true);
    goto L_028723;
L_028723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8723u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8723u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028723 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16));
    goto L_028725;
L_028725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8725u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8725u, 5u, 3u, cpu.address("absy", 0x16D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028725 STA
    hw.write(cpu.address("absy", 0x16D9u), cpu.a, cpu.m8?8:16);
    goto L_028728;
L_028728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028728 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x99u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02872A;
L_02872A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02872A SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x29u), cpu.m8?8:16));
    goto L_02872C;
L_02872C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu, 5u, 3u, cpu.address("absy", 0x16DDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02872C STA
    hw.write(cpu.address("absy", 0x16DDu), cpu.a, cpu.m8?8:16);
    goto L_02872F;
L_02872F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02872F LDA
    cpu.setA(0x1u, 8);
    goto L_028731;
L_028731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8731u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8731u, 5u, 3u, cpu.address("absy", 0x16CDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028731 STA
    hw.write(cpu.address("absy", 0x16CDu), cpu.a, cpu.m8?8:16);
    goto L_028734;
L_028734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028734 LDA
    cpu.setA(0x6u, 8);
    goto L_028736;
L_028736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8736u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8736u, 5u, 3u, cpu.address("absy", 0x18F8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028736 STA
    hw.write(cpu.address("absy", 0x18F8u), cpu.a, cpu.m8?8:16);
    goto L_028739;
L_028739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8739u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8739u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $028739 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x028739u);return;} hw.unresolvedReturn(0x028739u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0296C0_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0296C0u: goto L_0296C0;
    case 0x0296C3u: goto L_0296C3;
    case 0x0296C5u: goto L_0296C5;
    case 0x0296C7u: goto L_0296C7;
    case 0x0296CBu: goto L_0296CB;
    case 0x0296CDu: goto L_0296CD;
    case 0x0296CFu: goto L_0296CF;
    case 0x0296D1u: goto L_0296D1;
    case 0x0296D3u: goto L_0296D3;
    case 0x0296D5u: goto L_0296D5;
    case 0x0296D6u: goto L_0296D6;
    case 0x0296D7u: goto L_0296D7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0296C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C0u, 4u + ((((0x17C0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x17C0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0296C0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x17C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0296C3;
L_0296C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0296C3 BEQ -> $0296D7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0296D7; }
    goto L_0296C5;
L_0296C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0296C5 AND
    cpu.logicAnd(0x7Fu);
    goto L_0296C7;
L_0296C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C7u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0296C7 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x96CAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x96CBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x0296C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0296CB;
L_0296CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x96CBu,0x0296CBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CBu,cpu,0xD7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CBu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x96u) & 0xFFFFu), 3u, 0u);
    // $0296CB CMP
    cpu.compareA(hw.readW(cpu.addressDpLongY(hw, 0x96u), cpu.m8?8:16));
    goto L_0296CD;
L_0296CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CDu,cpu,0xE3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CDu, 4u, 2u, cpu.addressStack(0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0296CD SBC
    cpu.sbc(hw.readW(cpu.addressStack(0x96u), cpu.m8?8:16));
    goto L_0296CF;
L_0296CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CFu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CFu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x97u) & 0xFFFFu), 3u, 0u);
    // $0296CF STA
    hw.write(cpu.addressDpLongY(hw, 0x97u), cpu.a, cpu.m8?8:16);
    goto L_0296D1;
L_0296D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D1u,cpu,0x27u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D1u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x99u) & 0xFFFFu), 3u, 0u);
    // $0296D1 AND
    cpu.logicAnd(hw.readW(cpu.addressDpLong(hw, 0x99u), cpu.m8?8:16));
    goto L_0296D3;
L_0296D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D3u,cpu,0xD7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D3u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x96u) & 0xFFFFu), 3u, 0u);
    // $0296D3 CMP
    cpu.compareA(hw.readW(cpu.addressDpLongY(hw, 0x96u), cpu.m8?8:16));
    goto L_0296D5;
L_0296D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D5u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0296D5 DEX
    cpu.decReg('X');
    goto L_0296D6;
L_0296D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D6u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0296D6 TYA
    cpu.transfer("TYA");
    goto L_0296D7;
L_0296D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0296D7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0296D7u);return;} hw.unresolvedReturn(0x0296D7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0296D7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0296D7u);return;} hw.unresolvedReturn(0x0296D7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x96D7u,0x0296D7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_0296C0_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0296C0u: goto L_0296C0;
    case 0x0296C3u: goto L_0296C3;
    case 0x0296C5u: goto L_0296C5;
    case 0x0296C7u: goto L_0296C7;
    case 0x0296CBu: goto L_0296CB;
    case 0x0296CDu: goto L_0296CD;
    case 0x0296CFu: goto L_0296CF;
    case 0x0296D1u: goto L_0296D1;
    case 0x0296D3u: goto L_0296D3;
    case 0x0296D5u: goto L_0296D5;
    case 0x0296D6u: goto L_0296D6;
    case 0x0296D7u: goto L_0296D7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0296C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C0u, 4u + ((((0x17C0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x17C0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0296C0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x17C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0296C3;
L_0296C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0296C3 BEQ -> $0296D7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0296D7; }
    goto L_0296C5;
L_0296C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0296C5 AND
    cpu.logicAnd(0x7Fu);
    goto L_0296C7;
L_0296C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C7u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0296C7 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x96CAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x96CBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0x0296C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0296CB;
L_0296CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x96CBu,0x0296CBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CBu,cpu,0xD7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CBu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x96u) & 0xFFFFu), 3u, 0u);
    // $0296CB CMP
    cpu.compareA(hw.readW(cpu.addressDpLongY(hw, 0x96u), cpu.m8?8:16));
    goto L_0296CD;
L_0296CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CDu,cpu,0xE3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CDu, 4u, 2u, cpu.addressStack(0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0296CD SBC
    cpu.sbc(hw.readW(cpu.addressStack(0x96u), cpu.m8?8:16));
    goto L_0296CF;
L_0296CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CFu,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CFu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x97u) & 0xFFFFu), 3u, 0u);
    // $0296CF STA
    hw.write(cpu.addressDpLongY(hw, 0x97u), cpu.a, cpu.m8?8:16);
    goto L_0296D1;
L_0296D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D1u,cpu,0x27u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D1u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x99u) & 0xFFFFu), 3u, 0u);
    // $0296D1 AND
    cpu.logicAnd(hw.readW(cpu.addressDpLong(hw, 0x99u), cpu.m8?8:16));
    goto L_0296D3;
L_0296D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D3u,cpu,0xD7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D3u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x96u) & 0xFFFFu), 3u, 0u);
    // $0296D3 CMP
    cpu.compareA(hw.readW(cpu.addressDpLongY(hw, 0x96u), cpu.m8?8:16));
    goto L_0296D5;
L_0296D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D5u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0296D5 DEX
    cpu.decReg('X');
    goto L_0296D6;
L_0296D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D6u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0296D6 TYA
    cpu.transfer("TYA");
    goto L_0296D7;
L_0296D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0296D7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0296D7u);return;} hw.unresolvedReturn(0x0296D7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02D0D4_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02D0D4u: goto L_02D0D4;
    case 0x02D0D7u: goto L_02D0D7;
    case 0x02D0D9u: goto L_02D0D9;
    case 0x02D0DCu: goto L_02D0DC;
    case 0x02D0DEu: goto L_02D0DE;
    case 0x02D0DFu: goto L_02D0DF;
    case 0x02D0E0u: goto L_02D0E0;
    case 0x02D0E1u: goto L_02D0E1;
    case 0x02D0E4u: goto L_02D0E4;
    case 0x02D0E5u: goto L_02D0E5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02D0D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D4u, 4u + ((((0x1564u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1564u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0D4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1564u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D0D7;
L_02D0D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0D7 BNE -> $02D0E5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02D0E5; }
    goto L_02D0D9;
L_02D0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D9u, 4u + ((((0x160Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x160Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0D9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x160Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D0DC;
L_02D0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0DC BPL -> $02D0E5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_02D0E5; }
    goto L_02D0DE;
L_02D0DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DEu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D0DE PHB
    cpu.push("PHB", hw);
    goto L_02D0DF;
L_02D0DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DFu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D0DF PHK
    cpu.push("PHK", hw);
    goto L_02D0E0;
L_02D0E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E0u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D0E0 PLB
    cpu.pop("PLB", hw);
    goto L_02D0E1;
L_02D0E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E1u, 6u, 3u, cpu.address("abs", 0xD0E6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02D0E1 JSR -> $02D0E6 stack real
    { cpu.push16Value(hw,0xD0E3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0E4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD0E6u), 0x02D0E1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02D0E4;
L_02D0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0E4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0E4u,0x02D0E4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E4u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D0E4 PLB
    cpu.pop("PLB", hw);
    goto L_02D0E5;
L_02D0E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E5u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02D0E5 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02D0E5u);return;} hw.unresolvedReturn(0x02D0E5u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_03C334_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x03C334u: goto L_03C334;
    case 0x03C336u: goto L_03C336;
    case 0x03C338u: goto L_03C338;
    case 0x03C33Au: goto L_03C33A;
    case 0x03C33Bu: goto L_03C33B;
    case 0x03C33Eu: goto L_03C33E;
    case 0x03C340u: goto L_03C340;
    case 0x03C342u: goto L_03C342;
    case 0x03C344u: goto L_03C344;
    case 0x03C347u: goto L_03C347;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_03C334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC334u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC334u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC334u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C334 LDA
    cpu.setA(0x0u, 8);
    goto L_03C336;
L_03C336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC336u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC336u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C336 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x7Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_03C338;
L_03C338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC338u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC338u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C338 BPL -> $03C33B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_03C33B; }
    goto L_03C33A;
L_03C33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C33A INC
    cpu.inc('A');
    goto L_03C33B;
L_03C33B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Bu, 5u, 3u, cpu.address("absx", 0x157Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C33B STA
    hw.write(cpu.address("absx", 0x157Cu), cpu.a, cpu.m8?8:16);
    goto L_03C33E;
L_03C33E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C33E LDA
    cpu.setA(0xC0u, 8);
    goto L_03C340;
L_03C340:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC340u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC340u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC340u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C340 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_03C342;
L_03C342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC342u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC342u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C342 LDA
    cpu.setA(0x2u, 8);
    goto L_03C344;
L_03C344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC344u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC344u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $03C344 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_03C347;
L_03C347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC347u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC347u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $03C347 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x03C347u);return;} hw.unresolvedReturn(0x03C347u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04E4A9_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04E4A9u: goto L_04E4A9;
    case 0x04E4ABu: goto L_04E4AB;
    case 0x04E4ADu: goto L_04E4AD;
    case 0x04E4AFu: goto L_04E4AF;
    case 0x04E4B1u: goto L_04E4B1;
    case 0x04E4B3u: goto L_04E4B3;
    case 0x04E4B5u: goto L_04E4B5;
    case 0x04E4B8u: goto L_04E4B8;
    case 0x04E4BAu: goto L_04E4BA;
    case 0x04E4BDu: goto L_04E4BD;
    case 0x04E4BFu: goto L_04E4BF;
    case 0x04E4C2u: goto L_04E4C2;
    case 0x04E4C4u: goto L_04E4C4;
    case 0x04E4C7u: goto L_04E4C7;
    case 0x04E4CAu: goto L_04E4CA;
    case 0x04E4CDu: goto L_04E4CD;
    case 0x04E4CFu: goto L_04E4CF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04E4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4A9 SEP
    cpu.sep(0x20u);
    goto L_04E4AB;
L_04E4AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4ABu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4AB LDA
    cpu.setA(0x7Fu, 8);
    goto L_04E4AD;
L_04E4AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4ADu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4AD STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_04E4AF;
L_04E4AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4AF LDA
    cpu.setA(0xCu, 8);
    goto L_04E4B1;
L_04E4B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4B1 STA
    hw.write(cpu.address("dp", 0xBu), cpu.a, cpu.m8?8:16);
    goto L_04E4B3;
L_04E4B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4B3 REP
    cpu.rep(0x20u);
    goto L_04E4B5;
L_04E4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4B5 LDA
    cpu.setA(0x0u, 16);
    goto L_04E4B8;
L_04E4B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4B8 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_04E4BA;
L_04E4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4BA LDA
    cpu.setA(0x8000u, 16);
    goto L_04E4BD;
L_04E4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4BD STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_04E4BF;
L_04E4BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BFu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4BF CPY
    cpu.compareY(0x900u);
    goto L_04E4C2;
L_04E4C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C2u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4C2 BCC -> $04E4CA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_04E4CA; }
    goto L_04E4C4;
L_04E4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C4u, 6u, 3u, cpu.address("abs", 0xE4D0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04E4C4 JSR -> $04E4D0 stack real
    { cpu.push16Value(hw,0xE4C6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE4C7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE4D0u), 0x04E4C4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04E4C7;
L_04E4C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE4C7u,0x04E4C7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C7u, 3u, 3u, cpu.address("abs", 0xE4CDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4C7 JMP -> $04E4CD
    goto L_04E4CD;
L_04E4CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CAu, 6u, 3u, cpu.address("abs", 0xE520u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04E4CA JSR -> $04E520 stack real
    { cpu.push16Value(hw,0xE4CCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE4CDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE520u), 0x04E4CAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04E4CD;
L_04E4CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4CDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE4CDu,0x04E4CDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E4CD SEP
    cpu.sep(0x30u);
    goto L_04E4CF;
L_04E4CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04E4CF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04E4CFu);return;} hw.unresolvedReturn(0x04E4CFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04EBEB_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04EBEBu: goto L_04EBEB;
    case 0x04EBEEu: goto L_04EBEE;
    case 0x04EBF0u: goto L_04EBF0;
    case 0x04EBF3u: goto L_04EBF3;
    case 0x04EBF4u: goto L_04EBF4;
    case 0x04EBF7u: goto L_04EBF7;
    case 0x04EBFAu: goto L_04EBFA;
    case 0x04EBFCu: goto L_04EBFC;
    case 0x04EBFEu: goto L_04EBFE;
    case 0x04EC00u: goto L_04EC00;
    case 0x04EC02u: goto L_04EC02;
    case 0x04EC03u: goto L_04EC03;
    case 0x04EC06u: goto L_04EC06;
    case 0x04EC07u: goto L_04EC07;
    case 0x04EC08u: goto L_04EC08;
    case 0x04EC09u: goto L_04EC09;
    case 0x04EC0Au: goto L_04EC0A;
    case 0x04EC0Du: goto L_04EC0D;
    case 0x04EC0Fu: goto L_04EC0F;
    case 0x04EC12u: goto L_04EC12;
    case 0x04EC14u: goto L_04EC14;
    case 0x04EC17u: goto L_04EC17;
    case 0x04EC19u: goto L_04EC19;
    case 0x04EC1Bu: goto L_04EC1B;
    case 0x04EC1Cu: goto L_04EC1C;
    case 0x04EC1Fu: goto L_04EC1F;
    case 0x04EC20u: goto L_04EC20;
    case 0x04EC22u: goto L_04EC22;
    case 0x04EC23u: goto L_04EC23;
    case 0x04EC24u: goto L_04EC24;
    case 0x04EC25u: goto L_04EC25;
    case 0x04EC26u: goto L_04EC26;
    case 0x04EC29u: goto L_04EC29;
    case 0x04EC2Bu: goto L_04EC2B;
    case 0x04EC2Eu: goto L_04EC2E;
    case 0x04EC30u: goto L_04EC30;
    case 0x04EC32u: goto L_04EC32;
    case 0x04EC34u: goto L_04EC34;
    case 0x04EC36u: goto L_04EC36;
    case 0x04EC37u: goto L_04EC37;
    case 0x04EC3Au: goto L_04EC3A;
    case 0x04EC3Du: goto L_04EC3D;
    case 0x04EC3Fu: goto L_04EC3F;
    case 0x04EC40u: goto L_04EC40;
    case 0x04EC43u: goto L_04EC43;
    case 0x04EC46u: goto L_04EC46;
    case 0x04EC48u: goto L_04EC48;
    case 0x04EC4Bu: goto L_04EC4B;
    case 0x04EC4Eu: goto L_04EC4E;
    case 0x04EC51u: goto L_04EC51;
    case 0x04EC52u: goto L_04EC52;
    case 0x04EC53u: goto L_04EC53;
    case 0x04EC54u: goto L_04EC54;
    case 0x04EC55u: goto L_04EC55;
    case 0x04EC56u: goto L_04EC56;
    case 0x04EC58u: goto L_04EC58;
    case 0x04EC5Au: goto L_04EC5A;
    case 0x04EC5Du: goto L_04EC5D;
    case 0x04EC60u: goto L_04EC60;
    case 0x04EC63u: goto L_04EC63;
    case 0x04EC66u: goto L_04EC66;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04EBEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBEBu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBEBu, 6u, 3u, cpu.address("abs", 0x1B84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EBEB DEC
    cpu.decMem(hw, cpu.address("abs", 0x1B84u), cpu.m8?8:16);
    goto L_04EBEE;
L_04EBEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBEEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBEEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EBEE BPL -> $04EBF4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04EBF4; }
    goto L_04EBF0;
L_04EBF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBF0u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBF0u, 6u, 3u, cpu.address("abs", 0x1B86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EBF0 INC
    cpu.incMem(hw, cpu.address("abs", 0x1B86u), cpu.m8?8:16);
    goto L_04EBF3;
L_04EBF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBF3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBF3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EBF3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04EBF3u);return;} hw.unresolvedReturn(0x04EBF3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_04EBF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBF4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBF4u, 4u, 3u, cpu.address("abs", 0x1B84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EBF4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B84u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EBF7;
L_04EBF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBF7u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBF7u, 4u, 3u, cpu.address("abs", 0x1B86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EBF7 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1B86u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04EBFA;
L_04EBFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBFAu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EBFA CPY
    cpu.compareY(0x1u);
    goto L_04EBFC;
L_04EBFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBFCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EBFC BEQ -> $04EC17
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04EC17; }
    goto L_04EBFE;
L_04EBFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBFEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EBFE CMP
    cpu.compareA(0x10u);
    goto L_04EC00;
L_04EC00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC00u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC00 BNE -> $04EC07
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04EC07; }
    goto L_04EC02;
L_04EC02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC02u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC02u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04EC02 PHA
    cpu.push("PHA", hw);
    goto L_04EC03;
L_04EC03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC03u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC03u, 6u, 3u, cpu.address("abs", 0xED83u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EC03 JSR -> $04ED83 stack real
    { cpu.push16Value(hw,0xEC05u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEC06u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xED83u), 0x04EC03u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04EC06;
L_04EC06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC06u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC06u,0x04EC06u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC06u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC06u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04EC06 PLA
    cpu.pop("PLA", hw);
    goto L_04EC07;
L_04EC07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC07u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC07 LSR
    cpu.lsrA();
    goto L_04EC08;
L_04EC08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC08u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC08u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC08 LSR
    cpu.lsrA();
    goto L_04EC09;
L_04EC09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC09u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC09 TAX
    cpu.transfer("TAX");
    goto L_04EC0A;
L_04EC0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC0Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC0Au, 4u + ((((0xEBDAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xEBDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC0A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xEBDAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EC0D;
L_04EC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC0Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC0D STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04EC0F;
L_04EC0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC0Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC0Fu, 6u, 3u, cpu.address("abs", 0xEC67u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EC0F JSR -> $04EC67 stack real
    { cpu.push16Value(hw,0xEC11u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEC12u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEC67u), 0x04EC0Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04EC12;
L_04EC12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC12u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC12u,0x04EC12u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC12u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC12 LDX
    cpu.setX(0x28u, 8);
    goto L_04EC14;
L_04EC14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC14u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC14u, 3u, 3u, cpu.address("abs", 0xEC2Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC14 JMP -> $04EC2E
    goto L_04EC2E;
L_04EC17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC17u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC17 CMP
    cpu.compareA(0x18u);
    goto L_04EC19;
L_04EC19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC19u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC19 BNE -> $04EC20
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04EC20; }
    goto L_04EC1B;
L_04EC1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC1Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC1Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04EC1B PHA
    cpu.push("PHA", hw);
    goto L_04EC1C;
L_04EC1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC1Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC1Cu, 6u, 3u, cpu.address("abs", 0xEEAAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EC1C JSR -> $04EEAA stack real
    { cpu.push16Value(hw,0xEC1Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEC1Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEEAAu), 0x04EC1Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04EC1F;
L_04EC1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC1Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC1Fu,0x04EC1Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC1Fu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC1Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04EC1F PLA
    cpu.pop("PLA", hw);
    goto L_04EC20;
L_04EC20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC20u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC20 AND
    cpu.logicAnd(0xFCu);
    goto L_04EC22;
L_04EC22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC22u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC22 TAX
    cpu.transfer("TAX");
    goto L_04EC23;
L_04EC23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC23u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC23 LSR
    cpu.lsrA();
    goto L_04EC24;
L_04EC24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC24u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC24 LSR
    cpu.lsrA();
    goto L_04EC25;
L_04EC25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC25u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC25 TAY
    cpu.transfer("TAY");
    goto L_04EC26;
L_04EC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC26u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC26u, 4u + ((((0xEBE1u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEBE1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC26 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEBE1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EC29;
L_04EC29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC29u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC29u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC29 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04EC2B;
L_04EC2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC2Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC2Bu, 6u, 3u, cpu.address("abs", 0xEC67u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EC2B JSR -> $04EC67 stack real
    { cpu.push16Value(hw,0xEC2Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEC2Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEC67u), 0x04EC2Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04EC2E;
L_04EC2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC2Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC2Eu,0x04EC2Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC2Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC2Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC2E LDA
    cpu.setA(0x3u, 8);
    goto L_04EC30;
L_04EC30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC30u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC30u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC30 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_04EC32;
L_04EC32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC32u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC32 LDY
    cpu.setY(0x0u, 8);
    goto L_04EC34;
L_04EC34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC34u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC34u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC34 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EC36;
L_04EC36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC36u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC36u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC36 CLC
    cpu.setFlag('C', false);
    goto L_04EC37;
L_04EC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC37u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC37u, 4u + ((((0xEB56u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xEB56u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC37 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xEB56u), cpu.m8?8:16));
    goto L_04EC3A;
L_04EC3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC3Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC3Au, 5u, 3u, cpu.address("absy", 0x0280u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC3A STA
    hw.write(cpu.address("absy", 0x280u), cpu.a, cpu.m8?8:16);
    goto L_04EC3D;
L_04EC3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC3Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC3Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC3D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EC3F;
L_04EC3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC3Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC3Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC3F CLC
    cpu.setFlag('C', false);
    goto L_04EC40;
L_04EC40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC40u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC40u, 4u + ((((0xEB82u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xEB82u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC40 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xEB82u), cpu.m8?8:16));
    goto L_04EC43;
L_04EC43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC43u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC43u, 5u, 3u, cpu.address("absy", 0x0281u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC43 STA
    hw.write(cpu.address("absy", 0x281u), cpu.a, cpu.m8?8:16);
    goto L_04EC46;
L_04EC46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC46u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC46u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC46 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EC48;
L_04EC48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC48u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC48u, 5u, 3u, cpu.address("absy", 0x0282u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC48 STA
    hw.write(cpu.address("absy", 0x282u), cpu.a, cpu.m8?8:16);
    goto L_04EC4B;
L_04EC4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Bu, 4u + ((((0xEBAEu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xEBAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC4B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xEBAEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EC4E;
L_04EC4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Eu, 5u, 3u, cpu.address("absy", 0x0283u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC4E STA
    hw.write(cpu.address("absy", 0x283u), cpu.a, cpu.m8?8:16);
    goto L_04EC51;
L_04EC51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC51u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC51 INY
    cpu.inc('Y');
    goto L_04EC52;
L_04EC52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC52u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC52u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC52 INY
    cpu.inc('Y');
    goto L_04EC53;
L_04EC53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC53u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC53u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC53 INY
    cpu.inc('Y');
    goto L_04EC54;
L_04EC54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC54u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC54 INY
    cpu.inc('Y');
    goto L_04EC55;
L_04EC55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC55u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC55 INX
    cpu.inc('X');
    goto L_04EC56;
L_04EC56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC56u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC56u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC56 DEC
    cpu.decMem(hw, cpu.address("dp", 0x3u), cpu.m8?8:16);
    goto L_04EC58;
L_04EC58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC58u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC58 BPL -> $04EC34
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04EC34; }
    goto L_04EC5A;
L_04EC5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC5Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC5Au, 4u, 3u, cpu.address("abs", 0x0440u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC5A STZ
    hw.write(cpu.address("abs", 0x440u), 0, cpu.m8?8:16);
    goto L_04EC5D;
L_04EC5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC5Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC5Du, 4u, 3u, cpu.address("abs", 0x0441u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC5D STZ
    hw.write(cpu.address("abs", 0x441u), 0, cpu.m8?8:16);
    goto L_04EC60;
L_04EC60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC60u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC60u, 4u, 3u, cpu.address("abs", 0x0442u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC60 STZ
    hw.write(cpu.address("abs", 0x442u), 0, cpu.m8?8:16);
    goto L_04EC63;
L_04EC63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC63u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC63u, 4u, 3u, cpu.address("abs", 0x0443u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC63 STZ
    hw.write(cpu.address("abs", 0x443u), 0, cpu.m8?8:16);
    goto L_04EC66;
L_04EC66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC66u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC66u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EC66 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04EC66u);return;} hw.unresolvedReturn(0x04EC66u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04EBEB_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04EBEBu: goto L_04EBEB;
    case 0x04EBEEu: goto L_04EBEE;
    case 0x04EBF0u: goto L_04EBF0;
    case 0x04EBF3u: goto L_04EBF3;
    case 0x04EBF4u: goto L_04EBF4;
    case 0x04EBF7u: goto L_04EBF7;
    case 0x04EBFAu: goto L_04EBFA;
    case 0x04EBFCu: goto L_04EBFC;
    case 0x04EBFEu: goto L_04EBFE;
    case 0x04EC00u: goto L_04EC00;
    case 0x04EC02u: goto L_04EC02;
    case 0x04EC03u: goto L_04EC03;
    case 0x04EC06u: goto L_04EC06;
    case 0x04EC07u: goto L_04EC07;
    case 0x04EC08u: goto L_04EC08;
    case 0x04EC09u: goto L_04EC09;
    case 0x04EC0Au: goto L_04EC0A;
    case 0x04EC0Du: goto L_04EC0D;
    case 0x04EC0Fu: goto L_04EC0F;
    case 0x04EC12u: goto L_04EC12;
    case 0x04EC14u: goto L_04EC14;
    case 0x04EC17u: goto L_04EC17;
    case 0x04EC19u: goto L_04EC19;
    case 0x04EC1Bu: goto L_04EC1B;
    case 0x04EC1Cu: goto L_04EC1C;
    case 0x04EC1Fu: goto L_04EC1F;
    case 0x04EC20u: goto L_04EC20;
    case 0x04EC22u: goto L_04EC22;
    case 0x04EC23u: goto L_04EC23;
    case 0x04EC24u: goto L_04EC24;
    case 0x04EC25u: goto L_04EC25;
    case 0x04EC26u: goto L_04EC26;
    case 0x04EC29u: goto L_04EC29;
    case 0x04EC2Bu: goto L_04EC2B;
    case 0x04EC2Eu: goto L_04EC2E;
    case 0x04EC30u: goto L_04EC30;
    case 0x04EC32u: goto L_04EC32;
    case 0x04EC34u: goto L_04EC34;
    case 0x04EC36u: goto L_04EC36;
    case 0x04EC37u: goto L_04EC37;
    case 0x04EC3Au: goto L_04EC3A;
    case 0x04EC3Du: goto L_04EC3D;
    case 0x04EC3Fu: goto L_04EC3F;
    case 0x04EC40u: goto L_04EC40;
    case 0x04EC43u: goto L_04EC43;
    case 0x04EC46u: goto L_04EC46;
    case 0x04EC48u: goto L_04EC48;
    case 0x04EC4Bu: goto L_04EC4B;
    case 0x04EC4Eu: goto L_04EC4E;
    case 0x04EC51u: goto L_04EC51;
    case 0x04EC52u: goto L_04EC52;
    case 0x04EC53u: goto L_04EC53;
    case 0x04EC54u: goto L_04EC54;
    case 0x04EC55u: goto L_04EC55;
    case 0x04EC56u: goto L_04EC56;
    case 0x04EC58u: goto L_04EC58;
    case 0x04EC5Au: goto L_04EC5A;
    case 0x04EC5Du: goto L_04EC5D;
    case 0x04EC60u: goto L_04EC60;
    case 0x04EC63u: goto L_04EC63;
    case 0x04EC66u: goto L_04EC66;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04EBEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBEBu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBEBu, 6u, 3u, cpu.address("abs", 0x1B84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EBEB DEC
    cpu.decMem(hw, cpu.address("abs", 0x1B84u), cpu.m8?8:16);
    goto L_04EBEE;
L_04EBEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBEEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBEEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EBEE BPL -> $04EBF4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04EBF4; }
    goto L_04EBF0;
L_04EBF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBF0u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBF0u, 6u, 3u, cpu.address("abs", 0x1B86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EBF0 INC
    cpu.incMem(hw, cpu.address("abs", 0x1B86u), cpu.m8?8:16);
    goto L_04EBF3;
L_04EBF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBF3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBF3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EBF3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04EBF3u);return;} hw.unresolvedReturn(0x04EBF3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_04EBF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBF4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBF4u, 4u, 3u, cpu.address("abs", 0x1B84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EBF4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B84u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EBF7;
L_04EBF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBF7u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBF7u, 4u, 3u, cpu.address("abs", 0x1B86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EBF7 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1B86u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_04EBFA;
L_04EBFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBFAu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EBFA CPY
    cpu.compareY(0x1u);
    goto L_04EBFC;
L_04EBFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBFCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EBFC BEQ -> $04EC17
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04EC17; }
    goto L_04EBFE;
L_04EBFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEBFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEBFEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEBFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EBFE CMP
    cpu.compareA(0x10u);
    goto L_04EC00;
L_04EC00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC00u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC00 BNE -> $04EC07
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04EC07; }
    goto L_04EC02;
L_04EC02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC02u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC02u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04EC02 PHA
    cpu.push("PHA", hw);
    goto L_04EC03;
L_04EC03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC03u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC03u, 6u, 3u, cpu.address("abs", 0xED83u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EC03 JSR -> $04ED83 stack real
    { cpu.push16Value(hw,0xEC05u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEC06u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xED83u), 0x04EC03u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04EC06;
L_04EC06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC06u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC06u,0x04EC06u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC06u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC06u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04EC06 PLA
    cpu.pop("PLA", hw);
    goto L_04EC07;
L_04EC07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC07u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC07 LSR
    cpu.lsrA();
    goto L_04EC08;
L_04EC08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC08u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC08u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC08 LSR
    cpu.lsrA();
    goto L_04EC09;
L_04EC09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC09u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC09 TAX
    cpu.transfer("TAX");
    goto L_04EC0A;
L_04EC0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC0Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC0Au, 4u + ((((0xEBDAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xEBDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC0A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xEBDAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EC0D;
L_04EC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC0Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC0D STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04EC0F;
L_04EC0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC0Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC0Fu, 6u, 3u, cpu.address("abs", 0xEC67u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EC0F JSR -> $04EC67 stack real
    { cpu.push16Value(hw,0xEC11u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEC12u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEC67u), 0x04EC0Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04EC12;
L_04EC12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC12u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC12u,0x04EC12u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC12u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC12 LDX
    cpu.setX(0x28u, 8);
    goto L_04EC14;
L_04EC14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC14u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC14u, 3u, 3u, cpu.address("abs", 0xEC2Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC14 JMP -> $04EC2E
    goto L_04EC2E;
L_04EC17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC17u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC17 CMP
    cpu.compareA(0x18u);
    goto L_04EC19;
L_04EC19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC19u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC19 BNE -> $04EC20
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04EC20; }
    goto L_04EC1B;
L_04EC1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC1Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC1Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04EC1B PHA
    cpu.push("PHA", hw);
    goto L_04EC1C;
L_04EC1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC1Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC1Cu, 6u, 3u, cpu.address("abs", 0xEEAAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EC1C JSR -> $04EEAA stack real
    { cpu.push16Value(hw,0xEC1Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEC1Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEEAAu), 0x04EC1Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04EC1F;
L_04EC1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC1Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC1Fu,0x04EC1Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC1Fu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC1Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $04EC1F PLA
    cpu.pop("PLA", hw);
    goto L_04EC20;
L_04EC20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC20u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC20 AND
    cpu.logicAnd(0xFCu);
    goto L_04EC22;
L_04EC22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC22u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC22 TAX
    cpu.transfer("TAX");
    goto L_04EC23;
L_04EC23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC23u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC23 LSR
    cpu.lsrA();
    goto L_04EC24;
L_04EC24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC24u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC24 LSR
    cpu.lsrA();
    goto L_04EC25;
L_04EC25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC25u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC25 TAY
    cpu.transfer("TAY");
    goto L_04EC26;
L_04EC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC26u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC26u, 4u + ((((0xEBE1u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xEBE1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC26 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEBE1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EC29;
L_04EC29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC29u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC29u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC29 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_04EC2B;
L_04EC2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC2Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC2Bu, 6u, 3u, cpu.address("abs", 0xEC67u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EC2B JSR -> $04EC67 stack real
    { cpu.push16Value(hw,0xEC2Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEC2Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xEC67u), 0x04EC2Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04EC2E;
L_04EC2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC2Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC2Eu,0x04EC2Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC2Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC2Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC2E LDA
    cpu.setA(0x3u, 8);
    goto L_04EC30;
L_04EC30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC30u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC30u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC30 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_04EC32;
L_04EC32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC32u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC32 LDY
    cpu.setY(0x0u, 8);
    goto L_04EC34;
L_04EC34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC34u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC34u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC34 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EC36;
L_04EC36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC36u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC36u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC36 CLC
    cpu.setFlag('C', false);
    goto L_04EC37;
L_04EC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC37u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC37u, 4u + ((((0xEB56u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xEB56u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC37 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xEB56u), cpu.m8?8:16));
    goto L_04EC3A;
L_04EC3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC3Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC3Au, 5u, 3u, cpu.address("absy", 0x0280u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC3A STA
    hw.write(cpu.address("absy", 0x280u), cpu.a, cpu.m8?8:16);
    goto L_04EC3D;
L_04EC3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC3Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC3Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC3D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EC3F;
L_04EC3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC3Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC3Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC3F CLC
    cpu.setFlag('C', false);
    goto L_04EC40;
L_04EC40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC40u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC40u, 4u + ((((0xEB82u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xEB82u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC40 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xEB82u), cpu.m8?8:16));
    goto L_04EC43;
L_04EC43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC43u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC43u, 5u, 3u, cpu.address("absy", 0x0281u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC43 STA
    hw.write(cpu.address("absy", 0x281u), cpu.a, cpu.m8?8:16);
    goto L_04EC46;
L_04EC46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC46u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC46u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC46 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EC48;
L_04EC48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC48u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC48u, 5u, 3u, cpu.address("absy", 0x0282u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC48 STA
    hw.write(cpu.address("absy", 0x282u), cpu.a, cpu.m8?8:16);
    goto L_04EC4B;
L_04EC4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Bu, 4u + ((((0xEBAEu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xEBAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC4B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xEBAEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04EC4E;
L_04EC4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC4Eu, 5u, 3u, cpu.address("absy", 0x0283u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC4E STA
    hw.write(cpu.address("absy", 0x283u), cpu.a, cpu.m8?8:16);
    goto L_04EC51;
L_04EC51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC51u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC51 INY
    cpu.inc('Y');
    goto L_04EC52;
L_04EC52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC52u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC52u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC52 INY
    cpu.inc('Y');
    goto L_04EC53;
L_04EC53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC53u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC53u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC53 INY
    cpu.inc('Y');
    goto L_04EC54;
L_04EC54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC54u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC54 INY
    cpu.inc('Y');
    goto L_04EC55;
L_04EC55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC55u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC55 INX
    cpu.inc('X');
    goto L_04EC56;
L_04EC56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC56u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC56u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC56 DEC
    cpu.decMem(hw, cpu.address("dp", 0x3u), cpu.m8?8:16);
    goto L_04EC58;
L_04EC58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC58u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC58 BPL -> $04EC34
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04EC34; }
    goto L_04EC5A;
L_04EC5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC5Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC5Au, 4u, 3u, cpu.address("abs", 0x0440u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC5A STZ
    hw.write(cpu.address("abs", 0x440u), 0, cpu.m8?8:16);
    goto L_04EC5D;
L_04EC5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC5Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC5Du, 4u, 3u, cpu.address("abs", 0x0441u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC5D STZ
    hw.write(cpu.address("abs", 0x441u), 0, cpu.m8?8:16);
    goto L_04EC60;
L_04EC60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC60u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC60u, 4u, 3u, cpu.address("abs", 0x0442u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC60 STZ
    hw.write(cpu.address("abs", 0x442u), 0, cpu.m8?8:16);
    goto L_04EC63;
L_04EC63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC63u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC63u, 4u, 3u, cpu.address("abs", 0x0443u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04EC63 STZ
    hw.write(cpu.address("abs", 0x443u), 0, cpu.m8?8:16);
    goto L_04EC66;
L_04EC66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC66u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC66u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04EC66 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04EC66u);return;} hw.unresolvedReturn(0x04EC66u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_07F7D2_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x07F7D2u: goto L_07F7D2;
    case 0x07F7D6u: goto L_07F7D6;
    case 0x07F7DAu: goto L_07F7DA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_07F7D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D2u, 8u, 4u, 0x07F722u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F7D2 JSL -> $07F722 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF7D5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF7D6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F722u, 0x07F7D2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_07F7D6;
L_07F7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF7D6u,0x07F7D6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D6u, 8u, 4u, 0x07F78Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F7D6 JSL -> $07F78B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF7D9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF7DAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F78Bu, 0x07F7D6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_07F7DA;
L_07F7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF7DAu,0x07F7DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F7DA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x07F7DAu);return;} hw.unresolvedReturn(0x07F7DAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_07F7D2_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x07F7D2u: goto L_07F7D2;
    case 0x07F7D6u: goto L_07F7D6;
    case 0x07F7DAu: goto L_07F7DA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_07F7D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D2u, 8u, 4u, 0x07F722u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F7D2 JSL -> $07F722 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF7D5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF7D6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F722u, 0x07F7D2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_07F7D6;
L_07F7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF7D6u,0x07F7D6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D6u, 8u, 4u, 0x07F78Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F7D6 JSL -> $07F78B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF7D9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF7DAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F78Bu, 0x07F7D6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_07F7DA;
L_07F7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF7DAu,0x07F7DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F7DA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x07F7DAu);return;} hw.unresolvedReturn(0x07F7DAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_07F7D2_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x07F7D2u: goto L_07F7D2;
    case 0x07F7D6u: goto L_07F7D6;
    case 0x07F7DAu: goto L_07F7DA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_07F7D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D2u, 8u, 4u, 0x07F722u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F7D2 JSL -> $07F722 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF7D5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF7D6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F722u, 0x07F7D2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_07F7D6;
L_07F7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF7D6u,0x07F7D6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D6u, 8u, 4u, 0x07F78Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F7D6 JSL -> $07F78B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF7D9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF7DAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F78Bu, 0x07F7D6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_07F7DA;
L_07F7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF7DAu,0x07F7DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F7DA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x07F7DAu);return;} hw.unresolvedReturn(0x07F7DAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0CD6EC_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CD6ECu: goto L_0CD6EC;
    case 0x0CD6EFu: goto L_0CD6EF;
    case 0x0CD6F0u: goto L_0CD6F0;
    case 0x0CD6F2u: goto L_0CD6F2;
    case 0x0CD6F4u: goto L_0CD6F4;
    case 0x0CD6F6u: goto L_0CD6F6;
    case 0x0CD6F9u: goto L_0CD6F9;
    case 0x0CD6FAu: goto L_0CD6FA;
    case 0x0CD6FCu: goto L_0CD6FC;
    case 0x0CD6FFu: goto L_0CD6FF;
    case 0x0CD701u: goto L_0CD701;
    case 0x0CD704u: goto L_0CD704;
    case 0x0CD705u: goto L_0CD705;
    case 0x0CD707u: goto L_0CD707;
    case 0x0CD709u: goto L_0CD709;
    case 0x0CD70Au: goto L_0CD70A;
    case 0x0CD70Bu: goto L_0CD70B;
    case 0x0CD70Eu: goto L_0CD70E;
    case 0x0CD710u: goto L_0CD710;
    case 0x0CD713u: goto L_0CD713;
    case 0x0CD715u: goto L_0CD715;
    case 0x0CD717u: goto L_0CD717;
    case 0x0CD718u: goto L_0CD718;
    case 0x0CD719u: goto L_0CD719;
    case 0x0CD71Au: goto L_0CD71A;
    case 0x0CD71Cu: goto L_0CD71C;
    case 0x0CD71Eu: goto L_0CD71E;
    case 0x0CD720u: goto L_0CD720;
    case 0x0CD721u: goto L_0CD721;
    case 0x0CD722u: goto L_0CD722;
    case 0x0CD723u: goto L_0CD723;
    case 0x0CD724u: goto L_0CD724;
    case 0x0CD726u: goto L_0CD726;
    case 0x0CD727u: goto L_0CD727;
    case 0x0CD72Au: goto L_0CD72A;
    case 0x0CD72Cu: goto L_0CD72C;
    case 0x0CD72Eu: goto L_0CD72E;
    case 0x0CD730u: goto L_0CD730;
    case 0x0CD731u: goto L_0CD731;
    case 0x0CD732u: goto L_0CD732;
    case 0x0CD734u: goto L_0CD734;
    case 0x0CD737u: goto L_0CD737;
    case 0x0CD739u: goto L_0CD739;
    case 0x0CD73Au: goto L_0CD73A;
    case 0x0CD73Du: goto L_0CD73D;
    case 0x0CD73Eu: goto L_0CD73E;
    case 0x0CD740u: goto L_0CD740;
    case 0x0CD743u: goto L_0CD743;
    case 0x0CD746u: goto L_0CD746;
    case 0x0CD749u: goto L_0CD749;
    case 0x0CD74Bu: goto L_0CD74B;
    case 0x0CD74Eu: goto L_0CD74E;
    case 0x0CD74Fu: goto L_0CD74F;
    case 0x0CD751u: goto L_0CD751;
    case 0x0CD752u: goto L_0CD752;
    case 0x0CD754u: goto L_0CD754;
    case 0x0CD756u: goto L_0CD756;
    case 0x0CD759u: goto L_0CD759;
    case 0x0CD75Bu: goto L_0CD75B;
    case 0x0CD75Eu: goto L_0CD75E;
    case 0x0CD760u: goto L_0CD760;
    case 0x0CD762u: goto L_0CD762;
    case 0x0CD764u: goto L_0CD764;
    case 0x0CD767u: goto L_0CD767;
    case 0x0CD769u: goto L_0CD769;
    case 0x0CD76Au: goto L_0CD76A;
    case 0x0CD76Cu: goto L_0CD76C;
    case 0x0CD76Eu: goto L_0CD76E;
    case 0x0CD771u: goto L_0CD771;
    case 0x0CD773u: goto L_0CD773;
    case 0x0CD776u: goto L_0CD776;
    case 0x0CD778u: goto L_0CD778;
    case 0x0CD77Bu: goto L_0CD77B;
    case 0x0CD77Du: goto L_0CD77D;
    case 0x0CD780u: goto L_0CD780;
    case 0x0CD781u: goto L_0CD781;
    case 0x0CD783u: goto L_0CD783;
    case 0x0CD785u: goto L_0CD785;
    case 0x0CD787u: goto L_0CD787;
    case 0x0CD789u: goto L_0CD789;
    case 0x0CD78Bu: goto L_0CD78B;
    case 0x0CD78Cu: goto L_0CD78C;
    case 0x0CD78Du: goto L_0CD78D;
    case 0x0CD78Eu: goto L_0CD78E;
    case 0x0CD78Fu: goto L_0CD78F;
    case 0x0CD791u: goto L_0CD791;
    case 0x0CD793u: goto L_0CD793;
    case 0x0CD795u: goto L_0CD795;
    case 0x0CD798u: goto L_0CD798;
    case 0x0CD79Bu: goto L_0CD79B;
    case 0x0CD79Eu: goto L_0CD79E;
    case 0x0CD7A0u: goto L_0CD7A0;
    case 0x0CD7A3u: goto L_0CD7A3;
    case 0x0CD7A5u: goto L_0CD7A5;
    case 0x0CD7A8u: goto L_0CD7A8;
    case 0x0CD7A9u: goto L_0CD7A9;
    case 0x0CD7AAu: goto L_0CD7AA;
    case 0x0CD7ACu: goto L_0CD7AC;
    case 0x0CD7ADu: goto L_0CD7AD;
    case 0x0CD7AFu: goto L_0CD7AF;
    case 0x0CD7B1u: goto L_0CD7B1;
    case 0x0CD7B3u: goto L_0CD7B3;
    case 0x0CD7B5u: goto L_0CD7B5;
    case 0x0CD7B7u: goto L_0CD7B7;
    case 0x0CD7BAu: goto L_0CD7BA;
    case 0x0CD7BCu: goto L_0CD7BC;
    case 0x0CD7BFu: goto L_0CD7BF;
    case 0x0CD7C1u: goto L_0CD7C1;
    case 0x0CD7C2u: goto L_0CD7C2;
    case 0x0CD7C4u: goto L_0CD7C4;
    case 0x0CD7C6u: goto L_0CD7C6;
    case 0x0CD7C8u: goto L_0CD7C8;
    case 0x0CD7C9u: goto L_0CD7C9;
    case 0x0CD7CCu: goto L_0CD7CC;
    case 0x0CD7CEu: goto L_0CD7CE;
    case 0x0CD7D0u: goto L_0CD7D0;
    case 0x0CD7D3u: goto L_0CD7D3;
    case 0x0CD7D4u: goto L_0CD7D4;
    case 0x0CD7D5u: goto L_0CD7D5;
    case 0x0CD7D6u: goto L_0CD7D6;
    case 0x0CD7D8u: goto L_0CD7D8;
    case 0x0CD7DAu: goto L_0CD7DA;
    case 0x0CD7DDu: goto L_0CD7DD;
    case 0x0CD7DEu: goto L_0CD7DE;
    case 0x0CD7DFu: goto L_0CD7DF;
    case 0x0CD7E2u: goto L_0CD7E2;
    case 0x0CD7E5u: goto L_0CD7E5;
    case 0x0CD7E7u: goto L_0CD7E7;
    case 0x0CD7EAu: goto L_0CD7EA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CD6EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6ECu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6ECu, 4u, 3u, cpu.address("abs", 0x144Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD6EC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x144Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD6EF;
L_0CD6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD6EF LSR
    cpu.lsrA();
    goto L_0CD6F0;
L_0CD6F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD6F0 BEQ -> $0CD751
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CD751; }
    goto L_0CD6F2;
L_0CD6F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD6F2 LDY
    cpu.setY(0x4u, 8);
    goto L_0CD6F4;
L_0CD6F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD6F4 LDA
    cpu.setA(0x2u, 8);
    goto L_0CD6F6;
L_0CD6F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F6u, 5u, 3u, cpu.address("absy", 0x0470u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD6F6 STA
    hw.write(cpu.address("absy", 0x470u), cpu.a, cpu.m8?8:16);
    goto L_0CD6F9;
L_0CD6F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F9u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD6F9 DEY
    cpu.decReg('Y');
    goto L_0CD6FA;
L_0CD6FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD6FA BPL -> $0CD6F6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0CD6F6; }
    goto L_0CD6FC;
L_0CD6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FCu, 4u, 3u, cpu.address("abs", 0x1446u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD6FC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1446u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD6FF;
L_0CD6FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD6FF BNE -> $0CD752
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CD752; }
    goto L_0CD701;
L_0CD701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD701u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD701u, 4u, 3u, cpu.address("abs", 0x13DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD701 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13DBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD704;
L_0CD704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD704u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD704u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD704 ASL
    cpu.aslA();
    goto L_0CD705;
L_0CD705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD705u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD705u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD705 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0CD707;
L_0CD707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD707u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD707u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD707 BEQ -> $0CD70A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CD70A; }
    goto L_0CD709;
L_0CD709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD709u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD709u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD709 INC
    cpu.inc('A');
    goto L_0CD70A;
L_0CD70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD70A TAY
    cpu.transfer("TAY");
    goto L_0CD70B;
L_0CD70B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Bu, 4u + ((((0xD6C4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD6C4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD70B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD6C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD70E;
L_0CD70E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD70E STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0CD710;
L_0CD710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD710u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD710u, 4u + ((((0xD6CAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD6CAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD710 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD6CAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD713;
L_0CD713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD713u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD713u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD713 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0CD715;
L_0CD715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD715u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD715u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD715 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD717;
L_0CD717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD717u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD717u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD717 LSR
    cpu.lsrA();
    goto L_0CD718;
L_0CD718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD718u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD718u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD718 ROR
    cpu.rorA();
    goto L_0CD719;
L_0CD719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD719u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD719u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD719 LSR
    cpu.lsrA();
    goto L_0CD71A;
L_0CD71A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Au,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD71A EOR
    cpu.logicXor(0x61u);
    goto L_0CD71C;
L_0CD71C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD71C STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0CD71E;
L_0CD71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD71E LDX
    cpu.setX(0x2u, 8);
    goto L_0CD720;
L_0CD720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD720u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD720u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD720 TXA
    cpu.transfer("TXA");
    goto L_0CD721;
L_0CD721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD721u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD721u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD721 ASL
    cpu.aslA();
    goto L_0CD722;
L_0CD722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD722u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD722u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD722 ASL
    cpu.aslA();
    goto L_0CD723;
L_0CD723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD723u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD723u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD723 TAY
    cpu.transfer("TAY");
    goto L_0CD724;
L_0CD724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD724u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD724u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD724 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD726;
L_0CD726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD726u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD726u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD726 CLC
    cpu.setFlag('C', false);
    goto L_0CD727;
L_0CD727:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD727u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD727u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD727u, 4u + ((((0xD6D0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xD6D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD727 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xD6D0u), cpu.m8?8:16));
    goto L_0CD72A;
L_0CD72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD72Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Au,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD72A BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), false);
    goto L_0CD72C;
L_0CD72C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD72Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Cu,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD72C BVC -> $0CD731
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_0CD731; }
    goto L_0CD72E;
L_0CD72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Eu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD72E EOR
    cpu.logicXor(0xFFu);
    goto L_0CD730;
L_0CD730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD730u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD730u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD730 INC
    cpu.inc('A');
    goto L_0CD731;
L_0CD731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD731u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD731u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD731 CLC
    cpu.setFlag('C', false);
    goto L_0CD732;
L_0CD732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD732u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD732u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD732 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_0CD734;
L_0CD734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD734u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD734u, 5u, 3u, cpu.address("absy", 0x0340u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD734 STA
    hw.write(cpu.address("absy", 0x340u), cpu.a, cpu.m8?8:16);
    goto L_0CD737;
L_0CD737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD737u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD737u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD737 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD739;
L_0CD739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD739u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD739u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD739 CLC
    cpu.setFlag('C', false);
    goto L_0CD73A;
L_0CD73A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Au,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Au, 4u + ((((0xD6D3u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xD6D3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD73A ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xD6D3u), cpu.m8?8:16));
    goto L_0CD73D;
L_0CD73D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD73D CLC
    cpu.setFlag('C', false);
    goto L_0CD73E;
L_0CD73E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Eu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD73E ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16));
    goto L_0CD740;
L_0CD740:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD740u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD740u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD740u, 5u, 3u, cpu.address("absy", 0x0341u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD740 STA
    hw.write(cpu.address("absy", 0x341u), cpu.a, cpu.m8?8:16);
    goto L_0CD743;
L_0CD743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD743u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD743u, 4u + ((((0xD6D6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xD6D6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD743 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xD6D6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD746;
L_0CD746:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD746u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD746u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD746u, 5u, 3u, cpu.address("absy", 0x0342u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD746 STA
    hw.write(cpu.address("absy", 0x342u), cpu.a, cpu.m8?8:16);
    goto L_0CD749;
L_0CD749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD749u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD749u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD749u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD749 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD74B;
L_0CD74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Bu, 5u, 3u, cpu.address("absy", 0x0343u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD74B STA
    hw.write(cpu.address("absy", 0x343u), cpu.a, cpu.m8?8:16);
    goto L_0CD74E;
L_0CD74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD74E DEX
    cpu.decReg('X');
    goto L_0CD74F;
L_0CD74F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD74F BPL -> $0CD720
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0CD720; }
    goto L_0CD751;
L_0CD751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD751u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD751u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CD751 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CD751u);return;} hw.unresolvedReturn(0x0CD751u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_0CD752:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD752u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD752u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD752u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD752 AND
    cpu.logicAnd(0x7u);
    goto L_0CD754;
L_0CD754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD754u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD754u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD754 BNE -> $0CD759
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CD759; }
    goto L_0CD756;
L_0CD756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD756u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD756u, 6u, 3u, cpu.address("abs", 0xD22Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CD756 JSR -> $0CD22D stack real
    { cpu.push16Value(hw,0xD758u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD759u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD22Du), 0x0CD756u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0CD759;
L_0CD759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD759u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD759u,0x0CD759u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD759u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD759u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD759 LDY
    cpu.setY(0x25u, 8);
    goto L_0CD75B;
L_0CD75B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD75Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Bu, 4u, 3u, cpu.address("abs", 0x1446u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD75B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1446u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD75E;
L_0CD75E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD75Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD75E CMP
    cpu.compareA(0x4Cu);
    goto L_0CD760;
L_0CD760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD760u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD760u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD760u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD760 BCC -> $0CD764
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0CD764; }
    goto L_0CD762;
L_0CD762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD762u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD762u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD762 LDY
    cpu.setY(0x38u, 8);
    goto L_0CD764;
L_0CD764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD764u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD764u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD764 STY
    hw.write(cpu.address("abs", 0x13E0u), cpu.y, cpu.x8?8:16);
    goto L_0CD767;
L_0CD767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD767u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD767u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD767 LDY
    cpu.setY(0x0u, 8);
    goto L_0CD769;
L_0CD769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD769u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD769u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD769 DEC
    cpu.decReg('A');
    goto L_0CD76A;
L_0CD76A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD76A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0CD76C;
L_0CD76C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD76C LDA
    cpu.setA(0xACu, 8);
    goto L_0CD76E;
L_0CD76E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Eu, 5u, 3u, cpu.address("absy", 0x0342u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD76E STA
    hw.write(cpu.address("absy", 0x342u), cpu.a, cpu.m8?8:16);
    goto L_0CD771;
L_0CD771:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD771u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD771u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD771u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD771 LDA
    cpu.setA(0x21u, 8);
    goto L_0CD773;
L_0CD773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD773u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD773u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD773u, 5u, 3u, cpu.address("absy", 0x0343u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD773 STA
    hw.write(cpu.address("absy", 0x343u), cpu.a, cpu.m8?8:16);
    goto L_0CD776;
L_0CD776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD776u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD776u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD776 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD778;
L_0CD778:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD778u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD778u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD778u, 5u, 3u, cpu.address("absy", 0x0340u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD778 STA
    hw.write(cpu.address("absy", 0x340u), cpu.a, cpu.m8?8:16);
    goto L_0CD77B;
L_0CD77B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD77B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD77D;
L_0CD77D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Du, 5u, 3u, cpu.address("absy", 0x0341u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD77D STA
    hw.write(cpu.address("absy", 0x341u), cpu.a, cpu.m8?8:16);
    goto L_0CD780;
L_0CD780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD780u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD780u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD780 CLC
    cpu.setFlag('C', false);
    goto L_0CD781;
L_0CD781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD781u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD781u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD781 ADC
    cpu.adc(0x10u);
    goto L_0CD783;
L_0CD783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD783u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD783u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD783 CMP
    cpu.compareA(0x68u);
    goto L_0CD785;
L_0CD785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD785u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD785u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD785 BCC -> $0CD789
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0CD789; }
    goto L_0CD787;
L_0CD787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD787u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD787u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD787 LDA
    cpu.setA(0x68u, 8);
    goto L_0CD789;
L_0CD789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD789u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD789u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD789 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0CD78B;
L_0CD78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD78B INY
    cpu.inc('Y');
    goto L_0CD78C;
L_0CD78C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD78C INY
    cpu.inc('Y');
    goto L_0CD78D;
L_0CD78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD78D INY
    cpu.inc('Y');
    goto L_0CD78E;
L_0CD78E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD78E INY
    cpu.inc('Y');
    goto L_0CD78F;
L_0CD78F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD78F LDA
    cpu.setA(0xAEu, 8);
    goto L_0CD791;
L_0CD791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD791u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD791u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD791 CPY
    cpu.compareY(0x14u);
    goto L_0CD793;
L_0CD793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD793u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD793u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD793 BCC -> $0CD76E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0CD76E; }
    goto L_0CD795;
L_0CD795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD795u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD795u, 4u, 3u, cpu.address("abs", 0x1445u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD795 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1445u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0CD798;
L_0CD798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD798u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD798u, 4u, 3u, cpu.address("abs", 0x1446u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD798 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1446u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD79B;
L_0CD79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Bu,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Bu, 4u + ((((0xD6E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xD6E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD79B CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0xD6E0u), cpu.m8?8:16));
    goto L_0CD79E;
L_0CD79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD79E BNE -> $0CD7DE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CD7DE; }
    goto L_0CD7A0;
L_0CD7A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A0u, 4u, 3u, cpu.address("abs", 0x1449u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7A0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1449u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD7A3;
L_0CD7A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7A3 BEQ -> $0CD7A9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CD7A9; }
    goto L_0CD7A5;
L_0CD7A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A5u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A5u, 6u, 3u, cpu.address("abs", 0x1449u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7A5 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1449u), cpu.m8?8:16);
    goto L_0CD7A8;
L_0CD7A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CD7A8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CD7A8u);return;} hw.unresolvedReturn(0x0CD7A8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_0CD7A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A9u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7A9 TXA
    cpu.transfer("TXA");
    goto L_0CD7AA;
L_0CD7AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7AAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7AA BEQ -> $0CD7C9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CD7C9; }
    goto L_0CD7AC;
L_0CD7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ACu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7AC LSR
    cpu.lsrA();
    goto L_0CD7AD;
L_0CD7AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ADu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7AD BCS -> $0CD7C9
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_0CD7C9; }
    goto L_0CD7AF;
L_0CD7AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7AFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7AFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7AF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD7B1;
L_0CD7B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7B1 AND
    cpu.logicAnd(0x4u);
    goto L_0CD7B3;
L_0CD7B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7B3 BEQ -> $0CD7BA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CD7BA; }
    goto L_0CD7B5;
L_0CD7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7B5 LDA
    cpu.setA(0x39u, 8);
    goto L_0CD7B7;
L_0CD7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B7u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7B7 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    goto L_0CD7BA;
L_0CD7BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7BA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD7BC;
L_0CD7BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BCu,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BCu, 4u + ((((0xD6E5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xD6E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7BC CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0xD6E5u), cpu.m8?8:16));
    goto L_0CD7BF;
L_0CD7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7BF BEQ -> $0CD7C9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CD7C9; }
    goto L_0CD7C1;
L_0CD7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C1u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7C1 INC
    cpu.inc('A');
    goto L_0CD7C2;
L_0CD7C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7C2 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_0CD7C4;
L_0CD7C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7C4 AND
    cpu.logicAnd(0xFu);
    goto L_0CD7C6;
L_0CD7C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7C6 BEQ -> $0CD7E5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CD7E5; }
    goto L_0CD7C8;
L_0CD7C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CD7C8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CD7C8u);return;} hw.unresolvedReturn(0x0CD7C8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_0CD7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C9u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C9u, 6u, 3u, cpu.address("abs", 0x1445u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7C9 INC
    cpu.incMem(hw, cpu.address("abs", 0x1445u), cpu.m8?8:16);
    goto L_0CD7CC;
L_0CD7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CCu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7CC CPX
    cpu.compareX(0x6u);
    goto L_0CD7CE;
L_0CD7CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7CE BCC -> $0CD7D4
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0CD7D4; }
    goto L_0CD7D0;
L_0CD7D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D0u, 4u, 3u, cpu.address("abs", 0x1446u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7D0 STZ
    hw.write(cpu.address("abs", 0x1446u), 0, cpu.m8?8:16);
    goto L_0CD7D3;
L_0CD7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CD7D3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CD7D3u);return;} hw.unresolvedReturn(0x0CD7D3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_0CD7D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7D4 TXA
    cpu.transfer("TXA");
    goto L_0CD7D5;
L_0CD7D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7D5 LSR
    cpu.lsrA();
    goto L_0CD7D6;
L_0CD7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7D6 BCS -> $0CD7DD
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_0CD7DD; }
    goto L_0CD7D8;
L_0CD7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7D8 LDA
    cpu.setA(0xFu, 8);
    goto L_0CD7DA;
L_0CD7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DAu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7DA STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_0CD7DD;
L_0CD7DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CD7DD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CD7DDu);return;} hw.unresolvedReturn(0x0CD7DDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_0CD7DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7DE CLC
    cpu.setFlag('C', false);
    goto L_0CD7DF;
L_0CD7DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DFu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DFu, 4u + ((((0xD6D9u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xD6D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7DF ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xD6D9u), cpu.m8?8:16));
    goto L_0CD7E2;
L_0CD7E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E2u, 4u, 3u, cpu.address("abs", 0x1446u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7E2 STA
    hw.write(cpu.address("abs", 0x1446u), cpu.a, cpu.m8?8:16);
    goto L_0CD7E5;
L_0CD7E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7E5 LDA
    cpu.setA(0x10u, 8);
    goto L_0CD7E7;
L_0CD7E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E7u, 4u, 3u, cpu.address("abs", 0x1449u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD7E7 STA
    hw.write(cpu.address("abs", 0x1449u), cpu.a, cpu.m8?8:16);
    goto L_0CD7EA;
L_0CD7EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CD7EA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CD7EAu);return;} hw.unresolvedReturn(0x0CD7EAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DB3E3_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB3E3u: goto L_0DB3E3;
    case 0x0DB3E5u: goto L_0DB3E5;
    case 0x0DB3E7u: goto L_0DB3E7;
    case 0x0DB3E9u: goto L_0DB3E9;
    case 0x0DB3EBu: goto L_0DB3EB;
    case 0x0DB3EDu: goto L_0DB3ED;
    case 0x0DB3EFu: goto L_0DB3EF;
    case 0x0DB3F0u: goto L_0DB3F0;
    case 0x0DB3F1u: goto L_0DB3F1;
    case 0x0DB3F2u: goto L_0DB3F2;
    case 0x0DB3F3u: goto L_0DB3F3;
    case 0x0DB3F5u: goto L_0DB3F5;
    case 0x0DB3F6u: goto L_0DB3F6;
    case 0x0DB3F7u: goto L_0DB3F7;
    case 0x0DB3F9u: goto L_0DB3F9;
    case 0x0DB3FAu: goto L_0DB3FA;
    case 0x0DB3FDu: goto L_0DB3FD;
    case 0x0DB400u: goto L_0DB400;
    case 0x0DB404u: goto L_0DB404;
    case 0x0DB407u: goto L_0DB407;
    case 0x0DB409u: goto L_0DB409;
    case 0x0DB40Bu: goto L_0DB40B;
    case 0x0DB40Eu: goto L_0DB40E;
    case 0x0DB411u: goto L_0DB411;
    case 0x0DB415u: goto L_0DB415;
    case 0x0DB418u: goto L_0DB418;
    case 0x0DB41Au: goto L_0DB41A;
    case 0x0DB41Cu: goto L_0DB41C;
    case 0x0DB41Fu: goto L_0DB41F;
    case 0x0DB422u: goto L_0DB422;
    case 0x0DB424u: goto L_0DB424;
    case 0x0DB426u: goto L_0DB426;
    case 0x0DB428u: goto L_0DB428;
    case 0x0DB42Au: goto L_0DB42A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB3E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E3u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3E3 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB3E5;
L_0DB3E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3E5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB3E7;
L_0DB3E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3E7 AND
    cpu.logicAnd(0xFu);
    goto L_0DB3E9;
L_0DB3E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3E9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DB3EB;
L_0DB3EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3EB STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DB3ED;
L_0DB3ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3ED LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB3EF;
L_0DB3EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3EF LSR
    cpu.lsrA();
    goto L_0DB3F0;
L_0DB3F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3F0 LSR
    cpu.lsrA();
    goto L_0DB3F1;
L_0DB3F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3F1 LSR
    cpu.lsrA();
    goto L_0DB3F2;
L_0DB3F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3F2 LSR
    cpu.lsrA();
    goto L_0DB3F3;
L_0DB3F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3F3 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DB3F5;
L_0DB3F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3F5 TXA
    cpu.transfer("TXA");
    goto L_0DB3F6;
L_0DB3F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3F6 SEC
    cpu.setFlag('C', true);
    goto L_0DB3F7;
L_0DB3F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F7u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3F7 SBC
    cpu.sbc(0x17u);
    goto L_0DB3F9;
L_0DB3F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3F9 TAX
    cpu.transfer("TAX");
    goto L_0DB3FA;
L_0DB3FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FAu, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB3FA JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xB3FCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3FDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DB3FAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB3FD;
L_0DB3FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3FDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3FDu,0x0DB3FDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FDu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB3FD JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB3FFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB400u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB3FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB400;
L_0DB400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB400u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB400u,0x0DB400u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB400u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB400u, 5u, 4u, ((0x0DB3DBu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB400 LDA
    cpu.loadA(hw.readW(((0xDB3DBu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB404;
L_0DB404:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB404u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB404u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB404u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB404 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB406u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB407u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB404u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB407;
L_0DB407:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB407u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB407u,0x0DB407u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB407u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB407u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB407 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DB409;
L_0DB409:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB409u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB409u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB409u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB409 BPL -> $0DB3FD
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB3FD; }
    goto L_0DB40B;
L_0DB40B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB40Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Bu, 3u, 3u, cpu.address("abs", 0xB41Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB40B JMP -> $0DB41C
    goto L_0DB41C;
L_0DB40E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB40Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB40Eu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB40E JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB410u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB411u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB40Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB411;
L_0DB411:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB411u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB411u,0x0DB411u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB411u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB411u, 5u, 4u, ((0x0DB3DFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB411 LDA
    cpu.loadA(hw.readW(((0xDB3DFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB415;
L_0DB415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB415u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB415u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB415 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB417u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB418u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB415u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB418;
L_0DB418:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB418u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB418u,0x0DB418u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB418u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB418u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB418 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DB41A;
L_0DB41A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB41A BPL -> $0DB40E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB40E; }
    goto L_0DB41C;
L_0DB41C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Cu, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB41C JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xB41Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB41Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DB41Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB41F;
L_0DB41F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB41Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB41Fu,0x0DB41Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB41Fu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB41F JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xB421u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB422u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DB41Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB422;
L_0DB422:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB422u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB422u,0x0DB422u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB422u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB422u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB422 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB424;
L_0DB424:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB424u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB424u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB424u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB424 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DB426;
L_0DB426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB426u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB426u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB426 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DB428;
L_0DB428:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB428u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB428u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB428u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB428 BPL -> $0DB40E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB40E; }
    goto L_0DB42A;
L_0DB42A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB42Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB42Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB42A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB42Au);return;} hw.unresolvedReturn(0x0DB42Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DBB2C_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DBB2Cu: goto L_0DBB2C;
    case 0x0DBB2Eu: goto L_0DBB2E;
    case 0x0DBB30u: goto L_0DBB30;
    case 0x0DBB31u: goto L_0DBB31;
    case 0x0DBB32u: goto L_0DBB32;
    case 0x0DBB33u: goto L_0DBB33;
    case 0x0DBB34u: goto L_0DBB34;
    case 0x0DBB35u: goto L_0DBB35;
    case 0x0DBB38u: goto L_0DBB38;
    case 0x0DBB3Bu: goto L_0DBB3B;
    case 0x0DBB3Du: goto L_0DBB3D;
    case 0x0DBB40u: goto L_0DBB40;
    case 0x0DBB43u: goto L_0DBB43;
    case 0x0DBB45u: goto L_0DBB45;
    case 0x0DBB47u: goto L_0DBB47;
    case 0x0DBB4Au: goto L_0DBB4A;
    case 0x0DBB4Du: goto L_0DBB4D;
    case 0x0DBB4Fu: goto L_0DBB4F;
    case 0x0DBB52u: goto L_0DBB52;
    case 0x0DBB55u: goto L_0DBB55;
    case 0x0DBB57u: goto L_0DBB57;
    case 0x0DBB59u: goto L_0DBB59;
    case 0x0DBB5Cu: goto L_0DBB5C;
    case 0x0DBB5Fu: goto L_0DBB5F;
    case 0x0DBB60u: goto L_0DBB60;
    case 0x0DBB62u: goto L_0DBB62;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DBB2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DBB2C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DBB2E;
L_0DBB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DBB2E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DBB30;
L_0DBB30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB30u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB30u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DBB30 LSR
    cpu.lsrA();
    goto L_0DBB31;
L_0DBB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB31u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DBB31 LSR
    cpu.lsrA();
    goto L_0DBB32;
L_0DBB32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB32u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DBB32 LSR
    cpu.lsrA();
    goto L_0DBB33;
L_0DBB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB33u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB33u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DBB33 LSR
    cpu.lsrA();
    goto L_0DBB34;
L_0DBB34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB34u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DBB34 TAX
    cpu.transfer("TAX");
    goto L_0DBB35;
L_0DBB35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB35u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB35u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DBB35 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xBB37u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB38u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DBB35u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DBB38;
L_0DBB38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB38u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB38u,0x0DBB38u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB38u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB38u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DBB38 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xBB3Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB3Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DBB38u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DBB3B;
L_0DBB3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB3Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB3Bu,0x0DBB3Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DBB3B LDA
    cpu.setA(0x61u, 8);
    goto L_0DBB3D;
L_0DBB3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB3Du, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DBB3D JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xBB3Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB40u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DBB3Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DBB40;
L_0DBB40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB40u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB40u,0x0DBB40u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB40u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB40u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DBB40 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xBB42u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB43u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DBB40u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DBB43;
L_0DBB43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB43u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB43u,0x0DBB43u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DBB43 LDA
    cpu.setA(0x62u, 8);
    goto L_0DBB45;
L_0DBB45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB45u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB45u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DBB45 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DBB47;
L_0DBB47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB47u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB47u, 3u, 3u, cpu.address("abs", 0xBB59u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DBB47 JMP -> $0DBB59
    goto L_0DBB59;
L_0DBB4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Au, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DBB4A JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xBB4Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB4Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DBB4Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DBB4D;
L_0DBB4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB4Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB4Du,0x0DBB4Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DBB4D LDA
    cpu.setA(0x63u, 8);
    goto L_0DBB4F;
L_0DBB4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB4Fu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DBB4F JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xBB51u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB52u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DBB4Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DBB52;
L_0DBB52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB52u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB52u,0x0DBB52u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB52u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB52u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DBB52 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xBB54u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB55u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DBB52u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DBB55;
L_0DBB55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB55u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB55u,0x0DBB55u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB55u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DBB55 LDA
    cpu.setA(0x64u, 8);
    goto L_0DBB57;
L_0DBB57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB57u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB57u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DBB57 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DBB59;
L_0DBB59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB59u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB59u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DBB59 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xBB5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB5Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DBB59u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DBB5C;
L_0DBB5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB5Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB5Cu,0x0DBB5Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Cu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DBB5C JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xBB5Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB5Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DBB5Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DBB5F;
L_0DBB5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB5Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB5Fu,0x0DBB5Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DBB5F DEX
    cpu.decReg('X');
    goto L_0DBB60;
L_0DBB60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB60u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DBB60 BPL -> $0DBB4A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DBB4A; }
    goto L_0DBB62;
L_0DBB62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB62u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB62u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DBB62 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DBB62u);return;} hw.unresolvedReturn(0x0DBB62u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DCF6E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DCF6Eu: goto L_0DCF6E;
    case 0x0DCF70u: goto L_0DCF70;
    case 0x0DCF72u: goto L_0DCF72;
    case 0x0DCF73u: goto L_0DCF73;
    case 0x0DCF74u: goto L_0DCF74;
    case 0x0DCF75u: goto L_0DCF75;
    case 0x0DCF76u: goto L_0DCF76;
    case 0x0DCF77u: goto L_0DCF77;
    case 0x0DCF7Au: goto L_0DCF7A;
    case 0x0DCF7Du: goto L_0DCF7D;
    case 0x0DCF7Fu: goto L_0DCF7F;
    case 0x0DCF82u: goto L_0DCF82;
    case 0x0DCF85u: goto L_0DCF85;
    case 0x0DCF87u: goto L_0DCF87;
    case 0x0DCF89u: goto L_0DCF89;
    case 0x0DCF8Cu: goto L_0DCF8C;
    case 0x0DCF8Eu: goto L_0DCF8E;
    case 0x0DCF8Fu: goto L_0DCF8F;
    case 0x0DCF91u: goto L_0DCF91;
    case 0x0DCF92u: goto L_0DCF92;
    case 0x0DCF94u: goto L_0DCF94;
    case 0x0DCF97u: goto L_0DCF97;
    case 0x0DCF98u: goto L_0DCF98;
    case 0x0DCF9Au: goto L_0DCF9A;
    case 0x0DCF9Cu: goto L_0DCF9C;
    case 0x0DCF9Eu: goto L_0DCF9E;
    case 0x0DCF9Fu: goto L_0DCF9F;
    case 0x0DCFA0u: goto L_0DCFA0;
    case 0x0DCFA2u: goto L_0DCFA2;
    case 0x0DCFA3u: goto L_0DCFA3;
    case 0x0DCFA5u: goto L_0DCFA5;
    case 0x0DCFA8u: goto L_0DCFA8;
    case 0x0DCFABu: goto L_0DCFAB;
    case 0x0DCFADu: goto L_0DCFAD;
    case 0x0DCFAEu: goto L_0DCFAE;
    case 0x0DCFB0u: goto L_0DCFB0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DCF6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF6E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DCF70;
L_0DCF70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF70u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF70u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF70 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCF72;
L_0DCF72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF72u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF72u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF72 LSR
    cpu.lsrA();
    goto L_0DCF73;
L_0DCF73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF73u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF73u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF73 LSR
    cpu.lsrA();
    goto L_0DCF74;
L_0DCF74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF74u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF74u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF74 LSR
    cpu.lsrA();
    goto L_0DCF75;
L_0DCF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF75u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF75u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF75 LSR
    cpu.lsrA();
    goto L_0DCF76;
L_0DCF76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF76u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF76u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF76 TAX
    cpu.transfer("TAX");
    goto L_0DCF77;
L_0DCF77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF77u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF77u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCF77 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xCF79u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF7Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DCF77u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCF7A;
L_0DCF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF7Au,0x0DCF7Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Au, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCF7A JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xCF7Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF7Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DCF7Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCF7D;
L_0DCF7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF7Du,0x0DCF7Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF7D LDA
    cpu.setA(0x8Cu, 8);
    goto L_0DCF7F;
L_0DCF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCF7F JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xCF81u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF82u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DCF7Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCF82;
L_0DCF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF82u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF82u,0x0DCF82u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF82u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCF82 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xCF84u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF85u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DCF82u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCF85;
L_0DCF85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF85u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF85u,0x0DCF85u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF85u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF85 LDA
    cpu.setA(0x8Du, 8);
    goto L_0DCF87;
L_0DCF87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF87u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF87u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DCF87 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DCF89;
L_0DCF89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF89u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF89u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCF89 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xCF8Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF8Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DCF89u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCF8C;
L_0DCF8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF8Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF8Cu,0x0DCF8Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF8C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x57u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCF8E;
L_0DCF8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF8E CLC
    cpu.setFlag('C', false);
    goto L_0DCF8F;
L_0DCF8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF8F ADC
    cpu.adc(0xEu);
    goto L_0DCF91;
L_0DCF91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF91u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF91u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF91 TAY
    cpu.transfer("TAY");
    goto L_0DCF92;
L_0DCF92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF92u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF92 BCC -> $0DCF97
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DCF97; }
    goto L_0DCF94;
L_0DCF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF94u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF94u, 6u, 3u, cpu.address("abs", 0xA987u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCF94 JSR -> $0DA987 stack real
    { cpu.push16Value(hw,0xCF96u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF97u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA987u), 0x0DCF94u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCF97;
L_0DCF97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF97u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF97u,0x0DCF97u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF97u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF97u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF97 TYA
    cpu.transfer("TYA");
    goto L_0DCF98;
L_0DCF98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF98u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF98 AND
    cpu.logicAnd(0xFu);
    goto L_0DCF9A;
L_0DCF9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF9A CMP
    cpu.compareA(0xEu);
    goto L_0DCF9C;
L_0DCF9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF9C BMI -> $0DCFAB
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DCFAB; }
    goto L_0DCF9E;
L_0DCF9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Eu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF9E TYA
    cpu.transfer("TYA");
    goto L_0DCF9F;
L_0DCF9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF9F CLC
    cpu.setFlag('C', false);
    goto L_0DCFA0;
L_0DCFA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFA0 ADC
    cpu.adc(0x10u);
    goto L_0DCFA2;
L_0DCFA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA2u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFA2 TAY
    cpu.transfer("TAY");
    goto L_0DCFA3;
L_0DCFA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFA3 BCC -> $0DCFA8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DCFA8; }
    goto L_0DCFA5;
L_0DCFA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA5u, 6u, 3u, cpu.address("abs", 0xA987u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCFA5 JSR -> $0DA987 stack real
    { cpu.push16Value(hw,0xCFA7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCFA8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA987u), 0x0DCFA5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCFA8;
L_0DCFA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCFA8u,0x0DCFA8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA8u, 6u, 3u, cpu.address("abs", 0xA9D6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCFA8 JSR -> $0DA9D6 stack real
    { cpu.push16Value(hw,0xCFAAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCFABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA9D6u), 0x0DCFA8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCFAB;
L_0DCFAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFABu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCFABu,0x0DCFABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFABu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFABu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFAB STY
    hw.write(cpu.address("dp", 0x57u), cpu.y, cpu.x8?8:16);
    goto L_0DCFAD;
L_0DCFAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFADu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFAD DEX
    cpu.decReg('X');
    goto L_0DCFAE;
L_0DCFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFAEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFAEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCFAE BPL -> $0DCF7A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DCF7A; }
    goto L_0DCFB0;
L_0DCFB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCFB0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DCFB0u);return;} hw.unresolvedReturn(0x0DCFB0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DD145_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DD145u: goto L_0DD145;
    case 0x0DD147u: goto L_0DD147;
    case 0x0DD149u: goto L_0DD149;
    case 0x0DD14Bu: goto L_0DD14B;
    case 0x0DD14Du: goto L_0DD14D;
    case 0x0DD14Fu: goto L_0DD14F;
    case 0x0DD150u: goto L_0DD150;
    case 0x0DD151u: goto L_0DD151;
    case 0x0DD152u: goto L_0DD152;
    case 0x0DD153u: goto L_0DD153;
    case 0x0DD155u: goto L_0DD155;
    case 0x0DD158u: goto L_0DD158;
    case 0x0DD15Au: goto L_0DD15A;
    case 0x0DD15Du: goto L_0DD15D;
    case 0x0DD15Fu: goto L_0DD15F;
    case 0x0DD162u: goto L_0DD162;
    case 0x0DD165u: goto L_0DD165;
    case 0x0DD167u: goto L_0DD167;
    case 0x0DD16Au: goto L_0DD16A;
    case 0x0DD16Bu: goto L_0DD16B;
    case 0x0DD16Du: goto L_0DD16D;
    case 0x0DD170u: goto L_0DD170;
    case 0x0DD172u: goto L_0DD172;
    case 0x0DD175u: goto L_0DD175;
    case 0x0DD178u: goto L_0DD178;
    case 0x0DD17Au: goto L_0DD17A;
    case 0x0DD17Du: goto L_0DD17D;
    case 0x0DD17Fu: goto L_0DD17F;
    case 0x0DD181u: goto L_0DD181;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DD145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD145u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD145u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD145 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DD147;
L_0DD147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD147u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD147u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD147 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DD149;
L_0DD149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD149u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD149u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD149 AND
    cpu.logicAnd(0xFu);
    goto L_0DD14B;
L_0DD14B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD14Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD14Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD14Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD14B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DD14D;
L_0DD14D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD14Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD14Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD14Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD14D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DD14F;
L_0DD14F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD14Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD14Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD14Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD14F LSR
    cpu.lsrA();
    goto L_0DD150;
L_0DD150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD150u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD150u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD150u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD150 LSR
    cpu.lsrA();
    goto L_0DD151;
L_0DD151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD151u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD151u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD151u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD151 LSR
    cpu.lsrA();
    goto L_0DD152;
L_0DD152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD152u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD152u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD152 LSR
    cpu.lsrA();
    goto L_0DD153;
L_0DD153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD153u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD153u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD153 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DD155;
L_0DD155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD155u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD155u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD155 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xD157u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD158u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DD155u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD158;
L_0DD158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD158u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD158u,0x0DD158u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD158u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD158u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD158 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DD15A;
L_0DD15A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD15Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD15Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD15Au, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD15A JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xD15Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD15Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DD15Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD15D;
L_0DD15D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD15Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD15Du,0x0DD15Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD15Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD15Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD15D LDA
    cpu.setA(0x73u, 8);
    goto L_0DD15F;
L_0DD15F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD15Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD15Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD15Fu, 3u, 3u, cpu.address("abs", 0xD167u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD15F JMP -> $0DD167
    goto L_0DD167;
L_0DD162:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD162u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD162u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD162u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD162 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xD164u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD165u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DD162u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD165;
L_0DD165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD165u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD165u,0x0DD165u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD165u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD165u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD165 LDA
    cpu.setA(0x74u, 8);
    goto L_0DD167;
L_0DD167:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD167u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD167u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD167u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD167 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xD169u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD16Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DD167u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD16A;
L_0DD16A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD16Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD16Au,0x0DD16Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Au,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD16A DEX
    cpu.decReg('X');
    goto L_0DD16B;
L_0DD16B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD16Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD16B BNE -> $0DD162
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DD162; }
    goto L_0DD16D;
L_0DD16D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD16Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Du, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD16D JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xD16Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD170u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DD16Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD170;
L_0DD170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD170u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD170u,0x0DD170u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD170u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD170u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD170 LDA
    cpu.setA(0x75u, 8);
    goto L_0DD172;
L_0DD172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD172u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD172u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD172 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xD174u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD175u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DD172u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD175;
L_0DD175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD175u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD175u,0x0DD175u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD175u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD175u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD175 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xD177u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD178u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DD175u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD178;
L_0DD178:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD178u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD178u,0x0DD178u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD178u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD178u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD178 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DD17A;
L_0DD17A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD17Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Au, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD17A JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xD17Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD17Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DD17Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DD17D;
L_0DD17D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD17Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD17Du,0x0DD17Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Du,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD17D DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DD17F;
L_0DD17F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD17Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DD17F BPL -> $0DD158
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DD158; }
    goto L_0DD181;
L_0DD181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD181u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD181u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD181u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DD181 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DD181u);return;} hw.unresolvedReturn(0x0DD181u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DEC5C_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DEC5Cu: goto L_0DEC5C;
    case 0x0DEC5Eu: goto L_0DEC5E;
    case 0x0DEC61u: goto L_0DEC61;
    case 0x0DEC63u: goto L_0DEC63;
    case 0x0DEC65u: goto L_0DEC65;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DEC5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC5Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC5Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEC5C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DEC5E;
L_0DEC5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC5Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC5Eu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEC5E JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xEC60u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEC61u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DEC5Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEC61;
L_0DEC61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC61u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEC61u,0x0DEC61u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC61u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEC61 LDA
    cpu.setA(0x10u, 8);
    goto L_0DEC63;
L_0DEC63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC63u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC63u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DEC63 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DEC65;
L_0DEC65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEC65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEC65u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEC65u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEC65 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DEC65u);return;} hw.unresolvedReturn(0x0DEC65u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_808D00_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808C8Fu: goto L_808C8F;
    case 0x808C91u: goto L_808C91;
    case 0x808C93u: goto L_808C93;
    case 0x808C96u: goto L_808C96;
    case 0x808C99u: goto L_808C99;
    case 0x808C9Cu: goto L_808C9C;
    case 0x808C9Fu: goto L_808C9F;
    case 0x808CA2u: goto L_808CA2;
    case 0x808CA3u: goto L_808CA3;
    case 0x808CA6u: goto L_808CA6;
    case 0x808CA7u: goto L_808CA7;
    case 0x808CA8u: goto L_808CA8;
    case 0x808CA9u: goto L_808CA9;
    case 0x808CACu: goto L_808CAC;
    case 0x808CAFu: goto L_808CAF;
    case 0x808CB3u: goto L_808CB3;
    case 0x808CB6u: goto L_808CB6;
    case 0x808CB7u: goto L_808CB7;
    case 0x808CBAu: goto L_808CBA;
    case 0x808CBBu: goto L_808CBB;
    case 0x808CBEu: goto L_808CBE;
    case 0x808CBFu: goto L_808CBF;
    case 0x808D00u: goto L_808D00;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808C8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x28u) & 0xFFFFu), 2u, 0u);
    // $808C8F AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0x28u), cpu.m8?8:16));
    goto L_808C91;
L_808C91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C91 BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0x28u), cpu.m8?8:16), false);
    goto L_808C93;
L_808C93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C93u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C93u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $808C93 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8C95u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C96u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x808C93u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808C96;
L_808C96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C96u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C96u,0x808C96u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C96u,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C96u, 4u + ((((0x3CFCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x3CFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C96 BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x3CFCu), cpu.m8?8:16), false);
    goto L_808C99;
L_808C99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C99u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C99u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC3Cu + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $808C99 JSR (FC3C,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC3Cu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8C9Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C9Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x808C99u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808C9C;
L_808C9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C9Cu,0x808C9Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Cu,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Cu, 4u + ((((0x38FCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x38FCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C9C BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x38FCu), cpu.m8?8:16), false);
    goto L_808C9F;
L_808C9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Fu,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Fu, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x4A38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $808C9F JSR (4A38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x4A38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CA1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CA2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x808C9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808CA2;
L_808CA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CA2u,0x808CA2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA2 SEC
    cpu.setFlag('C', true);
    goto L_808CA3;
L_808CA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $808CA3 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CA5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CA6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x808CA3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808CA6;
L_808CA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CA6u,0x808CA6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA6 SEC
    cpu.setFlag('C', true);
    goto L_808CA7;
L_808CA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA7 LSR
    cpu.lsrA();
    goto L_808CA8;
L_808CA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u,cpu,0x78u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CA8 SEI
    cpu.setFlag('I', true);
    goto L_808CA9;
L_808CA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x3D38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $808CA9 JSR (3D38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x3D38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CACu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x808CA9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808CAC;
L_808CAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CACu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CACu,0x808CACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu, 4u + ((((0x3C3Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x3C3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CAC BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x3C3Eu), cpu.m8?8:16), false);
    goto L_808CAF;
L_808CAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu, 5u, 4u, ((0x38FC3Cu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CAF AND
    cpu.logicAnd(hw.readW(((0x38FC3Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_808CB3;
L_808CB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB3u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB3u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $808CB3 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CB6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x808CB3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808CB6;
L_808CB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CB6u,0x808CB6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CB6 SEC
    cpu.setFlag('C', true);
    goto L_808CB7;
L_808CB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u,cpu,0x2Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u, 6u, 3u, cpu.address("abs", 0x263Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CB7 ROL
    cpu.rolMem(hw, cpu.address("abs", 0x263Cu), cpu.m8?8:16);
    goto L_808CBA;
L_808CBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CBA SEC
    cpu.setFlag('C', true);
    goto L_808CBB;
L_808CBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBBu,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBBu, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $808CBB JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CBDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CBEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x808CBBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808CBE;
L_808CBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CBEu,0x808CBEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808CBE SEC
    cpu.setFlag('C', true);
    goto L_808CBF;
L_808CBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBFu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBFu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $808CBF BRK
    hw.partial(0x808CBFu, "BRK"); return;
L_808D00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D00u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D00u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D00 BRA -> $808C8F
    goto L_808C8F;
}

