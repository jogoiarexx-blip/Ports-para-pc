#include "generated.hpp"
void sub_008A79_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008A79u: goto L_008A79;
    case 0x008A7Cu: goto L_008A7C;
    case 0x008A7Fu: goto L_008A7F;
    case 0x008A81u: goto L_008A81;
    case 0x008A84u: goto L_008A84;
    case 0x008A86u: goto L_008A86;
    case 0x008A89u: goto L_008A89;
    case 0x008A8Bu: goto L_008A8B;
    case 0x008A8Eu: goto L_008A8E;
    case 0x008A90u: goto L_008A90;
    case 0x008A93u: goto L_008A93;
    case 0x008A95u: goto L_008A95;
    case 0x008A98u: goto L_008A98;
    case 0x008A9Au: goto L_008A9A;
    case 0x008A9Cu: goto L_008A9C;
    case 0x008A9Eu: goto L_008A9E;
    case 0x008AA1u: goto L_008AA1;
    case 0x008AA4u: goto L_008AA4;
    case 0x008AA7u: goto L_008AA7;
    case 0x008AAAu: goto L_008AAA;
    case 0x008AACu: goto L_008AAC;
    case 0x008AAEu: goto L_008AAE;
    case 0x008AB0u: goto L_008AB0;
    case 0x008AB3u: goto L_008AB3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008A79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A79u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A79u, 4u, 3u, cpu.address("abs", 0x2133u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A79 STZ
    hw.write(cpu.address("abs", 0x2133u), 0, cpu.m8?8:16);
    goto L_008A7C;
L_008A7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Cu, 4u, 3u, cpu.address("abs", 0x2106u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A7C STZ
    hw.write(cpu.address("abs", 0x2106u), 0, cpu.m8?8:16);
    goto L_008A7F;
L_008A7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A7F LDA
    cpu.setA(0x23u, 8);
    goto L_008A81;
L_008A81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A81u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A81u, 4u, 3u, cpu.address("abs", 0x2107u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A81 STA
    hw.write(cpu.address("abs", 0x2107u), cpu.a, cpu.m8?8:16);
    goto L_008A84;
L_008A84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A84u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A84 LDA
    cpu.setA(0x33u, 8);
    goto L_008A86;
L_008A86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A86u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A86u, 4u, 3u, cpu.address("abs", 0x2108u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A86 STA
    hw.write(cpu.address("abs", 0x2108u), cpu.a, cpu.m8?8:16);
    goto L_008A89;
L_008A89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A89 LDA
    cpu.setA(0x53u, 8);
    goto L_008A8B;
L_008A8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Bu, 4u, 3u, cpu.address("abs", 0x2109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A8B STA
    hw.write(cpu.address("abs", 0x2109u), cpu.a, cpu.m8?8:16);
    goto L_008A8E;
L_008A8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A8E LDA
    cpu.setA(0x0u, 8);
    goto L_008A90;
L_008A90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A90u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A90u, 4u, 3u, cpu.address("abs", 0x210Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A90 STA
    hw.write(cpu.address("abs", 0x210Bu), cpu.a, cpu.m8?8:16);
    goto L_008A93;
L_008A93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A93u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A93 LDA
    cpu.setA(0x4u, 8);
    goto L_008A95;
L_008A95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A95u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A95u, 4u, 3u, cpu.address("abs", 0x210Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A95 STA
    hw.write(cpu.address("abs", 0x210Cu), cpu.a, cpu.m8?8:16);
    goto L_008A98;
L_008A98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A98u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A98u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A98 STZ
    hw.write(cpu.address("dp", 0x41u), 0, cpu.m8?8:16);
    goto L_008A9A;
L_008A9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A9A STZ
    hw.write(cpu.address("dp", 0x42u), 0, cpu.m8?8:16);
    goto L_008A9C;
L_008A9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A9C STZ
    hw.write(cpu.address("dp", 0x43u), 0, cpu.m8?8:16);
    goto L_008A9E;
L_008A9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Eu, 4u, 3u, cpu.address("abs", 0x212Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008A9E STZ
    hw.write(cpu.address("abs", 0x212Au), 0, cpu.m8?8:16);
    goto L_008AA1;
L_008AA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA1u, 4u, 3u, cpu.address("abs", 0x212Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AA1 STZ
    hw.write(cpu.address("abs", 0x212Bu), 0, cpu.m8?8:16);
    goto L_008AA4;
L_008AA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA4u, 4u, 3u, cpu.address("abs", 0x212Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AA4 STZ
    hw.write(cpu.address("abs", 0x212Eu), 0, cpu.m8?8:16);
    goto L_008AA7;
L_008AA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA7u, 4u, 3u, cpu.address("abs", 0x212Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AA7 STZ
    hw.write(cpu.address("abs", 0x212Fu), 0, cpu.m8?8:16);
    goto L_008AAA;
L_008AAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AAA LDA
    cpu.setA(0x2u, 8);
    goto L_008AAC;
L_008AAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AACu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AAC STA
    hw.write(cpu.address("dp", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_008AAE;
L_008AAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AAE LDA
    cpu.setA(0x80u, 8);
    goto L_008AB0;
L_008AB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB0u, 4u, 3u, cpu.address("abs", 0x211Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008AB0 STA
    hw.write(cpu.address("abs", 0x211Au), cpu.a, cpu.m8?8:16);
    goto L_008AB3;
L_008AB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008AB3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008AB3u);return;} hw.unresolvedReturn(0x008AB3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_008D00_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008C8Fu: goto L_008C8F;
    case 0x008C91u: goto L_008C91;
    case 0x008C93u: goto L_008C93;
    case 0x008C96u: goto L_008C96;
    case 0x008C99u: goto L_008C99;
    case 0x008C9Cu: goto L_008C9C;
    case 0x008C9Fu: goto L_008C9F;
    case 0x008CA2u: goto L_008CA2;
    case 0x008CA3u: goto L_008CA3;
    case 0x008CA6u: goto L_008CA6;
    case 0x008CA7u: goto L_008CA7;
    case 0x008CA8u: goto L_008CA8;
    case 0x008CA9u: goto L_008CA9;
    case 0x008CACu: goto L_008CAC;
    case 0x008CAFu: goto L_008CAF;
    case 0x008CB3u: goto L_008CB3;
    case 0x008CB6u: goto L_008CB6;
    case 0x008CB7u: goto L_008CB7;
    case 0x008CBAu: goto L_008CBA;
    case 0x008CBBu: goto L_008CBB;
    case 0x008CBEu: goto L_008CBE;
    case 0x008CBFu: goto L_008CBF;
    case 0x008CC1u: goto L_008CC1;
    case 0x008CC3u: goto L_008CC3;
    case 0x008CC6u: goto L_008CC6;
    case 0x008CC7u: goto L_008CC7;
    case 0x008CCAu: goto L_008CCA;
    case 0x008CCBu: goto L_008CCB;
    case 0x008CCEu: goto L_008CCE;
    case 0x008CCFu: goto L_008CCF;
    case 0x008CD1u: goto L_008CD1;
    case 0x008CD4u: goto L_008CD4;
    case 0x008CD5u: goto L_008CD5;
    case 0x008CD8u: goto L_008CD8;
    case 0x008CD9u: goto L_008CD9;
    case 0x008CDCu: goto L_008CDC;
    case 0x008CDDu: goto L_008CDD;
    case 0x008CDEu: goto L_008CDE;
    case 0x008CDFu: goto L_008CDF;
    case 0x008CE2u: goto L_008CE2;
    case 0x008CE5u: goto L_008CE5;
    case 0x008CE7u: goto L_008CE7;
    case 0x008CEAu: goto L_008CEA;
    case 0x008CEBu: goto L_008CEB;
    case 0x008CEEu: goto L_008CEE;
    case 0x008CEFu: goto L_008CEF;
    case 0x008CF2u: goto L_008CF2;
    case 0x008CF3u: goto L_008CF3;
    case 0x008CF6u: goto L_008CF6;
    case 0x008CF7u: goto L_008CF7;
    case 0x008CF8u: goto L_008CF8;
    case 0x008CF9u: goto L_008CF9;
    case 0x008CFAu: goto L_008CFA;
    case 0x008CFBu: goto L_008CFB;
    case 0x008CFCu: goto L_008CFC;
    case 0x008CFDu: goto L_008CFD;
    case 0x008CFEu: goto L_008CFE;
    case 0x008CFFu: goto L_008CFF;
    case 0x008D00u: goto L_008D00;
    case 0x008D01u: goto L_008D01;
    case 0x008D04u: goto L_008D04;
    case 0x008D06u: goto L_008D06;
    case 0x008D09u: goto L_008D09;
    case 0x008D0Bu: goto L_008D0B;
    case 0x008D0Eu: goto L_008D0E;
    case 0x008D10u: goto L_008D10;
    case 0x008D13u: goto L_008D13;
    case 0x008D16u: goto L_008D16;
    case 0x008D17u: goto L_008D17;
    case 0x008D19u: goto L_008D19;
    case 0x008D1Bu: goto L_008D1B;
    case 0x008D1Eu: goto L_008D1E;
    case 0x008D20u: goto L_008D20;
    case 0x008D23u: goto L_008D23;
    case 0x008D25u: goto L_008D25;
    case 0x008D28u: goto L_008D28;
    case 0x008D2Au: goto L_008D2A;
    case 0x008D2Du: goto L_008D2D;
    case 0x008D2Fu: goto L_008D2F;
    case 0x008D32u: goto L_008D32;
    case 0x008D35u: goto L_008D35;
    case 0x008D36u: goto L_008D36;
    case 0x008D38u: goto L_008D38;
    case 0x008D3Au: goto L_008D3A;
    case 0x008D3Du: goto L_008D3D;
    case 0x008D3Fu: goto L_008D3F;
    case 0x008D42u: goto L_008D42;
    case 0x008D44u: goto L_008D44;
    case 0x008D47u: goto L_008D47;
    case 0x008D49u: goto L_008D49;
    case 0x008D4Cu: goto L_008D4C;
    case 0x008D4Eu: goto L_008D4E;
    case 0x008D51u: goto L_008D51;
    case 0x008D54u: goto L_008D54;
    case 0x008D55u: goto L_008D55;
    case 0x008D57u: goto L_008D57;
    case 0x008D59u: goto L_008D59;
    case 0x008D5Cu: goto L_008D5C;
    case 0x008D5Eu: goto L_008D5E;
    case 0x008D61u: goto L_008D61;
    case 0x008D63u: goto L_008D63;
    case 0x008D66u: goto L_008D66;
    case 0x008D68u: goto L_008D68;
    case 0x008D6Bu: goto L_008D6B;
    case 0x008D6Du: goto L_008D6D;
    case 0x008D70u: goto L_008D70;
    case 0x008D73u: goto L_008D73;
    case 0x008D74u: goto L_008D74;
    case 0x008D76u: goto L_008D76;
    case 0x008D78u: goto L_008D78;
    case 0x008D7Bu: goto L_008D7B;
    case 0x008D7Du: goto L_008D7D;
    case 0x008D7Fu: goto L_008D7F;
    case 0x008D82u: goto L_008D82;
    case 0x008D85u: goto L_008D85;
    case 0x008D86u: goto L_008D86;
    case 0x008D87u: goto L_008D87;
    case 0x008D88u: goto L_008D88;
    case 0x008D8Au: goto L_008D8A;
    case 0x008D8Cu: goto L_008D8C;
    case 0x008D8Fu: goto L_008D8F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008C8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C8Fu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x28u) & 0xFFFFu), 2u, 0u);
    // $008C8F AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0x28u), cpu.m8?8:16));
    goto L_008C91;
L_008C91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C91u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008C91 BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0x28u), cpu.m8?8:16), false);
    goto L_008C93;
L_008C93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C93u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C93u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008C93 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8C95u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C96u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008C93u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008C96;
L_008C96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C96u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C96u,0x008C96u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C96u,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C96u, 4u + ((((0x3CFCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x3CFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008C96 BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x3CFCu), cpu.m8?8:16), false);
    goto L_008C99;
L_008C99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C99u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C99u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC3Cu + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008C99 JSR (FC3C,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC3Cu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8C9Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C9Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008C99u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008C9C;
L_008C9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Cu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C9Cu,0x008C9Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Cu,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Cu, 4u + ((((0x38FCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x38FCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008C9C BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x38FCu), cpu.m8?8:16), false);
    goto L_008C9F;
L_008C9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Fu,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C9Fu, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x4A38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008C9F JSR (4A38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x4A38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CA1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CA2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008C9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CA2;
L_008CA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA2u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CA2u,0x008CA2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CA2 SEC
    cpu.setFlag('C', true);
    goto L_008CA3;
L_008CA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA3u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CA3 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CA5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CA6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CA3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CA6;
L_008CA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA6u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CA6u,0x008CA6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CA6 SEC
    cpu.setFlag('C', true);
    goto L_008CA7;
L_008CA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CA7 LSR
    cpu.lsrA();
    goto L_008CA8;
L_008CA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u,cpu,0x78u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CA8 SEI
    cpu.setFlag('I', true);
    goto L_008CA9;
L_008CA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CA9u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x3D38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CA9 JSR (3D38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x3D38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CABu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CACu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CA9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CAC;
L_008CAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CACu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CACu,0x008CACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CACu, 4u + ((((0x3C3Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x3C3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CAC BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x3C3Eu), cpu.m8?8:16), false);
    goto L_008CAF;
L_008CAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CAFu, 5u, 4u, ((0x38FC3Cu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CAF AND
    cpu.logicAnd(hw.readW(((0x38FC3Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_008CB3;
L_008CB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB3u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB3u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CB3 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CB6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CB3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CB6;
L_008CB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB6u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CB6u,0x008CB6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CB6 SEC
    cpu.setFlag('C', true);
    goto L_008CB7;
L_008CB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u,cpu,0x2Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CB7u, 6u, 3u, cpu.address("abs", 0x263Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CB7 ROL
    cpu.rolMem(hw, cpu.address("abs", 0x263Cu), cpu.m8?8:16);
    goto L_008CBA;
L_008CBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CBA SEC
    cpu.setFlag('C', true);
    goto L_008CBB;
L_008CBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBBu,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBBu, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CBB JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CBDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CBEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CBBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CBE;
L_008CBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBEu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CBEu,0x008CBEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CBE SEC
    cpu.setFlag('C', true);
    goto L_008CBF;
L_008CBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBFu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CBFu, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0x8CC1u,true);
    hw.requestDispatch(0x0082C3u,0x008CBFu);return;
L_008CC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC1u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CC1 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x38u), cpu.m8?8:16);
    goto L_008CC3;
L_008CC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC3u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC3u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x0038u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CC3 JSR (0038,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x0038u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CC5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CC6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CC3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CC6;
L_008CC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CC6u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CC6u,0x008CC6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CC6 SEC
    cpu.setFlag('C', true);
    goto L_008CC7;
L_008CC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC7u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CC7u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CC7 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CC9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CCAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CC7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CCA;
L_008CCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CCAu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CCAu,0x008CCAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CCA SEC
    cpu.setFlag('C', true);
    goto L_008CCB;
L_008CCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCBu,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCBu, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x6438u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CCB JSR (6438,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x6438u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CCDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CCEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CCBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CCE;
L_008CCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CCEu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CCEu,0x008CCEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCEu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008CCE PLP
    cpu.pop("PLP", hw);
    goto L_008CCF;
L_008CCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CCFu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CCFu,0x008CCFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCFu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CCFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CCF ROL
    cpu.rolMem(hw, cpu.address("dp", 0x38u), cpu.m8?8:16);
    goto L_008CD1;
L_008CD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD1u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD1u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CD1 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CD3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CD4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CD1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CD4;
L_008CD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD4u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CD4u,0x008CD4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CD4 SEC
    cpu.setFlag('C', true);
    goto L_008CD5;
L_008CD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD5u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD5u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x4A38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CD5 JSR (4A38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x4A38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CD7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CD8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CD5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CD8;
L_008CD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD8u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CD8u,0x008CD8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD8u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CD8 SEC
    cpu.setFlag('C', true);
    goto L_008CD9;
L_008CD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD9u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CD9u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CD9 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CDBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CDCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CD9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CDC;
L_008CDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CDCu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CDCu,0x008CDCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDCu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CDC SEC
    cpu.setFlag('C', true);
    goto L_008CDD;
L_008CDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CDD LSR
    cpu.lsrA();
    goto L_008CDE;
L_008CDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDEu,cpu,0x78u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CDE SEI
    cpu.setFlag('I', true);
    goto L_008CDF;
L_008CDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDFu,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CDFu, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFE38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CDF JSR (FE38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFE38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CE1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CE2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CDFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CE2;
L_008CE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CE2u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CE2u,0x008CE2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE2u,cpu,0x3Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE2u, 4u + ((((0x3CFEu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x3CFEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CE2 BIT
    cpu.bit(hw.readW(cpu.address("absx", 0x3CFEu), cpu.m8?8:16), false);
    goto L_008CE5;
L_008CE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE5u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE5u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0x8CE7u,true);
    hw.requestDispatch(0x0082C3u,0x008CE5u);return;
L_008CE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE7u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CE7u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CE7 JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CE9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CEAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CE7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CEA;
L_008CEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CEAu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CEAu,0x008CEAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CEA SEC
    cpu.setFlag('C', true);
    goto L_008CEB;
L_008CEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEBu,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEBu, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CEB JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CEDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CEEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CEBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CEE;
L_008CEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CEEu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CEEu,0x008CEEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CEE SEC
    cpu.setFlag('C', true);
    goto L_008CEF;
L_008CEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEFu,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CEFu, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC38u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CEF JSR (FC38,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC38u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CF1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CF2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CEFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CF2;
L_008CF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF2u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CF2u,0x008CF2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CF2 SEC
    cpu.setFlag('C', true);
    goto L_008CF3;
L_008CF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF3u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF3u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x0038u + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008CF3 JSR (0038,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x0038u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8CF5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8CF6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008CF3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_008CF6;
L_008CF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF6u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8CF6u,0x008CF6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CF6 SEC
    cpu.setFlag('C', true);
    goto L_008CF7;
L_008CF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF7u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CF7 DEC
    cpu.decReg('A');
    goto L_008CF8;
L_008CF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF8u,cpu,0xB8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CF8 CLV
    cpu.setFlag('V', false);
    goto L_008CF9;
L_008CF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF9u,cpu,0x3Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CF9 TSC
    cpu.tsc();
    goto L_008CFA;
L_008CFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFAu,cpu,0xB8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CFA CLV
    cpu.setFlag('V', false);
    goto L_008CFB;
L_008CFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFBu,cpu,0x3Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CFB TSC
    cpu.tsc();
    goto L_008CFC;
L_008CFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFCu,cpu,0xB8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CFC CLV
    cpu.setFlag('V', false);
    goto L_008CFD;
L_008CFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFDu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CFD DEC
    cpu.decReg('A');
    goto L_008CFE;
L_008CFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFEu,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CFE SED
    cpu.setFlag('D', true);
    goto L_008CFF;
L_008CFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008CFF LDA
    cpu.setA(0x80u, 8);
    goto L_008D01;
L_008D00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D00u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D00u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D00 BRA -> $008C8F
    hw.addCpuInternalCycles(1u); // penalidade de page-cross em emulacao
    goto L_008C8F;
L_008D01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D01u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D01u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D01 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_008D04;
L_008D04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D04u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D04 LDA
    cpu.setA(0x2Eu, 8);
    goto L_008D06;
L_008D06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D06u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D06u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D06 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008D09;
L_008D09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D09u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D09 LDA
    cpu.setA(0x50u, 8);
    goto L_008D0B;
L_008D0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Bu, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D0B STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008D0E;
L_008D0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D0E LDX
    cpu.setX(0x6u, 8);
    goto L_008D10;
L_008D10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u, 4u + ((((0x8D90u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8D90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D10 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8D90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008D13;
L_008D13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D13 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008D16;
L_008D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D16 DEX
    cpu.decReg('X');
    goto L_008D17;
L_008D17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D17u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D17 BPL -> $008D10
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008D10; }
    goto L_008D19;
L_008D19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D19 LDA
    cpu.setA(0x2u, 8);
    goto L_008D1B;
L_008D1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Bu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D1B STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008D1E;
L_008D1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D1E LDA
    cpu.setA(0x80u, 8);
    goto L_008D20;
L_008D20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D20u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D20u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D20 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_008D23;
L_008D23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D23u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D23 LDA
    cpu.setA(0x42u, 8);
    goto L_008D25;
L_008D25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D25u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D25u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D25 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008D28;
L_008D28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D28u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D28 LDA
    cpu.setA(0x50u, 8);
    goto L_008D2A;
L_008D2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D2A STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008D2D;
L_008D2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D2D LDX
    cpu.setX(0x6u, 8);
    goto L_008D2F;
L_008D2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Fu, 4u + ((((0x8D97u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8D97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D2F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8D97u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008D32;
L_008D32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D32u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D32u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D32 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008D35;
L_008D35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D35u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D35 DEX
    cpu.decReg('X');
    goto L_008D36;
L_008D36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D36u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D36 BPL -> $008D2F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008D2F; }
    goto L_008D38;
L_008D38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D38u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D38 LDA
    cpu.setA(0x2u, 8);
    goto L_008D3A;
L_008D3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Au, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D3A STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008D3D;
L_008D3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D3D LDA
    cpu.setA(0x80u, 8);
    goto L_008D3F;
L_008D3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D3F STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_008D42;
L_008D42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D42u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D42 LDA
    cpu.setA(0x63u, 8);
    goto L_008D44;
L_008D44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D44 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008D47;
L_008D47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D47u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D47 LDA
    cpu.setA(0x50u, 8);
    goto L_008D49;
L_008D49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D49u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D49u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D49 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008D4C;
L_008D4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D4C LDX
    cpu.setX(0x6u, 8);
    goto L_008D4E;
L_008D4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu, 4u + ((((0x8D9Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8D9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D4E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8D9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008D51;
L_008D51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D51u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D51u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D51 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008D54;
L_008D54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D54u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D54 DEX
    cpu.decReg('X');
    goto L_008D55;
L_008D55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D55u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D55 BPL -> $008D4E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008D4E; }
    goto L_008D57;
L_008D57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D57u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D57 LDA
    cpu.setA(0x2u, 8);
    goto L_008D59;
L_008D59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D59u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D59u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D59 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008D5C;
L_008D5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D5C LDA
    cpu.setA(0x80u, 8);
    goto L_008D5E;
L_008D5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Eu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D5E STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_008D61;
L_008D61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D61u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D61 LDA
    cpu.setA(0x8Eu, 8);
    goto L_008D63;
L_008D63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D63u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D63u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D63 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_008D66;
L_008D66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D66u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D66 LDA
    cpu.setA(0x50u, 8);
    goto L_008D68;
L_008D68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D68u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D68u, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D68 STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_008D6B;
L_008D6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D6B LDX
    cpu.setX(0x6u, 8);
    goto L_008D6D;
L_008D6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Du, 4u + ((((0x8DA5u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x8DA5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D6D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8DA5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008D70;
L_008D70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D70u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D70u, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D70 STA
    hw.write(cpu.address("absx", 0x4310u), cpu.a, cpu.m8?8:16);
    goto L_008D73;
L_008D73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D73 DEX
    cpu.decReg('X');
    goto L_008D74;
L_008D74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D74u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D74 BPL -> $008D6D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008D6D; }
    goto L_008D76;
L_008D76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D76 LDA
    cpu.setA(0x2u, 8);
    goto L_008D78;
L_008D78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D78 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_008D7B;
L_008D7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D7B LDX
    cpu.setX(0x36u, 8);
    goto L_008D7D;
L_008D7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D7D LDY
    cpu.setY(0x6Cu, 8);
    goto L_008D7F;
L_008D7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu, 4u + ((((0x8C89u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8C89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D7F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8C89u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008D82;
L_008D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u, 5u, 3u, cpu.address("absx", 0x0EF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D82 STA
    hw.write(cpu.address("absx", 0xEF9u), cpu.a, cpu.m8?8:16);
    goto L_008D85;
L_008D85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D85 DEY
    cpu.decReg('Y');
    goto L_008D86;
L_008D86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D86u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D86u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D86 DEY
    cpu.decReg('Y');
    goto L_008D87;
L_008D87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D87u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D87 DEX
    cpu.decReg('X');
    goto L_008D88;
L_008D88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D88 BPL -> $008D7F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008D7F; }
    goto L_008D8A;
L_008D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D8A LDA
    cpu.setA(0x28u, 8);
    goto L_008D8C;
L_008D8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu, 4u, 3u, cpu.address("abs", 0x0F30u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008D8C STA
    hw.write(cpu.address("abs", 0xF30u), cpu.a, cpu.m8?8:16);
    goto L_008D8F;
L_008D8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008D8F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008D8Fu);return;} hw.unresolvedReturn(0x008D8Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0091B1_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008494u: goto L_008494;
    case 0x008496u: goto L_008496;
    case 0x008499u: goto L_008499;
    case 0x00849Cu: goto L_00849C;
    case 0x00849Du: goto L_00849D;
    case 0x00849Eu: goto L_00849E;
    case 0x0084A1u: goto L_0084A1;
    case 0x0084A2u: goto L_0084A2;
    case 0x0084A3u: goto L_0084A3;
    case 0x0084A6u: goto L_0084A6;
    case 0x0084A7u: goto L_0084A7;
    case 0x0084A8u: goto L_0084A8;
    case 0x0084ABu: goto L_0084AB;
    case 0x0084AEu: goto L_0084AE;
    case 0x0084B1u: goto L_0084B1;
    case 0x0084B2u: goto L_0084B2;
    case 0x0084B3u: goto L_0084B3;
    case 0x0084B6u: goto L_0084B6;
    case 0x0084B7u: goto L_0084B7;
    case 0x0084B8u: goto L_0084B8;
    case 0x0084BBu: goto L_0084BB;
    case 0x0084BCu: goto L_0084BC;
    case 0x0084BDu: goto L_0084BD;
    case 0x0084C0u: goto L_0084C0;
    case 0x0084C3u: goto L_0084C3;
    case 0x0084C4u: goto L_0084C4;
    case 0x0084C5u: goto L_0084C5;
    case 0x0084C7u: goto L_0084C7;
    case 0x0091B1u: goto L_0091B1;
    case 0x0091B4u: goto L_0091B4;
    case 0x0091B6u: goto L_0091B6;
    case 0x0091B8u: goto L_0091B8;
    case 0x0091BBu: goto L_0091BB;
    case 0x0091BDu: goto L_0091BD;
    case 0x0091C0u: goto L_0091C0;
    case 0x0091C3u: goto L_0091C3;
    case 0x0091C6u: goto L_0091C6;
    case 0x0091C8u: goto L_0091C8;
    case 0x0091CAu: goto L_0091CA;
    case 0x0091CCu: goto L_0091CC;
    case 0x0091CEu: goto L_0091CE;
    case 0x0091D0u: goto L_0091D0;
    case 0x0091D3u: goto L_0091D3;
    case 0x0091D4u: goto L_0091D4;
    case 0x0091D6u: goto L_0091D6;
    case 0x0091D8u: goto L_0091D8;
    case 0x0091DBu: goto L_0091DB;
    case 0x0091DDu: goto L_0091DD;
    case 0x0091DFu: goto L_0091DF;
    case 0x0091E0u: goto L_0091E0;
    case 0x0091E1u: goto L_0091E1;
    case 0x0091E3u: goto L_0091E3;
    case 0x0091E4u: goto L_0091E4;
    case 0x0091E6u: goto L_0091E6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8494u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8494u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008494 LDY
    cpu.setY(0x1Eu, 8);
    goto L_008496;
L_008496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8496u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8496u, 4u + ((((0x8475u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8475u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008496 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x8475u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008499;
L_008499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u, 4u + ((((0x0423u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0423u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008499 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x423u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00849C;
L_00849C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849C ASL
    cpu.aslA();
    goto L_00849D;
L_00849D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849D ASL
    cpu.aslA();
    goto L_00849E;
L_00849E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu, 4u + ((((0x0422u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0422u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00849E ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x422u), cpu.m8?8:16));
    goto L_0084A1;
L_0084A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A1 ASL
    cpu.aslA();
    goto L_0084A2;
L_0084A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A2 ASL
    cpu.aslA();
    goto L_0084A3;
L_0084A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A3u, 4u + ((((0x0421u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0421u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x421u), cpu.m8?8:16));
    goto L_0084A6;
L_0084A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A6 ASL
    cpu.aslA();
    goto L_0084A7;
L_0084A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A7 ASL
    cpu.aslA();
    goto L_0084A8;
L_0084A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u, 4u + ((((0x0420u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084A8 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x420u), cpu.m8?8:16));
    goto L_0084AB;
L_0084AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84ABu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84ABu, 5u, 3u, cpu.address("absy", 0x0400u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084AB STA
    hw.write(cpu.address("absy", 0x400u), cpu.a, cpu.m8?8:16);
    goto L_0084AE;
L_0084AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84AEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84AEu, 4u + ((((0x0427u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0427u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084AE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x427u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0084B1;
L_0084B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B1 ASL
    cpu.aslA();
    goto L_0084B2;
L_0084B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B2 ASL
    cpu.aslA();
    goto L_0084B3;
L_0084B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B3u, 4u + ((((0x0426u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0426u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x426u), cpu.m8?8:16));
    goto L_0084B6;
L_0084B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B6 ASL
    cpu.aslA();
    goto L_0084B7;
L_0084B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B7 ASL
    cpu.aslA();
    goto L_0084B8;
L_0084B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u, 4u + ((((0x0425u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084B8 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x425u), cpu.m8?8:16));
    goto L_0084BB;
L_0084BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BB ASL
    cpu.aslA();
    goto L_0084BC;
L_0084BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BC ASL
    cpu.aslA();
    goto L_0084BD;
L_0084BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu, 4u + ((((0x0424u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0424u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084BD ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x424u), cpu.m8?8:16));
    goto L_0084C0;
L_0084C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C0u, 5u, 3u, cpu.address("absy", 0x0401u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C0 STA
    hw.write(cpu.address("absy", 0x401u), cpu.a, cpu.m8?8:16);
    goto L_0084C3;
L_0084C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C3 DEY
    cpu.decReg('Y');
    goto L_0084C4;
L_0084C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C4u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C4 DEY
    cpu.decReg('Y');
    goto L_0084C5;
L_0084C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0084C5 BPL -> $008496
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008496; }
    goto L_0084C7;
L_0084C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0084C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0084C7u);return;} hw.unresolvedReturn(0x0084C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_0091B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u, 6u, 3u, cpu.address("abs", 0xA82Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0091B1 JSR -> $00A82D stack real
    { cpu.push16Value(hw,0x91B3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91B4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA82Du), 0x0091B1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0091B4;
L_0091B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91B4u,0x0091B4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091B4 LDX
    cpu.setX(0x0u, 8);
    goto L_0091B6;
L_0091B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091B6 LDA
    cpu.setA(0xB0u, 8);
    goto L_0091B8;
L_0091B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B8u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B8u, 4u, 3u, cpu.address("abs", 0x1425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091B8 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1425u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0091BB;
L_0091BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091BB BEQ -> $0091CA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0091CA; }
    goto L_0091BD;
L_0091BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BDu, 4u, 3u, cpu.address("abs", 0x0F31u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091BD STZ
    hw.write(cpu.address("abs", 0xF31u), 0, cpu.m8?8:16);
    goto L_0091C0;
L_0091C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C0u, 4u, 3u, cpu.address("abs", 0x0F32u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091C0 STZ
    hw.write(cpu.address("abs", 0xF32u), 0, cpu.m8?8:16);
    goto L_0091C3;
L_0091C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C3u, 4u, 3u, cpu.address("abs", 0x0F33u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091C3 STZ
    hw.write(cpu.address("abs", 0xF33u), 0, cpu.m8?8:16);
    goto L_0091C6;
L_0091C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091C6 LDX
    cpu.setX(0x26u, 8);
    goto L_0091C8;
L_0091C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091C8 LDA
    cpu.setA(0xA4u, 8);
    goto L_0091CA;
L_0091CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091CA STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0091CC;
L_0091CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091CC STZ
    hw.write(cpu.address("dp", 0x1u), 0, cpu.m8?8:16);
    goto L_0091CE;
L_0091CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091CE LDY
    cpu.setY(0x70u, 8);
    goto L_0091D0;
L_0091D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u, 6u, 3u, cpu.address("abs", 0x91E9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0091D0 JSR -> $0091E9 stack real
    { cpu.push16Value(hw,0x91D2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91D3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x91E9u), 0x0091D0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0091D3;
L_0091D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91D3u,0x0091D3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091D3 INX
    cpu.inc('X');
    goto L_0091D4;
L_0091D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D4u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091D4 CPX
    cpu.compareX(0x8u);
    goto L_0091D6;
L_0091D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091D6 BNE -> $0091DF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0091DF; }
    goto L_0091D8;
L_0091D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D8u, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091D8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDB3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0091DB;
L_0091DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091DB BEQ -> $0091DF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0091DF; }
    goto L_0091DD;
L_0091DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091DD LDX
    cpu.setX(0xEu, 8);
    goto L_0091DF;
L_0091DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DFu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091DF TYA
    cpu.transfer("TYA");
    goto L_0091E0;
L_0091E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091E0 SEC
    cpu.setFlag('C', true);
    goto L_0091E1;
L_0091E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E1u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091E1 SBC
    cpu.sbc(0x8u);
    goto L_0091E3;
L_0091E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E3u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091E3 TAY
    cpu.transfer("TAY");
    goto L_0091E4;
L_0091E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091E4 BNE -> $0091D0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0091D0; }
    goto L_0091E6;
L_0091E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E6u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E6u, 3u, 3u, cpu.address("abs", 0x8494u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0091E6 JMP -> $008494
    goto L_008494;
}

void sub_00968E_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0093CAu: goto L_0093CA;
    case 0x0093CCu: goto L_0093CC;
    case 0x0093CFu: goto L_0093CF;
    case 0x0093D1u: goto L_0093D1;
    case 0x0093D4u: goto L_0093D4;
    case 0x0093D7u: goto L_0093D7;
    case 0x0093DAu: goto L_0093DA;
    case 0x0093DDu: goto L_0093DD;
    case 0x0093E0u: goto L_0093E0;
    case 0x0093E3u: goto L_0093E3;
    case 0x0093E6u: goto L_0093E6;
    case 0x0093E8u: goto L_0093E8;
    case 0x0093EAu: goto L_0093EA;
    case 0x0093ECu: goto L_0093EC;
    case 0x0093EFu: goto L_0093EF;
    case 0x0093F1u: goto L_0093F1;
    case 0x0093F4u: goto L_0093F4;
    case 0x00968Eu: goto L_00968E;
    case 0x009691u: goto L_009691;
    case 0x009694u: goto L_009694;
    case 0x009696u: goto L_009696;
    case 0x009699u: goto L_009699;
    case 0x00969Cu: goto L_00969C;
    case 0x00969Fu: goto L_00969F;
    case 0x0096A1u: goto L_0096A1;
    case 0x0096A4u: goto L_0096A4;
    case 0x0096A6u: goto L_0096A6;
    case 0x0096A8u: goto L_0096A8;
    case 0x0096ABu: goto L_0096AB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0093CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093CA LDA
    cpu.setA(0xFu, 8);
    goto L_0093CC;
L_0093CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CCu, 4u, 3u, cpu.address("abs", 0x0DAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093CC STA
    hw.write(cpu.address("abs", 0xDAEu), cpu.a, cpu.m8?8:16);
    goto L_0093CF;
L_0093CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093CF LDA
    cpu.setA(0x1u, 8);
    goto L_0093D1;
L_0093D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D1u, 4u, 3u, cpu.address("abs", 0x0DAFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093D1 STA
    hw.write(cpu.address("abs", 0xDAFu), cpu.a, cpu.m8?8:16);
    goto L_0093D4;
L_0093D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D4u, 4u, 3u, cpu.address("abs", 0x192Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093D4 STZ
    hw.write(cpu.address("abs", 0x192Eu), 0, cpu.m8?8:16);
    goto L_0093D7;
L_0093D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D7u, 6u, 3u, cpu.address("abs", 0xABEDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093D7 JSR -> $00ABED stack real
    { cpu.push16Value(hw,0x93D9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93DAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABEDu), 0x0093D7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0093DA;
L_0093DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93DAu,0x0093DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DAu, 4u, 3u, cpu.address("abs", 0x0701u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093DA STZ
    hw.write(cpu.address("abs", 0x701u), 0, cpu.m8?8:16);
    goto L_0093DD;
L_0093DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DDu, 4u, 3u, cpu.address("abs", 0x0702u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093DD STZ
    hw.write(cpu.address("abs", 0x702u), 0, cpu.m8?8:16);
    goto L_0093E0;
L_0093E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E0u, 6u, 3u, cpu.address("abs", 0x922Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093E0 JSR -> $00922F stack real
    { cpu.push16Value(hw,0x93E2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93E3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x922Fu), 0x0093E0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0093E3;
L_0093E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93E3u,0x0093E3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E3u, 4u, 3u, cpu.address("abs", 0x1B92u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093E3 STZ
    hw.write(cpu.address("abs", 0x1B92u), 0, cpu.m8?8:16);
    goto L_0093E6;
L_0093E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093E6 LDX
    cpu.setX(0x10u, 8);
    goto L_0093E8;
L_0093E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093E8 LDY
    cpu.setY(0x4u, 8);
    goto L_0093EA;
L_0093EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EA LDA
    cpu.setA(0x1u, 8);
    goto L_0093EC;
L_0093EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ECu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ECu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EC STA
    hw.write(cpu.address("abs", 0xD9Bu), cpu.a, cpu.m8?8:16);
    goto L_0093EF;
L_0093EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EF LDA
    cpu.setA(0x20u, 8);
    goto L_0093F1;
L_0093F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F1u, 6u, 3u, cpu.address("abs", 0x93FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093F1 JSR -> $0093FD stack real
    { cpu.push16Value(hw,0x93F3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93F4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x93FDu), 0x0093F1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0093F4;
L_0093F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93F4u,0x0093F4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u, 6u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F4 INC
    cpu.incMem(hw, cpu.address("abs", 0x100u), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93F7u,0x0093F4u); return;
L_00968E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x968Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x968Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x968Eu, 6u, 3u, cpu.address("abs", 0x85FAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00968E JSR -> $0085FA stack real
    { cpu.push16Value(hw,0x9690u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9691u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85FAu), 0x00968Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009691;
L_009691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9691u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9691u,0x009691u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9691u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9691u, 4u, 3u, cpu.address("abs", 0x1425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009691 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1425u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009694;
L_009694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9694u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9694u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009694 BNE -> $0096A8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0096A8; }
    goto L_009696;
L_009696:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9696u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9696u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9696u, 4u, 3u, cpu.address("abs", 0x141Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009696 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009699;
L_009699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9699u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9699u, 4u, 3u, cpu.address("abs", 0x141Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009699 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x141Du), cpu.m8?8:16));
    goto L_00969C;
L_00969C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Cu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Cu, 4u, 3u, cpu.address("abs", 0x0109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00969C ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x109u), cpu.m8?8:16));
    goto L_00969F;
L_00969F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00969F BNE -> $0096AB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0096AB; }
    goto L_0096A1;
L_0096A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A1u, 4u, 3u, cpu.address("abs", 0x13C1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0096A1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0096A4;
L_0096A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0096A4 CMP
    cpu.compareA(0x56u);
    goto L_0096A6;
L_0096A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0096A6 BEQ -> $0096AB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0096AB; }
    goto L_0096A8;
L_0096A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u, 6u, 3u, cpu.address("abs", 0x91B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0096A8 JSR -> $0091B1 stack real
    { cpu.push16Value(hw,0x96AAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x96ABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x91B1u), 0x0096A8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0096AB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u, 6u, 3u, cpu.address("abs", 0x91B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0096A8 JSR -> $0091B1 stack real
    { cpu.push16Value(hw,0x96AAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x96ABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x91B1u), 0x0096A8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0096AB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x96A8u,0x0096A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0096AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96ABu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96ABu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96ABu, 3u, 3u, cpu.address("abs", 0x93CAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0096AB JMP -> $0093CA
    goto L_0093CA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96ABu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96ABu, 3u, 3u, cpu.address("abs", 0x93CAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0096AB JMP -> $0093CA
    goto L_0093CA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x96ABu,0x0096ABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00968E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0093CAu: goto L_0093CA;
    case 0x0093CCu: goto L_0093CC;
    case 0x0093CFu: goto L_0093CF;
    case 0x0093D1u: goto L_0093D1;
    case 0x0093D4u: goto L_0093D4;
    case 0x0093D7u: goto L_0093D7;
    case 0x0093DAu: goto L_0093DA;
    case 0x0093DDu: goto L_0093DD;
    case 0x0093E0u: goto L_0093E0;
    case 0x0093E3u: goto L_0093E3;
    case 0x0093E6u: goto L_0093E6;
    case 0x0093E8u: goto L_0093E8;
    case 0x0093EAu: goto L_0093EA;
    case 0x0093ECu: goto L_0093EC;
    case 0x0093EFu: goto L_0093EF;
    case 0x0093F1u: goto L_0093F1;
    case 0x0093F4u: goto L_0093F4;
    case 0x0093F7u: goto L_0093F7;
    case 0x0093F9u: goto L_0093F9;
    case 0x0093FCu: goto L_0093FC;
    case 0x00968Eu: goto L_00968E;
    case 0x009691u: goto L_009691;
    case 0x009694u: goto L_009694;
    case 0x009696u: goto L_009696;
    case 0x009699u: goto L_009699;
    case 0x00969Cu: goto L_00969C;
    case 0x00969Fu: goto L_00969F;
    case 0x0096A1u: goto L_0096A1;
    case 0x0096A4u: goto L_0096A4;
    case 0x0096A6u: goto L_0096A6;
    case 0x0096A8u: goto L_0096A8;
    case 0x0096ABu: goto L_0096AB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0093CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093CA LDA
    cpu.setA(0xFu, 8);
    goto L_0093CC;
L_0093CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CCu, 4u, 3u, cpu.address("abs", 0x0DAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093CC STA
    hw.write(cpu.address("abs", 0xDAEu), cpu.a, cpu.m8?8:16);
    goto L_0093CF;
L_0093CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093CF LDA
    cpu.setA(0x1u, 8);
    goto L_0093D1;
L_0093D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D1u, 4u, 3u, cpu.address("abs", 0x0DAFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093D1 STA
    hw.write(cpu.address("abs", 0xDAFu), cpu.a, cpu.m8?8:16);
    goto L_0093D4;
L_0093D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D4u, 4u, 3u, cpu.address("abs", 0x192Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093D4 STZ
    hw.write(cpu.address("abs", 0x192Eu), 0, cpu.m8?8:16);
    goto L_0093D7;
L_0093D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D7u, 6u, 3u, cpu.address("abs", 0xABEDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093D7 JSR -> $00ABED stack real
    { cpu.push16Value(hw,0x93D9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93DAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABEDu), 0x0093D7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0093DA;
L_0093DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93DAu,0x0093DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DAu, 4u, 3u, cpu.address("abs", 0x0701u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093DA STZ
    hw.write(cpu.address("abs", 0x701u), 0, cpu.m8?8:16);
    goto L_0093DD;
L_0093DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DDu, 4u, 3u, cpu.address("abs", 0x0702u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093DD STZ
    hw.write(cpu.address("abs", 0x702u), 0, cpu.m8?8:16);
    goto L_0093E0;
L_0093E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E0u, 6u, 3u, cpu.address("abs", 0x922Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093E0 JSR -> $00922F stack real
    { cpu.push16Value(hw,0x93E2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93E3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x922Fu), 0x0093E0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0093E3;
L_0093E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93E3u,0x0093E3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E3u, 4u, 3u, cpu.address("abs", 0x1B92u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093E3 STZ
    hw.write(cpu.address("abs", 0x1B92u), 0, cpu.m8?8:16);
    goto L_0093E6;
L_0093E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093E6 LDX
    cpu.setX(0x10u, 8);
    goto L_0093E8;
L_0093E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093E8 LDY
    cpu.setY(0x4u, 8);
    goto L_0093EA;
L_0093EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EA LDA
    cpu.setA(0x1u, 8);
    goto L_0093EC;
L_0093EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ECu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ECu, 4u, 3u, cpu.address("abs", 0x0D9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EC STA
    hw.write(cpu.address("abs", 0xD9Bu), cpu.a, cpu.m8?8:16);
    goto L_0093EF;
L_0093EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093EF LDA
    cpu.setA(0x20u, 8);
    goto L_0093F1;
L_0093F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F1u, 6u, 3u, cpu.address("abs", 0x93FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093F1 JSR -> $0093FD stack real
    { cpu.push16Value(hw,0x93F3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93F4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x93FDu), 0x0093F1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0093F4;
L_0093F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93F4u,0x0093F4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u, 6u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F4 INC
    cpu.incMem(hw, cpu.address("abs", 0x100u), cpu.m8?8:16);
    goto L_0093F7;
L_0093F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F7 LDA
    cpu.setA(0x81u, 8);
    goto L_0093F9;
L_0093F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F9u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0093F9 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_0093FC;
L_0093FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0093FC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0093FCu);return;} hw.unresolvedReturn(0x0093FCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00968E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x968Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x968Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x968Eu, 6u, 3u, cpu.address("abs", 0x85FAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00968E JSR -> $0085FA stack real
    { cpu.push16Value(hw,0x9690u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9691u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85FAu), 0x00968Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_009691;
L_009691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9691u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9691u,0x009691u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9691u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9691u, 4u, 3u, cpu.address("abs", 0x1425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009691 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1425u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009694;
L_009694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9694u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9694u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009694 BNE -> $0096A8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0096A8; }
    goto L_009696;
L_009696:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9696u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9696u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9696u, 4u, 3u, cpu.address("abs", 0x141Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009696 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009699;
L_009699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9699u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9699u, 4u, 3u, cpu.address("abs", 0x141Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009699 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x141Du), cpu.m8?8:16));
    goto L_00969C;
L_00969C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Cu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Cu, 4u, 3u, cpu.address("abs", 0x0109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00969C ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x109u), cpu.m8?8:16));
    goto L_00969F;
L_00969F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00969F BNE -> $0096AB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0096AB; }
    goto L_0096A1;
L_0096A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A1u, 4u, 3u, cpu.address("abs", 0x13C1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0096A1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0096A4;
L_0096A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0096A4 CMP
    cpu.compareA(0x56u);
    goto L_0096A6;
L_0096A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0096A6 BEQ -> $0096AB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0096AB; }
    goto L_0096A8;
L_0096A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u, 6u, 3u, cpu.address("abs", 0x91B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0096A8 JSR -> $0091B1 stack real
    { cpu.push16Value(hw,0x96AAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x96ABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x91B1u), 0x0096A8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0096AB;
L_0096AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96ABu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x96ABu,0x0096ABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96ABu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96ABu, 3u, 3u, cpu.address("abs", 0x93CAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0096AB JMP -> $0093CA
    goto L_0093CA;
}

void sub_00A9DA_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00A9DAu: goto L_00A9DA;
    case 0x00A9DCu: goto L_00A9DC;
    case 0x00A9DFu: goto L_00A9DF;
    case 0x00A9E1u: goto L_00A9E1;
    case 0x00A9E4u: goto L_00A9E4;
    case 0x00A9E5u: goto L_00A9E5;
    case 0x00A9E6u: goto L_00A9E6;
    case 0x00A9E7u: goto L_00A9E7;
    case 0x00A9EAu: goto L_00A9EA;
    case 0x00A9ECu: goto L_00A9EC;
    case 0x00A9EDu: goto L_00A9ED;
    case 0x00A9EEu: goto L_00A9EE;
    case 0x00A9F0u: goto L_00A9F0;
    case 0x00A9F2u: goto L_00A9F2;
    case 0x00A9F4u: goto L_00A9F4;
    case 0x00A9F6u: goto L_00A9F6;
    case 0x00A9F9u: goto L_00A9F9;
    case 0x00A9FCu: goto L_00A9FC;
    case 0x00A9FFu: goto L_00A9FF;
    case 0x00AA01u: goto L_00AA01;
    case 0x00AA04u: goto L_00AA04;
    case 0x00AA06u: goto L_00AA06;
    case 0x00AA08u: goto L_00AA08;
    case 0x00AA0Bu: goto L_00AA0B;
    case 0x00AA0Du: goto L_00AA0D;
    case 0x00AA0Fu: goto L_00AA0F;
    case 0x00AA11u: goto L_00AA11;
    case 0x00AA13u: goto L_00AA13;
    case 0x00AA16u: goto L_00AA16;
    case 0x00AA17u: goto L_00AA17;
    case 0x00AA19u: goto L_00AA19;
    case 0x00AA1Cu: goto L_00AA1C;
    case 0x00AA1Eu: goto L_00AA1E;
    case 0x00AA20u: goto L_00AA20;
    case 0x00AA22u: goto L_00AA22;
    case 0x00AA25u: goto L_00AA25;
    case 0x00AA26u: goto L_00AA26;
    case 0x00AA27u: goto L_00AA27;
    case 0x00AA28u: goto L_00AA28;
    case 0x00AA2Bu: goto L_00AA2B;
    case 0x00AA2Du: goto L_00AA2D;
    case 0x00AA2Eu: goto L_00AA2E;
    case 0x00AA2Fu: goto L_00AA2F;
    case 0x00AA31u: goto L_00AA31;
    case 0x00AA33u: goto L_00AA33;
    case 0x00AA35u: goto L_00AA35;
    case 0x00AA37u: goto L_00AA37;
    case 0x00AA3Au: goto L_00AA3A;
    case 0x00AA3Du: goto L_00AA3D;
    case 0x00AA40u: goto L_00AA40;
    case 0x00AA42u: goto L_00AA42;
    case 0x00AA45u: goto L_00AA45;
    case 0x00AA47u: goto L_00AA47;
    case 0x00AA49u: goto L_00AA49;
    case 0x00AA4Cu: goto L_00AA4C;
    case 0x00AA4Eu: goto L_00AA4E;
    case 0x00AA50u: goto L_00AA50;
    case 0x00AA52u: goto L_00AA52;
    case 0x00AA54u: goto L_00AA54;
    case 0x00AA57u: goto L_00AA57;
    case 0x00AA58u: goto L_00AA58;
    case 0x00AA5Au: goto L_00AA5A;
    case 0x00AA5Bu: goto L_00AA5B;
    case 0x00AA5Du: goto L_00AA5D;
    case 0x00AA60u: goto L_00AA60;
    case 0x00AA62u: goto L_00AA62;
    case 0x00AA64u: goto L_00AA64;
    case 0x00AA67u: goto L_00AA67;
    case 0x00AA68u: goto L_00AA68;
    case 0x00AA6Au: goto L_00AA6A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00A9DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9DA LDA
    cpu.setA(0x80u, 8);
    goto L_00A9DC;
L_00A9DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DCu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9DC STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_00A9DF;
L_00A9DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9DF LDX
    cpu.setX(0x3u, 8);
    goto L_00A9E1;
L_00A9E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E1u, 4u, 3u, cpu.address("abs", 0x192Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9E1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x192Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A9E4;
L_00A9E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9E4 ASL
    cpu.aslA();
    goto L_00A9E5;
L_00A9E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9E5 ASL
    cpu.aslA();
    goto L_00A9E6;
L_00A9E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9E6 TAY
    cpu.transfer("TAY");
    goto L_00A9E7;
L_00A9E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E7u, 4u + ((((0xA8C3u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA8C3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9E7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA8C3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A9EA;
L_00A9EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EAu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9EA STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00A9EC;
L_00A9EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9ECu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9EC INY
    cpu.inc('Y');
    goto L_00A9ED;
L_00A9ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EDu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9ED DEX
    cpu.decReg('X');
    goto L_00A9EE;
L_00A9EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9EE BPL -> $00A9E7
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00A9E7; }
    goto L_00A9F0;
L_00A9F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9F0 LDA
    cpu.setA(0x3u, 8);
    goto L_00A9F2;
L_00A9F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9F2 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_00A9F4;
L_00A9F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F4u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9F4 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00A9F6;
L_00A9F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F6u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9F6 STZ
    hw.write(cpu.address("abs", 0x2116u), 0, cpu.m8?8:16);
    goto L_00A9F9;
L_00A9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u, 4u + ((((0xA9D2u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA9D2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9F9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA9D2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00A9FC;
L_00A9FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FCu, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9FC STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_00A9FF;
L_00A9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00A9FF LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00AA01;
L_00AA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u, 4u + ((((0x0101u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0101u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA01 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x101u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA04;
L_00AA04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA04 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16));
    goto L_00AA06;
L_00AA06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA06u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA06 BEQ -> $00AA0B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00AA0B; }
    goto L_00AA08;
L_00AA08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA08u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA08u, 6u, 3u, cpu.address("abs", 0xAA6Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AA08 JSR -> $00AA6B stack real
    { cpu.push16Value(hw,0xAA0Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA0Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA6Bu), 0x00AA08u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AA0B;
L_00AA0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Bu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA0Bu,0x00AA0Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Bu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA0B DEC
    cpu.decMem(hw, cpu.address("dp", 0xFu), cpu.m8?8:16);
    goto L_00AA0D;
L_00AA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA0D BPL -> $00A9F4
    if (!cpu.n) { hw.addCpuInternalCycles(2u); goto L_00A9F4; }
    goto L_00AA0F;
L_00AA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA0F LDX
    cpu.setX(0x3u, 8);
    goto L_00AA11;
L_00AA11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA11u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA11 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA13;
L_00AA13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA13u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA13u, 5u, 3u, cpu.address("absx", 0x0101u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA13 STA
    hw.write(cpu.address("absx", 0x101u), cpu.a, cpu.m8?8:16);
    goto L_00AA16;
L_00AA16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA16u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA16 DEX
    cpu.decReg('X');
    goto L_00AA17;
L_00AA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA17u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA17 BPL -> $00AA11
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AA11; }
    goto L_00AA19;
L_00AA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA19u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA19u, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA19 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA1C;
L_00AA1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA1C CMP
    cpu.compareA(0xFEu);
    goto L_00AA1E;
L_00AA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA1E BCS -> $00AA5B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00AA5B; }
    goto L_00AA20;
L_00AA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA20 LDX
    cpu.setX(0x3u, 8);
    goto L_00AA22;
L_00AA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA22u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA22u, 4u, 3u, cpu.address("abs", 0x1931u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA22 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1931u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA25;
L_00AA25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA25u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA25 ASL
    cpu.aslA();
    goto L_00AA26;
L_00AA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA26u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA26u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA26 ASL
    cpu.aslA();
    goto L_00AA27;
L_00AA27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA27u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA27u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA27 TAY
    cpu.transfer("TAY");
    goto L_00AA28;
L_00AA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA28u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA28u, 4u + ((((0xA92Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA92Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA28 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA92Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA2B;
L_00AA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA2B STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_00AA2D;
L_00AA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA2D INY
    cpu.inc('Y');
    goto L_00AA2E;
L_00AA2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA2E DEX
    cpu.decReg('X');
    goto L_00AA2F;
L_00AA2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA2F BPL -> $00AA28
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AA28; }
    goto L_00AA31;
L_00AA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA31u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA31 LDA
    cpu.setA(0x3u, 8);
    goto L_00AA33;
L_00AA33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA33u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA33u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA33 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_00AA35;
L_00AA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA35 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00AA37;
L_00AA37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u, 4u, 3u, cpu.address("abs", 0x2116u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA37 STZ
    hw.write(cpu.address("abs", 0x2116u), 0, cpu.m8?8:16);
    goto L_00AA3A;
L_00AA3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Au, 4u + ((((0xA9D6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xA9D6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA3A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xA9D6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA3D;
L_00AA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du, 4u, 3u, cpu.address("abs", 0x2117u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA3D STA
    hw.write(cpu.address("abs", 0x2117u), cpu.a, cpu.m8?8:16);
    goto L_00AA40;
L_00AA40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA40u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA40u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA40 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00AA42;
L_00AA42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA42u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA42u, 4u + ((((0x0105u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA42 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x105u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA45;
L_00AA45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA45u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA45u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA45 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16));
    goto L_00AA47;
L_00AA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA47u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA47 BEQ -> $00AA4C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00AA4C; }
    goto L_00AA49;
L_00AA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA49u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA49u, 6u, 3u, cpu.address("abs", 0xAA6Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AA49 JSR -> $00AA6B stack real
    { cpu.push16Value(hw,0xAA4Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA4Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA6Bu), 0x00AA49u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AA4C;
L_00AA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Cu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA4Cu,0x00AA4Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA4C DEC
    cpu.decMem(hw, cpu.address("dp", 0xFu), cpu.m8?8:16);
    goto L_00AA4E;
L_00AA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA4E BPL -> $00AA35
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AA35; }
    goto L_00AA50;
L_00AA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA50u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA50u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA50 LDX
    cpu.setX(0x3u, 8);
    goto L_00AA52;
L_00AA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA52u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA52u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA52 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00AA54;
L_00AA54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u, 5u, 3u, cpu.address("absx", 0x0105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA54 STA
    hw.write(cpu.address("absx", 0x105u), cpu.a, cpu.m8?8:16);
    goto L_00AA57;
L_00AA57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA57u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA57u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA57 DEX
    cpu.decReg('X');
    goto L_00AA58;
L_00AA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA58 BPL -> $00AA52
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AA52; }
    goto L_00AA5A;
L_00AA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AA5A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00AA5Au);return;} hw.unresolvedReturn(0x00AA5Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_00AA5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA5B BEQ -> $00AA60
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00AA60; }
    goto L_00AA5D;
L_00AA5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Du, 6u, 3u, cpu.address("abs", 0xAB42u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AA5D JSR -> $00AB42 stack real
    { cpu.push16Value(hw,0xAA5Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA60u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAB42u), 0x00AA5Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00AA60;
L_00AA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA60u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA60u,0x00AA60u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA60u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA60 LDX
    cpu.setX(0x3u, 8);
    goto L_00AA62;
L_00AA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA62u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA62 LDA
    cpu.setA(0x80u, 8);
    goto L_00AA64;
L_00AA64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA64u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA64u, 5u, 3u, cpu.address("absx", 0x0105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA64 STA
    hw.write(cpu.address("absx", 0x105u), cpu.a, cpu.m8?8:16);
    goto L_00AA67;
L_00AA67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA67u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA67u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA67 DEX
    cpu.decReg('X');
    goto L_00AA68;
L_00AA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA68u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00AA68 BPL -> $00AA64
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00AA64; }
    goto L_00AA6A;
L_00AA6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA6Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA6Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00AA6A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00AA6Au);return;} hw.unresolvedReturn(0x00AA6Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00EC35_E0M1X1CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF2Du: goto L_00EF2D;
    case 0x00EF2Fu: goto L_00EF2F;
    case 0x00EF31u: goto L_00EF31;
    case 0x00EF33u: goto L_00EF33;
    case 0x00EF36u: goto L_00EF36;
    case 0x00EF38u: goto L_00EF38;
    case 0x00EF3Bu: goto L_00EF3B;
    case 0x00EF3Du: goto L_00EF3D;
    case 0x00EF3Fu: goto L_00EF3F;
    case 0x00EF42u: goto L_00EF42;
    case 0x00EF43u: goto L_00EF43;
    case 0x00EF45u: goto L_00EF45;
    case 0x00EF48u: goto L_00EF48;
    case 0x00EF4Bu: goto L_00EF4B;
    case 0x00EF4Du: goto L_00EF4D;
    case 0x00EF50u: goto L_00EF50;
    case 0x00EF51u: goto L_00EF51;
    case 0x00EF54u: goto L_00EF54;
    case 0x00EF55u: goto L_00EF55;
    case 0x00EF56u: goto L_00EF56;
    case 0x00EF58u: goto L_00EF58;
    case 0x00EF5Au: goto L_00EF5A;
    case 0x00EF5Cu: goto L_00EF5C;
    case 0x00EF5Du: goto L_00EF5D;
    case 0x00EF5Eu: goto L_00EF5E;
    case 0x00EF60u: goto L_00EF60;
    case 0x00EF62u: goto L_00EF62;
    case 0x00EF63u: goto L_00EF63;
    case 0x00EF65u: goto L_00EF65;
    case 0x00EF68u: goto L_00EF68;
    case 0x00EF6Bu: goto L_00EF6B;
    case 0x00EF6Du: goto L_00EF6D;
    case 0x00EF6Fu: goto L_00EF6F;
    case 0x00EF72u: goto L_00EF72;
    case 0x00EF75u: goto L_00EF75;
    case 0x00EF77u: goto L_00EF77;
    case 0x00EF79u: goto L_00EF79;
    case 0x00EF7Cu: goto L_00EF7C;
    case 0x00EF7Eu: goto L_00EF7E;
    case 0x00EF81u: goto L_00EF81;
    case 0x00EF83u: goto L_00EF83;
    case 0x00EF85u: goto L_00EF85;
    case 0x00EF87u: goto L_00EF87;
    case 0x00EF8Au: goto L_00EF8A;
    case 0x00EF8Cu: goto L_00EF8C;
    case 0x00EF90u: goto L_00EF90;
    case 0x00EF92u: goto L_00EF92;
    case 0x00EF95u: goto L_00EF95;
    case 0x00EF98u: goto L_00EF98;
    case 0x00EF99u: goto L_00EF99;
    case 0x00EF9Cu: goto L_00EF9C;
    case 0x00EF9Fu: goto L_00EF9F;
    case 0x00EFA1u: goto L_00EFA1;
    case 0x00EFA3u: goto L_00EFA3;
    case 0x00EFA5u: goto L_00EFA5;
    case 0x00EFA7u: goto L_00EFA7;
    case 0x00EFA9u: goto L_00EFA9;
    case 0x00EFAAu: goto L_00EFAA;
    case 0x00EFADu: goto L_00EFAD;
    case 0x00EFAEu: goto L_00EFAE;
    case 0x00EFB0u: goto L_00EFB0;
    case 0x00EFB2u: goto L_00EFB2;
    case 0x00EFB6u: goto L_00EFB6;
    case 0x00EFB8u: goto L_00EFB8;
    case 0x00EFBBu: goto L_00EFBB;
    case 0x00F629u: goto L_00F629;
    case 0x00F62Du: goto L_00F62D;
    case 0x00F62Fu: goto L_00F62F;
    case 0x00F631u: goto L_00F631;
    case 0x00F633u: goto L_00F633;
    case 0x00F635u: goto L_00F635;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2D BRA -> $00EF60
    goto L_00EF60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF2Du,0x00EF2Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF2Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF2F LDY
    cpu.setY(0x20u, 8);
    goto L_00EF31;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF2Fu,0x00EF2Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF31u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF31u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF31 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF33;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF31u,0x00EF31u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF33u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF33u, 4u + ((((0xE4DAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF33 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16));
    goto L_00EF36;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF33u,0x00EF33u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF36u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF36u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF36 BCC -> $00EF3B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EF3B; }
    goto L_00EF38;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF36u,0x00EF36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF38u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF38u, 4u + ((((0xE4DAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE4DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF38 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE4DAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF3B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF38u,0x00EF38u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF3Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF3B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF3D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF3Bu,0x00EF3Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF3Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF3D BPL -> $00EF60
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF60; }
    goto L_00EF3F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF3Du,0x00EF3Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF3Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF3Fu, 6u, 3u, cpu.address("abs", 0x140Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF3F INC
    cpu.incMem(hw, cpu.address("abs", 0x140Eu), cpu.m8?8:16);
    goto L_00EF42;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF3Fu,0x00EF3Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF42u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF42u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EF42 PHA
    cpu.push("PHA", hw);
    goto L_00EF43;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF42u,0x00EF42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF43u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF43 REP
    cpu.rep(0x20u);
    goto L_00EF45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF43u,0x00EF43u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF45u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF45u, 5u, 3u, cpu.address("abs", 0x17BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF45 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF48;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF45u,0x00EF45u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF48u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF48 AND
    cpu.logicAnd(0xFF00u);
    goto L_00EF4B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF48u,0x00EF48u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF4Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF4B BPL -> $00EF50
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF50; }
    goto L_00EF4D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF4Bu,0x00EF4Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF4Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF4D ORA
    cpu.logicOr(0xFFu);
    goto L_00EF50;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF4Du,0x00EF4Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF50u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF50u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF50u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF50 XBA
    cpu.xba();
    goto L_00EF51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF50u,0x00EF50u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF51u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF51u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF51u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF51 EOR
    cpu.logicXor(0xFFFFu);
    goto L_00EF54;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF51u,0x00EF51u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF54u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF54 INC
    cpu.inc('A');
    goto L_00EF55;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF54u,0x00EF54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF55u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF55 CLC
    cpu.setFlag('C', false);
    goto L_00EF56;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF55u,0x00EF55u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF56u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF56u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF56 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_00EF58;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF56u,0x00EF56u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF58u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF58u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF58 STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_00EF5A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF58u,0x00EF58u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF5Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF5A SEP
    cpu.sep(0x20u);
    goto L_00EF5C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF5Au,0x00EF5Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF5Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Cu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EF5C PLA
    cpu.pop("PLA", hw);
    goto L_00EF5D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF5Cu,0x00EF5Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF5Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF5D CLC
    cpu.setFlag('C', false);
    goto L_00EF5E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF5Du,0x00EF5Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF5Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF5E ADC
    cpu.adc(0x28u);
    goto L_00EF60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF5Eu,0x00EF5Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF60u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF60 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00EF62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF60u,0x00EF60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF62u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF62 TAX
    cpu.transfer("TAX");
    goto L_00EF63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF62u,0x00EF62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF63u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF63 BPL -> $00EF68
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EF68; }
    goto L_00EF65;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF63u,0x00EF63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF65u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF65u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF65 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EF68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF65u,0x00EF65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF68u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 4u, 3u, cpu.address("abs", 0x18B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF68u,0x00EF68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF6Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_00EF6D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,0x00EF6Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF6Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6D STZ
    hw.write(cpu.address("dp", 0x74u), 0, cpu.m8?8:16);
    goto L_00EF6F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Du,0x00EF6Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF6Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Fu, 4u, 3u, cpu.address("abs", 0x1406u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6F STZ
    hw.write(cpu.address("abs", 0x1406u), 0, cpu.m8?8:16);
    goto L_00EF72;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,0x00EF6Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF72u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF72u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF72 STZ
    hw.write(cpu.address("abs", 0x140Du), 0, cpu.m8?8:16);
    goto L_00EF75;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF72u,0x00EF72u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF75u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF75u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF75 LDA
    cpu.setA(0x4u, 8);
    goto L_00EF77;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF75u,0x00EF75u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF77u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF77u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF77u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF77 TSB
    cpu.tsb(hw, cpu.address("dp", 0x77u), cpu.m8?8:16);
    goto L_00EF79;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF77u,0x00EF77u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF79u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF79u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF79u, 4u, 3u, cpu.address("abs", 0x1407u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF79 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1407u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00EF7C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF79u,0x00EF79u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF7Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7C BNE -> $00EF99
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF99; }
    goto L_00EF7E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF7Cu,0x00EF7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF7Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF7Eu, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF81;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF7Eu,0x00EF7Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF81u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF81 BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF95; }
    goto L_00EF83;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF81u,0x00EF81u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF83u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF83u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF83u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF83 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF85;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF83u,0x00EF83u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF85u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF85u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF85 BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF95; }
    goto L_00EF87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF85u,0x00EF85u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF87u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF87u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF87u, 4u, 3u, cpu.address("abs", 0x18E7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF87 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18E7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EF8A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF87u,0x00EF87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF8Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF8A BEQ -> $00EF95
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EF95; }
    goto L_00EF8C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF8Au,0x00EF8Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF8Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF8Cu, 8u, 4u, 0x0286BFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EF8C JSL -> $0286BF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEF8Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEF90u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0286BFu, 0x00EF8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EF90;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF8Cu,0x00EF8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF90u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF90u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF90 LDA
    cpu.setA(0x25u, 8);
    goto L_00EF92;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF90u,0x00EF90u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF92u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF92u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF92 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00EF95;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF92u,0x00EF92u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF95u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF95u, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF95 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF95u,0x00EF95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF98u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EF98 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EF98u);return;} hw.unresolvedReturn(0x00EF98u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF98u,0x00EF98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF99u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF99u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF99u, 4u, 3u, cpu.address("abs", 0x1697u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF99 STZ
    hw.write(cpu.address("abs", 0x1697u), 0, cpu.m8?8:16);
    goto L_00EF9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF99u,0x00EF99u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF9Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF9Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF9Cu, 4u, 3u, cpu.address("abs", 0x1407u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF9C STZ
    hw.write(cpu.address("abs", 0x1407u), 0, cpu.m8?8:16);
    goto L_00EF9F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF9Cu,0x00EF9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF9Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF9Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF9F CPY
    cpu.compareY(0x5u);
    goto L_00EFA1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF9Fu,0x00EF9Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFA1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA1u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFA1 BCS -> $00EFAE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00EFAE; }
    goto L_00EFA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFA1u,0x00EFA1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFA3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFA3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EFA5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFA3u,0x00EFA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFA5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFA5 CMP
    cpu.compareA(0x2u);
    goto L_00EFA7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFA5u,0x00EFA5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFA7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFA7 BNE -> $00EFAD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EFAD; }
    goto L_00EFA9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFA7u,0x00EFA7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFA9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFA9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFA9 SEC
    cpu.setFlag('C', true);
    goto L_00EFAA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFA9u,0x00EFA9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFAAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAAu,cpu,0x6Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAAu, 6u, 3u, cpu.address("abs", 0x13EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFAA ROR
    cpu.rorMem(hw, cpu.address("abs", 0x13EDu), cpu.m8?8:16);
    goto L_00EFAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFAAu,0x00EFAAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFADu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFAD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFADu);return;} hw.unresolvedReturn(0x00EFADu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFADu,0x00EFADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFAEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFAEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EFB0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFAEu,0x00EFAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB0 BEQ -> $00EFBB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00EFBB; }
    goto L_00EFB2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB0u,0x00EFB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB2u, 8u, 4u, 0x0294C1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00EFB2 JSL -> $0294C1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEFB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFB6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0294C1u, 0x00EFB2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00EFB6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB2u,0x00EFB2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB6 LDA
    cpu.setA(0x9u, 8);
    goto L_00EFB8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB6u,0x00EFB6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFB8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFB8u, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EFB8 STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00EFBB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFB8u,0x00EFB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EFBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFBBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFBBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00EFBB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00EFBBu);return;} hw.unresolvedReturn(0x00EFBBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFBBu,0x00EFBBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00F629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF629u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF629u, 8u, 4u, 0x00F606u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00F629 JSL -> $00F606 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF62Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF62Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F606u, 0x00F629u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00F62D;
L_00F62D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF62Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF62Du,0x00F62Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62D STZ
    hw.write(cpu.address("dp", 0x15u), 0, cpu.m8?8:16);
    goto L_00F62F;
L_00F62F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF62Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62F STZ
    hw.write(cpu.address("dp", 0x16u), 0, cpu.m8?8:16);
    goto L_00F631;
L_00F631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF631u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F631 STZ
    hw.write(cpu.address("dp", 0x17u), 0, cpu.m8?8:16);
    goto L_00F633;
L_00F633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF633u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F633 STZ
    hw.write(cpu.address("dp", 0x18u), 0, cpu.m8?8:16);
    goto L_00F635;
L_00F635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF635u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00F635 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00F635u);return;} hw.unresolvedReturn(0x00F635u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00EADB_E0M1X1CQ_part31(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EF68u: goto L_00EF68;
    case 0x00EF6Bu: goto L_00EF6B;
    case 0x00EF6Du: goto L_00EF6D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EF68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF68u))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 5u, 3u, cpu.address("abs", 0x18B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 5u, 3u, cpu.address("abs", 0x18B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 4u, 3u, cpu.address("abs", 0x18B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 4u, 3u, cpu.address("abs", 0x18B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF68u, 4u, 3u, cpu.address("abs", 0x18B5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF68 STZ
    hw.write(cpu.address("abs", 0x18B5u), 0, cpu.m8?8:16);
    goto L_00EF6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF68u,0x00EF68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF6Bu))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_00EF6D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_00EF6D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_00EF6D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_00EF6D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6B STZ
    hw.write(cpu.address("dp", 0x72u), 0, cpu.m8?8:16);
    goto L_00EF6D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Bu,0x00EF6Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EF6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEF6Du))return;
  // 49 variantes de decodificacao M/X para este endereco; 5 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6D STZ
    hw.write(cpu.address("dp", 0x74u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,0x00EF6Du); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6D STZ
    hw.write(cpu.address("dp", 0x74u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,0x00EF6Du); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6D STZ
    hw.write(cpu.address("dp", 0x74u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,0x00EF6Du); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6D STZ
    hw.write(cpu.address("dp", 0x74u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,0x00EF6Du); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEF6Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EF6D STZ
    hw.write(cpu.address("dp", 0x74u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Fu,0x00EF6Du); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEF6Du,0x00EF6Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_019138_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019138u: goto L_019138;
    case 0x019139u: goto L_019139;
    case 0x01913Au: goto L_01913A;
    case 0x01913Bu: goto L_01913B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019138:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9138u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019138 PHB
    cpu.push("PHB", hw);
    goto L_019139;
L_019139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9139u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9139u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019139 PHK
    cpu.push("PHK", hw);
    goto L_01913A;
L_01913A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01913A PLB
    cpu.pop("PLB", hw);
    goto L_01913B;
L_01913B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Bu, 6u, 3u, cpu.address("abs", 0x9140u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01913B JSR -> $019140 stack real
    { cpu.push16Value(hw,0x913Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x913Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9140u), 0x01913Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x913Eu,0x01913Bu); return;
}

void sub_019138_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019138u: goto L_019138;
    case 0x019139u: goto L_019139;
    case 0x01913Au: goto L_01913A;
    case 0x01913Bu: goto L_01913B;
    case 0x01913Eu: goto L_01913E;
    case 0x01913Fu: goto L_01913F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019138:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9138u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019138 PHB
    cpu.push("PHB", hw);
    goto L_019139;
L_019139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9139u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9139u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019139 PHK
    cpu.push("PHK", hw);
    goto L_01913A;
L_01913A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01913A PLB
    cpu.pop("PLB", hw);
    goto L_01913B;
L_01913B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Bu, 6u, 3u, cpu.address("abs", 0x9140u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01913B JSR -> $019140 stack real
    { cpu.push16Value(hw,0x913Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x913Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9140u), 0x01913Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01913E;
L_01913E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x913Eu,0x01913Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01913E PLB
    cpu.pop("PLB", hw);
    goto L_01913F;
L_01913F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01913F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x01913Fu);return;} hw.unresolvedReturn(0x01913Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_019138_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019138u: goto L_019138;
    case 0x019139u: goto L_019139;
    case 0x01913Au: goto L_01913A;
    case 0x01913Bu: goto L_01913B;
    case 0x01913Eu: goto L_01913E;
    case 0x01913Fu: goto L_01913F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019138:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9138u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019138 PHB
    cpu.push("PHB", hw);
    goto L_019139;
L_019139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9139u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9139u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019139 PHK
    cpu.push("PHK", hw);
    goto L_01913A;
L_01913A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01913A PLB
    cpu.pop("PLB", hw);
    goto L_01913B;
L_01913B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Bu, 6u, 3u, cpu.address("abs", 0x9140u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01913B JSR -> $019140 stack real
    { cpu.push16Value(hw,0x913Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x913Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9140u), 0x01913Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_01913E;
L_01913E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01913E PLB
    cpu.pop("PLB", hw);
    goto L_01913F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01913E PLB
    cpu.pop("PLB", hw);
    goto L_01913F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x913Eu,0x01913Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01913F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01913F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x01913Fu);return;} hw.unresolvedReturn(0x01913Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01913F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x01913Fu);return;} hw.unresolvedReturn(0x01913Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x913Fu,0x01913Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_019806_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019806u: goto L_019806;
    case 0x019808u: goto L_019808;
    case 0x01980Bu: goto L_01980B;
    case 0x01980Du: goto L_01980D;
    case 0x01980Fu: goto L_01980F;
    case 0x019812u: goto L_019812;
    case 0x019815u: goto L_019815;
    case 0x019816u: goto L_019816;
    case 0x019818u: goto L_019818;
    case 0x019819u: goto L_019819;
    case 0x01981Bu: goto L_01981B;
    case 0x01981Eu: goto L_01981E;
    case 0x019821u: goto L_019821;
    case 0x019822u: goto L_019822;
    case 0x019825u: goto L_019825;
    case 0x019828u: goto L_019828;
    case 0x01982Au: goto L_01982A;
    case 0x01982Du: goto L_01982D;
    case 0x01982Fu: goto L_01982F;
    case 0x019831u: goto L_019831;
    case 0x019834u: goto L_019834;
    case 0x019837u: goto L_019837;
    case 0x019839u: goto L_019839;
    case 0x01983Cu: goto L_01983C;
    case 0x01983Eu: goto L_01983E;
    case 0x019840u: goto L_019840;
    case 0x019842u: goto L_019842;
    case 0x019843u: goto L_019843;
    case 0x019846u: goto L_019846;
    case 0x019848u: goto L_019848;
    case 0x01984Au: goto L_01984A;
    case 0x01984Du: goto L_01984D;
    case 0x01984Fu: goto L_01984F;
    case 0x019851u: goto L_019851;
    case 0x019853u: goto L_019853;
    case 0x019856u: goto L_019856;
    case 0x019858u: goto L_019858;
    case 0x01985Bu: goto L_01985B;
    case 0x01985Cu: goto L_01985C;
    case 0x01985Eu: goto L_01985E;
    case 0x019860u: goto L_019860;
    case 0x019862u: goto L_019862;
    case 0x019864u: goto L_019864;
    case 0x019867u: goto L_019867;
    case 0x019868u: goto L_019868;
    case 0x01986Au: goto L_01986A;
    case 0x01986Du: goto L_01986D;
    case 0x01986Eu: goto L_01986E;
    case 0x019870u: goto L_019870;
    case 0x019873u: goto L_019873;
    case 0x019876u: goto L_019876;
    case 0x019877u: goto L_019877;
    case 0x019879u: goto L_019879;
    case 0x01987Cu: goto L_01987C;
    case 0x01987Fu: goto L_01987F;
    case 0x019880u: goto L_019880;
    case 0x019882u: goto L_019882;
    case 0x019884u: goto L_019884;
    case 0x019886u: goto L_019886;
    case 0x019888u: goto L_019888;
    case 0x01988Au: goto L_01988A;
    case 0x01988Bu: goto L_01988B;
    case 0x01988Cu: goto L_01988C;
    case 0x01988Fu: goto L_01988F;
    case 0x019892u: goto L_019892;
    case 0x019894u: goto L_019894;
    case 0x019897u: goto L_019897;
    case 0x01989Au: goto L_01989A;
    case 0x01989Bu: goto L_01989B;
    case 0x01989Cu: goto L_01989C;
    case 0x01989Du: goto L_01989D;
    case 0x01989Eu: goto L_01989E;
    case 0x0198A0u: goto L_0198A0;
    case 0x0198A3u: goto L_0198A3;
    case 0x0198A6u: goto L_0198A6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9806u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9806u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019806 LDA
    cpu.setA(0x6u, 8);
    goto L_019808;
L_019808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9808u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9808u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019808 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01980B;
L_01980B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01980B BNE -> $01980F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01980F; }
    goto L_01980D;
L_01980D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01980D LDA
    cpu.setA(0x8u, 8);
    goto L_01980F;
L_01980F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Fu, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01980F STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_019812;
L_019812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9812u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9812u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019812 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15EAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019815;
L_019815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9815u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9815u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019815 PHA
    cpu.push("PHA", hw);
    goto L_019816;
L_019816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9816u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9816u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019816 BEQ -> $01981B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01981B; }
    goto L_019818;
L_019818:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9818u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9818u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9818u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019818 CLC
    cpu.setFlag('C', false);
    goto L_019819;
L_019819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9819u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9819u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9819u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019819 ADC
    cpu.adc(0x8u);
    goto L_01981B;
L_01981B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x981Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x981Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x981Bu, 5u, 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01981B STA
    hw.write(cpu.address("absx", 0x15EAu), cpu.a, cpu.m8?8:16);
    goto L_01981E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x981Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x981Bu, 5u, 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01981B STA
    hw.write(cpu.address("absx", 0x15EAu), cpu.a, cpu.m8?8:16);
    goto L_01981E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x981Bu,0x01981Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_01981E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x981Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x981Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x981Eu, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01981E JSR -> $019F0D stack real
    { cpu.push16Value(hw,0x9820u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9821u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0x01981Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019821;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x981Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x981Eu, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01981E JSR -> $019F0D stack real
    { cpu.push16Value(hw,0x9820u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9821u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0x01981Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019821;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x981Eu,0x01981Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_019821:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9821u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9821u,0x019821u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9821u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9821u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019821 PLA
    cpu.pop("PLA", hw);
    goto L_019822;
L_019822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9822u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9822u, 5u, 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019822 STA
    hw.write(cpu.address("absx", 0x15EAu), cpu.a, cpu.m8?8:16);
    goto L_019825;
L_019825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9825u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9825u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9825u, 4u, 3u, cpu.address("abs", 0x1EEBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019825 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1EEBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019828;
L_019828:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9828u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9828u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9828u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019828 BMI -> $0198A6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0198A6; }
    goto L_01982A;
L_01982A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x982Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x982Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x982Au, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01982A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01982D;
L_01982D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x982Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x982Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x982Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01982D CMP
    cpu.compareA(0x6u);
    goto L_01982F;
L_01982F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x982Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x982Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x982Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01982F BNE -> $0198A6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0198A6; }
    goto L_019831;
L_019831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9831u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9831u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019831 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_019834;
L_019834:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9834u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9834u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9834u, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019834 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019837;
L_019837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9837u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9837u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019837 BNE -> $019842
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_019842; }
    goto L_019839;
L_019839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9839u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9839u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9839u, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019839 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01983C;
L_01983C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x983Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x983Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x983Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01983C BEQ -> $0198A6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0198A6; }
    goto L_01983E;
L_01983E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x983Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x983Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x983Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01983E CMP
    cpu.compareA(0x30u);
    goto L_019840;
L_019840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9840u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9840u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019840 BCS -> $01984D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_01984D; }
    goto L_019842;
L_019842:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9842u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9842u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9842u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019842 LSR
    cpu.lsrA();
    goto L_019843;
L_019843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9843u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9843u, 4u + ((((0x0308u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0308u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019843 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x308u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019846;
L_019846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9846u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9846u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019846 ADC
    cpu.adc(0x0u);
    goto L_019848;
L_019848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9848u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9848u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019848 BCS -> $01984D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_01984D; }
    goto L_01984A;
L_01984A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Au, 5u, 3u, cpu.address("absy", 0x0308u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01984A STA
    hw.write(cpu.address("absy", 0x308u), cpu.a, cpu.m8?8:16);
    goto L_01984D;
L_01984D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01984D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01984F;
L_01984F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01984F CMP
    cpu.compareA(0x11u);
    goto L_019851;
L_019851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019851 BEQ -> $0198A6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0198A6; }
    goto L_019853;
L_019853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9853u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9853u, 6u, 3u, cpu.address("abs", 0x80CBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019853 JSR -> $0180CB stack real
    { cpu.push16Value(hw,0x9855u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9856u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80CBu), 0x019853u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019856;
L_019856:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9856u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9856u,0x019856u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9856u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9856u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019856 BNE -> $0198A6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0198A6; }
    goto L_019858;
L_019858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9858u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9858u, 4u + ((((0x15F6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019858 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01985B;
L_01985B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01985B ASL
    cpu.aslA();
    goto L_01985C;
L_01985C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01985C LDA
    cpu.setA(0x8u, 8);
    goto L_01985E;
L_01985E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01985E BCC -> $019862
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_019862; }
    goto L_019860;
L_019860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9860u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9860u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019860 LDA
    cpu.setA(0x0u, 8);
    goto L_019862;
L_019862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9862u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9862u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019862 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_019864;
L_019864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9864u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9864u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9864u, 4u + ((((0x0308u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0308u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019864 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x308u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019867;
L_019867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9867u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9867u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019867 CLC
    cpu.setFlag('C', false);
    goto L_019868;
L_019868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9868u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9868u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019868 ADC
    cpu.adc(0x2u);
    goto L_01986A;
L_01986A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x986Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x986Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x986Au, 5u, 3u, cpu.address("absy", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01986A STA
    hw.write(cpu.address("absy", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_01986D;
L_01986D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x986Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x986Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x986Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01986D CLC
    cpu.setFlag('C', false);
    goto L_01986E;
L_01986E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x986Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x986Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x986Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01986E ADC
    cpu.adc(0x4u);
    goto L_019870;
L_019870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9870u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9870u, 5u, 3u, cpu.address("absy", 0x0304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019870 STA
    hw.write(cpu.address("absy", 0x304u), cpu.a, cpu.m8?8:16);
    goto L_019873;
L_019873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9873u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9873u, 4u + ((((0x0309u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0309u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019873 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x309u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019876;
L_019876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9876u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9876u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019876 CLC
    cpu.setFlag('C', false);
    goto L_019877;
L_019877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9877u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9877u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9877u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019877 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_019879;
L_019879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9879u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9879u, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019879 STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_01987C;
L_01987C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x987Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x987Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x987Cu, 5u, 3u, cpu.address("absy", 0x0305u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01987C STA
    hw.write(cpu.address("absy", 0x305u), cpu.a, cpu.m8?8:16);
    goto L_01987F;
L_01987F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x987Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x987Fu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x987Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01987F PHY
    cpu.push("PHY", hw);
    goto L_019880;
L_019880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9880u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9880u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019880 LDY
    cpu.setY(0x64u, 8);
    goto L_019882;
L_019882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9882u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9882u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019882 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019884;
L_019884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9884u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9884u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019884 AND
    cpu.logicAnd(0xF8u);
    goto L_019886;
L_019886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9886u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9886u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9886u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019886 BNE -> $01988A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01988A; }
    goto L_019888;
L_019888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9888u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9888u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019888 LDY
    cpu.setY(0x4Du, 8);
    goto L_01988A;
L_01988A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Au,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01988A TYA
    cpu.transfer("TYA");
    goto L_01988B;
L_01988B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Bu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01988B PLY
    cpu.pop("PLY", hw);
    goto L_01988C;
L_01988C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Cu, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01988C STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_01988F;
L_01988F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Fu, 5u, 3u, cpu.address("absy", 0x0306u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01988F STA
    hw.write(cpu.address("absy", 0x306u), cpu.a, cpu.m8?8:16);
    goto L_019892;
L_019892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9892u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9892u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019892 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019894;
L_019894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9894u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9894u, 5u, 3u, cpu.address("absy", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019894 STA
    hw.write(cpu.address("absy", 0x303u), cpu.a, cpu.m8?8:16);
    goto L_019897;
L_019897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9897u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9897u, 5u, 3u, cpu.address("absy", 0x0307u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019897 STA
    hw.write(cpu.address("absy", 0x307u), cpu.a, cpu.m8?8:16);
    goto L_01989A;
L_01989A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Au,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01989A TYA
    cpu.transfer("TYA");
    goto L_01989B;
L_01989B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01989B LSR
    cpu.lsrA();
    goto L_01989C;
L_01989C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01989C LSR
    cpu.lsrA();
    goto L_01989D;
L_01989D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01989D TAY
    cpu.transfer("TAY");
    goto L_01989E;
L_01989E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01989E LDA
    cpu.setA(0x0u, 8);
    goto L_0198A0;
L_0198A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A0u, 5u, 3u, cpu.address("absy", 0x0460u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0198A0 STA
    hw.write(cpu.address("absy", 0x460u), cpu.a, cpu.m8?8:16);
    goto L_0198A3;
L_0198A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A3u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A3u, 5u, 3u, cpu.address("absy", 0x0461u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0198A3 STA
    hw.write(cpu.address("absy", 0x461u), cpu.a, cpu.m8?8:16);
    goto L_0198A6;
L_0198A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0198A6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0198A6u);return;} hw.unresolvedReturn(0x0198A6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_019806_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x019806u: goto L_019806;
    case 0x019808u: goto L_019808;
    case 0x01980Bu: goto L_01980B;
    case 0x01980Du: goto L_01980D;
    case 0x01980Fu: goto L_01980F;
    case 0x019812u: goto L_019812;
    case 0x019815u: goto L_019815;
    case 0x019816u: goto L_019816;
    case 0x019818u: goto L_019818;
    case 0x019819u: goto L_019819;
    case 0x01981Bu: goto L_01981B;
    case 0x01981Eu: goto L_01981E;
    case 0x019821u: goto L_019821;
    case 0x019822u: goto L_019822;
    case 0x019825u: goto L_019825;
    case 0x019828u: goto L_019828;
    case 0x01982Au: goto L_01982A;
    case 0x01982Du: goto L_01982D;
    case 0x01982Fu: goto L_01982F;
    case 0x019831u: goto L_019831;
    case 0x019834u: goto L_019834;
    case 0x019837u: goto L_019837;
    case 0x019839u: goto L_019839;
    case 0x01983Cu: goto L_01983C;
    case 0x01983Eu: goto L_01983E;
    case 0x019840u: goto L_019840;
    case 0x019842u: goto L_019842;
    case 0x019843u: goto L_019843;
    case 0x019846u: goto L_019846;
    case 0x019848u: goto L_019848;
    case 0x01984Au: goto L_01984A;
    case 0x01984Du: goto L_01984D;
    case 0x01984Fu: goto L_01984F;
    case 0x019851u: goto L_019851;
    case 0x019853u: goto L_019853;
    case 0x019856u: goto L_019856;
    case 0x019858u: goto L_019858;
    case 0x01985Bu: goto L_01985B;
    case 0x01985Cu: goto L_01985C;
    case 0x01985Eu: goto L_01985E;
    case 0x019860u: goto L_019860;
    case 0x019862u: goto L_019862;
    case 0x019864u: goto L_019864;
    case 0x019867u: goto L_019867;
    case 0x019868u: goto L_019868;
    case 0x01986Au: goto L_01986A;
    case 0x01986Du: goto L_01986D;
    case 0x01986Eu: goto L_01986E;
    case 0x019870u: goto L_019870;
    case 0x019873u: goto L_019873;
    case 0x019876u: goto L_019876;
    case 0x019877u: goto L_019877;
    case 0x019879u: goto L_019879;
    case 0x01987Cu: goto L_01987C;
    case 0x01987Fu: goto L_01987F;
    case 0x019880u: goto L_019880;
    case 0x019882u: goto L_019882;
    case 0x019884u: goto L_019884;
    case 0x019886u: goto L_019886;
    case 0x019888u: goto L_019888;
    case 0x01988Au: goto L_01988A;
    case 0x01988Bu: goto L_01988B;
    case 0x01988Cu: goto L_01988C;
    case 0x01988Fu: goto L_01988F;
    case 0x019892u: goto L_019892;
    case 0x019894u: goto L_019894;
    case 0x019897u: goto L_019897;
    case 0x01989Au: goto L_01989A;
    case 0x01989Bu: goto L_01989B;
    case 0x01989Cu: goto L_01989C;
    case 0x01989Du: goto L_01989D;
    case 0x01989Eu: goto L_01989E;
    case 0x0198A0u: goto L_0198A0;
    case 0x0198A3u: goto L_0198A3;
    case 0x0198A6u: goto L_0198A6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_019806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9806u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9806u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019806 LDA
    cpu.setA(0x6u, 8);
    goto L_019808;
L_019808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9808u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9808u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019808 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01980B;
L_01980B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01980B BNE -> $01980F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01980F; }
    goto L_01980D;
L_01980D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01980D LDA
    cpu.setA(0x8u, 8);
    goto L_01980F;
L_01980F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Fu, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01980F STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_019812;
L_019812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9812u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9812u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019812 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15EAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019815;
L_019815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9815u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9815u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019815 PHA
    cpu.push("PHA", hw);
    goto L_019816;
L_019816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9816u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9816u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019816 BEQ -> $01981B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01981B; }
    goto L_019818;
L_019818:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9818u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9818u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9818u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019818 CLC
    cpu.setFlag('C', false);
    goto L_019819;
L_019819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9819u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9819u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9819u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019819 ADC
    cpu.adc(0x8u);
    goto L_01981B;
L_01981B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x981Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x981Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x981Bu, 5u, 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01981B STA
    hw.write(cpu.address("absx", 0x15EAu), cpu.a, cpu.m8?8:16);
    goto L_01981E;
L_01981E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x981Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x981Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x981Eu, 6u, 3u, cpu.address("abs", 0x9F0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01981E JSR -> $019F0D stack real
    { cpu.push16Value(hw,0x9820u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9821u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F0Du), 0x01981Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019821;
L_019821:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9821u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9821u,0x019821u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9821u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9821u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $019821 PLA
    cpu.pop("PLA", hw);
    goto L_019822;
L_019822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9822u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9822u, 5u, 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019822 STA
    hw.write(cpu.address("absx", 0x15EAu), cpu.a, cpu.m8?8:16);
    goto L_019825;
L_019825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9825u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9825u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9825u, 4u, 3u, cpu.address("abs", 0x1EEBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019825 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1EEBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019828;
L_019828:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9828u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9828u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9828u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019828 BMI -> $0198A6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0198A6; }
    goto L_01982A;
L_01982A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x982Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x982Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x982Au, 4u + ((((0x1602u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01982A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1602u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01982D;
L_01982D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x982Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x982Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x982Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01982D CMP
    cpu.compareA(0x6u);
    goto L_01982F;
L_01982F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x982Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x982Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x982Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01982F BNE -> $0198A6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0198A6; }
    goto L_019831;
L_019831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9831u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9831u, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019831 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_019834;
L_019834:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9834u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9834u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9834u, 4u + ((((0x1558u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1558u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019834 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1558u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019837;
L_019837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9837u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9837u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019837 BNE -> $019842
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_019842; }
    goto L_019839;
L_019839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9839u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9839u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9839u, 4u + ((((0x1540u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019839 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1540u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01983C;
L_01983C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x983Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x983Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x983Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01983C BEQ -> $0198A6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0198A6; }
    goto L_01983E;
L_01983E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x983Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x983Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x983Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01983E CMP
    cpu.compareA(0x30u);
    goto L_019840;
L_019840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9840u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9840u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019840 BCS -> $01984D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_01984D; }
    goto L_019842;
L_019842:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9842u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9842u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9842u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019842 LSR
    cpu.lsrA();
    goto L_019843;
L_019843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9843u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9843u, 4u + ((((0x0308u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0308u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019843 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x308u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019846;
L_019846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9846u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9846u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019846 ADC
    cpu.adc(0x0u);
    goto L_019848;
L_019848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9848u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9848u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019848 BCS -> $01984D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_01984D; }
    goto L_01984A;
L_01984A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Au, 5u, 3u, cpu.address("absy", 0x0308u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01984A STA
    hw.write(cpu.address("absy", 0x308u), cpu.a, cpu.m8?8:16);
    goto L_01984D;
L_01984D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01984D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01984F;
L_01984F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01984F CMP
    cpu.compareA(0x11u);
    goto L_019851;
L_019851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019851 BEQ -> $0198A6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0198A6; }
    goto L_019853;
L_019853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9853u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9853u, 6u, 3u, cpu.address("abs", 0x80CBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $019853 JSR -> $0180CB stack real
    { cpu.push16Value(hw,0x9855u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9856u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80CBu), 0x019853u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_019856;
L_019856:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9856u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9856u,0x019856u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9856u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9856u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019856 BNE -> $0198A6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0198A6; }
    goto L_019858;
L_019858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9858u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9858u, 4u + ((((0x15F6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019858 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01985B;
L_01985B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01985B ASL
    cpu.aslA();
    goto L_01985C;
L_01985C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01985C LDA
    cpu.setA(0x8u, 8);
    goto L_01985E;
L_01985E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x985Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x985Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x985Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01985E BCC -> $019862
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_019862; }
    goto L_019860;
L_019860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9860u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9860u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019860 LDA
    cpu.setA(0x0u, 8);
    goto L_019862;
L_019862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9862u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9862u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019862 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_019864;
L_019864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9864u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9864u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9864u, 4u + ((((0x0308u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0308u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019864 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x308u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019867;
L_019867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9867u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9867u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019867 CLC
    cpu.setFlag('C', false);
    goto L_019868;
L_019868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9868u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9868u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019868 ADC
    cpu.adc(0x2u);
    goto L_01986A;
L_01986A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x986Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x986Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x986Au, 5u, 3u, cpu.address("absy", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01986A STA
    hw.write(cpu.address("absy", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_01986D;
L_01986D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x986Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x986Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x986Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01986D CLC
    cpu.setFlag('C', false);
    goto L_01986E;
L_01986E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x986Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x986Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x986Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01986E ADC
    cpu.adc(0x4u);
    goto L_019870;
L_019870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9870u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9870u, 5u, 3u, cpu.address("absy", 0x0304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019870 STA
    hw.write(cpu.address("absy", 0x304u), cpu.a, cpu.m8?8:16);
    goto L_019873;
L_019873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9873u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9873u, 4u + ((((0x0309u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x0309u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019873 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x309u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019876;
L_019876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9876u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9876u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019876 CLC
    cpu.setFlag('C', false);
    goto L_019877;
L_019877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9877u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9877u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9877u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019877 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_019879;
L_019879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9879u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9879u, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019879 STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_01987C;
L_01987C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x987Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x987Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x987Cu, 5u, 3u, cpu.address("absy", 0x0305u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01987C STA
    hw.write(cpu.address("absy", 0x305u), cpu.a, cpu.m8?8:16);
    goto L_01987F;
L_01987F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x987Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x987Fu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x987Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01987F PHY
    cpu.push("PHY", hw);
    goto L_019880;
L_019880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9880u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9880u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019880 LDY
    cpu.setY(0x64u, 8);
    goto L_019882;
L_019882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9882u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9882u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019882 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019884;
L_019884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9884u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9884u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019884 AND
    cpu.logicAnd(0xF8u);
    goto L_019886;
L_019886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9886u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9886u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9886u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019886 BNE -> $01988A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01988A; }
    goto L_019888;
L_019888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9888u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9888u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019888 LDY
    cpu.setY(0x4Du, 8);
    goto L_01988A;
L_01988A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Au,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01988A TYA
    cpu.transfer("TYA");
    goto L_01988B;
L_01988B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Bu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01988B PLY
    cpu.pop("PLY", hw);
    goto L_01988C;
L_01988C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Cu, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01988C STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_01988F;
L_01988F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Fu, 5u, 3u, cpu.address("absy", 0x0306u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01988F STA
    hw.write(cpu.address("absy", 0x306u), cpu.a, cpu.m8?8:16);
    goto L_019892;
L_019892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9892u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9892u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x64u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019892 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x64u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_019894;
L_019894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9894u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9894u, 5u, 3u, cpu.address("absy", 0x0303u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019894 STA
    hw.write(cpu.address("absy", 0x303u), cpu.a, cpu.m8?8:16);
    goto L_019897;
L_019897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9897u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9897u, 5u, 3u, cpu.address("absy", 0x0307u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $019897 STA
    hw.write(cpu.address("absy", 0x307u), cpu.a, cpu.m8?8:16);
    goto L_01989A;
L_01989A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Au,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01989A TYA
    cpu.transfer("TYA");
    goto L_01989B;
L_01989B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01989B LSR
    cpu.lsrA();
    goto L_01989C;
L_01989C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01989C LSR
    cpu.lsrA();
    goto L_01989D;
L_01989D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01989D TAY
    cpu.transfer("TAY");
    goto L_01989E;
L_01989E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01989E LDA
    cpu.setA(0x0u, 8);
    goto L_0198A0;
L_0198A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A0u, 5u, 3u, cpu.address("absy", 0x0460u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0198A0 STA
    hw.write(cpu.address("absy", 0x460u), cpu.a, cpu.m8?8:16);
    goto L_0198A3;
L_0198A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A3u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A3u, 5u, 3u, cpu.address("absy", 0x0461u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0198A3 STA
    hw.write(cpu.address("absy", 0x461u), cpu.a, cpu.m8?8:16);
    goto L_0198A6;
L_0198A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0198A6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0198A6u);return;} hw.unresolvedReturn(0x0198A6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_028752_E1M1X1CQ_part5(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0289F2u: goto L_0289F2;
    case 0x0289F3u: goto L_0289F3;
    case 0x0289F4u: goto L_0289F4;
    case 0x0289F6u: goto L_0289F6;
    case 0x0289F9u: goto L_0289F9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0289F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F2u))return;
  // 31 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F2u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0289F2 PHP
    cpu.push("PHP", hw);
    goto L_0289F3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x89F2u,0x0289F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0289F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F3u))return;
  // 31 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F3u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0289F3 DEY
    cpu.decReg('Y');
    goto L_0289F4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x89F3u,0x0289F3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0289F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F4u))return;
  // 31 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0289F4 BPL -> $0289E1
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x0289E1u,0x0289F4u); return; }
    goto L_0289F6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x89F4u,0x0289F4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0289F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F6u))return;
  // 31 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F6u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F6u, 5u, 3u, cpu.address("abs", 0x18E2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0289F6 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x18E2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0289F9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x89F6u,0x0289F6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0289F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89F9u))return;
  // 31 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89F9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0289F9 BNE -> $0289EF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x0289EFu,0x0289F9u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x89FBu,0x0289F9u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x89F9u,0x0289F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_028752_E1M1X1CQ_part9(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x028A29u: goto L_028A29;
    case 0x028A2Au: goto L_028A2A;
    case 0x028A2Cu: goto L_028A2C;
    case 0x028A2Du: goto L_028A2D;
    case 0x028A2Eu: goto L_028A2E;
    case 0x028A2Fu: goto L_028A2F;
    case 0x028A30u: goto L_028A30;
    case 0x028A32u: goto L_028A32;
    case 0x028A35u: goto L_028A35;
    case 0x028A36u: goto L_028A36;
    case 0x028A39u: goto L_028A39;
    case 0x028A3Cu: goto L_028A3C;
    case 0x028A40u: goto L_028A40;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_028A29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A29u))return;
  // 33 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A29u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A29u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $028A29 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x028A29u);return;} hw.unresolvedReturn(0x028A29u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A29u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A29u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $028A29 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x028A29u);return;} hw.unresolvedReturn(0x028A29u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A29u,0x028A29u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028A2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A2A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028A2C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A2Au,0x028A2Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028A2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A2C LSR
    cpu.lsrA();
    goto L_028A2D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A2Cu,0x028A2Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028A2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A2D LSR
    cpu.lsrA();
    goto L_028A2E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A2Du,0x028A2Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028A2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A2E LSR
    cpu.lsrA();
    goto L_028A2F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A2Eu,0x028A2Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028A2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A2F LSR
    cpu.lsrA();
    goto L_028A30;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A2Fu,0x028A2Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028A30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A30u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A30u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A30u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A30 AND
    cpu.logicAnd(0x1u);
    goto L_028A32;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A30u,0x028A30u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028A32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A32u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A32u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A32u, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A32 STA
    hw.write(cpu.address("absx", 0x151Cu), cpu.a, cpu.m8?8:16);
    goto L_028A35;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A32u,0x028A32u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028A35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A35u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A35u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A35 TAY
    cpu.transfer("TAY");
    goto L_028A36;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A35u,0x028A35u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028A36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A36u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A36u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A36u, 4u + 1u, 3u, cpu.address("absy", 0x8A42u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A36 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8A42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_028A39;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A36u,0x028A36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028A39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A39u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A39u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A39u, 5u, 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A39 STA
    hw.write(cpu.address("absx", 0x15F6u), cpu.a, cpu.m8?8:16);
    goto L_028A3C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A39u,0x028A39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028A3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Cu, 8u, 4u, 0x028A44u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $028A3C JSL -> $028A44 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A3Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A40u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x028A44u, 0x028A3Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_028A40;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A3Cu,0x028A3Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_028A40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A40u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==true && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A40u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A40u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $028A40 BRA -> $028A0D
    hw.requestDispatch(0x028A0Du,0x028A40u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A40u,0x028A40u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_029398_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x029391u: goto L_029391;
    case 0x029394u: goto L_029394;
    case 0x029397u: goto L_029397;
    case 0x029398u: goto L_029398;
    case 0x02939Bu: goto L_02939B;
    case 0x02939Du: goto L_02939D;
    case 0x0293A0u: goto L_0293A0;
    case 0x0293A2u: goto L_0293A2;
    case 0x0293A5u: goto L_0293A5;
    case 0x0293A7u: goto L_0293A7;
    case 0x0293A9u: goto L_0293A9;
    case 0x0293ACu: goto L_0293AC;
    case 0x0293AEu: goto L_0293AE;
    case 0x0293B0u: goto L_0293B0;
    case 0x0293B3u: goto L_0293B3;
    case 0x0293B6u: goto L_0293B6;
    case 0x0293B8u: goto L_0293B8;
    case 0x0293BAu: goto L_0293BA;
    case 0x0293BCu: goto L_0293BC;
    case 0x0293BEu: goto L_0293BE;
    case 0x0293C1u: goto L_0293C1;
    case 0x0293C3u: goto L_0293C3;
    case 0x0293C6u: goto L_0293C6;
    case 0x0293C9u: goto L_0293C9;
    case 0x0293CCu: goto L_0293CC;
    case 0x0293CEu: goto L_0293CE;
    case 0x0293D1u: goto L_0293D1;
    case 0x0293D2u: goto L_0293D2;
    case 0x0293D4u: goto L_0293D4;
    case 0x0293D6u: goto L_0293D6;
    case 0x0293D8u: goto L_0293D8;
    case 0x0293D9u: goto L_0293D9;
    case 0x0293DCu: goto L_0293DC;
    case 0x0293DEu: goto L_0293DE;
    case 0x0293E2u: goto L_0293E2;
    case 0x0293E4u: goto L_0293E4;
    case 0x0293E6u: goto L_0293E6;
    case 0x0293E9u: goto L_0293E9;
    case 0x0293EBu: goto L_0293EB;
    case 0x0293EEu: goto L_0293EE;
    case 0x0293F2u: goto L_0293F2;
    case 0x0293F4u: goto L_0293F4;
    case 0x0293F7u: goto L_0293F7;
    case 0x0293FAu: goto L_0293FA;
    case 0x0293FBu: goto L_0293FB;
    case 0x0293FDu: goto L_0293FD;
    case 0x029400u: goto L_029400;
    case 0x029403u: goto L_029403;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_029391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9391u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9391u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9391u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $029391 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x029391u);return;} hw.unresolvedReturn(0x029391u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_029394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9394u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9394u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9394u, 5u, 3u, cpu.address("absx", 0x16CDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029394 STZ
    hw.write(cpu.address("absx", 0x16CDu), 0, cpu.m8?8:16);
    goto L_029397;
L_029397:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9397u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9397u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9397u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $029397 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x029397u);return;} hw.unresolvedReturn(0x029397u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_029398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9398u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9398u, 4u + ((((0x16CDu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x16CDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029398 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x16CDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02939B;
L_02939B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x939Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x939Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x939Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02939B BEQ -> $029397
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_029397; }
    goto L_02939D;
L_02939D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x939Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x939Du,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x939Du, 7u, 3u, cpu.address("absx", 0x18F8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02939D DEC
    cpu.decMem(hw, cpu.address("absx", 0x18F8u), cpu.m8?8:16);
    goto L_0293A0;
L_0293A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293A0 BEQ -> $029394
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_029394; }
    goto L_0293A2;
L_0293A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A2u, 4u + ((((0x18F8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x18F8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293A2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x18F8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0293A5;
L_0293A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293A5 CMP
    cpu.compareA(0x3u);
    goto L_0293A7;
L_0293A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A7u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293A7 BCS -> $029391
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_029391; }
    goto L_0293A9;
L_0293A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A9u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A9u, 4u, 3u, cpu.address("abs", 0x1698u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293A9 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1698u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0293AC;
L_0293AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ACu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293AC STZ
    hw.write(cpu.address("dp", 0xEu), 0, cpu.m8?8:16);
    goto L_0293AE;
L_0293AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93AEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293AE LDX
    cpu.setX(0xBu, 8);
    goto L_0293B0;
L_0293B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B0u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B0u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293B0 STX
    hw.write(cpu.address("abs", 0x15E9u), cpu.x, cpu.x8?8:16);
    goto L_0293B3;
L_0293B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B3u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293B3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0293B6;
L_0293B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293B6 CMP
    cpu.compareA(0xBu);
    goto L_0293B8;
L_0293B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293B8 BEQ -> $0293F7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0293F7; }
    goto L_0293BA;
L_0293BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93BAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293BA CMP
    cpu.compareA(0x8u);
    goto L_0293BC;
L_0293BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93BCu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293BC BCC -> $0293F7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0293F7; }
    goto L_0293BE;
L_0293BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93BEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93BEu, 4u + ((((0x166Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x166Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293BE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x166Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0293C1;
L_0293C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293C1 AND
    cpu.logicAnd(0x20u);
    goto L_0293C3;
L_0293C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C3u, 4u + ((((0x15D0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293C3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15D0u), cpu.m8?8:16));
    goto L_0293C6;
L_0293C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C6u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C6u, 4u + ((((0x154Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293C6 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x154Cu), cpu.m8?8:16));
    goto L_0293C9;
L_0293C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C9u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C9u, 4u + ((((0x1FE2u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1FE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293C9 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1FE2u), cpu.m8?8:16));
    goto L_0293CC;
L_0293CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293CC BNE -> $0293F7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0293F7; }
    goto L_0293CE;
L_0293CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CEu, 4u + ((((0x1632u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1632u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293CE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1632u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0293D1;
L_0293D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D1u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0293D1 PHY
    cpu.push("PHY", hw);
    goto L_0293D2;
L_0293D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D2u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293D2 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x74u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0293D4;
L_0293D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293D4 BEQ -> $0293D8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0293D8; }
    goto L_0293D6;
L_0293D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D6u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293D6 EOR
    cpu.logicXor(0x1u);
    goto L_0293D8;
L_0293D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D8u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0293D8 PLY
    cpu.pop("PLY", hw);
    goto L_0293D9;
L_0293D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D9u,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D9u, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293D9 EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0x13F9u), cpu.m8?8:16));
    goto L_0293DC;
L_0293DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293DC BNE -> $0293F7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0293F7; }
    goto L_0293DE;
L_0293DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DEu, 8u, 4u, 0x03B69Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0293DE JSL -> $03B69F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x93E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93E2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x03B69Fu, 0x0293DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0293E2;
L_0293E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93E2u,0x0293E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293E2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0293E4;
L_0293E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293E4 BEQ -> $0293EB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0293EB; }
    goto L_0293E6;
L_0293E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E6u, 6u, 3u, cpu.address("abs", 0x9696u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0293E6 JSR -> $029696 stack real
    { cpu.push16Value(hw,0x93E8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93E9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9696u), 0x0293E6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0293E9;
L_0293E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93E9u,0x0293E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293E9 BRA -> $0293EE
    goto L_0293EE;
L_0293EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EBu, 6u, 3u, cpu.address("abs", 0x9663u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0293EB JSR -> $029663 stack real
    { cpu.push16Value(hw,0x93EDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93EEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9663u), 0x0293EBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0293EE;
L_0293EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93EEu,0x0293EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EEu, 8u, 4u, 0x03B72Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0293EE JSL -> $03B72B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x93F1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93F2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x03B72Bu, 0x0293EEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0293F2;
L_0293F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93F2u,0x0293F2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F2u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293F2 BCC -> $0293F7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0293F7; }
    goto L_0293F4;
L_0293F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u, 6u, 3u, cpu.address("abs", 0x9404u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0293F4 JSR -> $029404 stack real
    { cpu.push16Value(hw,0x93F6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93F7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9404u), 0x0293F4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0293F7;
L_0293F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93F7u,0x0293F7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u, 4u, 3u, cpu.address("abs", 0x1698u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293F7 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1698u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0293FA;
L_0293FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FAu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293FA DEX
    cpu.decReg('X');
    goto L_0293FB;
L_0293FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FBu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293FB BMI -> $029400
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_029400; }
    goto L_0293FD;
L_0293FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FDu, 3u, 3u, cpu.address("abs", 0x93B0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293FD JMP -> $0293B0
    goto L_0293B0;
L_029400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9400u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9400u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9400u, 4u, 3u, cpu.address("abs", 0x1698u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029400 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1698u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_029403;
L_029403:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9403u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9403u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9403u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $029403 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x029403u);return;} hw.unresolvedReturn(0x029403u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_029398_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x029391u: goto L_029391;
    case 0x029394u: goto L_029394;
    case 0x029397u: goto L_029397;
    case 0x029398u: goto L_029398;
    case 0x02939Bu: goto L_02939B;
    case 0x02939Du: goto L_02939D;
    case 0x0293A0u: goto L_0293A0;
    case 0x0293A2u: goto L_0293A2;
    case 0x0293A5u: goto L_0293A5;
    case 0x0293A7u: goto L_0293A7;
    case 0x0293A9u: goto L_0293A9;
    case 0x0293ACu: goto L_0293AC;
    case 0x0293AEu: goto L_0293AE;
    case 0x0293B0u: goto L_0293B0;
    case 0x0293B3u: goto L_0293B3;
    case 0x0293B6u: goto L_0293B6;
    case 0x0293B8u: goto L_0293B8;
    case 0x0293BAu: goto L_0293BA;
    case 0x0293BCu: goto L_0293BC;
    case 0x0293BEu: goto L_0293BE;
    case 0x0293C1u: goto L_0293C1;
    case 0x0293C3u: goto L_0293C3;
    case 0x0293C6u: goto L_0293C6;
    case 0x0293C9u: goto L_0293C9;
    case 0x0293CCu: goto L_0293CC;
    case 0x0293CEu: goto L_0293CE;
    case 0x0293D1u: goto L_0293D1;
    case 0x0293D2u: goto L_0293D2;
    case 0x0293D4u: goto L_0293D4;
    case 0x0293D6u: goto L_0293D6;
    case 0x0293D8u: goto L_0293D8;
    case 0x0293D9u: goto L_0293D9;
    case 0x0293DCu: goto L_0293DC;
    case 0x0293DEu: goto L_0293DE;
    case 0x0293E2u: goto L_0293E2;
    case 0x0293E4u: goto L_0293E4;
    case 0x0293E6u: goto L_0293E6;
    case 0x0293E9u: goto L_0293E9;
    case 0x0293EBu: goto L_0293EB;
    case 0x0293EEu: goto L_0293EE;
    case 0x0293F2u: goto L_0293F2;
    case 0x0293F4u: goto L_0293F4;
    case 0x0293F7u: goto L_0293F7;
    case 0x0293FAu: goto L_0293FA;
    case 0x0293FBu: goto L_0293FB;
    case 0x0293FDu: goto L_0293FD;
    case 0x029400u: goto L_029400;
    case 0x029403u: goto L_029403;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_029391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9391u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9391u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9391u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $029391 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x029391u);return;} hw.unresolvedReturn(0x029391u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_029394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9394u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9394u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9394u, 5u, 3u, cpu.address("absx", 0x16CDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029394 STZ
    hw.write(cpu.address("absx", 0x16CDu), 0, cpu.m8?8:16);
    goto L_029397;
L_029397:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9397u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9397u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9397u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $029397 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x029397u);return;} hw.unresolvedReturn(0x029397u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_029398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9398u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9398u, 4u + ((((0x16CDu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x16CDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029398 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x16CDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02939B;
L_02939B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x939Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x939Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x939Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02939B BEQ -> $029397
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_029397; }
    goto L_02939D;
L_02939D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x939Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x939Du,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x939Du, 7u, 3u, cpu.address("absx", 0x18F8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02939D DEC
    cpu.decMem(hw, cpu.address("absx", 0x18F8u), cpu.m8?8:16);
    goto L_0293A0;
L_0293A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293A0 BEQ -> $029394
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_029394; }
    goto L_0293A2;
L_0293A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A2u, 4u + ((((0x18F8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x18F8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293A2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x18F8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0293A5;
L_0293A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293A5 CMP
    cpu.compareA(0x3u);
    goto L_0293A7;
L_0293A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A7u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293A7 BCS -> $029391
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_029391; }
    goto L_0293A9;
L_0293A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93A9u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93A9u, 4u, 3u, cpu.address("abs", 0x1698u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293A9 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1698u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0293AC;
L_0293AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93ACu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293AC STZ
    hw.write(cpu.address("dp", 0xEu), 0, cpu.m8?8:16);
    goto L_0293AE;
L_0293AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93AEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293AE LDX
    cpu.setX(0xBu, 8);
    goto L_0293B0;
L_0293B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B0u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B0u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293B0 STX
    hw.write(cpu.address("abs", 0x15E9u), cpu.x, cpu.x8?8:16);
    goto L_0293B3;
L_0293B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B3u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293B3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0293B6;
L_0293B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293B6 CMP
    cpu.compareA(0xBu);
    goto L_0293B8;
L_0293B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93B8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293B8 BEQ -> $0293F7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0293F7; }
    goto L_0293BA;
L_0293BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93BAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293BA CMP
    cpu.compareA(0x8u);
    goto L_0293BC;
L_0293BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93BCu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293BC BCC -> $0293F7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0293F7; }
    goto L_0293BE;
L_0293BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93BEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93BEu, 4u + ((((0x166Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x166Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293BE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x166Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0293C1;
L_0293C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293C1 AND
    cpu.logicAnd(0x20u);
    goto L_0293C3;
L_0293C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C3u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C3u, 4u + ((((0x15D0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293C3 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15D0u), cpu.m8?8:16));
    goto L_0293C6;
L_0293C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C6u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C6u, 4u + ((((0x154Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293C6 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x154Cu), cpu.m8?8:16));
    goto L_0293C9;
L_0293C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93C9u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93C9u, 4u + ((((0x1FE2u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1FE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293C9 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1FE2u), cpu.m8?8:16));
    goto L_0293CC;
L_0293CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293CC BNE -> $0293F7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0293F7; }
    goto L_0293CE;
L_0293CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CEu, 4u + ((((0x1632u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1632u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293CE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1632u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0293D1;
L_0293D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D1u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0293D1 PHY
    cpu.push("PHY", hw);
    goto L_0293D2;
L_0293D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D2u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293D2 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x74u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0293D4;
L_0293D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293D4 BEQ -> $0293D8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0293D8; }
    goto L_0293D6;
L_0293D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D6u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293D6 EOR
    cpu.logicXor(0x1u);
    goto L_0293D8;
L_0293D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D8u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0293D8 PLY
    cpu.pop("PLY", hw);
    goto L_0293D9;
L_0293D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D9u,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D9u, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293D9 EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0x13F9u), cpu.m8?8:16));
    goto L_0293DC;
L_0293DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293DC BNE -> $0293F7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0293F7; }
    goto L_0293DE;
L_0293DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93DEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93DEu, 8u, 4u, 0x03B69Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0293DE JSL -> $03B69F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x93E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93E2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x03B69Fu, 0x0293DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0293E2;
L_0293E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93E2u,0x0293E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293E2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0293E4;
L_0293E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293E4 BEQ -> $0293EB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0293EB; }
    goto L_0293E6;
L_0293E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E6u, 6u, 3u, cpu.address("abs", 0x9696u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0293E6 JSR -> $029696 stack real
    { cpu.push16Value(hw,0x93E8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93E9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9696u), 0x0293E6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0293E9;
L_0293E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93E9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93E9u,0x0293E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93E9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293E9 BRA -> $0293EE
    goto L_0293EE;
L_0293EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EBu, 6u, 3u, cpu.address("abs", 0x9663u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0293EB JSR -> $029663 stack real
    { cpu.push16Value(hw,0x93EDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93EEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9663u), 0x0293EBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0293EE;
L_0293EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93EEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93EEu,0x0293EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93EEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93EEu, 8u, 4u, 0x03B72Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0293EE JSL -> $03B72B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x93F1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93F2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x03B72Bu, 0x0293EEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0293F2;
L_0293F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93F2u,0x0293F2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F2u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293F2 BCC -> $0293F7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0293F7; }
    goto L_0293F4;
L_0293F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F4u, 6u, 3u, cpu.address("abs", 0x9404u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0293F4 JSR -> $029404 stack real
    { cpu.push16Value(hw,0x93F6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x93F7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9404u), 0x0293F4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0293F7;
L_0293F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93F7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x93F7u,0x0293F7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93F7u, 4u, 3u, cpu.address("abs", 0x1698u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293F7 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1698u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0293FA;
L_0293FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FAu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293FA DEX
    cpu.decReg('X');
    goto L_0293FB;
L_0293FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FBu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293FB BMI -> $029400
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_029400; }
    goto L_0293FD;
L_0293FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93FDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93FDu, 3u, 3u, cpu.address("abs", 0x93B0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0293FD JMP -> $0293B0
    goto L_0293B0;
L_029400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9400u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9400u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9400u, 4u, 3u, cpu.address("abs", 0x1698u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $029400 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1698u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_029403;
L_029403:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9403u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9403u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9403u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $029403 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x029403u);return;} hw.unresolvedReturn(0x029403u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_02C22C_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02C22Cu: goto L_02C22C;
    case 0x02C22Fu: goto L_02C22F;
    case 0x02C231u: goto L_02C231;
    case 0x02C233u: goto L_02C233;
    case 0x02C236u: goto L_02C236;
    case 0x02C238u: goto L_02C238;
    case 0x02C23Au: goto L_02C23A;
    case 0x02C23Du: goto L_02C23D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02C22C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Cu, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C22C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C22F;
L_02C22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C22F CMP
    cpu.compareA(0x8u);
    goto L_02C231;
L_02C231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC231u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC231u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C231 BNE -> $02C217
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.unresolvedFlow(0x02C231u,0x02C217u,cpu); return; }
    goto L_02C233;
L_02C233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC233u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC233u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC233u, 4u + ((((0x15ACu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15ACu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C233 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15ACu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02C236;
L_02C236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC236u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC236u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C236 BEQ -> $02C23D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_02C23D; }
    goto L_02C238;
L_02C238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC238u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC238u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C238 LDA
    cpu.setA(0x5u, 8);
    goto L_02C23A;
L_02C23A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Au, 5u, 3u, cpu.address("absx", 0x1602u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C23A STA
    hw.write(cpu.address("absx", 0x1602u), cpu.a, cpu.m8?8:16);
    goto L_02C23D;
L_02C23D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Du, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C23D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC240u,0x02C23Du); return;
}

void sub_02D0D4_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02D0D4u: goto L_02D0D4;
    case 0x02D0D7u: goto L_02D0D7;
    case 0x02D0D9u: goto L_02D0D9;
    case 0x02D0DCu: goto L_02D0DC;
    case 0x02D0DEu: goto L_02D0DE;
    case 0x02D0DFu: goto L_02D0DF;
    case 0x02D0E0u: goto L_02D0E0;
    case 0x02D0E1u: goto L_02D0E1;
    case 0x02D0E4u: goto L_02D0E4;
    case 0x02D0E5u: goto L_02D0E5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02D0D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D4u, 4u + ((((0x1564u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1564u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0D4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1564u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D0D7;
L_02D0D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0D7 BNE -> $02D0E5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_02D0E5; }
    goto L_02D0D9;
L_02D0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0D9u, 4u + ((((0x160Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x160Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0D9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x160Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_02D0DC;
L_02D0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02D0DC BPL -> $02D0E5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_02D0E5; }
    goto L_02D0DE;
L_02D0DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DEu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D0DE PHB
    cpu.push("PHB", hw);
    goto L_02D0DF;
L_02D0DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DFu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0DFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D0DF PHK
    cpu.push("PHK", hw);
    goto L_02D0E0;
L_02D0E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E0u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D0E0 PLB
    cpu.pop("PLB", hw);
    goto L_02D0E1;
L_02D0E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E1u, 6u, 3u, cpu.address("abs", 0xD0E6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02D0E1 JSR -> $02D0E6 stack real
    { cpu.push16Value(hw,0xD0E3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD0E4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD0E6u), 0x02D0E1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02D0E4;
L_02D0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0E4u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD0E4u,0x02D0E4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E4u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $02D0E4 PLB
    cpu.pop("PLB", hw);
    goto L_02D0E5;
L_02D0E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD0E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E5u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD0E5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $02D0E5 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x02D0E5u);return;} hw.unresolvedReturn(0x02D0E5u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_04E453_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04E453u: goto L_04E453;
    case 0x04E455u: goto L_04E455;
    case 0x04E457u: goto L_04E457;
    case 0x04E459u: goto L_04E459;
    case 0x04E45Au: goto L_04E45A;
    case 0x04E45Cu: goto L_04E45C;
    case 0x04E45Du: goto L_04E45D;
    case 0x04E45Eu: goto L_04E45E;
    case 0x04E45Fu: goto L_04E45F;
    case 0x04E460u: goto L_04E460;
    case 0x04E463u: goto L_04E463;
    case 0x04E467u: goto L_04E467;
    case 0x04E469u: goto L_04E469;
    case 0x04E46Au: goto L_04E46A;
    case 0x04E46Cu: goto L_04E46C;
    case 0x04E46Du: goto L_04E46D;
    case 0x04E46Eu: goto L_04E46E;
    case 0x04E470u: goto L_04E470;
    case 0x04E474u: goto L_04E474;
    case 0x04E477u: goto L_04E477;
    case 0x04E47Bu: goto L_04E47B;
    case 0x04E47Eu: goto L_04E47E;
    case 0x04E481u: goto L_04E481;
    case 0x04E483u: goto L_04E483;
    case 0x04E486u: goto L_04E486;
    case 0x04E488u: goto L_04E488;
    case 0x04E48Bu: goto L_04E48B;
    case 0x04E48Eu: goto L_04E48E;
    case 0x04E491u: goto L_04E491;
    case 0x04E493u: goto L_04E493;
    case 0x04E495u: goto L_04E495;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04E453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE453u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE453u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E453 SEP
    cpu.sep(0x30u);
    goto L_04E455;
L_04E455:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE455u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE455u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE455u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E455 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E457;
L_04E457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE457u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE457u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE457u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E457 AND
    cpu.logicAnd(0x7u);
    goto L_04E459;
L_04E459:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE459u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE459u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE459u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E459 TAX
    cpu.transfer("TAX");
    goto L_04E45A;
L_04E45A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E45A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E45C;
L_04E45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E45C LSR
    cpu.lsrA();
    goto L_04E45D;
L_04E45D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E45D LSR
    cpu.lsrA();
    goto L_04E45E;
L_04E45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E45E LSR
    cpu.lsrA();
    goto L_04E45F;
L_04E45F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E45F TAY
    cpu.transfer("TAY");
    goto L_04E460;
L_04E460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE460u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE460u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE460u, 4u + ((((0x1F02u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1F02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E460 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1F02u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E463;
L_04E463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE463u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE463u,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE463u, 5u, 4u, ((0x04E44Bu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E463 AND
    cpu.logicAnd(hw.readW(((0x4E44Bu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_04E467;
L_04E467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE467u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE467u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE467u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E467 BNE -> $04E46A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04E46A; }
    goto L_04E469;
L_04E469:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE469u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE469u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE469u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04E469 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04E469u);return;} hw.unresolvedReturn(0x04E469u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_04E46A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E46A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E46C;
L_04E46C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E46C ASL
    cpu.aslA();
    goto L_04E46D;
L_04E46D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E46D TAX
    cpu.transfer("TAX");
    goto L_04E46E;
L_04E46E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E46E REP
    cpu.rep(0x20u);
    goto L_04E470;
L_04E470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE470u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE470u, 6u, 4u, ((0x04E359u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E470 LDA
    cpu.loadA(hw.readW(((0x4E359u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E474;
L_04E474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE474u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE474u, 5u, 3u, cpu.address("abs", 0x1DEBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E474 STA
    hw.write(cpu.address("abs", 0x1DEBu), cpu.a, cpu.m8?8:16);
    goto L_04E477;
L_04E477:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE477u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE477u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE477u, 6u, 4u, ((0x04E35Bu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E477 LDA
    cpu.loadA(hw.readW(((0x4E35Bu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E47B;
L_04E47B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE47Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Bu, 5u, 3u, cpu.address("abs", 0x1DEDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E47B STA
    hw.write(cpu.address("abs", 0x1DEDu), cpu.a, cpu.m8?8:16);
    goto L_04E47E;
L_04E47E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE47Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Eu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Eu, 5u, 3u, cpu.address("abs", 0x1DEBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E47E CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1DEBu), cpu.m8?8:16));
    goto L_04E481;
L_04E481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE481u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE481u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E481 BEQ -> $04E493
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04E493; }
    goto L_04E483;
L_04E483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE483u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE483u, 6u, 3u, cpu.address("abs", 0xE496u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04E483 JSR -> $04E496 stack real
    { cpu.push16Value(hw,0xE485u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE486u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE496u), 0x04E483u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04E486;
L_04E486:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE486u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE486u,0x04E486u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE486u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE486u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E486 REP
    cpu.rep(0x20u);
    goto L_04E488;
L_04E488:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE488u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE488u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE488u, 8u, 3u, cpu.address("abs", 0x1DEBu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E488 INC
    cpu.incMem(hw, cpu.address("abs", 0x1DEBu), cpu.m8?8:16);
    goto L_04E48B;
L_04E48B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Bu, 5u, 3u, cpu.address("abs", 0x1DEBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E48B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DEBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04E48E;
L_04E48E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Eu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Eu, 5u, 3u, cpu.address("abs", 0x1DEDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E48E CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1DEDu), cpu.m8?8:16));
    goto L_04E491;
L_04E491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE491u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE491u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E491 BNE -> $04E483
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04E483; }
    goto L_04E493;
L_04E493:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE493u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE493u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE493u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E493 SEP
    cpu.sep(0x30u);
    goto L_04E495;
L_04E495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE495u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE495u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04E495 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04E495u);return;} hw.unresolvedReturn(0x04E495u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04E677_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04E677u: goto L_04E677;
    case 0x04E679u: goto L_04E679;
    case 0x04E67Bu: goto L_04E67B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04E677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE677u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE677u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE677u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E677 SEP
    cpu.sep(0x30u);
    goto L_04E679;
L_04E679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE679u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE679u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E679 LDX
    cpu.setX(0x17u, 8);
    goto L_04E67B;
L_04E67B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE67Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Bu,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Bu, 5u, 4u, ((0x04E5D6u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E67B CMP
    cpu.compareA(hw.readW(((0x4E5D6u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE67Fu,0x04E67Bu); return;
}

void sub_04E677_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04E677u: goto L_04E677;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04E677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE677u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE677u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE677u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04E677 SEP
    cpu.sep(0x30u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE679u,0x04E677u); return;
}

void sub_0580BF_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0580BDu: goto L_0580BD;
    case 0x0580BFu: goto L_0580BF;
    case 0x0580C3u: goto L_0580C3;
    case 0x0580C7u: goto L_0580C7;
    case 0x0580CBu: goto L_0580CB;
    case 0x0580CDu: goto L_0580CD;
    case 0x0580CFu: goto L_0580CF;
    case 0x0580D1u: goto L_0580D1;
    case 0x0580D3u: goto L_0580D3;
    case 0x0580D5u: goto L_0580D5;
    case 0x0580D6u: goto L_0580D6;
    case 0x0580D7u: goto L_0580D7;
    case 0x0580D8u: goto L_0580D8;
    case 0x0580DAu: goto L_0580DA;
    case 0x0580DDu: goto L_0580DD;
    case 0x0580DEu: goto L_0580DE;
    case 0x0580E1u: goto L_0580E1;
    case 0x0580E2u: goto L_0580E2;
    case 0x0580E3u: goto L_0580E3;
    case 0x0580E6u: goto L_0580E6;
    case 0x0580E8u: goto L_0580E8;
    case 0x0580ECu: goto L_0580EC;
    case 0x0580EFu: goto L_0580EF;
    case 0x0580F0u: goto L_0580F0;
    case 0x0580F1u: goto L_0580F1;
    case 0x0580F2u: goto L_0580F2;
    case 0x0580F5u: goto L_0580F5;
    case 0x0580F7u: goto L_0580F7;
    case 0x0580F9u: goto L_0580F9;
    case 0x0580FBu: goto L_0580FB;
    case 0x0580FEu: goto L_0580FE;
    case 0x058101u: goto L_058101;
    case 0x058103u: goto L_058103;
    case 0x058105u: goto L_058105;
    case 0x058108u: goto L_058108;
    case 0x05810Bu: goto L_05810B;
    case 0x05810Eu: goto L_05810E;
    case 0x058111u: goto L_058111;
    case 0x058114u: goto L_058114;
    case 0x058117u: goto L_058117;
    case 0x058119u: goto L_058119;
    case 0x05811Cu: goto L_05811C;
    case 0x05811Eu: goto L_05811E;
    case 0x058120u: goto L_058120;
    case 0x058122u: goto L_058122;
    case 0x058124u: goto L_058124;
    case 0x058125u: goto L_058125;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0580BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580BD REP
    cpu.rep(0x30u);
    goto L_0580BF;
L_0580BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu, 8u, 4u, 0x0588ECu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580BF JSL -> $0588EC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0588ECu, 0x0580BFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580C3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu, 8u, 4u, 0x0588ECu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580BF JSL -> $0588EC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0588ECu, 0x0580BFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580C3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80BFu,0x0580BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u, 8u, 4u, 0x058955u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580C3 JSL -> $058955 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x058955u, 0x0580C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580C7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u, 8u, 4u, 0x058955u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580C3 JSL -> $058955 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x058955u, 0x0580C3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580C7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80C3u,0x0580C3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u, 8u, 4u, 0x0087ADu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580C7 JSL -> $0087AD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80CAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80CBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0087ADu, 0x0580C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580CB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u, 8u, 4u, 0x0087ADu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0580C7 JSL -> $0087AD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80CAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80CBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0087ADu, 0x0580C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0580CB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80C7u,0x0580C7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CB REP
    cpu.rep(0x30u);
    goto L_0580CD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CB REP
    cpu.rep(0x30u);
    goto L_0580CD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80CBu,0x0580CBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CD INC
    cpu.incMem(hw, cpu.address("dp", 0x47u), cpu.m8?8:16);
    goto L_0580CF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CD INC
    cpu.incMem(hw, cpu.address("dp", 0x47u), cpu.m8?8:16);
    goto L_0580CF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80CDu,0x0580CDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CF INC
    cpu.incMem(hw, cpu.address("dp", 0x4Bu), cpu.m8?8:16);
    goto L_0580D1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580CF INC
    cpu.incMem(hw, cpu.address("dp", 0x4Bu), cpu.m8?8:16);
    goto L_0580D1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80CFu,0x0580CFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D1 SEP
    cpu.sep(0x30u);
    goto L_0580D3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D1 SEP
    cpu.sep(0x30u);
    goto L_0580D3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80D1u,0x0580D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x47u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580D5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x47u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580D5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80D3u,0x0580D3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D5 LSR
    cpu.lsrA();
    goto L_0580D6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D5 LSR
    cpu.lsrA();
    goto L_0580D6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80D5u,0x0580D5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0580D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D6 LSR
    cpu.lsrA();
    goto L_0580D7;
L_0580D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D7 LSR
    cpu.lsrA();
    goto L_0580D8;
L_0580D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580D8 REP
    cpu.rep(0x30u);
    goto L_0580DA;
L_0580DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580DA AND
    cpu.logicAnd(0x6u);
    goto L_0580DD;
L_0580DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580DD TAX
    cpu.transfer("TAX");
    goto L_0580DE;
L_0580DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580DE LDA
    cpu.setA(0x133u, 16);
    goto L_0580E1;
L_0580E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E1 ASL
    cpu.aslA();
    goto L_0580E2;
L_0580E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E2 TAY
    cpu.transfer("TAY");
    goto L_0580E3;
L_0580E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E3 LDA
    cpu.setA(0x7u, 16);
    goto L_0580E6;
L_0580E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E6 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0580E8;
L_0580E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u, 6u, 4u, ((0x058776u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580E8 LDA
    cpu.loadA(hw.readW(((0x58776u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0580EC;
L_0580EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu, 6u, 3u, cpu.address("absy", 0x0FBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580EC STA
    hw.write(cpu.address("absy", 0xFBEu), cpu.a, cpu.m8?8:16);
    goto L_0580EF;
L_0580EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580EF INY
    cpu.inc('Y');
    goto L_0580F0;
L_0580F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F0u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F0 INY
    cpu.inc('Y');
    goto L_0580F1;
L_0580F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F1 CLC
    cpu.setFlag('C', false);
    goto L_0580F2;
L_0580F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F2 ADC
    cpu.adc(0x8u);
    goto L_0580F5;
L_0580F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F5 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0580F7;
L_0580F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F7 BPL -> $0580EC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0580EC; }
    goto L_0580F9;
L_0580F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580F9 SEP
    cpu.sep(0x20u);
    goto L_0580FB;
L_0580FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu, 6u, 3u, cpu.address("abs", 0x1928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580FB INC
    cpu.incMem(hw, cpu.address("abs", 0x1928u), cpu.m8?8:16);
    goto L_0580FE;
L_0580FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu, 4u, 3u, cpu.address("abs", 0x1928u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0580FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1928u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058101;
L_058101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058101 CMP
    cpu.compareA(0x20u);
    goto L_058103;
L_058103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058103 BNE -> $0580BD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0580BD; }
    goto L_058105;
L_058105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u, 4u, 3u, cpu.address("abs", 0x0D9Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058105 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058108;
L_058108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8108u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8108u, 4u, 3u, cpu.address("abs", 0x212Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058108 STA
    hw.write(cpu.address("abs", 0x212Cu), cpu.a, cpu.m8?8:16);
    goto L_05810B;
L_05810B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Bu, 4u, 3u, cpu.address("abs", 0x212Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05810B STA
    hw.write(cpu.address("abs", 0x212Eu), cpu.a, cpu.m8?8:16);
    goto L_05810E;
L_05810E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu, 4u, 3u, cpu.address("abs", 0x0D9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05810E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xD9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_058111;
L_058111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u, 4u, 3u, cpu.address("abs", 0x212Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058111 STA
    hw.write(cpu.address("abs", 0x212Du), cpu.a, cpu.m8?8:16);
    goto L_058114;
L_058114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u, 4u, 3u, cpu.address("abs", 0x212Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058114 STA
    hw.write(cpu.address("abs", 0x212Fu), cpu.a, cpu.m8?8:16);
    goto L_058117;
L_058117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8117u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8117u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058117 REP
    cpu.rep(0x20u);
    goto L_058119;
L_058119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058119 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_05811C;
L_05811C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05811C STA
    hw.write(cpu.address("dp", 0x4Du), cpu.a, cpu.m8?8:16);
    goto L_05811E;
L_05811E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05811E STA
    hw.write(cpu.address("dp", 0x4Fu), cpu.a, cpu.m8?8:16);
    goto L_058120;
L_058120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058120 STA
    hw.write(cpu.address("dp", 0x51u), cpu.a, cpu.m8?8:16);
    goto L_058122;
L_058122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x53u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $058122 STA
    hw.write(cpu.address("dp", 0x53u), cpu.a, cpu.m8?8:16);
    goto L_058124;
L_058124:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8124u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8124u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8124u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $058124 PLP
    cpu.pop("PLP", hw);
    goto L_058125;
L_058125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058125 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x058125u);return;} hw.unresolvedReturn(0x058125u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058125 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x058125u);return;} hw.unresolvedReturn(0x058125u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058125 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x058125u);return;} hw.unresolvedReturn(0x058125u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $058125 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x058125u);return;} hw.unresolvedReturn(0x058125u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8125u,0x058125u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_05B160_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05B160u: goto L_05B160;
    case 0x05B163u: goto L_05B163;
    case 0x05B165u: goto L_05B165;
    case 0x05B168u: goto L_05B168;
    case 0x05B16Au: goto L_05B16A;
    case 0x05B16Du: goto L_05B16D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05B160:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB160u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB160u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB160u, 4u, 3u, cpu.address("abs", 0x0109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B160 STZ
    hw.write(cpu.address("abs", 0x109u), 0, cpu.m8?8:16);
    goto L_05B163;
L_05B163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB163u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB163u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB163u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B163 LDA
    cpu.setA(0x0u, 8);
    goto L_05B165;
L_05B165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB165u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB165u, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B165 STA
    hw.write(cpu.address("abs", 0xDD5u), cpu.a, cpu.m8?8:16);
    goto L_05B168;
L_05B168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB168u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB168u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B168 LDA
    cpu.setA(0xBu, 8);
    goto L_05B16A;
L_05B16A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB16Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Au, 4u, 3u, cpu.address("abs", 0x0100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B16A STA
    hw.write(cpu.address("abs", 0x100u), cpu.a, cpu.m8?8:16);
    goto L_05B16D;
L_05B16D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB16Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05B16D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x05B16Du);return;} hw.unresolvedReturn(0x05B16Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_07F78B_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x07F78Bu: goto L_07F78B;
    case 0x07F78Cu: goto L_07F78C;
    case 0x07F78Du: goto L_07F78D;
    case 0x07F78Fu: goto L_07F78F;
    case 0x07F790u: goto L_07F790;
    case 0x07F794u: goto L_07F794;
    case 0x07F796u: goto L_07F796;
    case 0x07F797u: goto L_07F797;
    case 0x07F79Au: goto L_07F79A;
    case 0x07F79Eu: goto L_07F79E;
    case 0x07F79Fu: goto L_07F79F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_07F78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Bu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F78B PHY
    cpu.push("PHY", hw);
    goto L_07F78C;
L_07F78C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Cu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F78C PHX
    cpu.push("PHX", hw);
    goto L_07F78D;
L_07F78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F78D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F78F;
L_07F78F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F78F TAX
    cpu.transfer("TAX");
    goto L_07F790;
L_07F790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF790u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF790u, 5u, 4u, ((0x07F3FEu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F790 LDA
    cpu.loadA(hw.readW(((0x7F3FEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_07F794;
L_07F794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF794u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF794u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F794 AND
    cpu.logicAnd(0xFu);
    goto L_07F796;
L_07F796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF796u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF796u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F796 PLX
    cpu.pop("PLX", hw);
    goto L_07F797;
L_07F797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF797u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF797u, 5u, 3u, cpu.address("absx", 0x15F6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $07F797 STA
    hw.write(cpu.address("absx", 0x15F6u), cpu.a, cpu.m8?8:16);
    goto L_07F79A;
L_07F79A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Au, 8u, 4u, 0x07F7A0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F79A JSL -> $07F7A0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF79Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF79Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F7A0u, 0x07F79Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_07F79E;
L_07F79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Eu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF79Eu,0x07F79Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Eu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $07F79E PLY
    cpu.pop("PLY", hw);
    goto L_07F79F;
L_07F79F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F79F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x07F79Fu);return;} hw.unresolvedReturn(0x07F79Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_07F7D2_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x07F7D2u: goto L_07F7D2;
    case 0x07F7D6u: goto L_07F7D6;
    case 0x07F7DAu: goto L_07F7DA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_07F7D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D2u, 8u, 4u, 0x07F722u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F7D2 JSL -> $07F722 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF7D5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF7D6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F722u, 0x07F7D2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_07F7D6;
L_07F7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D6u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF7D6u,0x07F7D6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D6u, 8u, 4u, 0x07F78Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F7D6 JSL -> $07F78B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF7D9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF7DAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F78Bu, 0x07F7D6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_07F7DA;
L_07F7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DAu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF7DAu,0x07F7DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $07F7DA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x07F7DAu);return;} hw.unresolvedReturn(0x07F7DAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0DB1D4_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB1D4u: goto L_0DB1D4;
    case 0x0DB1D6u: goto L_0DB1D6;
    case 0x0DB1D8u: goto L_0DB1D8;
    case 0x0DB1DAu: goto L_0DB1DA;
    case 0x0DB1DBu: goto L_0DB1DB;
    case 0x0DB1DDu: goto L_0DB1DD;
    case 0x0DB1DEu: goto L_0DB1DE;
    case 0x0DB1DFu: goto L_0DB1DF;
    case 0x0DB1E0u: goto L_0DB1E0;
    case 0x0DB1E1u: goto L_0DB1E1;
    case 0x0DB1E3u: goto L_0DB1E3;
    case 0x0DB1E6u: goto L_0DB1E6;
    case 0x0DB1E8u: goto L_0DB1E8;
    case 0x0DB1EBu: goto L_0DB1EB;
    case 0x0DB1EDu: goto L_0DB1ED;
    case 0x0DB1F0u: goto L_0DB1F0;
    case 0x0DB1F1u: goto L_0DB1F1;
    case 0x0DB1F3u: goto L_0DB1F3;
    case 0x0DB1F5u: goto L_0DB1F5;
    case 0x0DB1F8u: goto L_0DB1F8;
    case 0x0DB1FBu: goto L_0DB1FB;
    case 0x0DB1FDu: goto L_0DB1FD;
    case 0x0DB200u: goto L_0DB200;
    case 0x0DB201u: goto L_0DB201;
    case 0x0DB203u: goto L_0DB203;
    case 0x0DB205u: goto L_0DB205;
    case 0x0DB208u: goto L_0DB208;
    case 0x0DB20Bu: goto L_0DB20B;
    case 0x0DB20Du: goto L_0DB20D;
    case 0x0DB20Fu: goto L_0DB20F;
    case 0x0DB211u: goto L_0DB211;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB1D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1D4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB1D6;
L_0DB1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1D6 AND
    cpu.logicAnd(0xFu);
    goto L_0DB1D8;
L_0DB1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1D8 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DB1DA;
L_0DB1DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1DA TAX
    cpu.transfer("TAX");
    goto L_0DB1DB;
L_0DB1DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1DB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB1DD;
L_0DB1DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1DD LSR
    cpu.lsrA();
    goto L_0DB1DE;
L_0DB1DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1DE LSR
    cpu.lsrA();
    goto L_0DB1DF;
L_0DB1DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1DF LSR
    cpu.lsrA();
    goto L_0DB1E0;
L_0DB1E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1E0 LSR
    cpu.lsrA();
    goto L_0DB1E1;
L_0DB1E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1E1 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DB1E3;
L_0DB1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E3u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1E3 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xB1E5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1E6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DB1E3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1E6;
L_0DB1E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1E6u,0x0DB1E6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E6u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1E6 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB1E8;
L_0DB1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E8u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1E8 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xB1EAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1EBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DB1E8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1EB;
L_0DB1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1EBu,0x0DB1EBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1EB LDA
    cpu.setA(0x0u, 8);
    goto L_0DB1ED;
L_0DB1ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1ED JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB1EFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1F0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB1EDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1F0;
L_0DB1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1F0u,0x0DB1F0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F0 DEX
    cpu.decReg('X');
    goto L_0DB1F1;
L_0DB1F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F1u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F1 CPX
    cpu.compareX(0xFFu);
    goto L_0DB1F3;
L_0DB1F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F3 BNE -> $0DB1E8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB1E8; }
    goto L_0DB1F5;
L_0DB1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F5u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F5u, 3u, 3u, cpu.address("abs", 0xB205u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F5 JMP -> $0DB205
    goto L_0DB205;
L_0DB1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F8u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1F8 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB1FAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1FBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB1F8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1FB;
L_0DB1FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1FBu,0x0DB1FBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1FB LDA
    cpu.setA(0x3Fu, 8);
    goto L_0DB1FD;
L_0DB1FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FDu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1FD JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB1FFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB200u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB1FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB200;
L_0DB200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB200u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB200u,0x0DB200u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB200u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB200u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB200 DEX
    cpu.decReg('X');
    goto L_0DB201;
L_0DB201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB201u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB201u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB201 CPX
    cpu.compareX(0xFFu);
    goto L_0DB203;
L_0DB203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB203u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB203u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB203 BNE -> $0DB1F8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB1F8; }
    goto L_0DB205;
L_0DB205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB205u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB205u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB205 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xB207u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB208u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DB205u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB208;
L_0DB208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB208u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB208u,0x0DB208u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB208u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB208u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB208 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xB20Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB20Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DB208u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB20B;
L_0DB20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB20Bu,0x0DB20Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB20B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB20D;
L_0DB20D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Du,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB20D DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DB20F;
L_0DB20F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB20F BPL -> $0DB1F8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB1F8; }
    goto L_0DB211;
L_0DB211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB211 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB211u);return;} hw.unresolvedReturn(0x0DB211u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DB1D4_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB1D4u: goto L_0DB1D4;
    case 0x0DB1D6u: goto L_0DB1D6;
    case 0x0DB1D8u: goto L_0DB1D8;
    case 0x0DB1DAu: goto L_0DB1DA;
    case 0x0DB1DBu: goto L_0DB1DB;
    case 0x0DB1DDu: goto L_0DB1DD;
    case 0x0DB1DEu: goto L_0DB1DE;
    case 0x0DB1DFu: goto L_0DB1DF;
    case 0x0DB1E0u: goto L_0DB1E0;
    case 0x0DB1E1u: goto L_0DB1E1;
    case 0x0DB1E3u: goto L_0DB1E3;
    case 0x0DB1E6u: goto L_0DB1E6;
    case 0x0DB1E8u: goto L_0DB1E8;
    case 0x0DB1EBu: goto L_0DB1EB;
    case 0x0DB1EDu: goto L_0DB1ED;
    case 0x0DB1F0u: goto L_0DB1F0;
    case 0x0DB1F1u: goto L_0DB1F1;
    case 0x0DB1F3u: goto L_0DB1F3;
    case 0x0DB1F5u: goto L_0DB1F5;
    case 0x0DB1F8u: goto L_0DB1F8;
    case 0x0DB1FBu: goto L_0DB1FB;
    case 0x0DB1FDu: goto L_0DB1FD;
    case 0x0DB200u: goto L_0DB200;
    case 0x0DB201u: goto L_0DB201;
    case 0x0DB203u: goto L_0DB203;
    case 0x0DB205u: goto L_0DB205;
    case 0x0DB208u: goto L_0DB208;
    case 0x0DB20Bu: goto L_0DB20B;
    case 0x0DB20Du: goto L_0DB20D;
    case 0x0DB20Fu: goto L_0DB20F;
    case 0x0DB211u: goto L_0DB211;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB1D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1D4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB1D6;
L_0DB1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1D6 AND
    cpu.logicAnd(0xFu);
    goto L_0DB1D8;
L_0DB1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1D8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1D8 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DB1DA;
L_0DB1DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1DA TAX
    cpu.transfer("TAX");
    goto L_0DB1DB;
L_0DB1DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1DB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB1DD;
L_0DB1DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1DD LSR
    cpu.lsrA();
    goto L_0DB1DE;
L_0DB1DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1DE LSR
    cpu.lsrA();
    goto L_0DB1DF;
L_0DB1DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1DF LSR
    cpu.lsrA();
    goto L_0DB1E0;
L_0DB1E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1E0 LSR
    cpu.lsrA();
    goto L_0DB1E1;
L_0DB1E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1E1 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DB1E3;
L_0DB1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E3u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1E3 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xB1E5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1E6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DB1E3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1E6;
L_0DB1E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1E6u,0x0DB1E6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E6u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1E6 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB1E8;
L_0DB1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1E8u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1E8 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xB1EAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1EBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DB1E8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1EB;
L_0DB1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1EBu,0x0DB1EBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1EB LDA
    cpu.setA(0x0u, 8);
    goto L_0DB1ED;
L_0DB1ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1EDu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1ED JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB1EFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1F0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB1EDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1F0;
L_0DB1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1F0u,0x0DB1F0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F0 DEX
    cpu.decReg('X');
    goto L_0DB1F1;
L_0DB1F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F1u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F1 CPX
    cpu.compareX(0xFFu);
    goto L_0DB1F3;
L_0DB1F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F3 BNE -> $0DB1E8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB1E8; }
    goto L_0DB1F5;
L_0DB1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F5u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F5u, 3u, 3u, cpu.address("abs", 0xB205u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1F5 JMP -> $0DB205
    goto L_0DB205;
L_0DB1F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1F8u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1F8 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB1FAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1FBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB1F8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB1FB;
L_0DB1FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1FBu,0x0DB1FBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB1FB LDA
    cpu.setA(0x3Fu, 8);
    goto L_0DB1FD;
L_0DB1FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1FDu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB1FD JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB1FFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB200u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB1FDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB200;
L_0DB200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB200u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB200u,0x0DB200u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB200u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB200u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB200 DEX
    cpu.decReg('X');
    goto L_0DB201;
L_0DB201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB201u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB201u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB201 CPX
    cpu.compareX(0xFFu);
    goto L_0DB203;
L_0DB203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB203u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB203u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB203 BNE -> $0DB1F8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB1F8; }
    goto L_0DB205;
L_0DB205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB205u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB205u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB205 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xB207u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB208u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DB205u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB208;
L_0DB208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB208u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB208u,0x0DB208u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB208u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB208u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB208 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xB20Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB20Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DB208u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB20B;
L_0DB20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB20Bu,0x0DB20Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB20B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB20D;
L_0DB20D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Du,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB20D DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DB20F;
L_0DB20F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB20F BPL -> $0DB1F8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB1F8; }
    goto L_0DB211;
L_0DB211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB211 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB211u);return;} hw.unresolvedReturn(0x0DB211u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DB212_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB212u: goto L_0DB212;
    case 0x0DB216u: goto L_0DB216;
    case 0x0DB218u: goto L_0DB218;
    case 0x0DB21Au: goto L_0DB21A;
    case 0x0DB21Cu: goto L_0DB21C;
    case 0x0DB21Eu: goto L_0DB21E;
    case 0x0DB21Fu: goto L_0DB21F;
    case 0x0DB221u: goto L_0DB221;
    case 0x0DB222u: goto L_0DB222;
    case 0x0DB224u: goto L_0DB224;
    case 0x0DB226u: goto L_0DB226;
    case 0x0DB228u: goto L_0DB228;
    case 0x0DB22Au: goto L_0DB22A;
    case 0x0DB22Cu: goto L_0DB22C;
    case 0x0DB22Eu: goto L_0DB22E;
    case 0x0DB22Fu: goto L_0DB22F;
    case 0x0DB230u: goto L_0DB230;
    case 0x0DB231u: goto L_0DB231;
    case 0x0DB232u: goto L_0DB232;
    case 0x0DB234u: goto L_0DB234;
    case 0x0DB236u: goto L_0DB236;
    case 0x0DB239u: goto L_0DB239;
    case 0x0DB23Bu: goto L_0DB23B;
    case 0x0DB23Fu: goto L_0DB23F;
    case 0x0DB241u: goto L_0DB241;
    case 0x0DB243u: goto L_0DB243;
    case 0x0DB245u: goto L_0DB245;
    case 0x0DB249u: goto L_0DB249;
    case 0x0DB24Bu: goto L_0DB24B;
    case 0x0DB24Eu: goto L_0DB24E;
    case 0x0DB250u: goto L_0DB250;
    case 0x0DB252u: goto L_0DB252;
    case 0x0DB253u: goto L_0DB253;
    case 0x0DB254u: goto L_0DB254;
    case 0x0DB256u: goto L_0DB256;
    case 0x0DB257u: goto L_0DB257;
    case 0x0DB259u: goto L_0DB259;
    case 0x0DB25Bu: goto L_0DB25B;
    case 0x0DB25Du: goto L_0DB25D;
    case 0x0DB25Fu: goto L_0DB25F;
    case 0x0DB261u: goto L_0DB261;
    case 0x0DB263u: goto L_0DB263;
    case 0x0DB265u: goto L_0DB265;
    case 0x0DB269u: goto L_0DB269;
    case 0x0DB26Bu: goto L_0DB26B;
    case 0x0DB26Du: goto L_0DB26D;
    case 0x0DB26Fu: goto L_0DB26F;
    case 0x0DB273u: goto L_0DB273;
    case 0x0DB275u: goto L_0DB275;
    case 0x0DB278u: goto L_0DB278;
    case 0x0DB27Au: goto L_0DB27A;
    case 0x0DB27Cu: goto L_0DB27C;
    case 0x0DB27Du: goto L_0DB27D;
    case 0x0DB27Eu: goto L_0DB27E;
    case 0x0DB280u: goto L_0DB280;
    case 0x0DB281u: goto L_0DB281;
    case 0x0DB283u: goto L_0DB283;
    case 0x0DB285u: goto L_0DB285;
    case 0x0DB287u: goto L_0DB287;
    case 0x0DB289u: goto L_0DB289;
    case 0x0DB28Bu: goto L_0DB28B;
    case 0x0DB28Du: goto L_0DB28D;
    case 0x0DB28Fu: goto L_0DB28F;
    case 0x0DB293u: goto L_0DB293;
    case 0x0DB295u: goto L_0DB295;
    case 0x0DB297u: goto L_0DB297;
    case 0x0DB299u: goto L_0DB299;
    case 0x0DB29Du: goto L_0DB29D;
    case 0x0DB29Fu: goto L_0DB29F;
    case 0x0DB2A2u: goto L_0DB2A2;
    case 0x0DB2A4u: goto L_0DB2A4;
    case 0x0DB2A6u: goto L_0DB2A6;
    case 0x0DB2A9u: goto L_0DB2A9;
    case 0x0DB2ABu: goto L_0DB2AB;
    case 0x0DB2ACu: goto L_0DB2AC;
    case 0x0DB2AEu: goto L_0DB2AE;
    case 0x0DB2AFu: goto L_0DB2AF;
    case 0x0DB2B1u: goto L_0DB2B1;
    case 0x0DB2B3u: goto L_0DB2B3;
    case 0x0DB2B6u: goto L_0DB2B6;
    case 0x0DB2B8u: goto L_0DB2B8;
    case 0x0DB2BAu: goto L_0DB2BA;
    case 0x0DB2BBu: goto L_0DB2BB;
    case 0x0DB2BDu: goto L_0DB2BD;
    case 0x0DB2BFu: goto L_0DB2BF;
    case 0x0DB2C1u: goto L_0DB2C1;
    case 0x0DB2C2u: goto L_0DB2C2;
    case 0x0DB2C4u: goto L_0DB2C4;
    case 0x0DB2C6u: goto L_0DB2C6;
    case 0x0DB2C9u: goto L_0DB2C9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB212u,cpu,0x2Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB212u, 5u, 4u, 0x303225u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB212 AND
    cpu.logicAnd(hw.readW(0x303225u, cpu.m8?8:16));
    goto L_0DB216;
L_0DB216:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB216u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB216u,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB216u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x33u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB216 AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0x33u), cpu.m8?8:16));
    goto L_0DB218;
L_0DB218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB218u,cpu,0x31u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB218u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x25u) & 0xFFFFu), 2u, 0u);
    // $0DB218 AND
    cpu.logicAnd(hw.readW(cpu.addressDpIndirectY(hw, 0x25u), cpu.m8?8:16));
    goto L_0DB21A;
L_0DB21A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB21Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Au,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x39u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB21A BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0x39u), cpu.m8?8:16), false);
    goto L_0DB21C;
L_0DB21C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB21Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Cu,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB21C AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0x3Cu), cpu.m8?8:16));
    goto L_0DB21E;
L_0DB21E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB21Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Eu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB21E DEC
    cpu.decReg('A');
    goto L_0DB21F;
L_0DB21F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB21Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Fu,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB21Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB21F AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0x3Du), cpu.m8?8:16));
    goto L_0DB221;
L_0DB221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB221u,cpu,0x3Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB221u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB221 TSC
    cpu.tsc();
    goto L_0DB222;
L_0DB222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB222u,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB222u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB222 AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0x3Eu), cpu.m8?8:16));
    goto L_0DB224;
L_0DB224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB224u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB224u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB224 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB226;
L_0DB226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB226u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB226u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB226 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB228;
L_0DB228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB228u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB228u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB228 AND
    cpu.logicAnd(0xFu);
    goto L_0DB22A;
L_0DB22A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB22A STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_0DB22C;
L_0DB22C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB22C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB22E;
L_0DB22E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB22E LSR
    cpu.lsrA();
    goto L_0DB22F;
L_0DB22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB22Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB22F LSR
    cpu.lsrA();
    goto L_0DB230;
L_0DB230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB230u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB230u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB230 LSR
    cpu.lsrA();
    goto L_0DB231;
L_0DB231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB231u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB231u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB231 LSR
    cpu.lsrA();
    goto L_0DB232;
L_0DB232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB232u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB232u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB232 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DB234;
L_0DB234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB234u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB234u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB234 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DB236;
L_0DB236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB236u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB236u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB236 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xB238u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB239u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DB236u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB239;
L_0DB239:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB239u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB239u,0x0DB239u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB239u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB239u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB239 LDX
    cpu.setX(0x0u, 8);
    goto L_0DB23B;
L_0DB23B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB23Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Bu, 5u, 4u, ((0x0DB212u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB23B LDA
    cpu.loadA(hw.readW(((0xDB212u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB23F;
L_0DB23F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB23Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB23Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB23F STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_0DB241;
L_0DB241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB241u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB241u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB241 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB243;
L_0DB243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB243u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB243u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB243 BEQ -> $0DB24B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB24B; }
    goto L_0DB245;
L_0DB245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB245u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB245u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB245u, 5u, 4u, ((0x0DB21Bu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB245 LDA
    cpu.loadA(hw.readW(((0xDB21Bu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB249;
L_0DB249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB249u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB249u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB249 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_0DB24B;
L_0DB24B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Bu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB24B JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB24Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB24Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB24Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB24E;
L_0DB24E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB24Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB24Eu,0x0DB24Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB24Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB24E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB250;
L_0DB250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB250u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB250u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DB250 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DB252;
L_0DB252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB252u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB252u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB252 TYA
    cpu.transfer("TYA");
    goto L_0DB253;
L_0DB253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB253u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB253u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB253 CLC
    cpu.setFlag('C', false);
    goto L_0DB254;
L_0DB254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB254u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB254u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB254 ADC
    cpu.adc(0x10u);
    goto L_0DB256;
L_0DB256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB256u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB256u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB256 TAY
    cpu.transfer("TAY");
    goto L_0DB257;
L_0DB257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB257u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB257u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB257 BCC -> $0DB261
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DB261; }
    goto L_0DB259;
L_0DB259:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB259u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB259u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB259u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB259 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB25B;
L_0DB25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB25B ADC
    cpu.adc(0x0u);
    goto L_0DB25D;
L_0DB25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB25D STA
    hw.write(cpu.address("dp", 0x6Cu), cpu.a, cpu.m8?8:16);
    goto L_0DB25F;
L_0DB25F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB25Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB25Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB25F STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_0DB261;
L_0DB261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB261u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB261u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB261 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DB263;
L_0DB263:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB263u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB263u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB263u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB263 BEQ -> $0DB28F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB28F; }
    goto L_0DB265;
L_0DB265:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB265u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB265u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB265u, 5u, 4u, ((0x0DB215u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB265 LDA
    cpu.loadA(hw.readW(((0xDB215u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB269;
L_0DB269:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB269u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB269u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB269u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB269 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_0DB26B;
L_0DB26B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB26B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB26D;
L_0DB26D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB26D BEQ -> $0DB275
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB275; }
    goto L_0DB26F;
L_0DB26F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Fu, 5u, 4u, ((0x0DB21Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB26F LDA
    cpu.loadA(hw.readW(((0xDB21Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB273;
L_0DB273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB273u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB273u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB273 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_0DB275;
L_0DB275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB275u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB275u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB275 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB277u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB278u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB275u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB278;
L_0DB278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB278u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB278u,0x0DB278u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB278u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB278u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB278 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB27A;
L_0DB27A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Au,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DB27A STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DB27C;
L_0DB27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Cu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB27C TYA
    cpu.transfer("TYA");
    goto L_0DB27D;
L_0DB27D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB27D CLC
    cpu.setFlag('C', false);
    goto L_0DB27E;
L_0DB27E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB27E ADC
    cpu.adc(0x10u);
    goto L_0DB280;
L_0DB280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB280u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB280u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB280u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB280 TAY
    cpu.transfer("TAY");
    goto L_0DB281;
L_0DB281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB281u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB281u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB281 BCC -> $0DB28B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DB28B; }
    goto L_0DB283;
L_0DB283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB283u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB283u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB283 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB285;
L_0DB285:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB285u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB285u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB285u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB285 ADC
    cpu.adc(0x0u);
    goto L_0DB287;
L_0DB287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB287u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB287u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB287 STA
    hw.write(cpu.address("dp", 0x6Cu), cpu.a, cpu.m8?8:16);
    goto L_0DB289;
L_0DB289:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB289u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB289u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB289u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB289 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_0DB28B;
L_0DB28B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Bu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB28B DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DB28D;
L_0DB28D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB28D BNE -> $0DB265
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB265; }
    goto L_0DB28F;
L_0DB28F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB28Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB28Fu, 5u, 4u, ((0x0DB218u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB28F LDA
    cpu.loadA(hw.readW(((0xDB218u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB293;
L_0DB293:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB293u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB293u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB293u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB293 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_0DB295;
L_0DB295:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB295u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB295u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB295u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB295 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB297;
L_0DB297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB297u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB297u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB297 BEQ -> $0DB29F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB29F; }
    goto L_0DB299;
L_0DB299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB299u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB299u, 5u, 4u, ((0x0DB221u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB299 LDA
    cpu.loadA(hw.readW(((0xDB221u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB29D;
L_0DB29D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB29Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB29D STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_0DB29F;
L_0DB29F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB29Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB29Fu, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB29F JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB2A1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2A2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB29Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB2A2;
L_0DB2A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2A2u,0x0DB2A2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2A2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB2A4;
L_0DB2A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A4u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A4u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x6Bu) & 0xFFFFu), 3u, 0u);
    // $0DB2A4 STA
    hw.write(cpu.addressDpLongY(hw, 0x6Bu), cpu.a, cpu.m8?8:16);
    goto L_0DB2A6;
L_0DB2A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A6u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB2A6 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xB2A8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2A9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DB2A6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB2A9;
L_0DB2A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2A9u,0x0DB2A9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2A9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x57u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB2AB;
L_0DB2AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ABu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2AB CLC
    cpu.setFlag('C', false);
    goto L_0DB2AC;
L_0DB2AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ACu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2AC ADC
    cpu.adc(0x1u);
    goto L_0DB2AE;
L_0DB2AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2AEu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2AE TAY
    cpu.transfer("TAY");
    goto L_0DB2AF;
L_0DB2AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2AFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2AF AND
    cpu.logicAnd(0xFu);
    goto L_0DB2B1;
L_0DB2B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2B1 BNE -> $0DB2BB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB2BB; }
    goto L_0DB2B3;
L_0DB2B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B3u, 6u, 3u, cpu.address("abs", 0xA9EFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB2B3 JSR -> $0DA9EF stack real
    { cpu.push16Value(hw,0xB2B5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2B6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA9EFu), 0x0DB2B3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB2B6;
L_0DB2B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2B6u,0x0DB2B6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2B6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x57u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB2B8;
L_0DB2B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2B8 AND
    cpu.logicAnd(0xF0u);
    goto L_0DB2BA;
L_0DB2BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2BA TAY
    cpu.transfer("TAY");
    goto L_0DB2BB;
L_0DB2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2BB STY
    hw.write(cpu.address("dp", 0x57u), cpu.y, cpu.x8?8:16);
    goto L_0DB2BD;
L_0DB2BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2BD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB2BF;
L_0DB2BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2BF STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DB2C1;
L_0DB2C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2C1 INX
    cpu.inc('X');
    goto L_0DB2C2;
L_0DB2C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2C2 CPX
    cpu.compareX(0x3u);
    goto L_0DB2C4;
L_0DB2C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2C4 BEQ -> $0DB2C9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB2C9; }
    goto L_0DB2C6;
L_0DB2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u, 3u, 3u, cpu.address("abs", 0xB23Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB2C6 JMP -> $0DB23B
    goto L_0DB23B;
L_0DB2C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB2C9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB2C9u);return;} hw.unresolvedReturn(0x0DB2C9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DB336_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB336u: goto L_0DB336;
    case 0x0DB338u: goto L_0DB338;
    case 0x0DB33Au: goto L_0DB33A;
    case 0x0DB33Cu: goto L_0DB33C;
    case 0x0DB33Eu: goto L_0DB33E;
    case 0x0DB33Fu: goto L_0DB33F;
    case 0x0DB341u: goto L_0DB341;
    case 0x0DB342u: goto L_0DB342;
    case 0x0DB343u: goto L_0DB343;
    case 0x0DB344u: goto L_0DB344;
    case 0x0DB345u: goto L_0DB345;
    case 0x0DB347u: goto L_0DB347;
    case 0x0DB34Au: goto L_0DB34A;
    case 0x0DB34Bu: goto L_0DB34B;
    case 0x0DB34Cu: goto L_0DB34C;
    case 0x0DB34Du: goto L_0DB34D;
    case 0x0DB34Eu: goto L_0DB34E;
    case 0x0DB351u: goto L_0DB351;
    case 0x0DB353u: goto L_0DB353;
    case 0x0DB354u: goto L_0DB354;
    case 0x0DB358u: goto L_0DB358;
    case 0x0DB35Au: goto L_0DB35A;
    case 0x0DB35Cu: goto L_0DB35C;
    case 0x0DB360u: goto L_0DB360;
    case 0x0DB362u: goto L_0DB362;
    case 0x0DB365u: goto L_0DB365;
    case 0x0DB366u: goto L_0DB366;
    case 0x0DB367u: goto L_0DB367;
    case 0x0DB369u: goto L_0DB369;
    case 0x0DB36Bu: goto L_0DB36B;
    case 0x0DB36Du: goto L_0DB36D;
    case 0x0DB36Fu: goto L_0DB36F;
    case 0x0DB371u: goto L_0DB371;
    case 0x0DB373u: goto L_0DB373;
    case 0x0DB375u: goto L_0DB375;
    case 0x0DB376u: goto L_0DB376;
    case 0x0DB378u: goto L_0DB378;
    case 0x0DB37Au: goto L_0DB37A;
    case 0x0DB37Cu: goto L_0DB37C;
    case 0x0DB37Eu: goto L_0DB37E;
    case 0x0DB380u: goto L_0DB380;
    case 0x0DB381u: goto L_0DB381;
    case 0x0DB383u: goto L_0DB383;
    case 0x0DB384u: goto L_0DB384;
    case 0x0DB386u: goto L_0DB386;
    case 0x0DB388u: goto L_0DB388;
    case 0x0DB38Cu: goto L_0DB38C;
    case 0x0DB38Eu: goto L_0DB38E;
    case 0x0DB38Fu: goto L_0DB38F;
    case 0x0DB390u: goto L_0DB390;
    case 0x0DB391u: goto L_0DB391;
    case 0x0DB392u: goto L_0DB392;
    case 0x0DB395u: goto L_0DB395;
    case 0x0DB397u: goto L_0DB397;
    case 0x0DB399u: goto L_0DB399;
    case 0x0DB39Bu: goto L_0DB39B;
    case 0x0DB39Du: goto L_0DB39D;
    case 0x0DB3A0u: goto L_0DB3A0;
    case 0x0DB3A3u: goto L_0DB3A3;
    case 0x0DB3A5u: goto L_0DB3A5;
    case 0x0DB3A8u: goto L_0DB3A8;
    case 0x0DB3A9u: goto L_0DB3A9;
    case 0x0DB3ABu: goto L_0DB3AB;
    case 0x0DB3AEu: goto L_0DB3AE;
    case 0x0DB3B1u: goto L_0DB3B1;
    case 0x0DB3B3u: goto L_0DB3B3;
    case 0x0DB3B5u: goto L_0DB3B5;
    case 0x0DB3B7u: goto L_0DB3B7;
    case 0x0DB3BAu: goto L_0DB3BA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB336u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB336u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB336 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB338;
L_0DB338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB338u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB338u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB338 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB33A;
L_0DB33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB33Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB33A AND
    cpu.logicAnd(0xFu);
    goto L_0DB33C;
L_0DB33C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB33Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB33C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DB33E;
L_0DB33E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB33Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB33E TAX
    cpu.transfer("TAX");
    goto L_0DB33F;
L_0DB33F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB33Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB33F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB341;
L_0DB341:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB341u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB341u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB341u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB341 LSR
    cpu.lsrA();
    goto L_0DB342;
L_0DB342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB342u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB342u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB342 LSR
    cpu.lsrA();
    goto L_0DB343;
L_0DB343:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB343u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB343u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB343u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB343 LSR
    cpu.lsrA();
    goto L_0DB344;
L_0DB344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB344u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB344u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB344 LSR
    cpu.lsrA();
    goto L_0DB345;
L_0DB345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB345u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB345u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB345 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DB347;
L_0DB347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB347u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB347u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB347 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xB349u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB34Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DB347u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB34A;
L_0DB34A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB34Au,0x0DB34Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Au,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB34A TYA
    cpu.transfer("TYA");
    goto L_0DB34B;
L_0DB34B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0DB34B PHA
    cpu.push("PHA", hw);
    goto L_0DB34C;
L_0DB34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB34C TXA
    cpu.transfer("TXA");
    goto L_0DB34D;
L_0DB34D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0DB34D PHA
    cpu.push("PHA", hw);
    goto L_0DB34E;
L_0DB34E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Eu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Eu, 4u, 3u, cpu.address("abs", 0x13BEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB34E LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13BEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB351;
L_0DB351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB351 LDA
    cpu.setA(0xF8u, 8);
    goto L_0DB353;
L_0DB353:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB353u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB353u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB353u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB353 CLC
    cpu.setFlag('C', false);
    goto L_0DB354;
L_0DB354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u, 5u, 4u, ((0x0DA8AEu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB354 ADC
    cpu.adc(hw.readW(((0xDA8AEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DB358;
L_0DB358:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB358u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB358u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB358u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB358 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_0DB35A;
L_0DB35A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB35A LDA
    cpu.setA(0x19u, 8);
    goto L_0DB35C;
L_0DB35C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Cu,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Cu, 5u, 4u, ((0x0DA8B1u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB35C ADC
    cpu.adc(hw.readW(((0xDA8B1u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DB360;
L_0DB360:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB360u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB360u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB360u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB360 STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_0DB362;
L_0DB362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB362u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB362u, 4u, 3u, cpu.address("abs", 0x1BA1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB362 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB365;
L_0DB365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB365u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB365u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB365 ASL
    cpu.aslA();
    goto L_0DB366;
L_0DB366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB366u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB366u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB366 ASL
    cpu.aslA();
    goto L_0DB367;
L_0DB367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB367u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB367u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB367 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0DB369;
L_0DB369:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB369u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB369u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB369u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB369 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB36B;
L_0DB36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB36B AND
    cpu.logicAnd(0x10u);
    goto L_0DB36D;
L_0DB36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB36D BEQ -> $0DB375
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB375; }
    goto L_0DB36F;
L_0DB36F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB36F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB371;
L_0DB371:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB371u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB371u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB371u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB371 ORA
    cpu.logicOr(0x2u);
    goto L_0DB373;
L_0DB373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB373u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB373u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB373u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB373 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0DB375;
L_0DB375:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB375u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB375u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB375u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB375 TYA
    cpu.transfer("TYA");
    goto L_0DB376;
L_0DB376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB376u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB376u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB376 AND
    cpu.logicAnd(0x8u);
    goto L_0DB378;
L_0DB378:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB378u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB378u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB378u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB378 BEQ -> $0DB380
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB380; }
    goto L_0DB37A;
L_0DB37A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB37A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB37C;
L_0DB37C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Cu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB37C ORA
    cpu.logicOr(0x1u);
    goto L_0DB37E;
L_0DB37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB37E STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0DB380;
L_0DB380:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB380u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB380u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB380u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB380 TYA
    cpu.transfer("TYA");
    goto L_0DB381;
L_0DB381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB381u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB381u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB381 AND
    cpu.logicAnd(0x7u);
    goto L_0DB383;
L_0DB383:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB383u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB383u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB383u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB383 TAX
    cpu.transfer("TAX");
    goto L_0DB384;
L_0DB384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB384u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB384u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB384 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB386;
L_0DB386:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB386u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB386u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB386u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x08u) & 0xFFFFu), 2u, 0u);
    // $0DB386 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB388;
L_0DB388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB388u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB388u,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB388u, 5u, 4u, ((0x0DA8A6u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB388 AND
    cpu.logicAnd(hw.readW(((0xDA8A6u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_0DB38C;
L_0DB38C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB38C STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_0DB38E;
L_0DB38E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Eu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0DB38E PLA
    cpu.pop("PLA", hw);
    goto L_0DB38F;
L_0DB38F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB38F TAX
    cpu.transfer("TAX");
    goto L_0DB390;
L_0DB390:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB390u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB390u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB390u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0DB390 PLA
    cpu.pop("PLA", hw);
    goto L_0DB391;
L_0DB391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB391u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB391 TAY
    cpu.transfer("TAY");
    goto L_0DB392;
L_0DB392:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB392u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB392u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB392u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB392 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB394u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB395u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB392u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB395;
L_0DB395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB395u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB395u,0x0DB395u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB395u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB395u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB395 LDA
    cpu.setA(0x2Cu, 8);
    goto L_0DB397;
L_0DB397:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB397u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB397u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB397u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB397 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_0DB399;
L_0DB399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB399 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB39B;
L_0DB39B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB39B BEQ -> $0DB3A3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DB3A3; }
    goto L_0DB39D;
L_0DB39D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Du, 6u, 3u, cpu.address("abs", 0xA987u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB39D JSR -> $0DA987 stack real
    { cpu.push16Value(hw,0xB39Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3A0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA987u), 0x0DB39Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB3A0;
L_0DB3A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A0u,0x0DB3A0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 3u, 3u, cpu.address("abs", 0xB3A8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3A0 JMP -> $0DB3A8
    goto L_0DB3A8;
L_0DB3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3A3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB3A5;
L_0DB3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A5u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB3A5 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB3A7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3A8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB3A5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB3A8;
L_0DB3A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A8u,0x0DB3A8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A8u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3A8 DEX
    cpu.decReg('X');
    goto L_0DB3A9;
L_0DB3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3A9 BPL -> $0DB34A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB34A; }
    goto L_0DB3AB;
L_0DB3AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ABu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ABu, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB3AB JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xB3ADu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3AEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DB3ABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB3AE;
L_0DB3AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3AEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3AEu,0x0DB3AEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AEu, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB3AE JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xB3B0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3B1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DB3AEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB3B1;
L_0DB3B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3B1u,0x0DB3B1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B1u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3B1 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB3B3;
L_0DB3B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B3u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3B3 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DB3B5;
L_0DB3B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B5u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3B5 BMI -> $0DB3BA
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB3BA; }
    goto L_0DB3B7;
L_0DB3B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B7u, 3u, 3u, cpu.address("abs", 0xB34Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB3B7 JMP -> $0DB34A
    goto L_0DB34A;
L_0DB3BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB3BA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB3BAu);return;} hw.unresolvedReturn(0x0DB3BAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DB6C3_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DB6C3u: goto L_0DB6C3;
    case 0x0DB6C5u: goto L_0DB6C5;
    case 0x0DB6C7u: goto L_0DB6C7;
    case 0x0DB6C9u: goto L_0DB6C9;
    case 0x0DB6CBu: goto L_0DB6CB;
    case 0x0DB6CDu: goto L_0DB6CD;
    case 0x0DB6CEu: goto L_0DB6CE;
    case 0x0DB6CFu: goto L_0DB6CF;
    case 0x0DB6D0u: goto L_0DB6D0;
    case 0x0DB6D1u: goto L_0DB6D1;
    case 0x0DB6D2u: goto L_0DB6D2;
    case 0x0DB6D5u: goto L_0DB6D5;
    case 0x0DB6D9u: goto L_0DB6D9;
    case 0x0DB6DCu: goto L_0DB6DC;
    case 0x0DB6DEu: goto L_0DB6DE;
    case 0x0DB6E0u: goto L_0DB6E0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DB6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C3u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6C3 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DB6C5;
L_0DB6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6C5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB6C7;
L_0DB6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6C7 AND
    cpu.logicAnd(0xFu);
    goto L_0DB6C9;
L_0DB6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6C9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DB6CB;
L_0DB6CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6CB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB6CD;
L_0DB6CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6CD LSR
    cpu.lsrA();
    goto L_0DB6CE;
L_0DB6CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6CE LSR
    cpu.lsrA();
    goto L_0DB6CF;
L_0DB6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6CF LSR
    cpu.lsrA();
    goto L_0DB6D0;
L_0DB6D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6D0 LSR
    cpu.lsrA();
    goto L_0DB6D1;
L_0DB6D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6D1 TAX
    cpu.transfer("TAX");
    goto L_0DB6D2;
L_0DB6D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D2u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB6D2 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xB6D4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB6D5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DB6D2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB6D5;
L_0DB6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6D5u,0x0DB6D5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D5u, 5u, 4u, ((0x0DB6C1u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6D5 LDA
    cpu.loadA(hw.readW(((0xDB6C1u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DB6D9;
L_0DB6D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D9u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB6D9 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xB6DBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB6DCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DB6D9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DB6DC;
L_0DB6DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6DCu,0x0DB6DCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DCu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6DC DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DB6DE;
L_0DB6DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DB6DE BPL -> $0DB6D2
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DB6D2; }
    goto L_0DB6E0;
L_0DB6E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DB6E0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DB6E0u);return;} hw.unresolvedReturn(0x0DB6E0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DCF12_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DCF12u: goto L_0DCF12;
    case 0x0DCF14u: goto L_0DCF14;
    case 0x0DCF16u: goto L_0DCF16;
    case 0x0DCF18u: goto L_0DCF18;
    case 0x0DCF1Au: goto L_0DCF1A;
    case 0x0DCF1Cu: goto L_0DCF1C;
    case 0x0DCF1Du: goto L_0DCF1D;
    case 0x0DCF1Eu: goto L_0DCF1E;
    case 0x0DCF1Fu: goto L_0DCF1F;
    case 0x0DCF20u: goto L_0DCF20;
    case 0x0DCF21u: goto L_0DCF21;
    case 0x0DCF24u: goto L_0DCF24;
    case 0x0DCF28u: goto L_0DCF28;
    case 0x0DCF2Bu: goto L_0DCF2B;
    case 0x0DCF2Du: goto L_0DCF2D;
    case 0x0DCF2Fu: goto L_0DCF2F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DCF12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF12u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF12u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF12 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DCF14;
L_0DCF14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF14u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF14u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF14 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCF16;
L_0DCF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF16u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF16 AND
    cpu.logicAnd(0xFu);
    goto L_0DCF18;
L_0DCF18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF18u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF18u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF18 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DCF1A;
L_0DCF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF1A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCF1C;
L_0DCF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF1C LSR
    cpu.lsrA();
    goto L_0DCF1D;
L_0DCF1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF1D LSR
    cpu.lsrA();
    goto L_0DCF1E;
L_0DCF1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF1E LSR
    cpu.lsrA();
    goto L_0DCF1F;
L_0DCF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF1F LSR
    cpu.lsrA();
    goto L_0DCF20;
L_0DCF20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF20u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF20u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF20 TAX
    cpu.transfer("TAX");
    goto L_0DCF21;
L_0DCF21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF21u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF21u, 6u, 3u, cpu.address("abs", 0xAA0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCF21 JSR -> $0DAA0D stack real
    { cpu.push16Value(hw,0xCF23u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF24u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA0Du), 0x0DCF21u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCF24;
L_0DCF24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF24u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF24u,0x0DCF24u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF24u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF24u, 5u, 4u, ((0x0DCF10u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF24 LDA
    cpu.loadA(hw.readW(((0xDCF10u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DCF28;
L_0DCF28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF28u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF28u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCF28 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xCF2Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF2Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DCF28u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DCF2B;
L_0DCF2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF2Bu,0x0DCF2Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Bu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF2B DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DCF2D;
L_0DCF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DCF2D BPL -> $0DCF21
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DCF21; }
    goto L_0DCF2F;
L_0DCF2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DCF2F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DCF2Fu);return;} hw.unresolvedReturn(0x0DCF2Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

