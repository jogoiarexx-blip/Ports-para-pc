#include "generated.hpp"
void sub_0082C3_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0082C3u: goto L_0082C3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0082C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $0082C3 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x0082C3u);return;}
}

void sub_009A1F_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x009A1Fu: goto L_009A1F;
    case 0x009A21u: goto L_009A21;
    case 0x009A23u: goto L_009A23;
    case 0x009A27u: goto L_009A27;
    case 0x009A2Bu: goto L_009A2B;
    case 0x009A2Fu: goto L_009A2F;
    case 0x009A33u: goto L_009A33;
    case 0x009A34u: goto L_009A34;
    case 0x009A35u: goto L_009A35;
    case 0x009A37u: goto L_009A37;
    case 0x009A39u: goto L_009A39;
    case 0x009A3Bu: goto L_009A3B;
    case 0x009A3Du: goto L_009A3D;
    case 0x009A3Fu: goto L_009A3F;
    case 0x009A41u: goto L_009A41;
    case 0x009A45u: goto L_009A45;
    case 0x009A49u: goto L_009A49;
    case 0x009A4Au: goto L_009A4A;
    case 0x009A4Bu: goto L_009A4B;
    case 0x009A4Du: goto L_009A4D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_009A1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A1Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A1Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A1F LDY
    cpu.setY(0x10u, 8);
    goto L_009A21;
L_009A21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A21u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A21 LDA
    cpu.setA(0x32u, 8);
    goto L_009A23;
L_009A23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A23u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A23u, 5u, 4u, ((0x7EC800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A23 STA
    hw.write(((0x7EC800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_009A27;
L_009A27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A27u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A27u, 5u, 4u, ((0x7EC9B0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A27 STA
    hw.write(((0x7EC9B0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_009A2B;
L_009A2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Bu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Bu, 5u, 4u, ((0x7FC800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A2B STA
    hw.write(((0x7FC800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_009A2F;
L_009A2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Fu, 5u, 4u, ((0x7FC9B0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A2F STA
    hw.write(((0x7FC9B0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_009A33;
L_009A33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A33u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A33u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A33 INX
    cpu.inc('X');
    goto L_009A34;
L_009A34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A34u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A34 DEY
    cpu.decReg('Y');
    goto L_009A35;
L_009A35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A35u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A35u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A35 BNE -> $009A23
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009A23; }
    goto L_009A37;
L_009A37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A37u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A37 CPX
    cpu.compareX(0xC0u);
    goto L_009A39;
L_009A39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A39u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A39 BNE -> $009A4D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009A4D; }
    goto L_009A3B;
L_009A3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A3B LDX
    cpu.setX(0xD0u, 8);
    goto L_009A3D;
L_009A3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A3D LDY
    cpu.setY(0x10u, 8);
    goto L_009A3F;
L_009A3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A3F LDA
    cpu.setA(0x5u, 8);
    goto L_009A41;
L_009A41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A41u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A41u, 5u, 4u, ((0x7EC800u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A41 STA
    hw.write(((0x7EC800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_009A45;
L_009A45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A45u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A45u, 5u, 4u, ((0x7EC9B0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A45 STA
    hw.write(((0x7EC9B0u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_009A49;
L_009A49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A49u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A49 INX
    cpu.inc('X');
    goto L_009A4A;
L_009A4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A4A DEY
    cpu.decReg('Y');
    goto L_009A4B;
L_009A4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009A4B BNE -> $009A41
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_009A41; }
    goto L_009A4D;
L_009A4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009A4D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009A4Du);return;} hw.unresolvedReturn(0x009A4Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00CEB1_E1M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00CEB1u: goto L_00CEB1;
    case 0x00CEB4u: goto L_00CEB4;
    case 0x00CEB6u: goto L_00CEB6;
    case 0x00CEB9u: goto L_00CEB9;
    case 0x00CEBBu: goto L_00CEBB;
    case 0x00CEBDu: goto L_00CEBD;
    case 0x00CEBFu: goto L_00CEBF;
    case 0x00CEC1u: goto L_00CEC1;
    case 0x00CEC3u: goto L_00CEC3;
    case 0x00CEC5u: goto L_00CEC5;
    case 0x00CEC7u: goto L_00CEC7;
    case 0x00CEC9u: goto L_00CEC9;
    case 0x00CECBu: goto L_00CECB;
    case 0x00CECDu: goto L_00CECD;
    case 0x00CECEu: goto L_00CECE;
    case 0x00CED0u: goto L_00CED0;
    case 0x00CED2u: goto L_00CED2;
    case 0x00CED4u: goto L_00CED4;
    case 0x00CED6u: goto L_00CED6;
    case 0x00CED8u: goto L_00CED8;
    case 0x00CEDAu: goto L_00CEDA;
    case 0x00CEDCu: goto L_00CEDC;
    case 0x00CEDEu: goto L_00CEDE;
    case 0x00CEE0u: goto L_00CEE0;
    case 0x00CEE2u: goto L_00CEE2;
    case 0x00CEE4u: goto L_00CEE4;
    case 0x00CEE5u: goto L_00CEE5;
    case 0x00CEE7u: goto L_00CEE7;
    case 0x00CEE8u: goto L_00CEE8;
    case 0x00CEEAu: goto L_00CEEA;
    case 0x00CEECu: goto L_00CEEC;
    case 0x00CEEEu: goto L_00CEEE;
    case 0x00CEF0u: goto L_00CEF0;
    case 0x00CEF2u: goto L_00CEF2;
    case 0x00CEF4u: goto L_00CEF4;
    case 0x00CEF5u: goto L_00CEF5;
    case 0x00CEF6u: goto L_00CEF6;
    case 0x00CEF7u: goto L_00CEF7;
    case 0x00CEF8u: goto L_00CEF8;
    case 0x00CEF9u: goto L_00CEF9;
    case 0x00CEFCu: goto L_00CEFC;
    case 0x00CEFDu: goto L_00CEFD;
    case 0x00CEFEu: goto L_00CEFE;
    case 0x00CF00u: goto L_00CF00;
    case 0x00CF02u: goto L_00CF02;
    case 0x00CF04u: goto L_00CF04;
    case 0x00CF06u: goto L_00CF06;
    case 0x00CF08u: goto L_00CF08;
    case 0x00CF0Au: goto L_00CF0A;
    case 0x00CF0Du: goto L_00CF0D;
    case 0x00CF0Eu: goto L_00CF0E;
    case 0x00CF10u: goto L_00CF10;
    case 0x00CF12u: goto L_00CF12;
    case 0x00CF13u: goto L_00CF13;
    case 0x00CF16u: goto L_00CF16;
    case 0x00CF19u: goto L_00CF19;
    case 0x00CF1Cu: goto L_00CF1C;
    case 0x00CF1Eu: goto L_00CF1E;
    case 0x00CF20u: goto L_00CF20;
    case 0x00CF22u: goto L_00CF22;
    case 0x00CF24u: goto L_00CF24;
    case 0x00CF25u: goto L_00CF25;
    case 0x00CF26u: goto L_00CF26;
    case 0x00CF28u: goto L_00CF28;
    case 0x00CF2Au: goto L_00CF2A;
    case 0x00CF2Cu: goto L_00CF2C;
    case 0x00CF2Eu: goto L_00CF2E;
    case 0x00CF2Fu: goto L_00CF2F;
    case 0x00CF32u: goto L_00CF32;
    case 0x00CF35u: goto L_00CF35;
    case 0x00CF37u: goto L_00CF37;
    case 0x00CF39u: goto L_00CF39;
    case 0x00CF3Au: goto L_00CF3A;
    case 0x00CF3Du: goto L_00CF3D;
    case 0x00CF3Fu: goto L_00CF3F;
    case 0x00CF41u: goto L_00CF41;
    case 0x00CF43u: goto L_00CF43;
    case 0x00CF45u: goto L_00CF45;
    case 0x00CF48u: goto L_00CF48;
    case 0x00CF4Bu: goto L_00CF4B;
    case 0x00CF4Eu: goto L_00CF4E;
    case 0x00CF51u: goto L_00CF51;
    case 0x00CF53u: goto L_00CF53;
    case 0x00CF55u: goto L_00CF55;
    case 0x00CF58u: goto L_00CF58;
    case 0x00CF59u: goto L_00CF59;
    case 0x00CF5Au: goto L_00CF5A;
    case 0x00CF5Cu: goto L_00CF5C;
    case 0x00CF5Du: goto L_00CF5D;
    case 0x00CF60u: goto L_00CF60;
    case 0x00CF62u: goto L_00CF62;
    case 0x00CF64u: goto L_00CF64;
    case 0x00CF67u: goto L_00CF67;
    case 0x00CF69u: goto L_00CF69;
    case 0x00CF6Bu: goto L_00CF6B;
    case 0x00CF6Du: goto L_00CF6D;
    case 0x00CF6Fu: goto L_00CF6F;
    case 0x00CF72u: goto L_00CF72;
    case 0x00CF74u: goto L_00CF74;
    case 0x00CF76u: goto L_00CF76;
    case 0x00CF78u: goto L_00CF78;
    case 0x00CF7Au: goto L_00CF7A;
    case 0x00CF7Cu: goto L_00CF7C;
    case 0x00CF7Eu: goto L_00CF7E;
    case 0x00CF80u: goto L_00CF80;
    case 0x00CF83u: goto L_00CF83;
    case 0x00CF85u: goto L_00CF85;
    case 0x00CF88u: goto L_00CF88;
    case 0x00CF8Au: goto L_00CF8A;
    case 0x00CF8Du: goto L_00CF8D;
    case 0x00CF8Fu: goto L_00CF8F;
    case 0x00CF91u: goto L_00CF91;
    case 0x00CF94u: goto L_00CF94;
    case 0x00CF96u: goto L_00CF96;
    case 0x00CF98u: goto L_00CF98;
    case 0x00CF9Bu: goto L_00CF9B;
    case 0x00CF9Du: goto L_00CF9D;
    case 0x00CF9Fu: goto L_00CF9F;
    case 0x00CFA1u: goto L_00CFA1;
    case 0x00CFA4u: goto L_00CFA4;
    case 0x00CFA6u: goto L_00CFA6;
    case 0x00CFA9u: goto L_00CFA9;
    case 0x00CFABu: goto L_00CFAB;
    case 0x00CFAEu: goto L_00CFAE;
    case 0x00CFB1u: goto L_00CFB1;
    case 0x00CFB3u: goto L_00CFB3;
    case 0x00CFB5u: goto L_00CFB5;
    case 0x00CFB7u: goto L_00CFB7;
    case 0x00CFBAu: goto L_00CFBA;
    case 0x00CFBCu: goto L_00CFBC;
    case 0x00CFBEu: goto L_00CFBE;
    case 0x00CFC0u: goto L_00CFC0;
    case 0x00CFC2u: goto L_00CFC2;
    case 0x00CFC3u: goto L_00CFC3;
    case 0x00CFC4u: goto L_00CFC4;
    case 0x00CFC6u: goto L_00CFC6;
    case 0x00CFC7u: goto L_00CFC7;
    case 0x00CFC9u: goto L_00CFC9;
    case 0x00CFCBu: goto L_00CFCB;
    case 0x00CFCDu: goto L_00CFCD;
    case 0x00CFCFu: goto L_00CFCF;
    case 0x00CFD2u: goto L_00CFD2;
    case 0x00CFD4u: goto L_00CFD4;
    case 0x00CFD6u: goto L_00CFD6;
    case 0x00CFD8u: goto L_00CFD8;
    case 0x00CFDAu: goto L_00CFDA;
    case 0x00CFDCu: goto L_00CFDC;
    case 0x00CFDEu: goto L_00CFDE;
    case 0x00CFE0u: goto L_00CFE0;
    case 0x00CFE3u: goto L_00CFE3;
    case 0x00CFE6u: goto L_00CFE6;
    case 0x00CFE9u: goto L_00CFE9;
    case 0x00CFEBu: goto L_00CFEB;
    case 0x00CFECu: goto L_00CFEC;
    case 0x00CFEEu: goto L_00CFEE;
    case 0x00CFF0u: goto L_00CFF0;
    case 0x00CFF3u: goto L_00CFF3;
    case 0x00CFF4u: goto L_00CFF4;
    case 0x00CFF5u: goto L_00CFF5;
    case 0x00CFF6u: goto L_00CFF6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00CEB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB1u, 4u, 3u, cpu.address("abs", 0x14A2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEB1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CEB4;
L_00CEB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEB4 BNE -> $00CF16
    if (!cpu.z) { hw.addCpuInternalCycles(2u); goto L_00CF16; }
    goto L_00CEB6;
L_00CEB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB6u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB6u, 4u, 3u, cpu.address("abs", 0x13DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEB6 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13DFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CEB9;
L_00CEB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEB9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CEBB;
L_00CEBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEBB BEQ -> $00CEDE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CEDE; }
    goto L_00CEBD;
L_00CEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBDu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEBD LDY
    cpu.setY(0x4u, 8);
    goto L_00CEBF;
L_00CEBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBFu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEBF BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), false);
    goto L_00CEC1;
L_00CEC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEC1 BPL -> $00CECD
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00CECD; }
    goto L_00CEC3;
L_00CEC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEC3 CMP
    cpu.compareA(0xCu);
    goto L_00CEC5;
L_00CEC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEC5 BEQ -> $00CEFD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CEFD; }
    goto L_00CEC7;
L_00CEC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEC7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CEC9;
L_00CEC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEC9 BNE -> $00CEFD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CEFD; }
    goto L_00CECB;
L_00CECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECBu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CECB BRA -> $00CEE4
    goto L_00CEE4;
L_00CECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECDu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CECD INX
    cpu.inc('X');
    goto L_00CECE;
L_00CECE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECEu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CECE CPX
    cpu.compareX(0x5u);
    goto L_00CED0;
L_00CED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CED0 BCS -> $00CED6
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00CED6; }
    goto L_00CED2;
L_00CED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CED2 LDX
    cpu.setX(0x5u, 8);
    goto L_00CED4;
L_00CED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CED4 BRA -> $00CF0A
    hw.addCpuInternalCycles(1u); // penalidade de page-cross em emulacao
    goto L_00CF0A;
L_00CED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED6u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CED6 CPX
    cpu.compareX(0xBu);
    goto L_00CED8;
L_00CED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CED8 BCC -> $00CF0A
    if (!cpu.c) { hw.addCpuInternalCycles(2u); goto L_00CF0A; }
    goto L_00CEDA;
L_00CEDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDAu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEDA LDX
    cpu.setX(0x7u, 8);
    goto L_00CEDC;
L_00CEDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDCu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEDC BRA -> $00CF0A
    hw.addCpuInternalCycles(1u); // penalidade de page-cross em emulacao
    goto L_00CF0A;
L_00CEDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEDE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CEE0;
L_00CEE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEE0 BNE -> $00CEF0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CEF0; }
    goto L_00CEE2;
L_00CEE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEE2 LDY
    cpu.setY(0x8u, 8);
    goto L_00CEE4;
L_00CEE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEE4 TXA
    cpu.transfer("TXA");
    goto L_00CEE5;
L_00CEE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEE5 BEQ -> $00CF0A
    if (cpu.z) { hw.addCpuInternalCycles(2u); goto L_00CF0A; }
    goto L_00CEE7;
L_00CEE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE7u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEE7 DEX
    cpu.decReg('X');
    goto L_00CEE8;
L_00CEE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE8u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEE8 CPX
    cpu.compareX(0x3u);
    goto L_00CEEA;
L_00CEEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEEA BCC -> $00CF0A
    if (!cpu.c) { hw.addCpuInternalCycles(2u); goto L_00CF0A; }
    goto L_00CEEC;
L_00CEEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEECu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEEC LDX
    cpu.setX(0x2u, 8);
    goto L_00CEEE;
L_00CEEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEEE BRA -> $00CF0A
    hw.addCpuInternalCycles(1u); // penalidade de page-cross em emulacao
    goto L_00CF0A;
L_00CEF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEF0 BPL -> $00CEF5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00CEF5; }
    goto L_00CEF2;
L_00CEF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF2u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEF2 EOR
    cpu.logicXor(0xFFu);
    goto L_00CEF4;
L_00CEF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF4u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEF4 INC
    cpu.inc('A');
    goto L_00CEF5;
L_00CEF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEF5 LSR
    cpu.lsrA();
    goto L_00CEF6;
L_00CEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEF6 LSR
    cpu.lsrA();
    goto L_00CEF7;
L_00CEF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEF7 LSR
    cpu.lsrA();
    goto L_00CEF8;
L_00CEF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF8u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEF8 TAY
    cpu.transfer("TAY");
    goto L_00CEF9;
L_00CEF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF9u, 4u + ((((0xDC7Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDC7Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEF9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDC7Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CEFC;
L_00CEFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFCu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEFC TAY
    cpu.transfer("TAY");
    goto L_00CEFD;
L_00CEFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFDu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEFD INX
    cpu.inc('X');
    goto L_00CEFE;
L_00CEFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFEu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CEFE CPX
    cpu.compareX(0x3u);
    goto L_00CF00;
L_00CF00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF00u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF00 BCS -> $00CF04
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00CF04; }
    goto L_00CF02;
L_00CF02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF02u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF02 LDX
    cpu.setX(0x5u, 8);
    goto L_00CF04;
L_00CF04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF04u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF04 CPX
    cpu.compareX(0x7u);
    goto L_00CF06;
L_00CF06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF06u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF06 BCC -> $00CF0A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00CF0A; }
    goto L_00CF08;
L_00CF08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF08u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF08 LDX
    cpu.setX(0x3u, 8);
    goto L_00CF0A;
L_00CF0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Au,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Au, 4u, 3u, cpu.address("abs", 0x13DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF0A STX
    hw.write(cpu.address("abs", 0x13DFu), cpu.x, cpu.x8?8:16);
    goto L_00CF0D;
L_00CF0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF0D TYA
    cpu.transfer("TYA");
    goto L_00CF0E;
L_00CF0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF0E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x75u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF10;
L_00CF10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF10u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF10u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF10 BEQ -> $00CF13
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF13; }
    goto L_00CF12;
L_00CF12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF12u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF12 ASL
    cpu.aslA();
    goto L_00CF13;
L_00CF13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF13u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF13u, 4u, 3u, cpu.address("abs", 0x14A2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF13 STA
    hw.write(cpu.address("abs", 0x14A2u), cpu.a, cpu.m8?8:16);
    goto L_00CF16;
L_00CF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF16u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF16u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF16 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x140Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF19;
L_00CF19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF19u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF19u, 4u, 3u, cpu.address("abs", 0x14A6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF19 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x14A6u), cpu.m8?8:16));
    goto L_00CF1C;
L_00CF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF1C BEQ -> $00CF4E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF4E; }
    goto L_00CF1E;
L_00CF1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF1E STZ
    hw.write(cpu.address("dp", 0x73u), 0, cpu.m8?8:16);
    goto L_00CF20;
L_00CF20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF20u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF20u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF20 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF22;
L_00CF22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF22u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF22 AND
    cpu.logicAnd(0x6u);
    goto L_00CF24;
L_00CF24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF24u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF24 TAX
    cpu.transfer("TAX");
    goto L_00CF25;
L_00CF25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF25u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF25 TAY
    cpu.transfer("TAY");
    goto L_00CF26;
L_00CF26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF26u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF26u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF26 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF28;
L_00CF28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF28u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF28 BEQ -> $00CF2F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF2F; }
    goto L_00CF2A;
L_00CF2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF2A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF2C;
L_00CF2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF2C BMI -> $00CF2F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00CF2F; }
    goto L_00CF2E;
L_00CF2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF2E INY
    cpu.inc('Y');
    goto L_00CF2F;
L_00CF2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Fu, 4u + ((((0xCEA9u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCEA9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF2F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCEA9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF32;
L_00CF32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF32u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF32u, 4u, 3u, cpu.address("abs", 0x13DFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF32 STA
    hw.write(cpu.address("abs", 0x13DFu), cpu.a, cpu.m8?8:16);
    goto L_00CF35;
L_00CF35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF35u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF35u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF35 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF37;
L_00CF37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF37u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF37 BEQ -> $00CF3A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF3A; }
    goto L_00CF39;
L_00CF39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF39u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF39u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF39 INX
    cpu.inc('X');
    goto L_00CF3A;
L_00CF3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Au, 4u + ((((0xCEA1u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xCEA1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF3A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xCEA1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF3D;
L_00CF3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF3D STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_00CF3F;
L_00CF3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF3F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF41;
L_00CF41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF41u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF41 CPY
    cpu.compareY(0x2u);
    goto L_00CF43;
L_00CF43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF43u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF43 BNE -> $00CF48
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF48; }
    goto L_00CF45;
L_00CF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF45u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF45u, 6u, 3u, cpu.address("abs", 0xD044u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00CF45 JSR -> $00D044 stack real
    { cpu.push16Value(hw,0xCF47u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF48u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD044u), 0x00CF45u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00CF48;
L_00CF48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF48u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF48u,0x00CF48u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF48u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF48u, 4u + ((((0xCE99u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xCE99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF48 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xCE99u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF4B;
L_00CF4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Bu, 3u, 3u, cpu.address("abs", 0xD01Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF4B JMP -> $00D01A
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xD01Au),0x00CF4Bu); return;
L_00CF4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Eu, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF4E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13EDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF51;
L_00CF51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF51u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF51u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF51 BEQ -> $00CF62
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF62; }
    goto L_00CF53;
L_00CF53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF53u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF53 BPL -> $00CF85
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00CF85; }
    goto L_00CF55;
L_00CF55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF55u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF55u, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF55 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13E1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF58;
L_00CF58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF58u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF58u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF58 LSR
    cpu.lsrA();
    goto L_00CF59;
L_00CF59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF59u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF59u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF59 LSR
    cpu.lsrA();
    goto L_00CF5A;
L_00CF5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Au,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF5A ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16));
    goto L_00CF5C;
L_00CF5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF5C TAY
    cpu.transfer("TAY");
    goto L_00CF5D;
L_00CF5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Du, 4u + ((((0xCE7Fu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCE7Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF5D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCE7Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF60;
L_00CF60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF60u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF60u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF60 BRA -> $00CF85
    goto L_00CF85;
L_00CF62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF62u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF62 LDA
    cpu.setA(0x3Cu, 8);
    goto L_00CF64;
L_00CF64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF64u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF64u, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF64 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x148Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF67;
L_00CF67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF67u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF67 BEQ -> $00CF6B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF6B; }
    goto L_00CF69;
L_00CF69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF69u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF69u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF69 LDA
    cpu.setA(0x1Du, 8);
    goto L_00CF6B;
L_00CF6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF6B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x73u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF6D;
L_00CF6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF6D BNE -> $00CF85
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF85; }
    goto L_00CF6F;
L_00CF6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Fu, 4u, 3u, cpu.address("abs", 0x149Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF6F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x149Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF72;
L_00CF72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF72u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF72 BEQ -> $00CF7E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF7E; }
    goto L_00CF74;
L_00CF74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF74u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF74 LDA
    cpu.setA(0x3Fu, 8);
    goto L_00CF76;
L_00CF76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF76u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF76u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF76 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x72u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF78;
L_00CF78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF78u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF78 BEQ -> $00CF85
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF85; }
    goto L_00CF7A;
L_00CF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF7A LDA
    cpu.setA(0x16u, 8);
    goto L_00CF7C;
L_00CF7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF7C BRA -> $00CF85
    goto L_00CF85;
L_00CF7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF7E LDA
    cpu.setA(0xEu, 8);
    goto L_00CF80;
L_00CF80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF80u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF80u, 4u, 3u, cpu.address("abs", 0x149Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF80 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x149Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF83;
L_00CF83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF83u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF83 BEQ -> $00CF88
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF88; }
    goto L_00CF85;
L_00CF85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF85u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF85u, 3u, 3u, cpu.address("abs", 0xD01Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF85 JMP -> $00D01A
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xD01Au),0x00CF85u); return;
L_00CF88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF88u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF88 LDA
    cpu.setA(0x1Du, 8);
    goto L_00CF8A;
L_00CF8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Au,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Au, 4u, 3u, cpu.address("abs", 0x1498u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF8A LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1498u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF8D;
L_00CF8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF8D BNE -> $00CF85
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF85; }
    goto L_00CF8F;
L_00CF8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF8F LDA
    cpu.setA(0xFu, 8);
    goto L_00CF91;
L_00CF91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF91u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF91u, 4u, 3u, cpu.address("abs", 0x1499u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF91 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1499u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF94;
L_00CF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF94u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF94 BNE -> $00CF85
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CF85; }
    goto L_00CF96;
L_00CF96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF96u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF96 LDA
    cpu.setA(0x0u, 8);
    goto L_00CF98;
L_00CF98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF98u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF98u, 4u, 3u, cpu.address("abs", 0x18C2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF98 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x18C2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CF9B;
L_00CF9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF9B BNE -> $00CFC3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CFC3; }
    goto L_00CF9D;
L_00CF9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF9D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CF9F;
L_00CF9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CF9F BEQ -> $00CFB7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CFB7; }
    goto L_00CFA1;
L_00CFA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA1u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA1u, 4u, 3u, cpu.address("abs", 0x14A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFA1 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x14A0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CFA4;
L_00CFA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFA4 BNE -> $00CFBC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CFBC; }
    goto L_00CFA6;
L_00CFA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA6u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA6u, 4u, 3u, cpu.address("abs", 0x1407u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFA6 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1407u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CFA9;
L_00CFA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFA9 BEQ -> $00CFAE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CFAE; }
    goto L_00CFAB;
L_00CFAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFABu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFABu, 4u + ((((0xCE78u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xCE78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFAB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xCE78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFAE;
L_00CFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFAEu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFAEu, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFAE LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x148Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CFB1;
L_00CFB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFB1 BEQ -> $00D01A
    if (cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00D01Au,0x00CFB1u); return; }
    goto L_00CFB3;
L_00CFB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFB3 LDA
    cpu.setA(0x9u, 8);
    goto L_00CFB5;
L_00CFB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFB5 BRA -> $00D01A
    hw.addCpuInternalCycles(1u); // penalidade de page-cross em emulacao
    hw.requestDispatch(0x00D01Au,0x00CFB5u); return;
L_00CFB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB7u, 4u, 3u, cpu.address("abs", 0x13DDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFB7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13DDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFBA;
L_00CFBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFBA BNE -> $00D01A
    if (!cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00D01Au,0x00CFBAu); return; }
    goto L_00CFBC;
L_00CFBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFBC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFBE;
L_00CFBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFBE BPL -> $00CFC3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00CFC3; }
    goto L_00CFC0;
L_00CFC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC0u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFC0 EOR
    cpu.logicXor(0xFFu);
    goto L_00CFC2;
L_00CFC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC2u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFC2 INC
    cpu.inc('A');
    goto L_00CFC3;
L_00CFC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFC3 TAX
    cpu.transfer("TAX");
    goto L_00CFC4;
L_00CFC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFC4 BNE -> $00CFD4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CFD4; }
    goto L_00CFC6;
L_00CFC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC6u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFC6 XBA
    cpu.xba();
    goto L_00CFC7;
L_00CFC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFC7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFC9;
L_00CFC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFC9 AND
    cpu.logicAnd(0x8u);
    goto L_00CFCB;
L_00CFCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFCB BEQ -> $00D002
    if (cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00D002u,0x00CFCBu); return; }
    goto L_00CFCD;
L_00CFCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFCD LDA
    cpu.setA(0x3u, 8);
    goto L_00CFCF;
L_00CFCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCFu, 4u, 3u, cpu.address("abs", 0x13DEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFCF STA
    hw.write(cpu.address("abs", 0x13DEu), cpu.a, cpu.m8?8:16);
    goto L_00CFD2;
L_00CFD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFD2 BRA -> $00D002
    hw.addCpuInternalCycles(1u); // penalidade de page-cross em emulacao
    hw.requestDispatch(0x00D002u,0x00CFD2u); return;
L_00CFD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFD4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x86u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFD6;
L_00CFD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFD6 BEQ -> $00CFE3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00CFE3; }
    goto L_00CFD8;
L_00CFD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFD8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFDA;
L_00CFDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFDA AND
    cpu.logicAnd(0x3u);
    goto L_00CFDC;
L_00CFDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFDC BEQ -> $00D003
    if (cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00D003u,0x00CFDCu); return; }
    goto L_00CFDE;
L_00CFDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFDE LDA
    cpu.setA(0x68u, 8);
    goto L_00CFE0;
L_00CFE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE0u, 4u, 3u, cpu.address("abs", 0x13E5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFE0 STA
    hw.write(cpu.address("abs", 0x13E5u), cpu.a, cpu.m8?8:16);
    goto L_00CFE3;
L_00CFE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE3u, 4u, 3u, cpu.address("abs", 0x13DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFE3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13DBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFE6;
L_00CFE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE6u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE6u, 4u, 3u, cpu.address("abs", 0x1496u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFE6 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1496u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CFE9;
L_00CFE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFE9 BNE -> $00D003
    if (!cpu.z) { hw.addCpuInternalCycles(2u); hw.requestDispatch(0x00D003u,0x00CFE9u); return; }
    goto L_00CFEB;
L_00CFEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEBu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFEB DEC
    cpu.decReg('A');
    goto L_00CFEC;
L_00CFEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFECu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFEC BPL -> $00CFF3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00CFF3; }
    goto L_00CFEE;
L_00CFEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEEu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFEE LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x19u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00CFF0;
L_00CFF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF0u, 4u + ((((0xDC78u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDC78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFF0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDC78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00CFF3;
L_00CFF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF3u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFF3 XBA
    cpu.xba();
    goto L_00CFF4;
L_00CFF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFF4 TXA
    cpu.transfer("TXA");
    goto L_00CFF5;
L_00CFF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFF5 LSR
    cpu.lsrA();
    goto L_00CFF6;
L_00CFF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00CFF6 LSR
    cpu.lsrA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCFF7u,0x00CFF6u); return;
}

void sub_00D5F2_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00D5F2u: goto L_00D5F2;
    case 0x00D5F4u: goto L_00D5F4;
    case 0x00D5F6u: goto L_00D5F6;
    case 0x00D5F9u: goto L_00D5F9;
    case 0x00D5FBu: goto L_00D5FB;
    case 0x00D5FEu: goto L_00D5FE;
    case 0x00D600u: goto L_00D600;
    case 0x00D602u: goto L_00D602;
    case 0x00D604u: goto L_00D604;
    case 0x00D606u: goto L_00D606;
    case 0x00D608u: goto L_00D608;
    case 0x00D60Bu: goto L_00D60B;
    case 0x00D60Eu: goto L_00D60E;
    case 0x00D610u: goto L_00D610;
    case 0x00D612u: goto L_00D612;
    case 0x00D614u: goto L_00D614;
    case 0x00D616u: goto L_00D616;
    case 0x00D618u: goto L_00D618;
    case 0x00D61Au: goto L_00D61A;
    case 0x00D61Cu: goto L_00D61C;
    case 0x00D61Eu: goto L_00D61E;
    case 0x00D620u: goto L_00D620;
    case 0x00D622u: goto L_00D622;
    case 0x00D624u: goto L_00D624;
    case 0x00D626u: goto L_00D626;
    case 0x00D628u: goto L_00D628;
    case 0x00D62Au: goto L_00D62A;
    case 0x00D62Du: goto L_00D62D;
    case 0x00D630u: goto L_00D630;
    case 0x00D632u: goto L_00D632;
    case 0x00D634u: goto L_00D634;
    case 0x00D636u: goto L_00D636;
    case 0x00D637u: goto L_00D637;
    case 0x00D638u: goto L_00D638;
    case 0x00D639u: goto L_00D639;
    case 0x00D63Bu: goto L_00D63B;
    case 0x00D63Cu: goto L_00D63C;
    case 0x00D63Eu: goto L_00D63E;
    case 0x00D640u: goto L_00D640;
    case 0x00D643u: goto L_00D643;
    case 0x00D645u: goto L_00D645;
    case 0x00D646u: goto L_00D646;
    case 0x00D649u: goto L_00D649;
    case 0x00D64Bu: goto L_00D64B;
    case 0x00D64Eu: goto L_00D64E;
    case 0x00D650u: goto L_00D650;
    case 0x00D653u: goto L_00D653;
    case 0x00D656u: goto L_00D656;
    case 0x00D659u: goto L_00D659;
    case 0x00D65Bu: goto L_00D65B;
    case 0x00D65Cu: goto L_00D65C;
    case 0x00D65Eu: goto L_00D65E;
    case 0x00D660u: goto L_00D660;
    case 0x00D663u: goto L_00D663;
    case 0x00D666u: goto L_00D666;
    case 0x00D668u: goto L_00D668;
    case 0x00D66Au: goto L_00D66A;
    case 0x00D66Du: goto L_00D66D;
    case 0x00D66Fu: goto L_00D66F;
    case 0x00D671u: goto L_00D671;
    case 0x00D674u: goto L_00D674;
    case 0x00D676u: goto L_00D676;
    case 0x00D678u: goto L_00D678;
    case 0x00D67Bu: goto L_00D67B;
    case 0x00D67Du: goto L_00D67D;
    case 0x00D67Fu: goto L_00D67F;
    case 0x00D682u: goto L_00D682;
    case 0x00D685u: goto L_00D685;
    case 0x00D687u: goto L_00D687;
    case 0x00D689u: goto L_00D689;
    case 0x00D68Bu: goto L_00D68B;
    case 0x00D68Du: goto L_00D68D;
    case 0x00D690u: goto L_00D690;
    case 0x00D692u: goto L_00D692;
    case 0x00D695u: goto L_00D695;
    case 0x00D698u: goto L_00D698;
    case 0x00D69Au: goto L_00D69A;
    case 0x00D69Du: goto L_00D69D;
    case 0x00D6A0u: goto L_00D6A0;
    case 0x00D6A1u: goto L_00D6A1;
    case 0x00D6A2u: goto L_00D6A2;
    case 0x00D6A3u: goto L_00D6A3;
    case 0x00D6A5u: goto L_00D6A5;
    case 0x00D6A6u: goto L_00D6A6;
    case 0x00D6A7u: goto L_00D6A7;
    case 0x00D6A8u: goto L_00D6A8;
    case 0x00D6AAu: goto L_00D6AA;
    case 0x00D6ABu: goto L_00D6AB;
    case 0x00D6AEu: goto L_00D6AE;
    case 0x00D6B1u: goto L_00D6B1;
    case 0x00D6B4u: goto L_00D6B4;
    case 0x00D6B6u: goto L_00D6B6;
    case 0x00D6B9u: goto L_00D6B9;
    case 0x00D6BBu: goto L_00D6BB;
    case 0x00D6BDu: goto L_00D6BD;
    case 0x00D6BFu: goto L_00D6BF;
    case 0x00D6C1u: goto L_00D6C1;
    case 0x00D6C3u: goto L_00D6C3;
    case 0x00D6C5u: goto L_00D6C5;
    case 0x00D6C8u: goto L_00D6C8;
    case 0x00D6CBu: goto L_00D6CB;
    case 0x00D6CDu: goto L_00D6CD;
    case 0x00D6CEu: goto L_00D6CE;
    case 0x00D6CFu: goto L_00D6CF;
    case 0x00D6D2u: goto L_00D6D2;
    case 0x00D6D3u: goto L_00D6D3;
    case 0x00D6D5u: goto L_00D6D5;
    case 0x00D6D7u: goto L_00D6D7;
    case 0x00D6D9u: goto L_00D6D9;
    case 0x00D6DBu: goto L_00D6DB;
    case 0x00D6DEu: goto L_00D6DE;
    case 0x00D6E0u: goto L_00D6E0;
    case 0x00D6E3u: goto L_00D6E3;
    case 0x00D6E5u: goto L_00D6E5;
    case 0x00D6E7u: goto L_00D6E7;
    case 0x00D6EAu: goto L_00D6EA;
    case 0x00D6ECu: goto L_00D6EC;
    case 0x00D6EEu: goto L_00D6EE;
    case 0x00D6EFu: goto L_00D6EF;
    case 0x00D6F0u: goto L_00D6F0;
    case 0x00D6F3u: goto L_00D6F3;
    case 0x00D6F4u: goto L_00D6F4;
    case 0x00D6F6u: goto L_00D6F6;
    case 0x00D6F8u: goto L_00D6F8;
    case 0x00D6FBu: goto L_00D6FB;
    case 0x00D6FDu: goto L_00D6FD;
    case 0x00D700u: goto L_00D700;
    case 0x00D702u: goto L_00D702;
    case 0x00D704u: goto L_00D704;
    case 0x00D706u: goto L_00D706;
    case 0x00D708u: goto L_00D708;
    case 0x00D70Bu: goto L_00D70B;
    case 0x00D70Eu: goto L_00D70E;
    case 0x00D70Fu: goto L_00D70F;
    case 0x00D710u: goto L_00D710;
    case 0x00D712u: goto L_00D712;
    case 0x00D713u: goto L_00D713;
    case 0x00D715u: goto L_00D715;
    case 0x00D717u: goto L_00D717;
    case 0x00D719u: goto L_00D719;
    case 0x00D71Au: goto L_00D71A;
    case 0x00D71Bu: goto L_00D71B;
    case 0x00D71Cu: goto L_00D71C;
    case 0x00D71Eu: goto L_00D71E;
    case 0x00D720u: goto L_00D720;
    case 0x00D722u: goto L_00D722;
    case 0x00D723u: goto L_00D723;
    case 0x00D725u: goto L_00D725;
    case 0x00D727u: goto L_00D727;
    case 0x00D729u: goto L_00D729;
    case 0x00D72Bu: goto L_00D72B;
    case 0x00D72Du: goto L_00D72D;
    case 0x00D730u: goto L_00D730;
    case 0x00D732u: goto L_00D732;
    case 0x00D734u: goto L_00D734;
    case 0x00D736u: goto L_00D736;
    case 0x00D737u: goto L_00D737;
    case 0x00D73Au: goto L_00D73A;
    case 0x00D73Bu: goto L_00D73B;
    case 0x00D73Cu: goto L_00D73C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00D5F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D5F2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D5F4;
L_00D5F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D5F4 BEQ -> $00D5F9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D5F9; }
    goto L_00D5F6;
L_00D5F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F6u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F6u, 3u, 3u, cpu.address("abs", 0xD682u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D5F6 JMP -> $00D682
    goto L_00D682;
L_00D5F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F9u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D5F9 STZ
    hw.write(cpu.address("dp", 0x73u), 0, cpu.m8?8:16);
    goto L_00D5FB;
L_00D5FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5FBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5FBu, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D5FB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13EDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D5FE;
L_00D5FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5FEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D5FE BNE -> $00D60B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D60B; }
    goto L_00D600;
L_00D600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD600u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD600u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D600 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D602;
L_00D602:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD602u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD602u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD602u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D602 AND
    cpu.logicAnd(0x4u);
    goto L_00D604;
L_00D604:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD604u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD604u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD604u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D604 BEQ -> $00D60B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D60B; }
    goto L_00D606;
L_00D606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD606u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD606u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D606 STA
    hw.write(cpu.address("dp", 0x73u), cpu.a, cpu.m8?8:16);
    goto L_00D608;
L_00D608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD608u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD608u, 4u, 3u, cpu.address("abs", 0x13E8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D608 STZ
    hw.write(cpu.address("abs", 0x13E8u), 0, cpu.m8?8:16);
    goto L_00D60B;
L_00D60B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD60Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD60Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD60Bu, 4u, 3u, cpu.address("abs", 0x1471u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D60B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1471u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D60E;
L_00D60E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD60Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD60Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD60Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D60E CMP
    cpu.compareA(0x2u);
    goto L_00D610;
L_00D610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD610u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD610u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D610 BEQ -> $00D61E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D61E; }
    goto L_00D612;
L_00D612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD612u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD612u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D612 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D614;
L_00D614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD614u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD614u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D614 AND
    cpu.logicAnd(0x8u);
    goto L_00D616;
L_00D616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD616u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD616u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D616 BNE -> $00D61E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D61E; }
    goto L_00D618;
L_00D618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD618u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD618u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D618 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D61A;
L_00D61A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD61Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD61Au,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD61Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D61A ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16));
    goto L_00D61C;
L_00D61C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD61Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD61Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD61Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D61C BMI -> $00D630
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00D630; }
    goto L_00D61E;
L_00D61E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD61Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD61Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD61Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D61E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x73u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D620;
L_00D620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD620u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD620u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D620 BEQ -> $00D682
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D682; }
    goto L_00D622;
L_00D622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD622u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD622u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D622 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D624;
L_00D624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD624u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD624u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D624 BEQ -> $00D62D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D62D; }
    goto L_00D626;
L_00D626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD626u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD626u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD626u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D626 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x86u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D628;
L_00D628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD628u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD628u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD628u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D628 BNE -> $00D62D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D62D; }
    goto L_00D62A;
L_00D62A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD62Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD62Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD62Au, 6u, 3u, cpu.address("abs", 0xFE4Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00D62A JSR -> $00FE4A stack real
    { cpu.push16Value(hw,0xD62Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD62Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFE4Au), 0x00D62Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00D62D;
L_00D62D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD62Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD62Du,0x00D62Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD62Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD62Du, 3u, 3u, cpu.address("abs", 0xD764u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D62D JMP -> $00D764
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xD764u),0x00D62Du); return;
L_00D630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD630u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD630u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D630 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D632;
L_00D632:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD632u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD632u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD632u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D632 BPL -> $00D637
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00D637; }
    goto L_00D634;
L_00D634:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD634u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD634u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD634u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D634 EOR
    cpu.logicXor(0xFFu);
    goto L_00D636;
L_00D636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD636u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD636u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D636 INC
    cpu.inc('A');
    goto L_00D637;
L_00D637:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD637u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD637u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD637u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D637 LSR
    cpu.lsrA();
    goto L_00D638;
L_00D638:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD638u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD638u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD638u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D638 LSR
    cpu.lsrA();
    goto L_00D639;
L_00D639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD639u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD639u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D639 AND
    cpu.logicAnd(0xFEu);
    goto L_00D63B;
L_00D63B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD63Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD63Bu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD63Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D63B TAX
    cpu.transfer("TAX");
    goto L_00D63C;
L_00D63C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD63Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD63Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD63Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D63C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D63E;
L_00D63E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD63Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD63Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD63Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D63E BPL -> $00D65E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00D65E; }
    goto L_00D640;
L_00D640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD640u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD640u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD640u, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D640 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D643;
L_00D643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD643u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD643u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD643u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D643 BNE -> $00D65E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D65E; }
    goto L_00D645;
L_00D645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD645u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD645u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D645 INC
    cpu.inc('A');
    goto L_00D646;
L_00D646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD646u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD646u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD646u, 4u, 3u, cpu.address("abs", 0x140Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D646 STA
    hw.write(cpu.address("abs", 0x140Du), cpu.a, cpu.m8?8:16);
    goto L_00D649;
L_00D649:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD649u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD649u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD649u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D649 LDA
    cpu.setA(0x4u, 8);
    goto L_00D64B;
L_00D64B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD64Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD64Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD64Bu, 4u, 3u, cpu.address("abs", 0x1DFCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D64B STA
    hw.write(cpu.address("abs", 0x1DFCu), cpu.a, cpu.m8?8:16);
    goto L_00D64E;
L_00D64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD64Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD64Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D64E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x76u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00D650;
L_00D650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD650u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD650u, 4u + ((((0xD5F0u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD5F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D650 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD5F0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D653;
L_00D653:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD653u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD653u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD653u, 4u, 3u, cpu.address("abs", 0x13E2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D653 STA
    hw.write(cpu.address("abs", 0x13E2u), cpu.a, cpu.m8?8:16);
    goto L_00D656;
L_00D656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD656u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD656u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD656u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D656 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x187Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D659;
L_00D659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD659u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD659u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D659 BNE -> $00D682
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D682; }
    goto L_00D65B;
L_00D65B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD65Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D65B INX
    cpu.inc('X');
    goto L_00D65C;
L_00D65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD65Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D65C BRA -> $00D663
    goto L_00D663;
L_00D65E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD65Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D65E LDA
    cpu.setA(0x1u, 8);
    goto L_00D660;
L_00D660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD660u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD660u, 4u, 3u, cpu.address("abs", 0x1DFAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D660 STA
    hw.write(cpu.address("abs", 0x1DFAu), cpu.a, cpu.m8?8:16);
    goto L_00D663;
L_00D663:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD663u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD663u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD663u, 4u + ((((0xD2BDu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xD2BDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D663 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xD2BDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D666;
L_00D666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD666u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD666u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D666 STA
    hw.write(cpu.address("dp", 0x7Du), cpu.a, cpu.m8?8:16);
    goto L_00D668;
L_00D668:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD668u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD668u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD668u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D668 LDA
    cpu.setA(0xBu, 8);
    goto L_00D66A;
L_00D66A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD66Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD66Au,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD66Au, 4u, 3u, cpu.address("abs", 0x13E4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D66A LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x13E4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00D66D;
L_00D66D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD66Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD66Du,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD66Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D66D CPY
    cpu.compareY(0x70u);
    goto L_00D66F;
L_00D66F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD66Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD66Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD66Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D66F BCC -> $00D67D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00D67D; }
    goto L_00D671;
L_00D671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD671u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD671u, 4u, 3u, cpu.address("abs", 0x149Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D671 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x149Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D674;
L_00D674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD674u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD674u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD674u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D674 BNE -> $00D67B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D67B; }
    goto L_00D676;
L_00D676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD676u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD676u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D676 LDA
    cpu.setA(0x50u, 8);
    goto L_00D678;
L_00D678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD678u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD678u, 4u, 3u, cpu.address("abs", 0x149Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D678 STA
    hw.write(cpu.address("abs", 0x149Fu), cpu.a, cpu.m8?8:16);
    goto L_00D67B;
L_00D67B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD67Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD67Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD67Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D67B LDA
    cpu.setA(0xCu, 8);
    goto L_00D67D;
L_00D67D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD67Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD67Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD67Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D67D STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_00D67F;
L_00D67F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD67Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD67Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD67Fu, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D67F STZ
    hw.write(cpu.address("abs", 0x13EDu), 0, cpu.m8?8:16);
    goto L_00D682;
L_00D682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD682u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD682u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D682 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13EDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D685;
L_00D685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD685u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD685u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD685u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D685 BMI -> $00D692
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00D692; }
    goto L_00D687;
L_00D687:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD687u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD687u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD687u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D687 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D689;
L_00D689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD689u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD689u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D689 AND
    cpu.logicAnd(0x3u);
    goto L_00D68B;
L_00D68B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD68Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD68Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD68Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D68B BNE -> $00D6B1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D6B1; }
    goto L_00D68D;
L_00D68D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD68Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD68Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD68Du, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D68D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13EDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D690;
L_00D690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD690u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD690u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D690 BEQ -> $00D6AE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D6AE; }
    goto L_00D692;
L_00D692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD692u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD692u, 6u, 3u, cpu.address("abs", 0xFE4Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00D692 JSR -> $00FE4A stack real
    { cpu.push16Value(hw,0xD694u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD695u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFE4Au), 0x00D692u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00D695;
L_00D695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD695u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD695u,0x00D695u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD695u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD695u, 4u, 3u, cpu.address("abs", 0x13EEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D695 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13EEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D698;
L_00D698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD698u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD698u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD698u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D698 BEQ -> $00D6AE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D6AE; }
    goto L_00D69A;
L_00D69A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD69Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD69Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD69Au, 6u, 3u, cpu.address("abs", 0xD968u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00D69A JSR -> $00D968 stack real
    { cpu.push16Value(hw,0xD69Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD69Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD968u), 0x00D69Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00D69D;
L_00D69D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD69Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD69Du,0x00D69Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD69Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD69Du, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D69D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13E1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D6A0;
L_00D6A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6A0 LSR
    cpu.lsrA();
    goto L_00D6A1;
L_00D6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6A1 LSR
    cpu.lsrA();
    goto L_00D6A2;
L_00D6A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A2u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6A2 TAY
    cpu.transfer("TAY");
    goto L_00D6A3;
L_00D6A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6A3 ADC
    cpu.adc(0x76u);
    goto L_00D6A5;
L_00D6A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6A5 TAX
    cpu.transfer("TAX");
    goto L_00D6A6;
L_00D6A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A6u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6A6 TYA
    cpu.transfer("TYA");
    goto L_00D6A7;
L_00D6A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6A7 LSR
    cpu.lsrA();
    goto L_00D6A8;
L_00D6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A8u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6A8 ADC
    cpu.adc(0x87u);
    goto L_00D6AA;
L_00D6AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6AAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6AA TAY
    cpu.transfer("TAY");
    goto L_00D6AB;
L_00D6AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6ABu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6ABu, 3u, 3u, cpu.address("abs", 0xD742u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6AB JMP -> $00D742
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xD742u),0x00D6ABu); return;
L_00D6AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6AEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6AEu, 3u, 3u, cpu.address("abs", 0xD764u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6AE JMP -> $00D764
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xD764u),0x00D6AEu); return;
L_00D6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B1u, 4u, 3u, cpu.address("abs", 0x13EDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6B1 STZ
    hw.write(cpu.address("abs", 0x13EDu), 0, cpu.m8?8:16);
    goto L_00D6B4;
L_00D6B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6B4 AND
    cpu.logicAnd(0x1u);
    goto L_00D6B6;
L_00D6B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B6u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B6u, 4u, 3u, cpu.address("abs", 0x1407u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6B6 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1407u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00D6B9;
L_00D6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6B9 BEQ -> $00D6D5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D6D5; }
    goto L_00D6BB;
L_00D6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BBu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6BB CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16));
    goto L_00D6BD;
L_00D6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6BD BEQ -> $00D6C3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D6C3; }
    goto L_00D6BF;
L_00D6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BFu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6BF LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00D6C1;
L_00D6C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6C1 BPL -> $00D68D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00D68D; }
    goto L_00D6C3;
L_00D6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6C3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x76u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00D6C5;
L_00D6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C5u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C5u, 4u + ((((0xD5EEu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xD5EEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6C5 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xD5EEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00D6C8;
L_00D6C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C8u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C8u, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6C8 STY
    hw.write(cpu.address("abs", 0x13E1u), cpu.y, cpu.x8?8:16);
    goto L_00D6CB;
L_00D6CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6CB STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_00D6CD;
L_00D6CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6CD ASL
    cpu.aslA();
    goto L_00D6CE;
L_00D6CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6CE ASL
    cpu.aslA();
    goto L_00D6CF;
L_00D6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CFu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CFu, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6CF ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13E1u), cpu.m8?8:16));
    goto L_00D6D2;
L_00D6D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6D2 TAX
    cpu.transfer("TAX");
    goto L_00D6D3;
L_00D6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D3u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6D3 BRA -> $00D713
    goto L_00D713;
L_00D6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D5u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6D5 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x76u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00D6D7;
L_00D6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D7u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6D7 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x76u), cpu.m8?8:16));
    goto L_00D6D9;
L_00D6D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6D9 BEQ -> $00D6EC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D6EC; }
    goto L_00D6DB;
L_00D6DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DBu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DBu, 4u, 3u, cpu.address("abs", 0x148Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6DB LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x148Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00D6DE;
L_00D6DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6DE BEQ -> $00D6EA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D6EA; }
    goto L_00D6E0;
L_00D6E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E0u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E0u, 4u, 3u, cpu.address("abs", 0x1499u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6E0 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1499u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00D6E3;
L_00D6E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6E3 BNE -> $00D6EC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D6EC; }
    goto L_00D6E5;
L_00D6E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6E5 LDY
    cpu.setY(0x8u, 8);
    goto L_00D6E7;
L_00D6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E7u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E7u, 4u, 3u, cpu.address("abs", 0x1499u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6E7 STY
    hw.write(cpu.address("abs", 0x1499u), cpu.y, cpu.x8?8:16);
    goto L_00D6EA;
L_00D6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6EA STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_00D6EC;
L_00D6EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6ECu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6ECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6EC STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_00D6EE;
L_00D6EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6EE ASL
    cpu.aslA();
    goto L_00D6EF;
L_00D6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6EF ASL
    cpu.aslA();
    goto L_00D6F0;
L_00D6F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F0u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F0u, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6F0 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13E1u), cpu.m8?8:16));
    goto L_00D6F3;
L_00D6F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6F3 TAX
    cpu.transfer("TAX");
    goto L_00D6F4;
L_00D6F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6F4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D6F6;
L_00D6F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6F6 BEQ -> $00D713
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D713; }
    goto L_00D6F8;
L_00D6F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F8u,cpu,0x5Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F8u, 4u + ((((0xD346u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xD346u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6F8 EOR
    cpu.logicXor(hw.readW(cpu.address("absx", 0xD346u), cpu.m8?8:16));
    goto L_00D6FB;
L_00D6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FBu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6FB BPL -> $00D713
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00D713; }
    goto L_00D6FD;
L_00D6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FDu, 4u, 3u, cpu.address("abs", 0x14A1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D6FD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14A1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D700;
L_00D700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD700u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD700u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D700 BNE -> $00D713
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D713; }
    goto L_00D702;
L_00D702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD702u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD702u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D702 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x86u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D704;
L_00D704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD704u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD704u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D704 BNE -> $00D70E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D70E; }
    goto L_00D706;
L_00D706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD706u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD706u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD706u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D706 LDA
    cpu.setA(0xDu, 8);
    goto L_00D708;
L_00D708:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD708u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD708u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD708u, 4u, 3u, cpu.address("abs", 0x13DDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D708 STA
    hw.write(cpu.address("abs", 0x13DDu), cpu.a, cpu.m8?8:16);
    goto L_00D70B;
L_00D70B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Bu, 6u, 3u, cpu.address("abs", 0xFE4Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00D70B JSR -> $00FE4A stack real
    { cpu.push16Value(hw,0xD70Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD70Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFE4Au), 0x00D70Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00D70E;
L_00D70E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD70Eu,0x00D70Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D70E TXA
    cpu.transfer("TXA");
    goto L_00D70F;
L_00D70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D70F CLC
    cpu.setFlag('C', false);
    goto L_00D710;
L_00D710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD710u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD710u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D710 ADC
    cpu.adc(0x90u);
    goto L_00D712;
L_00D712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD712u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD712u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D712 TAX
    cpu.transfer("TAX");
    goto L_00D713;
L_00D713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD713u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD713u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D713 LDY
    cpu.setY(0x0u, 8);
    goto L_00D715;
L_00D715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD715u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD715u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D715 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), false);
    goto L_00D717;
L_00D717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD717u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD717u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D717 BVC -> $00D737
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_00D737; }
    goto L_00D719;
L_00D719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD719u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD719u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D719 INX
    cpu.inc('X');
    goto L_00D71A;
L_00D71A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Au,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D71A INX
    cpu.inc('X');
    goto L_00D71B;
L_00D71B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D71B INY
    cpu.inc('Y');
    goto L_00D71C;
L_00D71C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D71C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D71E;
L_00D71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D71E BPL -> $00D723
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00D723; }
    goto L_00D720;
L_00D720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD720u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD720u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D720 EOR
    cpu.logicXor(0xFFu);
    goto L_00D722;
L_00D722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD722u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD722u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D722 INC
    cpu.inc('A');
    goto L_00D723;
L_00D723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD723u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD723u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D723 CMP
    cpu.compareA(0x23u);
    goto L_00D725;
L_00D725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD725u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD725u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D725 BMI -> $00D737
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00D737; }
    goto L_00D727;
L_00D727:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD727u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD727u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD727u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D727 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x72u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00D729;
L_00D729:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD729u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD729u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD729u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D729 BNE -> $00D732
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D732; }
    goto L_00D72B;
L_00D72B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD72Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D72B LDA
    cpu.setA(0x10u, 8);
    goto L_00D72D;
L_00D72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Du, 4u, 3u, cpu.address("abs", 0x14A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D72D STA
    hw.write(cpu.address("abs", 0x14A0u), cpu.a, cpu.m8?8:16);
    goto L_00D730;
L_00D730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD730u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD730u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D730 BRA -> $00D736
    goto L_00D736;
L_00D732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD732u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD732u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D732 CMP
    cpu.compareA(0xCu);
    goto L_00D734;
L_00D734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD734u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD734u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D734 BNE -> $00D737
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00D737; }
    goto L_00D736;
L_00D736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD736u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD736u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D736 INY
    cpu.inc('Y');
    goto L_00D737;
L_00D737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD737u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD737u, 6u, 3u, cpu.address("abs", 0xD96Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00D737 JSR -> $00D96A stack real
    { cpu.push16Value(hw,0xD739u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD73Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD96Au), 0x00D737u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00D73A;
L_00D73A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD73Au,0x00D73Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Au,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D73A TYA
    cpu.transfer("TYA");
    goto L_00D73B;
L_00D73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D73B ASL
    cpu.aslA();
    goto L_00D73C;
L_00D73C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Cu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Cu, 4u, 3u, cpu.address("abs", 0x13E1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00D73C ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13E1u), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD73Fu,0x00D73Cu); return;
}

void sub_00E45D_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00E45Du: goto L_00E45D;
    case 0x00E45Fu: goto L_00E45F;
    case 0x00E461u: goto L_00E461;
    case 0x00E463u: goto L_00E463;
    case 0x00E466u: goto L_00E466;
    case 0x00E468u: goto L_00E468;
    case 0x00E46Bu: goto L_00E46B;
    case 0x00E46Du: goto L_00E46D;
    case 0x00E46Fu: goto L_00E46F;
    case 0x00E471u: goto L_00E471;
    case 0x00E472u: goto L_00E472;
    case 0x00E475u: goto L_00E475;
    case 0x00E476u: goto L_00E476;
    case 0x00E477u: goto L_00E477;
    case 0x00E47Au: goto L_00E47A;
    case 0x00E47Du: goto L_00E47D;
    case 0x00E47Eu: goto L_00E47E;
    case 0x00E480u: goto L_00E480;
    case 0x00E482u: goto L_00E482;
    case 0x00E485u: goto L_00E485;
    case 0x00E487u: goto L_00E487;
    case 0x00E489u: goto L_00E489;
    case 0x00E48Au: goto L_00E48A;
    case 0x00E48Du: goto L_00E48D;
    case 0x00E48Eu: goto L_00E48E;
    case 0x00E48Fu: goto L_00E48F;
    case 0x00E492u: goto L_00E492;
    case 0x00E495u: goto L_00E495;
    case 0x00E496u: goto L_00E496;
    case 0x00E498u: goto L_00E498;
    case 0x00E49Au: goto L_00E49A;
    case 0x00E49Du: goto L_00E49D;
    case 0x00E49Eu: goto L_00E49E;
    case 0x00E49Fu: goto L_00E49F;
    case 0x00E4A0u: goto L_00E4A0;
    case 0x00E4A1u: goto L_00E4A1;
    case 0x00E4A2u: goto L_00E4A2;
    case 0x00E4A3u: goto L_00E4A3;
    case 0x00E4A4u: goto L_00E4A4;
    case 0x00E4A6u: goto L_00E4A6;
    case 0x00E4A7u: goto L_00E4A7;
    case 0x00E4A8u: goto L_00E4A8;
    case 0x00E4A9u: goto L_00E4A9;
    case 0x00E4ABu: goto L_00E4AB;
    case 0x00E4AEu: goto L_00E4AE;
    case 0x00E4AFu: goto L_00E4AF;
    case 0x00E4B0u: goto L_00E4B0;
    case 0x00E4B1u: goto L_00E4B1;
    case 0x00E4B2u: goto L_00E4B2;
    case 0x00E4B4u: goto L_00E4B4;
    case 0x00E4B6u: goto L_00E4B6;
    case 0x00E4B8u: goto L_00E4B8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00E45D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Du,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E45D LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x78u), cpu.m8?8:16);
    goto L_00E45F;
L_00E45F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E45F BCS -> $00E49F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00E49F; }
    goto L_00E461;
L_00E461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE461u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE461u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E461 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00E463;
L_00E463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE463u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE463u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE463u, 4u + ((((0xDFDAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDFDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E463 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDFDAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E466;
L_00E466:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE466u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE466u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE466u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E466 BMI -> $00E49F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E49F; }
    goto L_00E468;
L_00E468:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE468u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE468u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE468u, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E468 STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_00E46B;
L_00E46B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E46B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00E46D;
L_00E46D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E46D REP
    cpu.rep(0x20u);
    goto L_00E46F;
L_00E46F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E46F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E471;
L_00E471:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE471u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE471u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE471u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E471 CLC
    cpu.setFlag('C', false);
    goto L_00E472;
L_00E472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE472u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE472u, 5u + ((((0xDE32u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDE32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E472 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xDE32u), cpu.m8?8:16));
    goto L_00E475;
L_00E475:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE475u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE475u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE475u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E475 PHA
    cpu.push("PHA", hw);
    goto L_00E476;
L_00E476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE476u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE476u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E476 CLC
    cpu.setFlag('C', false);
    goto L_00E477;
L_00E477:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE477u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE477u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE477u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E477 ADC
    cpu.adc(0x10u);
    goto L_00E47A;
L_00E47A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE47Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E47A CMP
    cpu.compareA(0x100u);
    goto L_00E47D;
L_00E47D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE47Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Du,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Du, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E47D PLA
    cpu.pop("PLA", hw);
    goto L_00E47E;
L_00E47E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE47Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E47E SEP
    cpu.sep(0x20u);
    goto L_00E480;
L_00E480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE480u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE480u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E480 BCS -> $00E49F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00E49F; }
    goto L_00E482;
L_00E482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE482u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE482u, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E482 STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_00E485;
L_00E485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE485u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE485u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E485 REP
    cpu.rep(0x20u);
    goto L_00E487;
L_00E487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE487u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE487u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E487 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E489;
L_00E489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE489u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE489u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E489 CLC
    cpu.setFlag('C', false);
    goto L_00E48A;
L_00E48A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Au,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Au, 5u + ((((0xDD4Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDD4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E48A ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xDD4Eu), cpu.m8?8:16));
    goto L_00E48D;
L_00E48D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E48D PHA
    cpu.push("PHA", hw);
    goto L_00E48E;
L_00E48E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E48E CLC
    cpu.setFlag('C', false);
    goto L_00E48F;
L_00E48F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E48F ADC
    cpu.adc(0x80u);
    goto L_00E492;
L_00E492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE492u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE492u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE492u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E492 CMP
    cpu.compareA(0x200u);
    goto L_00E495;
L_00E495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE495u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE495u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E495 PLA
    cpu.pop("PLA", hw);
    goto L_00E496;
L_00E496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE496u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE496u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E496 SEP
    cpu.sep(0x20u);
    goto L_00E498;
L_00E498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE498u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE498u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E498 BCS -> $00E49F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00E49F; }
    goto L_00E49A;
L_00E49A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Au, 5u, 3u, cpu.address("absy", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E49A STA
    hw.write(cpu.address("absy", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_00E49D;
L_00E49D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Du,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E49D XBA
    cpu.xba();
    goto L_00E49E;
L_00E49E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E49E LSR
    cpu.lsrA();
    goto L_00E49F;
L_00E49F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Fu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00E49F PHP
    cpu.push("PHP", hw);
    goto L_00E4A0;
L_00E4A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A0u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4A0 TYA
    cpu.transfer("TYA");
    goto L_00E4A1;
L_00E4A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4A1 LSR
    cpu.lsrA();
    goto L_00E4A2;
L_00E4A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4A2 LSR
    cpu.lsrA();
    goto L_00E4A3;
L_00E4A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4A3 TAX
    cpu.transfer("TAX");
    goto L_00E4A4;
L_00E4A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A4u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4A4 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_00E4A6;
L_00E4A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A6u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4A6 ROL
    cpu.rolA();
    goto L_00E4A7;
L_00E4A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A7u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00E4A7 PLP
    cpu.pop("PLP", hw);
    goto L_00E4A8;
L_00E4A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A8u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE4A8u,0x00E4A8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A8u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4A8 ROL
    cpu.rolA();
    goto L_00E4A9;
L_00E4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4A9 AND
    cpu.logicAnd(0x3u);
    goto L_00E4AB;
L_00E4AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4ABu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4ABu, 5u, 3u, cpu.address("absx", 0x0460u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4AB STA
    hw.write(cpu.address("absx", 0x460u), cpu.a, cpu.m8?8:16);
    goto L_00E4AE;
L_00E4AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4AE INY
    cpu.inc('Y');
    goto L_00E4AF;
L_00E4AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4AF INY
    cpu.inc('Y');
    goto L_00E4B0;
L_00E4B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B0u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4B0 INY
    cpu.inc('Y');
    goto L_00E4B1;
L_00E4B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B1u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4B1 INY
    cpu.inc('Y');
    goto L_00E4B2;
L_00E4B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B2u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4B2 INC
    cpu.incMem(hw, cpu.address("dp", 0x5u), cpu.m8?8:16);
    goto L_00E4B4;
L_00E4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B4u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4B4 INC
    cpu.incMem(hw, cpu.address("dp", 0x5u), cpu.m8?8:16);
    goto L_00E4B6;
L_00E4B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4B6 INC
    cpu.incMem(hw, cpu.address("dp", 0x6u), cpu.m8?8:16);
    goto L_00E4B8;
L_00E4B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E4B8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00E4B8u);return;} hw.unresolvedReturn(0x00E4B8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00EADB_E0M1X1CQ_part3(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00ED89u: goto L_00ED89;
    case 0x00ED8Bu: goto L_00ED8B;
    case 0x00ED8Cu: goto L_00ED8C;
    case 0x00ED8Du: goto L_00ED8D;
    case 0x00ED8Eu: goto L_00ED8E;
    case 0x00ED8Fu: goto L_00ED8F;
    case 0x00ED91u: goto L_00ED91;
    case 0x00ED93u: goto L_00ED93;
    case 0x00ED95u: goto L_00ED95;
    case 0x00ED96u: goto L_00ED96;
    case 0x00ED97u: goto L_00ED97;
    case 0x00ED99u: goto L_00ED99;
    case 0x00ED9Au: goto L_00ED9A;
    case 0x00ED9Cu: goto L_00ED9C;
    case 0x00ED9Du: goto L_00ED9D;
    case 0x00ED9Fu: goto L_00ED9F;
    case 0x00EDA2u: goto L_00EDA2;
    case 0x00EDA3u: goto L_00EDA3;
    case 0x00EDA4u: goto L_00EDA4;
    case 0x00EDA5u: goto L_00EDA5;
    case 0x00EDA6u: goto L_00EDA6;
    case 0x00EDA8u: goto L_00EDA8;
    case 0x00EDAAu: goto L_00EDAA;
    case 0x00EDABu: goto L_00EDAB;
    case 0x00EDADu: goto L_00EDAD;
    case 0x00EDAEu: goto L_00EDAE;
    case 0x00EDB0u: goto L_00EDB0;
    case 0x00EDB1u: goto L_00EDB1;
    case 0x00EDB4u: goto L_00EDB4;
    case 0x00EDB6u: goto L_00EDB6;
    case 0x00EDB9u: goto L_00EDB9;
    case 0x00EDBBu: goto L_00EDBB;
    case 0x00EDBCu: goto L_00EDBC;
    case 0x00EDBDu: goto L_00EDBD;
    case 0x00EDC0u: goto L_00EDC0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00ED89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED89u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED89u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED89u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED89 CMP
    cpu.compareA(0xF003u);
    goto L_00ED8C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED89u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED89 CMP
    cpu.compareA(0x3u);
    goto L_00ED8B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED89u,0x00ED89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED8B BEQ -> $00ED91
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00ED91; }
    goto L_00ED8D;
L_00ED8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Cu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Cu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED8C TSB
    cpu.tsb(hw, cpu.address("dp", 0xC9u), cpu.m8?8:16);
    goto L_00ED8E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED8Cu,0x00ED8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED8D CMP
    cpu.compareA(0xEu);
    goto L_00ED8F;
L_00ED8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Eu))return;
  // 4 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Eu,cpu,0x0Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Eu, 8u, 3u, cpu.address("abs", 0x04D0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED8E ASL
    cpu.aslMem(hw, cpu.address("abs", 0x4D0u), cpu.m8?8:16);
    goto L_00ED91;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED8Eu,0x00ED8Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED8F BNE -> $00ED95
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00ED95; }
    goto L_00ED91;
L_00ED91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED91u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED91u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED91 CPY
    cpu.compareY(0xD2u);
    goto L_00ED93;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED91u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED91 CPY
    cpu.compareY(0xD2u);
    goto L_00ED93;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED91u,0x00ED91u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED93u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED93u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED93 BCS -> $00EDE9
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED93u); return; }
    goto L_00ED95;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED93u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED93 BCS -> $00EDE9
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00ED93u); return; }
    goto L_00ED95;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED93u,0x00ED93u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED95u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED95u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED95 TYA
    cpu.transfer("TYA");
    goto L_00ED96;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED95u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED95 TYA
    cpu.transfer("TYA");
    goto L_00ED96;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED95u,0x00ED95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED96u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED96u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED96 SEC
    cpu.setFlag('C', true);
    goto L_00ED97;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED96u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED96 SEC
    cpu.setFlag('C', true);
    goto L_00ED97;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED96u,0x00ED96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED97u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED97u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED97u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED97 SBC
    cpu.sbc(0xA86Eu);
    goto L_00ED9A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED97u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED97 SBC
    cpu.sbc(0x6Eu);
    goto L_00ED99;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED97u,0x00ED97u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED99u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED99u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED99 TAY
    cpu.transfer("TAY");
    goto L_00ED9A;
L_00ED9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Au))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Au,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x82u) & 0xFFFFu), 3u, 0u);
    // $00ED9A LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED9C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Au,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x82u) & 0xFFFFu), 3u, 0u);
    // $00ED9A LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00ED9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED9Au,0x00ED9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Cu))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00ED9C PHA
    cpu.push("PHA", hw);
    goto L_00ED9D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00ED9C PHA
    cpu.push("PHA", hw);
    goto L_00ED9D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED9Cu,0x00ED9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Du))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED9D REP
    cpu.rep(0x20u);
    goto L_00ED9F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED9D REP
    cpu.rep(0x20u);
    goto L_00ED9F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED9Du,0x00ED9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00ED9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xED9Fu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xED9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00ED9F AND
    cpu.logicAnd(0xFFu);
    goto L_00EDA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xED9Fu,0x00ED9Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA2u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA2 ASL
    cpu.aslA();
    goto L_00EDA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA2u,0x00EDA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA3u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA3 ASL
    cpu.aslA();
    goto L_00EDA4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA3u,0x00EDA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA4u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA4 ASL
    cpu.aslA();
    goto L_00EDA5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA4u,0x00EDA4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA5u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA5 ASL
    cpu.aslA();
    goto L_00EDA6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA5u,0x00EDA5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA6u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA6 SEP
    cpu.sep(0x20u);
    goto L_00EDA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA6u,0x00EDA6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDA8u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA8u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDA8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDA8 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x92u), cpu.m8?8:16));
    goto L_00EDAA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDA8u,0x00EDA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDAAu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAAu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EDAA PHX
    cpu.push("PHX", hw);
    goto L_00EDAB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDAAu,0x00EDAAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDABu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDABu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDABu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDAB REP
    cpu.rep(0x10u);
    goto L_00EDAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDABu,0x00EDABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDADu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDADu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDAD TAX
    cpu.transfer("TAX");
    goto L_00EDAE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDADu,0x00EDADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDAEu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDAEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EDB0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDAEu,0x00EDAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB0u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDB0 SEC
    cpu.setFlag('C', true);
    goto L_00EDB1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDB0u,0x00EDB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB1u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB1u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB1u, 4u + 1u, 3u, cpu.address("absx", 0xE632u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDB1 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0xE632u), cpu.m8?8:16));
    goto L_00EDB4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDB1u,0x00EDB1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB4u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDB4 BPL -> $00EDB9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00EDB9; }
    goto L_00EDB6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDB4u,0x00EDB4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB6u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB6u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB6u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDB6 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EDB9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDB6u,0x00EDB6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDB9u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDB9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDB9 SEP
    cpu.sep(0x10u);
    goto L_00EDBB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDB9u,0x00EDB9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDBBu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBBu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EDBB PLX
    cpu.pop("PLX", hw);
    goto L_00EDBC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDBBu,0x00EDBBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDBCu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBCu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00EDBC PLY
    cpu.pop("PLY", hw);
    goto L_00EDBD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDBCu,0x00EDBCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDBDu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBDu,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDBDu, 4u + ((((0xE51Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xE51Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDBD CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xE51Cu), cpu.m8?8:16));
    goto L_00EDC0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDBDu,0x00EDBDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EDC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEDC0u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEDC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EDC0 BCS -> $00EDE9
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00EDE9u,0x00EDC0u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDC2u,0x00EDC0u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEDC0u,0x00EDC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_02C81A_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x02C81Au: goto L_02C81A;
    case 0x02C81Du: goto L_02C81D;
    case 0x02C820u: goto L_02C820;
    case 0x02C823u: goto L_02C823;
    case 0x02C826u: goto L_02C826;
    case 0x02C829u: goto L_02C829;
    case 0x02C82Bu: goto L_02C82B;
    case 0x02C82Du: goto L_02C82D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_02C81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC81Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Au, 6u, 3u, cpu.address("abs", 0xD378u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02C81A JSR -> $02D378 stack real
    { cpu.push16Value(hw,0xC81Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC81Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD378u), 0x02C81Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02C81D;
L_02C81D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC81Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC81Du,0x02C81Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Du, 6u, 3u, cpu.address("abs", 0xC88Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02C81D JSR -> $02C88C stack real
    { cpu.push16Value(hw,0xC81Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC820u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC88Cu), 0x02C81Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02C820;
L_02C820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC820u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC820u,0x02C820u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC820u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC820u, 6u, 3u, cpu.address("abs", 0xCA27u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02C820 JSR -> $02CA27 stack real
    { cpu.push16Value(hw,0xC822u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC823u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCA27u), 0x02C820u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02C823;
L_02C823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC823u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC823u,0x02C823u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC823u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC823u, 6u, 3u, cpu.address("abs", 0xCA9Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02C823 JSR -> $02CA9D stack real
    { cpu.push16Value(hw,0xC825u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC826u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCA9Du), 0x02C823u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02C826;
L_02C826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC826u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC826u,0x02C826u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC826u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC826u, 6u, 3u, cpu.address("abs", 0xCBA1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $02C826 JSR -> $02CBA1 stack real
    { cpu.push16Value(hw,0xC828u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC829u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCBA1u), 0x02C826u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_02C829;
L_02C829:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC829u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC829u,0x02C829u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC829u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC829u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C829 LDY
    cpu.setY(0xFFu, 8);
    goto L_02C82B;
L_02C82B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC82Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C82B LDA
    cpu.setA(0x4u, 8);
    goto L_02C82D;
L_02C82D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC82Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Du, 3u, 3u, cpu.address("abs", 0xB7A7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $02C82D JMP -> $02B7A7
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB7A7u),0x02C82Du); return;
}

void sub_049120_E0M1X1C0_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x049120u: goto L_049120;
    case 0x049123u: goto L_049123;
    case 0x049126u: goto L_049126;
    case 0x049128u: goto L_049128;
    case 0x04912Bu: goto L_04912B;
    case 0x04912Du: goto L_04912D;
    case 0x04912Fu: goto L_04912F;
    case 0x049132u: goto L_049132;
    case 0x049134u: goto L_049134;
    case 0x049136u: goto L_049136;
    case 0x049141u: goto L_049141;
    case 0x049143u: goto L_049143;
    case 0x049145u: goto L_049145;
    case 0x049147u: goto L_049147;
    case 0x049149u: goto L_049149;
    case 0x04914Cu: goto L_04914C;
    case 0x04914Eu: goto L_04914E;
    case 0x049150u: goto L_049150;
    case 0x049152u: goto L_049152;
    case 0x049154u: goto L_049154;
    case 0x049156u: goto L_049156;
    case 0x049158u: goto L_049158;
    case 0x04915Bu: goto L_04915B;
    case 0x04915Eu: goto L_04915E;
    case 0x049161u: goto L_049161;
    case 0x049163u: goto L_049163;
    case 0x049165u: goto L_049165;
    case 0x049168u: goto L_049168;
    case 0x04916Au: goto L_04916A;
    case 0x04916Du: goto L_04916D;
    case 0x049170u: goto L_049170;
    case 0x049172u: goto L_049172;
    case 0x049175u: goto L_049175;
    case 0x049177u: goto L_049177;
    case 0x04917Au: goto L_04917A;
    case 0x04917Du: goto L_04917D;
    case 0x049180u: goto L_049180;
    case 0x049182u: goto L_049182;
    case 0x049184u: goto L_049184;
    case 0x049186u: goto L_049186;
    case 0x049188u: goto L_049188;
    case 0x04918Bu: goto L_04918B;
    case 0x04918Du: goto L_04918D;
    case 0x049190u: goto L_049190;
    case 0x049193u: goto L_049193;
    case 0x049195u: goto L_049195;
    case 0x049198u: goto L_049198;
    case 0x049199u: goto L_049199;
    case 0x04919Bu: goto L_04919B;
    case 0x04919Du: goto L_04919D;
    case 0x04919Fu: goto L_04919F;
    case 0x0491A2u: goto L_0491A2;
    case 0x0491A3u: goto L_0491A3;
    case 0x0491A5u: goto L_0491A5;
    case 0x0491A6u: goto L_0491A6;
    case 0x0491A8u: goto L_0491A8;
    case 0x0491ABu: goto L_0491AB;
    case 0x0491ADu: goto L_0491AD;
    case 0x0491AFu: goto L_0491AF;
    case 0x0491B1u: goto L_0491B1;
    case 0x0491B2u: goto L_0491B2;
    case 0x0491B5u: goto L_0491B5;
    case 0x0491B8u: goto L_0491B8;
    case 0x0491BBu: goto L_0491BB;
    case 0x0491BEu: goto L_0491BE;
    case 0x0491C1u: goto L_0491C1;
    case 0x0491C4u: goto L_0491C4;
    case 0x0491C7u: goto L_0491C7;
    case 0x0491C9u: goto L_0491C9;
    case 0x0491CCu: goto L_0491CC;
    case 0x0491CFu: goto L_0491CF;
    case 0x0491D2u: goto L_0491D2;
    case 0x0491D5u: goto L_0491D5;
    case 0x0491D8u: goto L_0491D8;
    case 0x0491DBu: goto L_0491DB;
    case 0x0491DDu: goto L_0491DD;
    case 0x0491E0u: goto L_0491E0;
    case 0x0491E2u: goto L_0491E2;
    case 0x0491E5u: goto L_0491E5;
    case 0x0491E8u: goto L_0491E8;
    case 0x0491E9u: goto L_0491E9;
    case 0x0491EBu: goto L_0491EB;
    case 0x0491EEu: goto L_0491EE;
    case 0x0491F1u: goto L_0491F1;
    case 0x0491F2u: goto L_0491F2;
    case 0x0491F3u: goto L_0491F3;
    case 0x0491F4u: goto L_0491F4;
    case 0x0491F5u: goto L_0491F5;
    case 0x0491F7u: goto L_0491F7;
    case 0x0491FAu: goto L_0491FA;
    case 0x0491FDu: goto L_0491FD;
    case 0x0491FEu: goto L_0491FE;
    case 0x0491FFu: goto L_0491FF;
    case 0x049200u: goto L_049200;
    case 0x049201u: goto L_049201;
    case 0x049203u: goto L_049203;
    case 0x049206u: goto L_049206;
    case 0x049207u: goto L_049207;
    case 0x049208u: goto L_049208;
    case 0x049209u: goto L_049209;
    case 0x04920Au: goto L_04920A;
    case 0x04920Du: goto L_04920D;
    case 0x04920Fu: goto L_04920F;
    case 0x049212u: goto L_049212;
    case 0x049214u: goto L_049214;
    case 0x049215u: goto L_049215;
    case 0x049218u: goto L_049218;
    case 0x04921Au: goto L_04921A;
    case 0x04921Cu: goto L_04921C;
    case 0x04921Eu: goto L_04921E;
    case 0x049220u: goto L_049220;
    case 0x049224u: goto L_049224;
    case 0x049227u: goto L_049227;
    case 0x04922Au: goto L_04922A;
    case 0x04922Du: goto L_04922D;
    case 0x04922Fu: goto L_04922F;
    case 0x049232u: goto L_049232;
    case 0x049235u: goto L_049235;
    case 0x049238u: goto L_049238;
    case 0x04923Bu: goto L_04923B;
    case 0x04923Cu: goto L_04923C;
    case 0x04923Du: goto L_04923D;
    case 0x04923Fu: goto L_04923F;
    case 0x049243u: goto L_049243;
    case 0x049246u: goto L_049246;
    case 0x049248u: goto L_049248;
    case 0x04924Au: goto L_04924A;
    case 0x04924Bu: goto L_04924B;
    case 0x04924Cu: goto L_04924C;
    case 0x04924Eu: goto L_04924E;
    case 0x049251u: goto L_049251;
    case 0x049252u: goto L_049252;
    case 0x049253u: goto L_049253;
    case 0x049256u: goto L_049256;
    case 0x049257u: goto L_049257;
    case 0x04925Au: goto L_04925A;
    case 0x04925Cu: goto L_04925C;
    case 0x04925Fu: goto L_04925F;
    case 0x049261u: goto L_049261;
    case 0x049263u: goto L_049263;
    case 0x049265u: goto L_049265;
    case 0x049268u: goto L_049268;
    case 0x04926Au: goto L_04926A;
    case 0x04926Cu: goto L_04926C;
    case 0x04926Eu: goto L_04926E;
    case 0x049271u: goto L_049271;
    case 0x049273u: goto L_049273;
    case 0x049276u: goto L_049276;
    case 0x049279u: goto L_049279;
    case 0x04927Au: goto L_04927A;
    case 0x04927Cu: goto L_04927C;
    case 0x04927Du: goto L_04927D;
    case 0x049280u: goto L_049280;
    case 0x049282u: goto L_049282;
    case 0x049284u: goto L_049284;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_049120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9120u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9120u, 4u, 3u, cpu.address("abs", 0x0DD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049120 STZ
    hw.write(cpu.address("abs", 0xDD8u), 0, cpu.m8?8:16);
    goto L_049123;
L_049123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9123u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9123u, 4u, 3u, cpu.address("abs", 0x0EF7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049123 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0xEF7u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049126;
L_049126:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9126u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9126u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9126u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049126 BMI -> $049199
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_049199; }
    goto L_049128;
L_049128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9128u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9128u, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049128 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04912B;
L_04912B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04912B BMI -> $049132
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_049132; }
    goto L_04912D;
L_04912D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04912D BEQ -> $049132
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_049132; }
    goto L_04912F;
L_04912F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04912F BRL -> $0491E9
    goto L_0491E9;
L_049132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9132u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9132u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9132u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049132 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049134;
L_049134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9134u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9134u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049134 AND
    cpu.logicAnd(0x20u);
    goto L_049136;
L_049136:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9136u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9136u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9136u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049136 BRA -> $049141
    goto L_049141;
L_049141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9141u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9141u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049141 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049143;
L_049143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049143 AND
    cpu.logicAnd(0x30u);
    goto L_049145;
L_049145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9145u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9145u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049145 CMP
    cpu.compareA(0x30u);
    goto L_049147;
L_049147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9147u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9147u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049147 BNE -> $049150
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049150; }
    goto L_049149;
L_049149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u, 4u, 3u, cpu.address("abs", 0x13C1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049149 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04914C;
L_04914C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04914C CMP
    cpu.compareA(0x81u);
    goto L_04914E;
L_04914E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04914E BEQ -> $04919F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04919F; }
    goto L_049150;
L_049150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9150u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9150u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9150u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049150 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049152;
L_049152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9152u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9152u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049152 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16));
    goto L_049154;
L_049154:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9154u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9154u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9154u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049154 AND
    cpu.logicAnd(0xC0u);
    goto L_049156;
L_049156:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9156u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9156u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9156u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049156 BNE -> $04915B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04915B; }
    goto L_049158;
L_049158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049158 BRL -> $0491E9
    goto L_0491E9;
L_04915B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Bu, 4u, 3u, cpu.address("abs", 0x1B9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04915B STZ
    hw.write(cpu.address("abs", 0x1B9Eu), 0, cpu.m8?8:16);
    goto L_04915E;
L_04915E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Eu, 4u, 3u, cpu.address("abs", 0x13C1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04915E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049161;
L_049161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9161u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9161u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049161 CMP
    cpu.compareA(0x5Fu);
    goto L_049163;
L_049163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9163u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9163u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9163u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049163 BNE -> $04917D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04917D; }
    goto L_049165;
L_049165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9165u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9165u, 6u, 3u, cpu.address("abs", 0x8509u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049165 JSR -> $048509 stack real
    { cpu.push16Value(hw,0x9167u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9168u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8509u), 0x049165u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_049168;
L_049168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9168u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9168u,0x049168u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9168u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9168u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049168 BNE -> $049198
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049198; }
    goto L_04916A;
L_04916A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Au, 4u, 3u, cpu.address("abs", 0x1DF7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04916A STZ
    hw.write(cpu.address("abs", 0x1DF7u), 0, cpu.m8?8:16);
    goto L_04916D;
L_04916D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Du, 4u, 3u, cpu.address("abs", 0x1DF8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04916D STZ
    hw.write(cpu.address("abs", 0x1DF8u), 0, cpu.m8?8:16);
    goto L_049170;
L_049170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9170u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9170u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049170 LDA
    cpu.setA(0xDu, 8);
    goto L_049172;
L_049172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9172u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9172u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049172 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_049175;
L_049175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9175u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9175u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9175u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049175 LDA
    cpu.setA(0xBu, 8);
    goto L_049177;
L_049177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9177u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9177u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049177 STA
    hw.write(cpu.address("abs", 0x13D9u), cpu.a, cpu.m8?8:16);
    goto L_04917A;
L_04917A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Au, 3u, 3u, cpu.address("abs", 0x9E52u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04917A JMP -> $049E52
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9E52u),0x04917Au); return;
L_04917D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Du, 4u, 3u, cpu.address("abs", 0x13C1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04917D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049180;
L_049180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049180 CMP
    cpu.compareA(0x82u);
    goto L_049182;
L_049182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9182u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9182u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049182 BEQ -> $049188
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_049188; }
    goto L_049184;
L_049184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9184u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9184u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049184 CMP
    cpu.compareA(0x5Bu);
    goto L_049186;
L_049186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049186 BNE -> $049199
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049199; }
    goto L_049188;
L_049188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u, 6u, 3u, cpu.address("abs", 0x8509u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049188 JSR -> $048509 stack real
    { cpu.push16Value(hw,0x918Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x918Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8509u), 0x049188u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04918B;
L_04918B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x918Bu,0x04918Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04918B BNE -> $049198
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049198; }
    goto L_04918D;
L_04918D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du, 6u, 3u, cpu.address("abs", 0x1B9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04918D INC
    cpu.incMem(hw, cpu.address("abs", 0x1B9Cu), cpu.m8?8:16);
    goto L_049190;
L_049190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9190u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049190 STZ
    hw.write(cpu.address("abs", 0xDD5u), 0, cpu.m8?8:16);
    goto L_049193;
L_049193:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9193u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9193u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9193u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049193 LDA
    cpu.setA(0xBu, 8);
    goto L_049195;
L_049195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u, 4u, 3u, cpu.address("abs", 0x0100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049195 STA
    hw.write(cpu.address("abs", 0x100u), cpu.a, cpu.m8?8:16);
    goto L_049198;
L_049198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9198u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9198u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049198 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x049198u);return;} hw.unresolvedReturn(0x049198u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_049199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9199u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9199u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9199u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049199 CMP
    cpu.compareA(0x81u);
    goto L_04919B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9199u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9199u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049199 CMP
    cpu.compareA(0x81u);
    goto L_04919B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9199u,0x049199u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_04919B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04919B BEQ -> $0491E9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0491E9; }
    goto L_04919D;
L_04919D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04919D BCS -> $0491E9
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_0491E9; }
    goto L_04919F;
L_04919F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04919F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491A2;
L_0491A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491A2 LSR
    cpu.lsrA();
    goto L_0491A3;
L_0491A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491A3 AND
    cpu.logicAnd(0x2u);
    goto L_0491A5;
L_0491A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491A5 TAX
    cpu.transfer("TAX");
    goto L_0491A6;
L_0491A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491A6 LDY
    cpu.setY(0x10u, 8);
    goto L_0491A8;
L_0491A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A8u, 4u + ((((0x1F13u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491A8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491AB;
L_0491AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ABu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491AB AND
    cpu.logicAnd(0x8u);
    goto L_0491AD;
L_0491AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ADu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491AD BEQ -> $0491B1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0491B1; }
    goto L_0491AF;
L_0491AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91AFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491AF LDY
    cpu.setY(0x12u, 8);
    goto L_0491B1;
L_0491B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491B1 TYA
    cpu.transfer("TYA");
    goto L_0491B2;
L_0491B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u, 5u, 3u, cpu.address("absx", 0x1F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491B2 STA
    hw.write(cpu.address("absx", 0x1F13u), cpu.a, cpu.m8?8:16);
    goto L_0491B5;
L_0491B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B5u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B5u, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491B5 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDB3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0491B8;
L_0491B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B8u, 4u + ((((0x0DB6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491B8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491BB;
L_0491BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BBu, 4u, 3u, cpu.address("abs", 0x0DBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491BB STA
    hw.write(cpu.address("abs", 0xDBFu), cpu.a, cpu.m8?8:16);
    goto L_0491BE;
L_0491BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BEu, 4u + ((((0x0DB4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491BE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDB4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491C1;
L_0491C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u, 4u, 3u, cpu.address("abs", 0x0DBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491C1 STA
    hw.write(cpu.address("abs", 0xDBEu), cpu.a, cpu.m8?8:16);
    goto L_0491C4;
L_0491C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C4u, 4u + ((((0x0DB8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DB8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491C4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDB8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491C7;
L_0491C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491C7 STA
    hw.write(cpu.address("dp", 0x19u), cpu.a, cpu.m8?8:16);
    goto L_0491C9;
L_0491C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C9u, 4u + ((((0x0DBAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DBAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491C9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDBAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491CC;
L_0491CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu, 4u, 3u, cpu.address("abs", 0x0DC1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491CC STA
    hw.write(cpu.address("abs", 0xDC1u), cpu.a, cpu.m8?8:16);
    goto L_0491CF;
L_0491CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CFu, 4u, 3u, cpu.address("abs", 0x13C7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491CF STA
    hw.write(cpu.address("abs", 0x13C7u), cpu.a, cpu.m8?8:16);
    goto L_0491D2;
L_0491D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D2u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491D2 STA
    hw.write(cpu.address("abs", 0x187Au), cpu.a, cpu.m8?8:16);
    goto L_0491D5;
L_0491D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u, 4u + ((((0x0DBCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DBCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491D5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDBCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491D8;
L_0491D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D8u, 4u, 3u, cpu.address("abs", 0x0DC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491D8 STA
    hw.write(cpu.address("abs", 0xDC2u), cpu.a, cpu.m8?8:16);
    goto L_0491DB;
L_0491DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491DB LDA
    cpu.setA(0x2u, 8);
    goto L_0491DD;
L_0491DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DDu, 4u, 3u, cpu.address("abs", 0x0DB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491DD STA
    hw.write(cpu.address("abs", 0xDB1u), cpu.a, cpu.m8?8:16);
    goto L_0491E0;
L_0491E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491E0 LDA
    cpu.setA(0x80u, 8);
    goto L_0491E2;
L_0491E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E2u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491E2 STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_0491E5;
L_0491E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E5u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E5u, 6u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491E5 INC
    cpu.incMem(hw, cpu.address("abs", 0x100u), cpu.m8?8:16);
    goto L_0491E8;
L_0491E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0491E8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0491E8u);return;} hw.unresolvedReturn(0x0491E8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_0491E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491E9 REP
    cpu.rep(0x20u);
    goto L_0491EB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491E9 REP
    cpu.rep(0x20u);
    goto L_0491EB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91E9u,0x0491E9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0491EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EBu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EBu, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491EB LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0491EE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EBu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EBu, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491EB LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0491EE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91EBu,0x0491EBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0491EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EEu, 5u + ((((0x1F17u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491EE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491F1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EEu, 5u + ((((0x1F17u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491EE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491F1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91EEu,0x0491EEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0491F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491F1 LSR
    cpu.lsrA();
    goto L_0491F2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491F1 LSR
    cpu.lsrA();
    goto L_0491F2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91F1u,0x0491F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0491F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491F2 LSR
    cpu.lsrA();
    goto L_0491F3;
L_0491F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491F3 LSR
    cpu.lsrA();
    goto L_0491F4;
L_0491F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491F4 LSR
    cpu.lsrA();
    goto L_0491F5;
L_0491F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491F5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0491F7;
L_0491F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F7u, 6u, 3u, cpu.address("absx", 0x1F1Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491F7 STA
    hw.write(cpu.address("absx", 0x1F1Fu), cpu.a, cpu.m8?8:16);
    goto L_0491FA;
L_0491FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FAu, 5u + ((((0x1F19u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491FA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491FD;
L_0491FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491FD LSR
    cpu.lsrA();
    goto L_0491FE;
L_0491FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491FE LSR
    cpu.lsrA();
    goto L_0491FF;
L_0491FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491FF LSR
    cpu.lsrA();
    goto L_049200;
L_049200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9200u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9200u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049200 LSR
    cpu.lsrA();
    goto L_049201;
L_049201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9201u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9201u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049201 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_049203;
L_049203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9203u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9203u, 6u, 3u, cpu.address("absx", 0x1F21u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049203 STA
    hw.write(cpu.address("absx", 0x1F21u), cpu.a, cpu.m8?8:16);
    goto L_049206;
L_049206:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9206u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9206u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9206u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049206 TXA
    cpu.transfer("TXA");
    goto L_049207;
L_049207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049207 LSR
    cpu.lsrA();
    goto L_049208;
L_049208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9208u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9208u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049208 LSR
    cpu.lsrA();
    goto L_049209;
L_049209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049209 TAX
    cpu.transfer("TAX");
    goto L_04920A;
L_04920A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Au, 6u, 3u, cpu.address("abs", 0x9885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04920A JSR -> $049885 stack real
    { cpu.push16Value(hw,0x920Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x920Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9885u), 0x04920Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04920D;
L_04920D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x920Du,0x04920Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04920D SEP
    cpu.sep(0x20u);
    goto L_04920F;
L_04920F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04920F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049212;
L_049212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9212u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9212u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049212 BEQ -> $04925A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04925A; }
    goto L_049214;
L_049214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9214u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9214u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049214 DEX
    cpu.decReg('X');
    goto L_049215;
L_049215:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9215u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9215u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9215u, 4u + ((((0x9060u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9060u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049215 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9060u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049218;
L_049218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9218u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9218u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049218 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_04921A;
L_04921A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04921A STZ
    hw.write(cpu.address("dp", 0x9u), 0, cpu.m8?8:16);
    goto L_04921C;
L_04921C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04921C REP
    cpu.rep(0x30u);
    goto L_04921E;
L_04921E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04921E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049220;
L_049220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9220u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9220u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9220u, 6u, 4u, ((0x7ED000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049220 LDA
    cpu.loadA(hw.readW(((0x7ED000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049224;
L_049224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9224u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9224u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049224 AND
    cpu.logicAnd(0xFFu);
    goto L_049227;
L_049227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9227u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9227u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049227 LDY
    cpu.setY(0xAu, 16);
    goto L_04922A;
L_04922A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Au,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Au, 5u + 1u, 3u, cpu.address("absy", 0x906Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04922A CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x906Cu), cpu.m8?8:16));
    goto L_04922D;
L_04922D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04922D BNE -> $04923B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04923B; }
    goto L_04922F;
L_04922F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04922F LDA
    cpu.setA(0x5u, 16);
    goto L_049232;
L_049232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9232u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9232u, 5u, 3u, cpu.address("abs", 0x13D9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049232 STA
    hw.write(cpu.address("abs", 0x13D9u), cpu.a, cpu.m8?8:16);
    goto L_049235;
L_049235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u, 6u, 3u, cpu.address("abs", 0x9037u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049235 JSR -> $049037 stack real
    { cpu.push16Value(hw,0x9237u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9238u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9037u), 0x049235u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_049238;
L_049238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9238u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9238u,0x049238u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9238u,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9238u, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049238 BRL -> $049411
    hw.requestDispatch(0x049411u,0x049238u); return;
L_04923B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04923B DEY
    cpu.decReg('Y');
    goto L_04923C;
L_04923C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04923C DEY
    cpu.decReg('Y');
    goto L_04923D;
L_04923D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04923D BPL -> $04922A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04922A; }
    goto L_04923F;
L_04923F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Fu, 6u, 4u, ((0x7ED800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04923F LDA
    cpu.loadA(hw.readW(((0x7ED800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049243;
L_049243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049243 AND
    cpu.logicAnd(0xFFu);
    goto L_049246;
L_049246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9246u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9246u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049246 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049248;
L_049248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9248u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9248u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049248 BEQ -> $04924E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04924E; }
    goto L_04924A;
L_04924A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04924A LSR
    cpu.lsrA();
    goto L_04924B;
L_04924B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04924B DEX
    cpu.decReg('X');
    goto L_04924C;
L_04924C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04924C BPL -> $04924A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04924A; }
    goto L_04924E;
L_04924E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04924E AND
    cpu.logicAnd(0x3u);
    goto L_049251;
L_049251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9251u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9251u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049251 ASL
    cpu.aslA();
    goto L_049252;
L_049252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9252u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9252u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049252 TAX
    cpu.transfer("TAX");
    goto L_049253;
L_049253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9253u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9253u, 5u + 1u, 3u, cpu.address("absx", 0x9064u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049253 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9064u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049256;
L_049256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9256u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9256u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049256 TAY
    cpu.transfer("TAY");
    goto L_049257;
L_049257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9257u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9257u, 3u, 3u, cpu.address("abs", 0x92BCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049257 JMP -> $0492BC
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x92BCu),0x049257u); return;
L_04925A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04925A SEP
    cpu.sep(0x30u);
    goto L_04925C;
L_04925C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Cu, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04925C STZ
    hw.write(cpu.address("abs", 0xDD5u), 0, cpu.m8?8:16);
    goto L_04925F;
L_04925F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04925F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049261;
L_049261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9261u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9261u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049261 AND
    cpu.logicAnd(0xFu);
    goto L_049263;
L_049263:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9263u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9263u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9263u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049263 BEQ -> $04926E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04926E; }
    goto L_049265;
L_049265:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9265u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9265u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9265u, 4u, 3u, cpu.address("abs", 0x13C1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049265 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13C1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049268;
L_049268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9268u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9268u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049268 CPX
    cpu.compareX(0x82u);
    goto L_04926A;
L_04926A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04926A BEQ -> $0492AD
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x0492ADu,0x04926Au); return; }
    goto L_04926C;
L_04926C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04926C BRA -> $04928C
    hw.requestDispatch(0x04928Cu,0x04926Cu); return;
L_04926E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Eu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Eu, 6u, 3u, cpu.address("abs", 0x144Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04926E DEC
    cpu.decMem(hw, cpu.address("abs", 0x144Eu), cpu.m8?8:16);
    goto L_049271;
L_049271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9271u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9271u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049271 BPL -> $049287
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x049287u,0x049271u); return; }
    goto L_049273;
L_049273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9273u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9273u, 4u, 3u, cpu.address("abs", 0x144Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049273 STZ
    hw.write(cpu.address("abs", 0x144Eu), 0, cpu.m8?8:16);
    goto L_049276;
L_049276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9276u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9276u, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049276 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049279;
L_049279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9279u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9279u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049279 LSR
    cpu.lsrA();
    goto L_04927A;
L_04927A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04927A AND
    cpu.logicAnd(0x2u);
    goto L_04927C;
L_04927C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04927C TAX
    cpu.transfer("TAX");
    goto L_04927D;
L_04927D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du, 4u + ((((0x1F13u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04927D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049280;
L_049280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9280u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049280 AND
    cpu.logicAnd(0x8u);
    goto L_049282;
L_049282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049282 ORA
    cpu.logicOr(0x2u);
    goto L_049284;
L_049284:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9284u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9284u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9284u, 5u, 3u, cpu.address("absx", 0x1F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049284 STA
    hw.write(cpu.address("absx", 0x1F13u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9287u,0x049284u); return;
}

void sub_049120_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x049120u: goto L_049120;
    case 0x049123u: goto L_049123;
    case 0x049126u: goto L_049126;
    case 0x049128u: goto L_049128;
    case 0x04912Bu: goto L_04912B;
    case 0x04912Du: goto L_04912D;
    case 0x04912Fu: goto L_04912F;
    case 0x049132u: goto L_049132;
    case 0x049134u: goto L_049134;
    case 0x049136u: goto L_049136;
    case 0x049141u: goto L_049141;
    case 0x049143u: goto L_049143;
    case 0x049145u: goto L_049145;
    case 0x049147u: goto L_049147;
    case 0x049149u: goto L_049149;
    case 0x04914Cu: goto L_04914C;
    case 0x04914Eu: goto L_04914E;
    case 0x049150u: goto L_049150;
    case 0x049152u: goto L_049152;
    case 0x049154u: goto L_049154;
    case 0x049156u: goto L_049156;
    case 0x049158u: goto L_049158;
    case 0x04915Bu: goto L_04915B;
    case 0x04915Eu: goto L_04915E;
    case 0x049161u: goto L_049161;
    case 0x049163u: goto L_049163;
    case 0x049165u: goto L_049165;
    case 0x049168u: goto L_049168;
    case 0x04916Au: goto L_04916A;
    case 0x04916Du: goto L_04916D;
    case 0x049170u: goto L_049170;
    case 0x049172u: goto L_049172;
    case 0x049175u: goto L_049175;
    case 0x049177u: goto L_049177;
    case 0x04917Au: goto L_04917A;
    case 0x04917Du: goto L_04917D;
    case 0x049180u: goto L_049180;
    case 0x049182u: goto L_049182;
    case 0x049184u: goto L_049184;
    case 0x049186u: goto L_049186;
    case 0x049188u: goto L_049188;
    case 0x04918Bu: goto L_04918B;
    case 0x04918Du: goto L_04918D;
    case 0x049190u: goto L_049190;
    case 0x049193u: goto L_049193;
    case 0x049195u: goto L_049195;
    case 0x049198u: goto L_049198;
    case 0x049199u: goto L_049199;
    case 0x04919Bu: goto L_04919B;
    case 0x04919Du: goto L_04919D;
    case 0x04919Fu: goto L_04919F;
    case 0x0491A2u: goto L_0491A2;
    case 0x0491A3u: goto L_0491A3;
    case 0x0491A5u: goto L_0491A5;
    case 0x0491A6u: goto L_0491A6;
    case 0x0491A8u: goto L_0491A8;
    case 0x0491ABu: goto L_0491AB;
    case 0x0491ADu: goto L_0491AD;
    case 0x0491AFu: goto L_0491AF;
    case 0x0491B1u: goto L_0491B1;
    case 0x0491B2u: goto L_0491B2;
    case 0x0491B5u: goto L_0491B5;
    case 0x0491B8u: goto L_0491B8;
    case 0x0491BBu: goto L_0491BB;
    case 0x0491BEu: goto L_0491BE;
    case 0x0491C1u: goto L_0491C1;
    case 0x0491C4u: goto L_0491C4;
    case 0x0491C7u: goto L_0491C7;
    case 0x0491C9u: goto L_0491C9;
    case 0x0491CCu: goto L_0491CC;
    case 0x0491CFu: goto L_0491CF;
    case 0x0491D2u: goto L_0491D2;
    case 0x0491D5u: goto L_0491D5;
    case 0x0491D8u: goto L_0491D8;
    case 0x0491DBu: goto L_0491DB;
    case 0x0491DDu: goto L_0491DD;
    case 0x0491E0u: goto L_0491E0;
    case 0x0491E2u: goto L_0491E2;
    case 0x0491E5u: goto L_0491E5;
    case 0x0491E8u: goto L_0491E8;
    case 0x0491E9u: goto L_0491E9;
    case 0x0491EBu: goto L_0491EB;
    case 0x0491EEu: goto L_0491EE;
    case 0x0491F1u: goto L_0491F1;
    case 0x0491F2u: goto L_0491F2;
    case 0x0491F3u: goto L_0491F3;
    case 0x0491F4u: goto L_0491F4;
    case 0x0491F5u: goto L_0491F5;
    case 0x0491F7u: goto L_0491F7;
    case 0x0491FAu: goto L_0491FA;
    case 0x0491FDu: goto L_0491FD;
    case 0x0491FEu: goto L_0491FE;
    case 0x0491FFu: goto L_0491FF;
    case 0x049200u: goto L_049200;
    case 0x049201u: goto L_049201;
    case 0x049203u: goto L_049203;
    case 0x049206u: goto L_049206;
    case 0x049207u: goto L_049207;
    case 0x049208u: goto L_049208;
    case 0x049209u: goto L_049209;
    case 0x04920Au: goto L_04920A;
    case 0x04920Du: goto L_04920D;
    case 0x04920Fu: goto L_04920F;
    case 0x049212u: goto L_049212;
    case 0x049214u: goto L_049214;
    case 0x049215u: goto L_049215;
    case 0x049218u: goto L_049218;
    case 0x04921Au: goto L_04921A;
    case 0x04921Cu: goto L_04921C;
    case 0x04921Eu: goto L_04921E;
    case 0x049220u: goto L_049220;
    case 0x049224u: goto L_049224;
    case 0x049227u: goto L_049227;
    case 0x04922Au: goto L_04922A;
    case 0x04922Du: goto L_04922D;
    case 0x04922Fu: goto L_04922F;
    case 0x049232u: goto L_049232;
    case 0x049235u: goto L_049235;
    case 0x049238u: goto L_049238;
    case 0x04923Bu: goto L_04923B;
    case 0x04923Cu: goto L_04923C;
    case 0x04923Du: goto L_04923D;
    case 0x04923Fu: goto L_04923F;
    case 0x049243u: goto L_049243;
    case 0x049246u: goto L_049246;
    case 0x049248u: goto L_049248;
    case 0x04924Au: goto L_04924A;
    case 0x04924Bu: goto L_04924B;
    case 0x04924Cu: goto L_04924C;
    case 0x04924Eu: goto L_04924E;
    case 0x049251u: goto L_049251;
    case 0x049252u: goto L_049252;
    case 0x049253u: goto L_049253;
    case 0x049256u: goto L_049256;
    case 0x049257u: goto L_049257;
    case 0x04925Au: goto L_04925A;
    case 0x04925Cu: goto L_04925C;
    case 0x04925Fu: goto L_04925F;
    case 0x049261u: goto L_049261;
    case 0x049263u: goto L_049263;
    case 0x049265u: goto L_049265;
    case 0x049268u: goto L_049268;
    case 0x04926Au: goto L_04926A;
    case 0x04926Cu: goto L_04926C;
    case 0x04926Eu: goto L_04926E;
    case 0x049271u: goto L_049271;
    case 0x049273u: goto L_049273;
    case 0x049276u: goto L_049276;
    case 0x049279u: goto L_049279;
    case 0x04927Au: goto L_04927A;
    case 0x04927Cu: goto L_04927C;
    case 0x04927Du: goto L_04927D;
    case 0x049280u: goto L_049280;
    case 0x049282u: goto L_049282;
    case 0x049284u: goto L_049284;
    case 0x049287u: goto L_049287;
    case 0x049289u: goto L_049289;
    case 0x04928Cu: goto L_04928C;
    case 0x04928Eu: goto L_04928E;
    case 0x049291u: goto L_049291;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_049120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9120u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9120u, 4u, 3u, cpu.address("abs", 0x0DD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049120 STZ
    hw.write(cpu.address("abs", 0xDD8u), 0, cpu.m8?8:16);
    goto L_049123;
L_049123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9123u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9123u, 4u, 3u, cpu.address("abs", 0x0EF7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049123 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0xEF7u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049126;
L_049126:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9126u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9126u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9126u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049126 BMI -> $049199
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_049199; }
    goto L_049128;
L_049128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9128u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9128u, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049128 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04912B;
L_04912B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04912B BMI -> $049132
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_049132; }
    goto L_04912D;
L_04912D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04912D BEQ -> $049132
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_049132; }
    goto L_04912F;
L_04912F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04912F BRL -> $0491E9
    goto L_0491E9;
L_049132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9132u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9132u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9132u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049132 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049134;
L_049134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9134u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9134u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049134 AND
    cpu.logicAnd(0x20u);
    goto L_049136;
L_049136:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9136u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9136u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9136u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049136 BRA -> $049141
    goto L_049141;
L_049141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9141u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9141u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049141 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049143;
L_049143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049143 AND
    cpu.logicAnd(0x30u);
    goto L_049145;
L_049145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9145u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9145u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049145 CMP
    cpu.compareA(0x30u);
    goto L_049147;
L_049147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9147u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9147u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049147 BNE -> $049150
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049150; }
    goto L_049149;
L_049149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u, 4u, 3u, cpu.address("abs", 0x13C1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049149 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04914C;
L_04914C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04914C CMP
    cpu.compareA(0x81u);
    goto L_04914E;
L_04914E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04914E BEQ -> $04919F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04919F; }
    goto L_049150;
L_049150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9150u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9150u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9150u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049150 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049152;
L_049152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9152u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9152u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049152 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16));
    goto L_049154;
L_049154:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9154u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9154u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9154u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049154 AND
    cpu.logicAnd(0xC0u);
    goto L_049156;
L_049156:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9156u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9156u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9156u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049156 BNE -> $04915B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04915B; }
    goto L_049158;
L_049158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049158 BRL -> $0491E9
    goto L_0491E9;
L_04915B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Bu, 4u, 3u, cpu.address("abs", 0x1B9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04915B STZ
    hw.write(cpu.address("abs", 0x1B9Eu), 0, cpu.m8?8:16);
    goto L_04915E;
L_04915E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Eu, 4u, 3u, cpu.address("abs", 0x13C1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04915E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049161;
L_049161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9161u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9161u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049161 CMP
    cpu.compareA(0x5Fu);
    goto L_049163;
L_049163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9163u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9163u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9163u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049163 BNE -> $04917D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04917D; }
    goto L_049165;
L_049165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9165u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9165u, 6u, 3u, cpu.address("abs", 0x8509u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049165 JSR -> $048509 stack real
    { cpu.push16Value(hw,0x9167u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9168u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8509u), 0x049165u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_049168;
L_049168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9168u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9168u,0x049168u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9168u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9168u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049168 BNE -> $049198
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049198; }
    goto L_04916A;
L_04916A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Au, 4u, 3u, cpu.address("abs", 0x1DF7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04916A STZ
    hw.write(cpu.address("abs", 0x1DF7u), 0, cpu.m8?8:16);
    goto L_04916D;
L_04916D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Du, 4u, 3u, cpu.address("abs", 0x1DF8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04916D STZ
    hw.write(cpu.address("abs", 0x1DF8u), 0, cpu.m8?8:16);
    goto L_049170;
L_049170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9170u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9170u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049170 LDA
    cpu.setA(0xDu, 8);
    goto L_049172;
L_049172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9172u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9172u, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049172 STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_049175;
L_049175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9175u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9175u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9175u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049175 LDA
    cpu.setA(0xBu, 8);
    goto L_049177;
L_049177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9177u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9177u, 4u, 3u, cpu.address("abs", 0x13D9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049177 STA
    hw.write(cpu.address("abs", 0x13D9u), cpu.a, cpu.m8?8:16);
    goto L_04917A;
L_04917A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Au, 3u, 3u, cpu.address("abs", 0x9E52u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04917A JMP -> $049E52
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9E52u),0x04917Au); return;
L_04917D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Du, 4u, 3u, cpu.address("abs", 0x13C1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04917D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13C1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049180;
L_049180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049180 CMP
    cpu.compareA(0x82u);
    goto L_049182;
L_049182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9182u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9182u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049182 BEQ -> $049188
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_049188; }
    goto L_049184;
L_049184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9184u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9184u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049184 CMP
    cpu.compareA(0x5Bu);
    goto L_049186;
L_049186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049186 BNE -> $049199
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049199; }
    goto L_049188;
L_049188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u, 6u, 3u, cpu.address("abs", 0x8509u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049188 JSR -> $048509 stack real
    { cpu.push16Value(hw,0x918Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x918Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8509u), 0x049188u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04918B;
L_04918B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x918Bu,0x04918Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04918B BNE -> $049198
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_049198; }
    goto L_04918D;
L_04918D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du, 6u, 3u, cpu.address("abs", 0x1B9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04918D INC
    cpu.incMem(hw, cpu.address("abs", 0x1B9Cu), cpu.m8?8:16);
    goto L_049190;
L_049190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9190u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049190 STZ
    hw.write(cpu.address("abs", 0xDD5u), 0, cpu.m8?8:16);
    goto L_049193;
L_049193:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9193u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9193u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9193u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049193 LDA
    cpu.setA(0xBu, 8);
    goto L_049195;
L_049195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u, 4u, 3u, cpu.address("abs", 0x0100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049195 STA
    hw.write(cpu.address("abs", 0x100u), cpu.a, cpu.m8?8:16);
    goto L_049198;
L_049198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9198u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9198u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049198 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x049198u);return;} hw.unresolvedReturn(0x049198u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_049199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9199u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9199u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9199u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049199 CMP
    cpu.compareA(0x81u);
    goto L_04919B;
L_04919B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04919B BEQ -> $0491E9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0491E9; }
    goto L_04919D;
L_04919D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04919D BCS -> $0491E9
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_0491E9; }
    goto L_04919F;
L_04919F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04919F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491A2;
L_0491A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491A2 LSR
    cpu.lsrA();
    goto L_0491A3;
L_0491A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491A3 AND
    cpu.logicAnd(0x2u);
    goto L_0491A5;
L_0491A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491A5 TAX
    cpu.transfer("TAX");
    goto L_0491A6;
L_0491A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491A6 LDY
    cpu.setY(0x10u, 8);
    goto L_0491A8;
L_0491A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A8u, 4u + ((((0x1F13u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491A8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491AB;
L_0491AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ABu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491AB AND
    cpu.logicAnd(0x8u);
    goto L_0491AD;
L_0491AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ADu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491AD BEQ -> $0491B1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0491B1; }
    goto L_0491AF;
L_0491AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91AFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491AF LDY
    cpu.setY(0x12u, 8);
    goto L_0491B1;
L_0491B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491B1 TYA
    cpu.transfer("TYA");
    goto L_0491B2;
L_0491B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u, 5u, 3u, cpu.address("absx", 0x1F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491B2 STA
    hw.write(cpu.address("absx", 0x1F13u), cpu.a, cpu.m8?8:16);
    goto L_0491B5;
L_0491B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B5u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B5u, 4u, 3u, cpu.address("abs", 0x0DB3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491B5 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDB3u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0491B8;
L_0491B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B8u, 4u + ((((0x0DB6u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491B8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491BB;
L_0491BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BBu, 4u, 3u, cpu.address("abs", 0x0DBFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491BB STA
    hw.write(cpu.address("abs", 0xDBFu), cpu.a, cpu.m8?8:16);
    goto L_0491BE;
L_0491BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BEu, 4u + ((((0x0DB4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491BE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDB4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491C1;
L_0491C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u, 4u, 3u, cpu.address("abs", 0x0DBEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491C1 STA
    hw.write(cpu.address("abs", 0xDBEu), cpu.a, cpu.m8?8:16);
    goto L_0491C4;
L_0491C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C4u, 4u + ((((0x0DB8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DB8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491C4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDB8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491C7;
L_0491C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491C7 STA
    hw.write(cpu.address("dp", 0x19u), cpu.a, cpu.m8?8:16);
    goto L_0491C9;
L_0491C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C9u, 4u + ((((0x0DBAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DBAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491C9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDBAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491CC;
L_0491CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu, 4u, 3u, cpu.address("abs", 0x0DC1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491CC STA
    hw.write(cpu.address("abs", 0xDC1u), cpu.a, cpu.m8?8:16);
    goto L_0491CF;
L_0491CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CFu, 4u, 3u, cpu.address("abs", 0x13C7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491CF STA
    hw.write(cpu.address("abs", 0x13C7u), cpu.a, cpu.m8?8:16);
    goto L_0491D2;
L_0491D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D2u, 4u, 3u, cpu.address("abs", 0x187Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491D2 STA
    hw.write(cpu.address("abs", 0x187Au), cpu.a, cpu.m8?8:16);
    goto L_0491D5;
L_0491D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u, 4u + ((((0x0DBCu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0DBCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491D5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDBCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491D8;
L_0491D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D8u, 4u, 3u, cpu.address("abs", 0x0DC2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491D8 STA
    hw.write(cpu.address("abs", 0xDC2u), cpu.a, cpu.m8?8:16);
    goto L_0491DB;
L_0491DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491DB LDA
    cpu.setA(0x2u, 8);
    goto L_0491DD;
L_0491DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DDu, 4u, 3u, cpu.address("abs", 0x0DB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491DD STA
    hw.write(cpu.address("abs", 0xDB1u), cpu.a, cpu.m8?8:16);
    goto L_0491E0;
L_0491E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491E0 LDA
    cpu.setA(0x80u, 8);
    goto L_0491E2;
L_0491E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E2u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491E2 STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_0491E5;
L_0491E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E5u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E5u, 6u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491E5 INC
    cpu.incMem(hw, cpu.address("abs", 0x100u), cpu.m8?8:16);
    goto L_0491E8;
L_0491E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0491E8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0491E8u);return;} hw.unresolvedReturn(0x0491E8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_0491E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491E9 REP
    cpu.rep(0x20u);
    goto L_0491EB;
L_0491EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EBu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EBu, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491EB LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0491EE;
L_0491EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EEu, 5u + ((((0x1F17u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F17u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491EE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491F1;
L_0491F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491F1 LSR
    cpu.lsrA();
    goto L_0491F2;
L_0491F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491F2 LSR
    cpu.lsrA();
    goto L_0491F3;
L_0491F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491F3 LSR
    cpu.lsrA();
    goto L_0491F4;
L_0491F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491F4 LSR
    cpu.lsrA();
    goto L_0491F5;
L_0491F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491F5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0491F7;
L_0491F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F7u, 6u, 3u, cpu.address("absx", 0x1F1Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491F7 STA
    hw.write(cpu.address("absx", 0x1F1Fu), cpu.a, cpu.m8?8:16);
    goto L_0491FA;
L_0491FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FAu, 5u + ((((0x1F19u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F19u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491FA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0491FD;
L_0491FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FDu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491FD LSR
    cpu.lsrA();
    goto L_0491FE;
L_0491FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491FE LSR
    cpu.lsrA();
    goto L_0491FF;
L_0491FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0491FF LSR
    cpu.lsrA();
    goto L_049200;
L_049200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9200u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9200u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049200 LSR
    cpu.lsrA();
    goto L_049201;
L_049201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9201u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9201u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049201 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_049203;
L_049203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9203u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9203u, 6u, 3u, cpu.address("absx", 0x1F21u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049203 STA
    hw.write(cpu.address("absx", 0x1F21u), cpu.a, cpu.m8?8:16);
    goto L_049206;
L_049206:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9206u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9206u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9206u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049206 TXA
    cpu.transfer("TXA");
    goto L_049207;
L_049207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049207 LSR
    cpu.lsrA();
    goto L_049208;
L_049208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9208u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9208u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049208 LSR
    cpu.lsrA();
    goto L_049209;
L_049209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049209 TAX
    cpu.transfer("TAX");
    goto L_04920A;
L_04920A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Au, 6u, 3u, cpu.address("abs", 0x9885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04920A JSR -> $049885 stack real
    { cpu.push16Value(hw,0x920Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x920Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9885u), 0x04920Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_04920D;
L_04920D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x920Du,0x04920Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04920D SEP
    cpu.sep(0x20u);
    goto L_04920F;
L_04920F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04920F LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049212;
L_049212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9212u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9212u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049212 BEQ -> $04925A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04925A; }
    goto L_049214;
L_049214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9214u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9214u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049214 DEX
    cpu.decReg('X');
    goto L_049215;
L_049215:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9215u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9215u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9215u, 4u + ((((0x9060u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x9060u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049215 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9060u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049218;
L_049218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9218u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9218u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049218 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_04921A;
L_04921A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04921A STZ
    hw.write(cpu.address("dp", 0x9u), 0, cpu.m8?8:16);
    goto L_04921C;
L_04921C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04921C REP
    cpu.rep(0x30u);
    goto L_04921E;
L_04921E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04921E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049220;
L_049220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9220u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9220u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9220u, 6u, 4u, ((0x7ED000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049220 LDA
    cpu.loadA(hw.readW(((0x7ED000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049224;
L_049224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9224u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9224u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049224 AND
    cpu.logicAnd(0xFFu);
    goto L_049227;
L_049227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9227u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9227u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049227 LDY
    cpu.setY(0xAu, 16);
    goto L_04922A;
L_04922A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Au,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Au, 5u + 1u, 3u, cpu.address("absy", 0x906Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04922A CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x906Cu), cpu.m8?8:16));
    goto L_04922D;
L_04922D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04922D BNE -> $04923B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_04923B; }
    goto L_04922F;
L_04922F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04922F LDA
    cpu.setA(0x5u, 16);
    goto L_049232;
L_049232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9232u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9232u, 5u, 3u, cpu.address("abs", 0x13D9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049232 STA
    hw.write(cpu.address("abs", 0x13D9u), cpu.a, cpu.m8?8:16);
    goto L_049235;
L_049235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u, 6u, 3u, cpu.address("abs", 0x9037u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $049235 JSR -> $049037 stack real
    { cpu.push16Value(hw,0x9237u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9238u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9037u), 0x049235u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_049238;
L_049238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9238u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9238u,0x049238u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9238u,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9238u, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049238 BRL -> $049411
    hw.requestDispatch(0x049411u,0x049238u); return;
L_04923B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04923B DEY
    cpu.decReg('Y');
    goto L_04923C;
L_04923C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04923C DEY
    cpu.decReg('Y');
    goto L_04923D;
L_04923D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04923D BPL -> $04922A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04922A; }
    goto L_04923F;
L_04923F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Fu, 6u, 4u, ((0x7ED800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04923F LDA
    cpu.loadA(hw.readW(((0x7ED800u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049243;
L_049243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049243 AND
    cpu.logicAnd(0xFFu);
    goto L_049246;
L_049246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9246u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9246u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049246 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049248;
L_049248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9248u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9248u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049248 BEQ -> $04924E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04924E; }
    goto L_04924A;
L_04924A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04924A LSR
    cpu.lsrA();
    goto L_04924B;
L_04924B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04924B DEX
    cpu.decReg('X');
    goto L_04924C;
L_04924C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04924C BPL -> $04924A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_04924A; }
    goto L_04924E;
L_04924E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04924E AND
    cpu.logicAnd(0x3u);
    goto L_049251;
L_049251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9251u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9251u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049251 ASL
    cpu.aslA();
    goto L_049252;
L_049252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9252u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9252u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049252 TAX
    cpu.transfer("TAX");
    goto L_049253;
L_049253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9253u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9253u, 5u + 1u, 3u, cpu.address("absx", 0x9064u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049253 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x9064u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049256;
L_049256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9256u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9256u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049256 TAY
    cpu.transfer("TAY");
    goto L_049257;
L_049257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9257u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9257u, 3u, 3u, cpu.address("abs", 0x92BCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049257 JMP -> $0492BC
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x92BCu),0x049257u); return;
L_04925A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04925A SEP
    cpu.sep(0x30u);
    goto L_04925C;
L_04925C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Cu, 4u, 3u, cpu.address("abs", 0x0DD5u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04925C STZ
    hw.write(cpu.address("abs", 0xDD5u), 0, cpu.m8?8:16);
    goto L_04925F;
L_04925F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x925Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x925Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x925Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04925F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049261;
L_049261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9261u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9261u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049261 AND
    cpu.logicAnd(0xFu);
    goto L_049263;
L_049263:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9263u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9263u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9263u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049263 BEQ -> $04926E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_04926E; }
    goto L_049265;
L_049265:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9265u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9265u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9265u, 4u, 3u, cpu.address("abs", 0x13C1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049265 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13C1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_049268;
L_049268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9268u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9268u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049268 CPX
    cpu.compareX(0x82u);
    goto L_04926A;
L_04926A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04926A BEQ -> $0492AD
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x0492ADu,0x04926Au); return; }
    goto L_04926C;
L_04926C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04926C BRA -> $04928C
    goto L_04928C;
L_04926E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x926Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x926Eu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x926Eu, 6u, 3u, cpu.address("abs", 0x144Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04926E DEC
    cpu.decMem(hw, cpu.address("abs", 0x144Eu), cpu.m8?8:16);
    goto L_049271;
L_049271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9271u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9271u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049271 BPL -> $049287
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_049287; }
    goto L_049273;
L_049273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9273u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9273u, 4u, 3u, cpu.address("abs", 0x144Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049273 STZ
    hw.write(cpu.address("abs", 0x144Eu), 0, cpu.m8?8:16);
    goto L_049276;
L_049276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9276u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9276u, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049276 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049279;
L_049279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9279u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9279u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049279 LSR
    cpu.lsrA();
    goto L_04927A;
L_04927A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04927A AND
    cpu.logicAnd(0x2u);
    goto L_04927C;
L_04927C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04927C TAX
    cpu.transfer("TAX");
    goto L_04927D;
L_04927D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du, 4u + ((((0x1F13u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04927D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049280;
L_049280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9280u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049280 AND
    cpu.logicAnd(0x8u);
    goto L_049282;
L_049282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049282 ORA
    cpu.logicOr(0x2u);
    goto L_049284;
L_049284:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9284u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9284u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9284u, 5u, 3u, cpu.address("absx", 0x1F13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049284 STA
    hw.write(cpu.address("absx", 0x1F13u), cpu.a, cpu.m8?8:16);
    goto L_049287;
L_049287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9287u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9287u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049287 REP
    cpu.rep(0x30u);
    goto L_049289;
L_049289:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9289u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9289u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9289u, 3u, 3u, cpu.address("abs", 0x9831u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049289 JMP -> $049831
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9831u),0x049289u); return;
L_04928C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04928C REP
    cpu.rep(0x30u);
    goto L_04928E;
L_04928E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x928Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x928Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x928Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04928E AND
    cpu.logicAnd(0xFFu);
    goto L_049291;
L_049291:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9291u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9291u,cpu,0xEAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9291u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049291 NOP
    ;
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9292u,0x049291u); return;
}

void sub_05D796_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05D796u: goto L_05D796;
    case 0x05D797u: goto L_05D797;
    case 0x05D798u: goto L_05D798;
    case 0x05D799u: goto L_05D799;
    case 0x05D79Bu: goto L_05D79B;
    case 0x05D79Eu: goto L_05D79E;
    case 0x05D7A1u: goto L_05D7A1;
    case 0x05D7A3u: goto L_05D7A3;
    case 0x05D7A6u: goto L_05D7A6;
    case 0x05D7A8u: goto L_05D7A8;
    case 0x05D7ABu: goto L_05D7AB;
    case 0x05D7AEu: goto L_05D7AE;
    case 0x05D7B0u: goto L_05D7B0;
    case 0x05D7B3u: goto L_05D7B3;
    case 0x05D7B5u: goto L_05D7B5;
    case 0x05D7B7u: goto L_05D7B7;
    case 0x05D7B9u: goto L_05D7B9;
    case 0x05D7BBu: goto L_05D7BB;
    case 0x05D7BDu: goto L_05D7BD;
    case 0x05D7C0u: goto L_05D7C0;
    case 0x05D7C3u: goto L_05D7C3;
    case 0x05D7C5u: goto L_05D7C5;
    case 0x05D7C8u: goto L_05D7C8;
    case 0x05D7C9u: goto L_05D7C9;
    case 0x05D7CAu: goto L_05D7CA;
    case 0x05D7CBu: goto L_05D7CB;
    case 0x05D7CEu: goto L_05D7CE;
    case 0x05D7D0u: goto L_05D7D0;
    case 0x05D7D2u: goto L_05D7D2;
    case 0x05D7D4u: goto L_05D7D4;
    case 0x05D7D7u: goto L_05D7D7;
    case 0x05D7D9u: goto L_05D7D9;
    case 0x05D7DBu: goto L_05D7DB;
    case 0x05D7DEu: goto L_05D7DE;
    case 0x05D7E0u: goto L_05D7E0;
    case 0x05D7E2u: goto L_05D7E2;
    case 0x05D7E5u: goto L_05D7E5;
    case 0x05D7E7u: goto L_05D7E7;
    case 0x05D7EAu: goto L_05D7EA;
    case 0x05D7EDu: goto L_05D7ED;
    case 0x05D7EFu: goto L_05D7EF;
    case 0x05D7F1u: goto L_05D7F1;
    case 0x05D7F2u: goto L_05D7F2;
    case 0x05D7F6u: goto L_05D7F6;
    case 0x05D7F8u: goto L_05D7F8;
    case 0x05D7FCu: goto L_05D7FC;
    case 0x05D7FEu: goto L_05D7FE;
    case 0x05D800u: goto L_05D800;
    case 0x05D802u: goto L_05D802;
    case 0x05D803u: goto L_05D803;
    case 0x05D804u: goto L_05D804;
    case 0x05D805u: goto L_05D805;
    case 0x05D806u: goto L_05D806;
    case 0x05D807u: goto L_05D807;
    case 0x05D80Bu: goto L_05D80B;
    case 0x05D80Du: goto L_05D80D;
    case 0x05D80Fu: goto L_05D80F;
    case 0x05D810u: goto L_05D810;
    case 0x05D811u: goto L_05D811;
    case 0x05D812u: goto L_05D812;
    case 0x05D813u: goto L_05D813;
    case 0x05D814u: goto L_05D814;
    case 0x05D815u: goto L_05D815;
    case 0x05D816u: goto L_05D816;
    case 0x05D81Au: goto L_05D81A;
    case 0x05D81Cu: goto L_05D81C;
    case 0x05D81Fu: goto L_05D81F;
    case 0x05D821u: goto L_05D821;
    case 0x05D822u: goto L_05D822;
    case 0x05D823u: goto L_05D823;
    case 0x05D824u: goto L_05D824;
    case 0x05D825u: goto L_05D825;
    case 0x05D826u: goto L_05D826;
    case 0x05D827u: goto L_05D827;
    case 0x05D82Bu: goto L_05D82B;
    case 0x05D82Du: goto L_05D82D;
    case 0x05D831u: goto L_05D831;
    case 0x05D833u: goto L_05D833;
    case 0x05D836u: goto L_05D836;
    case 0x05D838u: goto L_05D838;
    case 0x05D83Bu: goto L_05D83B;
    case 0x05D83Eu: goto L_05D83E;
    case 0x05D840u: goto L_05D840;
    case 0x05D842u: goto L_05D842;
    case 0x05D845u: goto L_05D845;
    case 0x05D847u: goto L_05D847;
    case 0x05D849u: goto L_05D849;
    case 0x05D84Bu: goto L_05D84B;
    case 0x05D84Du: goto L_05D84D;
    case 0x05D850u: goto L_05D850;
    case 0x05D853u: goto L_05D853;
    case 0x05D856u: goto L_05D856;
    case 0x05D858u: goto L_05D858;
    case 0x05D85Bu: goto L_05D85B;
    case 0x05D85Eu: goto L_05D85E;
    case 0x05D85Fu: goto L_05D85F;
    case 0x05D860u: goto L_05D860;
    case 0x05D861u: goto L_05D861;
    case 0x05D862u: goto L_05D862;
    case 0x05D864u: goto L_05D864;
    case 0x05D867u: goto L_05D867;
    case 0x05D86Au: goto L_05D86A;
    case 0x05D86Bu: goto L_05D86B;
    case 0x05D86Cu: goto L_05D86C;
    case 0x05D86Du: goto L_05D86D;
    case 0x05D86Eu: goto L_05D86E;
    case 0x05D870u: goto L_05D870;
    case 0x05D872u: goto L_05D872;
    case 0x05D875u: goto L_05D875;
    case 0x05D878u: goto L_05D878;
    case 0x05D879u: goto L_05D879;
    case 0x05D87Au: goto L_05D87A;
    case 0x05D87Bu: goto L_05D87B;
    case 0x05D87Cu: goto L_05D87C;
    case 0x05D87Du: goto L_05D87D;
    case 0x05D87Fu: goto L_05D87F;
    case 0x05D881u: goto L_05D881;
    case 0x05D882u: goto L_05D882;
    case 0x05D885u: goto L_05D885;
    case 0x05D888u: goto L_05D888;
    case 0x05D889u: goto L_05D889;
    case 0x05D88Au: goto L_05D88A;
    case 0x05D88Bu: goto L_05D88B;
    case 0x05D88Eu: goto L_05D88E;
    case 0x05D891u: goto L_05D891;
    case 0x05D893u: goto L_05D893;
    case 0x05D894u: goto L_05D894;
    case 0x05D895u: goto L_05D895;
    case 0x05D898u: goto L_05D898;
    case 0x05D899u: goto L_05D899;
    case 0x05D89Bu: goto L_05D89B;
    case 0x05D89Fu: goto L_05D89F;
    case 0x05D8A2u: goto L_05D8A2;
    case 0x05D8A4u: goto L_05D8A4;
    case 0x05D8A6u: goto L_05D8A6;
    case 0x05D8A7u: goto L_05D8A7;
    case 0x05D8A9u: goto L_05D8A9;
    case 0x05D8ACu: goto L_05D8AC;
    case 0x05D8AEu: goto L_05D8AE;
    case 0x05D8B1u: goto L_05D8B1;
    case 0x05D8B3u: goto L_05D8B3;
    case 0x05D8B5u: goto L_05D8B5;
    case 0x05D8B7u: goto L_05D8B7;
    case 0x05D8B9u: goto L_05D8B9;
    case 0x05D8BBu: goto L_05D8BB;
    case 0x05D8BCu: goto L_05D8BC;
    case 0x05D8BDu: goto L_05D8BD;
    case 0x05D8BFu: goto L_05D8BF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05D796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD796u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD796u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05D796 PHB
    cpu.push("PHB", hw);
    goto L_05D797;
L_05D797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD797u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD797u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05D797 PHK
    cpu.push("PHK", hw);
    goto L_05D798;
L_05D798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD798u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD798u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05D798 PLB
    cpu.pop("PLB", hw);
    goto L_05D799;
L_05D799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD799u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD799u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D799 SEP
    cpu.sep(0x30u);
    goto L_05D79B;
L_05D79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Bu, 4u, 3u, cpu.address("abs", 0x13CFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D79B STZ
    hw.write(cpu.address("abs", 0x13CFu), 0, cpu.m8?8:16);
    goto L_05D79E;
L_05D79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Eu, 4u, 3u, cpu.address("abs", 0x1B95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D79E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B95u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D7A1;
L_05D7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7A1 BNE -> $05D7A8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05D7A8; }
    goto L_05D7A3;
L_05D7A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A3u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A3u, 4u, 3u, cpu.address("abs", 0x1425u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7A3 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1425u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05D7A6;
L_05D7A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7A6 BEQ -> $05D7AB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05D7AB; }
    goto L_05D7A8;
L_05D7A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A8u, 6u, 3u, cpu.address("abs", 0xDBACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05D7A8 JSR -> $05DBAC stack real
    { cpu.push16Value(hw,0xD7AAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD7ABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDBACu), 0x05D7A8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_05D7AB;
L_05D7AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7ABu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD7ABu,0x05D7ABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ABu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ABu, 4u, 3u, cpu.address("abs", 0x141Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7AB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D7AE;
L_05D7AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7AEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7AE BNE -> $05D7B3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05D7B3; }
    goto L_05D7B0;
L_05D7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B0u, 3u, 3u, cpu.address("abs", 0xD83Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7B0 JMP -> $05D83E
    goto L_05D83E;
L_05D7B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7B3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x95u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05D7B5;
L_05D7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7B5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D7B7;
L_05D7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7B7 AND
    cpu.logicAnd(0x1u);
    goto L_05D7B9;
L_05D7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7B9 BEQ -> $05D7BD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05D7BD; }
    goto L_05D7BB;
L_05D7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7BB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x97u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05D7BD;
L_05D7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BDu, 4u + ((((0x19B8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x19B8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7BD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x19B8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D7C0;
L_05D7C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C0u, 4u, 3u, cpu.address("abs", 0x17BBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7C0 STA
    hw.write(cpu.address("abs", 0x17BBu), cpu.a, cpu.m8?8:16);
    goto L_05D7C3;
L_05D7C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7C3 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_05D7C5;
L_05D7C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C5u, 4u, 3u, cpu.address("abs", 0x0DD6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7C5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D7C8;
L_05D7C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7C8 LSR
    cpu.lsrA();
    goto L_05D7C9;
L_05D7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7C9 LSR
    cpu.lsrA();
    goto L_05D7CA;
L_05D7CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7CA TAY
    cpu.transfer("TAY");
    goto L_05D7CB;
L_05D7CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CBu, 4u + ((((0x1F11u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1F11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7CB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1F11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D7CE;
L_05D7CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7CE BEQ -> $05D7D2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05D7D2; }
    goto L_05D7D0;
L_05D7D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7D0 LDA
    cpu.setA(0x1u, 8);
    goto L_05D7D2;
L_05D7D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7D2 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_05D7D4;
L_05D7D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D4u, 4u, 3u, cpu.address("abs", 0x1B93u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7D4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B93u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D7D7;
L_05D7D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7D7 BEQ -> $05D83B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05D83B; }
    goto L_05D7D9;
L_05D7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7D9 REP
    cpu.rep(0x30u);
    goto L_05D7DB;
L_05D7DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7DB LDA
    cpu.setA(0x0u, 16);
    goto L_05D7DE;
L_05D7DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DEu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7DE SEP
    cpu.sep(0x20u);
    goto L_05D7E0;
L_05D7E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E0u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7E0 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05D7E2;
L_05D7E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E2u, 4u + 1u, 3u, cpu.address("absy", 0xF800u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7E2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF800u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D7E5;
L_05D7E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7E5 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_05D7E7;
L_05D7E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E7u, 4u, 3u, cpu.address("abs", 0x17BBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7E7 STA
    hw.write(cpu.address("abs", 0x17BBu), cpu.a, cpu.m8?8:16);
    goto L_05D7EA;
L_05D7EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EAu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EAu, 4u + 1u, 3u, cpu.address("absy", 0xFA00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7EA LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xFA00u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D7ED;
L_05D7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7ED STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_05D7EF;
L_05D7EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7EF AND
    cpu.logicAnd(0xFu);
    goto L_05D7F1;
L_05D7F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7F1 TAX
    cpu.transfer("TAX");
    goto L_05D7F2;
L_05D7F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F2u, 5u, 4u, ((0x05D730u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7F2 LDA
    cpu.loadA(hw.readW(((0x5D730u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D7F6;
L_05D7F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7F6 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_05D7F8;
L_05D7F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F8u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F8u, 5u, 4u, ((0x05D740u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7F8 LDA
    cpu.loadA(hw.readW(((0x5D740u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D7FC;
L_05D7FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7FC STA
    hw.write(cpu.address("dp", 0x97u), cpu.a, cpu.m8?8:16);
    goto L_05D7FE;
L_05D7FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D7FE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D800;
L_05D800:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD800u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD800u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD800u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D800 AND
    cpu.logicAnd(0x30u);
    goto L_05D802;
L_05D802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD802u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD802u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D802 LSR
    cpu.lsrA();
    goto L_05D803;
L_05D803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD803u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD803u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD803u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D803 LSR
    cpu.lsrA();
    goto L_05D804;
L_05D804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD804u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD804u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD804u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D804 LSR
    cpu.lsrA();
    goto L_05D805;
L_05D805:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD805u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD805u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD805u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D805 LSR
    cpu.lsrA();
    goto L_05D806;
L_05D806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD806u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD806u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D806 TAX
    cpu.transfer("TAX");
    goto L_05D807;
L_05D807:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD807u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD807u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD807u, 5u, 4u, ((0x05D708u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D807 LDA
    cpu.loadA(hw.readW(((0x5D708u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D80B;
L_05D80B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D80B STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_05D80D;
L_05D80D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D80D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D80F;
L_05D80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D80F LSR
    cpu.lsrA();
    goto L_05D810;
L_05D810:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD810u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD810u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD810u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D810 LSR
    cpu.lsrA();
    goto L_05D811;
L_05D811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD811u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD811u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D811 LSR
    cpu.lsrA();
    goto L_05D812;
L_05D812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD812u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD812u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D812 LSR
    cpu.lsrA();
    goto L_05D813;
L_05D813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD813u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD813u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D813 LSR
    cpu.lsrA();
    goto L_05D814;
L_05D814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD814u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD814u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD814u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D814 LSR
    cpu.lsrA();
    goto L_05D815;
L_05D815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD815u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD815u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D815 TAX
    cpu.transfer("TAX");
    goto L_05D816;
L_05D816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD816u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD816u, 5u, 4u, ((0x05D70Cu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D816 LDA
    cpu.loadA(hw.readW(((0x5D70Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D81A;
L_05D81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD81Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D81A STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_05D81C;
L_05D81C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD81Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Cu, 4u + 1u, 3u, cpu.address("absy", 0xFC00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D81C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xFC00u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D81F;
L_05D81F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD81Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD81Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D81F STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_05D821;
L_05D821:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD821u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD821u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD821u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D821 LSR
    cpu.lsrA();
    goto L_05D822;
L_05D822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD822u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD822u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D822 LSR
    cpu.lsrA();
    goto L_05D823;
L_05D823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD823u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD823u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D823 LSR
    cpu.lsrA();
    goto L_05D824;
L_05D824:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD824u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD824u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD824u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D824 LSR
    cpu.lsrA();
    goto L_05D825;
L_05D825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD825u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD825u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD825u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D825 LSR
    cpu.lsrA();
    goto L_05D826;
L_05D826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD826u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD826u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD826u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D826 TAX
    cpu.transfer("TAX");
    goto L_05D827;
L_05D827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD827u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD827u, 5u, 4u, ((0x05D750u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D827 LDA
    cpu.loadA(hw.readW(((0x5D750u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D82B;
L_05D82B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD82Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D82B STA
    hw.write(cpu.address("dp", 0x94u), cpu.a, cpu.m8?8:16);
    goto L_05D82D;
L_05D82D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD82Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD82Du, 5u, 4u, ((0x05D758u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D82D LDA
    cpu.loadA(hw.readW(((0x5D758u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D831;
L_05D831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD831u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD831u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x95u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D831 STA
    hw.write(cpu.address("dp", 0x95u), cpu.a, cpu.m8?8:16);
    goto L_05D833;
L_05D833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD833u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD833u, 4u + 1u, 3u, cpu.address("absy", 0xFE00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D833 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xFE00u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D836;
L_05D836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD836u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD836u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D836 AND
    cpu.logicAnd(0x7u);
    goto L_05D838;
L_05D838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD838u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD838u, 4u, 3u, cpu.address("abs", 0x192Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D838 STA
    hw.write(cpu.address("abs", 0x192Au), cpu.a, cpu.m8?8:16);
    goto L_05D83B;
L_05D83B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD83Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Bu, 3u, 3u, cpu.address("abs", 0xD8B7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D83B JMP -> $05D8B7
    goto L_05D8B7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Bu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Bu, 3u, 3u, cpu.address("abs", 0xD8B7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D83B JMP -> $05D8B7
    goto L_05D8B7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD83Bu,0x05D83Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05D83E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD83Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD83Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D83E STZ
    hw.write(cpu.address("dp", 0xFu), 0, cpu.m8?8:16);
    goto L_05D840;
L_05D840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD840u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD840u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D840 LDY
    cpu.setY(0x0u, 8);
    goto L_05D842;
L_05D842:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD842u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD842u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD842u, 4u, 3u, cpu.address("abs", 0x0109u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D842 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x109u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D845;
L_05D845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD845u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD845u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D845 BNE -> $05D8A2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_05D8A2; }
    goto L_05D847;
L_05D847:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD847u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD847u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD847u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D847 REP
    cpu.rep(0x30u);
    goto L_05D849;
L_05D849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD849u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD849u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD849u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D849 STZ
    hw.write(cpu.address("dp", 0x1Au), 0, cpu.m8?8:16);
    goto L_05D84B;
L_05D84B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD84Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD84Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD84Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D84B STZ
    hw.write(cpu.address("dp", 0x1Eu), 0, cpu.m8?8:16);
    goto L_05D84D;
L_05D84D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD84Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD84Du,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD84Du, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D84D LDX
    cpu.setX(hw.readW(cpu.address("abs", 0xDD6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_05D850;
L_05D850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD850u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD850u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD850u, 5u + 1u, 3u, cpu.address("absx", 0x1F1Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D850 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F1Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D853;
L_05D853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD853u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD853u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D853 AND
    cpu.logicAnd(0xFu);
    goto L_05D856;
L_05D856:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD856u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD856u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD856u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D856 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_05D858;
L_05D858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD858u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD858u, 5u + 1u, 3u, cpu.address("absx", 0x1F21u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D858 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F21u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D85B;
L_05D85B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD85Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D85B AND
    cpu.logicAnd(0xFu);
    goto L_05D85E;
L_05D85E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD85Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D85E ASL
    cpu.aslA();
    goto L_05D85F;
L_05D85F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD85Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD85Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D85F ASL
    cpu.aslA();
    goto L_05D860;
L_05D860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD860u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD860u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D860 ASL
    cpu.aslA();
    goto L_05D861;
L_05D861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD861u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD861u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD861u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D861 ASL
    cpu.aslA();
    goto L_05D862;
L_05D862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD862u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD862u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D862 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_05D864;
L_05D864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD864u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD864u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD864u, 5u + 1u, 3u, cpu.address("absx", 0x1F1Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D864 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F1Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D867;
L_05D867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD867u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD867u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D867 AND
    cpu.logicAnd(0x10u);
    goto L_05D86A;
L_05D86A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD86Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD86Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD86Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D86A ASL
    cpu.aslA();
    goto L_05D86B;
L_05D86B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD86Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD86Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD86Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D86B ASL
    cpu.aslA();
    goto L_05D86C;
L_05D86C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD86Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD86Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD86Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D86C ASL
    cpu.aslA();
    goto L_05D86D;
L_05D86D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD86Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD86Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD86Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D86D ASL
    cpu.aslA();
    goto L_05D86E;
L_05D86E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD86Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD86Eu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD86Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D86E ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_05D870;
L_05D870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD870u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD870u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D870 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_05D872;
L_05D872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD872u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD872u, 5u + 1u, 3u, cpu.address("absx", 0x1F21u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D872 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F21u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D875;
L_05D875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD875u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD875u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D875 AND
    cpu.logicAnd(0x10u);
    goto L_05D878;
L_05D878:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD878u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD878u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD878u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D878 ASL
    cpu.aslA();
    goto L_05D879;
L_05D879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD879u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD879u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D879 ASL
    cpu.aslA();
    goto L_05D87A;
L_05D87A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD87Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD87Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD87Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D87A ASL
    cpu.aslA();
    goto L_05D87B;
L_05D87B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD87Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD87Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD87Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D87B ASL
    cpu.aslA();
    goto L_05D87C;
L_05D87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD87Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD87Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D87C ASL
    cpu.aslA();
    goto L_05D87D;
L_05D87D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD87Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD87Du,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD87Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D87D ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_05D87F;
L_05D87F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD87Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD87Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD87Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D87F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_05D881;
L_05D881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD881u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD881u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D881 TAX
    cpu.transfer("TAX");
    goto L_05D882;
L_05D882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD882u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD882u, 5u, 3u, cpu.address("abs", 0x0DD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D882 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xDD6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D885;
L_05D885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD885u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD885u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D885 AND
    cpu.logicAnd(0xFFu);
    goto L_05D888;
L_05D888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD888u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD888u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D888 LSR
    cpu.lsrA();
    goto L_05D889;
L_05D889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD889u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD889u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD889u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D889 LSR
    cpu.lsrA();
    goto L_05D88A;
L_05D88A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD88Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D88A TAY
    cpu.transfer("TAY");
    goto L_05D88B;
L_05D88B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD88Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Bu, 5u + 1u, 3u, cpu.address("absy", 0x1F11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D88B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1F11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D88E;
L_05D88E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD88Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D88E AND
    cpu.logicAnd(0xFu);
    goto L_05D891;
L_05D891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD891u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD891u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D891 BEQ -> $05D899
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05D899; }
    goto L_05D893;
L_05D893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD893u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD893u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D893 TXA
    cpu.transfer("TXA");
    goto L_05D894;
L_05D894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD894u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD894u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D894 CLC
    cpu.setFlag('C', false);
    goto L_05D895;
L_05D895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD895u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD895u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD895u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D895 ADC
    cpu.adc(0x400u);
    goto L_05D898;
L_05D898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD898u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD898u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD898u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D898 TAX
    cpu.transfer("TAX");
    goto L_05D899;
L_05D899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD899u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD899u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D899 SEP
    cpu.sep(0x20u);
    goto L_05D89B;
L_05D89B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD89Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Bu, 5u, 4u, ((0x7ED000u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D89B LDA
    cpu.loadA(hw.readW(((0x7ED000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D89F;
L_05D89F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD89Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Fu, 4u, 3u, cpu.address("abs", 0x13BFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D89F STA
    hw.write(cpu.address("abs", 0x13BFu), cpu.a, cpu.m8?8:16);
    goto L_05D8A2;
L_05D8A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8A2 CMP
    cpu.compareA(0x25u);
    goto L_05D8A4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8A2 CMP
    cpu.compareA(0x25u);
    goto L_05D8A4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8A2u,0x05D8A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05D8A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A4u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8A4 BCC -> $05D8A9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_05D8A9; }
    goto L_05D8A6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A4u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8A4 BCC -> $05D8A9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_05D8A9; }
    goto L_05D8A6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8A4u,0x05D8A4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05D8A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8A6 SEC
    cpu.setFlag('C', true);
    goto L_05D8A7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8A6 SEC
    cpu.setFlag('C', true);
    goto L_05D8A7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8A6u,0x05D8A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05D8A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A7u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8A7 SBC
    cpu.sbc(0x24u);
    goto L_05D8A9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A7u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8A7 SBC
    cpu.sbc(0x24u);
    goto L_05D8A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8A7u,0x05D8A7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05D8A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A9u, 4u, 3u, cpu.address("abs", 0x17BBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8A9 STA
    hw.write(cpu.address("abs", 0x17BBu), cpu.a, cpu.m8?8:16);
    goto L_05D8AC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A9u, 4u, 3u, cpu.address("abs", 0x17BBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8A9 STA
    hw.write(cpu.address("abs", 0x17BBu), cpu.a, cpu.m8?8:16);
    goto L_05D8AC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8A9u,0x05D8A9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05D8AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8ACu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8ACu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8AC STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_05D8AE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8ACu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8AC STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_05D8AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8ACu,0x05D8ACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05D8AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8AEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8AEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8AEu, 4u + 1u, 3u, cpu.address("absy", 0x1F11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8AE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1F11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D8B1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8AEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8AEu, 4u + ((((0x1F11u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x1F11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8AE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1F11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D8B1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8AEu,0x05D8AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05D8B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8B1 BEQ -> $05D8B5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05D8B5; }
    goto L_05D8B3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8B1 BEQ -> $05D8B5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_05D8B5; }
    goto L_05D8B3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8B1u,0x05D8B1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05D8B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8B3 LDA
    cpu.setA(0x1u, 8);
    goto L_05D8B5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8B3 LDA
    cpu.setA(0x1u, 8);
    goto L_05D8B5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8B3u,0x05D8B3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05D8B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8B5 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_05D8B7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8B5 STA
    hw.write(cpu.address("dp", 0xFu), cpu.a, cpu.m8?8:16);
    goto L_05D8B7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8B5u,0x05D8B5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05D8B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8B7 REP
    cpu.rep(0x30u);
    goto L_05D8B9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8B7 REP
    cpu.rep(0x30u);
    goto L_05D8B9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8B7u,0x05D8B7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_05D8B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8B9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05D8BB;
L_05D8BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8BB ASL
    cpu.aslA();
    goto L_05D8BC;
L_05D8BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8BC CLC
    cpu.setFlag('C', false);
    goto L_05D8BD;
L_05D8BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BDu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8BD ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    goto L_05D8BF;
L_05D8BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BFu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05D8BF TAY
    cpu.transfer("TAY");
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8C0u,0x05D8BFu); return;
}

void sub_0CD4F8_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CD4F8u: goto L_0CD4F8;
    case 0x0CD4FBu: goto L_0CD4FB;
    case 0x0CD4FDu: goto L_0CD4FD;
    case 0x0CD500u: goto L_0CD500;
    case 0x0CD502u: goto L_0CD502;
    case 0x0CD504u: goto L_0CD504;
    case 0x0CD506u: goto L_0CD506;
    case 0x0CD509u: goto L_0CD509;
    case 0x0CD50Cu: goto L_0CD50C;
    case 0x0CD50Fu: goto L_0CD50F;
    case 0x0CD511u: goto L_0CD511;
    case 0x0CD512u: goto L_0CD512;
    case 0x0CD514u: goto L_0CD514;
    case 0x0CD516u: goto L_0CD516;
    case 0x0CD519u: goto L_0CD519;
    case 0x0CD51Bu: goto L_0CD51B;
    case 0x0CD51Du: goto L_0CD51D;
    case 0x0CD51Fu: goto L_0CD51F;
    case 0x0CD521u: goto L_0CD521;
    case 0x0CD523u: goto L_0CD523;
    case 0x0CD525u: goto L_0CD525;
    case 0x0CD527u: goto L_0CD527;
    case 0x0CD529u: goto L_0CD529;
    case 0x0CD52Au: goto L_0CD52A;
    case 0x0CD52Cu: goto L_0CD52C;
    case 0x0CD52Fu: goto L_0CD52F;
    case 0x0CD532u: goto L_0CD532;
    case 0x0CD533u: goto L_0CD533;
    case 0x0CD535u: goto L_0CD535;
    case 0x0CD536u: goto L_0CD536;
    case 0x0CD538u: goto L_0CD538;
    case 0x0CD53Bu: goto L_0CD53B;
    case 0x0CD53Eu: goto L_0CD53E;
    case 0x0CD540u: goto L_0CD540;
    case 0x0CD541u: goto L_0CD541;
    case 0x0CD542u: goto L_0CD542;
    case 0x0CD543u: goto L_0CD543;
    case 0x0CD544u: goto L_0CD544;
    case 0x0CD547u: goto L_0CD547;
    case 0x0CD54Au: goto L_0CD54A;
    case 0x0CD54Cu: goto L_0CD54C;
    case 0x0CD54Fu: goto L_0CD54F;
    case 0x0CD550u: goto L_0CD550;
    case 0x0CD551u: goto L_0CD551;
    case 0x0CD552u: goto L_0CD552;
    case 0x0CD553u: goto L_0CD553;
    case 0x0CD556u: goto L_0CD556;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CD4F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F8u, 4u, 3u, cpu.address("abs", 0x1446u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD4F8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1446u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD4FB;
L_0CD4FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD4FB BNE -> $0CD502
    if (!cpu.z) { hw.addCpuInternalCycles(2u); goto L_0CD502; }
    goto L_0CD4FD;
L_0CD4FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FDu, 4u, 3u, cpu.address("abs", 0x0B43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD4FD STZ
    hw.write(cpu.address("abs", 0xB43u), 0, cpu.m8?8:16);
    goto L_0CD500;
L_0CD500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD500u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD500u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD500 BRA -> $0CD556
    goto L_0CD556;
L_0CD502:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD502u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD502u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD502u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD502 LDX
    cpu.setX(0x2u, 8);
    goto L_0CD504;
L_0CD504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD504u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD504u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD504 LDA
    cpu.setA(0xFDu, 8);
    goto L_0CD506;
L_0CD506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD506u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD506u, 5u, 3u, cpu.address("absx", 0x0B05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD506 STA
    hw.write(cpu.address("absx", 0xB05u), cpu.a, cpu.m8?8:16);
    goto L_0CD509;
L_0CD509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD509u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD509u, 6u, 3u, cpu.address("abs", 0xD33Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CD509 JSR -> $0CD33A stack real
    { cpu.push16Value(hw,0xD50Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD50Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD33Au), 0x0CD509u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0CD50C;
L_0CD50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD50Cu))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD50Cu,0x0CD50Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Cu, 4u + ((((0x0B41u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0B41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD50C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB41u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD50F;
L_0CD50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD50Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Fu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD50F EOR
    cpu.logicXor(0xFFu);
    goto L_0CD511;
L_0CD511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD511u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD511u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD511 INC
    cpu.inc('A');
    goto L_0CD512;
L_0CD512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD512u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD512u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD512 CMP
    cpu.compareA(0xDu);
    goto L_0CD514;
L_0CD514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD514u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD514u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD514 BCC -> $0CD51B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0CD51B; }
    goto L_0CD516;
L_0CD516:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD516u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD516u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD516u, 4u, 3u, cpu.address("abs", 0x1446u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD516 STZ
    hw.write(cpu.address("abs", 0x1446u), 0, cpu.m8?8:16);
    goto L_0CD519;
L_0CD519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD519u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD519u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD519 BRA -> $0CD556
    goto L_0CD556;
L_0CD51B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD51Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD51B LDX
    cpu.setX(0x0u, 8);
    goto L_0CD51D;
L_0CD51D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD51Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x19u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD51D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x19u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD51F;
L_0CD51F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD51Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD51F BNE -> $0CD523
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CD523; }
    goto L_0CD521;
L_0CD521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD521u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD521u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD521 LDX
    cpu.setX(0x8u, 8);
    goto L_0CD523;
L_0CD523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD523u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD523u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD523 STX
    hw.write(cpu.address("dp", 0x0u), cpu.x, cpu.x8?8:16);
    goto L_0CD525;
L_0CD525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD525u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD525u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD525 LDX
    cpu.setX(0x34u, 8);
    goto L_0CD527;
L_0CD527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD527u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD527u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD527u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD527 LDA
    cpu.setA(0x4u, 8);
    goto L_0CD529;
L_0CD529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD529u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD529u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD529 CLC
    cpu.setFlag('C', false);
    goto L_0CD52A;
L_0CD52A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Au,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD52A ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_0CD52C;
L_0CD52C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Cu, 5u, 3u, cpu.address("absx", 0x0200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD52C STA
    hw.write(cpu.address("absx", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_0CD52F;
L_0CD52F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Fu, 4u, 3u, cpu.address("abs", 0x0B43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD52F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xB43u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD532;
L_0CD532:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD532u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD532u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD532u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD532 CLC
    cpu.setFlag('C', false);
    goto L_0CD533;
L_0CD533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD533u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD533u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD533u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD533 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16));
    goto L_0CD535;
L_0CD535:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD535u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD535u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD535u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD535 CLC
    cpu.setFlag('C', false);
    goto L_0CD536;
L_0CD536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD536u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD536u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD536 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_0CD538;
L_0CD538:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD538u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD538u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD538u, 5u, 3u, cpu.address("absx", 0x0201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD538 STA
    hw.write(cpu.address("absx", 0x201u), cpu.a, cpu.m8?8:16);
    goto L_0CD53B;
L_0CD53B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD53Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Bu, 4u, 3u, cpu.address("abs", 0x0B43u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD53B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xB43u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD53E;
L_0CD53E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD53Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Eu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD53E EOR
    cpu.logicXor(0xFFu);
    goto L_0CD540;
L_0CD540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD540u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD540u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD540 INC
    cpu.inc('A');
    goto L_0CD541;
L_0CD541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD541u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD541u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD541 LSR
    cpu.lsrA();
    goto L_0CD542;
L_0CD542:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD542u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD542u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD542u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD542 LSR
    cpu.lsrA();
    goto L_0CD543;
L_0CD543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD543u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD543u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD543u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD543 TAY
    cpu.transfer("TAY");
    goto L_0CD544;
L_0CD544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD544u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD544u, 4u + ((((0xD4F4u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xD4F4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD544 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD4F4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CD547;
L_0CD547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD547u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD547u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD547u, 5u, 3u, cpu.address("absx", 0x0202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD547 STA
    hw.write(cpu.address("absx", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_0CD54A;
L_0CD54A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD54Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD54A LDA
    cpu.setA(0x33u, 8);
    goto L_0CD54C;
L_0CD54C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD54Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Cu, 5u, 3u, cpu.address("absx", 0x0203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD54C STA
    hw.write(cpu.address("absx", 0x203u), cpu.a, cpu.m8?8:16);
    goto L_0CD54F;
L_0CD54F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD54Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD54F TXA
    cpu.transfer("TXA");
    goto L_0CD550;
L_0CD550:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD550u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD550u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD550u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD550 LSR
    cpu.lsrA();
    goto L_0CD551;
L_0CD551:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD551u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD551u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD551u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD551 LSR
    cpu.lsrA();
    goto L_0CD552;
L_0CD552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD552u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD552u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD552 TAX
    cpu.transfer("TAX");
    goto L_0CD553;
L_0CD553:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD553u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD553u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD553u, 5u, 3u, cpu.address("absx", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CD553 STZ
    hw.write(cpu.address("absx", 0x420u), 0, cpu.m8?8:16);
    goto L_0CD556;
L_0CD556:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD556u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD556u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD556u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CD556 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CD556u);return;} hw.unresolvedReturn(0x0CD556u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DEE89_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DEE89u: goto L_0DEE89;
    case 0x0DEE8Bu: goto L_0DEE8B;
    case 0x0DEE8Du: goto L_0DEE8D;
    case 0x0DEE8Fu: goto L_0DEE8F;
    case 0x0DEE91u: goto L_0DEE91;
    case 0x0DEE93u: goto L_0DEE93;
    case 0x0DEE94u: goto L_0DEE94;
    case 0x0DEE95u: goto L_0DEE95;
    case 0x0DEE96u: goto L_0DEE96;
    case 0x0DEE97u: goto L_0DEE97;
    case 0x0DEE99u: goto L_0DEE99;
    case 0x0DEE9Cu: goto L_0DEE9C;
    case 0x0DEE9Fu: goto L_0DEE9F;
    case 0x0DEEA1u: goto L_0DEEA1;
    case 0x0DEEA4u: goto L_0DEEA4;
    case 0x0DEEA6u: goto L_0DEEA6;
    case 0x0DEEA8u: goto L_0DEEA8;
    case 0x0DEEABu: goto L_0DEEAB;
    case 0x0DEEADu: goto L_0DEEAD;
    case 0x0DEEB0u: goto L_0DEEB0;
    case 0x0DEEB1u: goto L_0DEEB1;
    case 0x0DEEB3u: goto L_0DEEB3;
    case 0x0DEEB6u: goto L_0DEEB6;
    case 0x0DEEB9u: goto L_0DEEB9;
    case 0x0DEEBBu: goto L_0DEEBB;
    case 0x0DEEBDu: goto L_0DEEBD;
    case 0x0DEEBFu: goto L_0DEEBF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DEE89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE89u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE89 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DEE8B;
L_0DEE8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE8B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DEE8D;
L_0DEE8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE8D AND
    cpu.logicAnd(0xFu);
    goto L_0DEE8F;
L_0DEE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE8Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE8F STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DEE91;
L_0DEE91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE91u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE91u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE91 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DEE93;
L_0DEE93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE93u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE93u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE93 LSR
    cpu.lsrA();
    goto L_0DEE94;
L_0DEE94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE94 LSR
    cpu.lsrA();
    goto L_0DEE95;
L_0DEE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE95 LSR
    cpu.lsrA();
    goto L_0DEE96;
L_0DEE96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE96 LSR
    cpu.lsrA();
    goto L_0DEE97;
L_0DEE97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE97u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE97u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE97 STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_0DEE99;
L_0DEE99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE99u, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEE99 JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xEE9Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DEE99u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEE9C;
L_0DEE9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,0x0DEE9Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Cu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEE9C JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xEE9Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DEE9Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEE9F;
L_0DEE9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEE9Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,0x0DEE9Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEE9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEE9F LDA
    cpu.setA(0x5Cu, 8);
    goto L_0DEEA1;
L_0DEEA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA1u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEEA1 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xEEA3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEA4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DEEA1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEEA4;
L_0DEEA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEA4u,0x0DEEA4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA4u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEEA4 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DEEA6;
L_0DEEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEEA6 BEQ -> $0DEEB3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DEEB3; }
    goto L_0DEEA8;
L_0DEEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEA8u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEEA8 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xEEAAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEABu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DEEA8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEEAB;
L_0DEEAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEABu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEABu,0x0DEEABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEEAB LDA
    cpu.setA(0x53u, 8);
    goto L_0DEEAD;
L_0DEEAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEADu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEADu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEEAD JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xEEAFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEB0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DEEADu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEEB0;
L_0DEEB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB0u,0x0DEEB0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEEB0 DEX
    cpu.decReg('X');
    goto L_0DEEB1;
L_0DEEB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEEB1 BPL -> $0DEEA8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DEEA8; }
    goto L_0DEEB3;
L_0DEEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB3u, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEEB3 JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xEEB5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEB6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DEEB3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEEB6;
L_0DEEB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB6u,0x0DEEB6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB6u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEEB6 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xEEB8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEEB9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DEEB6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DEEB9;
L_0DEEB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEB9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEB9u,0x0DEEB9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEB9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEEB9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DEEBB;
L_0DEEBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEEBB DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0DEEBD;
L_0DEEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBDu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DEEBD BPL -> $0DEE9C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DEE9C; }
    goto L_0DEEBF;
L_0DEEBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEBFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DEEBF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DEEBFu);return;} hw.unresolvedReturn(0x0DEEBFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_4C208F_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x4C2063u: goto L_4C2063;
    case 0x4C2066u: goto L_4C2066;
    case 0x4C2069u: goto L_4C2069;
    case 0x4C206Bu: goto L_4C206B;
    case 0x4C206Cu: goto L_4C206C;
    case 0x4C206Fu: goto L_4C206F;
    case 0x4C2072u: goto L_4C2072;
    case 0x4C2075u: goto L_4C2075;
    case 0x4C2078u: goto L_4C2078;
    case 0x4C207Bu: goto L_4C207B;
    case 0x4C207Du: goto L_4C207D;
    case 0x4C2080u: goto L_4C2080;
    case 0x4C2081u: goto L_4C2081;
    case 0x4C2082u: goto L_4C2082;
    case 0x4C2084u: goto L_4C2084;
    case 0x4C2086u: goto L_4C2086;
    case 0x4C2088u: goto L_4C2088;
    case 0x4C208Au: goto L_4C208A;
    case 0x4C208Du: goto L_4C208D;
    case 0x4C208Eu: goto L_4C208E;
    case 0x4C208Fu: goto L_4C208F;
    case 0x4C2093u: goto L_4C2093;
    case 0x4C2094u: goto L_4C2094;
    case 0x4C2096u: goto L_4C2096;
    case 0x4C2098u: goto L_4C2098;
    case 0x4C209Au: goto L_4C209A;
    case 0x4C209Cu: goto L_4C209C;
    case 0x4C20A0u: goto L_4C20A0;
    case 0x4C20A4u: goto L_4C20A4;
    case 0x4C20A8u: goto L_4C20A8;
    case 0x4C20AAu: goto L_4C20AA;
    case 0x4C20ADu: goto L_4C20AD;
    case 0x4C20B1u: goto L_4C20B1;
    case 0x4C20B5u: goto L_4C20B5;
    case 0x4C20B9u: goto L_4C20B9;
    case 0x4C20BDu: goto L_4C20BD;
    case 0x4C20BFu: goto L_4C20BF;
    case 0x4C20C1u: goto L_4C20C1;
    case 0x4C20C4u: goto L_4C20C4;
    case 0x4C20C6u: goto L_4C20C6;
    case 0x4C20CAu: goto L_4C20CA;
    case 0x4C20CEu: goto L_4C20CE;
    case 0x4C20D2u: goto L_4C20D2;
    case 0x4C20D4u: goto L_4C20D4;
    case 0x4C20D6u: goto L_4C20D6;
    case 0x4C20D8u: goto L_4C20D8;
    case 0x4C20DCu: goto L_4C20DC;
    case 0x4C20E0u: goto L_4C20E0;
    case 0x4C20E4u: goto L_4C20E4;
    case 0x4C20E6u: goto L_4C20E6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_4C2063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2063u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2063u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2063u, 4u + ((((0xA04Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA04Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C2063 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA04Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_4C2066;
L_4C2066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2066u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2066u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2066u, 5u, 3u, cpu.address("absx", 0x0B41u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C2066 STA
    hw.write(cpu.address("absx", 0xB41u), cpu.a, cpu.m8?8:16);
    goto L_4C2069;
L_4C2069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2069u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2069u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2069u, 5u, 3u, cpu.address("absx", 0x0B5Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C2069 STZ
    hw.write(cpu.address("absx", 0xB5Fu), 0, cpu.m8?8:16);
    goto L_4C206C;
L_4C206B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x206Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x206Bu,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x206Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $4C206B PHD
    cpu.push("PHD", hw);
    goto L_4C206C;
L_4C206C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x206Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x206Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x206Cu, 4u + ((((0xA043u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA043u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C206C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA043u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_4C206F;
L_4C206F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x206Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x206Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x206Fu, 5u, 3u, cpu.address("absx", 0x0B50u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C206F STA
    hw.write(cpu.address("absx", 0xB50u), cpu.a, cpu.m8?8:16);
    goto L_4C2072;
L_4C2072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2072u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2072u, 5u, 3u, cpu.address("absx", 0x0B6Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C2072 STZ
    hw.write(cpu.address("absx", 0xB6Eu), 0, cpu.m8?8:16);
    goto L_4C2075;
L_4C2075:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2075u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2075u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2075u, 4u + ((((0xA3C2u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA3C2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C2075 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA3C2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_4C2078;
L_4C2078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2078u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2078u, 5u, 3u, cpu.address("absx", 0x0B05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C2078 STA
    hw.write(cpu.address("absx", 0xB05u), cpu.a, cpu.m8?8:16);
    goto L_4C207B;
L_4C207B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x207Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x207Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x207Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C207B LDA
    cpu.setA(0x1u, 8);
    goto L_4C207D;
L_4C207D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x207Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x207Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x207Du, 5u, 3u, cpu.address("absx", 0x0AF6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C207D STA
    hw.write(cpu.address("absx", 0xAF6u), cpu.a, cpu.m8?8:16);
    goto L_4C2080;
L_4C2080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2080u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2080u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C2080 DEY
    cpu.decReg('Y');
    goto L_4C2081;
L_4C2081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2081u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2081u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C2081 DEX
    cpu.decReg('X');
    goto L_4C2082;
L_4C2082:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2082u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2082u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2082u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C2082 CPX
    cpu.compareX(0x6u);
    goto L_4C2084;
L_4C2084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2084u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2084u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2084u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C2084 BNE -> $4C2063
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_4C2063; }
    goto L_4C2086;
L_4C2086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2086u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2086u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2086u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C2086 STZ
    hw.write(cpu.address("dp", 0x76u), 0, cpu.m8?8:16);
    goto L_4C2088;
L_4C2088:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2088u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2088u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2088u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C2088 LDA
    cpu.setA(0xE2u, 8);
    goto L_4C208A;
L_4C208A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x208Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x208Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x208Au, 4u, 3u, cpu.address("abs", 0x1B89u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C208A STA
    hw.write(cpu.address("abs", 0x1B89u), cpu.a, cpu.m8?8:16);
    goto L_4C208D;
L_4C208D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x208Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x208Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x208Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $4C208D PLB
    cpu.pop("PLB", hw);
    goto L_4C208E;
L_4C208E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x208Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x208Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x208Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $4C208E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x4C208Eu);return;} hw.unresolvedReturn(0x4C208Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_4C208F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x208Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x208Fu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x208Fu, 5u, 4u, ((0x060402u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C208F SBC
    cpu.sbc(hw.readW(((0x60402u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_4C2093;
L_4C2093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2093u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2093u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2093u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $4C2093 PHP
    cpu.push("PHP", hw);
    goto L_4C2094;
L_4C2094:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2094u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2094u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2094u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C2094 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_4C2096;
L_4C2096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2096u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2096u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2096u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C2096 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_4C2098;
L_4C2098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2098u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2098u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2098u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C2098 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_4C209A;
L_4C209A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x209Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x209Au,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x209Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C209A TSB
    cpu.tsb(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_4C209C;
L_4C209C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x209Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x209Cu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x209Cu, 5u, 4u, ((0x242220u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C209C SBC
    cpu.sbc(hw.readW(((0x242220u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_4C20A0;
L_4C20A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20A0u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20A0u, 5u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C20A0 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_4C20A4;
L_4C20A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20A4u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20A4u, 5u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C20A4 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_4C20A8;
L_4C20A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20A8u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20A8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C20A8 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16), false);
    goto L_4C20AA;
L_4C20AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20AAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20AAu, 6u, 3u, cpu.address("abs", 0x4240u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $4C20AA JSR -> $4C4240 stack real
    { cpu.push16Value(hw,0x20ACu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x20ADu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x4240u), 0x4C20AAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_4C20AD;
L_4C20AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20ADu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x20ADu,0x4C20ADu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20ADu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20ADu, 5u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C20AD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_4C20B1;
L_4C20B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20B1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20B1u, 5u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C20B1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_4C20B5;
L_4C20B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20B5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20B5u, 5u, 4u, ((0x4042FFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C20B5 SBC
    cpu.sbc(hw.readW(((0x4042FFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_4C20B9;
L_4C20B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20B9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20B9u, 5u, 4u, ((0x353737u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C20B9 SBC
    cpu.sbc(hw.readW(((0x353737u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_4C20BD;
L_4C20BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20BDu,cpu,0x35u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x37u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C20BD AND
    cpu.logicAnd(hw.readW(cpu.address("dpx", 0x37u), cpu.m8?8:16));
    goto L_4C20BF;
L_4C20BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20BFu,cpu,0x37u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20BFu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x39u) & 0xFFFFu), 3u, 0u);
    // $4C20BF AND
    cpu.logicAnd(hw.readW(cpu.addressDpLongY(hw, 0x39u), cpu.m8?8:16));
    goto L_4C20C1;
L_4C20C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20C1u,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20C1u, 4u + ((((0x3B3Bu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x3B3Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C20C1 AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0x3B3Bu), cpu.m8?8:16));
    goto L_4C20C4;
L_4C20C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20C4u,cpu,0x77u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20C4u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x77u) & 0xFFFFu), 3u, 0u);
    // $4C20C4 ADC
    cpu.adc(hw.readW(cpu.addressDpLongY(hw, 0x77u), cpu.m8?8:16));
    goto L_4C20C6;
L_4C20C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20C6u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20C6u, 5u, 4u, ((0x373737u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C20C6 SBC
    cpu.sbc(hw.readW(((0x373737u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_4C20CA;
L_4C20CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20CAu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20CAu, 5u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C20CA SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_4C20CE;
L_4C20CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20CEu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20CEu, 5u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C20CE SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_4C20D2;
L_4C20D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20D2u,cpu,0x77u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20D2u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x77u) & 0xFFFFu), 3u, 0u);
    // $4C20D2 ADC
    cpu.adc(hw.readW(cpu.addressDpLongY(hw, 0x77u), cpu.m8?8:16));
    goto L_4C20D4;
L_4C20D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20D4u,cpu,0x77u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20D4u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x37u) & 0xFFFFu), 3u, 0u);
    // $4C20D4 ADC
    cpu.adc(hw.readW(cpu.addressDpLongY(hw, 0x37u), cpu.m8?8:16));
    goto L_4C20D6;
L_4C20D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20D6u,cpu,0x37u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20D6u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFFu) & 0xFFFFu), 3u, 0u);
    // $4C20D6 AND
    cpu.logicAnd(hw.readW(cpu.addressDpLongY(hw, 0xFFu), cpu.m8?8:16));
    goto L_4C20D8;
L_4C20D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20D8u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20D8u, 5u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C20D8 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_4C20DC;
L_4C20DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20DCu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20DCu, 5u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C20DC SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_4C20E0;
L_4C20E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20E0u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20E0u, 5u, 4u, ((0xA97777u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C20E0 SBC
    cpu.sbc(hw.readW(((0xA97777u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_4C20E4;
L_4C20E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20E4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $4C20E4 BPL -> $4C206B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_4C206B; }
    goto L_4C20E6;
L_4C20E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x20E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x20E6u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x20E6u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $4C20E6 BRK
    hw.partial(0x4C20E6u, "BRK"); return;
}

void sub_B18D0E_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB18D0Eu: goto L_B18D0E;
    case 0xB18D10u: goto L_B18D10;
    case 0xB18D12u: goto L_B18D12;
    case 0xB18D13u: goto L_B18D13;
    case 0xB18D16u: goto L_B18D16;
    case 0xB18D18u: goto L_B18D18;
    case 0xB18D1Au: goto L_B18D1A;
    case 0xB18D1Du: goto L_B18D1D;
    case 0xB18D1Fu: goto L_B18D1F;
    case 0xB18D22u: goto L_B18D22;
    case 0xB18D24u: goto L_B18D24;
    case 0xB18D27u: goto L_B18D27;
    case 0xB18D2Au: goto L_B18D2A;
    case 0xB18D2Du: goto L_B18D2D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B18D0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Eu,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Eu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xA8u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $B18D0E ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0xA8u), cpu.m8?8:16));
    goto L_B18D10;
L_B18D10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D10 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B18D12;
L_B18D12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D12u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D12 CLC
    cpu.setFlag('C', false);
    goto L_B18D13;
L_B18D13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u, 4u + ((((0x8CBAu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8CBAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D13 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x8CBAu), cpu.m8?8:16));
    goto L_B18D16;
L_B18D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xAAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D16 STA
    hw.write(cpu.address("dpx", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B18D18;
L_B18D18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D18 STA
    hw.write(cpu.address("dpx", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_B18D1A;
L_B18D1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au, 4u + ((((0x8CBCu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x8CBCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D1A CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x8CBCu), cpu.m8?8:16));
    goto L_B18D1D;
L_B18D1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D1D BNE -> $B18D27
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_B18D27; }
    goto L_B18D1F;
L_B18D1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Fu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Fu, 7u, 3u, cpu.address("absx", 0x151Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D1F INC
    cpu.incMem(hw, cpu.address("absx", 0x151Cu), cpu.m8?8:16);
    goto L_B18D22;
L_B18D22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D22u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D22 LDA
    cpu.setA(0x30u, 8);
    goto L_B18D24;
L_B18D24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D24u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D24u, 5u, 3u, cpu.address("absx", 0x1540u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18D24 STA
    hw.write(cpu.address("absx", 0x1540u), cpu.a, cpu.m8?8:16);
    goto L_B18D27;
L_B18D27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D27u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D27u, 6u, 3u, cpu.address("abs", 0x8FC1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D27 JSR -> $B18FC1 stack real
    { cpu.push16Value(hw,0x8D29u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D2Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8FC1u), 0xB18D27u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D2A;
L_B18D2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au, 6u, 3u, cpu.address("abs", 0x8CB7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D2A JSR -> $B18CB7 stack real
    { cpu.push16Value(hw,0x8D2Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D2Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8CB7u), 0xB18D2Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D2D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au, 6u, 3u, cpu.address("abs", 0x8CB7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D2A JSR -> $B18CB7 stack real
    { cpu.push16Value(hw,0x8D2Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D2Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8CB7u), 0xB18D2Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D2D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Au, 6u, 3u, cpu.address("abs", 0x8CB7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D2A JSR -> $B18CB7 stack real
    { cpu.push16Value(hw,0x8D2Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D2Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8CB7u), 0xB18D2Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B18D2D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D2Au,0xB18D2Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18D2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D2Du,0xB18D2Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B18D2D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB18D2Du);return;} hw.unresolvedReturn(0xB18D2Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B19523_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB19523u: goto L_B19523;
    case 0xB19525u: goto L_B19525;
    case 0xB19527u: goto L_B19527;
    case 0xB1952Au: goto L_B1952A;
    case 0xB1952Cu: goto L_B1952C;
    case 0xB1952Fu: goto L_B1952F;
    case 0xB19531u: goto L_B19531;
    case 0xB19533u: goto L_B19533;
    case 0xB19537u: goto L_B19537;
    case 0xB19539u: goto L_B19539;
    case 0xB1953Bu: goto L_B1953B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B19523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9523u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9523u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19523 LDA
    cpu.setA(0x7Eu, 8);
    goto L_B19525;
L_B19525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9525u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9525u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19525 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_B19527;
L_B19527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9527u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9527u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9527u, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19527 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1952A;
L_B1952A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Au,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x05u) & 0xFFFFu), 3u, 0u);
    // $B1952A LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1952C;
L_B1952C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Cu, 4u, 3u, cpu.address("abs", 0x1693u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1952C STA
    hw.write(cpu.address("abs", 0x1693u), cpu.a, cpu.m8?8:16);
    goto L_B1952F;
L_B1952F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1952F INC
    cpu.incMem(hw, cpu.address("dp", 0x7u), cpu.m8?8:16);
    goto L_B19531;
L_B19531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9531u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9531u,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9531u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x05u) & 0xFFFFu), 3u, 0u);
    // $B19531 LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19533;
L_B19533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9533u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9533u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9533u, 8u, 4u, 0x00F545u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B19533 JSL -> $00F545 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9536u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9537u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x00F545u, 0xB19533u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B19537;
L_B19537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9537u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9537u,0xB19537u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9537u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9537u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19537 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B19539;
L_B19539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9539u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9539u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9539u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19539 CMP
    cpu.compareA(0x0u);
    goto L_B1953B;
L_B1953B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1953B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1953Bu);return;} hw.unresolvedReturn(0xB1953Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1AD54_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1AD54u: goto L_B1AD54;
    case 0xB1AD58u: goto L_B1AD58;
    case 0xB1AD5Cu: goto L_B1AD5C;
    case 0xB1AD5Du: goto L_B1AD5D;
    case 0xB1AD5Eu: goto L_B1AD5E;
    case 0xB1AD5Fu: goto L_B1AD5F;
    case 0xB1AD61u: goto L_B1AD61;
    case 0xB1AD64u: goto L_B1AD64;
    case 0xB1AD67u: goto L_B1AD67;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1AD54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD54u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD54u, 5u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD54 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_B1AD58;
L_B1AD58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD58u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD58u, 5u, 4u, ((0x4AE4B5u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD58 SBC
    cpu.sbc(hw.readW(((0x4AE4B5u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_B1AD5C;
L_B1AD5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD5C LSR
    cpu.lsrA();
    goto L_B1AD5D;
L_B1AD5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD5D LSR
    cpu.lsrA();
    goto L_B1AD5E;
L_B1AD5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD5E LSR
    cpu.lsrA();
    goto L_B1AD5F;
L_B1AD5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD5F AND
    cpu.logicAnd(0x3u);
    goto L_B1AD61;
L_B1AD61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD61u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD61u, 5u, 3u, cpu.address("absx", 0x151Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD61 STA
    hw.write(cpu.address("absx", 0x151Cu), cpu.a, cpu.m8?8:16);
    goto L_B1AD64;
L_B1AD64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD64u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD64u, 7u, 3u, cpu.address("absx", 0x157Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1AD64 INC
    cpu.incMem(hw, cpu.address("absx", 0x157Cu), cpu.m8?8:16);
    goto L_B1AD67;
L_B1AD67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD67u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD67u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1AD67 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1AD67u);return;} hw.unresolvedReturn(0xB1AD67u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

