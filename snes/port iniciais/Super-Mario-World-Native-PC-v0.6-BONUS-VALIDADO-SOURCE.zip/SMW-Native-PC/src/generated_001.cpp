#include "generated.hpp"
void sub_0082C3_E1M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0082C3u: goto L_0082C3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0082C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0082C3 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x0082C3u);return;}
}

void sub_0082C3_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0082C3u: goto L_0082C3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0082C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0082C3 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x0082C3u);return;}
}

void sub_0092ED_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0092EDu: goto L_0092ED;
    case 0x0092EFu: goto L_0092EF;
    case 0x0092F2u: goto L_0092F2;
    case 0x0092F5u: goto L_0092F5;
    case 0x0092F8u: goto L_0092F8;
    case 0x0092FBu: goto L_0092FB;
    case 0x0092FEu: goto L_0092FE;
    case 0x009301u: goto L_009301;
    case 0x009304u: goto L_009304;
    case 0x009305u: goto L_009305;
    case 0x009306u: goto L_009306;
    case 0x009309u: goto L_009309;
    case 0x00930Au: goto L_00930A;
    case 0x00930Bu: goto L_00930B;
    case 0x00930Cu: goto L_00930C;
    case 0x00930Du: goto L_00930D;
    case 0x00930Eu: goto L_00930E;
    case 0x009310u: goto L_009310;
    case 0x009312u: goto L_009312;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0092ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92EDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92EDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092ED REP
    cpu.rep(0x30u);
    goto L_0092EF;
L_0092EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92EFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092EF LDY
    cpu.setY(0x8u, 16);
    goto L_0092F2;
L_0092F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092F2 LDX
    cpu.setX(0x14u, 16);
    goto L_0092F5;
L_0092F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F5u, 5u + 1u, 3u, cpu.address("absy", 0x001Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092F5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0092F8;
L_0092F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92F8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92F8u, 6u, 3u, cpu.address("absx", 0x04A1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092F8 STA
    hw.write(cpu.address("absx", 0x4A1u), cpu.a, cpu.m8?8:16);
    goto L_0092FB;
L_0092FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FBu, 6u, 3u, cpu.address("absx", 0x04A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092FB STA
    hw.write(cpu.address("absx", 0x4A4u), cpu.a, cpu.m8?8:16);
    goto L_0092FE;
L_0092FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FEu, 5u + 1u, 3u, cpu.address("absy", 0x1462u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0092FE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1462u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_009301;
L_009301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9301u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9301u, 6u, 3u, cpu.address("absx", 0x04A7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009301 STA
    hw.write(cpu.address("absx", 0x4A7u), cpu.a, cpu.m8?8:16);
    goto L_009304;
L_009304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9304u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9304u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9304u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009304 TXA
    cpu.transfer("TXA");
    goto L_009305;
L_009305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009305 SEC
    cpu.setFlag('C', true);
    goto L_009306;
L_009306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9306u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9306u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009306 SBC
    cpu.sbc(0xAu);
    goto L_009309;
L_009309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9309u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9309u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009309 TAX
    cpu.transfer("TAX");
    goto L_00930A;
L_00930A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00930A DEY
    cpu.decReg('Y');
    goto L_00930B;
L_00930B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00930B DEY
    cpu.decReg('Y');
    goto L_00930C;
L_00930C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00930C DEY
    cpu.decReg('Y');
    goto L_00930D;
L_00930D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00930D DEY
    cpu.decReg('Y');
    goto L_00930E;
L_00930E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00930E BPL -> $0092F5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0092F5; }
    goto L_009310;
L_009310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9310u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9310u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $009310 SEP
    cpu.sep(0x30u);
    goto L_009312;
L_009312:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9312u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9312u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9312u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $009312 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x009312u);return;} hw.unresolvedReturn(0x009312u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00C593_E0M1X1CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00DB26u: goto L_00DB26;
    case 0x00DB29u: goto L_00DB29;
    case 0x00DB2Bu: goto L_00DB2B;
    case 0x00DB2Du: goto L_00DB2D;
    case 0x00DB2Eu: goto L_00DB2E;
    case 0x00DB2Fu: goto L_00DB2F;
    case 0x00DB31u: goto L_00DB31;
    case 0x00DB32u: goto L_00DB32;
    case 0x00DB33u: goto L_00DB33;
    case 0x00DB34u: goto L_00DB34;
    case 0x00DB36u: goto L_00DB36;
    case 0x00DB38u: goto L_00DB38;
    case 0x00DB39u: goto L_00DB39;
    case 0x00DB3Bu: goto L_00DB3B;
    case 0x00DB3Du: goto L_00DB3D;
    case 0x00DB3Eu: goto L_00DB3E;
    case 0x00DB40u: goto L_00DB40;
    case 0x00DB42u: goto L_00DB42;
    case 0x00DB45u: goto L_00DB45;
    case 0x00DB46u: goto L_00DB46;
    case 0x00DB47u: goto L_00DB47;
    case 0x00DB48u: goto L_00DB48;
    case 0x00DB4Bu: goto L_00DB4B;
    case 0x00DB4Du: goto L_00DB4D;
    case 0x00DB4Eu: goto L_00DB4E;
    case 0x00DB4Fu: goto L_00DB4F;
    case 0x00DB50u: goto L_00DB50;
    case 0x00DB51u: goto L_00DB51;
    case 0x00DB52u: goto L_00DB52;
    case 0x00DB54u: goto L_00DB54;
    case 0x00DB57u: goto L_00DB57;
    case 0x00DB59u: goto L_00DB59;
    case 0x00DB5Cu: goto L_00DB5C;
    case 0x00DB5Du: goto L_00DB5D;
    case 0x00DB5Eu: goto L_00DB5E;
    case 0x00DB60u: goto L_00DB60;
    case 0x00DB62u: goto L_00DB62;
    case 0x00DB64u: goto L_00DB64;
    case 0x00DB65u: goto L_00DB65;
    case 0x00DB66u: goto L_00DB66;
    case 0x00DB68u: goto L_00DB68;
    case 0x00DB6Bu: goto L_00DB6B;
    case 0x00DB6Cu: goto L_00DB6C;
    case 0x00DB6Fu: goto L_00DB6F;
    case 0x00DB72u: goto L_00DB72;
    case 0x00DB74u: goto L_00DB74;
    case 0x00DB76u: goto L_00DB76;
    case 0x00DB78u: goto L_00DB78;
    case 0x00DB7Bu: goto L_00DB7B;
    case 0x00DB7Du: goto L_00DB7D;
    case 0x00DB7Fu: goto L_00DB7F;
    case 0x00DB81u: goto L_00DB81;
    case 0x00DB84u: goto L_00DB84;
    case 0x00DB87u: goto L_00DB87;
    case 0x00DB89u: goto L_00DB89;
    case 0x00DB8Au: goto L_00DB8A;
    case 0x00DB8Bu: goto L_00DB8B;
    case 0x00DB8Cu: goto L_00DB8C;
    case 0x00DB8Fu: goto L_00DB8F;
    case 0x00DB92u: goto L_00DB92;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00DB26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB26u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB26 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB29;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB26 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB29;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB26u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB26 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB29;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB26u,0x00DB26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB29u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB29 BPL -> $00DB2E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB2E; }
    goto L_00DB2B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB29 BPL -> $00DB2E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB2E; }
    goto L_00DB2B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB29 BPL -> $00DB2E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB2E; }
    goto L_00DB2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB29u,0x00DB29u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB2Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2B EOR
    cpu.logicXor(0xFFu);
    goto L_00DB2D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2B EOR
    cpu.logicXor(0xFFu);
    goto L_00DB2D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2B EOR
    cpu.logicXor(0xFFu);
    goto L_00DB2D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB2Bu,0x00DB2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB2Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2D INC
    cpu.inc('A');
    goto L_00DB2E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2D INC
    cpu.inc('A');
    goto L_00DB2E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2D INC
    cpu.inc('A');
    goto L_00DB2E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB2Du,0x00DB2Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB2Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2E TAX
    cpu.transfer("TAX");
    goto L_00DB2F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2E TAX
    cpu.transfer("TAX");
    goto L_00DB2F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2E TAX
    cpu.transfer("TAX");
    goto L_00DB2F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB2Eu,0x00DB2Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB2Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2F CPY
    cpu.compareY(0x901Eu);
    goto L_00DB32;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2F CPY
    cpu.compareY(0x1Eu);
    goto L_00DB31;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB2F CPY
    cpu.compareY(0x1Eu);
    goto L_00DB31;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB2Fu,0x00DB2Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB31u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB31u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB31 BCC -> $00DB45
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00DB45; }
    goto L_00DB33;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB31u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB31 BCC -> $00DB45
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_00DB45; }
    goto L_00DB33;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB31u,0x00DB31u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB32u,cpu,0x12u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB32u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xBDu) & 0xFFFFu), 2u, 0u);
    // $00DB32 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirect(hw, 0xBDu), cpu.m8?8:16));
    goto L_00DB34;
L_00DB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB33u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB33u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB33u, 4u + ((((0xDADFu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDADFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB33 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDADFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB36;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB33u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB33u, 4u + ((((0xDADFu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDADFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB33 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDADFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB36;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB33u,0x00DB33u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB34u,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB34u, 5u, 4u, ((0x782CDAu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB34 CMP
    cpu.compareA(hw.readW(((0x782CDAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00DB38;
L_00DB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB36u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB36u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB36u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB36 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), false);
    goto L_00DB39;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB36u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB36u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB36 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), false);
    goto L_00DB39;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB36u,0x00DB36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB38u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB38 CLC
    cpu.setFlag('C', false);
    goto L_00DB39;
L_00DB39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB39u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB39 BPL -> $00DB3E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB3E; }
    goto L_00DB3B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB39 BPL -> $00DB3E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB3E; }
    goto L_00DB3B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB39 BPL -> $00DB3E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB3E; }
    goto L_00DB3B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB39u,0x00DB39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB3Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3B EOR
    cpu.logicXor(0xFFu);
    goto L_00DB3D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3B EOR
    cpu.logicXor(0xFFu);
    goto L_00DB3D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3B EOR
    cpu.logicXor(0xFFu);
    goto L_00DB3D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB3Bu,0x00DB3Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB3Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3D INC
    cpu.inc('A');
    goto L_00DB3E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3D INC
    cpu.inc('A');
    goto L_00DB3E;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3D INC
    cpu.inc('A');
    goto L_00DB3E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB3Du,0x00DB3Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB3Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3E STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00DB40;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3E STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00DB40;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB3E STA
    hw.write(cpu.address("dp", 0x7Bu), cpu.a, cpu.m8?8:16);
    goto L_00DB40;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB3Eu,0x00DB3Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB40u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB40u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB40u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB40 STZ
    hw.write(cpu.address("dp", 0x7Au), 0, cpu.m8?8:16);
    goto L_00DB42;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB40u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB40u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB40 STZ
    hw.write(cpu.address("dp", 0x7Au), 0, cpu.m8?8:16);
    goto L_00DB42;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB40u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB40u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB40 STZ
    hw.write(cpu.address("dp", 0x7Au), 0, cpu.m8?8:16);
    goto L_00DB42;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB40u,0x00DB40u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB42u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB42u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB42u, 4u, 3u, cpu.address("abs", 0x13DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB42 STZ
    hw.write(cpu.address("abs", 0x13DAu), 0, cpu.m8?8:16);
    goto L_00DB45;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB42u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB42u, 4u, 3u, cpu.address("abs", 0x13DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB42 STZ
    hw.write(cpu.address("abs", 0x13DAu), 0, cpu.m8?8:16);
    goto L_00DB45;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB42u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB42u, 4u, 3u, cpu.address("abs", 0x13DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB42 STZ
    hw.write(cpu.address("abs", 0x13DAu), 0, cpu.m8?8:16);
    goto L_00DB45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB42u,0x00DB42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB45u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB45u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB45 TXA
    cpu.transfer("TXA");
    goto L_00DB46;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB45u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB45 TXA
    cpu.transfer("TXA");
    goto L_00DB46;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB45u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB45 TXA
    cpu.transfer("TXA");
    goto L_00DB46;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB45u,0x00DB45u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB46u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB46u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB46 ASL
    cpu.aslA();
    goto L_00DB47;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB46u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB46 ASL
    cpu.aslA();
    goto L_00DB47;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB46u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB46 ASL
    cpu.aslA();
    goto L_00DB47;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB46u,0x00DB46u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB47u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB47u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB47 TAX
    cpu.transfer("TAX");
    goto L_00DB48;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB47u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB47 TAX
    cpu.transfer("TAX");
    goto L_00DB48;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB47u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB47 TAX
    cpu.transfer("TAX");
    goto L_00DB48;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB47u,0x00DB47u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB48u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB48u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB48u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB48 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB4B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB48u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB48u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB48 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB4B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB48u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB48u, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB48 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB4B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB48u,0x00DB48u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB4Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB4B CPY
    cpu.compareY(0xB008u);
    goto L_00DB4E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB4B CPY
    cpu.compareY(0x8u);
    goto L_00DB4D;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB4B CPY
    cpu.compareY(0x8u);
    goto L_00DB4D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB4Bu,0x00DB4Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB4Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB4D BCS -> $00DB51
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00DB51; }
    goto L_00DB4F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB4D BCS -> $00DB51
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00DB51; }
    goto L_00DB4F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB4Du,0x00DB4Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Eu,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Eu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    cpu.enterInterrupt(hw,(std::uint32_t(cpu.pb)<<16)|0xDB50u,true);
    hw.requestDispatch(0x0082C3u,0x00DB4Eu);return;
L_00DB4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB4Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Fu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB4F EOR
    cpu.logicXor(0x80u);
    goto L_00DB51;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Fu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB4F EOR
    cpu.logicXor(0x80u);
    goto L_00DB51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB4Fu,0x00DB4Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB50u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB50u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB50 BRA -> $00DB5C
    goto L_00DB5C;
L_00DB51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB51u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB51u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB51 ASL
    cpu.aslA();
    goto L_00DB52;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB51u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB51 ASL
    cpu.aslA();
    goto L_00DB52;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB51u,0x00DB51u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB52u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB52u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB52u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB52 REP
    cpu.rep(0x20u);
    goto L_00DB54;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB52u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB52u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB52 REP
    cpu.rep(0x20u);
    goto L_00DB54;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB52u,0x00DB52u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB54u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB54u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB54u, 5u + ((((0xDAF1u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDAF1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB54 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDAF1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB57;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB54u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB54u, 5u + ((((0xDAF1u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDAF1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB54 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDAF1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB57;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB54u,0x00DB54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB57u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB57u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB57 BCS -> $00DB5D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00DB5D; }
    goto L_00DB59;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB57u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB57 BCS -> $00DB5D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00DB5D; }
    goto L_00DB59;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB57u,0x00DB57u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB59u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB59u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB59u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB59 EOR
    cpu.logicXor(0xFFFFu);
    goto L_00DB5C;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB59u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB59u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB59 EOR
    cpu.logicXor(0xFFFFu);
    goto L_00DB5C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB59u,0x00DB59u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB5Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Cu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB5C INC
    cpu.inc('A');
    goto L_00DB5D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Cu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB5C INC
    cpu.inc('A');
    goto L_00DB5D;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Cu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB5C INC
    cpu.inc('A');
    goto L_00DB5D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB5Cu,0x00DB5Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB5Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB5D CLC
    cpu.setFlag('C', false);
    goto L_00DB5E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB5D CLC
    cpu.setFlag('C', false);
    goto L_00DB5E;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB5D CLC
    cpu.setFlag('C', false);
    goto L_00DB5E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB5Du,0x00DB5Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB5Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Eu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB5E ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x7Au), cpu.m8?8:16));
    goto L_00DB60;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Eu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB5E ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x7Au), cpu.m8?8:16));
    goto L_00DB60;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Eu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB5E ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x7Au), cpu.m8?8:16));
    goto L_00DB60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB5Eu,0x00DB5Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB60u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB60 STA
    hw.write(cpu.address("dp", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_00DB62;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB60u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB60 STA
    hw.write(cpu.address("dp", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_00DB62;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB60u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB60 STA
    hw.write(cpu.address("dp", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_00DB62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB60u,0x00DB60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB62u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB62u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB62u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB62 SEP
    cpu.sep(0x20u);
    goto L_00DB64;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB62u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB62u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB62 SEP
    cpu.sep(0x20u);
    goto L_00DB64;
  }
  if (cpu.e==true && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB62u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB62u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB62 SEP
    cpu.sep(0x20u);
    goto L_00DB64;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB62u,0x00DB62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB64u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB64u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB64u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB64 TYA
    cpu.transfer("TYA");
    goto L_00DB65;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB64u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB64u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB64 TYA
    cpu.transfer("TYA");
    goto L_00DB65;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB64u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB64u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB64 TYA
    cpu.transfer("TYA");
    goto L_00DB65;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB64u,0x00DB64u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB65u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB65u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB65 LSR
    cpu.lsrA();
    goto L_00DB66;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB65u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB65 LSR
    cpu.lsrA();
    goto L_00DB66;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB65u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB65 LSR
    cpu.lsrA();
    goto L_00DB66;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB65u,0x00DB65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB66u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB66u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB66 AND
    cpu.logicAnd(0xEu);
    goto L_00DB68;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB66u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB66 AND
    cpu.logicAnd(0xEu);
    goto L_00DB68;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB66u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB66 AND
    cpu.logicAnd(0xEu);
    goto L_00DB68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB66u,0x00DB66u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB68u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB68u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB68u, 4u, 3u, cpu.address("abs", 0x13F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB68 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13F0u), cpu.m8?8:16));
    goto L_00DB6B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB68u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB68u, 4u, 3u, cpu.address("abs", 0x13F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB68 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13F0u), cpu.m8?8:16));
    goto L_00DB6B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB68u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB68u, 4u, 3u, cpu.address("abs", 0x13F0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB68 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x13F0u), cpu.m8?8:16));
    goto L_00DB6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB68u,0x00DB68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB6Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB6B TAY
    cpu.transfer("TAY");
    goto L_00DB6C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB6B TAY
    cpu.transfer("TAY");
    goto L_00DB6C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB6B TAY
    cpu.transfer("TAY");
    goto L_00DB6C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB6Bu,0x00DB6Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB6Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Cu, 4u + 1u, 3u, cpu.address("absy", 0xDABDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB6C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDABDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB6F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Cu, 4u + ((((0xDABDu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDABDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB6C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDABDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB6F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Cu, 4u + ((((0xDABDu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDABDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB6C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDABDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB6F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB6Cu,0x00DB6Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB6Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Fu,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Fu, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB6F BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), false);
    goto L_00DB72;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Fu,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Fu, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB6F BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), false);
    goto L_00DB72;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Fu,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Fu, 4u, 3u, cpu.address("abs", 0x1878u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB6F BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x1878u), cpu.m8?8:16), false);
    goto L_00DB72;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB6Fu,0x00DB6Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB72u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB72u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB72 BMI -> $00DB76
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB76; }
    goto L_00DB74;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB72u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB72 BMI -> $00DB76
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB76; }
    goto L_00DB74;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB72u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB72 BMI -> $00DB76
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00DB76; }
    goto L_00DB74;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB72u,0x00DB72u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB74u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB74u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB74 EOR
    cpu.logicXor(0x1u);
    goto L_00DB76;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB74u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB74 EOR
    cpu.logicXor(0x1u);
    goto L_00DB76;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB74u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB74 EOR
    cpu.logicXor(0x1u);
    goto L_00DB76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB74u,0x00DB74u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB76u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB76u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB76u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB76 STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_00DB78;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB76u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB76u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB76 STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_00DB78;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB76u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB76u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB76 STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_00DB78;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB76u,0x00DB76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB78u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB78u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB78u, 4u + 1u, 3u, cpu.address("absy", 0xDACDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB78 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDACDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB7B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB78u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB78u, 4u + ((((0xDACDu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDACDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB78 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDACDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB7B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB78u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB78u, 4u + ((((0xDACDu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xDACDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB78 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDACDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB7B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB78u,0x00DB78u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB7Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB7B BRA -> $00DB92
    goto L_00DB92;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB7B BRA -> $00DB92
    goto L_00DB92;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB7B BRA -> $00DB92
    goto L_00DB92;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB7Bu,0x00DB7Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB7Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB7D STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00DB7F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB7D STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00DB7F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB7D STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_00DB7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB7Du,0x00DB7Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB7Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB7F STZ
    hw.write(cpu.address("dp", 0x7Au), 0, cpu.m8?8:16);
    goto L_00DB81;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB7F STZ
    hw.write(cpu.address("dp", 0x7Au), 0, cpu.m8?8:16);
    goto L_00DB81;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Fu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB7F STZ
    hw.write(cpu.address("dp", 0x7Au), 0, cpu.m8?8:16);
    goto L_00DB81;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB7Fu,0x00DB7Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB81u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB81u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB81u, 5u, 3u, cpu.address("abs", 0x13F9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB81 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13F9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DB84;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB81u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB81u, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB81 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13F9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DB84;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB81u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB81u, 4u, 3u, cpu.address("abs", 0x13F9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB81 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x13F9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00DB84;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB81u,0x00DB81u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB84u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB84u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB84u, 4u, 3u, cpu.address("abs", 0x149Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB84 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x149Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB87;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB84u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB84u, 4u, 3u, cpu.address("abs", 0x149Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB84 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x149Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB87;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB84u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB84u, 4u, 3u, cpu.address("abs", 0x149Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB84 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x149Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB84u,0x00DB84u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB87u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB87u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB87 BEQ -> $00DB96
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB96u,0x00DB87u); return; }
    goto L_00DB89;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB87u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB87 BEQ -> $00DB96
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB96u,0x00DB87u); return; }
    goto L_00DB89;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB87u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB87 BEQ -> $00DB96
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x00DB96u,0x00DB87u); return; }
    goto L_00DB89;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB87u,0x00DB87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB89u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB89u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB89 TXA
    cpu.transfer("TXA");
    goto L_00DB8A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB89u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB89 TXA
    cpu.transfer("TXA");
    goto L_00DB8A;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB89u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB89 TXA
    cpu.transfer("TXA");
    goto L_00DB8A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB89u,0x00DB89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB8Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB8A INC
    cpu.inc('A');
    goto L_00DB8B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB8A INC
    cpu.inc('A');
    goto L_00DB8B;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB8A INC
    cpu.inc('A');
    goto L_00DB8B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB8Au,0x00DB8Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB8Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB8B INC
    cpu.inc('A');
    goto L_00DB8C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB8B INC
    cpu.inc('A');
    goto L_00DB8C;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB8B INC
    cpu.inc('A');
    goto L_00DB8C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB8Bu,0x00DB8Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB8Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Cu, 6u, 3u, cpu.address("abs", 0xD044u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DB8C JSR -> $00D044 stack real
    { cpu.push16Value(hw,0xDB8Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD044u), 0x00DB8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00DB8F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Cu, 6u, 3u, cpu.address("abs", 0xD044u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DB8C JSR -> $00D044 stack real
    { cpu.push16Value(hw,0xDB8Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD044u), 0x00DB8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00DB8F;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Cu, 6u, 3u, cpu.address("abs", 0xD044u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00DB8C JSR -> $00D044 stack real
    { cpu.push16Value(hw,0xDB8Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD044u), 0x00DB8Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_00DB8F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB8Cu,0x00DB8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB8Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu, 4u + 1u, 3u, cpu.address("absx", 0xDADDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB8F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDADDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB92;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu, 4u + ((((0xDADDu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDADDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB8F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDADDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB92;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Fu, 4u + ((((0xDADDu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDADDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB8F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDADDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00DB92;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB8Fu,0x00DB8Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00DB92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB92u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB92u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB92 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB95u,0x00DB92u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB92u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB92 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB95u,0x00DB92u); return;
  }
  if (cpu.e==true && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB92u, 4u, 3u, cpu.address("abs", 0x13E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00DB92 STA
    hw.write(cpu.address("abs", 0x13E0u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB95u,0x00DB92u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB92u,0x00DB92u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00E45D_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00E45Du: goto L_00E45D;
    case 0x00E45Fu: goto L_00E45F;
    case 0x00E461u: goto L_00E461;
    case 0x00E463u: goto L_00E463;
    case 0x00E466u: goto L_00E466;
    case 0x00E468u: goto L_00E468;
    case 0x00E46Bu: goto L_00E46B;
    case 0x00E46Du: goto L_00E46D;
    case 0x00E46Fu: goto L_00E46F;
    case 0x00E471u: goto L_00E471;
    case 0x00E472u: goto L_00E472;
    case 0x00E475u: goto L_00E475;
    case 0x00E476u: goto L_00E476;
    case 0x00E477u: goto L_00E477;
    case 0x00E47Au: goto L_00E47A;
    case 0x00E47Du: goto L_00E47D;
    case 0x00E47Eu: goto L_00E47E;
    case 0x00E480u: goto L_00E480;
    case 0x00E482u: goto L_00E482;
    case 0x00E485u: goto L_00E485;
    case 0x00E487u: goto L_00E487;
    case 0x00E489u: goto L_00E489;
    case 0x00E48Au: goto L_00E48A;
    case 0x00E48Du: goto L_00E48D;
    case 0x00E48Eu: goto L_00E48E;
    case 0x00E48Fu: goto L_00E48F;
    case 0x00E492u: goto L_00E492;
    case 0x00E495u: goto L_00E495;
    case 0x00E496u: goto L_00E496;
    case 0x00E498u: goto L_00E498;
    case 0x00E49Au: goto L_00E49A;
    case 0x00E49Du: goto L_00E49D;
    case 0x00E49Eu: goto L_00E49E;
    case 0x00E49Fu: goto L_00E49F;
    case 0x00E4A0u: goto L_00E4A0;
    case 0x00E4A1u: goto L_00E4A1;
    case 0x00E4A2u: goto L_00E4A2;
    case 0x00E4A3u: goto L_00E4A3;
    case 0x00E4A4u: goto L_00E4A4;
    case 0x00E4A6u: goto L_00E4A6;
    case 0x00E4A7u: goto L_00E4A7;
    case 0x00E4A8u: goto L_00E4A8;
    case 0x00E4A9u: goto L_00E4A9;
    case 0x00E4ABu: goto L_00E4AB;
    case 0x00E4AEu: goto L_00E4AE;
    case 0x00E4AFu: goto L_00E4AF;
    case 0x00E4B0u: goto L_00E4B0;
    case 0x00E4B1u: goto L_00E4B1;
    case 0x00E4B2u: goto L_00E4B2;
    case 0x00E4B4u: goto L_00E4B4;
    case 0x00E4B6u: goto L_00E4B6;
    case 0x00E4B8u: goto L_00E4B8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00E45D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Du,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E45D LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x78u), cpu.m8?8:16);
    goto L_00E45F;
L_00E45F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE45Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE45Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E45F BCS -> $00E49F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00E49F; }
    goto L_00E461;
L_00E461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE461u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE461u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E461 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00E463;
L_00E463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE463u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE463u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE463u, 4u + ((((0xDFDAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDFDAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E463 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xDFDAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E466;
L_00E466:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE466u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE466u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE466u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E466 BMI -> $00E49F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_00E49F; }
    goto L_00E468;
L_00E468:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE468u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE468u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE468u, 5u, 3u, cpu.address("absy", 0x0302u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E468 STA
    hw.write(cpu.address("absy", 0x302u), cpu.a, cpu.m8?8:16);
    goto L_00E46B;
L_00E46B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E46B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_00E46D;
L_00E46D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E46D REP
    cpu.rep(0x20u);
    goto L_00E46F;
L_00E46F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE46Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE46Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E46F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E471;
L_00E471:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE471u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE471u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE471u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E471 CLC
    cpu.setFlag('C', false);
    goto L_00E472;
L_00E472:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE472u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE472u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE472u, 5u + ((((0xDE32u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDE32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E472 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xDE32u), cpu.m8?8:16));
    goto L_00E475;
L_00E475:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE475u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE475u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE475u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E475 PHA
    cpu.push("PHA", hw);
    goto L_00E476;
L_00E476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE476u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE476u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E476 CLC
    cpu.setFlag('C', false);
    goto L_00E477;
L_00E477:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE477u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE477u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE477u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E477 ADC
    cpu.adc(0x10u);
    goto L_00E47A;
L_00E47A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE47Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E47A CMP
    cpu.compareA(0x100u);
    goto L_00E47D;
L_00E47D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE47Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Du,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Du, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E47D PLA
    cpu.pop("PLA", hw);
    goto L_00E47E;
L_00E47E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE47Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE47Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E47E SEP
    cpu.sep(0x20u);
    goto L_00E480;
L_00E480:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE480u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE480u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE480u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E480 BCS -> $00E49F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00E49F; }
    goto L_00E482;
L_00E482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE482u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE482u, 5u, 3u, cpu.address("absy", 0x0301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E482 STA
    hw.write(cpu.address("absy", 0x301u), cpu.a, cpu.m8?8:16);
    goto L_00E485;
L_00E485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE485u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE485u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E485 REP
    cpu.rep(0x20u);
    goto L_00E487;
L_00E487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE487u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE487u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E487 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00E489;
L_00E489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE489u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE489u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E489 CLC
    cpu.setFlag('C', false);
    goto L_00E48A;
L_00E48A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Au,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Au, 5u + ((((0xDD4Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xDD4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E48A ADC
    cpu.adc(hw.readW(cpu.address("absx", 0xDD4Eu), cpu.m8?8:16));
    goto L_00E48D;
L_00E48D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E48D PHA
    cpu.push("PHA", hw);
    goto L_00E48E;
L_00E48E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E48E CLC
    cpu.setFlag('C', false);
    goto L_00E48F;
L_00E48F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE48Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE48Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E48F ADC
    cpu.adc(0x80u);
    goto L_00E492;
L_00E492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE492u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE492u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE492u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E492 CMP
    cpu.compareA(0x200u);
    goto L_00E495;
L_00E495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE495u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE495u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E495 PLA
    cpu.pop("PLA", hw);
    goto L_00E496;
L_00E496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE496u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE496u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E496 SEP
    cpu.sep(0x20u);
    goto L_00E498;
L_00E498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE498u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE498u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E498 BCS -> $00E49F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_00E49F; }
    goto L_00E49A;
L_00E49A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Au, 5u, 3u, cpu.address("absy", 0x0300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E49A STA
    hw.write(cpu.address("absy", 0x300u), cpu.a, cpu.m8?8:16);
    goto L_00E49D;
L_00E49D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Du,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E49D XBA
    cpu.xba();
    goto L_00E49E;
L_00E49E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E49E LSR
    cpu.lsrA();
    goto L_00E49F;
L_00E49F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE49Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Fu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE49Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00E49F PHP
    cpu.push("PHP", hw);
    goto L_00E4A0;
L_00E4A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A0u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4A0 TYA
    cpu.transfer("TYA");
    goto L_00E4A1;
L_00E4A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4A1 LSR
    cpu.lsrA();
    goto L_00E4A2;
L_00E4A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4A2 LSR
    cpu.lsrA();
    goto L_00E4A3;
L_00E4A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4A3 TAX
    cpu.transfer("TAX");
    goto L_00E4A4;
L_00E4A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A4u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4A4 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_00E4A6;
L_00E4A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A6u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4A6 ROL
    cpu.rolA();
    goto L_00E4A7;
L_00E4A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A7u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00E4A7 PLP
    cpu.pop("PLP", hw);
    goto L_00E4A8;
L_00E4A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE4A8u,0x00E4A8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A8u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4A8 ROL
    cpu.rolA();
    goto L_00E4A9;
L_00E4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4A9 AND
    cpu.logicAnd(0x3u);
    goto L_00E4AB;
L_00E4AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4ABu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4ABu, 5u, 3u, cpu.address("absx", 0x0460u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4AB STA
    hw.write(cpu.address("absx", 0x460u), cpu.a, cpu.m8?8:16);
    goto L_00E4AE;
L_00E4AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4AE INY
    cpu.inc('Y');
    goto L_00E4AF;
L_00E4AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AFu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4AF INY
    cpu.inc('Y');
    goto L_00E4B0;
L_00E4B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B0u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4B0 INY
    cpu.inc('Y');
    goto L_00E4B1;
L_00E4B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B1u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4B1 INY
    cpu.inc('Y');
    goto L_00E4B2;
L_00E4B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B2u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4B2 INC
    cpu.incMem(hw, cpu.address("dp", 0x5u), cpu.m8?8:16);
    goto L_00E4B4;
L_00E4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B4u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4B4 INC
    cpu.incMem(hw, cpu.address("dp", 0x5u), cpu.m8?8:16);
    goto L_00E4B6;
L_00E4B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00E4B6 INC
    cpu.incMem(hw, cpu.address("dp", 0x6u), cpu.m8?8:16);
    goto L_00E4B8;
L_00E4B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00E4B8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x00E4B8u);return;} hw.unresolvedReturn(0x00E4B8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_00EBDD_E0M1X1C1_part13(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EED1u: goto L_00EED1;
    case 0x00EED4u: goto L_00EED4;
    case 0x00EED6u: goto L_00EED6;
    case 0x00EED7u: goto L_00EED7;
    case 0x00EED9u: goto L_00EED9;
    case 0x00EEDBu: goto L_00EEDB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED1u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED1u,0x00EED1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED4u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED4u,0x00EED4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED6u))return;
  // 26 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    goto L_00EED7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    goto L_00EED7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    goto L_00EED7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    goto L_00EED7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED6u,0x00EED6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED7u))return;
  // 26 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED7u,0x00EED7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED9u))return;
  // 26 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED9u,0x00EED9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEDBu))return;
  // 26 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDDu,0x00EEDBu); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDDu,0x00EEDBu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDDu,0x00EEDBu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDDu,0x00EEDBu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDBu,0x00EEDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_00EBDD_E0M1X1CQ_part13(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00EED1u: goto L_00EED1;
    case 0x00EED4u: goto L_00EED4;
    case 0x00EED6u: goto L_00EED6;
    case 0x00EED7u: goto L_00EED7;
    case 0x00EED9u: goto L_00EED9;
    case 0x00EEDBu: goto L_00EEDB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00EED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED1u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 8u, 3u, cpu.address("abs", 0x13EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED1u, 6u, 3u, cpu.address("abs", 0x13EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13EFu), cpu.m8?8:16);
    goto L_00EED4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED1u,0x00EED1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED4u))return;
  // 27 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00EED6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED4u,0x00EED4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED6u))return;
  // 26 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    goto L_00EED7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    goto L_00EED7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    goto L_00EED7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED6 SEC
    cpu.setFlag('C', true);
    goto L_00EED7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED6u,0x00EED6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED7u))return;
  // 26 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x91u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x91u), cpu.m8?8:16));
    goto L_00EED9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED7u,0x00EED7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEED9u))return;
  // 26 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEED9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EED9 STA
    hw.write(cpu.address("dp", 0x96u), cpu.a, cpu.m8?8:16);
    goto L_00EEDB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEED9u,0x00EED9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_00EEDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEEDBu))return;
  // 26 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDDu,0x00EEDBu); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDDu,0x00EEDBu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDDu,0x00EEDBu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEEDBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00EEDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x97u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDDu,0x00EEDBu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEEDBu,0x00EEDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_01A365_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01A365u: goto L_01A365;
    case 0x01A368u: goto L_01A368;
    case 0x01A36Bu: goto L_01A36B;
    case 0x01A36Du: goto L_01A36D;
    case 0x01A36Fu: goto L_01A36F;
    case 0x01A372u: goto L_01A372;
    case 0x01A374u: goto L_01A374;
    case 0x01A376u: goto L_01A376;
    case 0x01A379u: goto L_01A379;
    case 0x01A37Cu: goto L_01A37C;
    case 0x01A37Du: goto L_01A37D;
    case 0x01A37Fu: goto L_01A37F;
    case 0x01A381u: goto L_01A381;
    case 0x01A382u: goto L_01A382;
    case 0x01A384u: goto L_01A384;
    case 0x01A385u: goto L_01A385;
    case 0x01A388u: goto L_01A388;
    case 0x01A38Bu: goto L_01A38B;
    case 0x01A38Du: goto L_01A38D;
    case 0x01A38Eu: goto L_01A38E;
    case 0x01A390u: goto L_01A390;
    case 0x01A393u: goto L_01A393;
    case 0x01A395u: goto L_01A395;
    case 0x01A397u: goto L_01A397;
    case 0x01A39Au: goto L_01A39A;
    case 0x01A39Cu: goto L_01A39C;
    case 0x01A39Eu: goto L_01A39E;
    case 0x01A3A1u: goto L_01A3A1;
    case 0x01A3A3u: goto L_01A3A3;
    case 0x01A3A5u: goto L_01A3A5;
    case 0x01A3A6u: goto L_01A3A6;
    case 0x01A3A8u: goto L_01A3A8;
    case 0x01A3A9u: goto L_01A3A9;
    case 0x01A3ACu: goto L_01A3AC;
    case 0x01A3ADu: goto L_01A3AD;
    case 0x01A3AFu: goto L_01A3AF;
    case 0x01A3B1u: goto L_01A3B1;
    case 0x01A3B2u: goto L_01A3B2;
    case 0x01A3B5u: goto L_01A3B5;
    case 0x01A3B7u: goto L_01A3B7;
    case 0x01A3B9u: goto L_01A3B9;
    case 0x01A3BBu: goto L_01A3BB;
    case 0x01A3BDu: goto L_01A3BD;
    case 0x01A3C0u: goto L_01A3C0;
    case 0x01A3C3u: goto L_01A3C3;
    case 0x01A3C6u: goto L_01A3C6;
    case 0x01A3C7u: goto L_01A3C7;
    case 0x01A3C9u: goto L_01A3C9;
    case 0x01A3CBu: goto L_01A3CB;
    case 0x01A3CCu: goto L_01A3CC;
    case 0x01A3CDu: goto L_01A3CD;
    case 0x01A3D0u: goto L_01A3D0;
    case 0x01A3D2u: goto L_01A3D2;
    case 0x01A3D3u: goto L_01A3D3;
    case 0x01A3D5u: goto L_01A3D5;
    case 0x01A3D7u: goto L_01A3D7;
    case 0x01A3D9u: goto L_01A3D9;
    case 0x01A3DAu: goto L_01A3DA;
    case 0x01A3DCu: goto L_01A3DC;
    case 0x01A3DEu: goto L_01A3DE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01A365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA365u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA365u, 5u, 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A365 STZ
    hw.write(cpu.address("absx", 0x186Cu), 0, cpu.m8?8:16);
    goto L_01A368;
L_01A368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u, 5u, 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A368 STZ
    hw.write(cpu.address("absx", 0x15A0u), 0, cpu.m8?8:16);
    goto L_01A36B;
L_01A36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A36B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A36D;
L_01A36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Du,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A36D CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_01A36F;
L_01A36F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Fu, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A36F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A372;
L_01A372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA372u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA372u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA372u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A372 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Bu), cpu.m8?8:16));
    goto L_01A374;
L_01A374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA374u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA374u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A374 BEQ -> $01A379
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A379; }
    goto L_01A376;
L_01A376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA376u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA376u, 7u, 3u, cpu.address("absx", 0x15A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A376 INC
    cpu.incMem(hw, cpu.address("absx", 0x15A0u), cpu.m8?8:16);
    goto L_01A379;
L_01A379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA379u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA379u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A379 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A37C;
L_01A37C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A37C XBA
    cpu.xba();
    goto L_01A37D;
L_01A37D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A37D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A37F;
L_01A37F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A37F REP
    cpu.rep(0x20u);
    goto L_01A381;
L_01A381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA381u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA381u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A381 SEC
    cpu.setFlag('C', true);
    goto L_01A382;
L_01A382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA382u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA382u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A382 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_01A384;
L_01A384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA384u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA384u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A384 CLC
    cpu.setFlag('C', false);
    goto L_01A385;
L_01A385:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA385u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA385u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA385u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A385 ADC
    cpu.adc(0x40u);
    goto L_01A388;
L_01A388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA388u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA388u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA388u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A388 CMP
    cpu.compareA(0x180u);
    goto L_01A38B;
L_01A38B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A38B SEP
    cpu.sep(0x20u);
    goto L_01A38D;
L_01A38D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Du,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A38D ROL
    cpu.rolA();
    goto L_01A38E;
L_01A38E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A38E AND
    cpu.logicAnd(0x1u);
    goto L_01A390;
L_01A390:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA390u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA390u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA390u, 5u, 3u, cpu.address("absx", 0x15C4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A390 STA
    hw.write(cpu.address("absx", 0x15C4u), cpu.a, cpu.m8?8:16);
    goto L_01A393;
L_01A393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA393u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA393u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A393 BNE -> $01A3CB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A3CB; }
    goto L_01A395;
L_01A395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA395u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA395u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A395 LDY
    cpu.setY(0x0u, 8);
    goto L_01A397;
L_01A397:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA397u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA397u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA397u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A397 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A39A;
L_01A39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A39A CMP
    cpu.compareA(0x9u);
    goto L_01A39C;
L_01A39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A39C BEQ -> $01A3A6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A3A6; }
    goto L_01A39E;
L_01A39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Eu, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A39E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3A1;
L_01A3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A1 AND
    cpu.logicAnd(0x20u);
    goto L_01A3A3;
L_01A3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A3 BEQ -> $01A3A6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A3A6; }
    goto L_01A3A5;
L_01A3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A5 INY
    cpu.inc('Y');
    goto L_01A3A6;
L_01A3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3A8;
L_01A3A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A8 CLC
    cpu.setFlag('C', false);
    goto L_01A3A9;
L_01A3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A9u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A9u, 4u + ((((0xA361u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA361u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A9 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xA361u), cpu.m8?8:16));
    goto L_01A3AC;
L_01A3AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ACu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ACu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A3AC PHP
    cpu.push("PHP", hw);
    goto L_01A3AD;
L_01A3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ADu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3AD CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_01A3AF;
L_01A3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3AFu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3AF ROL
    cpu.rolMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_01A3B1;
L_01A3B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B1u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A3B1 PLP
    cpu.pop("PLP", hw);
    goto L_01A3B2;
L_01A3B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3B2u,0x01A3B2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B2u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3B2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3B5;
L_01A3B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3B5 ADC
    cpu.adc(0x0u);
    goto L_01A3B7;
L_01A3B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B7u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3B7 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_01A3B9;
L_01A3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B9u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3B9 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Du), cpu.m8?8:16));
    goto L_01A3BB;
L_01A3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3BB BEQ -> $01A3C6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A3C6; }
    goto L_01A3BD;
L_01A3BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BDu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3BD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3C0;
L_01A3C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C0u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C0u, 4u + ((((0xA363u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA363u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3C0 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xA363u), cpu.m8?8:16));
    goto L_01A3C3;
L_01A3C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C3u, 5u, 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3C3 STA
    hw.write(cpu.address("absx", 0x186Cu), cpu.a, cpu.m8?8:16);
    goto L_01A3C6;
L_01A3C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C6u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3C6 DEY
    cpu.decReg('Y');
    goto L_01A3C7;
L_01A3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3C7 BPL -> $01A3A6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01A3A6; }
    goto L_01A3C9;
L_01A3C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3C9 BRA -> $01A3CD
    goto L_01A3CD;
L_01A3CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CBu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A3CB PLA
    cpu.pop("PLA", hw);
    goto L_01A3CC;
L_01A3CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CCu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A3CC PLA
    cpu.pop("PLA", hw);
    goto L_01A3CD;
L_01A3CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CDu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CDu, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3CD LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A3D0;
L_01A3D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3D2;
L_01A3D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D2 SEC
    cpu.setFlag('C', true);
    goto L_01A3D3;
L_01A3D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D3u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D3 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_01A3D5;
L_01A3D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_01A3D7;
L_01A3D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3D9;
L_01A3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D9 SEC
    cpu.setFlag('C', true);
    goto L_01A3DA;
L_01A3DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DAu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3DA SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_01A3DC;
L_01A3DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3DC STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_01A3DE;
L_01A3DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A3DE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A3DEu);return;} hw.unresolvedReturn(0x01A3DEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01A365_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01A365u: goto L_01A365;
    case 0x01A368u: goto L_01A368;
    case 0x01A36Bu: goto L_01A36B;
    case 0x01A36Du: goto L_01A36D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01A365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA365u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA365u, 5u, 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A365 STZ
    hw.write(cpu.address("absx", 0x186Cu), 0, cpu.m8?8:16);
    goto L_01A368;
L_01A368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u, 5u, 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A368 STZ
    hw.write(cpu.address("absx", 0x15A0u), 0, cpu.m8?8:16);
    goto L_01A36B;
L_01A36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A36B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A36D;
L_01A36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Du,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A36D CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA36Fu,0x01A36Du); return;
}

void sub_01A365_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01A365u: goto L_01A365;
    case 0x01A368u: goto L_01A368;
    case 0x01A36Bu: goto L_01A36B;
    case 0x01A36Du: goto L_01A36D;
    case 0x01A36Fu: goto L_01A36F;
    case 0x01A372u: goto L_01A372;
    case 0x01A374u: goto L_01A374;
    case 0x01A376u: goto L_01A376;
    case 0x01A379u: goto L_01A379;
    case 0x01A37Cu: goto L_01A37C;
    case 0x01A37Du: goto L_01A37D;
    case 0x01A37Fu: goto L_01A37F;
    case 0x01A381u: goto L_01A381;
    case 0x01A382u: goto L_01A382;
    case 0x01A384u: goto L_01A384;
    case 0x01A385u: goto L_01A385;
    case 0x01A388u: goto L_01A388;
    case 0x01A38Bu: goto L_01A38B;
    case 0x01A38Du: goto L_01A38D;
    case 0x01A38Eu: goto L_01A38E;
    case 0x01A390u: goto L_01A390;
    case 0x01A393u: goto L_01A393;
    case 0x01A395u: goto L_01A395;
    case 0x01A397u: goto L_01A397;
    case 0x01A39Au: goto L_01A39A;
    case 0x01A39Cu: goto L_01A39C;
    case 0x01A39Eu: goto L_01A39E;
    case 0x01A3A1u: goto L_01A3A1;
    case 0x01A3A3u: goto L_01A3A3;
    case 0x01A3A5u: goto L_01A3A5;
    case 0x01A3A6u: goto L_01A3A6;
    case 0x01A3A8u: goto L_01A3A8;
    case 0x01A3A9u: goto L_01A3A9;
    case 0x01A3ACu: goto L_01A3AC;
    case 0x01A3ADu: goto L_01A3AD;
    case 0x01A3AFu: goto L_01A3AF;
    case 0x01A3B1u: goto L_01A3B1;
    case 0x01A3B2u: goto L_01A3B2;
    case 0x01A3B5u: goto L_01A3B5;
    case 0x01A3B7u: goto L_01A3B7;
    case 0x01A3B9u: goto L_01A3B9;
    case 0x01A3BBu: goto L_01A3BB;
    case 0x01A3BDu: goto L_01A3BD;
    case 0x01A3C0u: goto L_01A3C0;
    case 0x01A3C3u: goto L_01A3C3;
    case 0x01A3C6u: goto L_01A3C6;
    case 0x01A3C7u: goto L_01A3C7;
    case 0x01A3C9u: goto L_01A3C9;
    case 0x01A3CBu: goto L_01A3CB;
    case 0x01A3CCu: goto L_01A3CC;
    case 0x01A3CDu: goto L_01A3CD;
    case 0x01A3D0u: goto L_01A3D0;
    case 0x01A3D2u: goto L_01A3D2;
    case 0x01A3D3u: goto L_01A3D3;
    case 0x01A3D5u: goto L_01A3D5;
    case 0x01A3D7u: goto L_01A3D7;
    case 0x01A3D9u: goto L_01A3D9;
    case 0x01A3DAu: goto L_01A3DA;
    case 0x01A3DCu: goto L_01A3DC;
    case 0x01A3DEu: goto L_01A3DE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01A365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA365u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA365u, 5u, 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A365 STZ
    hw.write(cpu.address("absx", 0x186Cu), 0, cpu.m8?8:16);
    goto L_01A368;
L_01A368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u, 5u, 3u, cpu.address("absx", 0x15A0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A368 STZ
    hw.write(cpu.address("absx", 0x15A0u), 0, cpu.m8?8:16);
    goto L_01A36B;
L_01A36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A36B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A36D;
L_01A36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Du,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A36D CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_01A36F;
L_01A36F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Fu, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A36F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A372;
L_01A372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA372u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA372u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA372u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A372 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Bu), cpu.m8?8:16));
    goto L_01A374;
L_01A374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA374u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA374u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A374 BEQ -> $01A379
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A379; }
    goto L_01A376;
L_01A376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA376u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA376u, 7u, 3u, cpu.address("absx", 0x15A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A376 INC
    cpu.incMem(hw, cpu.address("absx", 0x15A0u), cpu.m8?8:16);
    goto L_01A379;
L_01A379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA379u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA379u, 4u + ((((0x14E0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14E0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A379 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14E0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A37C;
L_01A37C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A37C XBA
    cpu.xba();
    goto L_01A37D;
L_01A37D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A37D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A37F;
L_01A37F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A37F REP
    cpu.rep(0x20u);
    goto L_01A381;
L_01A381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA381u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA381u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A381 SEC
    cpu.setFlag('C', true);
    goto L_01A382;
L_01A382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA382u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA382u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A382 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_01A384;
L_01A384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA384u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA384u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A384 CLC
    cpu.setFlag('C', false);
    goto L_01A385;
L_01A385:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA385u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA385u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA385u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A385 ADC
    cpu.adc(0x40u);
    goto L_01A388;
L_01A388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA388u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA388u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA388u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A388 CMP
    cpu.compareA(0x180u);
    goto L_01A38B;
L_01A38B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A38B SEP
    cpu.sep(0x20u);
    goto L_01A38D;
L_01A38D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Du,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A38D ROL
    cpu.rolA();
    goto L_01A38E;
L_01A38E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A38E AND
    cpu.logicAnd(0x1u);
    goto L_01A390;
L_01A390:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA390u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA390u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA390u, 5u, 3u, cpu.address("absx", 0x15C4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A390 STA
    hw.write(cpu.address("absx", 0x15C4u), cpu.a, cpu.m8?8:16);
    goto L_01A393;
L_01A393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA393u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA393u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A393 BNE -> $01A3CB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A3CB; }
    goto L_01A395;
L_01A395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA395u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA395u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A395 LDY
    cpu.setY(0x0u, 8);
    goto L_01A397;
L_01A397:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA397u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA397u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA397u, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A397 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A39A;
L_01A39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A39A CMP
    cpu.compareA(0x9u);
    goto L_01A39C;
L_01A39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A39C BEQ -> $01A3A6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A3A6; }
    goto L_01A39E;
L_01A39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Eu, 4u + ((((0x190Fu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x190Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A39E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x190Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3A1;
L_01A3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A1 AND
    cpu.logicAnd(0x20u);
    goto L_01A3A3;
L_01A3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A3 BEQ -> $01A3A6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A3A6; }
    goto L_01A3A5;
L_01A3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A5 INY
    cpu.inc('Y');
    goto L_01A3A6;
L_01A3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3A8;
L_01A3A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A8 CLC
    cpu.setFlag('C', false);
    goto L_01A3A9;
L_01A3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A9u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A9u, 4u + ((((0xA361u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA361u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3A9 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xA361u), cpu.m8?8:16));
    goto L_01A3AC;
L_01A3AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ACu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ACu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A3AC PHP
    cpu.push("PHP", hw);
    goto L_01A3AD;
L_01A3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ADu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3AD CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_01A3AF;
L_01A3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3AFu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3AF ROL
    cpu.rolMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_01A3B1;
L_01A3B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B1u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A3B1 PLP
    cpu.pop("PLP", hw);
    goto L_01A3B2;
L_01A3B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3B2u,0x01A3B2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B2u, 4u + ((((0x14D4u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14D4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3B2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3B5;
L_01A3B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3B5 ADC
    cpu.adc(0x0u);
    goto L_01A3B7;
L_01A3B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B7u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3B7 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_01A3B9;
L_01A3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B9u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3B9 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Du), cpu.m8?8:16));
    goto L_01A3BB;
L_01A3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3BB BEQ -> $01A3C6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_01A3C6; }
    goto L_01A3BD;
L_01A3BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BDu, 4u + ((((0x186Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3BD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x186Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3C0;
L_01A3C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C0u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C0u, 4u + ((((0xA363u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA363u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3C0 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0xA363u), cpu.m8?8:16));
    goto L_01A3C3;
L_01A3C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C3u, 5u, 3u, cpu.address("absx", 0x186Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3C3 STA
    hw.write(cpu.address("absx", 0x186Cu), cpu.a, cpu.m8?8:16);
    goto L_01A3C6;
L_01A3C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C6u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3C6 DEY
    cpu.decReg('Y');
    goto L_01A3C7;
L_01A3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3C7 BPL -> $01A3A6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_01A3A6; }
    goto L_01A3C9;
L_01A3C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3C9 BRA -> $01A3CD
    goto L_01A3CD;
L_01A3CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CBu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A3CB PLA
    cpu.pop("PLA", hw);
    goto L_01A3CC;
L_01A3CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CCu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $01A3CC PLA
    cpu.pop("PLA", hw);
    goto L_01A3CD;
L_01A3CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CDu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CDu, 4u + ((((0x15EAu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15EAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3CD LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x15EAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_01A3D0;
L_01A3D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xE4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xE4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3D2;
L_01A3D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D2 SEC
    cpu.setFlag('C', true);
    goto L_01A3D3;
L_01A3D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D3u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D3 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_01A3D5;
L_01A3D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_01A3D7;
L_01A3D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xD8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xD8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_01A3D9;
L_01A3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3D9 SEC
    cpu.setFlag('C', true);
    goto L_01A3DA;
L_01A3DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DAu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3DA SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_01A3DC;
L_01A3DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01A3DC STA
    hw.write(cpu.address("dp", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_01A3DE;
L_01A3DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $01A3DE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x01A3DEu);return;} hw.unresolvedReturn(0x01A3DEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_01C11F_E0M1X1C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01C11Fu: goto L_01C11F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01C11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Fu, 8u, 4u, 0x07F252u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01C11F JSL -> $07F252 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC122u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC123u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x07F252u, 0x01C11Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC123u,0x01C11Fu); return;
}

void sub_01C580_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x01C580u: goto L_01C580;
    case 0x01C582u: goto L_01C582;
    case 0x01C585u: goto L_01C585;
    case 0x01C587u: goto L_01C587;
    case 0x01C58Au: goto L_01C58A;
    case 0x01C58Du: goto L_01C58D;
    case 0x01C58Eu: goto L_01C58E;
    case 0x01C591u: goto L_01C591;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_01C580:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC580u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC580u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC580u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C580 LDA
    cpu.setA(0xFFu, 8);
    goto L_01C582;
L_01C582:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC582u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC582u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC582u, 4u, 3u, cpu.address("abs", 0x1490u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C582 STA
    hw.write(cpu.address("abs", 0x1490u), cpu.a, cpu.m8?8:16);
    goto L_01C585;
L_01C585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC585u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC585u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C585 LDA
    cpu.setA(0xDu, 8);
    goto L_01C587;
L_01C587:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC587u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC587u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC587u, 4u, 3u, cpu.address("abs", 0x1DFBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C587 STA
    hw.write(cpu.address("abs", 0x1DFBu), cpu.a, cpu.m8?8:16);
    goto L_01C58A;
L_01C58A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au,cpu,0x0Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Au, 6u, 3u, cpu.address("abs", 0x0DDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C58A ASL
    cpu.aslMem(hw, cpu.address("abs", 0xDDAu), cpu.m8?8:16);
    goto L_01C58D;
L_01C58D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C58D SEC
    cpu.setFlag('C', true);
    goto L_01C58E;
L_01C58E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC58Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Eu,cpu,0x6Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC58Eu, 6u, 3u, cpu.address("abs", 0x0DDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $01C58E ROR
    cpu.rorMem(hw, cpu.address("abs", 0xDDAu), cpu.m8?8:16);
    goto L_01C591;
L_01C591:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC591u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC591u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC591u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $01C591 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x01C591u);return;} hw.unresolvedReturn(0x01C591u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0294C1_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0294C1u: goto L_0294C1;
    case 0x0294C3u: goto L_0294C3;
    case 0x0294C6u: goto L_0294C6;
    case 0x0294C9u: goto L_0294C9;
    case 0x0294CAu: goto L_0294CA;
    case 0x0294CBu: goto L_0294CB;
    case 0x0294CCu: goto L_0294CC;
    case 0x0294CEu: goto L_0294CE;
    case 0x0294D1u: goto L_0294D1;
    case 0x0294D3u: goto L_0294D3;
    case 0x0294D5u: goto L_0294D5;
    case 0x0294D8u: goto L_0294D8;
    case 0x0294DAu: goto L_0294DA;
    case 0x0294DCu: goto L_0294DC;
    case 0x0294DFu: goto L_0294DF;
    case 0x0294E1u: goto L_0294E1;
    case 0x0294E4u: goto L_0294E4;
    case 0x0294E7u: goto L_0294E7;
    case 0x0294E9u: goto L_0294E9;
    case 0x0294EBu: goto L_0294EB;
    case 0x0294EDu: goto L_0294ED;
    case 0x0294F0u: goto L_0294F0;
    case 0x0294F1u: goto L_0294F1;
    case 0x0294F3u: goto L_0294F3;
    case 0x0294F4u: goto L_0294F4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0294C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294C1 LDA
    cpu.setA(0x30u, 8);
    goto L_0294C3;
L_0294C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C3u, 4u, 3u, cpu.address("abs", 0x1887u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294C3 STA
    hw.write(cpu.address("abs", 0x1887u), cpu.a, cpu.m8?8:16);
    goto L_0294C6;
L_0294C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C6u, 4u, 3u, cpu.address("abs", 0x14A9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294C6 STZ
    hw.write(cpu.address("abs", 0x14A9u), 0, cpu.m8?8:16);
    goto L_0294C9;
L_0294C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C9u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0294C9 PHB
    cpu.push("PHB", hw);
    goto L_0294CA;
L_0294CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CAu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0294CA PHK
    cpu.push("PHK", hw);
    goto L_0294CB;
L_0294CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CBu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0294CB PLB
    cpu.pop("PLB", hw);
    goto L_0294CC;
L_0294CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CCu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294CC LDX
    cpu.setX(0x9u, 8);
    goto L_0294CE;
L_0294CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CEu, 4u + ((((0x14C8u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294CE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x14C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0294D1;
L_0294D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294D1 CMP
    cpu.compareA(0x8u);
    goto L_0294D3;
L_0294D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294D3 BCC -> $0294F0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0294F0; }
    goto L_0294D5;
L_0294D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D5u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294D5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0294D8;
L_0294D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294D8 AND
    cpu.logicAnd(0x4u);
    goto L_0294DA;
L_0294DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294DA BEQ -> $0294F0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0294F0; }
    goto L_0294DC;
L_0294DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DCu, 4u + ((((0x166Eu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x166Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294DC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x166Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0294DF;
L_0294DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294DF AND
    cpu.logicAnd(0x20u);
    goto L_0294E1;
L_0294E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E1u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E1u, 4u + ((((0x15D0u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x15D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294E1 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x15D0u), cpu.m8?8:16));
    goto L_0294E4;
L_0294E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E4u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E4u, 4u + ((((0x154Cu & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x154Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294E4 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x154Cu), cpu.m8?8:16));
    goto L_0294E7;
L_0294E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294E7 BNE -> $0294F0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0294F0; }
    goto L_0294E9;
L_0294E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294E9 LDA
    cpu.setA(0x35u, 8);
    goto L_0294EB;
L_0294EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294EB STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_0294ED;
L_0294ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EDu, 6u, 3u, cpu.address("abs", 0x9404u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0294ED JSR -> $029404 stack real
    { cpu.push16Value(hw,0x94EFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94F0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9404u), 0x0294EDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0294F0;
L_0294F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F0u))return;
  if (!(cpu.e==true && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94F0u,0x0294F0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294F0 DEX
    cpu.decReg('X');
    goto L_0294F1;
L_0294F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0294F1 BPL -> $0294CE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0294CE; }
    goto L_0294F3;
L_0294F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F3u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0294F3 PLB
    cpu.pop("PLB", hw);
    goto L_0294F4;
L_0294F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0294F4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x0294F4u);return;} hw.unresolvedReturn(0x0294F4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_049885_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x049885u: goto L_049885;
    case 0x049887u: goto L_049887;
    case 0x04988Au: goto L_04988A;
    case 0x04988Cu: goto L_04988C;
    case 0x04988Eu: goto L_04988E;
    case 0x049891u: goto L_049891;
    case 0x049892u: goto L_049892;
    case 0x049893u: goto L_049893;
    case 0x049894u: goto L_049894;
    case 0x049895u: goto L_049895;
    case 0x049897u: goto L_049897;
    case 0x049899u: goto L_049899;
    case 0x04989Bu: goto L_04989B;
    case 0x04989Cu: goto L_04989C;
    case 0x04989Du: goto L_04989D;
    case 0x04989Eu: goto L_04989E;
    case 0x04989Fu: goto L_04989F;
    case 0x0498A2u: goto L_0498A2;
    case 0x0498A4u: goto L_0498A4;
    case 0x0498A6u: goto L_0498A6;
    case 0x0498A8u: goto L_0498A8;
    case 0x0498ABu: goto L_0498AB;
    case 0x0498ADu: goto L_0498AD;
    case 0x0498AFu: goto L_0498AF;
    case 0x0498B0u: goto L_0498B0;
    case 0x0498B3u: goto L_0498B3;
    case 0x0498B5u: goto L_0498B5;
    case 0x0498B8u: goto L_0498B8;
    case 0x0498BBu: goto L_0498BB;
    case 0x0498BDu: goto L_0498BD;
    case 0x0498BFu: goto L_0498BF;
    case 0x0498C0u: goto L_0498C0;
    case 0x0498C3u: goto L_0498C3;
    case 0x0498C5u: goto L_0498C5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_049885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9885u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9885u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049885 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_049887;
L_049887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9887u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9887u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049887 AND
    cpu.logicAnd(0xFu);
    goto L_04988A;
L_04988A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04988A STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_04988C;
L_04988C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04988C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04988E;
L_04988E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04988E AND
    cpu.logicAnd(0x10u);
    goto L_049891;
L_049891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9891u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9891u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049891 ASL
    cpu.aslA();
    goto L_049892;
L_049892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9892u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9892u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049892 ASL
    cpu.aslA();
    goto L_049893;
L_049893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9893u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9893u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049893 ASL
    cpu.aslA();
    goto L_049894;
L_049894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9894u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9894u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049894 ASL
    cpu.aslA();
    goto L_049895;
L_049895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9895u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9895u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9895u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049895 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_049897;
L_049897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9897u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9897u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049897 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_049899;
L_049899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9899u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9899u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $049899 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04989B;
L_04989B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04989B ASL
    cpu.aslA();
    goto L_04989C;
L_04989C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04989C ASL
    cpu.aslA();
    goto L_04989D;
L_04989D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04989D ASL
    cpu.aslA();
    goto L_04989E;
L_04989E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04989E ASL
    cpu.aslA();
    goto L_04989F;
L_04989F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04989F AND
    cpu.logicAnd(0xFFu);
    goto L_0498A2;
L_0498A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A2u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498A2 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_0498A4;
L_0498A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498A4 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_0498A6;
L_0498A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0498A8;
L_0498A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498A8 AND
    cpu.logicAnd(0x10u);
    goto L_0498AB;
L_0498AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98ABu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498AB BEQ -> $0498B5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0498B5; }
    goto L_0498AD;
L_0498AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98ADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498AD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0498AF;
L_0498AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98AFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498AF CLC
    cpu.setFlag('C', false);
    goto L_0498B0;
L_0498B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498B0 ADC
    cpu.adc(0x200u);
    goto L_0498B3;
L_0498B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498B3 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_0498B5;
L_0498B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B5u, 5u + ((((0x1F11u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1F11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498B5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1F11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0498B8;
L_0498B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498B8 AND
    cpu.logicAnd(0xFFu);
    goto L_0498BB;
L_0498BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498BB BEQ -> $0498C5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0498C5; }
    goto L_0498BD;
L_0498BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498BD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0498BF;
L_0498BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498BF CLC
    cpu.setFlag('C', false);
    goto L_0498C0;
L_0498C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498C0 ADC
    cpu.adc(0x400u);
    goto L_0498C3;
L_0498C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0498C3 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_0498C5;
L_0498C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0498C5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0498C5u);return;} hw.unresolvedReturn(0x0498C5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_04FE7D_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x04FE7Du: goto L_04FE7D;
    case 0x04FE80u: goto L_04FE80;
    case 0x04FE81u: goto L_04FE81;
    case 0x04FE84u: goto L_04FE84;
    case 0x04FE86u: goto L_04FE86;
    case 0x04FE87u: goto L_04FE87;
    case 0x04FE8Au: goto L_04FE8A;
    case 0x04FE8Du: goto L_04FE8D;
    case 0x04FE8Fu: goto L_04FE8F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_04FE7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE7Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE7Du, 4u + ((((0x0E65u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E65u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE7D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FE80;
L_04FE80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE80u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE80u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE80 XBA
    cpu.xba();
    goto L_04FE81;
L_04FE81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE81u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE81u, 4u + ((((0x0E35u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x0E35u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE81 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE35u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_04FE84;
L_04FE84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE84u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE84u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE84 REP
    cpu.rep(0x20u);
    goto L_04FE86;
L_04FE86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE86u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE86u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE86 SEC
    cpu.setFlag('C', true);
    goto L_04FE87;
L_04FE87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE87u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE87u, 5u + ((((0x001Au & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x001Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE87 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1Au), cpu.m8?8:16));
    goto L_04FE8A;
L_04FE8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Au, 6u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE8A STA
    hw.write(cpu.address("absy", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_04FE8D;
L_04FE8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $04FE8D SEP
    cpu.sep(0x20u);
    goto L_04FE8F;
L_04FE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $04FE8F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x04FE8Fu);return;} hw.unresolvedReturn(0x04FE8Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_05B31B_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05B31Bu: goto L_05B31B;
    case 0x05B31Du: goto L_05B31D;
    case 0x05B31Fu: goto L_05B31F;
    case 0x05B322u: goto L_05B322;
    case 0x05B323u: goto L_05B323;
    case 0x05B324u: goto L_05B324;
    case 0x05B325u: goto L_05B325;
    case 0x05B326u: goto L_05B326;
    case 0x05B328u: goto L_05B328;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05B31B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B31B LDY
    cpu.setY(0x1Cu, 8);
    goto L_05B31D;
L_05B31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B31D LDA
    cpu.setA(0xF0u, 8);
    goto L_05B31F;
L_05B31F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Fu, 5u, 3u, cpu.address("absy", 0x0201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B31F STA
    hw.write(cpu.address("absy", 0x201u), cpu.a, cpu.m8?8:16);
    goto L_05B322;
L_05B322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B322 DEY
    cpu.decReg('Y');
    goto L_05B323;
L_05B323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB323u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB323u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B323 DEY
    cpu.decReg('Y');
    goto L_05B324;
L_05B324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB324u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB324u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B324 DEY
    cpu.decReg('Y');
    goto L_05B325;
L_05B325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B325 DEY
    cpu.decReg('Y');
    goto L_05B326;
L_05B326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB326u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB326u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05B326 BPL -> $05B31F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_05B31F; }
    goto L_05B328;
L_05B328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB328u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB328u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $05B328 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x05B328u);return;} hw.unresolvedReturn(0x05B328u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_05BE8A_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05BE8Au: goto L_05BE8A;
    case 0x05BE8Bu: goto L_05BE8B;
    case 0x05BE8Cu: goto L_05BE8C;
    case 0x05BE8Du: goto L_05BE8D;
    case 0x05BE8Fu: goto L_05BE8F;
    case 0x05BE92u: goto L_05BE92;
    case 0x05BE95u: goto L_05BE95;
    case 0x05BE98u: goto L_05BE98;
    case 0x05BE9Bu: goto L_05BE9B;
    case 0x05BE9Eu: goto L_05BE9E;
    case 0x05BEA0u: goto L_05BEA0;
    case 0x05BEA2u: goto L_05BEA2;
    case 0x05BEA4u: goto L_05BEA4;
    case 0x05BEA5u: goto L_05BEA5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05BE8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Au,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05BE8A PHB
    cpu.push("PHB", hw);
    goto L_05BE8B;
L_05BE8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Bu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05BE8B PHK
    cpu.push("PHK", hw);
    goto L_05BE8C;
L_05BE8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05BE8C PLB
    cpu.pop("PLB", hw);
    goto L_05BE8D;
L_05BE8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BE8D REP
    cpu.rep(0x20u);
    goto L_05BE8F;
L_05BE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Fu, 5u, 3u, cpu.address("abs", 0xCA26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BE8F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xCA26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05BE92;
L_05BE92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE92u, 5u, 3u, cpu.address("abs", 0x1460u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BE92 STA
    hw.write(cpu.address("abs", 0x1460u), cpu.a, cpu.m8?8:16);
    goto L_05BE95;
L_05BE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE95u, 5u, 3u, cpu.address("abs", 0x1458u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BE95 STZ
    hw.write(cpu.address("abs", 0x1458u), 0, cpu.m8?8:16);
    goto L_05BE98;
L_05BE98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE98u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE98u, 5u, 3u, cpu.address("abs", 0x145Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BE98 STZ
    hw.write(cpu.address("abs", 0x145Au), 0, cpu.m8?8:16);
    goto L_05BE9B;
L_05BE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE9Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE9Bu, 5u, 3u, cpu.address("abs", 0x145Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BE9B STZ
    hw.write(cpu.address("abs", 0x145Cu), 0, cpu.m8?8:16);
    goto L_05BE9E;
L_05BE9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE9Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE9Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BE9E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05BEA0;
L_05BEA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BEA0 STA
    hw.write(cpu.address("dp", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_05BEA2;
L_05BEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BEA2 SEP
    cpu.sep(0x20u);
    goto L_05BEA4;
L_05BEA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA4u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05BEA4 PLB
    cpu.pop("PLB", hw);
    goto L_05BEA5;
L_05BEA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA5u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05BEA5 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x05BEA5u);return;} hw.unresolvedReturn(0x05BEA5u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_05BE8A_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x05BE8Au: goto L_05BE8A;
    case 0x05BE8Bu: goto L_05BE8B;
    case 0x05BE8Cu: goto L_05BE8C;
    case 0x05BE8Du: goto L_05BE8D;
    case 0x05BE8Fu: goto L_05BE8F;
    case 0x05BE92u: goto L_05BE92;
    case 0x05BE95u: goto L_05BE95;
    case 0x05BE98u: goto L_05BE98;
    case 0x05BE9Bu: goto L_05BE9B;
    case 0x05BE9Eu: goto L_05BE9E;
    case 0x05BEA0u: goto L_05BEA0;
    case 0x05BEA2u: goto L_05BEA2;
    case 0x05BEA4u: goto L_05BEA4;
    case 0x05BEA5u: goto L_05BEA5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_05BE8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Au,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05BE8A PHB
    cpu.push("PHB", hw);
    goto L_05BE8B;
L_05BE8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Bu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05BE8B PHK
    cpu.push("PHK", hw);
    goto L_05BE8C;
L_05BE8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05BE8C PLB
    cpu.pop("PLB", hw);
    goto L_05BE8D;
L_05BE8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BE8D REP
    cpu.rep(0x20u);
    goto L_05BE8F;
L_05BE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Fu, 5u, 3u, cpu.address("abs", 0xCA26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BE8F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xCA26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05BE92;
L_05BE92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE92u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE92u, 5u, 3u, cpu.address("abs", 0x1460u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BE92 STA
    hw.write(cpu.address("abs", 0x1460u), cpu.a, cpu.m8?8:16);
    goto L_05BE95;
L_05BE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE95u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE95u, 5u, 3u, cpu.address("abs", 0x1458u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BE95 STZ
    hw.write(cpu.address("abs", 0x1458u), 0, cpu.m8?8:16);
    goto L_05BE98;
L_05BE98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE98u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE98u, 5u, 3u, cpu.address("abs", 0x145Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BE98 STZ
    hw.write(cpu.address("abs", 0x145Au), 0, cpu.m8?8:16);
    goto L_05BE9B;
L_05BE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE9Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE9Bu, 5u, 3u, cpu.address("abs", 0x145Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BE9B STZ
    hw.write(cpu.address("abs", 0x145Cu), 0, cpu.m8?8:16);
    goto L_05BE9E;
L_05BE9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE9Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE9Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BE9E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_05BEA0;
L_05BEA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BEA0 STA
    hw.write(cpu.address("dp", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_05BEA2;
L_05BEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $05BEA2 SEP
    cpu.sep(0x20u);
    goto L_05BEA4;
L_05BEA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA4u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $05BEA4 PLB
    cpu.pop("PLB", hw);
    goto L_05BEA5;
L_05BEA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA5u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $05BEA5 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x05BEA5u);return;} hw.unresolvedReturn(0x05BEA5u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_0CAEAD_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0CAEADu: goto L_0CAEAD;
    case 0x0CAEAFu: goto L_0CAEAF;
    case 0x0CAEB2u: goto L_0CAEB2;
    case 0x0CAEB4u: goto L_0CAEB4;
    case 0x0CAEB6u: goto L_0CAEB6;
    case 0x0CAEB9u: goto L_0CAEB9;
    case 0x0CAEBCu: goto L_0CAEBC;
    case 0x0CAEBEu: goto L_0CAEBE;
    case 0x0CAEC0u: goto L_0CAEC0;
    case 0x0CAEC3u: goto L_0CAEC3;
    case 0x0CAEC5u: goto L_0CAEC5;
    case 0x0CAEC8u: goto L_0CAEC8;
    case 0x0CAECAu: goto L_0CAECA;
    case 0x0CAECDu: goto L_0CAECD;
    case 0x0CAED0u: goto L_0CAED0;
    case 0x0CAED2u: goto L_0CAED2;
    case 0x0CAED3u: goto L_0CAED3;
    case 0x0CAED6u: goto L_0CAED6;
    case 0x0CAED8u: goto L_0CAED8;
    case 0x0CAEDAu: goto L_0CAEDA;
    case 0x0CAEDDu: goto L_0CAEDD;
    case 0x0CAEDEu: goto L_0CAEDE;
    case 0x0CAEE1u: goto L_0CAEE1;
    case 0x0CAEE4u: goto L_0CAEE4;
    case 0x0CAEE7u: goto L_0CAEE7;
    case 0x0CAEE9u: goto L_0CAEE9;
    case 0x0CAEECu: goto L_0CAEEC;
    case 0x0CAEEEu: goto L_0CAEEE;
    case 0x0CAEF1u: goto L_0CAEF1;
    case 0x0CAEF4u: goto L_0CAEF4;
    case 0x0CAEF6u: goto L_0CAEF6;
    case 0x0CAEF8u: goto L_0CAEF8;
    case 0x0CAEFBu: goto L_0CAEFB;
    case 0x0CAEFDu: goto L_0CAEFD;
    case 0x0CAF00u: goto L_0CAF00;
    case 0x0CAF03u: goto L_0CAF03;
    case 0x0CAF05u: goto L_0CAF05;
    case 0x0CAF07u: goto L_0CAF07;
    case 0x0CAF09u: goto L_0CAF09;
    case 0x0CAF0Cu: goto L_0CAF0C;
    case 0x0CAF0Eu: goto L_0CAF0E;
    case 0x0CB5BCu: goto L_0CB5BC;
    case 0x0CB5BEu: goto L_0CB5BE;
    case 0x0CB5BFu: goto L_0CB5BF;
    case 0x0CB5C1u: goto L_0CB5C1;
    case 0x0CB5C4u: goto L_0CB5C4;
    case 0x0CB5C6u: goto L_0CB5C6;
    case 0x0CB5C8u: goto L_0CB5C8;
    case 0x0CB5CAu: goto L_0CB5CA;
    case 0x0CB5CCu: goto L_0CB5CC;
    case 0x0CB5CDu: goto L_0CB5CD;
    case 0x0CB5CFu: goto L_0CB5CF;
    case 0x0CB5D0u: goto L_0CB5D0;
    case 0x0CB5D3u: goto L_0CB5D3;
    case 0x0CB5D6u: goto L_0CB5D6;
    case 0x0CB5D8u: goto L_0CB5D8;
    case 0x0CB5DBu: goto L_0CB5DB;
    case 0x0CB5DCu: goto L_0CB5DC;
    case 0x0CB5DEu: goto L_0CB5DE;
    case 0x0CB5E1u: goto L_0CB5E1;
    case 0x0CB5E3u: goto L_0CB5E3;
    case 0x0CB5E5u: goto L_0CB5E5;
    case 0x0CB5E8u: goto L_0CB5E8;
    case 0x0CB5EAu: goto L_0CB5EA;
    case 0x0CB5EBu: goto L_0CB5EB;
    case 0x0CB5EEu: goto L_0CB5EE;
    case 0x0CB5F0u: goto L_0CB5F0;
    case 0x0CB5F2u: goto L_0CB5F2;
    case 0x0CB5F3u: goto L_0CB5F3;
    case 0x0CB5F5u: goto L_0CB5F5;
    case 0x0CB5F8u: goto L_0CB5F8;
    case 0x0CB5FAu: goto L_0CB5FA;
    case 0x0CB5FCu: goto L_0CB5FC;
    case 0x0CB5FEu: goto L_0CB5FE;
    case 0x0CB600u: goto L_0CB600;
    case 0x0CB603u: goto L_0CB603;
    case 0x0CB605u: goto L_0CB605;
    case 0x0CB606u: goto L_0CB606;
    case 0x0CB607u: goto L_0CB607;
    case 0x0CB608u: goto L_0CB608;
    case 0x0CB60Au: goto L_0CB60A;
    case 0x0CB60Bu: goto L_0CB60B;
    case 0x0CB60Du: goto L_0CB60D;
    case 0x0CB610u: goto L_0CB610;
    case 0x0CB611u: goto L_0CB611;
    case 0x0CB614u: goto L_0CB614;
    case 0x0CB617u: goto L_0CB617;
    case 0x0CB61Au: goto L_0CB61A;
    case 0x0CB61Du: goto L_0CB61D;
    case 0x0CB620u: goto L_0CB620;
    case 0x0CB622u: goto L_0CB622;
    case 0x0CB624u: goto L_0CB624;
    case 0x0CB627u: goto L_0CB627;
    case 0x0CB628u: goto L_0CB628;
    case 0x0CB629u: goto L_0CB629;
    case 0x0CB62Au: goto L_0CB62A;
    case 0x0CB62Bu: goto L_0CB62B;
    case 0x0CB62Cu: goto L_0CB62C;
    case 0x0CB62Du: goto L_0CB62D;
    case 0x0CB62Eu: goto L_0CB62E;
    case 0x0CB62Fu: goto L_0CB62F;
    case 0x0CB631u: goto L_0CB631;
    case 0x0CB633u: goto L_0CB633;
    case 0x0CB635u: goto L_0CB635;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0CAEAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEADu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEAD SEP
    cpu.sep(0x20u);
    goto L_0CAEAF;
L_0CAEAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEAFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEAFu, 4u, 3u, cpu.address("abs", 0x1DE9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEAF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DE9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CAEB2;
L_0CAEB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEB2 CMP
    cpu.compareA(0xCu);
    goto L_0CAEB4;
L_0CAEB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEB4 BNE -> $0CAEBC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CAEBC; }
    goto L_0CAEB6;
L_0CAEB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB6u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB6u, 6u, 3u, cpu.address("abs", 0x145Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEB6 DEC
    cpu.decMem(hw, cpu.address("abs", 0x145Bu), cpu.m8?8:16);
    goto L_0CAEB9;
L_0CAEB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB9u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB9u, 3u, 3u, cpu.address("abs", 0xAEF8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEB9 JMP -> $0CAEF8
    goto L_0CAEF8;
L_0CAEBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBCu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEBC REP
    cpu.rep(0x20u);
    goto L_0CAEBE;
L_0CAEBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEBE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CAEC0;
L_0CAEC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC0u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC0u, 5u, 3u, cpu.address("abs", 0x1462u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEC0 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1462u), cpu.m8?8:16));
    goto L_0CAEC3;
L_0CAEC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEC3 BNE -> $0CAED0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CAED0; }
    goto L_0CAEC5;
L_0CAEC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC5u, 5u, 3u, cpu.address("abs", 0x145Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEC5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x145Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CAEC8;
L_0CAEC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEC8 BEQ -> $0CAED0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CAED0; }
    goto L_0CAECA;
L_0CAECA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAECAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAECAu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAECAu, 8u, 3u, cpu.address("abs", 0x145Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAECA DEC
    cpu.decMem(hw, cpu.address("abs", 0x145Bu), cpu.m8?8:16);
    goto L_0CAECD;
L_0CAECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAECDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAECDu, 3u, 3u, cpu.address("abs", 0xAF0Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAECD JMP -> $0CAF0C
    goto L_0CAF0C;
L_0CAED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAED0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CAED2;
L_0CAED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAED2 CLC
    cpu.setFlag('C', false);
    goto L_0CAED3;
L_0CAED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAED3 ADC
    cpu.adc(0x2u);
    goto L_0CAED6;
L_0CAED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAED6 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_0CAED8;
L_0CAED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAED8 STA
    hw.write(cpu.address("dp", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_0CAEDA;
L_0CAEDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDAu, 5u, 3u, cpu.address("abs", 0x1462u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEDA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1462u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CAEDD;
L_0CAEDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEDD SEC
    cpu.setFlag('C', true);
    goto L_0CAEDE;
L_0CAEDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDEu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEDE SBC
    cpu.sbc(0x2u);
    goto L_0CAEE1;
L_0CAEE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE1u, 5u, 3u, cpu.address("abs", 0x1462u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEE1 STA
    hw.write(cpu.address("abs", 0x1462u), cpu.a, cpu.m8?8:16);
    goto L_0CAEE4;
L_0CAEE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE4u, 5u, 3u, cpu.address("abs", 0x146Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEE4 STA
    hw.write(cpu.address("abs", 0x146Au), cpu.a, cpu.m8?8:16);
    goto L_0CAEE7;
L_0CAEE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEE7 INC
    cpu.incMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_0CAEE9;
L_0CAEE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE9u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE9u, 8u, 3u, cpu.address("abs", 0x1466u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEE9 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1466u), cpu.m8?8:16);
    goto L_0CAEEC;
L_0CAEEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEEC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CAEEE;
L_0CAEEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEEu,cpu,0x2Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEEu, 5u, 3u, cpu.address("abs", 0x1462u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEEE AND
    cpu.logicAnd(hw.readW(cpu.address("abs", 0x1462u), cpu.m8?8:16));
    goto L_0CAEF1;
L_0CAEF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEF1 AND
    cpu.logicAnd(0xFFu);
    goto L_0CAEF4;
L_0CAEF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEF4 SEP
    cpu.sep(0x20u);
    goto L_0CAEF6;
L_0CAEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEF6 BNE -> $0CAF0C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CAF0C; }
    goto L_0CAEF8;
L_0CAEF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF8u, 4u, 3u, cpu.address("abs", 0x145Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEF8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x145Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CAEFB;
L_0CAEFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEFB BNE -> $0CAF0C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CAF0C; }
    goto L_0CAEFD;
L_0CAEFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFDu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFDu, 6u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAEFD INC
    cpu.incMem(hw, cpu.address("abs", 0x100u), cpu.m8?8:16);
    goto L_0CAF00;
L_0CAF00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF00u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF00u, 4u, 3u, cpu.address("abs", 0x1DE9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAF00 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DE9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CAF03;
L_0CAF03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF03u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF03u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAF03 CMP
    cpu.compareA(0xCu);
    goto L_0CAF05;
L_0CAF05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF05u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF05u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAF05 BEQ -> $0CAF0C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CAF0C; }
    goto L_0CAF07;
L_0CAF07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF07u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAF07 LDA
    cpu.setA(0x22u, 8);
    goto L_0CAF09;
L_0CAF09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF09u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF09u, 4u, 3u, cpu.address("abs", 0x0100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAF09 STA
    hw.write(cpu.address("abs", 0x100u), cpu.a, cpu.m8?8:16);
    goto L_0CAF0C;
L_0CAF0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAF0C SEP
    cpu.sep(0x20u);
    goto L_0CAF0E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAF0C SEP
    cpu.sep(0x20u);
    goto L_0CAF0E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF0Cu,0x0CAF0Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_0CAF0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Eu, 3u, 3u, cpu.address("abs", 0xB5BCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CAF0E JMP -> $0CB5BC
    goto L_0CB5BC;
L_0CB5BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5BC LDA
    cpu.setA(0x0u, 8);
    goto L_0CB5BE;
L_0CB5BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BEu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5BE XBA
    cpu.xba();
    goto L_0CB5BF;
L_0CB5BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5BF LDY
    cpu.setY(0x20u, 8);
    goto L_0CB5C1;
L_0CB5C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C1u, 4u, 3u, cpu.address("abs", 0x1DE9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5C1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1DE9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CB5C4;
L_0CB5C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5C4 CMP
    cpu.compareA(0x5u);
    goto L_0CB5C6;
L_0CB5C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5C6 BNE -> $0CB5CA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CB5CA; }
    goto L_0CB5C8;
L_0CB5C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5C8 LDY
    cpu.setY(0x30u, 8);
    goto L_0CB5CA;
L_0CB5CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CAu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5CA STY
    hw.write(cpu.address("dp", 0x0u), cpu.y, cpu.x8?8:16);
    goto L_0CB5CC;
L_0CB5CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5CC ASL
    cpu.aslA();
    goto L_0CB5CD;
L_0CB5CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5CD REP
    cpu.rep(0x10u);
    goto L_0CB5CF;
L_0CB5CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5CF TAY
    cpu.transfer("TAY");
    goto L_0CB5D0;
L_0CB5D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D0u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D0u, 5u + 1u, 3u, cpu.address("absy", 0xB5A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5D0 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xB5A2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0CB5D3;
L_0CB5D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D3u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5D3 LDY
    cpu.setY(0x7Fu, 16);
    goto L_0CB5D6;
L_0CB5D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D6u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5D6 STY
    hw.write(cpu.address("dp", 0x1u), cpu.y, cpu.x8?8:16);
    goto L_0CB5D8;
L_0CB5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5D8 LDY
    cpu.setY(0x1FCu, 16);
    goto L_0CB5DB;
L_0CB5DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DBu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CB5DB PHY
    cpu.push("PHY", hw);
    goto L_0CB5DC;
L_0CB5DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DCu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5DC LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0CB5DE;
L_0CB5DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DEu, 4u + 1u, 3u, cpu.address("absx", 0xAF14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5DE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xAF14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CB5E1;
L_0CB5E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5E1 AND
    cpu.logicAnd(0x20u);
    goto L_0CB5E3;
L_0CB5E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5E3 BEQ -> $0CB5E8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CB5E8; }
    goto L_0CB5E5;
L_0CB5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u, 5u, 3u, cpu.address("abs", 0x1462u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5E5 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1462u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0CB5E8;
L_0CB5E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E8u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5E8 STY
    hw.write(cpu.address("dp", 0x3u), cpu.y, cpu.x8?8:16);
    goto L_0CB5EA;
L_0CB5EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EAu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EAu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CB5EA PLY
    cpu.pop("PLY", hw);
    goto L_0CB5EB;
L_0CB5EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EBu, 4u + 1u, 3u, cpu.address("absx", 0xAF11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5EB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xAF11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CB5EE;
L_0CB5EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5EE CMP
    cpu.compareA(0xFFu);
    goto L_0CB5F0;
L_0CB5F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5F0 BEQ -> $0CB633
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0CB633; }
    goto L_0CB5F2;
L_0CB5F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5F2 SEC
    cpu.setFlag('C', true);
    goto L_0CB5F3;
L_0CB5F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F3u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5F3 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16));
    goto L_0CB5F5;
L_0CB5F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F5u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F5u, 5u, 3u, cpu.address("absy", 0x0200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5F5 STA
    hw.write(cpu.address("absy", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_0CB5F8;
L_0CB5F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5F8 LDA
    cpu.setA(0x0u, 8);
    goto L_0CB5FA;
L_0CB5FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FAu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5FA SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_0CB5FC;
L_0CB5FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5FC AND
    cpu.logicAnd(0x1u);
    goto L_0CB5FE;
L_0CB5FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB5FE STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_0CB600;
L_0CB600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB600u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB600u, 4u + 1u, 3u, cpu.address("absx", 0xAF14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB600 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xAF14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CB603;
L_0CB603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB603u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB603u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB603 AND
    cpu.logicAnd(0x10u);
    goto L_0CB605;
L_0CB605:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB605u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB605u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB605u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB605 LSR
    cpu.lsrA();
    goto L_0CB606;
L_0CB606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB606u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB606u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB606 LSR
    cpu.lsrA();
    goto L_0CB607;
L_0CB607:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB607u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB607u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB607u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB607 LSR
    cpu.lsrA();
    goto L_0CB608;
L_0CB608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB608u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB608u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB608 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_0CB60A;
L_0CB60A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Au,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CB60A PHY
    cpu.push("PHY", hw);
    goto L_0CB60B;
L_0CB60B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB60B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0CB60D;
L_0CB60D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Du, 5u, 3u, cpu.address("absy", 0x0420u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB60D STA
    hw.write(cpu.address("absy", 0x420u), cpu.a, cpu.m8?8:16);
    goto L_0CB610;
L_0CB610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB610u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB610u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CB610 PLY
    cpu.pop("PLY", hw);
    goto L_0CB611;
L_0CB611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB611u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB611u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB611u, 4u + 1u, 3u, cpu.address("absx", 0xAF12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB611 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xAF12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CB614;
L_0CB614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB614u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB614u, 5u, 3u, cpu.address("absy", 0x0201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB614 STA
    hw.write(cpu.address("absy", 0x201u), cpu.a, cpu.m8?8:16);
    goto L_0CB617;
L_0CB617:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB617u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB617u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB617u, 4u + 1u, 3u, cpu.address("absx", 0xAF13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB617 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xAF13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CB61A;
L_0CB61A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Au, 5u, 3u, cpu.address("absy", 0x0202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB61A STA
    hw.write(cpu.address("absy", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_0CB61D;
L_0CB61D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Du, 4u + 1u, 3u, cpu.address("absx", 0xAF14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB61D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xAF14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0CB620;
L_0CB620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB620u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB620u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB620 AND
    cpu.logicAnd(0xCFu);
    goto L_0CB622;
L_0CB622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB622u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB622u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB622 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_0CB624;
L_0CB624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB624u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB624u, 5u, 3u, cpu.address("absy", 0x0203u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB624 STA
    hw.write(cpu.address("absy", 0x203u), cpu.a, cpu.m8?8:16);
    goto L_0CB627;
L_0CB627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB627u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB627u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB627 DEY
    cpu.decReg('Y');
    goto L_0CB628;
L_0CB628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB628u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB628u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB628u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB628 DEY
    cpu.decReg('Y');
    goto L_0CB629;
L_0CB629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB629u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB629u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB629 DEY
    cpu.decReg('Y');
    goto L_0CB62A;
L_0CB62A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB62A DEY
    cpu.decReg('Y');
    goto L_0CB62B;
L_0CB62B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB62B INX
    cpu.inc('X');
    goto L_0CB62C;
L_0CB62C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB62C INX
    cpu.inc('X');
    goto L_0CB62D;
L_0CB62D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB62D INX
    cpu.inc('X');
    goto L_0CB62E;
L_0CB62E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB62E INX
    cpu.inc('X');
    goto L_0CB62F;
L_0CB62F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Fu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB62F DEC
    cpu.decMem(hw, cpu.address("dp", 0x1u), cpu.m8?8:16);
    goto L_0CB631;
L_0CB631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB631u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB631u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB631u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB631 BRA -> $0CB5DB
    goto L_0CB5DB;
L_0CB633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB633u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB633u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0CB633 SEP
    cpu.sep(0x10u);
    goto L_0CB635;
L_0CB635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB635u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB635u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB635u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0CB635 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0CB635u);return;} hw.unresolvedReturn(0x0CB635u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DA82A_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DA82Au: goto L_0DA82A;
    case 0x0DA82Cu: goto L_0DA82C;
    case 0x0DA82Du: goto L_0DA82D;
    case 0x0DA82Fu: goto L_0DA82F;
    case 0x0DA831u: goto L_0DA831;
    case 0x0DA832u: goto L_0DA832;
    case 0x0DA834u: goto L_0DA834;
    case 0x0DA836u: goto L_0DA836;
    case 0x0DA837u: goto L_0DA837;
    case 0x0DA839u: goto L_0DA839;
    case 0x0DA83Bu: goto L_0DA83B;
    case 0x0DA83Du: goto L_0DA83D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DA82A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA82Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA82A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x57u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA82C;
L_0DA82C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA82Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA82C CLC
    cpu.setFlag('C', false);
    goto L_0DA82D;
L_0DA82D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA82Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA82D ADC
    cpu.adc(0x10u);
    goto L_0DA82F;
L_0DA82F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA82Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA82Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA82F STA
    hw.write(cpu.address("dp", 0x57u), cpu.a, cpu.m8?8:16);
    goto L_0DA831;
L_0DA831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA831u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA831u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA831 TAY
    cpu.transfer("TAY");
    goto L_0DA832;
L_0DA832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA832u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA832u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA832 BCC -> $0DA83D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_0DA83D; }
    goto L_0DA834;
L_0DA834:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA834u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA834u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA834u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA834 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DA836;
L_0DA836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA836u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA836u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA836 CLC
    cpu.setFlag('C', false);
    goto L_0DA837;
L_0DA837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA837u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA837u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA837 ADC
    cpu.adc(0x2u);
    goto L_0DA839;
L_0DA839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA839u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA839u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA839u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA839 STA
    hw.write(cpu.address("dp", 0x6Cu), cpu.a, cpu.m8?8:16);
    goto L_0DA83B;
L_0DA83B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA83Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DA83B STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_0DA83D;
L_0DA83D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA83Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA83Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DA83D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DA83Du);return;} hw.unresolvedReturn(0x0DA83Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_0DDC02_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0DDC02u: goto L_0DDC02;
    case 0x0DDC04u: goto L_0DDC04;
    case 0x0DDC06u: goto L_0DDC06;
    case 0x0DDC08u: goto L_0DDC08;
    case 0x0DDC0Au: goto L_0DDC0A;
    case 0x0DDC0Du: goto L_0DDC0D;
    case 0x0DDC0Fu: goto L_0DDC0F;
    case 0x0DDC10u: goto L_0DDC10;
    case 0x0DDC11u: goto L_0DDC11;
    case 0x0DDC12u: goto L_0DDC12;
    case 0x0DDC13u: goto L_0DDC13;
    case 0x0DDC15u: goto L_0DDC15;
    case 0x0DDC17u: goto L_0DDC17;
    case 0x0DDC1Au: goto L_0DDC1A;
    case 0x0DDC1Du: goto L_0DDC1D;
    case 0x0DDC1Fu: goto L_0DDC1F;
    case 0x0DDC22u: goto L_0DDC22;
    case 0x0DDC23u: goto L_0DDC23;
    case 0x0DDC25u: goto L_0DDC25;
    case 0x0DDC27u: goto L_0DDC27;
    case 0x0DDC2Au: goto L_0DDC2A;
    case 0x0DDC2Cu: goto L_0DDC2C;
    case 0x0DDC2Fu: goto L_0DDC2F;
    case 0x0DDC32u: goto L_0DDC32;
    case 0x0DDC34u: goto L_0DDC34;
    case 0x0DDC37u: goto L_0DDC37;
    case 0x0DDC38u: goto L_0DDC38;
    case 0x0DDC39u: goto L_0DDC39;
    case 0x0DDC3Bu: goto L_0DDC3B;
    case 0x0DDC3Du: goto L_0DDC3D;
    case 0x0DDC40u: goto L_0DDC40;
    case 0x0DDC42u: goto L_0DDC42;
    case 0x0DDC45u: goto L_0DDC45;
    case 0x0DDC48u: goto L_0DDC48;
    case 0x0DDC4Au: goto L_0DDC4A;
    case 0x0DDC4Du: goto L_0DDC4D;
    case 0x0DDC50u: goto L_0DDC50;
    case 0x0DDC53u: goto L_0DDC53;
    case 0x0DDC55u: goto L_0DDC55;
    case 0x0DDC57u: goto L_0DDC57;
    case 0x0DDC59u: goto L_0DDC59;
    case 0x0DDC5Bu: goto L_0DDC5B;
    case 0x0DDC5Du: goto L_0DDC5D;
    case 0x0DDC5Eu: goto L_0DDC5E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0DDC02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC02u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC02u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x57u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC02 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x57u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DDC04;
L_0DDC04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC04u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC04 LDX
    cpu.setX(0x1u, 8);
    goto L_0DDC06;
L_0DDC06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC06u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC06u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC06 STX
    hw.write(cpu.address("dp", 0x2u), cpu.x, cpu.x8?8:16);
    goto L_0DDC08;
L_0DDC08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC08u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC08u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC08 STX
    hw.write(cpu.address("dp", 0x0u), cpu.x, cpu.x8?8:16);
    goto L_0DDC0A;
L_0DDC0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Au, 6u, 3u, cpu.address("abs", 0xA6B1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC0A JSR -> $0DA6B1 stack real
    { cpu.push16Value(hw,0xDC0Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC0Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6B1u), 0x0DDC0Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC0D;
L_0DDC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC0Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC0Du,0x0DDC0Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x59u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC0D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x59u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDC0F;
L_0DDC0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC0F LSR
    cpu.lsrA();
    goto L_0DDC10;
L_0DDC10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC10u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC10u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC10 LSR
    cpu.lsrA();
    goto L_0DDC11;
L_0DDC11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC11 LSR
    cpu.lsrA();
    goto L_0DDC12;
L_0DDC12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC12u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC12 LSR
    cpu.lsrA();
    goto L_0DDC13;
L_0DDC13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC13u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC13u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC13 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_0DDC15;
L_0DDC15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC15u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC15u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC15 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DDC17;
L_0DDC17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC17u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC17u, 3u, 3u, cpu.address("abs", 0xDC3Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC17 JMP -> $0DDC3D
    goto L_0DDC3D;
L_0DDC1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC1A JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDC1Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC1Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDC1Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC1D;
L_0DDC1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC1Du,0x0DDC1Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC1D LDA
    cpu.setA(0xFFu, 8);
    goto L_0DDC1F;
L_0DDC1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC1F JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xDC21u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC22u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DDC1Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC22;
L_0DDC22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC22u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC22u,0x0DDC22u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC22 DEX
    cpu.decReg('X');
    goto L_0DDC23;
L_0DDC23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC23u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC23 CPX
    cpu.compareX(0x3u);
    goto L_0DDC25;
L_0DDC25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC25u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC25u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC25 BNE -> $0DDC1A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DDC1A; }
    goto L_0DDC27;
L_0DDC27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC27u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC27u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC27 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDC29u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC2Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDC27u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC2A;
L_0DDC2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC2Au,0x0DDC2Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC2A LDA
    cpu.setA(0xFFu, 8);
    goto L_0DDC2C;
L_0DDC2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Cu, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC2C JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xDC2Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC2Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DDC2Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC2F;
L_0DDC2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC2Fu,0x0DDC2Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Fu, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC2F JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDC31u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC32u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDC2Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC32;
L_0DDC32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC32u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC32u,0x0DDC32u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC32u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC32 LDA
    cpu.setA(0xFCu, 8);
    goto L_0DDC34;
L_0DDC34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC34u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC34u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC34 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xDC36u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC37u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DDC34u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC37;
L_0DDC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC37u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC37u,0x0DDC37u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC37u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC37u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC37 DEX
    cpu.decReg('X');
    goto L_0DDC38;
L_0DDC38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC38u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC38 DEX
    cpu.decReg('X');
    goto L_0DDC39;
L_0DDC39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC39u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC39u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC39 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0DDC3B;
L_0DDC3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC3B BEQ -> $0DDC5D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0DDC5D; }
    goto L_0DDC3D;
L_0DDC3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Du, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC3D JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDC3Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC40u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDC3Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC40;
L_0DDC40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC40u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC40u,0x0DDC40u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC40u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC40 LDA
    cpu.setA(0xD4u, 8);
    goto L_0DDC42;
L_0DDC42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC42u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC42u, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC42 JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xDC44u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC45u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DDC42u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC45;
L_0DDC45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC45u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC45u,0x0DDC45u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC45u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC45u, 6u, 3u, cpu.address("abs", 0xAA08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC45 JSR -> $0DAA08 stack real
    { cpu.push16Value(hw,0xDC47u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC48u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA08u), 0x0DDC45u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC48;
L_0DDC48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC48u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC48u,0x0DDC48u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC48u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC48u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC48 LDA
    cpu.setA(0xD5u, 8);
    goto L_0DDC4A;
L_0DDC4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Au, 6u, 3u, cpu.address("abs", 0xA95Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC4A JSR -> $0DA95B stack real
    { cpu.push16Value(hw,0xDC4Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC4Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA95Bu), 0x0DDC4Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC4D;
L_0DDC4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC4Du,0x0DDC4Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Du, 6u, 3u, cpu.address("abs", 0xA6BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC4D JSR -> $0DA6BA stack real
    { cpu.push16Value(hw,0xDC4Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC50u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA6BAu), 0x0DDC4Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC50;
L_0DDC50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC50u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC50u,0x0DDC50u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC50u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC50u, 6u, 3u, cpu.address("abs", 0xA97Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC50 JSR -> $0DA97D stack real
    { cpu.push16Value(hw,0xDC52u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC53u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA97Du), 0x0DDC50u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0DDC53;
L_0DDC53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC53u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC53u,0x0DDC53u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC53u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC53u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC53 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DDC55;
L_0DDC55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC55u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC55u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC55 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_0DDC57;
L_0DDC57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC57u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC57u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC57 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_0DDC59;
L_0DDC59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC59u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC59u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC59 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_0DDC5B;
L_0DDC5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC5B BPL -> $0DDC5E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0DDC5E; }
    goto L_0DDC5D;
L_0DDC5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0DDC5D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x0DDC5Du);return;} hw.unresolvedReturn(0x0DDC5Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_0DDC5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Eu, 3u, 3u, cpu.address("abs", 0xDC23u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0DDC5E JMP -> $0DDC23
    goto L_0DDC23;
}

void sub_B19425_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB19425u: goto L_B19425;
    case 0xB19427u: goto L_B19427;
    case 0xB19429u: goto L_B19429;
    case 0xB1942Bu: goto L_B1942B;
    case 0xB1942Du: goto L_B1942D;
    case 0xB1942Fu: goto L_B1942F;
    case 0xB19431u: goto L_B19431;
    case 0xB19433u: goto L_B19433;
    case 0xB19435u: goto L_B19435;
    case 0xB19437u: goto L_B19437;
    case 0xB1943Au: goto L_B1943A;
    case 0xB1943Du: goto L_B1943D;
    case 0xB19440u: goto L_B19440;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B19425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9425u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9425u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19425 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19427;
L_B19427:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9427u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9427u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9427u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19427 STA
    hw.write(cpu.address("dp", 0x9Au), cpu.a, cpu.m8?8:16);
    goto L_B19429;
L_B19429:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9429u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9429u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9429u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19429 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1942B;
L_B1942B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x942Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x942Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x942Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1942B STA
    hw.write(cpu.address("dp", 0x9Bu), cpu.a, cpu.m8?8:16);
    goto L_B1942D;
L_B1942D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x942Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x942Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x942Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1942D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1942F;
L_B1942F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x942Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x942Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x942Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1942F STA
    hw.write(cpu.address("dp", 0x98u), cpu.a, cpu.m8?8:16);
    goto L_B19431;
L_B19431:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9431u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9431u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9431u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19431 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B19433;
L_B19433:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9433u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9433u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9433u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x99u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19433 STA
    hw.write(cpu.address("dp", 0x99u), cpu.a, cpu.m8?8:16);
    goto L_B19435;
L_B19435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9435u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9435u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19435 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B19437;
L_B19437:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9437u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9437u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9437u, 4u + ((((0x1588u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B19437 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1588u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1943A;
L_B1943A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x943Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x943Au,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x943Au, 4u + ((((0x9134u & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0x9134u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1943A ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x9134u), cpu.m8?8:16));
    goto L_B1943D;
L_B1943D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x943Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x943Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x943Du, 5u, 3u, cpu.address("absx", 0x1588u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1943D STA
    hw.write(cpu.address("absx", 0x1588u), cpu.a, cpu.m8?8:16);
    goto L_B19440;
L_B19440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9440u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9440u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B19440 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB19440u);return;} hw.unresolvedReturn(0xB19440u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B19B13_E0M1X1C0_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB185C3u: goto L_B185C3;
    case 0xB185C6u: goto L_B185C6;
    case 0xB185C8u: goto L_B185C8;
    case 0xB185CCu: goto L_B185CC;
    case 0xB185CEu: goto L_B185CE;
    case 0xB185D0u: goto L_B185D0;
    case 0xB185D2u: goto L_B185D2;
    case 0xB185D4u: goto L_B185D4;
    case 0xB185D7u: goto L_B185D7;
    case 0xB185D8u: goto L_B185D8;
    case 0xB185DBu: goto L_B185DB;
    case 0xB185DCu: goto L_B185DC;
    case 0xB185DFu: goto L_B185DF;
    case 0xB185E2u: goto L_B185E2;
    case 0xB185E5u: goto L_B185E5;
    case 0xB185E6u: goto L_B185E6;
    case 0xB185E8u: goto L_B185E8;
    case 0xB185E9u: goto L_B185E9;
    case 0xB185EBu: goto L_B185EB;
    case 0xB185ECu: goto L_B185EC;
    case 0xB185EFu: goto L_B185EF;
    case 0xB185F0u: goto L_B185F0;
    case 0xB185F1u: goto L_B185F1;
    case 0xB185F2u: goto L_B185F2;
    case 0xB185F5u: goto L_B185F5;
    case 0xB185F8u: goto L_B185F8;
    case 0xB185FAu: goto L_B185FA;
    case 0xB185FCu: goto L_B185FC;
    case 0xB185FEu: goto L_B185FE;
    case 0xB185FFu: goto L_B185FF;
    case 0xB18601u: goto L_B18601;
    case 0xB18604u: goto L_B18604;
    case 0xB18606u: goto L_B18606;
    case 0xB18609u: goto L_B18609;
    case 0xB1860Du: goto L_B1860D;
    case 0xB18610u: goto L_B18610;
    case 0xB18614u: goto L_B18614;
    case 0xB18618u: goto L_B18618;
    case 0xB1861Au: goto L_B1861A;
    case 0xB1861Eu: goto L_B1861E;
    case 0xB18620u: goto L_B18620;
    case 0xB18622u: goto L_B18622;
    case 0xB18624u: goto L_B18624;
    case 0xB18626u: goto L_B18626;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B185C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u, 4u, 3u, cpu.address("abs", 0x1491u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185C3 STZ
    hw.write(cpu.address("abs", 0x1491u), 0, cpu.m8?8:16);
    goto L_B185C6;
L_B185C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185C6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B185C8;
L_B185C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C8u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B185C8 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x85CBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x85CCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0xB185C8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B185CC;
L_B185CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85CCu,0xB185CCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CCu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185CC TSB
    cpu.tsb(hw, cpu.address("dp", 0x89u), cpu.m8?8:16);
    goto L_B185CE;
L_B185CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CEu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185CE TSB
    cpu.tsb(hw, cpu.address("dp", 0x89u), cpu.m8?8:16);
    goto L_B185D0;
L_B185D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D0u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185D0 TSB
    cpu.tsb(hw, cpu.address("dp", 0x89u), cpu.m8?8:16);
    goto L_B185D2;
L_B185D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185D2 TSB
    cpu.tsb(hw, cpu.address("dp", 0x89u), cpu.m8?8:16);
    goto L_B185D4;
L_B185D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D4u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D4u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC8Au + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $B185D4 JSR (FC8A,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC8Au+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x85D6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x85D7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0xB185D4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B185D7;
L_B185D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85D7u,0xB185D7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185D7 TXA
    cpu.transfer("TXA");
    goto L_B185D8;
L_B185D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D8u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D8u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC8Au + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $B185D8 JSR (FC8A,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC8Au+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x85DAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x85DBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0xB185D8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B185DB;
L_B185DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85DBu,0xB185DBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DBu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185DB TXA
    cpu.transfer("TXA");
    goto L_B185DC;
L_B185DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu, 4u, 3u, cpu.address("abs", 0x4D8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185DC EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0x4D8Cu), cpu.m8?8:16));
    goto L_B185DF;
L_B185DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu, 4u, 3u, cpu.address("abs", 0x8CC3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185DF STY
    hw.write(cpu.address("abs", 0x8CC3u), cpu.y, cpu.x8?8:16);
    goto L_B185E2;
L_B185E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E2u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E2u, 4u + ((((0xFC8Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xFC8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185E2 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xFC8Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B185E5;
L_B185E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185E5 TXA
    cpu.transfer("TXA");
    goto L_B185E6;
L_B185E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E6u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185E6 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16));
    goto L_B185E8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185E6 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16));
    goto L_B185E8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85E6u,0xB185E6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E8u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185E8 INY
    cpu.inc('Y');
    goto L_B185E9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85E8u,0xB185E8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E9u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E9u,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E9u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFCu + cpu.x) & 0xFFFFu), 2u, 0u);
    // $B185E9 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0xFCu), cpu.m8?8:16));
    goto L_B185EB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85E9u,0xB185E9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EBu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EBu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185EB TXA
    cpu.transfer("TXA");
    goto L_B185EC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85EBu,0xB185EBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85ECu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85ECu,cpu,0x2Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85ECu, 6u, 3u, cpu.address("abs", 0xFC8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185EC ROL
    cpu.rolMem(hw, cpu.address("abs", 0xFC8Du), cpu.m8?8:16);
    goto L_B185EF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85ECu,0xB185ECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EFu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EFu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185EF TXA
    cpu.transfer("TXA");
    goto L_B185F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85EFu,0xB185EFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F0u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F0u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185F0 TDC
    cpu.tdc();
    goto L_B185F1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85F0u,0xB185F0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F1u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F1u,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185F1 SED
    cpu.setFlag('D', true);
    goto L_B185F2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85F1u,0xB185F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F2u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F2u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F2u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x188Au + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $B185F2 JSR (188A,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x188Au+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x85F4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x85F5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0xB185F2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B185F5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85F2u,0xB185F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F5u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u, 4u, 3u, cpu.address("abs", 0xB033u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185F5 STY
    hw.write(cpu.address("abs", 0xB033u), cpu.y, cpu.x8?8:16);
    goto L_B185F8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85F5u,0xB185F5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F8u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xB0u) & 0xFFFFu), 2u, 0u);
    // $B185F8 AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0xB0u), cpu.m8?8:16));
    goto L_B185FA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85F8u,0xB185F8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FAu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FAu,cpu,0x92u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xB1u) & 0xFFFFu), 2u, 0u);
    // $B185FA STA
    hw.write(cpu.addressDpIndirect(hw, 0xB1u), cpu.a, cpu.m8?8:16);
    goto L_B185FC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85FAu,0xB185FAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FCu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FCu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185FC LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0xB1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B185FE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85FCu,0xB185FCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FEu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FEu,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185FE TCD
    cpu.tcd();
    goto L_B185FF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85FEu,0xB185FEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FFu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FFu,cpu,0xE7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FFu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x76u) & 0xFFFFu), 3u, 0u);
    // $B185FF SBC
    cpu.sbc(hw.readW(cpu.addressDpLong(hw, 0x76u), cpu.m8?8:16));
    goto L_B18601;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85FFu,0xB185FFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18601:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8601u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8601u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8601u, 4u, 3u, cpu.address("abs", 0x878Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18601 STX
    hw.write(cpu.address("abs", 0x878Eu), cpu.x, cpu.x8?8:16);
    goto L_B18604;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8601u,0xB18601u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18604:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8604u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8604u,cpu,0xE7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8604u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Fu) & 0xFFFFu), 3u, 0u);
    // $B18604 SBC
    cpu.sbc(hw.readW(cpu.addressDpLong(hw, 0x8Fu), cpu.m8?8:16));
    goto L_B18606;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8604u,0xB18604u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8606u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8606u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8606u, 4u, 3u, cpu.address("abs", 0x978Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18606 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x978Fu), cpu.m8?8:16));
    goto L_B18609;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8606u,0xB18606u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8609u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u, 5u, 4u, 0x38BDD6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18609 STA
    hw.write(0x38BDD6u, cpu.a, cpu.m8?8:16);
    goto L_B1860D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8609u,0xB18609u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1860D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Du))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Du,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Du, 4u + ((((0xC353u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xC353u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1860D LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xC353u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B18610;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x860Du,0xB1860Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8610u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8610u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8610u, 5u, 4u, ((0xB97FB9u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18610 ADC
    cpu.adc(hw.readW(((0xB97FB9u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_B18614;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8610u,0xB18610u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8614u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8614u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8614u, 5u, 4u, ((0xB97FB9u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18614 ADC
    cpu.adc(hw.readW(((0xB97FB9u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_B18618;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8614u,0xB18614u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8618u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u,cpu,0xA3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u, 4u, 2u, cpu.addressStack(0xAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18618 LDA
    cpu.loadA(hw.readW(cpu.addressStack(0xAEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1861A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8618u,0xB18618u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1861A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Au))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Au,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Au, 5u, 4u, ((0xF8D5AFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1861A STA
    hw.write(((0xF8D5AFu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_B1861E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x861Au,0xB1861Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1861E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Eu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu,cpu,0xC1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFAu + cpu.x) & 0xFFFFu), 2u, 0u);
    // $B1861E CMP
    cpu.compareA(hw.readW(cpu.addressDpIndirectX(hw, 0xFAu), cpu.m8?8:16));
    goto L_B18620;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x861Eu,0xB1861Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8620u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8620u,cpu,0x76u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8620u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x8Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18620 ROR
    cpu.rorMem(hw, cpu.address("dpx", 0x8Eu), cpu.m8?8:16);
    goto L_B18622;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8620u,0xB18620u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8622u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8622u,cpu,0xB6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8622u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpy", 0x87u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18622 LDX
    cpu.setX(hw.readW(cpu.address("dpy", 0x87u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B18624;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8622u,0xB18622u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8624u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8624u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8624u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18624 STZ
    hw.write(cpu.address("dp", 0xF7u), 0, cpu.m8?8:16);
    goto L_B18626;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8624u,0xB18624u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8626u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8626u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8626u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18626 REP
    cpu.rep(0x85u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8628u,0xB18626u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8626u,0xB18626u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_B19B13_E0M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB185C3u: goto L_B185C3;
    case 0xB185C6u: goto L_B185C6;
    case 0xB185C8u: goto L_B185C8;
    case 0xB185CCu: goto L_B185CC;
    case 0xB185CEu: goto L_B185CE;
    case 0xB185D0u: goto L_B185D0;
    case 0xB185D2u: goto L_B185D2;
    case 0xB185D4u: goto L_B185D4;
    case 0xB185D7u: goto L_B185D7;
    case 0xB185D8u: goto L_B185D8;
    case 0xB185DBu: goto L_B185DB;
    case 0xB185DCu: goto L_B185DC;
    case 0xB185DFu: goto L_B185DF;
    case 0xB185E2u: goto L_B185E2;
    case 0xB185E5u: goto L_B185E5;
    case 0xB185E6u: goto L_B185E6;
    case 0xB185E8u: goto L_B185E8;
    case 0xB185E9u: goto L_B185E9;
    case 0xB185EBu: goto L_B185EB;
    case 0xB185ECu: goto L_B185EC;
    case 0xB185EFu: goto L_B185EF;
    case 0xB185F0u: goto L_B185F0;
    case 0xB185F1u: goto L_B185F1;
    case 0xB185F2u: goto L_B185F2;
    case 0xB185F5u: goto L_B185F5;
    case 0xB185F8u: goto L_B185F8;
    case 0xB185FAu: goto L_B185FA;
    case 0xB185FCu: goto L_B185FC;
    case 0xB185FEu: goto L_B185FE;
    case 0xB185FFu: goto L_B185FF;
    case 0xB18601u: goto L_B18601;
    case 0xB18604u: goto L_B18604;
    case 0xB18606u: goto L_B18606;
    case 0xB18609u: goto L_B18609;
    case 0xB1860Du: goto L_B1860D;
    case 0xB18610u: goto L_B18610;
    case 0xB18614u: goto L_B18614;
    case 0xB18618u: goto L_B18618;
    case 0xB1861Au: goto L_B1861A;
    case 0xB1861Eu: goto L_B1861E;
    case 0xB18620u: goto L_B18620;
    case 0xB18622u: goto L_B18622;
    case 0xB18624u: goto L_B18624;
    case 0xB18626u: goto L_B18626;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B185C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u, 4u, 3u, cpu.address("abs", 0x1491u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185C3 STZ
    hw.write(cpu.address("abs", 0x1491u), 0, cpu.m8?8:16);
    goto L_B185C6;
L_B185C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x9Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185C6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B185C8;
L_B185C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C8u, 8u, 4u, 0x0086DFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B185C8 JSL -> $0086DF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x85CBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x85CCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x0086DFu, 0xB185C8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B185CC;
L_B185CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85CCu,0xB185CCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CCu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185CC TSB
    cpu.tsb(hw, cpu.address("dp", 0x89u), cpu.m8?8:16);
    goto L_B185CE;
L_B185CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CEu,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185CE TSB
    cpu.tsb(hw, cpu.address("dp", 0x89u), cpu.m8?8:16);
    goto L_B185D0;
L_B185D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D0u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185D0 TSB
    cpu.tsb(hw, cpu.address("dp", 0x89u), cpu.m8?8:16);
    goto L_B185D2;
L_B185D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185D2 TSB
    cpu.tsb(hw, cpu.address("dp", 0x89u), cpu.m8?8:16);
    goto L_B185D4;
L_B185D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D4u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D4u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC8Au + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $B185D4 JSR (FC8A,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC8Au+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x85D6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x85D7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0xB185D4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B185D7;
L_B185D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85D7u,0xB185D7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185D7 TXA
    cpu.transfer("TXA");
    goto L_B185D8;
L_B185D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D8u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D8u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xFC8Au + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $B185D8 JSR (FC8A,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xFC8Au+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x85DAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x85DBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0xB185D8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B185DB;
L_B185DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85DBu,0xB185DBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DBu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185DB TXA
    cpu.transfer("TXA");
    goto L_B185DC;
L_B185DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu, 4u, 3u, cpu.address("abs", 0x4D8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185DC EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0x4D8Cu), cpu.m8?8:16));
    goto L_B185DF;
L_B185DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu, 4u, 3u, cpu.address("abs", 0x8CC3u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185DF STY
    hw.write(cpu.address("abs", 0x8CC3u), cpu.y, cpu.x8?8:16);
    goto L_B185E2;
L_B185E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E2u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E2u, 4u + ((((0xFC8Cu & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xFC8Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185E2 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xFC8Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B185E5;
L_B185E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185E5 TXA
    cpu.transfer("TXA");
    goto L_B185E6;
L_B185E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E6u))return;
  // 5 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185E6 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16));
    goto L_B185E8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185E6 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16));
    goto L_B185E8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85E6u,0xB185E6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E8u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185E8 INY
    cpu.inc('Y');
    goto L_B185E9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85E8u,0xB185E8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E9u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E9u,cpu,0xE1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E9u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFCu + cpu.x) & 0xFFFFu), 2u, 0u);
    // $B185E9 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirectX(hw, 0xFCu), cpu.m8?8:16));
    goto L_B185EB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85E9u,0xB185E9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EBu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EBu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185EB TXA
    cpu.transfer("TXA");
    goto L_B185EC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85EBu,0xB185EBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85ECu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85ECu,cpu,0x2Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85ECu, 6u, 3u, cpu.address("abs", 0xFC8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185EC ROL
    cpu.rolMem(hw, cpu.address("abs", 0xFC8Du), cpu.m8?8:16);
    goto L_B185EF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85ECu,0xB185ECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EFu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EFu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185EF TXA
    cpu.transfer("TXA");
    goto L_B185F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85EFu,0xB185EFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F0u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F0u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185F0 TDC
    cpu.tdc();
    goto L_B185F1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85F0u,0xB185F0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F1u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F1u,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185F1 SED
    cpu.setFlag('D', true);
    goto L_B185F2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85F1u,0xB185F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F2u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F2u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F2u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x188Au + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $B185F2 JSR (188A,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x188Au+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x85F4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x85F5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0xB185F2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B185F5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85F2u,0xB185F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F5u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u, 4u, 3u, cpu.address("abs", 0xB033u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185F5 STY
    hw.write(cpu.address("abs", 0xB033u), cpu.y, cpu.x8?8:16);
    goto L_B185F8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85F5u,0xB185F5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F8u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u,cpu,0x33u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u, 7u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0xB0u) & 0xFFFFu), 2u, 0u);
    // $B185F8 AND
    cpu.logicAnd(hw.readW(cpu.addressStackIndirectY(hw, 0xB0u), cpu.m8?8:16));
    goto L_B185FA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85F8u,0xB185F8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FAu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FAu,cpu,0x92u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xB1u) & 0xFFFFu), 2u, 0u);
    // $B185FA STA
    hw.write(cpu.addressDpIndirect(hw, 0xB1u), cpu.a, cpu.m8?8:16);
    goto L_B185FC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85FAu,0xB185FAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FCu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FCu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185FC LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0xB1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B185FE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85FCu,0xB185FCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FEu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FEu,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B185FE TCD
    cpu.tcd();
    goto L_B185FF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85FEu,0xB185FEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B185FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FFu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FFu,cpu,0xE7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FFu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x76u) & 0xFFFFu), 3u, 0u);
    // $B185FF SBC
    cpu.sbc(hw.readW(cpu.addressDpLong(hw, 0x76u), cpu.m8?8:16));
    goto L_B18601;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85FFu,0xB185FFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18601:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8601u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8601u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8601u, 4u, 3u, cpu.address("abs", 0x878Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18601 STX
    hw.write(cpu.address("abs", 0x878Eu), cpu.x, cpu.x8?8:16);
    goto L_B18604;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8601u,0xB18601u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18604:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8604u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8604u,cpu,0xE7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8604u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Fu) & 0xFFFFu), 3u, 0u);
    // $B18604 SBC
    cpu.sbc(hw.readW(cpu.addressDpLong(hw, 0x8Fu), cpu.m8?8:16));
    goto L_B18606;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8604u,0xB18604u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8606u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8606u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8606u, 4u, 3u, cpu.address("abs", 0x978Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18606 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x978Fu), cpu.m8?8:16));
    goto L_B18609;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8606u,0xB18606u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8609u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u, 5u, 4u, 0x38BDD6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18609 STA
    hw.write(0x38BDD6u, cpu.a, cpu.m8?8:16);
    goto L_B1860D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8609u,0xB18609u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1860D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Du))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Du,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Du, 4u + ((((0xC353u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xC353u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1860D LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xC353u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B18610;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x860Du,0xB1860Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8610u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8610u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8610u, 5u, 4u, ((0xB97FB9u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18610 ADC
    cpu.adc(hw.readW(((0xB97FB9u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_B18614;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8610u,0xB18610u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8614u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8614u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8614u, 5u, 4u, ((0xB97FB9u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18614 ADC
    cpu.adc(hw.readW(((0xB97FB9u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_B18618;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8614u,0xB18614u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8618u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u,cpu,0xA3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u, 4u, 2u, cpu.addressStack(0xAEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18618 LDA
    cpu.loadA(hw.readW(cpu.addressStack(0xAEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1861A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8618u,0xB18618u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1861A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Au))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Au,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Au, 5u, 4u, ((0xF8D5AFu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1861A STA
    hw.write(((0xF8D5AFu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_B1861E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x861Au,0xB1861Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B1861E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Eu))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu,cpu,0xC1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xFAu + cpu.x) & 0xFFFFu), 2u, 0u);
    // $B1861E CMP
    cpu.compareA(hw.readW(cpu.addressDpIndirectX(hw, 0xFAu), cpu.m8?8:16));
    goto L_B18620;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x861Eu,0xB1861Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8620u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8620u,cpu,0x76u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8620u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x8Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18620 ROR
    cpu.rorMem(hw, cpu.address("dpx", 0x8Eu), cpu.m8?8:16);
    goto L_B18622;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8620u,0xB18620u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8622u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8622u,cpu,0xB6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8622u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpy", 0x87u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18622 LDX
    cpu.setX(hw.readW(cpu.address("dpy", 0x87u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B18624;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8622u,0xB18622u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8624u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8624u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8624u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xF7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18624 STZ
    hw.write(cpu.address("dp", 0xF7u), 0, cpu.m8?8:16);
    goto L_B18626;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8624u,0xB18624u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_B18626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8626u))return;
  // 5 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8626u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8626u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B18626 REP
    cpu.rep(0x85u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8628u,0xB18626u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8626u,0xB18626u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_B1A5DA_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1A5DAu: goto L_B1A5DA;
    case 0xB1A5DDu: goto L_B1A5DD;
    case 0xB1A5E0u: goto L_B1A5E0;
    case 0xB1A5E3u: goto L_B1A5E3;
    case 0xB1A5E5u: goto L_B1A5E5;
    case 0xB1A5E8u: goto L_B1A5E8;
    case 0xB1A5E9u: goto L_B1A5E9;
    case 0xB1A5EAu: goto L_B1A5EA;
    case 0xB1A5EEu: goto L_B1A5EE;
    case 0xB1A5EFu: goto L_B1A5EF;
    case 0xB1A5F1u: goto L_B1A5F1;
    case 0xB1A5F2u: goto L_B1A5F2;
    case 0xB1A5F4u: goto L_B1A5F4;
    case 0xB1A5F6u: goto L_B1A5F6;
    case 0xB1A5F8u: goto L_B1A5F8;
    case 0xB1A5FBu: goto L_B1A5FB;
    case 0xB1A5FDu: goto L_B1A5FD;
    case 0xB1A600u: goto L_B1A600;
    case 0xB1A601u: goto L_B1A601;
    case 0xB1A604u: goto L_B1A604;
    case 0xB1A607u: goto L_B1A607;
    case 0xB1A609u: goto L_B1A609;
    case 0xB1A60Bu: goto L_B1A60B;
    case 0xB1A60Eu: goto L_B1A60E;
    case 0xB1A611u: goto L_B1A611;
    case 0xB1A612u: goto L_B1A612;
    case 0xB1A614u: goto L_B1A614;
    case 0xB1A616u: goto L_B1A616;
    case 0xB1A618u: goto L_B1A618;
    case 0xB1A619u: goto L_B1A619;
    case 0xB1A61Du: goto L_B1A61D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1A5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DAu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DAu, 4u, 3u, cpu.address("abs", 0x15E9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5DA LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x15E9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A5DD;
L_B1A5DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DDu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DDu, 4u, 3u, cpu.address("abs", 0x1695u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5DD LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1695u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A5E0;
L_B1A5E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E0u, 6u, 3u, cpu.address("abs", 0xA77Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A5E0 JSR -> $B1A77C stack real
    { cpu.push16Value(hw,0xA5E2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5E3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA77Cu), 0xB1A5E0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A5E3;
L_B1A5E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5E3u,0xB1A5E3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5E3 LDA
    cpu.setA(0x2u, 8);
    goto L_B1A5E5;
L_B1A5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E5u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E5u, 5u, 3u, cpu.address("absy", 0x14C8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5E5 STA
    hw.write(cpu.address("absy", 0x14C8u), cpu.a, cpu.m8?8:16);
    goto L_B1A5E8;
L_B1A5E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E8u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A5E8 PHX
    cpu.push("PHX", hw);
    goto L_B1A5E9;
L_B1A5E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E9u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5E9 TYX
    cpu.transfer("TYX");
    goto L_B1A5EA;
L_B1A5EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EAu, 8u, 4u, 0x01AB72u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A5EA JSL -> $01AB72 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA5EDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5EEu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x01AB72u, 0xB1A5EAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A5EE;
L_B1A5EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EEu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5EEu,0xB1A5EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EEu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A5EE PLX
    cpu.pop("PLX", hw);
    goto L_B1A5EF;
L_B1A5EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EFu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xB6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5EF LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A5F1;
L_B1A5F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5F1 ASL
    cpu.aslA();
    goto L_B1A5F2;
L_B1A5F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5F2 LDA
    cpu.setA(0x10u, 8);
    goto L_B1A5F4;
L_B1A5F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F4u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5F4 BCC -> $B1A5F8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A5F8; }
    goto L_B1A5F6;
L_B1A5F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5F6 LDA
    cpu.setA(0xF0u, 8);
    goto L_B1A5F8;
L_B1A5F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F8u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5F8u, 5u, 3u, cpu.address("absy", 0x00B6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5F8 STA
    hw.write(cpu.address("absy", 0xB6u), cpu.a, cpu.m8?8:16);
    goto L_B1A5FB;
L_B1A5FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5FB LDA
    cpu.setA(0xD0u, 8);
    goto L_B1A5FD;
L_B1A5FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FDu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5FDu, 5u, 3u, cpu.address("absy", 0x00AAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A5FD STA
    hw.write(cpu.address("absy", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_B1A600;
L_B1A600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA600u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA600u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A600 PHY
    cpu.push("PHY", hw);
    goto L_B1A601;
L_B1A601:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA601u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA601u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA601u, 7u, 3u, cpu.address("absx", 0x1626u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A601 INC
    cpu.incMem(hw, cpu.address("absx", 0x1626u), cpu.m8?8:16);
    goto L_B1A604;
L_B1A604:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA604u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA604u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA604u, 4u + ((((0x1626u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0x1626u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A604 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1626u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_B1A607;
L_B1A607:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA607u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA607u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA607u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A607 CPY
    cpu.compareY(0x8u);
    goto L_B1A609;
L_B1A609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA609u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA609u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A609 BCS -> $B1A611
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A611; }
    goto L_B1A60B;
L_B1A60B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Bu, 4u + ((((0xA61Du & 0xFFu) + (cpu.y & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absy", 0xA61Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A60B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA61Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1A60E;
L_B1A60E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Eu, 4u, 3u, cpu.address("abs", 0x1DF9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A60E STA
    hw.write(cpu.address("abs", 0x1DF9u), cpu.a, cpu.m8?8:16);
    goto L_B1A611;
L_B1A611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA611u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA611u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA611u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A611 TYA
    cpu.transfer("TYA");
    goto L_B1A612;
L_B1A612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA612u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA612u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A612 CMP
    cpu.compareA(0x8u);
    goto L_B1A614;
L_B1A614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA614u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA614u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A614 BCC -> $B1A618
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_B1A618; }
    goto L_B1A616;
L_B1A616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA616u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA616u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1A616 LDA
    cpu.setA(0x8u, 8);
    goto L_B1A618;
L_B1A618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA618u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA618u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $B1A618 PLY
    cpu.pop("PLY", hw);
    goto L_B1A619;
L_B1A619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u, 8u, 4u, 0x02ACE1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $B1A619 JSL -> $02ACE1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA61Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA61Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x02ACE1u, 0xB1A619u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_B1A61D;
L_B1A61D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA61Du,0xB1A61Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1A61D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1A61Du);return;} hw.unresolvedReturn(0xB1A61Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_B1C9BF_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xB1C9BFu: goto L_B1C9BF;
    case 0xB1C9C1u: goto L_B1C9C1;
    case 0xB1C9C3u: goto L_B1C9C3;
    case 0xB1C9C4u: goto L_B1C9C4;
    case 0xB1C9C5u: goto L_B1C9C5;
    case 0xB1C9C8u: goto L_B1C9C8;
    case 0xB1C9CAu: goto L_B1C9CA;
    case 0xB1C9CBu: goto L_B1C9CB;
    case 0xB1C9CDu: goto L_B1C9CD;
    case 0xB1C9D0u: goto L_B1C9D0;
    case 0xB1C9D1u: goto L_B1C9D1;
    case 0xB1C9D3u: goto L_B1C9D3;
    case 0xB1C9D5u: goto L_B1C9D5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_B1C9BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9BFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9BFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1C9BF REP
    cpu.rep(0x20u);
    goto L_B1C9C1;
L_B1C9C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1C9C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_B1C9C3;
L_B1C9C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C3u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1C9C3 PHA
    cpu.push("PHA", hw);
    goto L_B1C9C4;
L_B1C9C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1C9C4 CLC
    cpu.setFlag('C', false);
    goto L_B1C9C5;
L_B1C9C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1C9C5 ADC
    cpu.adc(0x10u);
    goto L_B1C9C8;
L_B1C9C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1C9C8 STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_B1C9CA;
L_B1C9CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1C9CA SEC
    cpu.setFlag('C', true);
    goto L_B1C9CB;
L_B1C9CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CBu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1C9CB SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_B1C9CD;
L_B1C9CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1C9CD CMP
    cpu.compareA(0x100u);
    goto L_B1C9D0;
L_B1C9D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D0u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1C9D0 PLA
    cpu.pop("PLA", hw);
    goto L_B1C9D1;
L_B1C9D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1C9D1 STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_B1C9D3;
L_B1C9D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $B1C9D3 SEP
    cpu.sep(0x20u);
    goto L_B1C9D5;
L_B1C9D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $B1C9D5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xB1C9D5u);return;} hw.unresolvedReturn(0xB1C9D5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

