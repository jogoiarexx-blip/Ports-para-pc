@echo off
setlocal
cd /d "%~dp0"
set "FORJA65_CAPTURE_FRAMES=%~1"
if "%FORJA65_CAPTURE_FRAMES%"=="" set "FORJA65_CAPTURE_FRAMES=1,60,120"
if not "%~2"=="" set "FORJA65_INPUT_REPLAY=%~f2"
set "FORJA65_CAPTURE_DIR=%~dp0scene-timeline"
set FORJA65_CAPTURE_STOP=1
set FORJA65_HEADLESS=1
set FORJA65_UNCAPPED=1
set FORJA65_HEADLESS_FRAMES=20000
if exist game.exe goto run
if exist bin\game.exe (cd bin & goto run)
echo Execute BUILD-WINDOWS.cmd primeiro.
exit /b 1
:run
game.exe
exit /b %errorlevel%
