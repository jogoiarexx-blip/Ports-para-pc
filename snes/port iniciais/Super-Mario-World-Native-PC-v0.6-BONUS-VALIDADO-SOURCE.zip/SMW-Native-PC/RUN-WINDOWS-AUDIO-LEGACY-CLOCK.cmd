@echo off
setlocal
set FORJA65_DSP_CLOCK=legacy
call "%~dp0RUN-WINDOWS-AUDIO.cmd"
