# Super Mario World v0.5 / Forja65 v0.4.29

**Yoshi's Island 2 foi concluida.** O replay com SRAM novo aciona a fita no frame 4588, registra a saida normal no frame 5186 e retorna ao mapa no frame 5280. A captura de 5.000 frames mostra MARIO / COURSE CLEAR; a de 6.000 mostra Yoshi's Island 3 desbloqueada. Nenhuma morte foi registrada.

## Validacao

- Replay de 6.000 frames: PASS, sem falha de CPU e sem novos hints pendentes.
- Repeticao com objetos C++ sem otimizacao (O0): PASS; todos os campos de QA iguais ao build usado nas tentativas.
- Replay anterior de 2.400 frames: todos os campos de QA iguais aos da v0.4.
- Sete regressoes direcionadas do Forja: PASS, incluindo crescimento do cache, limite, reutilizacao de registros identicos, compatibilidade, mapeamento WRAM e retomada apos NMI/IRQ.
- Framebuffer final `104a7042af225120`; WRAM `212d0a9871b2e2c8`; 82723823 instrucoes, 5622 NMI e 3869 IRQ.

## Mudancas

O Forja v0.4.29 corrige a uniao incremental do CFG: tamanho maior nao prova que uma nova rotina contem todos os estados anteriores. A uniao agora conserva os estados antigos ausentes e a evidencia de chamadas/arestas/blocos, tambem quando a descoberta nova e menor. O teste novo falhava antes da correcao. Foram restaurados os estados perdidos durante as tentativas anteriores. A comparacao final contem 62001 estados da v0.4, 69825 estados atuais e **zero estados antigos ausentes**. O decoder de opcodes e o executor WRAM da v0.4.28 nao foram alterados.

O Mario recebe o CFG e os hints observados durante a fase e o retorno ao mapa. Sao 37746 enderecos decodificados, 186 hints, 110143 referencias e 69864 registros distintos. O limite deste projeto foi ampliado uma vez de 65.536 para 73.728, sem alterar o limite padrao do Forja e sem evictar cobertura antiga.

O replay fecha a mensagem da fase com A no frame 3.050. Depois do frame 4.600, solta todos os botoes para validar o encerramento e evitar a entrada involuntaria em outra fase. Nao modifica RAM nem usa saves de progresso.

## Reproduzir

Compile pelo BUILD-WINDOWS.cmd e execute RUN-TESTE-FASE-2.cmd (Python 3), ou use `python tools/verify_smw_island_2.py --exe caminho/do/game`. O teste usa uma pasta temporaria e preserva o SRAM do jogador. As entradas estao em `tests/smw-island-2-clear.input.txt` e as evidencias em `evidencias/SMW-v05-frame-*.png`. Resultados e registros estao em `reports/v05`.

## Limites

Build e replay validados com g++ C++20 no Linux. Nao foi compilado um game.exe de Windows nesta rodada; o pacote contem fontes e scripts de build. As suites gerais tinham falhas historicas (Forja v0.4: 185 PASS, 38 falhas, 2 timeouts; nativos: 17 PASS, 2 falhas, 1 ignorado). Elas nao foram declaradas verdes nem reexecutadas integralmente nesta rodada. PPU/APU virtuais e leituras de dados da ROM permanecem. Esta prova cobre uma rota e a primeira fase; nao certifica todo o jogo nem equivalencia completa com SNES.

Mario e Forja permanecem em pacotes separados. Objetos, PCH, saves de QA e executaveis Linux de teste nao acompanham os ZIPs.
