#!/usr/bin/env python3
"""Replay a fresh game in an isolated directory, preserving the player's SRAM."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


def main():
    project = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exe', type=Path, required=True)
    parser.add_argument('--frames', type=int, default=2400)
    parser.add_argument('--out', type=Path, default=project / 'reports' / 'qa-v04')
    args = parser.parse_args()
    exe = args.exe.resolve()
    if not exe.is_file() or not 1 <= args.frames <= 2400:
        parser.error('Provide a compiled executable and 1..2400 frames')
    output = args.out.resolve()
    if output == project or output in project.parents:
        parser.error('Output must be a dedicated diagnostics directory')
    output.mkdir(parents=True, exist_ok=True)
    replay = project / 'tests' / 'smw-new-game-to-island-2.input.txt'
    captures = ','.join(str(f) for f in (400, 900, 1600, 2000, 2200, 2400) if f <= args.frames)
    with tempfile.TemporaryDirectory(prefix='smw-fresh-') as temp:
        work = Path(temp)
        shutil.copytree(project / 'assets', work / 'assets')
        env = dict(os.environ)
        env.update(FORJA65_HEADLESS='1', FORJA65_EXECUTION='reference',
                   FORJA65_HEADLESS_FRAMES=str(args.frames),
                   FORJA65_WATCHDOG_INSTRUCTIONS='70000000', FORJA65_PPU_TRACE='0',
                   FORJA65_INPUT_REPLAY=str(replay), FORJA65_CAPTURE_FRAMES=captures,
                   FORJA65_CAPTURE_DIR=str(work / 'captures'))
        env.pop('FORJA65_CAPTURE_FRAME', None)
        env.pop('FORJA65_CAPTURE_STOP', None)
        run = subprocess.run([str(exe)], cwd=work, env=env, capture_output=True,
                             text=True, timeout=180)
        (output / 'run.log').write_text(run.stdout + run.stderr, encoding='utf-8')
        status = work / 'forja65-qa-status.txt'
        values = dict(line.split('=', 1) for line in status.read_text().splitlines()
                      if '=' in line) if status.exists() else {}
        passed = (run.returncode == 0 and values.get('runtime_started') == 'PASS'
                  and values.get('frames') == str(args.frames))
        result = {'exit': run.returncode, 'passed': passed, 'fresh_sram': True,
                  'frames_requested': args.frames, 'qa': values,
                  'limits': 'Replay/renderer evidence; not a full-game equivalence test.'}
        for name in ('forja65-qa-status.txt', 'forja65-last-error.txt',
                     'forja65-cpu-failure.txt', 'forja65-crash-trace.txt',
                     'forja65-runtime-hints.txt', 'forja65-oracle-hints.txt'):
            file = work / name
            if file.exists():
                shutil.copy2(file, output / name)
        if (work / 'captures').exists():
            shutil.copytree(work / 'captures', output / 'captures', dirs_exist_ok=True)
    (output / 'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(('PASS' if passed else 'FAIL') + ': ' + str(args.frames) + ' frames; ' + str(output))
    return 0 if passed else 2


if __name__ == '__main__':
    raise SystemExit(main())
