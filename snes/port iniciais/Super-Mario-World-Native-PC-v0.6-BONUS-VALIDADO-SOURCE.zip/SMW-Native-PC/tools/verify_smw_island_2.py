#!/usr/bin/env python3
"""Verify a fresh controller replay, the level exit, and the return to the map."""
import argparse
import csv
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


def main():
    project = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exe', type=Path, required=True)
    parser.add_argument('--out', type=Path, default=project / 'reports' / 'qa-island-2')
    args = parser.parse_args()
    exe, output = args.exe.resolve(), args.out.resolve()
    if not exe.is_file() or output == project or output in project.parents:
        parser.error('Provide a compiled executable and a dedicated output directory')
    output.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='smw-island-2-') as temp:
        work = Path(temp)
        shutil.copytree(project / 'assets', work / 'assets')
        env = dict(os.environ)
        env.update(FORJA65_HEADLESS='1', FORJA65_EXECUTION='reference',
                   FORJA65_HEADLESS_FRAMES='6000', FORJA65_WATCHDOG_INSTRUCTIONS='170000000',
                   FORJA65_INPUT_REPLAY=str(project / 'tests' / 'smw-island-2-clear.input.txt'),
                   FORJA65_CAPTURE_FRAMES='2400,3500,4500,5000,5500,6000',
                   FORJA65_CAPTURE_DIR=str(work / 'captures'),
                   FORJA65_WRAM_WRITE_CSV=str(work / 'state.csv'),
                   FORJA65_WRAM_WRITE_ADDRS='0100,0071,1493,0dd5,13ce',
                   FORJA65_WRAM_WRITE_START='2400', FORJA65_WRAM_WRITE_END='6000', FORJA65_WRAM_WRITE_MAX='20000',
                   FORJA65_SRAM_PATH=str(work / 'save.srm'))
        env.pop('FORJA65_CAPTURE_FRAME', None)
        env.pop('FORJA65_CAPTURE_STOP', None)
        run = subprocess.run([str(exe)], cwd=work, env=env,
                             capture_output=True, text=True, timeout=360)
        (output / 'run.log').write_text(run.stdout + run.stderr, encoding='utf-8')
        status = work / 'forja65-qa-status.txt'
        qa = dict(line.split('=', 1) for line in status.read_text().splitlines()
                  if '=' in line) if status.exists() else {}
        trace = work / 'state.csv'
        with trace.open() if trace.exists() else open(os.devnull) as file:
            rows = list(csv.DictReader(file))
        def events(address, value=None, after=0):
            return [int(r['frame']) for r in rows
                    if r['address'] == address and int(r['frame']) >= after
                    and (int(r['new']) == value if value is not None else int(r['new']) != 0)]
        goals = events('7E1493')
        goal = min(goals) if goals else None
        exits = events('7E0DD5', 1, goal or 6001)
        maps = events('7E0100', 14, goal or 6001)
        deaths = events('7E0071', 9)
        failure = (work / 'forja65-cpu-failure.txt').exists()
        passed = (run.returncode == 0 and qa.get('frames') == '6000'
                  and qa.get('runtime_started') == 'PASS' and not failure
                  and goal is not None and bool(exits) and bool(maps) and not deaths)
        result = {'passed': passed, 'exit': run.returncode, 'fresh_sram': True,
                  'goal_frame': goal, 'normal_exit_frames': sorted(set(exits)),
                  'map_frames': sorted(set(maps)), 'death_frames': sorted(set(deaths)),
                  'qa': qa, 'limits': 'One controller route; not full-game SNES equivalence.'}
        for file in work.glob('forja65-*.txt'):
            shutil.copy2(file, output / file.name)
        if trace.exists():
            shutil.copy2(trace, output / trace.name)
        if (work / 'captures').exists():
            shutil.copytree(work / 'captures', output / 'captures', dirs_exist_ok=True)
    (output / 'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(('PASS' if passed else 'FAIL') + ': Yoshi Island 2; ' + str(output))
    return 0 if passed else 2


if __name__ == '__main__':
    raise SystemExit(main())
