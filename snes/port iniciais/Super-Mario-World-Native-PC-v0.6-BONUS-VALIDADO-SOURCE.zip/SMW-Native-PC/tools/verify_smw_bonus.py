#!/usr/bin/env python3
"""Verify a fresh controller replay, the pipe bonus, a block throw, the level exit, and the map."""
import argparse
import csv
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


def main():
    project = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exe', type=Path, required=True)
    parser.add_argument('--out', type=Path, default=project / 'reports' / 'qa-island-2-bonus')
    args = parser.parse_args()
    exe, output = args.exe.resolve(), args.out.resolve()
    if not exe.is_file() or output == project or output in project.parents:
        parser.error('Provide a compiled executable and a dedicated output directory')
    output.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='smw-island-2-') as temp:
        work = Path(temp)
        shutil.copytree(project / 'assets', work / 'assets')
        env = dict(os.environ)
        env.update(FORJA65_HEADLESS='1', FORJA65_EXECUTION='reference',
                   FORJA65_HEADLESS_FRAMES='7000', FORJA65_WATCHDOG_INSTRUCTIONS='220000000',
                   FORJA65_INPUT_REPLAY=str(project / 'tests' / 'smw-island-2-bonus-clear.input.txt'),
                   FORJA65_CAPTURE_FRAMES='4220,4450,4560,4700,4900,5500,6200,7000',
                   FORJA65_CAPTURE_DIR=str(work / 'captures'),
                   FORJA65_WRAM_WRITE_CSV=str(work / 'state.csv'),
                   FORJA65_WRAM_WRITE_ADDRS='0100,0071,1493,0dd5,141a,00ce,1470',
                   FORJA65_WRAM_WRITE_START='2400', FORJA65_WRAM_WRITE_END='7000', FORJA65_WRAM_WRITE_MAX='60000',
                   FORJA65_SRAM_PATH=str(work / 'save.srm'))
        env.pop('FORJA65_CAPTURE_FRAME', None)
        env.pop('FORJA65_CAPTURE_STOP', None)
        run = subprocess.run([str(exe)], cwd=work, env=env,
                             capture_output=True, text=True, timeout=360)
        (output / 'run.log').write_text(run.stdout + run.stderr, encoding='utf-8')
        status = work / 'forja65-qa-status.txt'
        qa = dict(line.split('=', 1) for line in status.read_text().splitlines()
                  if '=' in line) if status.exists() else {}
        trace = work / 'state.csv'
        with trace.open() if trace.exists() else open(os.devnull) as file:
            rows = list(csv.DictReader(file))
        def events(address, value=None, after=0):
            return [int(r['frame']) for r in rows
                    if r['address'] == address and int(r['frame']) >= after
                    and (int(r['new']) == value if value is not None else int(r['new']) != 0)]
        def first(address, value=None, after=0):
            found = events(address, value, after)
            return min(found) if found else None
        entrance = first('7E0071', 6)
        bonus = first('7E00CE', 127, entrance if entrance is not None else 7001)
        carry = first('7E1470', 1, bonus if bonus is not None else 7001)
        throws = [int(r['frame']) for r in rows if r['address'] == '7E1470'
                  and int(r['old']) == 1 and int(r['new']) == 0
                  and int(r['joy1']) & 0x0800 and not int(r['joy1']) & 0x4000
                  and int(r['frame']) >= (carry if carry is not None else 7001)]
        thrown = min(throws) if throws else None
        pipe_exit = first('7E0071', 5, thrown if thrown is not None else 7001)
        returned = first('7E00CE', 50, pipe_exit if pipe_exit is not None else 7001)
        goal = first('7E1493', after=returned if returned is not None else 7001)
        exits = events('7E0DD5', 1, goal if goal is not None else 7001)
        maps = events('7E0100', 14, goal if goal is not None else 7001)
        deaths = events('7E0071', 9)
        failure = (work / 'forja65-cpu-failure.txt').exists()
        passed = (run.returncode == 0 and qa.get('frames') == '7000'
                  and qa.get('runtime_started') == 'PASS' and not failure
                  and all(v is not None for v in [entrance, bonus, carry, thrown, pipe_exit, returned, goal])
                  and bool(exits) and bool(maps) and not deaths)
        result = {'passed': passed, 'exit': run.returncode, 'fresh_sram': True,
                  'pipe_entrance_frame': entrance, 'bonus_room_frame': bonus,
                  'block_carried_frame': carry, 'block_thrown_up_frame': thrown,
                  'exit_pipe_frame': pipe_exit, 'main_level_return_frame': returned,
                  'goal_frame': goal, 'normal_exit_frames': sorted(set(exits)),
                  'map_frames': sorted(set(maps)), 'death_frames': sorted(set(deaths)),
                  'qa': qa, 'limits': 'One pipe route; flying-block rewards and full-game SNES equivalence are not asserted.'}
        for file in work.glob('forja65-*.txt'):
            shutil.copy2(file, output / file.name)
        if trace.exists():
            shutil.copy2(trace, output / trace.name)
        if (work / 'captures').exists():
            shutil.copytree(work / 'captures', output / 'captures', dirs_exist_ok=True)
    (output / 'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(('PASS' if passed else 'FAIL') + ': Yoshi Island 2 BONUS; ' + str(output))
    return 0 if passed else 2


if __name__ == '__main__':
    raise SystemExit(main())
