# Super Mario World Native PC v0.6 — percurso bônus validado

O caminho de Yoshi's Island 2 pelo cano azul até a sala dos blocos com asas foi validado com controle real, partida nova e SRAM isolada. Mario pegou um bloco azul, arremessou-o para cima, saiu pelo cano lateral, terminou a fase e retornou ao mapa com Yoshi's Island 3 desbloqueada.

## Evidência do replay de 7.000 frames

| Evento | Frame |
| --- | ---: |
| Descida pelo cano azul | 4221 |
| Subnível bônus carregado | 4285 |
| Bloco carregado | 4541 |
| Arremesso para cima | 4562 |
| Entrada no cano lateral de saída | 4671 |
| Retorno ao nível principal | 4759 |
| Meta atingida | 5132 |
| Saída normal registrada | 5730 |
| Retorno ao mapa | 5824 |

Sem mortes, sem alteração artificial da RAM e sem save anterior. Nenhuma nova falha de CPU ou hint pendente ao final. O executável com todos os objetos compilados em O0 repetiu os mesmos campos QA do executável de teste.

O percurso normal de 6.000 frames foi repetido e continua com todos os campos QA idênticos à versão v0.5. Meta no frame 4.588 e mapa no frame 5.280.

## Reproduzir no Windows

1. Compile com BUILD-WINDOWS.cmd.
2. Execute RUN-TESTE-BONUS.cmd (Python 3 necessário).
3. Para o percurso normal, execute RUN-TESTE-FASE-2.cmd.

O pacote contém os fontes, o replay `tests/smw-island-2-bonus-clear.input.txt`, o verificador `tools/verify_smw_bonus.py`, resultados em `reports/v06` e capturas em `evidencias`.

## Alteração e limites

Somente a cobertura gerada do projeto Mario foi ampliada a partir das falhas reproduzidas na entrada, objetos carregáveis e saída. O SDK Forja continua separado, na versão 0.4.29. Todos os 69,825 estados prévios foram preservados; agora há 70,670 estados. O teto do cache continua 73.728 registros.

Este teste comprova o percurso pela sala dos blocos com asas e a interação de pegar/arremessar um bloco. Não comprova o recebimento de moedas ou 1-Up dos blocos voadores. Permanecem limitações visuais do PPU e caminhos virtuais de PPU/APU; não é validação do jogo inteiro. Não foi compilado um EXE Windows nesta rodada.
