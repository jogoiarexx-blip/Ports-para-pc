@echo off
setlocal
cd /d "%~dp0"
if not exist "Super-Mario-World.exe" (echo ERRO: extraia todo o ZIP antes de jogar. & pause & exit /b 1)
if not exist "assets\cart-data.bin" (echo ERRO: pasta assets ausente. Extraia todo o ZIP. & pause & exit /b 1)
for /f "tokens=1 delims==" %%V in ('set FORJA65_ 2^>nul') do set "%%V="
set "FORJA65_AUDIO_MODE=native"
set "FORJA65_AUDIO_GAIN=100"
set "FORJA65_AUDIO_DUMP=0"
set "FORJA65_HEADLESS=0"
if not exist "rota\smw143_ate_gh.trace" (echo ERRO: rota gravada ausente. & pause & exit /b 1)
if not exist "replay-temporario" mkdir "replay-temporario"
set "FORJA65_SRAM_PATH=%~dp0replay-temporario\rota-%RANDOM%-%RANDOM%.srm"
set "FORJA65_INPUT_REPLAY=%~dp0rota\smw143_ate_gh.trace"
"Super-Mario-World.exe"
set "RESULTADO=%ERRORLEVEL%"
if not "%RESULTADO%"=="0" (
 echo.
 echo O jogo encerrou com erro %RESULTADO%.
 if exist "forja65-last-error.txt" type "forja65-last-error.txt"
 echo Guarde os arquivos forja65-*.txt desta pasta para diagnostico.
 pause
)
if exist "%FORJA65_SRAM_PATH%" del /q "%FORJA65_SRAM_PATH%"
exit /b %RESULTADO%
