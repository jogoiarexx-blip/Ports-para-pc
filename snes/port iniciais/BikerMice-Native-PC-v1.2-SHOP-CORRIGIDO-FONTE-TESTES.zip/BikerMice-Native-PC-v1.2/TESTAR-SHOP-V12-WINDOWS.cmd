@echo off
setlocal EnableExtensions
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (echo Node.js ausente. & exit /b 2)
node tools\audit-shop-table-v12.js
if errorlevel 1 exit /b 3
set "GAME=%CD%\bin\game.exe"
if not exist "%GAME%" set "GAME=%CD%\build-win\Release\game.exe"
if not exist "%GAME%" (echo Compile o game.exe antes de executar. & exit /b 4)
set "RESULT=%CD%\diagnosticos-shop-v12"
if not exist "%RESULT%\assets" mkdir "%RESULT%\assets"
copy /Y "%CD%\assets\cart-data.bin" "%RESULT%\assets\cart-data.bin" >nul
set "FORJA65_HEADLESS=1"
set "FORJA65_HEADLESS_FRAMES=6000"
set "FORJA65_UNCAPPED=1"
set "FORJA65_MODE7_PRECISE=0"
set "FORJA65_FRAME_HASHES=1"
set "FORJA65_FRAME_HASH_PATH=%RESULT%\forja65-frame-hashes.txt"
set "FORJA65_INPUT_REPLAY=%CD%\tests\biker-shop-item-v12.trace"
pushd "%RESULT%"
"%GAME%"
set "RC=%ERRORLEVEL%"
popd
if not "%RC%"=="0" (echo SHOP falhou. Verifique diagnosticos-shop-v12. & exit /b 5)
node tools\check-shop-qa-v12.js "%RESULT%\forja65-qa-status.txt"
if errorlevel 1 exit /b 6
node tools\verify-replay-series.js --baseline "evidence\shop-v12\shop-item-6000-hashes.txt" --current "%RESULT%\forja65-frame-hashes.txt" --through 6000
if errorlevel 1 exit /b 7
echo PASS: SHOP e interacao com item 6000 frames, sem crash, sem divergencias.
exit /b 0
