@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul || (echo ERRO: instale CMake e Visual Studio C++ & pause & exit /b 1)
cmake -S . -B build-win -G "Visual Studio 17 2022" -A x64 || goto :erro
cmake --build build-win --config Release --target cpu_bank_cross_smoke --parallel 2 || goto :erro
ctest --test-dir build-win -C Release -R ^cpu_bank_cross_smoke$ --output-on-failure || goto :erro
echo CPU_BANK_CROSS_PASS
pause
exit /b 0
:erro
echo CPU_BANK_CROSS_FAIL
pause
exit /b 1
