@echo off
setlocal
cd /d "%~dp0"
echo ============================================
echo BIKER MICE NATIVE PC - COMPILAR JOGO (x64)
echo ============================================
where cmake >nul 2>nul || (echo ERRO: instale CMake e Visual Studio 2022 C++ & pause & exit /b 1)
cmake -S . -B build-win -G "Visual Studio 17 2022" -A x64 || goto :err
cmake --build build-win --config Release --target game --parallel 2 || goto :err
if not exist bin mkdir bin
copy /Y build-win\Release\game.exe bin\game.exe >nul || goto :err
xcopy /E /I /Y assets bin\assets >nul || goto :err
echo.
echo OK: bin\game.exe compilado. Port experimental; largada e controles funcionam em replays ate 6800 frames.
echo Use RUN-WINDOWS.cmd; teste com TESTAR-CONTROLES-V09-WINDOWS.cmd.
pause
exit /b 0
:err
echo FALHA ao compilar/copiar game.exe.
pause
exit /b 1
