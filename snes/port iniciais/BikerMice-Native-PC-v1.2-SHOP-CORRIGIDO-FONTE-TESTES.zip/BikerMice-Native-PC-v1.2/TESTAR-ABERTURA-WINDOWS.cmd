@echo off
setlocal
cd /d "%~dp0"
set "EXE=bin\game.exe"
if not exist "%EXE%" set "EXE=build-win\Release\game.exe"
if not exist "%EXE%" set "EXE=build-win\game.exe"
if not exist "%EXE%" (
  echo game.exe nao encontrado. Execute GERAR-GAME-EXE-WINDOWS.cmd.
  exit /b 1
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 tools\verificar-abertura.py --game "%EXE%" --out "reports\biker-native-reference-qa.json"
) else (
  python tools\verificar-abertura.py --game "%EXE%" --out "reports\biker-native-reference-qa.json"
)
exit /b %errorlevel%
