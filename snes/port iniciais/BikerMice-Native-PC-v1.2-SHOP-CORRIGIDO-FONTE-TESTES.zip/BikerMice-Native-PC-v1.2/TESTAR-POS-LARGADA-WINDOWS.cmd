@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "GAME=bin\game.exe"
if not exist "%GAME%" set "GAME=build-win\Release\game.exe"
if not exist "%GAME%" (echo Compile primeiro com GERAR-GAME-EXE-WINDOWS.cmd.& exit /b 2)
set "FORJA65_HEADLESS=1"
set "FORJA65_UNCAPPED=1"
set "FORJA65_FRAME_HASHES=1"
set "FORJA65_HEADLESS_FRAMES=6200"
set "FORJA65_WATCHDOG_INSTRUCTIONS=180000000"
set "FORJA65_INPUT_REPLAY=%CD%\tests\biker-enter-track.trace"
set "FORJA65_CAPTURE_FRAMES=6040,6070,6100,6200"
set "FORJA65_CAPTURE_DIR=%CD%\capturas-pos-largada"
if not exist "diagnosticos-pos-largada\assets" mkdir "diagnosticos-pos-largada\assets"
copy /Y "assets\cart-data.bin" "diagnosticos-pos-largada\assets\cart-data.bin" >nul
if errorlevel 1 (echo Nao foi possivel preparar a ROM. & exit /b 2)
pushd "diagnosticos-pos-largada"
"%CD%\..\%GAME%"
set "RUNTIME_EXIT=%errorlevel%"
python "..\tools\validar-largada-v06.py" --frames "forja65-frame-hashes.txt" --qa "forja65-qa-status.txt" --baseline-status "..\reports\BIKER-V05-QA-6040.txt" --out "resultado-largada.json"
set "AUDIT_EXIT=%errorlevel%"
popd
if not "%RUNTIME_EXIT%"=="0" (
  echo O replay parou antes da meta. Consulte diagnosticos-pos-largada\forja65-runtime-hints.txt
  exit /b 3
)
if not "%AUDIT_EXIT%"=="0" exit /b 4
echo Replay de 6200 frames concluido. Teste visual e A/B dos controles ainda necessarios.
exit /b 0
