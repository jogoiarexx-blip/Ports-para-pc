@echo off
setlocal
cd /d "%~dp0"
set "EXE=bin\game.exe"
if not exist "%EXE%" set "EXE=build-win\Release\game.exe"
if not exist "%EXE%" set "EXE=build-win\game.exe"
if not exist "%EXE%" (
  echo game.exe nao encontrado. Execute GERAR-GAME-EXE-WINDOWS.cmd.
  exit /b 1
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 tools\verificar-abertura.py --game "%EXE%" --frames 2100 --trace tests/biker-modo-start.trace --out "reports\biker-native-reference-menu-2100.json"
) else (
  python tools\verificar-abertura.py --game "%EXE%" --frames 2100 --trace tests/biker-modo-start.trace --out "reports\biker-native-reference-menu-2100.json"
)
exit /b %errorlevel%
