#include "generated.hpp"
void sub_808791_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808790u: goto L_808790;
    case 0x808791u: goto L_808791;
    case 0x808793u: goto L_808793;
    case 0x808795u: goto L_808795;
    case 0x808797u: goto L_808797;
    case 0x808799u: goto L_808799;
    case 0x80879Bu: goto L_80879B;
    case 0x80879Fu: goto L_80879F;
    case 0x8087A0u: goto L_8087A0;
    case 0x8087A2u: goto L_8087A2;
    case 0x8087A6u: goto L_8087A6;
    case 0x8087A8u: goto L_8087A8;
    case 0x8087AAu: goto L_8087AA;
    case 0x8087ACu: goto L_8087AC;
    case 0x8087B0u: goto L_8087B0;
    case 0x8087B3u: goto L_8087B3;
    case 0x8087B7u: goto L_8087B7;
    case 0x8087B9u: goto L_8087B9;
    case 0x8087BFu: goto L_8087BF;
    case 0x8087C2u: goto L_8087C2;
    case 0x8087C4u: goto L_8087C4;
    case 0x8087C8u: goto L_8087C8;
    case 0x8087CCu: goto L_8087CC;
    case 0x8087CEu: goto L_8087CE;
    case 0x8087D1u: goto L_8087D1;
    case 0x8087D4u: goto L_8087D4;
    case 0x8087D8u: goto L_8087D8;
    case 0x8087DCu: goto L_8087DC;
    case 0x8087E0u: goto L_8087E0;
    case 0x8087E3u: goto L_8087E3;
    case 0x8087E6u: goto L_8087E6;
    case 0x8088DCu: goto L_8088DC;
    case 0x8088DFu: goto L_8088DF;
    case 0x8088E1u: goto L_8088E1;
    case 0x8088E3u: goto L_8088E3;
    case 0x8088E4u: goto L_8088E4;
    case 0x8088E5u: goto L_8088E5;
    case 0x8088E9u: goto L_8088E9;
    case 0x8088EDu: goto L_8088ED;
    case 0x8088EEu: goto L_8088EE;
    case 0x8088F0u: goto L_8088F0;
    case 0x8088F3u: goto L_8088F3;
    case 0x8088F5u: goto L_8088F5;
    case 0x8088F7u: goto L_8088F7;
    case 0x8088F9u: goto L_8088F9;
    case 0x8088FBu: goto L_8088FB;
    case 0x8088FDu: goto L_8088FD;
    case 0x80C341u: goto L_80C341;
    case 0x80C344u: goto L_80C344;
    case 0x80C348u: goto L_80C348;
    case 0x80C34Cu: goto L_80C34C;
    case 0x80C34Fu: goto L_80C34F;
    case 0x80C351u: goto L_80C351;
    case 0x80C354u: goto L_80C354;
    case 0x80C356u: goto L_80C356;
    case 0x80C357u: goto L_80C357;
    case 0x80C35Bu: goto L_80C35B;
    case 0x80C35Fu: goto L_80C35F;
    case 0x80C360u: goto L_80C360;
    case 0x80C361u: goto L_80C361;
    case 0x80C364u: goto L_80C364;
    case 0x80C366u: goto L_80C366;
    case 0x80C367u: goto L_80C367;
    case 0x80C36Bu: goto L_80C36B;
    case 0x80C36Du: goto L_80C36D;
    case 0x80C36Eu: goto L_80C36E;
    case 0x80C371u: goto L_80C371;
    case 0x80C375u: goto L_80C375;
    case 0x80C376u: goto L_80C376;
    case 0x80C377u: goto L_80C377;
    case 0x80C37Bu: goto L_80C37B;
    case 0x80C37Fu: goto L_80C37F;
    case 0x80D515u: goto L_80D515;
    case 0x80D517u: goto L_80D517;
    case 0x80D519u: goto L_80D519;
    case 0x80D51Au: goto L_80D51A;
    case 0x80D51Cu: goto L_80D51C;
    case 0x80D51Fu: goto L_80D51F;
    case 0x80D521u: goto L_80D521;
    case 0x80D524u: goto L_80D524;
    case 0x80D527u: goto L_80D527;
    case 0x80D529u: goto L_80D529;
    case 0x80D52Au: goto L_80D52A;
    case 0x80D52Bu: goto L_80D52B;
    case 0x80D52Cu: goto L_80D52C;
    case 0x80D52Du: goto L_80D52D;
    case 0x80D52Fu: goto L_80D52F;
    case 0x80D531u: goto L_80D531;
    case 0x80D534u: goto L_80D534;
    case 0x80D536u: goto L_80D536;
    case 0x80D537u: goto L_80D537;
    case 0x80D53Au: goto L_80D53A;
    case 0x80D53Bu: goto L_80D53B;
    case 0x80D53Cu: goto L_80D53C;
    case 0x80D53Eu: goto L_80D53E;
    case 0x80D541u: goto L_80D541;
    case 0x80D543u: goto L_80D543;
    case 0x80D545u: goto L_80D545;
    case 0x80D548u: goto L_80D548;
    case 0x80D54Au: goto L_80D54A;
    case 0x80D54Bu: goto L_80D54B;
    case 0x80D54Du: goto L_80D54D;
    case 0x80D54Eu: goto L_80D54E;
    case 0x80D550u: goto L_80D550;
    case 0x80D553u: goto L_80D553;
    case 0x80D555u: goto L_80D555;
    case 0x80D558u: goto L_80D558;
    case 0x80D55Au: goto L_80D55A;
    case 0x80D55Bu: goto L_80D55B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8790u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8790u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808790 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808790u);return;} hw.unresolvedReturn(0x808790u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_808791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8791u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8791u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808791 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x3Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808793;
L_808793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8793u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8793u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808793 BNE -> $80879F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80879F; }
    goto L_808795;
L_808795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8795u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8795u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808795 STZ
    hw.write(cpu.address("dp", 0x80u), 0, cpu.m8?8:16);
    goto L_808797;
L_808797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x66u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808797 STZ
    hw.write(cpu.address("dp", 0x66u), 0, cpu.m8?8:16);
    goto L_808799;
L_808799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8799u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8799u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808799 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_80879B;
L_80879B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Bu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Bu, 4u, 4u, 0x80C341u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80879B JML -> $80C341
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_80C341;
L_80879F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80879F DEX
    cpu.decReg('X');
    goto L_8087A0;
L_8087A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A0 BNE -> $8087BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8087BF; }
    goto L_8087A2;
L_8087A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u, 8u, 4u, 0x80BB55u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8087A2 JSL -> $80BB55 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87A5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87A6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80BB55u, 0x8087A2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8087A6;
L_8087A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87A6u,0x8087A6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087A8;
L_8087A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A8 BEQ -> $808790
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808790; }
    goto L_8087AA;
L_8087AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087AA STZ
    hw.write(cpu.address("dp", 0xEAu), 0, cpu.m8?8:16);
    goto L_8087AC;
L_8087AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ACu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ACu, 8u, 4u, 0x808A92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8087AC JSL -> $808A92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87B0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808A92u, 0x8087ACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8087B0;
L_8087B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87B0u,0x8087B0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087B0 LDY
    cpu.setY(0x8E3Eu, 16);
    goto L_8087B3;
L_8087B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B3u, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8087B3 JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87B6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87B7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x8087B3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8087B7;
L_8087B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87B7u,0x8087B7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087B7 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_8087B9;
L_8087B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8087B9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8087B9u);return;} hw.unresolvedReturn(0x8087B9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8087BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BFu, 5u, 3u, cpu.address("abs", 0x1F50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087BF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1F50u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087C2;
L_8087C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087C2 BNE -> $808790
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_808790; }
    goto L_8087C4;
L_8087C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C4u, 8u, 4u, 0x80DC8Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8087C4 JSL -> $80DC8F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87C7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87C8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80DC8Fu, 0x8087C4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8087C8;
L_8087C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87C8u,0x8087C8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u, 8u, 4u, 0x808ADCu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8087C8 JSL -> $808ADC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87CBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87CCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADCu, 0x8087C8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8087CC;
L_8087CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87CCu,0x8087CCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CCu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087CC STZ
    hw.write(cpu.address("dp", 0x5Cu), 0, cpu.m8?8:16);
    goto L_8087CE;
L_8087CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087CE LDA
    cpu.setA(0x3u, 16);
    goto L_8087D1;
L_8087D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D1u, 5u, 3u, cpu.address("abs", 0x1FA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087D1 STA
    hw.write(cpu.address("abs", 0x1FA6u), cpu.a, cpu.m8?8:16);
    goto L_8087D4;
L_8087D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D4u, 8u, 4u, 0x80890Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8087D4 JSL -> $80890B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87D7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87D8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80890Bu, 0x8087D4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8087D8;
L_8087D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87D8u,0x8087D8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u, 8u, 4u, 0x80D592u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8087D8 JSL -> $80D592 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87DBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87DCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D592u, 0x8087D8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8087DC;
L_8087DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87DCu,0x8087DCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu, 8u, 4u, 0x808877u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8087DC JSL -> $808877 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87DFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87E0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808877u, 0x8087DCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8087E0;
L_8087E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87E0u,0x8087E0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E0u, 6u, 3u, cpu.address("abs", 0x88FEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087E0 JSR -> $8088FE stack real
    { cpu.push16Value(hw,0x87E2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87E3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x88FEu), 0x8087E0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8087E3;
L_8087E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87E3u,0x8087E3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087E3 LDA
    cpu.setA(0x1u, 16);
    goto L_8087E6;
L_8087E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E6u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E6u, 3u, 3u, cpu.address("abs", 0x88E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087E6 JMP -> $8088E4
    goto L_8088E4;
L_8088DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088DC LDA
    cpu.setA(0x0u, 16);
    goto L_8088DF;
L_8088DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088DF STA
    hw.write(cpu.address("dp", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_8088E1;
L_8088E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088E1 STA
    hw.write(cpu.address("dp", 0x3Cu), cpu.a, cpu.m8?8:16);
    goto L_8088E3;
L_8088E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8088E3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8088E3u);return;} hw.unresolvedReturn(0x8088E3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8088E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E4u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088E4 PHA
    cpu.push("PHA", hw);
    goto L_8088E5;
L_8088E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E5u, 8u, 4u, 0x809979u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8088E5 JSL -> $809979 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x88E8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88E9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809979u, 0x8088E5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8088E9;
L_8088E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88E9u,0x8088E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E9u, 8u, 4u, 0x808C65u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8088E9 JSL -> $808C65 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x88ECu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x88EDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C65u, 0x8088E9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8088ED;
L_8088ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88EDu,0x8088EDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EDu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EDu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088ED PLA
    cpu.pop("PLA", hw);
    goto L_8088EE;
L_8088EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088EE STA
    hw.write(cpu.address("dp", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_8088F0;
L_8088F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F0 LDX
    cpu.setX(0x50u, 16);
    goto L_8088F3;
L_8088F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F3 STX
    hw.write(cpu.address("dp", 0x74u), cpu.x, cpu.x8?8:16);
    goto L_8088F5;
L_8088F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F5 BNE -> $8088DC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8088DC; }
    goto L_8088F7;
L_8088F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088F9;
L_8088F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F9 BEQ -> $8088FD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8088FD; }
    goto L_8088FB;
L_8088FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088FB DEC
    cpu.decMem(hw, cpu.address("dp", 0x74u), cpu.m8?8:16);
    goto L_8088FD;
L_8088FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8088FD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8088FDu);return;} hw.unresolvedReturn(0x8088FDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C341:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC341u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC341u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC341u, 5u, 3u, cpu.address("abs", 0x1FF0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C341 STZ
    hw.write(cpu.address("abs", 0x1FF0u), 0, cpu.m8?8:16);
    goto L_80C344;
L_80C344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC344u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC344u, 8u, 4u, 0x80DAA5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C344 JSL -> $80DAA5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC347u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC348u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80DAA5u, 0x80C344u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C348;
L_80C348:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC348u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC348u,0x80C348u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC348u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC348u, 8u, 4u, 0x80890Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C348 JSL -> $80890B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC34Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC34Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80890Bu, 0x80C348u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C34C;
L_80C34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC34Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC34Cu,0x80C34Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C34C LDA
    cpu.setA(0x7C0u, 16);
    goto L_80C34F;
L_80C34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC34Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C34F STA
    hw.write(cpu.address("dp", 0x74u), cpu.a, cpu.m8?8:16);
    goto L_80C351;
L_80C351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC351u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC351u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C351 LDA
    cpu.setA(0x1u, 16);
    goto L_80C354;
L_80C354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC354u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC354u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C354 STA
    hw.write(cpu.address("dp", 0x4Cu), cpu.a, cpu.m8?8:16);
    goto L_80C356;
L_80C356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC356u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC356u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C356 DEC
    cpu.decReg('A');
    goto L_80C357;
L_80C357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC357u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC357u, 6u, 4u, 0x7EFE00u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C357 STA
    hw.write(0x7EFE00u, cpu.a, cpu.m8?8:16);
    goto L_80C35B;
L_80C35B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC35Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC35Bu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC35Bu, 6u, 4u, 0x7EFE48u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C35B LDA
    cpu.loadA(hw.readW(0x7EFE48u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C35F;
L_80C35F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC35Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC35Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC35Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C35F TAY
    cpu.transfer("TAY");
    goto L_80C360;
L_80C360:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC360u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC360u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC360u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C360 INC
    cpu.inc('A');
    goto L_80C361;
L_80C361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC361u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC361u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C361 CMP
    cpu.compareA(0xCu);
    goto L_80C364;
L_80C364:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC364u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC364u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC364u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C364 BCC -> $80C367
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C367; }
    goto L_80C366;
L_80C366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC366u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC366u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C366 TDC
    cpu.tdc();
    goto L_80C367;
L_80C367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC367u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC367u, 6u, 4u, 0x7EFE48u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C367 STA
    hw.write(0x7EFE48u, cpu.a, cpu.m8?8:16);
    goto L_80C36B;
L_80C36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC36Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC36Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C36B STA
    hw.write(cpu.address("dp", 0xD2u), cpu.a, cpu.m8?8:16);
    goto L_80C36D;
L_80C36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC36Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC36Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C36D TYA
    cpu.transfer("TYA");
    goto L_80C36E;
L_80C36E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC36Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC36Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC36Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C36E LDY
    cpu.setY(0x6u, 16);
    goto L_80C371;
L_80C371:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC371u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC371u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC371u, 8u, 4u, 0x808D53u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C371 JSL -> $808D53 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC374u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC375u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D53u, 0x80C371u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C375;
L_80C375:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC375u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC375u,0x80C375u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC375u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC375u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C375 TYA
    cpu.transfer("TYA");
    goto L_80C376;
L_80C376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC376u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC376u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C376 ASL
    cpu.aslA();
    goto L_80C377;
L_80C377:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC377u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC377u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC377u, 6u, 4u, 0x7EFE02u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C377 STA
    hw.write(0x7EFE02u, cpu.a, cpu.m8?8:16);
    goto L_80C37B;
L_80C37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC37Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC37Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC37Bu, 8u, 4u, 0x809224u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C37B JSL -> $809224 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC37Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC37Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809224u, 0x80C37Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C37F;
L_80C37F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC37Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC37Fu,0x80C37Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC37Fu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC37Fu, 4u, 4u, 0x80D515u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C37F JML -> $80D515
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_80D515;
L_80D515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD515u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD515u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD515u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D515 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xD2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D517;
L_80D517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD517u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD517u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D517 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D519;
L_80D519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD519u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD519u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D519 DEC
    cpu.decReg('A');
    goto L_80D51A;
L_80D51A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD51Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D51A BNE -> $80D521
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D521; }
    goto L_80D51C;
L_80D51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD51Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Cu, 5u + 1u, 3u, cpu.address("absy", 0xA67Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D51C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA67Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D51F;
L_80D51F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD51Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D51F BRA -> $80D524
    goto L_80D524;
L_80D521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD521u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD521u, 5u + 1u, 3u, cpu.address("absy", 0xA63Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D521 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA63Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D524;
L_80D524:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD524u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD524u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD524u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D524 AND
    cpu.logicAnd(0xFFu);
    goto L_80D527;
L_80D527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD527u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD527u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD527u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D527 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D529;
L_80D529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD529u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD529u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D529 LSR
    cpu.lsrA();
    goto L_80D52A;
L_80D52A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D52A LSR
    cpu.lsrA();
    goto L_80D52B;
L_80D52B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D52B LSR
    cpu.lsrA();
    goto L_80D52C;
L_80D52C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D52C LSR
    cpu.lsrA();
    goto L_80D52D;
L_80D52D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D52D STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80D52F;
L_80D52F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD52Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD52Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D52F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D531;
L_80D531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD531u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD531u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD531u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D531 AND
    cpu.logicAnd(0xFu);
    goto L_80D534;
L_80D534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD534u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD534u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD534u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D534 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D536;
L_80D536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD536u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD536u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80D536 PHB
    cpu.push("PHB", hw);
    goto L_80D537;
L_80D537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD537u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD537u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD537u, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D537 PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80D53A;
L_80D53A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD53Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80D53A PLB
    cpu.pop("PLB", hw);
    goto L_80D53B;
L_80D53B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD53Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80D53B PLB
    cpu.pop("PLB", hw);
    goto L_80D53C;
L_80D53C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD53Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D53C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D53E;
L_80D53E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD53Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD53Eu, 5u, 3u, cpu.address("abs", 0xFE16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D53E STA
    hw.write(cpu.address("abs", 0xFE16u), cpu.a, cpu.m8?8:16);
    goto L_80D541;
L_80D541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD541u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD541u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D541 STA
    hw.write(cpu.address("dp", 0xA2u), cpu.a, cpu.m8?8:16);
    goto L_80D543;
L_80D543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD543u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD543u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD543u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D543 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D545;
L_80D545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD545u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD545u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD545u, 5u, 3u, cpu.address("abs", 0xFE14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D545 STA
    hw.write(cpu.address("abs", 0xFE14u), cpu.a, cpu.m8?8:16);
    goto L_80D548;
L_80D548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD548u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD548u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D548 STA
    hw.write(cpu.address("dp", 0xA4u), cpu.a, cpu.m8?8:16);
    goto L_80D54A;
L_80D54A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD54Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D54A ASL
    cpu.aslA();
    goto L_80D54B;
L_80D54B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD54Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D54B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D54D;
L_80D54D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD54Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D54D ASL
    cpu.aslA();
    goto L_80D54E;
L_80D54E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD54Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Eu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D54E ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80D550;
L_80D550:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD550u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD550u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD550u, 5u, 3u, cpu.address("abs", 0xFE16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D550 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0xFE16u), cpu.m8?8:16));
    goto L_80D553;
L_80D553:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD553u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD553u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD553u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D553 STA
    hw.write(cpu.address("dp", 0xA0u), cpu.a, cpu.m8?8:16);
    goto L_80D555;
L_80D555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD555u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD555u, 5u, 3u, cpu.address("abs", 0xFE00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D555 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0xFE00u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D558;
L_80D558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD558u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD558u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D558 STA
    hw.write(cpu.address("dp", 0x90u), cpu.a, cpu.m8?8:16);
    goto L_80D55A;
L_80D55A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD55Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD55Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD55Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80D55A PLB
    cpu.pop("PLB", hw);
    goto L_80D55B;
L_80D55B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD55Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD55Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD55Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D55B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80D55Bu);return;} hw.unresolvedReturn(0x80D55Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809605_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809605u: goto L_809605;
    case 0x809607u: goto L_809607;
    case 0x80960Au: goto L_80960A;
    case 0x80960Eu: goto L_80960E;
    case 0x809610u: goto L_809610;
    case 0x809613u: goto L_809613;
    case 0x809615u: goto L_809615;
    case 0x809617u: goto L_809617;
    case 0x809619u: goto L_809619;
    case 0x80961Bu: goto L_80961B;
    case 0x80961Du: goto L_80961D;
    case 0x809620u: goto L_809620;
    case 0x809622u: goto L_809622;
    case 0x809623u: goto L_809623;
    case 0x809626u: goto L_809626;
    case 0x809629u: goto L_809629;
    case 0x80962Bu: goto L_80962B;
    case 0x80962Cu: goto L_80962C;
    case 0x80962Du: goto L_80962D;
    case 0x80962Eu: goto L_80962E;
    case 0x80962Fu: goto L_80962F;
    case 0x809631u: goto L_809631;
    case 0x809633u: goto L_809633;
    case 0x809635u: goto L_809635;
    case 0x809637u: goto L_809637;
    case 0x809639u: goto L_809639;
    case 0x80963Bu: goto L_80963B;
    case 0x80963Cu: goto L_80963C;
    case 0x80963Eu: goto L_80963E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809605:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9605u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9605u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9605u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809605 REP
    cpu.rep(0x30u);
    goto L_809607;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9605u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9605u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809605 REP
    cpu.rep(0x30u);
    goto L_809607;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9605u,0x809605u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809607:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9607u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9607u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9607u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809607 LDA
    cpu.setA(0x400u, 16);
    goto L_80960A;
L_80960A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x960Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x960Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x960Au, 8u, 4u, 0x80AF34u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80960A JSL -> $80AF34 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x960Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x960Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AF34u, 0x80960Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80960E;
L_80960E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x960Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x960Eu,0x80960Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x960Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x960Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80960E STZ
    hw.write(cpu.address("dp", 0x15u), 0, cpu.m8?8:16);
    goto L_809610;
L_809610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9610u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9610u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809610 LDX
    cpu.setX(0x0u, 16);
    goto L_809613;
L_809613:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9613u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9613u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9613u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809613 SEP
    cpu.sep(0x20u);
    goto L_809615;
L_809615:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9615u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9615u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9615u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809615 LDA
    cpu.setA(0x7Eu, 8);
    goto L_809617;
L_809617:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9617u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9617u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9617u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809617 STA
    hw.write(cpu.address("dp", 0x17u), cpu.a, cpu.m8?8:16);
    goto L_809619;
L_809619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9619u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9619u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809619 REP
    cpu.rep(0x20u);
    goto L_80961B;
L_80961B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x961Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x961Bu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x961Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x15u) & 0xFFFFu), 3u, 0u);
    // $80961B LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80961D;
L_80961D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x961Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x961Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x961Du, 5u, 3u, cpu.address("abs", 0x2142u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80961D STA
    hw.write(cpu.address("abs", 0x2142u), cpu.a, cpu.m8?8:16);
    goto L_809620;
L_809620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9620u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9620u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809620 SEP
    cpu.sep(0x20u);
    goto L_809622;
L_809622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9622u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9622u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809622 TXA
    cpu.transfer("TXA");
    goto L_809623;
L_809623:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9623u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9623u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9623u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809623 STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_809626;
L_809626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9626u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9626u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9626u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809626 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2141u), cpu.m8?8:16));
    goto L_809629;
L_809629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9629u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9629u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809629 BNE -> $809623
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809623; }
    goto L_80962B;
L_80962B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x962Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x962Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x962Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80962B INX
    cpu.inc('X');
    goto L_80962C;
L_80962C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x962Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x962Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x962Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80962C INX
    cpu.inc('X');
    goto L_80962D;
L_80962D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x962Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x962Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x962Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80962D INY
    cpu.inc('Y');
    goto L_80962E;
L_80962E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x962Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x962Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x962Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80962E INY
    cpu.inc('Y');
    goto L_80962F;
L_80962F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x962Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x962Fu,cpu,0xC4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x962Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80962F CPY
    cpu.compareY(hw.readW(cpu.address("dp", 0x20u), cpu.x8?8:16));
    goto L_809631;
L_809631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9631u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9631u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9631u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809631 BNE -> $809619
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809619; }
    goto L_809633;
L_809633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9633u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9633u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809633 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x13u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809635;
L_809635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9635u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9635u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9635u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809635 STY
    hw.write(cpu.address("dp", 0x18u), cpu.y, cpu.x8?8:16);
    goto L_809637;
L_809637:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9637u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9637u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9637u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809637 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809639;
L_809639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9639u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9639u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809639 BPL -> $809605
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809605; }
    goto L_80963B;
L_80963B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x963Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x963Bu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x963Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80963B TXY
    cpu.transfer("TXY");
    goto L_80963C;
L_80963C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x963Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x963Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x963Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80963C REP
    cpu.rep(0x20u);
    goto L_80963E;
L_80963E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x963Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x963Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x963Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80963E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80963Eu);return;} hw.unresolvedReturn(0x80963Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8098DC_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8098DCu: goto L_8098DC;
    case 0x8098DEu: goto L_8098DE;
    case 0x8098E2u: goto L_8098E2;
    case 0x8098E3u: goto L_8098E3;
    case 0x8098E4u: goto L_8098E4;
    case 0x8098E6u: goto L_8098E6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8098DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98DCu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098DC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x52u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8098DE;
L_8098DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98DEu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98DEu, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098DE STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8098E2;
L_8098E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098E2 INX
    cpu.inc('X');
    goto L_8098E3;
L_8098E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098E3 INX
    cpu.inc('X');
    goto L_8098E4;
L_8098E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E4u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098E4 STX
    hw.write(cpu.address("dp", 0x52u), cpu.x, cpu.x8?8:16);
    goto L_8098E6;
L_8098E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E6u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8098E6 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8098E6u);return;} hw.unresolvedReturn(0x8098E6u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80997E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80997Eu: goto L_80997E;
    case 0x809980u: goto L_809980;
    case 0x809983u: goto L_809983;
    case 0x809985u: goto L_809985;
    case 0x809988u: goto L_809988;
    case 0x80998Au: goto L_80998A;
    case 0x80998Cu: goto L_80998C;
    case 0x80998Du: goto L_80998D;
    case 0x80998Fu: goto L_80998F;
    case 0x809990u: goto L_809990;
    case 0x809991u: goto L_809991;
    case 0x809992u: goto L_809992;
    case 0x809993u: goto L_809993;
    case 0x809994u: goto L_809994;
    case 0x809997u: goto L_809997;
    case 0x809999u: goto L_809999;
    case 0x80999Cu: goto L_80999C;
    case 0x80999Eu: goto L_80999E;
    case 0x8099A1u: goto L_8099A1;
    case 0x8099A3u: goto L_8099A3;
    case 0x8099A6u: goto L_8099A6;
    case 0x8099A8u: goto L_8099A8;
    case 0x8099ABu: goto L_8099AB;
    case 0x8099ADu: goto L_8099AD;
    case 0x8099B0u: goto L_8099B0;
    case 0x8099B2u: goto L_8099B2;
    case 0x8099B4u: goto L_8099B4;
    case 0x8099B5u: goto L_8099B5;
    case 0x8099B6u: goto L_8099B6;
    case 0x8099B9u: goto L_8099B9;
    case 0x8099BAu: goto L_8099BA;
    case 0x8099BCu: goto L_8099BC;
    case 0x8099BEu: goto L_8099BE;
    case 0x8099BFu: goto L_8099BF;
    case 0x8099C1u: goto L_8099C1;
    case 0x8099C4u: goto L_8099C4;
    case 0x8099C6u: goto L_8099C6;
    case 0x8099C9u: goto L_8099C9;
    case 0x8099CCu: goto L_8099CC;
    case 0x8099CEu: goto L_8099CE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80997E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x997Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x997Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x997Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80997E SEP
    cpu.sep(0x20u);
    goto L_809980;
L_809980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9980u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9980u, 4u, 3u, cpu.address("abs", 0x1FF2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809980 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FF2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809983;
L_809983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9983u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9983u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9983u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809983 BEQ -> $8099C9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8099C9; }
    goto L_809985;
L_809985:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9985u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9985u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9985u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809985 LDX
    cpu.setX(0x4370u, 16);
    goto L_809988;
L_809988:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9988u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9988u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9988u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809988 LDA
    cpu.setA(0x7u, 8);
    goto L_80998A;
L_80998A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x998Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x998Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x998Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80998A STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80998C;
L_80998C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x998Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x998Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x998Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80998C XBA
    cpu.xba();
    goto L_80998D;
L_80998D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x998Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x998Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x998Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80998D LDA
    cpu.setA(0x0u, 8);
    goto L_80998F;
L_80998F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x998Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x998Fu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x998Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80998F XBA
    cpu.xba();
    goto L_809990;
L_809990:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9990u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9990u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9990u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809990 ASL
    cpu.aslA();
    goto L_809991;
L_809991:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9991u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9991u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9991u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809991 ASL
    cpu.aslA();
    goto L_809992;
L_809992:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9992u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9992u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9992u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809992 ASL
    cpu.aslA();
    goto L_809993;
L_809993:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9993u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9993u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9993u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809993 TAY
    cpu.transfer("TAY");
    goto L_809994;
L_809994:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9994u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9994u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9994u, 4u + 1u, 3u, cpu.address("absy", 0x0500u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809994 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x500u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809997;
L_809997:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9997u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9997u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9997u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809997 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_809999;
L_809999:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9999u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9999u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9999u, 4u + 1u, 3u, cpu.address("absy", 0x0501u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809999 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x501u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80999C;
L_80999C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x999Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x999Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x999Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x01u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80999C STA
    hw.write(cpu.address("dpx", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_80999E;
L_80999E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x999Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x999Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x999Eu, 4u + 1u, 3u, cpu.address("absy", 0x0502u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80999E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x502u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8099A1;
L_8099A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A1u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099A1 STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8099A3;
L_8099A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A3u, 4u + 1u, 3u, cpu.address("absy", 0x0503u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099A3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x503u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8099A6;
L_8099A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A6u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099A6 STA
    hw.write(cpu.address("dpx", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8099A8;
L_8099A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A8u, 4u + 1u, 3u, cpu.address("absy", 0x0504u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099A8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x504u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8099AB;
L_8099AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99ABu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099AB STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_8099AD;
L_8099AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99ADu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99ADu, 4u + 1u, 3u, cpu.address("absy", 0x0507u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099AD LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x507u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8099B0;
L_8099B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99B0u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099B0 STA
    hw.write(cpu.address("dpx", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_8099B2;
L_8099B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99B2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99B2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099B2 REP
    cpu.rep(0x20u);
    goto L_8099B4;
L_8099B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99B4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99B4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099B4 TXA
    cpu.transfer("TXA");
    goto L_8099B5;
L_8099B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99B5u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099B5 SEC
    cpu.setFlag('C', true);
    goto L_8099B6;
L_8099B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99B6u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099B6 SBC
    cpu.sbc(0x10u);
    goto L_8099B9;
L_8099B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99B9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099B9 TAX
    cpu.transfer("TAX");
    goto L_8099BA;
L_8099BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99BAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99BAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099BA SEP
    cpu.sep(0x20u);
    goto L_8099BC;
L_8099BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99BCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99BCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099BC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8099BE;
L_8099BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99BEu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099BE DEC
    cpu.decReg('A');
    goto L_8099BF;
L_8099BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99BFu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099BF BMI -> $8099C6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8099C6; }
    goto L_8099C1;
L_8099C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99C1u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99C1u, 4u, 3u, cpu.address("abs", 0x1FF6u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099C1 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1FF6u), cpu.m8?8:16));
    goto L_8099C4;
L_8099C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99C4u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099C4 BCS -> $80998A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80998A; }
    goto L_8099C6;
L_8099C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99C6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99C6u, 4u, 3u, cpu.address("abs", 0x1FF2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099C6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FF2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8099C9;
L_8099C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99C9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99C9u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099C9 STA
    hw.write(cpu.address("abs", 0x420Cu), cpu.a, cpu.m8?8:16);
    goto L_8099CC;
L_8099CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99CCu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99CCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8099CC REP
    cpu.rep(0x20u);
    goto L_8099CE;
L_8099CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99CEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8099CE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8099CEu);return;} hw.unresolvedReturn(0x8099CEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809DD5_E0M0X0C0_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E72u: goto L_809E72;
    case 0x809E73u: goto L_809E73;
    case 0x809E76u: goto L_809E76;
    case 0x809E79u: goto L_809E79;
    case 0x809E7Bu: goto L_809E7B;
    case 0x809E7Eu: goto L_809E7E;
    case 0x809E80u: goto L_809E80;
    case 0x809E81u: goto L_809E81;
    case 0x809E83u: goto L_809E83;
    case 0x809E84u: goto L_809E84;
    case 0x809E87u: goto L_809E87;
    case 0x809E8Au: goto L_809E8A;
    case 0x809E8Cu: goto L_809E8C;
    case 0x809E8Fu: goto L_809E8F;
    case 0x809E91u: goto L_809E91;
    case 0x809E93u: goto L_809E93;
    case 0x809E94u: goto L_809E94;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E72u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E72u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E72u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E72 CLC
    cpu.setFlag('C', false);
    goto L_809E73;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E72u,0x809E72u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E73u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E73u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E73u, 5u + 1u, 3u, cpu.address("absy", 0x3000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E73 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x3000u), cpu.m8?8:16));
    goto L_809E76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E73u,0x809E73u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E76u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E76u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E76 CMP
    cpu.compareA(0xF0u);
    goto L_809E79;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E76u,0x809E76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E79u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E79u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E79 BCC -> $809E80
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809E80; }
    goto L_809E7B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E79u,0x809E79u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Bu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E7B CMP
    cpu.compareA(0xFFE8u);
    goto L_809E7E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E7Bu,0x809E7Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Eu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E7E BCC -> $809ED9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809ED9u,0x809E7Eu); return; }
    goto L_809E80;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E7Eu,0x809E7Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E80u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E80u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E80u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E80 TAX
    cpu.transfer("TAX");
    goto L_809E81;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E80u,0x809E80u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E81u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E81u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E81u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E81 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E83;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E81u,0x809E81u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E83u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E83u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E83u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E83 CLC
    cpu.setFlag('C', false);
    goto L_809E84;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E83u,0x809E83u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E84u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E84u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E84u, 5u + 1u, 3u, cpu.address("absy", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E84 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x1800u), cpu.m8?8:16));
    goto L_809E87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E84u,0x809E84u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E87u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E87u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E87u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E87 CMP
    cpu.compareA(0x100u);
    goto L_809E8A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E87u,0x809E87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Au))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E8A BCC -> $809E91
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809E91; }
    goto L_809E8C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E8Au,0x809E8Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Cu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E8C CMP
    cpu.compareA(0xFFF0u);
    goto L_809E8F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E8Cu,0x809E8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Fu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E8F BCC -> $809ED9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809ED9u,0x809E8Fu); return; }
    goto L_809E91;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E8Fu,0x809E8Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E91u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E91u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E91u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E91 SEP
    cpu.sep(0x20u);
    goto L_809E93;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E91u,0x809E91u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E93u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E93u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E93u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809E93 PHA
    cpu.push("PHA", hw);
    goto L_809E94;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E93u,0x809E93u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E94u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E94u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E94 TXA
    cpu.transfer("TXA");
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E95u,0x809E94u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E94u,0x809E94u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80A8ED_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A8EDu: goto L_80A8ED;
    case 0x80A8EFu: goto L_80A8EF;
    case 0x80A8F2u: goto L_80A8F2;
    case 0x80A8F5u: goto L_80A8F5;
    case 0x80A8F9u: goto L_80A8F9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A8ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8ED REP
    cpu.rep(0x10u);
    goto L_80A8EF;
L_80A8EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8EF LDY
    cpu.setY(0x3Fu, 16);
    goto L_80A8F2;
L_80A8F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8F2 LDX
    cpu.setX(0x5800u, 16);
    goto L_80A8F5;
L_80A8F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F5u, 8u, 4u, 0x80A91Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A8F5 JSL -> $80A91D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA8F8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8F9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A91Du, 0x80A8F5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A8F9;
L_80A8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8F9u,0x80A8F9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A8F9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A8F9u);return;} hw.unresolvedReturn(0x80A8F9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A8ED_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A8EDu: goto L_80A8ED;
    case 0x80A8EFu: goto L_80A8EF;
    case 0x80A8F2u: goto L_80A8F2;
    case 0x80A8F5u: goto L_80A8F5;
    case 0x80A8F9u: goto L_80A8F9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A8ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8ED REP
    cpu.rep(0x10u);
    goto L_80A8EF;
L_80A8EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8EF LDY
    cpu.setY(0x3Fu, 16);
    goto L_80A8F2;
L_80A8F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8F2 LDX
    cpu.setX(0x5800u, 16);
    goto L_80A8F5;
L_80A8F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F5u, 8u, 4u, 0x80A91Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A8F5 JSL -> $80A91D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA8F8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA8F9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A91Du, 0x80A8F5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A8F9;
L_80A8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA8F9u,0x80A8F9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A8F9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A8F9u);return;} hw.unresolvedReturn(0x80A8F9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AC16_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AC16u: goto L_80AC16;
    case 0x80AC1Au: goto L_80AC1A;
    case 0x80AC1Bu: goto L_80AC1B;
    case 0x80AC1Cu: goto L_80AC1C;
    case 0x80AC1Du: goto L_80AC1D;
    case 0x80AC21u: goto L_80AC21;
    case 0x80AC25u: goto L_80AC25;
    case 0x80AC26u: goto L_80AC26;
    case 0x80AC27u: goto L_80AC27;
    case 0x80AC28u: goto L_80AC28;
    case 0x80AC2Bu: goto L_80AC2B;
    case 0x80AC2Du: goto L_80AC2D;
    case 0x80AC2Eu: goto L_80AC2E;
    case 0x80AC32u: goto L_80AC32;
    case 0x80AC36u: goto L_80AC36;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AC16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC16u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC16u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC16 LDA
    cpu.loadA(hw.readW(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AC1A;
L_80AC1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AC1A PHA
    cpu.push("PHA", hw);
    goto L_80AC1B;
L_80AC1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC1B INX
    cpu.inc('X');
    goto L_80AC1C;
L_80AC1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC1C INX
    cpu.inc('X');
    goto L_80AC1D;
L_80AC1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Du, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC1D LDA
    cpu.loadA(hw.readW(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AC21;
L_80AC21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC21u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC21u, 6u, 4u, ((0x7DFFFEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC21 STA
    hw.write(((0x7DFFFEu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80AC25;
L_80AC25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC25u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC25 INX
    cpu.inc('X');
    goto L_80AC26;
L_80AC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC26u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC26u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC26 INX
    cpu.inc('X');
    goto L_80AC27;
L_80AC27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC27u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC27u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC27 TXA
    cpu.transfer("TXA");
    goto L_80AC28;
L_80AC28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC28u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC28u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC28 AND
    cpu.logicAnd(0x1Fu);
    goto L_80AC2B;
L_80AC2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC2Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC2B BNE -> $80AC1D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AC1D; }
    goto L_80AC2D;
L_80AC2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC2Du,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC2Du, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AC2D PLA
    cpu.pop("PLA", hw);
    goto L_80AC2E;
L_80AC2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC2Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC2Eu, 6u, 4u, ((0x7DFFFEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC2E STA
    hw.write(((0x7DFFFEu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80AC32;
L_80AC32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC32u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC32u, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AC32 JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAC35u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAC36u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80AC32u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AC36;
L_80AC36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC36u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAC36u,0x80AC36u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC36u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AC36 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AC36u);return;} hw.unresolvedReturn(0x80AC36u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80AC16_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AC16u: goto L_80AC16;
    case 0x80AC1Au: goto L_80AC1A;
    case 0x80AC1Bu: goto L_80AC1B;
    case 0x80AC1Cu: goto L_80AC1C;
    case 0x80AC1Du: goto L_80AC1D;
    case 0x80AC21u: goto L_80AC21;
    case 0x80AC25u: goto L_80AC25;
    case 0x80AC26u: goto L_80AC26;
    case 0x80AC27u: goto L_80AC27;
    case 0x80AC28u: goto L_80AC28;
    case 0x80AC2Bu: goto L_80AC2B;
    case 0x80AC2Du: goto L_80AC2D;
    case 0x80AC2Eu: goto L_80AC2E;
    case 0x80AC32u: goto L_80AC32;
    case 0x80AC36u: goto L_80AC36;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AC16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC16u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC16u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC16 LDA
    cpu.loadA(hw.readW(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AC1A;
L_80AC1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AC1A PHA
    cpu.push("PHA", hw);
    goto L_80AC1B;
L_80AC1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC1B INX
    cpu.inc('X');
    goto L_80AC1C;
L_80AC1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC1C INX
    cpu.inc('X');
    goto L_80AC1D;
L_80AC1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Du, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC1D LDA
    cpu.loadA(hw.readW(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AC21;
L_80AC21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC21u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC21u, 6u, 4u, ((0x7DFFFEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC21 STA
    hw.write(((0x7DFFFEu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80AC25;
L_80AC25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC25u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC25 INX
    cpu.inc('X');
    goto L_80AC26;
L_80AC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC26u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC26u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC26 INX
    cpu.inc('X');
    goto L_80AC27;
L_80AC27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC27u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC27u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC27 TXA
    cpu.transfer("TXA");
    goto L_80AC28;
L_80AC28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC28u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC28u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC28 AND
    cpu.logicAnd(0x1Fu);
    goto L_80AC2B;
L_80AC2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC2Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC2B BNE -> $80AC1D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AC1D; }
    goto L_80AC2D;
L_80AC2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC2Du,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC2Du, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AC2D PLA
    cpu.pop("PLA", hw);
    goto L_80AC2E;
L_80AC2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC2Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC2Eu, 6u, 4u, ((0x7DFFFEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC2E STA
    hw.write(((0x7DFFFEu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80AC32;
L_80AC32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC32u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC32u, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AC32 JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAC35u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAC36u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80AC32u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AC36;
L_80AC36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC36u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAC36u,0x80AC36u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC36u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AC36 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AC36u);return;} hw.unresolvedReturn(0x80AC36u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B96C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B6ACu: goto L_80B6AC;
    case 0x80B6AFu: goto L_80B6AF;
    case 0x80B6B1u: goto L_80B6B1;
    case 0x80B6B3u: goto L_80B6B3;
    case 0x80B6B5u: goto L_80B6B5;
    case 0x80B6B7u: goto L_80B6B7;
    case 0x80B6B9u: goto L_80B6B9;
    case 0x80B6BBu: goto L_80B6BB;
    case 0x80B6BDu: goto L_80B6BD;
    case 0x80B6BFu: goto L_80B6BF;
    case 0x80B96Cu: goto L_80B96C;
    case 0x80B96Eu: goto L_80B96E;
    case 0x80B970u: goto L_80B970;
    case 0x80B972u: goto L_80B972;
    case 0x80B973u: goto L_80B973;
    case 0x80B975u: goto L_80B975;
    case 0x80B976u: goto L_80B976;
    case 0x80B979u: goto L_80B979;
    case 0x80B97Bu: goto L_80B97B;
    case 0x80B97Du: goto L_80B97D;
    case 0x80B980u: goto L_80B980;
    case 0x80B982u: goto L_80B982;
    case 0x80B983u: goto L_80B983;
    case 0x80B984u: goto L_80B984;
    case 0x80B985u: goto L_80B985;
    case 0x80B986u: goto L_80B986;
    case 0x80B987u: goto L_80B987;
    case 0x80B989u: goto L_80B989;
    case 0x80B98Au: goto L_80B98A;
    case 0x80B98Bu: goto L_80B98B;
    case 0x80B98Cu: goto L_80B98C;
    case 0x80B98Du: goto L_80B98D;
    case 0x80B98Eu: goto L_80B98E;
    case 0x80B990u: goto L_80B990;
    case 0x80B992u: goto L_80B992;
    case 0x80B995u: goto L_80B995;
    case 0x80B998u: goto L_80B998;
    case 0x80B99Au: goto L_80B99A;
    case 0x80B99Du: goto L_80B99D;
    case 0x80B99Fu: goto L_80B99F;
    case 0x80B9A2u: goto L_80B9A2;
    case 0x80B9A5u: goto L_80B9A5;
    case 0x80B9A6u: goto L_80B9A6;
    case 0x80B9A9u: goto L_80B9A9;
    case 0x80B9AAu: goto L_80B9AA;
    case 0x80B9ABu: goto L_80B9AB;
    case 0x80B9AEu: goto L_80B9AE;
    case 0x80B9B1u: goto L_80B9B1;
    case 0x80B9B2u: goto L_80B9B2;
    case 0x80B9B4u: goto L_80B9B4;
    case 0x80B9B6u: goto L_80B9B6;
    case 0x80B9B9u: goto L_80B9B9;
    case 0x80B9BBu: goto L_80B9BB;
    case 0x80B9BEu: goto L_80B9BE;
    case 0x80B9C1u: goto L_80B9C1;
    case 0x80B9C2u: goto L_80B9C2;
    case 0x80B9C4u: goto L_80B9C4;
    case 0x80B9C6u: goto L_80B9C6;
    case 0x80B9C9u: goto L_80B9C9;
    case 0x80B9CBu: goto L_80B9CB;
    case 0x80B9CDu: goto L_80B9CD;
    case 0x80B9D0u: goto L_80B9D0;
    case 0x80B9D3u: goto L_80B9D3;
    case 0x80B9D4u: goto L_80B9D4;
    case 0x80B9D6u: goto L_80B9D6;
    case 0x80B9D8u: goto L_80B9D8;
    case 0x80B9DBu: goto L_80B9DB;
    case 0x80B9DDu: goto L_80B9DD;
    case 0x80B9E0u: goto L_80B9E0;
    case 0x80B9E1u: goto L_80B9E1;
    case 0x80B9E2u: goto L_80B9E2;
    case 0x80B9E3u: goto L_80B9E3;
    case 0x80B9E4u: goto L_80B9E4;
    case 0x80B9E6u: goto L_80B9E6;
    case 0x80B9E8u: goto L_80B9E8;
    case 0x80B9EBu: goto L_80B9EB;
    case 0x80B9ECu: goto L_80B9EC;
    case 0x80B9EDu: goto L_80B9ED;
    case 0x80B9F1u: goto L_80B9F1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6AC LDA
    cpu.setA(0x0u, 16);
    goto L_80B6AF;
L_80B6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6AF STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_80B6B1;
L_80B6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B1u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B1 STZ
    hw.write(cpu.address("dpx", 0x0u), 0, cpu.m8?8:16);
    goto L_80B6B3;
L_80B6B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B3 STZ
    hw.write(cpu.address("dpx", 0x2u), 0, cpu.m8?8:16);
    goto L_80B6B5;
L_80B6B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B5 STZ
    hw.write(cpu.address("dpx", 0x6u), 0, cpu.m8?8:16);
    goto L_80B6B7;
L_80B6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B7u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B7 STZ
    hw.write(cpu.address("dpx", 0x8u), 0, cpu.m8?8:16);
    goto L_80B6B9;
L_80B6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B9 STZ
    hw.write(cpu.address("dpx", 0xAu), 0, cpu.m8?8:16);
    goto L_80B6BB;
L_80B6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6BB STZ
    hw.write(cpu.address("dpx", 0xCu), 0, cpu.m8?8:16);
    goto L_80B6BD;
L_80B6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6BD STZ
    hw.write(cpu.address("dpx", 0xEu), 0, cpu.m8?8:16);
    goto L_80B6BF;
L_80B6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B6BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B6BFu);return;} hw.unresolvedReturn(0x80B6BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B96C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B96C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B96E;
L_80B96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B96E BEQ -> $80B973
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B973; }
    goto L_80B970;
L_80B970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB970u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB970u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B970 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x8u), cpu.m8?8:16);
    goto L_80B972;
L_80B972:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB972u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB972u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB972u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B972 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B972u);return;} hw.unresolvedReturn(0x80B972u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B973:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB973u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB973u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB973u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B973 INC
    cpu.incMem(hw, cpu.address("dpx", 0x4u), cpu.m8?8:16);
    goto L_80B975;
L_80B975:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB975u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB975u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB975u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B975 SEC
    cpu.setFlag('C', true);
    goto L_80B976;
L_80B976:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB976u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB976u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB976u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B976 LDA
    cpu.setA(0x1Fu, 16);
    goto L_80B979;
L_80B979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB979u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB979u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B979 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16));
    goto L_80B97B;
L_80B97B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B97B BPL -> $80B980
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B980; }
    goto L_80B97D;
L_80B97D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Du, 3u, 3u, cpu.address("abs", 0xB6ACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B97D JMP -> $80B6AC
    goto L_80B6AC;
L_80B980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB980u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB980u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B980 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80B982;
L_80B982:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB982u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB982u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB982u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B982 ASL
    cpu.aslA();
    goto L_80B983;
L_80B983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB983u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB983u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB983u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B983 ASL
    cpu.aslA();
    goto L_80B984;
L_80B984:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB984u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB984u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB984u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B984 ASL
    cpu.aslA();
    goto L_80B985;
L_80B985:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB985u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB985u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB985u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B985 ASL
    cpu.aslA();
    goto L_80B986;
L_80B986:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB986u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB986u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB986u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B986 ASL
    cpu.aslA();
    goto L_80B987;
L_80B987:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB987u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B987 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80B989;
L_80B989:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB989u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB989u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB989u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B989 ASL
    cpu.aslA();
    goto L_80B98A;
L_80B98A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B98A ASL
    cpu.aslA();
    goto L_80B98B;
L_80B98B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B98B ASL
    cpu.aslA();
    goto L_80B98C;
L_80B98C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B98C ASL
    cpu.aslA();
    goto L_80B98D;
L_80B98D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B98D ASL
    cpu.aslA();
    goto L_80B98E;
L_80B98E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B98E STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_80B990;
L_80B990:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB990u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB990u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB990u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B990 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B992;
L_80B992:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB992u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB992u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB992u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B992 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B995;
L_80B995:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB995u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB995u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB995u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B995 AND
    cpu.logicAnd(0xFFu);
    goto L_80B998;
L_80B998:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB998u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB998u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB998u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B998 STA
    hw.write(cpu.address("dpx", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80B99A;
L_80B99A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Au, 5u + 1u, 3u, cpu.address("absy", 0x0003u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B99A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B99D;
L_80B99D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B99D STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80B99F;
L_80B99F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Fu,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Fu, 5u + 1u, 3u, cpu.address("absy", 0x0001u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B99F LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B9A2;
L_80B9A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A2u, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9A2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B9A5;
L_80B9A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A5u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9A5 TAY
    cpu.transfer("TAY");
    goto L_80B9A6;
L_80B9A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A6u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A6u, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B9A6 PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80B9A9;
L_80B9A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B9A9 PLB
    cpu.pop("PLB", hw);
    goto L_80B9AA;
L_80B9AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AAu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B9AA PLB
    cpu.pop("PLB", hw);
    goto L_80B9AB;
L_80B9AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ABu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ABu, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9AB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B9AE;
L_80B9AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9AE AND
    cpu.logicAnd(0x1Fu);
    goto L_80B9B1;
L_80B9B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9B1 SEC
    cpu.setFlag('C', true);
    goto L_80B9B2;
L_80B9B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B2u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9B2 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80B9B4;
L_80B9B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9B4 BPL -> $80B9B9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B9B9; }
    goto L_80B9B6;
L_80B9B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9B6 LDA
    cpu.setA(0x0u, 16);
    goto L_80B9B9;
L_80B9B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9B9 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80B9BB;
L_80B9BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BBu, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9BB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B9BE;
L_80B9BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9BE AND
    cpu.logicAnd(0x3E0u);
    goto L_80B9C1;
L_80B9C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9C1 SEC
    cpu.setFlag('C', true);
    goto L_80B9C2;
L_80B9C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C2u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9C2 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_80B9C4;
L_80B9C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9C4 BPL -> $80B9C9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B9C9; }
    goto L_80B9C6;
L_80B9C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9C6 LDA
    cpu.setA(0x0u, 16);
    goto L_80B9C9;
L_80B9C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C9u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9C9 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80B9CB;
L_80B9CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9CB STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80B9CD;
L_80B9CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CDu, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9CD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B9D0;
L_80B9D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9D0 AND
    cpu.logicAnd(0x7C00u);
    goto L_80B9D3;
L_80B9D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D3u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9D3 SEC
    cpu.setFlag('C', true);
    goto L_80B9D4;
L_80B9D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D4u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9D4 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16));
    goto L_80B9D6;
L_80B9D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9D6 BPL -> $80B9DB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B9DB; }
    goto L_80B9D8;
L_80B9D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9D8 LDA
    cpu.setA(0x0u, 16);
    goto L_80B9DB;
L_80B9DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DBu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9DB ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80B9DD;
L_80B9DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DDu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DDu, 6u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9DD STA
    hw.write(cpu.address("absy", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B9E0;
L_80B9E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9E0 INX
    cpu.inc('X');
    goto L_80B9E1;
L_80B9E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9E1 INX
    cpu.inc('X');
    goto L_80B9E2;
L_80B9E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E2u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9E2 INY
    cpu.inc('Y');
    goto L_80B9E3;
L_80B9E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9E3 INY
    cpu.inc('Y');
    goto L_80B9E4;
L_80B9E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E4u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9E4 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0xAu), cpu.x8?8:16));
    goto L_80B9E6;
L_80B9E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9E6 BCC -> $80B9AB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B9AB; }
    goto L_80B9E8;
L_80B9E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E8u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E8u, 5u, 3u, cpu.address("abs", 0x8100u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B9E8 PEA
    cpu.push16Value(hw, 0x8100u);
    goto L_80B9EB;
L_80B9EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EBu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B9EB PLB
    cpu.pop("PLB", hw);
    goto L_80B9EC;
L_80B9EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ECu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ECu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B9EC PLB
    cpu.pop("PLB", hw);
    goto L_80B9ED;
L_80B9ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EDu, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B9ED JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB9F0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB9F1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80B9EDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B9F1;
L_80B9F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9F1u,0x80B9F1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B9F1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B9F1u);return;} hw.unresolvedReturn(0x80B9F1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B96C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B6ACu: goto L_80B6AC;
    case 0x80B6AFu: goto L_80B6AF;
    case 0x80B6B1u: goto L_80B6B1;
    case 0x80B6B3u: goto L_80B6B3;
    case 0x80B6B5u: goto L_80B6B5;
    case 0x80B6B7u: goto L_80B6B7;
    case 0x80B6B9u: goto L_80B6B9;
    case 0x80B6BBu: goto L_80B6BB;
    case 0x80B6BDu: goto L_80B6BD;
    case 0x80B6BFu: goto L_80B6BF;
    case 0x80B96Cu: goto L_80B96C;
    case 0x80B96Eu: goto L_80B96E;
    case 0x80B970u: goto L_80B970;
    case 0x80B972u: goto L_80B972;
    case 0x80B973u: goto L_80B973;
    case 0x80B975u: goto L_80B975;
    case 0x80B976u: goto L_80B976;
    case 0x80B979u: goto L_80B979;
    case 0x80B97Bu: goto L_80B97B;
    case 0x80B97Du: goto L_80B97D;
    case 0x80B980u: goto L_80B980;
    case 0x80B982u: goto L_80B982;
    case 0x80B983u: goto L_80B983;
    case 0x80B984u: goto L_80B984;
    case 0x80B985u: goto L_80B985;
    case 0x80B986u: goto L_80B986;
    case 0x80B987u: goto L_80B987;
    case 0x80B989u: goto L_80B989;
    case 0x80B98Au: goto L_80B98A;
    case 0x80B98Bu: goto L_80B98B;
    case 0x80B98Cu: goto L_80B98C;
    case 0x80B98Du: goto L_80B98D;
    case 0x80B98Eu: goto L_80B98E;
    case 0x80B990u: goto L_80B990;
    case 0x80B992u: goto L_80B992;
    case 0x80B995u: goto L_80B995;
    case 0x80B998u: goto L_80B998;
    case 0x80B99Au: goto L_80B99A;
    case 0x80B99Du: goto L_80B99D;
    case 0x80B99Fu: goto L_80B99F;
    case 0x80B9A2u: goto L_80B9A2;
    case 0x80B9A5u: goto L_80B9A5;
    case 0x80B9A6u: goto L_80B9A6;
    case 0x80B9A9u: goto L_80B9A9;
    case 0x80B9AAu: goto L_80B9AA;
    case 0x80B9ABu: goto L_80B9AB;
    case 0x80B9AEu: goto L_80B9AE;
    case 0x80B9B1u: goto L_80B9B1;
    case 0x80B9B2u: goto L_80B9B2;
    case 0x80B9B4u: goto L_80B9B4;
    case 0x80B9B6u: goto L_80B9B6;
    case 0x80B9B9u: goto L_80B9B9;
    case 0x80B9BBu: goto L_80B9BB;
    case 0x80B9BEu: goto L_80B9BE;
    case 0x80B9C1u: goto L_80B9C1;
    case 0x80B9C2u: goto L_80B9C2;
    case 0x80B9C4u: goto L_80B9C4;
    case 0x80B9C6u: goto L_80B9C6;
    case 0x80B9C9u: goto L_80B9C9;
    case 0x80B9CBu: goto L_80B9CB;
    case 0x80B9CDu: goto L_80B9CD;
    case 0x80B9D0u: goto L_80B9D0;
    case 0x80B9D3u: goto L_80B9D3;
    case 0x80B9D4u: goto L_80B9D4;
    case 0x80B9D6u: goto L_80B9D6;
    case 0x80B9D8u: goto L_80B9D8;
    case 0x80B9DBu: goto L_80B9DB;
    case 0x80B9DDu: goto L_80B9DD;
    case 0x80B9E0u: goto L_80B9E0;
    case 0x80B9E1u: goto L_80B9E1;
    case 0x80B9E2u: goto L_80B9E2;
    case 0x80B9E3u: goto L_80B9E3;
    case 0x80B9E4u: goto L_80B9E4;
    case 0x80B9E6u: goto L_80B9E6;
    case 0x80B9E8u: goto L_80B9E8;
    case 0x80B9EBu: goto L_80B9EB;
    case 0x80B9ECu: goto L_80B9EC;
    case 0x80B9EDu: goto L_80B9ED;
    case 0x80B9F1u: goto L_80B9F1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6AC LDA
    cpu.setA(0x0u, 16);
    goto L_80B6AF;
L_80B6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6AF STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_80B6B1;
L_80B6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B1u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B1 STZ
    hw.write(cpu.address("dpx", 0x0u), 0, cpu.m8?8:16);
    goto L_80B6B3;
L_80B6B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B3 STZ
    hw.write(cpu.address("dpx", 0x2u), 0, cpu.m8?8:16);
    goto L_80B6B5;
L_80B6B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B5 STZ
    hw.write(cpu.address("dpx", 0x6u), 0, cpu.m8?8:16);
    goto L_80B6B7;
L_80B6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B7u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B7 STZ
    hw.write(cpu.address("dpx", 0x8u), 0, cpu.m8?8:16);
    goto L_80B6B9;
L_80B6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B9 STZ
    hw.write(cpu.address("dpx", 0xAu), 0, cpu.m8?8:16);
    goto L_80B6BB;
L_80B6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6BB STZ
    hw.write(cpu.address("dpx", 0xCu), 0, cpu.m8?8:16);
    goto L_80B6BD;
L_80B6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6BD STZ
    hw.write(cpu.address("dpx", 0xEu), 0, cpu.m8?8:16);
    goto L_80B6BF;
L_80B6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B6BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B6BFu);return;} hw.unresolvedReturn(0x80B6BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B96C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B96C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B96E;
L_80B96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B96E BEQ -> $80B973
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B973; }
    goto L_80B970;
L_80B970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB970u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB970u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B970 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x8u), cpu.m8?8:16);
    goto L_80B972;
L_80B972:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB972u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB972u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB972u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B972 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B972u);return;} hw.unresolvedReturn(0x80B972u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B973:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB973u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB973u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB973u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B973 INC
    cpu.incMem(hw, cpu.address("dpx", 0x4u), cpu.m8?8:16);
    goto L_80B975;
L_80B975:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB975u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB975u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB975u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B975 SEC
    cpu.setFlag('C', true);
    goto L_80B976;
L_80B976:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB976u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB976u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB976u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B976 LDA
    cpu.setA(0x1Fu, 16);
    goto L_80B979;
L_80B979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB979u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB979u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B979 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16));
    goto L_80B97B;
L_80B97B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B97B BPL -> $80B980
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B980; }
    goto L_80B97D;
L_80B97D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Du, 3u, 3u, cpu.address("abs", 0xB6ACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B97D JMP -> $80B6AC
    goto L_80B6AC;
L_80B980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB980u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB980u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B980 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80B982;
L_80B982:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB982u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB982u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB982u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B982 ASL
    cpu.aslA();
    goto L_80B983;
L_80B983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB983u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB983u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB983u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B983 ASL
    cpu.aslA();
    goto L_80B984;
L_80B984:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB984u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB984u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB984u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B984 ASL
    cpu.aslA();
    goto L_80B985;
L_80B985:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB985u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB985u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB985u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B985 ASL
    cpu.aslA();
    goto L_80B986;
L_80B986:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB986u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB986u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB986u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B986 ASL
    cpu.aslA();
    goto L_80B987;
L_80B987:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB987u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B987 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80B989;
L_80B989:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB989u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB989u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB989u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B989 ASL
    cpu.aslA();
    goto L_80B98A;
L_80B98A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B98A ASL
    cpu.aslA();
    goto L_80B98B;
L_80B98B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B98B ASL
    cpu.aslA();
    goto L_80B98C;
L_80B98C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B98C ASL
    cpu.aslA();
    goto L_80B98D;
L_80B98D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B98D ASL
    cpu.aslA();
    goto L_80B98E;
L_80B98E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B98E STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_80B990;
L_80B990:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB990u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB990u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB990u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B990 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B992;
L_80B992:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB992u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB992u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB992u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B992 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B995;
L_80B995:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB995u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB995u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB995u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B995 AND
    cpu.logicAnd(0xFFu);
    goto L_80B998;
L_80B998:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB998u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB998u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB998u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B998 STA
    hw.write(cpu.address("dpx", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80B99A;
L_80B99A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Au, 5u + 1u, 3u, cpu.address("absy", 0x0003u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B99A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B99D;
L_80B99D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B99D STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80B99F;
L_80B99F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Fu,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Fu, 5u + 1u, 3u, cpu.address("absy", 0x0001u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B99F LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B9A2;
L_80B9A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A2u, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9A2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B9A5;
L_80B9A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A5u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9A5 TAY
    cpu.transfer("TAY");
    goto L_80B9A6;
L_80B9A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A6u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A6u, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B9A6 PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80B9A9;
L_80B9A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B9A9 PLB
    cpu.pop("PLB", hw);
    goto L_80B9AA;
L_80B9AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AAu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B9AA PLB
    cpu.pop("PLB", hw);
    goto L_80B9AB;
L_80B9AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ABu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ABu, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9AB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B9AE;
L_80B9AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9AE AND
    cpu.logicAnd(0x1Fu);
    goto L_80B9B1;
L_80B9B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9B1 SEC
    cpu.setFlag('C', true);
    goto L_80B9B2;
L_80B9B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B2u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9B2 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80B9B4;
L_80B9B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9B4 BPL -> $80B9B9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B9B9; }
    goto L_80B9B6;
L_80B9B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9B6 LDA
    cpu.setA(0x0u, 16);
    goto L_80B9B9;
L_80B9B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9B9 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80B9BB;
L_80B9BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BBu, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9BB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B9BE;
L_80B9BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9BE AND
    cpu.logicAnd(0x3E0u);
    goto L_80B9C1;
L_80B9C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9C1 SEC
    cpu.setFlag('C', true);
    goto L_80B9C2;
L_80B9C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C2u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9C2 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_80B9C4;
L_80B9C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9C4 BPL -> $80B9C9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B9C9; }
    goto L_80B9C6;
L_80B9C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9C6 LDA
    cpu.setA(0x0u, 16);
    goto L_80B9C9;
L_80B9C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C9u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9C9 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80B9CB;
L_80B9CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9CB STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80B9CD;
L_80B9CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CDu, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9CD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B9D0;
L_80B9D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9D0 AND
    cpu.logicAnd(0x7C00u);
    goto L_80B9D3;
L_80B9D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D3u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9D3 SEC
    cpu.setFlag('C', true);
    goto L_80B9D4;
L_80B9D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D4u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9D4 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16));
    goto L_80B9D6;
L_80B9D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9D6 BPL -> $80B9DB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B9DB; }
    goto L_80B9D8;
L_80B9D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9D8 LDA
    cpu.setA(0x0u, 16);
    goto L_80B9DB;
L_80B9DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DBu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9DB ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80B9DD;
L_80B9DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DDu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DDu, 6u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9DD STA
    hw.write(cpu.address("absy", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B9E0;
L_80B9E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9E0 INX
    cpu.inc('X');
    goto L_80B9E1;
L_80B9E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9E1 INX
    cpu.inc('X');
    goto L_80B9E2;
L_80B9E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E2u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9E2 INY
    cpu.inc('Y');
    goto L_80B9E3;
L_80B9E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9E3 INY
    cpu.inc('Y');
    goto L_80B9E4;
L_80B9E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E4u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9E4 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0xAu), cpu.x8?8:16));
    goto L_80B9E6;
L_80B9E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9E6 BCC -> $80B9AB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B9AB; }
    goto L_80B9E8;
L_80B9E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E8u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E8u, 5u, 3u, cpu.address("abs", 0x8100u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B9E8 PEA
    cpu.push16Value(hw, 0x8100u);
    goto L_80B9EB;
L_80B9EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EBu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B9EB PLB
    cpu.pop("PLB", hw);
    goto L_80B9EC;
L_80B9EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ECu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ECu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B9EC PLB
    cpu.pop("PLB", hw);
    goto L_80B9ED;
L_80B9ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EDu, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B9ED JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB9F0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB9F1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80B9EDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B9F1;
L_80B9F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9F1u,0x80B9F1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B9F1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B9F1u);return;} hw.unresolvedReturn(0x80B9F1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B9F2_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B6ACu: goto L_80B6AC;
    case 0x80B6AFu: goto L_80B6AF;
    case 0x80B6B1u: goto L_80B6B1;
    case 0x80B6B3u: goto L_80B6B3;
    case 0x80B6B5u: goto L_80B6B5;
    case 0x80B6B7u: goto L_80B6B7;
    case 0x80B6B9u: goto L_80B6B9;
    case 0x80B6BBu: goto L_80B6BB;
    case 0x80B6BDu: goto L_80B6BD;
    case 0x80B6BFu: goto L_80B6BF;
    case 0x80B9F2u: goto L_80B9F2;
    case 0x80B9F4u: goto L_80B9F4;
    case 0x80B9F6u: goto L_80B9F6;
    case 0x80B9F8u: goto L_80B9F8;
    case 0x80B9F9u: goto L_80B9F9;
    case 0x80B9FBu: goto L_80B9FB;
    case 0x80B9FDu: goto L_80B9FD;
    case 0x80BA00u: goto L_80BA00;
    case 0x80BA02u: goto L_80BA02;
    case 0x80BA05u: goto L_80BA05;
    case 0x80BA07u: goto L_80BA07;
    case 0x80BA0Au: goto L_80BA0A;
    case 0x80BA0Du: goto L_80BA0D;
    case 0x80BA0Fu: goto L_80BA0F;
    case 0x80BA12u: goto L_80BA12;
    case 0x80BA14u: goto L_80BA14;
    case 0x80BA17u: goto L_80BA17;
    case 0x80BA1Bu: goto L_80BA1B;
    case 0x80BA1Eu: goto L_80BA1E;
    case 0x80BA22u: goto L_80BA22;
    case 0x80BA23u: goto L_80BA23;
    case 0x80BA24u: goto L_80BA24;
    case 0x80BA26u: goto L_80BA26;
    case 0x80BA28u: goto L_80BA28;
    case 0x80BA2Cu: goto L_80BA2C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6AC LDA
    cpu.setA(0x0u, 16);
    goto L_80B6AF;
L_80B6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6AF STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_80B6B1;
L_80B6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B1u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B1 STZ
    hw.write(cpu.address("dpx", 0x0u), 0, cpu.m8?8:16);
    goto L_80B6B3;
L_80B6B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B3 STZ
    hw.write(cpu.address("dpx", 0x2u), 0, cpu.m8?8:16);
    goto L_80B6B5;
L_80B6B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B5 STZ
    hw.write(cpu.address("dpx", 0x6u), 0, cpu.m8?8:16);
    goto L_80B6B7;
L_80B6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B7u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B7 STZ
    hw.write(cpu.address("dpx", 0x8u), 0, cpu.m8?8:16);
    goto L_80B6B9;
L_80B6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B9 STZ
    hw.write(cpu.address("dpx", 0xAu), 0, cpu.m8?8:16);
    goto L_80B6BB;
L_80B6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6BB STZ
    hw.write(cpu.address("dpx", 0xCu), 0, cpu.m8?8:16);
    goto L_80B6BD;
L_80B6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6BD STZ
    hw.write(cpu.address("dpx", 0xEu), 0, cpu.m8?8:16);
    goto L_80B6BF;
L_80B6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B6BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B6BFu);return;} hw.unresolvedReturn(0x80B6BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B9F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F2u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9F2 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B9F4;
L_80B9F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9F4 BEQ -> $80B9F9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B9F9; }
    goto L_80B9F6;
L_80B9F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F6u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F6u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9F6 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x8u), cpu.m8?8:16);
    goto L_80B9F8;
L_80B9F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B9F8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B9F8u);return;} hw.unresolvedReturn(0x80B9F8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F9u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F9u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9F9 INC
    cpu.incMem(hw, cpu.address("dpx", 0x4u), cpu.m8?8:16);
    goto L_80B9FB;
L_80B9FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9FB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B9FD;
L_80B9FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9FD CMP
    cpu.compareA(0x20u);
    goto L_80BA00;
L_80BA00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA00u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA00 BCC -> $80BA05
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BA05; }
    goto L_80BA02;
L_80BA02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA02u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA02u, 3u, 3u, cpu.address("abs", 0xB6ACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA02 JMP -> $80B6AC
    goto L_80B6AC;
L_80BA05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA05u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA05u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA05 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BA07;
L_80BA07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA07u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA07u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA07 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA0A;
L_80BA0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA0A AND
    cpu.logicAnd(0x7Fu);
    goto L_80BA0D;
L_80BA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA0D STA
    hw.write(cpu.address("dpx", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BA0F;
L_80BA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Fu, 5u + 1u, 3u, cpu.address("absy", 0x0003u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA0F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA12;
L_80BA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA12u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA12u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA12 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BA14;
L_80BA14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA14u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA14u, 5u + 1u, 3u, cpu.address("absy", 0x0001u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA14 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BA17;
L_80BA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA17u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA17u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA17 LDA
    cpu.loadA(hw.readW(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA1B;
L_80BA1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Bu, 6u, 3u, cpu.address("abs", 0xBA2Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BA1B JSR -> $80BA2D stack real
    { cpu.push16Value(hw,0xBA1Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBA1Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBA2Du), 0x80BA1Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BA1E;
L_80BA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA1Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA1Eu,0x80BA1Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Eu, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA1E STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80BA22;
L_80BA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA22u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA22 INX
    cpu.inc('X');
    goto L_80BA23;
L_80BA23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA23u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA23 INX
    cpu.inc('X');
    goto L_80BA24;
L_80BA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA24u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA24u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA24 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16));
    goto L_80BA26;
L_80BA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA26u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA26 BCC -> $80BA17
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BA17; }
    goto L_80BA28;
L_80BA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA28u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA28u, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BA28 JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBA2Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBA2Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80BA28u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BA2C;
L_80BA2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA2Cu,0x80BA2Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BA2C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BA2Cu);return;} hw.unresolvedReturn(0x80BA2Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B9F2_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B6ACu: goto L_80B6AC;
    case 0x80B6AFu: goto L_80B6AF;
    case 0x80B6B1u: goto L_80B6B1;
    case 0x80B6B3u: goto L_80B6B3;
    case 0x80B6B5u: goto L_80B6B5;
    case 0x80B6B7u: goto L_80B6B7;
    case 0x80B6B9u: goto L_80B6B9;
    case 0x80B6BBu: goto L_80B6BB;
    case 0x80B6BDu: goto L_80B6BD;
    case 0x80B6BFu: goto L_80B6BF;
    case 0x80B9F2u: goto L_80B9F2;
    case 0x80B9F4u: goto L_80B9F4;
    case 0x80B9F6u: goto L_80B9F6;
    case 0x80B9F8u: goto L_80B9F8;
    case 0x80B9F9u: goto L_80B9F9;
    case 0x80B9FBu: goto L_80B9FB;
    case 0x80B9FDu: goto L_80B9FD;
    case 0x80BA00u: goto L_80BA00;
    case 0x80BA02u: goto L_80BA02;
    case 0x80BA05u: goto L_80BA05;
    case 0x80BA07u: goto L_80BA07;
    case 0x80BA0Au: goto L_80BA0A;
    case 0x80BA0Du: goto L_80BA0D;
    case 0x80BA0Fu: goto L_80BA0F;
    case 0x80BA12u: goto L_80BA12;
    case 0x80BA14u: goto L_80BA14;
    case 0x80BA17u: goto L_80BA17;
    case 0x80BA1Bu: goto L_80BA1B;
    case 0x80BA1Eu: goto L_80BA1E;
    case 0x80BA22u: goto L_80BA22;
    case 0x80BA23u: goto L_80BA23;
    case 0x80BA24u: goto L_80BA24;
    case 0x80BA26u: goto L_80BA26;
    case 0x80BA28u: goto L_80BA28;
    case 0x80BA2Cu: goto L_80BA2C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6AC LDA
    cpu.setA(0x0u, 16);
    goto L_80B6AF;
L_80B6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6AF STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_80B6B1;
L_80B6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B1u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B1 STZ
    hw.write(cpu.address("dpx", 0x0u), 0, cpu.m8?8:16);
    goto L_80B6B3;
L_80B6B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B3 STZ
    hw.write(cpu.address("dpx", 0x2u), 0, cpu.m8?8:16);
    goto L_80B6B5;
L_80B6B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B5 STZ
    hw.write(cpu.address("dpx", 0x6u), 0, cpu.m8?8:16);
    goto L_80B6B7;
L_80B6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B7u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B7 STZ
    hw.write(cpu.address("dpx", 0x8u), 0, cpu.m8?8:16);
    goto L_80B6B9;
L_80B6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6B9 STZ
    hw.write(cpu.address("dpx", 0xAu), 0, cpu.m8?8:16);
    goto L_80B6BB;
L_80B6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6BB STZ
    hw.write(cpu.address("dpx", 0xCu), 0, cpu.m8?8:16);
    goto L_80B6BD;
L_80B6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6BD STZ
    hw.write(cpu.address("dpx", 0xEu), 0, cpu.m8?8:16);
    goto L_80B6BF;
L_80B6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B6BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B6BFu);return;} hw.unresolvedReturn(0x80B6BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B9F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F2u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9F2 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B9F4;
L_80B9F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9F4 BEQ -> $80B9F9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B9F9; }
    goto L_80B9F6;
L_80B9F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F6u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F6u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9F6 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x8u), cpu.m8?8:16);
    goto L_80B9F8;
L_80B9F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B9F8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B9F8u);return;} hw.unresolvedReturn(0x80B9F8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F9u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F9u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9F9 INC
    cpu.incMem(hw, cpu.address("dpx", 0x4u), cpu.m8?8:16);
    goto L_80B9FB;
L_80B9FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9FB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B9FD;
L_80B9FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B9FD CMP
    cpu.compareA(0x20u);
    goto L_80BA00;
L_80BA00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA00u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA00 BCC -> $80BA05
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BA05; }
    goto L_80BA02;
L_80BA02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA02u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA02u, 3u, 3u, cpu.address("abs", 0xB6ACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA02 JMP -> $80B6AC
    goto L_80B6AC;
L_80BA05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA05u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA05u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA05 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BA07;
L_80BA07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA07u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA07u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA07 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA0A;
L_80BA0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA0A AND
    cpu.logicAnd(0x7Fu);
    goto L_80BA0D;
L_80BA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA0D STA
    hw.write(cpu.address("dpx", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BA0F;
L_80BA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Fu, 5u + 1u, 3u, cpu.address("absy", 0x0003u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA0F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA12;
L_80BA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA12u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA12u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA12 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80BA14;
L_80BA14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA14u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA14u, 5u + 1u, 3u, cpu.address("absy", 0x0001u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA14 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BA17;
L_80BA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA17u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA17u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA17 LDA
    cpu.loadA(hw.readW(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BA1B;
L_80BA1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Bu, 6u, 3u, cpu.address("abs", 0xBA2Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BA1B JSR -> $80BA2D stack real
    { cpu.push16Value(hw,0xBA1Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBA1Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBA2Du), 0x80BA1Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BA1E;
L_80BA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA1Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA1Eu,0x80BA1Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Eu, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA1E STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80BA22;
L_80BA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA22u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA22 INX
    cpu.inc('X');
    goto L_80BA23;
L_80BA23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA23u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA23 INX
    cpu.inc('X');
    goto L_80BA24;
L_80BA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA24u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA24u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA24 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16));
    goto L_80BA26;
L_80BA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA26u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BA26 BCC -> $80BA17
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BA17; }
    goto L_80BA28;
L_80BA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA28u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA28u, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BA28 JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBA2Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBA2Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80BA28u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BA2C;
L_80BA2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA2Cu,0x80BA2Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BA2C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BA2Cu);return;} hw.unresolvedReturn(0x80BA2Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8293CB_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8293CBu: goto L_8293CB;
    case 0x8293CCu: goto L_8293CC;
    case 0x8293CFu: goto L_8293CF;
    case 0x8293D2u: goto L_8293D2;
    case 0x8293D5u: goto L_8293D5;
    case 0x8293D8u: goto L_8293D8;
    case 0x8293D9u: goto L_8293D9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8293CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CBu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CBu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8293CB PHB
    cpu.push("PHB", hw);
    goto L_8293CC;
L_8293CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293CC LDA
    cpu.setA(0x2Fu, 16);
    goto L_8293CF;
L_8293CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93CFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293CF LDX
    cpu.setX(0xEF10u, 16);
    goto L_8293D2;
L_8293D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8293D2 LDY
    cpu.setY(0xED10u, 16);
    goto L_8293D5;
L_8293D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D5u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x93D5u, (std::uint32_t(cpu.a)+1u), 0x7Fu, 0x7Fu);
    // $8293D5 MVN
    cpu.blockMove(hw, 0x7Fu, 0x7Fu, false);
    goto L_8293D8;
L_8293D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D8u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8293D8 PLB
    cpu.pop("PLB", hw);
    goto L_8293D9;
L_8293D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x93D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x93D9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x93D9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8293D9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8293D9u);return;} hw.unresolvedReturn(0x8293D9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B594_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B4B4u: goto L_82B4B4;
    case 0x82B4B7u: goto L_82B4B7;
    case 0x82B4BAu: goto L_82B4BA;
    case 0x82B4BDu: goto L_82B4BD;
    case 0x82B4BEu: goto L_82B4BE;
    case 0x82B4C1u: goto L_82B4C1;
    case 0x82B4C4u: goto L_82B4C4;
    case 0x82B4C7u: goto L_82B4C7;
    case 0x82B4DFu: goto L_82B4DF;
    case 0x82B4E2u: goto L_82B4E2;
    case 0x82B4E4u: goto L_82B4E4;
    case 0x82B4E7u: goto L_82B4E7;
    case 0x82B4E8u: goto L_82B4E8;
    case 0x82B4E9u: goto L_82B4E9;
    case 0x82B4ECu: goto L_82B4EC;
    case 0x82B4EFu: goto L_82B4EF;
    case 0x82B4F0u: goto L_82B4F0;
    case 0x82B4F3u: goto L_82B4F3;
    case 0x82B4F5u: goto L_82B4F5;
    case 0x82B4F6u: goto L_82B4F6;
    case 0x82B4F9u: goto L_82B4F9;
    case 0x82B4FCu: goto L_82B4FC;
    case 0x82B4FFu: goto L_82B4FF;
    case 0x82B500u: goto L_82B500;
    case 0x82B501u: goto L_82B501;
    case 0x82B504u: goto L_82B504;
    case 0x82B506u: goto L_82B506;
    case 0x82B509u: goto L_82B509;
    case 0x82B50Cu: goto L_82B50C;
    case 0x82B50Du: goto L_82B50D;
    case 0x82B50Fu: goto L_82B50F;
    case 0x82B512u: goto L_82B512;
    case 0x82B514u: goto L_82B514;
    case 0x82B517u: goto L_82B517;
    case 0x82B594u: goto L_82B594;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u, 6u, 3u, cpu.address("absx", 0x1C58u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4B4 STZ
    hw.write(cpu.address("absx", 0x1C58u), 0, cpu.m8?8:16);
    goto L_82B4B7;
L_82B4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4B7 LDY
    cpu.setY(0x3u, 16);
    goto L_82B4BA;
L_82B4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu, 6u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BA STA
    hw.write(cpu.address("absx", 0x1C48u), cpu.a, cpu.m8?8:16);
    goto L_82B4BD;
L_82B4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BD TYA
    cpu.transfer("TYA");
    goto L_82B4BE;
L_82B4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu, 6u, 3u, cpu.address("absx", 0x1C54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BE STA
    hw.write(cpu.address("absx", 0x1C54u), cpu.a, cpu.m8?8:16);
    goto L_82B4C1;
L_82B4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u, 6u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4C1 STA
    hw.write(cpu.address("absx", 0x1C5Cu), cpu.a, cpu.m8?8:16);
    goto L_82B4C4;
L_82B4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u, 9u, 3u, cpu.address("absx", 0x1C24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4C4 INC
    cpu.incMem(hw, cpu.address("absx", 0x1C24u), cpu.m8?8:16);
    goto L_82B4C7;
L_82B4C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B4C7u);return;} hw.unresolvedReturn(0x82B4C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu, 9u, 3u, cpu.address("absx", 0x1C54u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4DF DEC
    cpu.decMem(hw, cpu.address("absx", 0x1C54u), cpu.m8?8:16);
    goto L_82B4E2;
L_82B4E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E2 BNE -> $82B50C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B50C; }
    goto L_82B4E4;
L_82B4E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E4u, 5u + 1u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4E7;
L_82B4E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E7 TAY
    cpu.transfer("TAY");
    goto L_82B4E8;
L_82B4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E8 CLC
    cpu.setFlag('C', false);
    goto L_82B4E9;
L_82B4E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E9 ADC
    cpu.adc(0x6u);
    goto L_82B4EC;
L_82B4EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu, 6u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4EC STA
    hw.write(cpu.address("absx", 0x1C48u), cpu.a, cpu.m8?8:16);
    goto L_82B4EF;
L_82B4EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EFu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4EF TYX
    cpu.transfer("TYX");
    goto L_82B4F0;
L_82B4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4F3;
L_82B4F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F3 BEQ -> $82B50D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B50D; }
    goto L_82B4F5;
L_82B4F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F5u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4F5 PHA
    cpu.push("PHA", hw);
    goto L_82B4F6;
L_82B4F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F6u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F6u, 5u + 1u, 3u, cpu.address("absx", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F6 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B4F9;
L_82B4F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F9u, 6u, 3u, cpu.address("abs", 0xB47Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4F9 JSR -> $82B47D stack real
    { cpu.push16Value(hw,0xB4FBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4FCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB47Du), 0x82B4F9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B4FC;
L_82B4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4FCu,0x82B4FCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu, 5u + 1u, 3u, cpu.address("absx", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4FC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4FF;
L_82B4FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4FF TAX
    cpu.transfer("TAX");
    goto L_82B500;
L_82B500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB500u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB500u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B500 PLA
    cpu.pop("PLA", hw);
    goto L_82B501;
L_82B501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u, 6u, 3u, cpu.address("abs", 0xB800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B501 JSR -> $82B800 stack real
    { cpu.push16Value(hw,0xB503u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB504u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB800u), 0x82B501u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B504;
L_82B504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB504u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB504u,0x82B504u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB504u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB504u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B504 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B506;
L_82B506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB506u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB506u, 5u + 1u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B506 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C5Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B509;
L_82B509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u, 6u, 3u, cpu.address("absx", 0x1C54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B509 STA
    hw.write(cpu.address("absx", 0x1C54u), cpu.a, cpu.m8?8:16);
    goto L_82B50C;
L_82B50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B50C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B50Cu);return;} hw.unresolvedReturn(0x82B50Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B50C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B50Cu);return;} hw.unresolvedReturn(0x82B50Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB50Cu,0x82B50Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B50D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B50D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B50F;
L_82B50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu, 5u + 1u, 3u, cpu.address("absx", 0x1C58u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B50F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C58u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B512;
L_82B512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B512 BEQ -> $82B4C4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B4C4; }
    goto L_82B514;
L_82B514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u, 9u, 3u, cpu.address("absx", 0x1C24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B514 DEC
    cpu.decMem(hw, cpu.address("absx", 0x1C24u), cpu.m8?8:16);
    goto L_82B517;
L_82B517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB517u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB517u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B517 BRA -> $82B4B4
    goto L_82B4B4;
L_82B594:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB594u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB594u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB594u, 3u, 3u, cpu.address("abs", 0xB4DFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B594 JMP -> $82B4DF
    goto L_82B4DF;
}

void sub_82B594_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B4B4u: goto L_82B4B4;
    case 0x82B4B7u: goto L_82B4B7;
    case 0x82B4BAu: goto L_82B4BA;
    case 0x82B4BDu: goto L_82B4BD;
    case 0x82B4BEu: goto L_82B4BE;
    case 0x82B4C1u: goto L_82B4C1;
    case 0x82B4C4u: goto L_82B4C4;
    case 0x82B4C7u: goto L_82B4C7;
    case 0x82B4DFu: goto L_82B4DF;
    case 0x82B4E2u: goto L_82B4E2;
    case 0x82B4E4u: goto L_82B4E4;
    case 0x82B4E7u: goto L_82B4E7;
    case 0x82B4E8u: goto L_82B4E8;
    case 0x82B4E9u: goto L_82B4E9;
    case 0x82B4ECu: goto L_82B4EC;
    case 0x82B4EFu: goto L_82B4EF;
    case 0x82B4F0u: goto L_82B4F0;
    case 0x82B4F3u: goto L_82B4F3;
    case 0x82B4F5u: goto L_82B4F5;
    case 0x82B4F6u: goto L_82B4F6;
    case 0x82B4F9u: goto L_82B4F9;
    case 0x82B4FCu: goto L_82B4FC;
    case 0x82B4FFu: goto L_82B4FF;
    case 0x82B500u: goto L_82B500;
    case 0x82B501u: goto L_82B501;
    case 0x82B504u: goto L_82B504;
    case 0x82B506u: goto L_82B506;
    case 0x82B509u: goto L_82B509;
    case 0x82B50Cu: goto L_82B50C;
    case 0x82B50Du: goto L_82B50D;
    case 0x82B50Fu: goto L_82B50F;
    case 0x82B512u: goto L_82B512;
    case 0x82B514u: goto L_82B514;
    case 0x82B517u: goto L_82B517;
    case 0x82B594u: goto L_82B594;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u, 6u, 3u, cpu.address("absx", 0x1C58u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4B4 STZ
    hw.write(cpu.address("absx", 0x1C58u), 0, cpu.m8?8:16);
    goto L_82B4B7;
L_82B4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4B7 LDY
    cpu.setY(0x3u, 16);
    goto L_82B4BA;
L_82B4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu, 6u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BA STA
    hw.write(cpu.address("absx", 0x1C48u), cpu.a, cpu.m8?8:16);
    goto L_82B4BD;
L_82B4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BD TYA
    cpu.transfer("TYA");
    goto L_82B4BE;
L_82B4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu, 6u, 3u, cpu.address("absx", 0x1C54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BE STA
    hw.write(cpu.address("absx", 0x1C54u), cpu.a, cpu.m8?8:16);
    goto L_82B4C1;
L_82B4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u, 6u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4C1 STA
    hw.write(cpu.address("absx", 0x1C5Cu), cpu.a, cpu.m8?8:16);
    goto L_82B4C4;
L_82B4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u, 9u, 3u, cpu.address("absx", 0x1C24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4C4 INC
    cpu.incMem(hw, cpu.address("absx", 0x1C24u), cpu.m8?8:16);
    goto L_82B4C7;
L_82B4C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B4C7u);return;} hw.unresolvedReturn(0x82B4C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu, 9u, 3u, cpu.address("absx", 0x1C54u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4DF DEC
    cpu.decMem(hw, cpu.address("absx", 0x1C54u), cpu.m8?8:16);
    goto L_82B4E2;
L_82B4E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E2 BNE -> $82B50C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B50C; }
    goto L_82B4E4;
L_82B4E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E4u, 5u + 1u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4E7;
L_82B4E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E7 TAY
    cpu.transfer("TAY");
    goto L_82B4E8;
L_82B4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E8 CLC
    cpu.setFlag('C', false);
    goto L_82B4E9;
L_82B4E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E9 ADC
    cpu.adc(0x6u);
    goto L_82B4EC;
L_82B4EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu, 6u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4EC STA
    hw.write(cpu.address("absx", 0x1C48u), cpu.a, cpu.m8?8:16);
    goto L_82B4EF;
L_82B4EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EFu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4EF TYX
    cpu.transfer("TYX");
    goto L_82B4F0;
L_82B4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4F3;
L_82B4F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F3 BEQ -> $82B50D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B50D; }
    goto L_82B4F5;
L_82B4F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F5u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4F5 PHA
    cpu.push("PHA", hw);
    goto L_82B4F6;
L_82B4F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F6u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F6u, 5u + 1u, 3u, cpu.address("absx", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F6 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B4F9;
L_82B4F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F9u, 6u, 3u, cpu.address("abs", 0xB47Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4F9 JSR -> $82B47D stack real
    { cpu.push16Value(hw,0xB4FBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4FCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB47Du), 0x82B4F9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B4FC;
L_82B4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4FCu,0x82B4FCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu, 5u + 1u, 3u, cpu.address("absx", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4FC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4FF;
L_82B4FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4FF TAX
    cpu.transfer("TAX");
    goto L_82B500;
L_82B500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB500u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB500u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B500 PLA
    cpu.pop("PLA", hw);
    goto L_82B501;
L_82B501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u, 6u, 3u, cpu.address("abs", 0xB800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B501 JSR -> $82B800 stack real
    { cpu.push16Value(hw,0xB503u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB504u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB800u), 0x82B501u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B504;
L_82B504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB504u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB504u,0x82B504u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB504u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB504u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B504 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B506;
L_82B506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB506u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB506u, 5u + 1u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B506 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C5Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B509;
L_82B509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u, 6u, 3u, cpu.address("absx", 0x1C54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B509 STA
    hw.write(cpu.address("absx", 0x1C54u), cpu.a, cpu.m8?8:16);
    goto L_82B50C;
L_82B50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B50C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B50Cu);return;} hw.unresolvedReturn(0x82B50Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B50D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B50D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B50F;
L_82B50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu, 5u + 1u, 3u, cpu.address("absx", 0x1C58u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B50F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C58u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B512;
L_82B512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B512 BEQ -> $82B4C4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B4C4; }
    goto L_82B514;
L_82B514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u, 9u, 3u, cpu.address("absx", 0x1C24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B514 DEC
    cpu.decMem(hw, cpu.address("absx", 0x1C24u), cpu.m8?8:16);
    goto L_82B517;
L_82B517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB517u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB517u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B517 BRA -> $82B4B4
    goto L_82B4B4;
L_82B594:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB594u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB594u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB594u, 3u, 3u, cpu.address("abs", 0xB4DFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B594 JMP -> $82B4DF
    goto L_82B4DF;
}

void sub_838D6B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x838D6Bu: goto L_838D6B;
    case 0x838D6Du: goto L_838D6D;
    case 0x838D70u: goto L_838D70;
    case 0x838D72u: goto L_838D72;
    case 0x838D76u: goto L_838D76;
    case 0x838D78u: goto L_838D78;
    case 0x838D7Au: goto L_838D7A;
    case 0x838D7Cu: goto L_838D7C;
    case 0x838D7Fu: goto L_838D7F;
    case 0x838D82u: goto L_838D82;
    case 0x838D83u: goto L_838D83;
    case 0x838D85u: goto L_838D85;
    case 0x838D88u: goto L_838D88;
    case 0x838D89u: goto L_838D89;
    case 0x838D8Au: goto L_838D8A;
    case 0x838D8Bu: goto L_838D8B;
    case 0x838D8Cu: goto L_838D8C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_838D6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D6B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D6D;
L_838D6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D6D CMP
    cpu.compareA(0x4u);
    goto L_838D70;
L_838D70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D70u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D70 BNE -> $838D8B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838D8B; }
    goto L_838D72;
L_838D72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D72u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D72u, 8u, 4u, 0x83CD3Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $838D72 JSL -> $83CD3C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8D75u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D76u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CD3Cu, 0x838D72u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838D76;
L_838D76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D76u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D76 BCC -> $838D89
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838D89; }
    goto L_838D78;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D76 BCC -> $838D89
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838D89; }
    goto L_838D78;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D76 BCC -> $838D89
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838D89; }
    goto L_838D78;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D76u,0x838D76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D78u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D78 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_838D7A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D78 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_838D7A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D78 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_838D7A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D78u,0x838D78u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D7C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D7C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D7C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D7Au,0x838D7Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7C ADC
    cpu.adc(0xFu);
    goto L_838D7F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7C ADC
    cpu.adc(0xFu);
    goto L_838D7F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7C ADC
    cpu.adc(0xFu);
    goto L_838D7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D7Cu,0x838D7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7F AND
    cpu.logicAnd(0xF0u);
    goto L_838D82;
L_838D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D82 SEC
    cpu.setFlag('C', true);
    goto L_838D83;
L_838D83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D83u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D83u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D83 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_838D85;
L_838D85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D85 CMP
    cpu.compareA(0x20u);
    goto L_838D88;
L_838D88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838D88 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838D88u);return;} hw.unresolvedReturn(0x838D88u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_838D89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D89u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D89 CLC
    cpu.setFlag('C', false);
    goto L_838D8A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D89 CLC
    cpu.setFlag('C', false);
    goto L_838D8A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D89 CLC
    cpu.setFlag('C', false);
    goto L_838D8A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D89u,0x838D89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838D8A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838D8Au);return;} hw.unresolvedReturn(0x838D8Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_838D8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D8B SEC
    cpu.setFlag('C', true);
    goto L_838D8C;
L_838D8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838D8C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838D8Cu);return;} hw.unresolvedReturn(0x838D8Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_838D6B_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x838D6Bu: goto L_838D6B;
    case 0x838D6Du: goto L_838D6D;
    case 0x838D70u: goto L_838D70;
    case 0x838D72u: goto L_838D72;
    case 0x838D76u: goto L_838D76;
    case 0x838D78u: goto L_838D78;
    case 0x838D7Au: goto L_838D7A;
    case 0x838D7Cu: goto L_838D7C;
    case 0x838D7Fu: goto L_838D7F;
    case 0x838D82u: goto L_838D82;
    case 0x838D83u: goto L_838D83;
    case 0x838D85u: goto L_838D85;
    case 0x838D88u: goto L_838D88;
    case 0x838D89u: goto L_838D89;
    case 0x838D8Au: goto L_838D8A;
    case 0x838D8Bu: goto L_838D8B;
    case 0x838D8Cu: goto L_838D8C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_838D6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D6B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D6D;
L_838D6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D6D CMP
    cpu.compareA(0x4u);
    goto L_838D70;
L_838D70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D70u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D70 BNE -> $838D8B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838D8B; }
    goto L_838D72;
L_838D72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D72u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D72u, 8u, 4u, 0x83CD3Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $838D72 JSL -> $83CD3C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8D75u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D76u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CD3Cu, 0x838D72u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838D76;
L_838D76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D76u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D76 BCC -> $838D89
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838D89; }
    goto L_838D78;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D76 BCC -> $838D89
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838D89; }
    goto L_838D78;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D76 BCC -> $838D89
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838D89; }
    goto L_838D78;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D76u,0x838D76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D78u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D78 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_838D7A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D78 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_838D7A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D78 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_838D7A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D78u,0x838D78u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D7C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D7C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D7C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D7Au,0x838D7Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7C ADC
    cpu.adc(0xFu);
    goto L_838D7F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7C ADC
    cpu.adc(0xFu);
    goto L_838D7F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7C ADC
    cpu.adc(0xFu);
    goto L_838D7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D7Cu,0x838D7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7F AND
    cpu.logicAnd(0xF0u);
    goto L_838D82;
L_838D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D82 SEC
    cpu.setFlag('C', true);
    goto L_838D83;
L_838D83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D83u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D83u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D83 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_838D85;
L_838D85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D85 CMP
    cpu.compareA(0x20u);
    goto L_838D88;
L_838D88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838D88 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838D88u);return;} hw.unresolvedReturn(0x838D88u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_838D89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D89u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D89 CLC
    cpu.setFlag('C', false);
    goto L_838D8A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D89 CLC
    cpu.setFlag('C', false);
    goto L_838D8A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D89 CLC
    cpu.setFlag('C', false);
    goto L_838D8A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D89u,0x838D89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838D8A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838D8Au);return;} hw.unresolvedReturn(0x838D8Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_838D8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D8B SEC
    cpu.setFlag('C', true);
    goto L_838D8C;
L_838D8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838D8C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838D8Cu);return;} hw.unresolvedReturn(0x838D8Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_838D6B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x838D6Bu: goto L_838D6B;
    case 0x838D6Du: goto L_838D6D;
    case 0x838D70u: goto L_838D70;
    case 0x838D72u: goto L_838D72;
    case 0x838D76u: goto L_838D76;
    case 0x838D78u: goto L_838D78;
    case 0x838D7Au: goto L_838D7A;
    case 0x838D7Cu: goto L_838D7C;
    case 0x838D7Fu: goto L_838D7F;
    case 0x838D82u: goto L_838D82;
    case 0x838D83u: goto L_838D83;
    case 0x838D85u: goto L_838D85;
    case 0x838D88u: goto L_838D88;
    case 0x838D89u: goto L_838D89;
    case 0x838D8Au: goto L_838D8A;
    case 0x838D8Bu: goto L_838D8B;
    case 0x838D8Cu: goto L_838D8C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_838D6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D6B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D6D;
L_838D6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D6D CMP
    cpu.compareA(0x4u);
    goto L_838D70;
L_838D70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D70u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D70 BNE -> $838D8B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_838D8B; }
    goto L_838D72;
L_838D72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D72u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D72u, 8u, 4u, 0x83CD3Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $838D72 JSL -> $83CD3C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8D75u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8D76u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CD3Cu, 0x838D72u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_838D76;
L_838D76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D76u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D76 BCC -> $838D89
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838D89; }
    goto L_838D78;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D76 BCC -> $838D89
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838D89; }
    goto L_838D78;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D76 BCC -> $838D89
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_838D89; }
    goto L_838D78;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D76u,0x838D76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D78u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D78 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_838D7A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D78 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_838D7A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D78 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_838D7A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D78u,0x838D78u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D7C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D7C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_838D7C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D7Au,0x838D7Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7C ADC
    cpu.adc(0xFu);
    goto L_838D7F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7C ADC
    cpu.adc(0xFu);
    goto L_838D7F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7C ADC
    cpu.adc(0xFu);
    goto L_838D7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D7Cu,0x838D7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D7F AND
    cpu.logicAnd(0xF0u);
    goto L_838D82;
L_838D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D82 SEC
    cpu.setFlag('C', true);
    goto L_838D83;
L_838D83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D83u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D83u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D83 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_838D85;
L_838D85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D85 CMP
    cpu.compareA(0x20u);
    goto L_838D88;
L_838D88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D88u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838D88 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838D88u);return;} hw.unresolvedReturn(0x838D88u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_838D89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D89u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D89 CLC
    cpu.setFlag('C', false);
    goto L_838D8A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D89 CLC
    cpu.setFlag('C', false);
    goto L_838D8A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D89 CLC
    cpu.setFlag('C', false);
    goto L_838D8A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D89u,0x838D89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_838D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838D8A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838D8Au);return;} hw.unresolvedReturn(0x838D8Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_838D8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $838D8B SEC
    cpu.setFlag('C', true);
    goto L_838D8C;
L_838D8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D8Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $838D8C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x838D8Cu);return;} hw.unresolvedReturn(0x838D8Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8396AC_E0M0X0C1_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8397FBu: goto L_8397FB;
    case 0x8397FDu: goto L_8397FD;
    case 0x8397FFu: goto L_8397FF;
    case 0x839802u: goto L_839802;
    case 0x839804u: goto L_839804;
    case 0x839806u: goto L_839806;
    case 0x839809u: goto L_839809;
    case 0x83980Cu: goto L_83980C;
    case 0x83980Eu: goto L_83980E;
    case 0x839811u: goto L_839811;
    case 0x839812u: goto L_839812;
    case 0x839814u: goto L_839814;
    case 0x839815u: goto L_839815;
    case 0x839816u: goto L_839816;
    case 0x839819u: goto L_839819;
    case 0x83981Bu: goto L_83981B;
    case 0x83981Eu: goto L_83981E;
    case 0x839821u: goto L_839821;
    case 0x839823u: goto L_839823;
    case 0x839825u: goto L_839825;
    case 0x839828u: goto L_839828;
    case 0x83982Au: goto L_83982A;
    case 0x83982Du: goto L_83982D;
    case 0x839830u: goto L_839830;
    case 0x839832u: goto L_839832;
    case 0x839835u: goto L_839835;
    case 0x839839u: goto L_839839;
    case 0x83983Bu: goto L_83983B;
    case 0x83983Du: goto L_83983D;
    case 0x83983Fu: goto L_83983F;
    case 0x839842u: goto L_839842;
    case 0x839844u: goto L_839844;
    case 0x839847u: goto L_839847;
    case 0x83984Au: goto L_83984A;
    case 0x83984Eu: goto L_83984E;
    case 0x839851u: goto L_839851;
    case 0x839854u: goto L_839854;
    case 0x839857u: goto L_839857;
    case 0x839860u: goto L_839860;
    case 0x839862u: goto L_839862;
    case 0x839864u: goto L_839864;
    case 0x839866u: goto L_839866;
    case 0x839868u: goto L_839868;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8397FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FBu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8397FB STA
    hw.write(cpu.address("dpx", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_8397FD;
L_8397FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8397FD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8397FF;
L_8397FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8397FF AND
    cpu.logicAnd(0xFF00u);
    goto L_839802;
L_839802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9802u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9802u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839802 STA
    hw.write(cpu.address("dpx", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_839804;
L_839804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9804u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9804u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9804u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839804 BRA -> $83979D
    hw.requestDispatch(0x83979Du,0x839804u); return;
L_839806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9806u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9806u, 6u, 3u, cpu.address("abs", 0x8968u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839806 JSR -> $838968 stack real
    { cpu.push16Value(hw,0x9808u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9809u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8968u), 0x839806u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839809;
L_839809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9809u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9809u,0x839809u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9809u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9809u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839809 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83980C;
L_83980C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83980C BPL -> $839812
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_839812; }
    goto L_83980E;
L_83980E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Eu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83980E EOR
    cpu.logicXor(0xFFFFu);
    goto L_839811;
L_839811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9811u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9811u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839811 INC
    cpu.inc('A');
    goto L_839812;
L_839812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9812u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9812u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839812 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_839814;
L_839814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9814u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9814u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9814u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839814 LSR
    cpu.lsrA();
    goto L_839815;
L_839815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9815u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9815u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839815 XBA
    cpu.xba();
    goto L_839816;
L_839816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9816u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9816u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839816 AND
    cpu.logicAnd(0xFFu);
    goto L_839819;
L_839819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9819u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9819u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9819u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839819 STA
    hw.write(cpu.address("dpx", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_83981B;
L_83981B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x981Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x981Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x981Bu, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83981B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83981E;
L_83981E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x981Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x981Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x981Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83981E CMP
    cpu.compareA(0x180u);
    goto L_839821;
L_839821:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9821u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9821u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9821u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839821 BCS -> $83983B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83983B; }
    goto L_839823;
L_839823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9823u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9823u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839823 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839825;
L_839825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9825u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9825u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9825u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839825 CMP
    cpu.compareA(0x6u);
    goto L_839828;
L_839828:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9828u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9828u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9828u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839828 BEQ -> $839832
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839832; }
    goto L_83982A;
L_83982A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x982Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x982Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x982Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83982A LDY
    cpu.setY(0x20u, 16);
    goto L_83982D;
L_83982D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x982Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x982Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x982Du, 6u, 3u, cpu.address("abs", 0x9CECu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83982D JSR -> $839CEC stack real
    { cpu.push16Value(hw,0x982Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9830u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CECu), 0x83982Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839830;
L_839830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9830u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9830u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9830u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839830 BRA -> $83984E
    goto L_83984E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9830u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9830u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839830 BRA -> $83984E
    goto L_83984E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9830u,0x839830u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9832u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9832u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839832 LDA
    cpu.setA(0x14u, 16);
    goto L_839835;
L_839835:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9835u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9835u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9835u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839835 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9838u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9839u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x839835u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839839;
L_839839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9839u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9839u,0x839839u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9839u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9839u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839839 BRA -> $83984E
    goto L_83984E;
L_83983B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x983Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x983Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x983Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83983B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83983D;
L_83983D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x983Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x983Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x983Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83983D BNE -> $83984E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83984E; }
    goto L_83983F;
L_83983F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x983Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x983Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x983Fu, 5u + 1u, 3u, cpu.address("absx", 0x10C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83983F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839842;
L_839842:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9842u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9842u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9842u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839842 BMI -> $83984E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83984E; }
    goto L_839844;
L_839844:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9844u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9844u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9844u, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839844 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839847;
L_839847:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9847u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9847u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9847u, 5u + 1u, 3u, cpu.address("absy", 0xD898u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839847 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD898u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83984A;
L_83984A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Au, 8u, 4u, 0x809508u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83984A JSL -> $809508 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x984Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x984Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809508u, 0x83984Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83984E;
L_83984E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83984E LDA
    cpu.setA(0xFFF8u, 16);
    goto L_839851;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83984E LDA
    cpu.setA(0xFFF8u, 16);
    goto L_839851;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83984E LDA
    cpu.setA(0xFFF8u, 16);
    goto L_839851;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x984Eu,0x83984Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9851u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u, 6u, 3u, cpu.address("absx", 0x10C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839851 STA
    hw.write(cpu.address("absx", 0x10C8u), cpu.a, cpu.m8?8:16);
    goto L_839854;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u, 6u, 3u, cpu.address("absx", 0x10C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839851 STA
    hw.write(cpu.address("absx", 0x10C8u), cpu.a, cpu.m8?8:16);
    goto L_839854;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u, 6u, 3u, cpu.address("absx", 0x10C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839851 STA
    hw.write(cpu.address("absx", 0x10C8u), cpu.a, cpu.m8?8:16);
    goto L_839854;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9851u,0x839851u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9854u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9854u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9854u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839854 LDA
    cpu.setA(0x0u, 16);
    goto L_839857;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9854u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9854u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839854 LDA
    cpu.setA(0x0u, 16);
    goto L_839857;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9854u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9854u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839854 LDA
    cpu.setA(0x0u, 16);
    goto L_839857;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9854u,0x839854u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9857u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9857u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9857u, 3u, 3u, cpu.address("abs", 0x97A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839857 JMP -> $8397A0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x97A0u),0x839857u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9857u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9857u, 3u, 3u, cpu.address("abs", 0x97A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839857 JMP -> $8397A0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x97A0u),0x839857u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9857u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9857u, 3u, 3u, cpu.address("abs", 0x97A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839857 JMP -> $8397A0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x97A0u),0x839857u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9857u,0x839857u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9860u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9860u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839860 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839862;
L_839862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9862u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9862u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839862 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_839864;
L_839864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9864u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9864u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9864u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839864 STZ
    hw.write(cpu.address("dpx", 0x20u), 0, cpu.m8?8:16);
    goto L_839866;
L_839866:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9866u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9866u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9866u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839866 STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_839868;
L_839868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9868u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9868u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839868 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839868u);return;} hw.unresolvedReturn(0x839868u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8396AC_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8397FBu: goto L_8397FB;
    case 0x8397FDu: goto L_8397FD;
    case 0x8397FFu: goto L_8397FF;
    case 0x839802u: goto L_839802;
    case 0x839804u: goto L_839804;
    case 0x839806u: goto L_839806;
    case 0x839809u: goto L_839809;
    case 0x83980Cu: goto L_83980C;
    case 0x83980Eu: goto L_83980E;
    case 0x839811u: goto L_839811;
    case 0x839812u: goto L_839812;
    case 0x839814u: goto L_839814;
    case 0x839815u: goto L_839815;
    case 0x839816u: goto L_839816;
    case 0x839819u: goto L_839819;
    case 0x83981Bu: goto L_83981B;
    case 0x83981Eu: goto L_83981E;
    case 0x839821u: goto L_839821;
    case 0x839823u: goto L_839823;
    case 0x839825u: goto L_839825;
    case 0x839828u: goto L_839828;
    case 0x83982Au: goto L_83982A;
    case 0x83982Du: goto L_83982D;
    case 0x839830u: goto L_839830;
    case 0x839832u: goto L_839832;
    case 0x839835u: goto L_839835;
    case 0x839839u: goto L_839839;
    case 0x83983Bu: goto L_83983B;
    case 0x83983Du: goto L_83983D;
    case 0x83983Fu: goto L_83983F;
    case 0x839842u: goto L_839842;
    case 0x839844u: goto L_839844;
    case 0x839847u: goto L_839847;
    case 0x83984Au: goto L_83984A;
    case 0x83984Eu: goto L_83984E;
    case 0x839851u: goto L_839851;
    case 0x839854u: goto L_839854;
    case 0x839857u: goto L_839857;
    case 0x839860u: goto L_839860;
    case 0x839862u: goto L_839862;
    case 0x839864u: goto L_839864;
    case 0x839866u: goto L_839866;
    case 0x839868u: goto L_839868;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8397FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FBu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8397FB STA
    hw.write(cpu.address("dpx", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_8397FD;
L_8397FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8397FD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8397FF;
L_8397FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x97FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x97FFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x97FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8397FF AND
    cpu.logicAnd(0xFF00u);
    goto L_839802;
L_839802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9802u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9802u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839802 STA
    hw.write(cpu.address("dpx", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_839804;
L_839804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9804u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9804u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9804u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839804 BRA -> $83979D
    hw.requestDispatch(0x83979Du,0x839804u); return;
L_839806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9806u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9806u, 6u, 3u, cpu.address("abs", 0x8968u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839806 JSR -> $838968 stack real
    { cpu.push16Value(hw,0x9808u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9809u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8968u), 0x839806u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839809;
L_839809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9809u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9809u,0x839809u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9809u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9809u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839809 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83980C;
L_83980C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83980C BPL -> $839812
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_839812; }
    goto L_83980E;
L_83980E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Eu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83980E EOR
    cpu.logicXor(0xFFFFu);
    goto L_839811;
L_839811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9811u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9811u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839811 INC
    cpu.inc('A');
    goto L_839812;
L_839812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9812u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9812u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839812 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_839814;
L_839814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9814u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9814u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9814u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839814 LSR
    cpu.lsrA();
    goto L_839815;
L_839815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9815u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9815u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839815 XBA
    cpu.xba();
    goto L_839816;
L_839816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9816u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9816u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839816 AND
    cpu.logicAnd(0xFFu);
    goto L_839819;
L_839819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9819u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9819u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9819u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839819 STA
    hw.write(cpu.address("dpx", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_83981B;
L_83981B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x981Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x981Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x981Bu, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83981B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83981E;
L_83981E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x981Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x981Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x981Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83981E CMP
    cpu.compareA(0x180u);
    goto L_839821;
L_839821:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9821u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9821u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9821u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839821 BCS -> $83983B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83983B; }
    goto L_839823;
L_839823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9823u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9823u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839823 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839825;
L_839825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9825u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9825u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9825u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839825 CMP
    cpu.compareA(0x6u);
    goto L_839828;
L_839828:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9828u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9828u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9828u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839828 BEQ -> $839832
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839832; }
    goto L_83982A;
L_83982A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x982Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x982Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x982Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83982A LDY
    cpu.setY(0x20u, 16);
    goto L_83982D;
L_83982D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x982Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x982Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x982Du, 6u, 3u, cpu.address("abs", 0x9CECu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83982D JSR -> $839CEC stack real
    { cpu.push16Value(hw,0x982Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9830u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CECu), 0x83982Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839830;
L_839830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9830u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9830u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9830u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839830 BRA -> $83984E
    goto L_83984E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9830u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9830u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839830 BRA -> $83984E
    goto L_83984E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9830u,0x839830u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9832u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9832u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839832 LDA
    cpu.setA(0x14u, 16);
    goto L_839835;
L_839835:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9835u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9835u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9835u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839835 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9838u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9839u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x839835u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839839;
L_839839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9839u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9839u,0x839839u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9839u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9839u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839839 BRA -> $83984E
    goto L_83984E;
L_83983B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x983Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x983Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x983Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83983B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83983D;
L_83983D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x983Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x983Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x983Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83983D BNE -> $83984E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83984E; }
    goto L_83983F;
L_83983F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x983Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x983Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x983Fu, 5u + 1u, 3u, cpu.address("absx", 0x10C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83983F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839842;
L_839842:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9842u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9842u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9842u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839842 BMI -> $83984E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83984E; }
    goto L_839844;
L_839844:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9844u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9844u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9844u, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839844 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839847;
L_839847:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9847u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9847u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9847u, 5u + 1u, 3u, cpu.address("absy", 0xD898u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839847 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD898u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83984A;
L_83984A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Au, 8u, 4u, 0x809508u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83984A JSL -> $809508 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x984Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x984Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809508u, 0x83984Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83984E;
L_83984E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83984E LDA
    cpu.setA(0xFFF8u, 16);
    goto L_839851;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83984E LDA
    cpu.setA(0xFFF8u, 16);
    goto L_839851;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83984E LDA
    cpu.setA(0xFFF8u, 16);
    goto L_839851;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x984Eu,0x83984Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9851u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u, 6u, 3u, cpu.address("absx", 0x10C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839851 STA
    hw.write(cpu.address("absx", 0x10C8u), cpu.a, cpu.m8?8:16);
    goto L_839854;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u, 6u, 3u, cpu.address("absx", 0x10C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839851 STA
    hw.write(cpu.address("absx", 0x10C8u), cpu.a, cpu.m8?8:16);
    goto L_839854;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u, 6u, 3u, cpu.address("absx", 0x10C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839851 STA
    hw.write(cpu.address("absx", 0x10C8u), cpu.a, cpu.m8?8:16);
    goto L_839854;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9851u,0x839851u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9854u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9854u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9854u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839854 LDA
    cpu.setA(0x0u, 16);
    goto L_839857;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9854u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9854u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839854 LDA
    cpu.setA(0x0u, 16);
    goto L_839857;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9854u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9854u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839854 LDA
    cpu.setA(0x0u, 16);
    goto L_839857;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9854u,0x839854u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9857u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9857u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9857u, 3u, 3u, cpu.address("abs", 0x97A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839857 JMP -> $8397A0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x97A0u),0x839857u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9857u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9857u, 3u, 3u, cpu.address("abs", 0x97A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839857 JMP -> $8397A0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x97A0u),0x839857u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9857u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9857u, 3u, 3u, cpu.address("abs", 0x97A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839857 JMP -> $8397A0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x97A0u),0x839857u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9857u,0x839857u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9860u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9860u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839860 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839862;
L_839862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9862u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9862u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839862 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_839864;
L_839864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9864u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9864u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9864u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839864 STZ
    hw.write(cpu.address("dpx", 0x20u), 0, cpu.m8?8:16);
    goto L_839866;
L_839866:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9866u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9866u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9866u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839866 STZ
    hw.write(cpu.address("dpx", 0x1Eu), 0, cpu.m8?8:16);
    goto L_839868;
L_839868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9868u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9868u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839868 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839868u);return;} hw.unresolvedReturn(0x839868u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83A714_E0M0X0C0_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A600u: goto L_83A600;
    case 0x83A603u: goto L_83A603;
    case 0x83A605u: goto L_83A605;
    case 0x83A608u: goto L_83A608;
    case 0x83A609u: goto L_83A609;
    case 0x83A60Au: goto L_83A60A;
    case 0x83A60Bu: goto L_83A60B;
    case 0x83A60Eu: goto L_83A60E;
    case 0x83A610u: goto L_83A610;
    case 0x83A613u: goto L_83A613;
    case 0x83A616u: goto L_83A616;
    case 0x83A619u: goto L_83A619;
    case 0x83A61Bu: goto L_83A61B;
    case 0x83A61Eu: goto L_83A61E;
    case 0x83A61Fu: goto L_83A61F;
    case 0x83A620u: goto L_83A620;
    case 0x83A621u: goto L_83A621;
    case 0x83A622u: goto L_83A622;
    case 0x83A625u: goto L_83A625;
    case 0x83A626u: goto L_83A626;
    case 0x83A629u: goto L_83A629;
    case 0x83A62Bu: goto L_83A62B;
    case 0x83A62Eu: goto L_83A62E;
    case 0x83A630u: goto L_83A630;
    case 0x83A632u: goto L_83A632;
    case 0x83A634u: goto L_83A634;
    case 0x83A638u: goto L_83A638;
    case 0x83A63Au: goto L_83A63A;
    case 0x83A63Cu: goto L_83A63C;
    case 0x83A63Fu: goto L_83A63F;
    case 0x83A641u: goto L_83A641;
    case 0x83A643u: goto L_83A643;
    case 0x83A646u: goto L_83A646;
    case 0x83A649u: goto L_83A649;
    case 0x83A64Bu: goto L_83A64B;
    case 0x83A64Eu: goto L_83A64E;
    case 0x83A650u: goto L_83A650;
    case 0x83A652u: goto L_83A652;
    case 0x83A654u: goto L_83A654;
    case 0x83A656u: goto L_83A656;
    case 0x83A658u: goto L_83A658;
    case 0x83A65Bu: goto L_83A65B;
    case 0x83A65Cu: goto L_83A65C;
    case 0x83A65Eu: goto L_83A65E;
    case 0x83A660u: goto L_83A660;
    case 0x83A663u: goto L_83A663;
    case 0x83A665u: goto L_83A665;
    case 0x83A667u: goto L_83A667;
    case 0x83A669u: goto L_83A669;
    case 0x83A66Au: goto L_83A66A;
    case 0x83A66Du: goto L_83A66D;
    case 0x83A66Fu: goto L_83A66F;
    case 0x83A671u: goto L_83A671;
    case 0x83A673u: goto L_83A673;
    case 0x83A676u: goto L_83A676;
    case 0x83A678u: goto L_83A678;
    case 0x83A67Au: goto L_83A67A;
    case 0x83A67Cu: goto L_83A67C;
    case 0x83A67Eu: goto L_83A67E;
    case 0x83A682u: goto L_83A682;
    case 0x83A684u: goto L_83A684;
    case 0x83A686u: goto L_83A686;
    case 0x83A689u: goto L_83A689;
    case 0x83A68Bu: goto L_83A68B;
    case 0x83A68Du: goto L_83A68D;
    case 0x83A690u: goto L_83A690;
    case 0x83A693u: goto L_83A693;
    case 0x83A695u: goto L_83A695;
    case 0x83A697u: goto L_83A697;
    case 0x83A699u: goto L_83A699;
    case 0x83A69Bu: goto L_83A69B;
    case 0x83A69Du: goto L_83A69D;
    case 0x83A6A0u: goto L_83A6A0;
    case 0x83A6A1u: goto L_83A6A1;
    case 0x83A6A3u: goto L_83A6A3;
    case 0x83A6A5u: goto L_83A6A5;
    case 0x83A6A8u: goto L_83A6A8;
    case 0x83A6AAu: goto L_83A6AA;
    case 0x83A6ACu: goto L_83A6AC;
    case 0x83A6AEu: goto L_83A6AE;
    case 0x83A6AFu: goto L_83A6AF;
    case 0x83A6B2u: goto L_83A6B2;
    case 0x83A6B4u: goto L_83A6B4;
    case 0x83A6B6u: goto L_83A6B6;
    case 0x83A6B8u: goto L_83A6B8;
    case 0x83A6BBu: goto L_83A6BB;
    case 0x83A6BDu: goto L_83A6BD;
    case 0x83A6BFu: goto L_83A6BF;
    case 0x83A6C2u: goto L_83A6C2;
    case 0x83A6C3u: goto L_83A6C3;
    case 0x83A6C5u: goto L_83A6C5;
    case 0x83A6C7u: goto L_83A6C7;
    case 0x83A6CAu: goto L_83A6CA;
    case 0x83A6CCu: goto L_83A6CC;
    case 0x83A6CFu: goto L_83A6CF;
    case 0x83A6D1u: goto L_83A6D1;
    case 0x83A6D3u: goto L_83A6D3;
    case 0x83A6D4u: goto L_83A6D4;
    case 0x83A6D5u: goto L_83A6D5;
    case 0x83A6D7u: goto L_83A6D7;
    case 0x83A6D9u: goto L_83A6D9;
    case 0x83A6DAu: goto L_83A6DA;
    case 0x83A6DBu: goto L_83A6DB;
    case 0x83A6DDu: goto L_83A6DD;
    case 0x83A6DFu: goto L_83A6DF;
    case 0x83A6E0u: goto L_83A6E0;
    case 0x83A6E2u: goto L_83A6E2;
    case 0x83A6E4u: goto L_83A6E4;
    case 0x83A6E5u: goto L_83A6E5;
    case 0x83A6E7u: goto L_83A6E7;
    case 0x83A6E9u: goto L_83A6E9;
    case 0x83A6EBu: goto L_83A6EB;
    case 0x83A6EDu: goto L_83A6ED;
    case 0x83A6EFu: goto L_83A6EF;
    case 0x83A6F1u: goto L_83A6F1;
    case 0x83A6F3u: goto L_83A6F3;
    case 0x83A6F5u: goto L_83A6F5;
    case 0x83A6F6u: goto L_83A6F6;
    case 0x83A6F7u: goto L_83A6F7;
    case 0x83A6F9u: goto L_83A6F9;
    case 0x83A6FBu: goto L_83A6FB;
    case 0x83A6FCu: goto L_83A6FC;
    case 0x83A6FDu: goto L_83A6FD;
    case 0x83A6FFu: goto L_83A6FF;
    case 0x83A701u: goto L_83A701;
    case 0x83A702u: goto L_83A702;
    case 0x83A704u: goto L_83A704;
    case 0x83A706u: goto L_83A706;
    case 0x83A707u: goto L_83A707;
    case 0x83A709u: goto L_83A709;
    case 0x83A70Bu: goto L_83A70B;
    case 0x83A70Du: goto L_83A70D;
    case 0x83A70Fu: goto L_83A70F;
    case 0x83A711u: goto L_83A711;
    case 0x83A713u: goto L_83A713;
    case 0x83A714u: goto L_83A714;
    case 0x83A717u: goto L_83A717;
    case 0x83A718u: goto L_83A718;
    case 0x83A71Au: goto L_83A71A;
    case 0x83A71Cu: goto L_83A71C;
    case 0x83A71Eu: goto L_83A71E;
    case 0x83A720u: goto L_83A720;
    case 0x83A721u: goto L_83A721;
    case 0x83A722u: goto L_83A722;
    case 0x83A724u: goto L_83A724;
    case 0x83A726u: goto L_83A726;
    case 0x83A728u: goto L_83A728;
    case 0x83A72Au: goto L_83A72A;
    case 0x83A72Du: goto L_83A72D;
    case 0x83A731u: goto L_83A731;
    case 0x83A734u: goto L_83A734;
    case 0x83A736u: goto L_83A736;
    case 0x83A739u: goto L_83A739;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA600u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA600u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A600 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A603;
L_83A603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA603u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA603u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A603 BPL -> $83A609
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A609; }
    goto L_83A605;
L_83A605:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA605u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA605u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA605u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A605 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A608;
L_83A608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA608u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA608u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A608 INC
    cpu.inc('A');
    goto L_83A609;
L_83A609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA609u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA609u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A609 ASL
    cpu.aslA();
    goto L_83A60A;
L_83A60A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Au,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A60A XBA
    cpu.xba();
    goto L_83A60B;
L_83A60B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A60B AND
    cpu.logicAnd(0xFFu);
    goto L_83A60E;
L_83A60E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A60E STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_83A610;
L_83A610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA610u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA610u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A610 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A613;
L_83A613:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA613u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA613u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA613u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A613 AND
    cpu.logicAnd(0xF0u);
    goto L_83A616;
L_83A616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA616u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA616u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A616 BIT
    cpu.bit(0x80u, true);
    goto L_83A619;
L_83A619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A619 BEQ -> $83A61F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A61F; }
    goto L_83A61B;
L_83A61B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A61B EOR
    cpu.logicXor(0x7Fu);
    goto L_83A61E;
L_83A61E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Eu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A61E INC
    cpu.inc('A');
    goto L_83A61F;
L_83A61F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A61F LSR
    cpu.lsrA();
    goto L_83A620;
L_83A620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA620u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA620u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A620 LSR
    cpu.lsrA();
    goto L_83A621;
L_83A621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA621u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA621u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A621 LSR
    cpu.lsrA();
    goto L_83A622;
L_83A622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA622u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA622u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A622 AND
    cpu.logicAnd(0xEu);
    goto L_83A625;
L_83A625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A625 TAY
    cpu.transfer("TAY");
    goto L_83A626;
L_83A626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA626u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA626u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA626u, 5u + 1u, 3u, cpu.address("absy", 0xF974u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A626 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF974u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A629;
L_83A629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA629u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA629u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A629 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_83A62B;
L_83A62B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Bu, 5u + 1u, 3u, cpu.address("absy", 0xF97Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A62B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF97Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A62E;
L_83A62E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A62E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A630;
L_83A630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA630u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA630u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A630 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A632;
L_83A632:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA632u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA632u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA632u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A632 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A634;
L_83A634:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA634u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA634u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA634u, 8u, 4u, 0x808D32u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A634 JSL -> $808D32 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA637u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA638u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D32u, 0x83A634u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A638;
L_83A638:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA638u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA638u,0x83A638u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA638u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA638u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A638 STY
    hw.write(cpu.address("dp", 0xAu), cpu.y, cpu.x8?8:16);
    goto L_83A63A;
L_83A63A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A63A STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_83A63C;
L_83A63C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Cu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A63C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1090u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A63F;
L_83A63F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A63F BPL -> $83A643
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A643; }
    goto L_83A641;
L_83A641:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA641u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA641u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA641u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A641 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A643;
L_83A643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA643u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA643u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA643u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A643 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1098u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A646;
L_83A646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA646u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA646u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA646u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A646 CPY
    cpu.compareY(0xC0u);
    goto L_83A649;
L_83A649:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA649u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA649u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA649u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A649 BCS -> $83A652
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A652; }
    goto L_83A64B;
L_83A64B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A64B CPY
    cpu.compareY(0x40u);
    goto L_83A64E;
L_83A64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A64E BCC -> $83A652
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A652; }
    goto L_83A650;
L_83A650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA650u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA650u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A650 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A652;
L_83A652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A652 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A654;
L_83A654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA654u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA654u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A654 BCC -> $83A669
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A669; }
    goto L_83A656;
L_83A656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA656u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA656u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA656u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A656 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A658;
L_83A658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA658u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA658u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A658 LDA
    cpu.setA(0x0u, 16);
    goto L_83A65B;
L_83A65B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A65B SEC
    cpu.setFlag('C', true);
    goto L_83A65C;
L_83A65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Cu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A65C SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A65E;
L_83A65E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A65E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A660;
L_83A660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A660 LDA
    cpu.setA(0x0u, 16);
    goto L_83A663;
L_83A663:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA663u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA663u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA663u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A663 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83A665;
L_83A665:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA665u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA665u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA665u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A665 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A667;
L_83A667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA667u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A667 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A669;
L_83A669:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA669u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA669u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA669u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A669 CLC
    cpu.setFlag('C', false);
    goto L_83A66A;
L_83A66A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Au,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Au, 5u, 3u, cpu.address("abs", 0x1BD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A66A ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BD4u), cpu.m8?8:16));
    goto L_83A66D;
L_83A66D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A66D STA
    hw.write(cpu.address("dpx", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_83A66F;
L_83A66F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A66F STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_83A671;
L_83A671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA671u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA671u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A671 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A673;
L_83A673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA673u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA673u, 5u, 3u, cpu.address("abs", 0x1BD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A673 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BD2u), cpu.m8?8:16));
    goto L_83A676;
L_83A676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA676u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA676u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A676 STA
    hw.write(cpu.address("dpx", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_83A678;
L_83A678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A678 STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_83A67A;
L_83A67A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Au,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A67A LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A67C;
L_83A67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A67C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A67E;
L_83A67E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu, 8u, 4u, 0x808D32u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A67E JSL -> $808D32 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA681u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA682u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D32u, 0x83A67Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A682;
L_83A682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA682u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA682u,0x83A682u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA682u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA682u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A682 STY
    hw.write(cpu.address("dp", 0xAu), cpu.y, cpu.x8?8:16);
    goto L_83A684;
L_83A684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A684 STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_83A686;
L_83A686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA686u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA686u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A686 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1090u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A689;
L_83A689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A689 BPL -> $83A68D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A68D; }
    goto L_83A68B;
L_83A68B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A68B INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A68D;
L_83A68D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Du,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Du, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A68D LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1098u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A690;
L_83A690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA690u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA690u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A690 CPY
    cpu.compareY(0x80u);
    goto L_83A693;
L_83A693:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA693u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA693u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA693u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A693 BCC -> $83A697
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A697; }
    goto L_83A695;
L_83A695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA695u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA695u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A695 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A697;
L_83A697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A697 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A699;
L_83A699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A699 BCC -> $83A6AE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A6AE; }
    goto L_83A69B;
L_83A69B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A69B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A69D;
L_83A69D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A69D LDA
    cpu.setA(0x0u, 16);
    goto L_83A6A0;
L_83A6A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A0 SEC
    cpu.setFlag('C', true);
    goto L_83A6A1;
L_83A6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A1 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A6A3;
L_83A6A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A3 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A6A5;
L_83A6A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A5 LDA
    cpu.setA(0x0u, 16);
    goto L_83A6A8;
L_83A6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A8 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83A6AA;
L_83A6AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6AA STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A6AC;
L_83A6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6AE;
L_83A6AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6AE CLC
    cpu.setFlag('C', false);
    goto L_83A6AF;
L_83A6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AFu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AFu, 5u, 3u, cpu.address("abs", 0x1BD8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6AF ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BD8u), cpu.m8?8:16));
    goto L_83A6B2;
L_83A6B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6B2 STA
    hw.write(cpu.address("dpx", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_83A6B4;
L_83A6B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6B4 STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_83A6B6;
L_83A6B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6B6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6B8;
L_83A6B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B8u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B8u, 5u, 3u, cpu.address("abs", 0x1BD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6B8 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BD6u), cpu.m8?8:16));
    goto L_83A6BB;
L_83A6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BBu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6BB STA
    hw.write(cpu.address("dpx", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_83A6BD;
L_83A6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6BD STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_83A6BF;
L_83A6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu, 5u + 1u, 3u, cpu.address("absx", 0x0024u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6BF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6C2;
L_83A6C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6C2 LSR
    cpu.lsrA();
    goto L_83A6C3;
L_83A6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6C3 BNE -> $83A713
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A713; }
    goto L_83A6C5;
L_83A6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6C5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6C7;
L_83A6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6C7 CMP
    cpu.compareA(0x8u);
    goto L_83A6CA;
L_83A6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6CA BCC -> $83A713
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A713; }
    goto L_83A6CC;
L_83A6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6CC AND
    cpu.logicAnd(0x1u);
    goto L_83A6CF;
L_83A6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6CF BNE -> $83A6F3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A6F3; }
    goto L_83A6D1;
L_83A6D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6D1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6D3;
L_83A6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6D3 ASL
    cpu.aslA();
    goto L_83A6D4;
L_83A6D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D4u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6D4 PHP
    cpu.push("PHP", hw);
    goto L_83A6D5;
L_83A6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D5u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6D5 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x18u), cpu.m8?8:16);
    goto L_83A6D7;
L_83A6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D7u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6D7 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_83A6D9;
L_83A6D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D9u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6D9 PLP
    cpu.pop("PLP", hw);
    goto L_83A6DA;
L_83A6DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6DAu,0x83A6DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DAu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6DA PHP
    cpu.push("PHP", hw);
    goto L_83A6DB;
L_83A6DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DBu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6DB ROR
    cpu.rorMem(hw, cpu.address("dp", 0x18u), cpu.m8?8:16);
    goto L_83A6DD;
L_83A6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DDu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6DD ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_83A6DF;
L_83A6DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DFu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6DF PLP
    cpu.pop("PLP", hw);
    goto L_83A6E0;
L_83A6E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6E0u,0x83A6E0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E0u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E0 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x18u), cpu.m8?8:16);
    goto L_83A6E2;
L_83A6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E2u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E2 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_83A6E4;
L_83A6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E4 SEC
    cpu.setFlag('C', true);
    goto L_83A6E5;
L_83A6E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6E7;
L_83A6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_83A6E9;
L_83A6E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E9u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E9 STA
    hw.write(cpu.address("dpx", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_83A6EB;
L_83A6EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6EB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6ED;
L_83A6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6ED SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16));
    goto L_83A6EF;
L_83A6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6EF STA
    hw.write(cpu.address("dpx", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_83A6F1;
L_83A6F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F1 BRA -> $83A713
    goto L_83A713;
L_83A6F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6F5;
L_83A6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F5 ASL
    cpu.aslA();
    goto L_83A6F6;
L_83A6F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F6u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6F6 PHP
    cpu.push("PHP", hw);
    goto L_83A6F7;
L_83A6F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F7u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F7 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_83A6F9;
L_83A6F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F9u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F9 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_83A6FB;
L_83A6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6FB PLP
    cpu.pop("PLP", hw);
    goto L_83A6FC;
L_83A6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6FCu,0x83A6FCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6FC PHP
    cpu.push("PHP", hw);
    goto L_83A6FD;
L_83A6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6FD ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_83A6FF;
L_83A6FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6FF ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_83A701;
L_83A701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA701u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA701u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A701 PLP
    cpu.pop("PLP", hw);
    goto L_83A702;
L_83A702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA702u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA702u,0x83A702u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA702u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA702u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A702 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_83A704;
L_83A704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA704u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA704u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A704 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_83A706;
L_83A706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA706u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA706u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA706u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A706 SEC
    cpu.setFlag('C', true);
    goto L_83A707;
L_83A707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A707 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A709;
L_83A709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A709 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16));
    goto L_83A70B;
L_83A70B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A70B STA
    hw.write(cpu.address("dpx", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_83A70D;
L_83A70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A70D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A70F;
L_83A70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A70F SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_83A711;
L_83A711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A711 STA
    hw.write(cpu.address("dpx", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_83A713;
L_83A713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA713u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A713 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A713u);return;} hw.unresolvedReturn(0x83A713u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A713 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A713u);return;} hw.unresolvedReturn(0x83A713u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA713u,0x83A713u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA714u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA714u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA714u, 5u, 3u, cpu.address("abs", 0x1BA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A714 STZ
    hw.write(cpu.address("abs", 0x1BA4u), 0, cpu.m8?8:16);
    goto L_83A717;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA714u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA714u, 5u, 3u, cpu.address("abs", 0x1BA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A714 STZ
    hw.write(cpu.address("abs", 0x1BA4u), 0, cpu.m8?8:16);
    goto L_83A717;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA714u,0x83A714u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA717u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A717 CLC
    cpu.setFlag('C', false);
    goto L_83A718;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A717 CLC
    cpu.setFlag('C', false);
    goto L_83A718;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA717u,0x83A717u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA718u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA718u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A718 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A71A;
L_83A71A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Au,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A71A ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xCu), cpu.m8?8:16));
    goto L_83A71C;
L_83A71C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A71C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A71E;
L_83A71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A71E ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83A720;
L_83A720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA720u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA720u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A720 TAY
    cpu.transfer("TAY");
    goto L_83A721;
L_83A721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A721 CLC
    cpu.setFlag('C', false);
    goto L_83A722;
L_83A722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA722u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA722u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A722 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A724;
L_83A724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA724u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA724u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A724 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16));
    goto L_83A726;
L_83A726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA726u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA726u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A726 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A728;
L_83A728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA728u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA728u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A728 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83A72A;
L_83A72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Au, 5u, 3u, cpu.address("abs", 0x1BA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A72A STA
    hw.write(cpu.address("abs", 0x1BA2u), cpu.a, cpu.m8?8:16);
    goto L_83A72D;
L_83A72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Du, 8u, 4u, 0x848914u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A72D JSL -> $848914 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA730u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA731u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848914u, 0x83A72Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A731;
L_83A731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA731u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA731u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA731u, 6u, 3u, cpu.address("abs", 0xA8E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A731 JSR -> $83A8E4 stack real
    { cpu.push16Value(hw,0xA733u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA734u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA8E4u), 0x83A731u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A734;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA731u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA731u, 6u, 3u, cpu.address("abs", 0xA8E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A731 JSR -> $83A8E4 stack real
    { cpu.push16Value(hw,0xA733u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA734u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA8E4u), 0x83A731u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A734;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA731u,0x83A731u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA734u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA734u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA734u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A734 BCC -> $83A713
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A713; }
    goto L_83A736;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA734u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA734u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A734 BCC -> $83A713
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A713; }
    goto L_83A736;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA734u,0x83A734u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA736u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA736u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA736u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A736 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A739;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA736u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA736u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A736 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A739;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA736u,0x83A736u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA739u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA739u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA739u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A739 BPL -> $83A76B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83A76Bu,0x83A739u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA73Bu,0x83A739u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA739u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA739u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A739 BPL -> $83A76B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83A76Bu,0x83A739u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA73Bu,0x83A739u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA739u,0x83A739u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_83A714_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A600u: goto L_83A600;
    case 0x83A603u: goto L_83A603;
    case 0x83A605u: goto L_83A605;
    case 0x83A608u: goto L_83A608;
    case 0x83A609u: goto L_83A609;
    case 0x83A60Au: goto L_83A60A;
    case 0x83A60Bu: goto L_83A60B;
    case 0x83A60Eu: goto L_83A60E;
    case 0x83A610u: goto L_83A610;
    case 0x83A613u: goto L_83A613;
    case 0x83A616u: goto L_83A616;
    case 0x83A619u: goto L_83A619;
    case 0x83A61Bu: goto L_83A61B;
    case 0x83A61Eu: goto L_83A61E;
    case 0x83A61Fu: goto L_83A61F;
    case 0x83A620u: goto L_83A620;
    case 0x83A621u: goto L_83A621;
    case 0x83A622u: goto L_83A622;
    case 0x83A625u: goto L_83A625;
    case 0x83A626u: goto L_83A626;
    case 0x83A629u: goto L_83A629;
    case 0x83A62Bu: goto L_83A62B;
    case 0x83A62Eu: goto L_83A62E;
    case 0x83A630u: goto L_83A630;
    case 0x83A632u: goto L_83A632;
    case 0x83A634u: goto L_83A634;
    case 0x83A638u: goto L_83A638;
    case 0x83A63Au: goto L_83A63A;
    case 0x83A63Cu: goto L_83A63C;
    case 0x83A63Fu: goto L_83A63F;
    case 0x83A641u: goto L_83A641;
    case 0x83A643u: goto L_83A643;
    case 0x83A646u: goto L_83A646;
    case 0x83A649u: goto L_83A649;
    case 0x83A64Bu: goto L_83A64B;
    case 0x83A64Eu: goto L_83A64E;
    case 0x83A650u: goto L_83A650;
    case 0x83A652u: goto L_83A652;
    case 0x83A654u: goto L_83A654;
    case 0x83A656u: goto L_83A656;
    case 0x83A658u: goto L_83A658;
    case 0x83A65Bu: goto L_83A65B;
    case 0x83A65Cu: goto L_83A65C;
    case 0x83A65Eu: goto L_83A65E;
    case 0x83A660u: goto L_83A660;
    case 0x83A663u: goto L_83A663;
    case 0x83A665u: goto L_83A665;
    case 0x83A667u: goto L_83A667;
    case 0x83A669u: goto L_83A669;
    case 0x83A66Au: goto L_83A66A;
    case 0x83A66Du: goto L_83A66D;
    case 0x83A66Fu: goto L_83A66F;
    case 0x83A671u: goto L_83A671;
    case 0x83A673u: goto L_83A673;
    case 0x83A676u: goto L_83A676;
    case 0x83A678u: goto L_83A678;
    case 0x83A67Au: goto L_83A67A;
    case 0x83A67Cu: goto L_83A67C;
    case 0x83A67Eu: goto L_83A67E;
    case 0x83A682u: goto L_83A682;
    case 0x83A684u: goto L_83A684;
    case 0x83A686u: goto L_83A686;
    case 0x83A689u: goto L_83A689;
    case 0x83A68Bu: goto L_83A68B;
    case 0x83A68Du: goto L_83A68D;
    case 0x83A690u: goto L_83A690;
    case 0x83A693u: goto L_83A693;
    case 0x83A695u: goto L_83A695;
    case 0x83A697u: goto L_83A697;
    case 0x83A699u: goto L_83A699;
    case 0x83A69Bu: goto L_83A69B;
    case 0x83A69Du: goto L_83A69D;
    case 0x83A6A0u: goto L_83A6A0;
    case 0x83A6A1u: goto L_83A6A1;
    case 0x83A6A3u: goto L_83A6A3;
    case 0x83A6A5u: goto L_83A6A5;
    case 0x83A6A8u: goto L_83A6A8;
    case 0x83A6AAu: goto L_83A6AA;
    case 0x83A6ACu: goto L_83A6AC;
    case 0x83A6AEu: goto L_83A6AE;
    case 0x83A6AFu: goto L_83A6AF;
    case 0x83A6B2u: goto L_83A6B2;
    case 0x83A6B4u: goto L_83A6B4;
    case 0x83A6B6u: goto L_83A6B6;
    case 0x83A6B8u: goto L_83A6B8;
    case 0x83A6BBu: goto L_83A6BB;
    case 0x83A6BDu: goto L_83A6BD;
    case 0x83A6BFu: goto L_83A6BF;
    case 0x83A6C2u: goto L_83A6C2;
    case 0x83A6C3u: goto L_83A6C3;
    case 0x83A6C5u: goto L_83A6C5;
    case 0x83A6C7u: goto L_83A6C7;
    case 0x83A6CAu: goto L_83A6CA;
    case 0x83A6CCu: goto L_83A6CC;
    case 0x83A6CFu: goto L_83A6CF;
    case 0x83A6D1u: goto L_83A6D1;
    case 0x83A6D3u: goto L_83A6D3;
    case 0x83A6D4u: goto L_83A6D4;
    case 0x83A6D5u: goto L_83A6D5;
    case 0x83A6D7u: goto L_83A6D7;
    case 0x83A6D9u: goto L_83A6D9;
    case 0x83A6DAu: goto L_83A6DA;
    case 0x83A6DBu: goto L_83A6DB;
    case 0x83A6DDu: goto L_83A6DD;
    case 0x83A6DFu: goto L_83A6DF;
    case 0x83A6E0u: goto L_83A6E0;
    case 0x83A6E2u: goto L_83A6E2;
    case 0x83A6E4u: goto L_83A6E4;
    case 0x83A6E5u: goto L_83A6E5;
    case 0x83A6E7u: goto L_83A6E7;
    case 0x83A6E9u: goto L_83A6E9;
    case 0x83A6EBu: goto L_83A6EB;
    case 0x83A6EDu: goto L_83A6ED;
    case 0x83A6EFu: goto L_83A6EF;
    case 0x83A6F1u: goto L_83A6F1;
    case 0x83A6F3u: goto L_83A6F3;
    case 0x83A6F5u: goto L_83A6F5;
    case 0x83A6F6u: goto L_83A6F6;
    case 0x83A6F7u: goto L_83A6F7;
    case 0x83A6F9u: goto L_83A6F9;
    case 0x83A6FBu: goto L_83A6FB;
    case 0x83A6FCu: goto L_83A6FC;
    case 0x83A6FDu: goto L_83A6FD;
    case 0x83A6FFu: goto L_83A6FF;
    case 0x83A701u: goto L_83A701;
    case 0x83A702u: goto L_83A702;
    case 0x83A704u: goto L_83A704;
    case 0x83A706u: goto L_83A706;
    case 0x83A707u: goto L_83A707;
    case 0x83A709u: goto L_83A709;
    case 0x83A70Bu: goto L_83A70B;
    case 0x83A70Du: goto L_83A70D;
    case 0x83A70Fu: goto L_83A70F;
    case 0x83A711u: goto L_83A711;
    case 0x83A713u: goto L_83A713;
    case 0x83A714u: goto L_83A714;
    case 0x83A717u: goto L_83A717;
    case 0x83A718u: goto L_83A718;
    case 0x83A71Au: goto L_83A71A;
    case 0x83A71Cu: goto L_83A71C;
    case 0x83A71Eu: goto L_83A71E;
    case 0x83A720u: goto L_83A720;
    case 0x83A721u: goto L_83A721;
    case 0x83A722u: goto L_83A722;
    case 0x83A724u: goto L_83A724;
    case 0x83A726u: goto L_83A726;
    case 0x83A728u: goto L_83A728;
    case 0x83A72Au: goto L_83A72A;
    case 0x83A72Du: goto L_83A72D;
    case 0x83A731u: goto L_83A731;
    case 0x83A734u: goto L_83A734;
    case 0x83A736u: goto L_83A736;
    case 0x83A739u: goto L_83A739;
    case 0x83A73Bu: goto L_83A73B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA600u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA600u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A600 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A603;
L_83A603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA603u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA603u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A603 BPL -> $83A609
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A609; }
    goto L_83A605;
L_83A605:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA605u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA605u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA605u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A605 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A608;
L_83A608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA608u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA608u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A608 INC
    cpu.inc('A');
    goto L_83A609;
L_83A609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA609u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA609u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A609 ASL
    cpu.aslA();
    goto L_83A60A;
L_83A60A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Au,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A60A XBA
    cpu.xba();
    goto L_83A60B;
L_83A60B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A60B AND
    cpu.logicAnd(0xFFu);
    goto L_83A60E;
L_83A60E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A60E STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_83A610;
L_83A610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA610u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA610u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A610 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A613;
L_83A613:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA613u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA613u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA613u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A613 AND
    cpu.logicAnd(0xF0u);
    goto L_83A616;
L_83A616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA616u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA616u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A616 BIT
    cpu.bit(0x80u, true);
    goto L_83A619;
L_83A619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A619 BEQ -> $83A61F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A61F; }
    goto L_83A61B;
L_83A61B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A61B EOR
    cpu.logicXor(0x7Fu);
    goto L_83A61E;
L_83A61E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Eu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A61E INC
    cpu.inc('A');
    goto L_83A61F;
L_83A61F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A61F LSR
    cpu.lsrA();
    goto L_83A620;
L_83A620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA620u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA620u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A620 LSR
    cpu.lsrA();
    goto L_83A621;
L_83A621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA621u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA621u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A621 LSR
    cpu.lsrA();
    goto L_83A622;
L_83A622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA622u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA622u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A622 AND
    cpu.logicAnd(0xEu);
    goto L_83A625;
L_83A625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A625 TAY
    cpu.transfer("TAY");
    goto L_83A626;
L_83A626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA626u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA626u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA626u, 5u + 1u, 3u, cpu.address("absy", 0xF974u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A626 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF974u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A629;
L_83A629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA629u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA629u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A629 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_83A62B;
L_83A62B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Bu, 5u + 1u, 3u, cpu.address("absy", 0xF97Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A62B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF97Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A62E;
L_83A62E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A62E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A630;
L_83A630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA630u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA630u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A630 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A632;
L_83A632:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA632u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA632u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA632u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A632 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A634;
L_83A634:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA634u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA634u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA634u, 8u, 4u, 0x808D32u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A634 JSL -> $808D32 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA637u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA638u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D32u, 0x83A634u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A638;
L_83A638:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA638u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA638u,0x83A638u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA638u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA638u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A638 STY
    hw.write(cpu.address("dp", 0xAu), cpu.y, cpu.x8?8:16);
    goto L_83A63A;
L_83A63A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A63A STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_83A63C;
L_83A63C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Cu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A63C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1090u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A63F;
L_83A63F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A63F BPL -> $83A643
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A643; }
    goto L_83A641;
L_83A641:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA641u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA641u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA641u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A641 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A643;
L_83A643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA643u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA643u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA643u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A643 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1098u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A646;
L_83A646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA646u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA646u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA646u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A646 CPY
    cpu.compareY(0xC0u);
    goto L_83A649;
L_83A649:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA649u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA649u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA649u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A649 BCS -> $83A652
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A652; }
    goto L_83A64B;
L_83A64B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A64B CPY
    cpu.compareY(0x40u);
    goto L_83A64E;
L_83A64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A64E BCC -> $83A652
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A652; }
    goto L_83A650;
L_83A650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA650u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA650u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A650 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A652;
L_83A652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A652 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A654;
L_83A654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA654u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA654u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A654 BCC -> $83A669
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A669; }
    goto L_83A656;
L_83A656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA656u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA656u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA656u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A656 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A658;
L_83A658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA658u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA658u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A658 LDA
    cpu.setA(0x0u, 16);
    goto L_83A65B;
L_83A65B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A65B SEC
    cpu.setFlag('C', true);
    goto L_83A65C;
L_83A65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Cu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A65C SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A65E;
L_83A65E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A65E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A660;
L_83A660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A660 LDA
    cpu.setA(0x0u, 16);
    goto L_83A663;
L_83A663:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA663u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA663u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA663u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A663 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83A665;
L_83A665:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA665u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA665u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA665u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A665 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A667;
L_83A667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA667u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A667 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A669;
L_83A669:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA669u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA669u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA669u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A669 CLC
    cpu.setFlag('C', false);
    goto L_83A66A;
L_83A66A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Au,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Au, 5u, 3u, cpu.address("abs", 0x1BD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A66A ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BD4u), cpu.m8?8:16));
    goto L_83A66D;
L_83A66D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A66D STA
    hw.write(cpu.address("dpx", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_83A66F;
L_83A66F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A66F STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_83A671;
L_83A671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA671u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA671u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A671 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A673;
L_83A673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA673u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA673u, 5u, 3u, cpu.address("abs", 0x1BD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A673 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BD2u), cpu.m8?8:16));
    goto L_83A676;
L_83A676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA676u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA676u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A676 STA
    hw.write(cpu.address("dpx", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_83A678;
L_83A678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A678 STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_83A67A;
L_83A67A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Au,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A67A LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A67C;
L_83A67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A67C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A67E;
L_83A67E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu, 8u, 4u, 0x808D32u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A67E JSL -> $808D32 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA681u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA682u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D32u, 0x83A67Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A682;
L_83A682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA682u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA682u,0x83A682u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA682u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA682u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A682 STY
    hw.write(cpu.address("dp", 0xAu), cpu.y, cpu.x8?8:16);
    goto L_83A684;
L_83A684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A684 STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_83A686;
L_83A686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA686u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA686u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A686 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1090u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A689;
L_83A689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A689 BPL -> $83A68D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A68D; }
    goto L_83A68B;
L_83A68B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A68B INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A68D;
L_83A68D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Du,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Du, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A68D LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1098u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A690;
L_83A690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA690u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA690u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A690 CPY
    cpu.compareY(0x80u);
    goto L_83A693;
L_83A693:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA693u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA693u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA693u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A693 BCC -> $83A697
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A697; }
    goto L_83A695;
L_83A695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA695u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA695u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A695 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A697;
L_83A697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A697 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A699;
L_83A699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A699 BCC -> $83A6AE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A6AE; }
    goto L_83A69B;
L_83A69B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A69B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A69D;
L_83A69D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A69D LDA
    cpu.setA(0x0u, 16);
    goto L_83A6A0;
L_83A6A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A0 SEC
    cpu.setFlag('C', true);
    goto L_83A6A1;
L_83A6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A1 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A6A3;
L_83A6A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A3 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A6A5;
L_83A6A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A5 LDA
    cpu.setA(0x0u, 16);
    goto L_83A6A8;
L_83A6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A8 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83A6AA;
L_83A6AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6AA STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A6AC;
L_83A6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6AE;
L_83A6AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6AE CLC
    cpu.setFlag('C', false);
    goto L_83A6AF;
L_83A6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AFu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AFu, 5u, 3u, cpu.address("abs", 0x1BD8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6AF ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BD8u), cpu.m8?8:16));
    goto L_83A6B2;
L_83A6B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6B2 STA
    hw.write(cpu.address("dpx", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_83A6B4;
L_83A6B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6B4 STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_83A6B6;
L_83A6B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6B6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6B8;
L_83A6B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B8u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B8u, 5u, 3u, cpu.address("abs", 0x1BD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6B8 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BD6u), cpu.m8?8:16));
    goto L_83A6BB;
L_83A6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BBu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6BB STA
    hw.write(cpu.address("dpx", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_83A6BD;
L_83A6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6BD STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_83A6BF;
L_83A6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu, 5u + 1u, 3u, cpu.address("absx", 0x0024u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6BF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6C2;
L_83A6C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6C2 LSR
    cpu.lsrA();
    goto L_83A6C3;
L_83A6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6C3 BNE -> $83A713
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A713; }
    goto L_83A6C5;
L_83A6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6C5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6C7;
L_83A6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6C7 CMP
    cpu.compareA(0x8u);
    goto L_83A6CA;
L_83A6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6CA BCC -> $83A713
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A713; }
    goto L_83A6CC;
L_83A6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6CC AND
    cpu.logicAnd(0x1u);
    goto L_83A6CF;
L_83A6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6CF BNE -> $83A6F3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A6F3; }
    goto L_83A6D1;
L_83A6D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6D1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6D3;
L_83A6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6D3 ASL
    cpu.aslA();
    goto L_83A6D4;
L_83A6D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D4u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6D4 PHP
    cpu.push("PHP", hw);
    goto L_83A6D5;
L_83A6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D5u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6D5 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x18u), cpu.m8?8:16);
    goto L_83A6D7;
L_83A6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D7u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6D7 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_83A6D9;
L_83A6D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D9u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6D9 PLP
    cpu.pop("PLP", hw);
    goto L_83A6DA;
L_83A6DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6DAu,0x83A6DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DAu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6DA PHP
    cpu.push("PHP", hw);
    goto L_83A6DB;
L_83A6DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DBu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6DB ROR
    cpu.rorMem(hw, cpu.address("dp", 0x18u), cpu.m8?8:16);
    goto L_83A6DD;
L_83A6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DDu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6DD ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_83A6DF;
L_83A6DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DFu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6DF PLP
    cpu.pop("PLP", hw);
    goto L_83A6E0;
L_83A6E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6E0u,0x83A6E0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E0u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E0 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x18u), cpu.m8?8:16);
    goto L_83A6E2;
L_83A6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E2u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E2 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_83A6E4;
L_83A6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E4 SEC
    cpu.setFlag('C', true);
    goto L_83A6E5;
L_83A6E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6E7;
L_83A6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_83A6E9;
L_83A6E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E9u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E9 STA
    hw.write(cpu.address("dpx", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_83A6EB;
L_83A6EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6EB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6ED;
L_83A6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6ED SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16));
    goto L_83A6EF;
L_83A6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6EF STA
    hw.write(cpu.address("dpx", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_83A6F1;
L_83A6F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F1 BRA -> $83A713
    goto L_83A713;
L_83A6F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6F5;
L_83A6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F5 ASL
    cpu.aslA();
    goto L_83A6F6;
L_83A6F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F6u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6F6 PHP
    cpu.push("PHP", hw);
    goto L_83A6F7;
L_83A6F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F7u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F7 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_83A6F9;
L_83A6F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F9u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F9 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_83A6FB;
L_83A6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6FB PLP
    cpu.pop("PLP", hw);
    goto L_83A6FC;
L_83A6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6FCu,0x83A6FCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6FC PHP
    cpu.push("PHP", hw);
    goto L_83A6FD;
L_83A6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6FD ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_83A6FF;
L_83A6FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6FF ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_83A701;
L_83A701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA701u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA701u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A701 PLP
    cpu.pop("PLP", hw);
    goto L_83A702;
L_83A702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA702u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA702u,0x83A702u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA702u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA702u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A702 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_83A704;
L_83A704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA704u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA704u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A704 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_83A706;
L_83A706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA706u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA706u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA706u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A706 SEC
    cpu.setFlag('C', true);
    goto L_83A707;
L_83A707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A707 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A709;
L_83A709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A709 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16));
    goto L_83A70B;
L_83A70B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A70B STA
    hw.write(cpu.address("dpx", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_83A70D;
L_83A70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A70D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A70F;
L_83A70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A70F SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_83A711;
L_83A711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A711 STA
    hw.write(cpu.address("dpx", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_83A713;
L_83A713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA713u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A713 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A713u);return;} hw.unresolvedReturn(0x83A713u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A713 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A713u);return;} hw.unresolvedReturn(0x83A713u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA713u,0x83A713u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA714u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA714u, 5u, 3u, cpu.address("abs", 0x1BA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A714 STZ
    hw.write(cpu.address("abs", 0x1BA4u), 0, cpu.m8?8:16);
    goto L_83A717;
L_83A717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA717u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A717 CLC
    cpu.setFlag('C', false);
    goto L_83A718;
L_83A718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA718u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA718u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A718 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A71A;
L_83A71A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Au,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A71A ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xCu), cpu.m8?8:16));
    goto L_83A71C;
L_83A71C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A71C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A71E;
L_83A71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA71Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A71E ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83A720;
L_83A720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA720u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA720u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A720 TAY
    cpu.transfer("TAY");
    goto L_83A721;
L_83A721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA721u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A721 CLC
    cpu.setFlag('C', false);
    goto L_83A722;
L_83A722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA722u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA722u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A722 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A724;
L_83A724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA724u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA724u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A724 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16));
    goto L_83A726;
L_83A726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA726u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA726u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A726 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A728;
L_83A728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA728u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA728u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A728 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83A72A;
L_83A72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Au, 5u, 3u, cpu.address("abs", 0x1BA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A72A STA
    hw.write(cpu.address("abs", 0x1BA2u), cpu.a, cpu.m8?8:16);
    goto L_83A72D;
L_83A72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Du, 8u, 4u, 0x848914u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A72D JSL -> $848914 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA730u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA731u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848914u, 0x83A72Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A731;
L_83A731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA731u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA731u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA731u, 6u, 3u, cpu.address("abs", 0xA8E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A731 JSR -> $83A8E4 stack real
    { cpu.push16Value(hw,0xA733u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA734u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA8E4u), 0x83A731u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A734;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA731u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA731u, 6u, 3u, cpu.address("abs", 0xA8E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A731 JSR -> $83A8E4 stack real
    { cpu.push16Value(hw,0xA733u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA734u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA8E4u), 0x83A731u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A734;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA731u,0x83A731u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA734u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA734u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA734u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A734 BCC -> $83A713
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A713; }
    goto L_83A736;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA734u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA734u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A734 BCC -> $83A713
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A713; }
    goto L_83A736;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA734u,0x83A734u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA736u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA736u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA736u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A736 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A739;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA736u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA736u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A736 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A739;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA736u,0x83A736u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA739u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA739u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA739u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A739 BPL -> $83A76B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83A76Bu,0x83A739u); return; }
    goto L_83A73B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA739u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA739u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A739 BPL -> $83A76B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83A76Bu,0x83A739u); return; }
    goto L_83A73B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA739u,0x83A739u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA73Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Bu, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A73B STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA73Eu,0x83A73Bu); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Bu, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A73B STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA73Eu,0x83A73Bu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA73Bu,0x83A73Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_83B388_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83B388u: goto L_83B388;
    case 0x83B38Au: goto L_83B38A;
    case 0x83B38Cu: goto L_83B38C;
    case 0x83B38Fu: goto L_83B38F;
    case 0x83B391u: goto L_83B391;
    case 0x83B394u: goto L_83B394;
    case 0x83B395u: goto L_83B395;
    case 0x83B396u: goto L_83B396;
    case 0x83B398u: goto L_83B398;
    case 0x83B399u: goto L_83B399;
    case 0x83B39Bu: goto L_83B39B;
    case 0x83B39Du: goto L_83B39D;
    case 0x83B3A0u: goto L_83B3A0;
    case 0x83B3A2u: goto L_83B3A2;
    case 0x83B3A5u: goto L_83B3A5;
    case 0x83B3A7u: goto L_83B3A7;
    case 0x83B3AAu: goto L_83B3AA;
    case 0x83B3ACu: goto L_83B3AC;
    case 0x83B3AFu: goto L_83B3AF;
    case 0x83B3B1u: goto L_83B3B1;
    case 0x83B3B4u: goto L_83B3B4;
    case 0x83B3B6u: goto L_83B3B6;
    case 0x83B3B9u: goto L_83B3B9;
    case 0x83B3BBu: goto L_83B3BB;
    case 0x83B3BDu: goto L_83B3BD;
    case 0x83B3C0u: goto L_83B3C0;
    case 0x83B3C2u: goto L_83B3C2;
    case 0x83B3C5u: goto L_83B3C5;
    case 0x83B3C7u: goto L_83B3C7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83B388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB388u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB388u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB388u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B388 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B38A;
L_83B38A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B38A BEQ -> $83B391
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B391; }
    goto L_83B38C;
L_83B38C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Cu, 6u, 3u, cpu.address("abs", 0xB793u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B38C JSR -> $83B793 stack real
    { cpu.push16Value(hw,0xB38Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB38Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB793u), 0x83B38Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B38F;
L_83B38F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Fu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B38F STZ
    hw.write(cpu.address("dpx", 0x4Au), 0, cpu.m8?8:16);
    goto L_83B391;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Fu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B38F STZ
    hw.write(cpu.address("dpx", 0x4Au), 0, cpu.m8?8:16);
    goto L_83B391;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Fu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B38F STZ
    hw.write(cpu.address("dpx", 0x4Au), 0, cpu.m8?8:16);
    goto L_83B391;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB38Fu,0x83B38Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB391u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B391 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B394;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B391 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B394;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B391 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B394;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB391u,0x83B391u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB394u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB394u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB394u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B394 LSR
    cpu.lsrA();
    goto L_83B395;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB394u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB394u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B394 LSR
    cpu.lsrA();
    goto L_83B395;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB394u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB394u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B394 LSR
    cpu.lsrA();
    goto L_83B395;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB394u,0x83B394u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB395u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB395u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B395 CLC
    cpu.setFlag('C', false);
    goto L_83B396;
L_83B396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB396u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B396 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16));
    goto L_83B398;
L_83B398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB398u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB398u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B398 LSR
    cpu.lsrA();
    goto L_83B399;
L_83B399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B399 BCC -> $83B3C7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B3C7; }
    goto L_83B39B;
L_83B39B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B39B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B39D;
L_83B39D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B39D CMP
    cpu.compareA(0x5u);
    goto L_83B3A0;
L_83B3A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3A0 BCS -> $83B3C5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B3C5; }
    goto L_83B3A2;
L_83B3A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u, 5u + 1u, 3u, cpu.address("absx", 0x10B6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3A2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B3A5;
L_83B3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3A5 BEQ -> $83B3B1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B3B1; }
    goto L_83B3A7;
L_83B3A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A7u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A7u, 9u, 3u, cpu.address("absx", 0x10B6u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3A7 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10B6u), cpu.m8?8:16);
    goto L_83B3AA;
L_83B3AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3AA BNE -> $83B3B1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B3B1; }
    goto L_83B3AC;
L_83B3AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3AC LDA
    cpu.setA(0x2u, 16);
    goto L_83B3AF;
L_83B3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3AF STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_83B3B1;
L_83B3B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B1u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B1u, 5u + 1u, 3u, cpu.address("absx", 0x1092u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3B1 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1092u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B3B4;
L_83B3B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3B4 BEQ -> $83B3BB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B3BB; }
    goto L_83B3B6;
L_83B3B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B6u, 6u, 3u, cpu.address("abs", 0xB855u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B3B6 JSR -> $83B855 stack real
    { cpu.push16Value(hw,0xB3B8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3B9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB855u), 0x83B3B6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B3B9;
L_83B3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3B9u,0x83B3B9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3B9 BRA -> $83B3C5
    goto L_83B3C5;
L_83B3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3BB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x44u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B3BD;
L_83B3BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3BD AND
    cpu.logicAnd(0x7FFFu);
    goto L_83B3C0;
L_83B3C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3C0 BEQ -> $83B3C5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B3C5; }
    goto L_83B3C2;
L_83B3C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C2u, 6u, 3u, cpu.address("abs", 0xB3C8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B3C2 JSR -> $83B3C8 stack real
    { cpu.push16Value(hw,0xB3C4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3C5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB3C8u), 0x83B3C2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B3C5;
L_83B3C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C5u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3C5 STZ
    hw.write(cpu.address("dpx", 0x44u), 0, cpu.m8?8:16);
    goto L_83B3C7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3C5 STZ
    hw.write(cpu.address("dpx", 0x44u), 0, cpu.m8?8:16);
    goto L_83B3C7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3C5 STZ
    hw.write(cpu.address("dpx", 0x44u), 0, cpu.m8?8:16);
    goto L_83B3C7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3C5u,0x83B3C5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C7u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B3C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B3C7u);return;} hw.unresolvedReturn(0x83B3C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B3C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B3C7u);return;} hw.unresolvedReturn(0x83B3C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B3C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B3C7u);return;} hw.unresolvedReturn(0x83B3C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3C7u,0x83B3C7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_83B388_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83B388u: goto L_83B388;
    case 0x83B38Au: goto L_83B38A;
    case 0x83B38Cu: goto L_83B38C;
    case 0x83B38Fu: goto L_83B38F;
    case 0x83B391u: goto L_83B391;
    case 0x83B394u: goto L_83B394;
    case 0x83B395u: goto L_83B395;
    case 0x83B396u: goto L_83B396;
    case 0x83B398u: goto L_83B398;
    case 0x83B399u: goto L_83B399;
    case 0x83B39Bu: goto L_83B39B;
    case 0x83B39Du: goto L_83B39D;
    case 0x83B3A0u: goto L_83B3A0;
    case 0x83B3A2u: goto L_83B3A2;
    case 0x83B3A5u: goto L_83B3A5;
    case 0x83B3A7u: goto L_83B3A7;
    case 0x83B3AAu: goto L_83B3AA;
    case 0x83B3ACu: goto L_83B3AC;
    case 0x83B3AFu: goto L_83B3AF;
    case 0x83B3B1u: goto L_83B3B1;
    case 0x83B3B4u: goto L_83B3B4;
    case 0x83B3B6u: goto L_83B3B6;
    case 0x83B3B9u: goto L_83B3B9;
    case 0x83B3BBu: goto L_83B3BB;
    case 0x83B3BDu: goto L_83B3BD;
    case 0x83B3C0u: goto L_83B3C0;
    case 0x83B3C2u: goto L_83B3C2;
    case 0x83B3C5u: goto L_83B3C5;
    case 0x83B3C7u: goto L_83B3C7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83B388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB388u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB388u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB388u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B388 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B38A;
L_83B38A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B38A BEQ -> $83B391
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B391; }
    goto L_83B38C;
L_83B38C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Cu, 6u, 3u, cpu.address("abs", 0xB793u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B38C JSR -> $83B793 stack real
    { cpu.push16Value(hw,0xB38Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB38Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB793u), 0x83B38Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B38F;
L_83B38F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Fu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B38F STZ
    hw.write(cpu.address("dpx", 0x4Au), 0, cpu.m8?8:16);
    goto L_83B391;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Fu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B38F STZ
    hw.write(cpu.address("dpx", 0x4Au), 0, cpu.m8?8:16);
    goto L_83B391;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Fu,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B38F STZ
    hw.write(cpu.address("dpx", 0x4Au), 0, cpu.m8?8:16);
    goto L_83B391;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB38Fu,0x83B38Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB391u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B391 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B394;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B391 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B394;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B391 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B394;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB391u,0x83B391u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB394u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB394u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB394u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B394 LSR
    cpu.lsrA();
    goto L_83B395;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB394u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB394u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B394 LSR
    cpu.lsrA();
    goto L_83B395;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB394u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB394u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B394 LSR
    cpu.lsrA();
    goto L_83B395;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB394u,0x83B394u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB395u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB395u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B395 CLC
    cpu.setFlag('C', false);
    goto L_83B396;
L_83B396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB396u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B396 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16));
    goto L_83B398;
L_83B398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB398u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB398u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B398 LSR
    cpu.lsrA();
    goto L_83B399;
L_83B399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B399 BCC -> $83B3C7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B3C7; }
    goto L_83B39B;
L_83B39B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B39B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B39D;
L_83B39D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B39D CMP
    cpu.compareA(0x5u);
    goto L_83B3A0;
L_83B3A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3A0 BCS -> $83B3C5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B3C5; }
    goto L_83B3A2;
L_83B3A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A2u, 5u + 1u, 3u, cpu.address("absx", 0x10B6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3A2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B3A5;
L_83B3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3A5 BEQ -> $83B3B1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B3B1; }
    goto L_83B3A7;
L_83B3A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A7u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A7u, 9u, 3u, cpu.address("absx", 0x10B6u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3A7 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10B6u), cpu.m8?8:16);
    goto L_83B3AA;
L_83B3AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3AA BNE -> $83B3B1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B3B1; }
    goto L_83B3AC;
L_83B3AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3AC LDA
    cpu.setA(0x2u, 16);
    goto L_83B3AF;
L_83B3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3AF STA
    hw.write(cpu.address("dpx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_83B3B1;
L_83B3B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B1u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B1u, 5u + 1u, 3u, cpu.address("absx", 0x1092u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3B1 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1092u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B3B4;
L_83B3B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3B4 BEQ -> $83B3BB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B3BB; }
    goto L_83B3B6;
L_83B3B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B6u, 6u, 3u, cpu.address("abs", 0xB855u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B3B6 JSR -> $83B855 stack real
    { cpu.push16Value(hw,0xB3B8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3B9u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB855u), 0x83B3B6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B3B9;
L_83B3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3B9u,0x83B3B9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3B9 BRA -> $83B3C5
    goto L_83B3C5;
L_83B3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3BB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x44u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B3BD;
L_83B3BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3BD AND
    cpu.logicAnd(0x7FFFu);
    goto L_83B3C0;
L_83B3C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3C0 BEQ -> $83B3C5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B3C5; }
    goto L_83B3C2;
L_83B3C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C2u, 6u, 3u, cpu.address("abs", 0xB3C8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B3C2 JSR -> $83B3C8 stack real
    { cpu.push16Value(hw,0xB3C4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB3C5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB3C8u), 0x83B3C2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B3C5;
L_83B3C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C5u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3C5 STZ
    hw.write(cpu.address("dpx", 0x44u), 0, cpu.m8?8:16);
    goto L_83B3C7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3C5 STZ
    hw.write(cpu.address("dpx", 0x44u), 0, cpu.m8?8:16);
    goto L_83B3C7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x44u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B3C5 STZ
    hw.write(cpu.address("dpx", 0x44u), 0, cpu.m8?8:16);
    goto L_83B3C7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3C5u,0x83B3C5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C7u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B3C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B3C7u);return;} hw.unresolvedReturn(0x83B3C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B3C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B3C7u);return;} hw.unresolvedReturn(0x83B3C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B3C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B3C7u);return;} hw.unresolvedReturn(0x83B3C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3C7u,0x83B3C7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_83B8D5_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83B8C6u: goto L_83B8C6;
    case 0x83B8C9u: goto L_83B8C9;
    case 0x83B8CBu: goto L_83B8CB;
    case 0x83B8CCu: goto L_83B8CC;
    case 0x83B8CFu: goto L_83B8CF;
    case 0x83B8D3u: goto L_83B8D3;
    case 0x83B8D4u: goto L_83B8D4;
    case 0x83B8D5u: goto L_83B8D5;
    case 0x83B8D7u: goto L_83B8D7;
    case 0x83B8DAu: goto L_83B8DA;
    case 0x83B8DDu: goto L_83B8DD;
    case 0x83B8DEu: goto L_83B8DE;
    case 0x83B8DFu: goto L_83B8DF;
    case 0x83B8E0u: goto L_83B8E0;
    case 0x83B8E1u: goto L_83B8E1;
    case 0x83B8E4u: goto L_83B8E4;
    case 0x83B8E7u: goto L_83B8E7;
    case 0x83B8E9u: goto L_83B8E9;
    case 0x83B8EBu: goto L_83B8EB;
    case 0x83B8EEu: goto L_83B8EE;
    case 0x83B8F1u: goto L_83B8F1;
    case 0x83B8F2u: goto L_83B8F2;
    case 0x83B8F3u: goto L_83B8F3;
    case 0x83B8F4u: goto L_83B8F4;
    case 0x83B8F5u: goto L_83B8F5;
    case 0x83B8F6u: goto L_83B8F6;
    case 0x83B8F9u: goto L_83B8F9;
    case 0x83B8FAu: goto L_83B8FA;
    case 0x83B8FBu: goto L_83B8FB;
    case 0x83B8FEu: goto L_83B8FE;
    case 0x83B8FFu: goto L_83B8FF;
    case 0x83B900u: goto L_83B900;
    case 0x83B901u: goto L_83B901;
    case 0x83B902u: goto L_83B902;
    case 0x83B904u: goto L_83B904;
    case 0x83B908u: goto L_83B908;
    case 0x83B909u: goto L_83B909;
    case 0x83B90Cu: goto L_83B90C;
    case 0x83B90Fu: goto L_83B90F;
    case 0x83B910u: goto L_83B910;
    case 0x83B911u: goto L_83B911;
    case 0x83B912u: goto L_83B912;
    case 0x83B916u: goto L_83B916;
    case 0x83B918u: goto L_83B918;
    case 0x83B91Bu: goto L_83B91B;
    case 0x83B91Cu: goto L_83B91C;
    case 0x83B91Fu: goto L_83B91F;
    case 0x83B921u: goto L_83B921;
    case 0x83B924u: goto L_83B924;
    case 0x83B927u: goto L_83B927;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83B8C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8C6 CMP
    cpu.compareA(0xCu);
    goto L_83B8C9;
L_83B8C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8C9 BNE -> $83B8D4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B8D4; }
    goto L_83B8CB;
L_83B8CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CBu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B8CB PHY
    cpu.push("PHY", hw);
    goto L_83B8CC;
L_83B8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8CC LDA
    cpu.setA(0x8u, 16);
    goto L_83B8CF;
L_83B8CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CFu, 8u, 4u, 0x809508u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83B8CF JSL -> $809508 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB8D2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB8D3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809508u, 0x83B8CFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B8D3;
L_83B8D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB8D3u,0x83B8D3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D3u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B8D3 PLY
    cpu.pop("PLY", hw);
    goto L_83B8D4;
L_83B8D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B8D4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B8D4u);return;} hw.unresolvedReturn(0x83B8D4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83B8D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D5u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8D5 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_83B8D7;
L_83B8D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D7u, 5u + 1u, 3u, cpu.address("absx", 0x109Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8D7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B8DA;
L_83B8DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8DA AND
    cpu.logicAnd(0xFu);
    goto L_83B8DD;
L_83B8DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8DD ASL
    cpu.aslA();
    goto L_83B8DE;
L_83B8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8DE ASL
    cpu.aslA();
    goto L_83B8DF;
L_83B8DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8DF ASL
    cpu.aslA();
    goto L_83B8E0;
L_83B8E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8E0 ASL
    cpu.aslA();
    goto L_83B8E1;
L_83B8E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E1u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E1u, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8E1 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B8E4;
L_83B8E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E4u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E4u, 5u + 1u, 3u, cpu.address("absy", 0xD8EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8E4 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD8EDu), cpu.m8?8:16));
    goto L_83B8E7;
L_83B8E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8E7 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83B8E9;
L_83B8E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E9u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8E9 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B8EB;
L_83B8EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EBu, 5u + 1u, 3u, cpu.address("absy", 0x109Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8EB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x109Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B8EE;
L_83B8EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8EE AND
    cpu.logicAnd(0xFu);
    goto L_83B8F1;
L_83B8F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8F1 ASL
    cpu.aslA();
    goto L_83B8F2;
L_83B8F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8F2 ASL
    cpu.aslA();
    goto L_83B8F3;
L_83B8F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8F3 ASL
    cpu.aslA();
    goto L_83B8F4;
L_83B8F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8F4 ASL
    cpu.aslA();
    goto L_83B8F5;
L_83B8F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F5u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B8F5 PHA
    cpu.push("PHA", hw);
    goto L_83B8F6;
L_83B8F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u, 5u + 1u, 3u, cpu.address("absy", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8F6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B8F9;
L_83B8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F9u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8F9 TAY
    cpu.transfer("TAY");
    goto L_83B8FA;
L_83B8FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FAu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FAu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B8FA PLA
    cpu.pop("PLA", hw);
    goto L_83B8FB;
L_83B8FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FBu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FBu, 5u + 1u, 3u, cpu.address("absy", 0xD8EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8FB ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD8EDu), cpu.m8?8:16));
    goto L_83B8FE;
L_83B8FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8FE LSR
    cpu.lsrA();
    goto L_83B8FF;
L_83B8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8FF LSR
    cpu.lsrA();
    goto L_83B900;
L_83B900:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB900u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB900u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB900u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B900 LSR
    cpu.lsrA();
    goto L_83B901;
L_83B901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B901 TAY
    cpu.transfer("TAY");
    goto L_83B902;
L_83B902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB902u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB902u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B902 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B904;
L_83B904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB904u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB904u, 8u, 4u, 0x808D53u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83B904 JSL -> $808D53 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB907u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB908u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D53u, 0x83B904u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B908;
L_83B908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB908u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB908u,0x83B908u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB908u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB908u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B908 TAY
    cpu.transfer("TAY");
    goto L_83B909;
L_83B909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB909u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB909u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B909 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B90C;
L_83B90C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B90C ADC
    cpu.adc(0x80u);
    goto L_83B90F;
L_83B90F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B90F LSR
    cpu.lsrA();
    goto L_83B910;
L_83B910:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB910u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB910u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB910u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B910 LSR
    cpu.lsrA();
    goto L_83B911;
L_83B911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB911u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB911u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B911 LSR
    cpu.lsrA();
    goto L_83B912;
L_83B912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB912u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB912u, 8u, 4u, 0x808D32u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83B912 JSL -> $808D32 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB915u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB916u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D32u, 0x83B912u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B916;
L_83B916:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB916u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB916u,0x83B916u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB916u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB916u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B916 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B918;
L_83B918:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB918u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB918u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB918u, 6u, 3u, cpu.address("absy", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B918 STA
    hw.write(cpu.address("absy", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83B91B;
L_83B91B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B91B SEC
    cpu.setFlag('C', true);
    goto L_83B91C;
L_83B91C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Cu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Cu, 5u + 1u, 3u, cpu.address("absy", 0x0214u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B91C SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x214u), cpu.m8?8:16));
    goto L_83B91F;
L_83B91F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B91F BCC -> $83B924
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B924; }
    goto L_83B921;
L_83B921:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB921u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB921u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB921u, 6u, 3u, cpu.address("absy", 0x0216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B921 STA
    hw.write(cpu.address("absy", 0x216u), cpu.a, cpu.m8?8:16);
    goto L_83B924;
L_83B924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB924u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u, 5u + 1u, 3u, cpu.address("absy", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B924 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B927;
L_83B927:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB927u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB927u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB927u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B927 BRA -> $83B8C6
    goto L_83B8C6;
}

void sub_83B8D5_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83B8C6u: goto L_83B8C6;
    case 0x83B8C9u: goto L_83B8C9;
    case 0x83B8CBu: goto L_83B8CB;
    case 0x83B8CCu: goto L_83B8CC;
    case 0x83B8CFu: goto L_83B8CF;
    case 0x83B8D3u: goto L_83B8D3;
    case 0x83B8D4u: goto L_83B8D4;
    case 0x83B8D5u: goto L_83B8D5;
    case 0x83B8D7u: goto L_83B8D7;
    case 0x83B8DAu: goto L_83B8DA;
    case 0x83B8DDu: goto L_83B8DD;
    case 0x83B8DEu: goto L_83B8DE;
    case 0x83B8DFu: goto L_83B8DF;
    case 0x83B8E0u: goto L_83B8E0;
    case 0x83B8E1u: goto L_83B8E1;
    case 0x83B8E4u: goto L_83B8E4;
    case 0x83B8E7u: goto L_83B8E7;
    case 0x83B8E9u: goto L_83B8E9;
    case 0x83B8EBu: goto L_83B8EB;
    case 0x83B8EEu: goto L_83B8EE;
    case 0x83B8F1u: goto L_83B8F1;
    case 0x83B8F2u: goto L_83B8F2;
    case 0x83B8F3u: goto L_83B8F3;
    case 0x83B8F4u: goto L_83B8F4;
    case 0x83B8F5u: goto L_83B8F5;
    case 0x83B8F6u: goto L_83B8F6;
    case 0x83B8F9u: goto L_83B8F9;
    case 0x83B8FAu: goto L_83B8FA;
    case 0x83B8FBu: goto L_83B8FB;
    case 0x83B8FEu: goto L_83B8FE;
    case 0x83B8FFu: goto L_83B8FF;
    case 0x83B900u: goto L_83B900;
    case 0x83B901u: goto L_83B901;
    case 0x83B902u: goto L_83B902;
    case 0x83B904u: goto L_83B904;
    case 0x83B908u: goto L_83B908;
    case 0x83B909u: goto L_83B909;
    case 0x83B90Cu: goto L_83B90C;
    case 0x83B90Fu: goto L_83B90F;
    case 0x83B910u: goto L_83B910;
    case 0x83B911u: goto L_83B911;
    case 0x83B912u: goto L_83B912;
    case 0x83B916u: goto L_83B916;
    case 0x83B918u: goto L_83B918;
    case 0x83B91Bu: goto L_83B91B;
    case 0x83B91Cu: goto L_83B91C;
    case 0x83B91Fu: goto L_83B91F;
    case 0x83B921u: goto L_83B921;
    case 0x83B924u: goto L_83B924;
    case 0x83B927u: goto L_83B927;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83B8C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8C6 CMP
    cpu.compareA(0xCu);
    goto L_83B8C9;
L_83B8C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8C9 BNE -> $83B8D4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B8D4; }
    goto L_83B8CB;
L_83B8CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CBu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B8CB PHY
    cpu.push("PHY", hw);
    goto L_83B8CC;
L_83B8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8CC LDA
    cpu.setA(0x8u, 16);
    goto L_83B8CF;
L_83B8CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CFu, 8u, 4u, 0x809508u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83B8CF JSL -> $809508 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB8D2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB8D3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809508u, 0x83B8CFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B8D3;
L_83B8D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB8D3u,0x83B8D3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D3u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B8D3 PLY
    cpu.pop("PLY", hw);
    goto L_83B8D4;
L_83B8D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B8D4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B8D4u);return;} hw.unresolvedReturn(0x83B8D4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83B8D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D5u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8D5 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_83B8D7;
L_83B8D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D7u, 5u + 1u, 3u, cpu.address("absx", 0x109Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8D7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B8DA;
L_83B8DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8DA AND
    cpu.logicAnd(0xFu);
    goto L_83B8DD;
L_83B8DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8DD ASL
    cpu.aslA();
    goto L_83B8DE;
L_83B8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8DE ASL
    cpu.aslA();
    goto L_83B8DF;
L_83B8DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8DF ASL
    cpu.aslA();
    goto L_83B8E0;
L_83B8E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8E0 ASL
    cpu.aslA();
    goto L_83B8E1;
L_83B8E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E1u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E1u, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8E1 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B8E4;
L_83B8E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E4u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E4u, 5u + 1u, 3u, cpu.address("absy", 0xD8EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8E4 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD8EDu), cpu.m8?8:16));
    goto L_83B8E7;
L_83B8E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8E7 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83B8E9;
L_83B8E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E9u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8E9 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B8EB;
L_83B8EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EBu, 5u + 1u, 3u, cpu.address("absy", 0x109Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8EB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x109Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B8EE;
L_83B8EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8EE AND
    cpu.logicAnd(0xFu);
    goto L_83B8F1;
L_83B8F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8F1 ASL
    cpu.aslA();
    goto L_83B8F2;
L_83B8F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8F2 ASL
    cpu.aslA();
    goto L_83B8F3;
L_83B8F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8F3 ASL
    cpu.aslA();
    goto L_83B8F4;
L_83B8F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8F4 ASL
    cpu.aslA();
    goto L_83B8F5;
L_83B8F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F5u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B8F5 PHA
    cpu.push("PHA", hw);
    goto L_83B8F6;
L_83B8F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u, 5u + 1u, 3u, cpu.address("absy", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8F6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B8F9;
L_83B8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F9u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8F9 TAY
    cpu.transfer("TAY");
    goto L_83B8FA;
L_83B8FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FAu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FAu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B8FA PLA
    cpu.pop("PLA", hw);
    goto L_83B8FB;
L_83B8FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FBu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FBu, 5u + 1u, 3u, cpu.address("absy", 0xD8EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8FB ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD8EDu), cpu.m8?8:16));
    goto L_83B8FE;
L_83B8FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8FE LSR
    cpu.lsrA();
    goto L_83B8FF;
L_83B8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B8FF LSR
    cpu.lsrA();
    goto L_83B900;
L_83B900:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB900u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB900u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB900u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B900 LSR
    cpu.lsrA();
    goto L_83B901;
L_83B901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B901 TAY
    cpu.transfer("TAY");
    goto L_83B902;
L_83B902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB902u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB902u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B902 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B904;
L_83B904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB904u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB904u, 8u, 4u, 0x808D53u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83B904 JSL -> $808D53 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB907u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB908u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D53u, 0x83B904u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B908;
L_83B908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB908u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB908u,0x83B908u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB908u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB908u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B908 TAY
    cpu.transfer("TAY");
    goto L_83B909;
L_83B909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB909u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB909u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B909 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B90C;
L_83B90C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B90C ADC
    cpu.adc(0x80u);
    goto L_83B90F;
L_83B90F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B90F LSR
    cpu.lsrA();
    goto L_83B910;
L_83B910:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB910u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB910u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB910u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B910 LSR
    cpu.lsrA();
    goto L_83B911;
L_83B911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB911u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB911u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B911 LSR
    cpu.lsrA();
    goto L_83B912;
L_83B912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB912u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB912u, 8u, 4u, 0x808D32u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83B912 JSL -> $808D32 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB915u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB916u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D32u, 0x83B912u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B916;
L_83B916:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB916u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB916u,0x83B916u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB916u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB916u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B916 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B918;
L_83B918:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB918u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB918u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB918u, 6u, 3u, cpu.address("absy", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B918 STA
    hw.write(cpu.address("absy", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83B91B;
L_83B91B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B91B SEC
    cpu.setFlag('C', true);
    goto L_83B91C;
L_83B91C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Cu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Cu, 5u + 1u, 3u, cpu.address("absy", 0x0214u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B91C SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x214u), cpu.m8?8:16));
    goto L_83B91F;
L_83B91F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B91F BCC -> $83B924
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B924; }
    goto L_83B921;
L_83B921:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB921u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB921u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB921u, 6u, 3u, cpu.address("absy", 0x0216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B921 STA
    hw.write(cpu.address("absy", 0x216u), cpu.a, cpu.m8?8:16);
    goto L_83B924;
L_83B924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB924u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u, 5u + 1u, 3u, cpu.address("absy", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B924 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B927;
L_83B927:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB927u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB927u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB927u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B927 BRA -> $83B8C6
    goto L_83B8C6;
}

void sub_83D546_E0M0X0C1_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83DA43u: goto L_83DA43;
    case 0x83DA45u: goto L_83DA45;
    case 0x83DA48u: goto L_83DA48;
    case 0x83DA4Au: goto L_83DA4A;
    case 0x83E21Eu: goto L_83E21E;
    case 0x83E221u: goto L_83E221;
    case 0x83E222u: goto L_83E222;
    case 0x83E224u: goto L_83E224;
    case 0x83E227u: goto L_83E227;
    case 0x83E228u: goto L_83E228;
    case 0x83E22Au: goto L_83E22A;
    case 0x83E22Du: goto L_83E22D;
    case 0x83E22Fu: goto L_83E22F;
    case 0x83E232u: goto L_83E232;
    case 0x83E235u: goto L_83E235;
    case 0x83E238u: goto L_83E238;
    case 0x83E23Au: goto L_83E23A;
    case 0x83E23Cu: goto L_83E23C;
    case 0x83E23Eu: goto L_83E23E;
    case 0x83E240u: goto L_83E240;
    case 0x83E242u: goto L_83E242;
    case 0x83E243u: goto L_83E243;
    case 0x83E246u: goto L_83E246;
    case 0x83E248u: goto L_83E248;
    case 0x83E249u: goto L_83E249;
    case 0x83E24Bu: goto L_83E24B;
    case 0x83E24Du: goto L_83E24D;
    case 0x83E24Fu: goto L_83E24F;
    case 0x83E252u: goto L_83E252;
    case 0x83E254u: goto L_83E254;
    case 0x83E255u: goto L_83E255;
    case 0x83E257u: goto L_83E257;
    case 0x83E25Au: goto L_83E25A;
    case 0x83E25Du: goto L_83E25D;
    case 0x83E25Fu: goto L_83E25F;
    case 0x83E261u: goto L_83E261;
    case 0x83E264u: goto L_83E264;
    case 0x83E266u: goto L_83E266;
    case 0x83E26Au: goto L_83E26A;
    case 0x83E26Du: goto L_83E26D;
    case 0x83E26Fu: goto L_83E26F;
    case 0x83E271u: goto L_83E271;
    case 0x83E273u: goto L_83E273;
    case 0x83E275u: goto L_83E275;
    case 0x83E276u: goto L_83E276;
    case 0x83E277u: goto L_83E277;
    case 0x83E279u: goto L_83E279;
    case 0x83E27Bu: goto L_83E27B;
    case 0x83E27Cu: goto L_83E27C;
    case 0x83E27Eu: goto L_83E27E;
    case 0x83E280u: goto L_83E280;
    case 0x83E283u: goto L_83E283;
    case 0x83E285u: goto L_83E285;
    case 0x83E286u: goto L_83E286;
    case 0x83E288u: goto L_83E288;
    case 0x83E28Bu: goto L_83E28B;
    case 0x83E28Du: goto L_83E28D;
    case 0x83E28Eu: goto L_83E28E;
    case 0x83E290u: goto L_83E290;
    case 0x83E292u: goto L_83E292;
    case 0x83E293u: goto L_83E293;
    case 0x83E294u: goto L_83E294;
    case 0x83E296u: goto L_83E296;
    case 0x83E298u: goto L_83E298;
    case 0x83E299u: goto L_83E299;
    case 0x83E29Bu: goto L_83E29B;
    case 0x83E29Du: goto L_83E29D;
    case 0x83E2A0u: goto L_83E2A0;
    case 0x83E2A2u: goto L_83E2A2;
    case 0x83E2A3u: goto L_83E2A3;
    case 0x83E2A5u: goto L_83E2A5;
    case 0x83E2A8u: goto L_83E2A8;
    case 0x83E2AAu: goto L_83E2AA;
    case 0x83E2ABu: goto L_83E2AB;
    case 0x83E2ACu: goto L_83E2AC;
    case 0x83E2AFu: goto L_83E2AF;
    case 0x83E2B2u: goto L_83E2B2;
    case 0x83E2B4u: goto L_83E2B4;
    case 0x83E2B6u: goto L_83E2B6;
    case 0x83E2B8u: goto L_83E2B8;
    case 0x83E2BAu: goto L_83E2BA;
    case 0x83E2BBu: goto L_83E2BB;
    case 0x83E2BEu: goto L_83E2BE;
    case 0x83E2C0u: goto L_83E2C0;
    case 0x83E2C1u: goto L_83E2C1;
    case 0x83E2C3u: goto L_83E2C3;
    case 0x83E2C5u: goto L_83E2C5;
    case 0x83E2C7u: goto L_83E2C7;
    case 0x83E2CAu: goto L_83E2CA;
    case 0x83E2CCu: goto L_83E2CC;
    case 0x83E2CDu: goto L_83E2CD;
    case 0x83E2CFu: goto L_83E2CF;
    case 0x83E2D2u: goto L_83E2D2;
    case 0x83E2D5u: goto L_83E2D5;
    case 0x83E2D7u: goto L_83E2D7;
    case 0x83E2D9u: goto L_83E2D9;
    case 0x83E2DCu: goto L_83E2DC;
    case 0x83E2DEu: goto L_83E2DE;
    case 0x83E2E2u: goto L_83E2E2;
    case 0x83E2E5u: goto L_83E2E5;
    case 0x83E2E7u: goto L_83E2E7;
    case 0x83E2E9u: goto L_83E2E9;
    case 0x83E2EBu: goto L_83E2EB;
    case 0x83E2EDu: goto L_83E2ED;
    case 0x83E2EEu: goto L_83E2EE;
    case 0x83E2EFu: goto L_83E2EF;
    case 0x83E2F1u: goto L_83E2F1;
    case 0x83E2F3u: goto L_83E2F3;
    case 0x83E2F4u: goto L_83E2F4;
    case 0x83E2F6u: goto L_83E2F6;
    case 0x83E2F8u: goto L_83E2F8;
    case 0x83E2FBu: goto L_83E2FB;
    case 0x83E2FDu: goto L_83E2FD;
    case 0x83E2FEu: goto L_83E2FE;
    case 0x83E300u: goto L_83E300;
    case 0x83E303u: goto L_83E303;
    case 0x83E305u: goto L_83E305;
    case 0x83E306u: goto L_83E306;
    case 0x83E308u: goto L_83E308;
    case 0x83E30Au: goto L_83E30A;
    case 0x83E30Bu: goto L_83E30B;
    case 0x83E30Cu: goto L_83E30C;
    case 0x83E30Eu: goto L_83E30E;
    case 0x83E310u: goto L_83E310;
    case 0x83E311u: goto L_83E311;
    case 0x83E313u: goto L_83E313;
    case 0x83E315u: goto L_83E315;
    case 0x83E318u: goto L_83E318;
    case 0x83E31Au: goto L_83E31A;
    case 0x83E31Bu: goto L_83E31B;
    case 0x83E31Du: goto L_83E31D;
    case 0x83E320u: goto L_83E320;
    case 0x83E322u: goto L_83E322;
    case 0x83E323u: goto L_83E323;
    case 0x83E324u: goto L_83E324;
    case 0x83E326u: goto L_83E326;
    case 0x83E328u: goto L_83E328;
    case 0x83E32Au: goto L_83E32A;
    case 0x83E32Bu: goto L_83E32B;
    case 0x83E32Eu: goto L_83E32E;
    case 0x83E330u: goto L_83E330;
    case 0x83E331u: goto L_83E331;
    case 0x83E333u: goto L_83E333;
    case 0x83E335u: goto L_83E335;
    case 0x83E337u: goto L_83E337;
    case 0x83E33Au: goto L_83E33A;
    case 0x83E33Cu: goto L_83E33C;
    case 0x83E33Du: goto L_83E33D;
    case 0x83E33Fu: goto L_83E33F;
    case 0x83E342u: goto L_83E342;
    case 0x83E345u: goto L_83E345;
    case 0x83E347u: goto L_83E347;
    case 0x83E349u: goto L_83E349;
    case 0x83E34Cu: goto L_83E34C;
    case 0x83E34Eu: goto L_83E34E;
    case 0x83E352u: goto L_83E352;
    case 0x83E355u: goto L_83E355;
    case 0x83E357u: goto L_83E357;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83DA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83DA43 LDA
    cpu.setA(0x80u, 8);
    goto L_83DA45;
L_83DA45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA45u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA45u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83DA45 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83DA48;
L_83DA48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA48u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA48u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83DA48 REP
    cpu.rep(0x20u);
    goto L_83DA4A;
L_83DA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83DA4A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83DA4Au);return;} hw.unresolvedReturn(0x83DA4Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E21E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE21Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE21Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE21Eu, 6u, 3u, cpu.address("absx", 0x10DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E21E STZ
    hw.write(cpu.address("absx", 0x10DAu), 0, cpu.m8?8:16);
    goto L_83E221;
L_83E221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE221u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE221u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E221 LSR
    cpu.lsrA();
    goto L_83E222;
L_83E222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE222u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE222u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E222 BCC -> $83E227
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E227; }
    goto L_83E224;
L_83E224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE224u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE224u, 3u, 3u, cpu.address("abs", 0xE4FBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E224 JMP -> $83E4FB
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xE4FBu),0x83E224u); return;
L_83E227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE227u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE227u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E227 LSR
    cpu.lsrA();
    goto L_83E228;
L_83E228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE228u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE228u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E228 BCS -> $83E22D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E22D; }
    goto L_83E22A;
L_83E22A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE22Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Au, 3u, 3u, cpu.address("abs", 0xE394u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E22A JMP -> $83E394
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xE394u),0x83E22Au); return;
L_83E22D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE22Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E22D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E22F;
L_83E22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Fu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Fu, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E22F SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16));
    goto L_83E232;
L_83E232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE232u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE232u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E232 ADC
    cpu.adc(0x14u);
    goto L_83E235;
L_83E235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE235u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE235u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E235 CMP
    cpu.compareA(0x28u);
    goto L_83E238;
L_83E238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE238u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE238u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E238 BCC -> $83E2B4
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E2B4; }
    goto L_83E23A;
L_83E23A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE23Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E23A BPL -> $83E2AC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E2AC; }
    goto L_83E23C;
L_83E23C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE23Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E23C SEP
    cpu.sep(0x20u);
    goto L_83E23E;
L_83E23E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE23Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Eu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E23E LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E240;
L_83E240:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE240u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE240u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE240u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E240 AND
    cpu.logicAnd(0xF0u);
    goto L_83E242;
L_83E242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE242u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE242u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E242 SEC
    cpu.setFlag('C', true);
    goto L_83E243;
L_83E243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE243u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE243u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E243 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83E246;
L_83E246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE246u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE246u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E246 BEQ -> $83E255
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E255; }
    goto L_83E248;
L_83E248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE248u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE248u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E248 ASL
    cpu.aslA();
    goto L_83E249;
L_83E249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE249u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE249u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E249 LDA
    cpu.setA(0x82u, 8);
    goto L_83E24B;
L_83E24B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E24B BCC -> $83E24F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E24F; }
    goto L_83E24D;
L_83E24D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E24D LDA
    cpu.setA(0x81u, 8);
    goto L_83E24F;
L_83E24F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Fu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E24F STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E252;
L_83E252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE252u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE252u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E252 REP
    cpu.rep(0x20u);
    goto L_83E254;
L_83E254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE254u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE254u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E254 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E254u);return;} hw.unresolvedReturn(0x83E254u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE255u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE255u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE255u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E255 LDA
    cpu.setA(0x80u, 8);
    goto L_83E257;
L_83E257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE257u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE257u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E257 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E25A;
L_83E25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE25Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Au, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E25A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E25D;
L_83E25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E25D REP
    cpu.rep(0x20u);
    goto L_83E25F;
L_83E25F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE25Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E25F BEQ -> $83E2AB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E2AB; }
    goto L_83E261;
L_83E261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE261u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE261u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E261 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E264;
L_83E264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE264u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE264u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E264 BNE -> $83E28B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E28B; }
    goto L_83E266;
L_83E266:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE266u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE266u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE266u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E266 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE269u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE26Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E266u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E26A;
L_83E26A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE26Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE26Au,0x83E26Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Au, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E26A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E26D;
L_83E26D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE26Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Du,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E26D CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83E26F;
L_83E26F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE26Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E26F BMI -> $83E28E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E28E; }
    goto L_83E271;
L_83E271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE271u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE271u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E271 SEP
    cpu.sep(0x20u);
    goto L_83E273;
L_83E273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE273u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE273u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E273 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E275;
L_83E275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE275u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE275u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E275 TAY
    cpu.transfer("TAY");
    goto L_83E276;
L_83E276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE276u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE276u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E276 SEC
    cpu.setFlag('C', true);
    goto L_83E277;
L_83E277:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE277u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE277u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE277u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E277 SBC
    cpu.sbc(0x20u);
    goto L_83E279;
L_83E279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE279u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE279u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E279 CMP
    cpu.compareA(0x80u);
    goto L_83E27B;
L_83E27B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E27B TYA
    cpu.transfer("TYA");
    goto L_83E27C;
L_83E27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E27C BCS -> $83E286
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E286; }
    goto L_83E27E;
L_83E27E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E27E SBC
    cpu.sbc(0x3Fu);
    goto L_83E280;
L_83E280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE280u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE280u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE280u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E280 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E283;
L_83E283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE283u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE283u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E283 REP
    cpu.rep(0x20u);
    goto L_83E285;
L_83E285:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE285u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE285u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE285u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E285 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E285u);return;} hw.unresolvedReturn(0x83E285u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E286:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE286u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE286u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE286u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E286 ADC
    cpu.adc(0x3Fu);
    goto L_83E288;
L_83E288:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE288u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE288u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE288u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E288 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E28B;
L_83E28B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE28Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E28B REP
    cpu.rep(0x20u);
    goto L_83E28D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E28B REP
    cpu.rep(0x20u);
    goto L_83E28D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE28Bu,0x83E28Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E28D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE28Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E28D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E28Du);return;} hw.unresolvedReturn(0x83E28Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E28E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE28Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E28E SEP
    cpu.sep(0x20u);
    goto L_83E290;
L_83E290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE290u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE290u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E290 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E292;
L_83E292:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE292u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE292u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE292u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E292 TAY
    cpu.transfer("TAY");
    goto L_83E293;
L_83E293:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE293u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE293u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE293u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E293 SEC
    cpu.setFlag('C', true);
    goto L_83E294;
L_83E294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE294u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE294u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE294u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E294 SBC
    cpu.sbc(0x20u);
    goto L_83E296;
L_83E296:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE296u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE296u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE296u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E296 CMP
    cpu.compareA(0x80u);
    goto L_83E298;
L_83E298:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE298u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE298u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE298u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E298 TYA
    cpu.transfer("TYA");
    goto L_83E299;
L_83E299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE299u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE299u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E299 BCS -> $83E2A3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E2A3; }
    goto L_83E29B;
L_83E29B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE29Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE29Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE29Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E29B ADC
    cpu.adc(0x40u);
    goto L_83E29D;
L_83E29D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE29Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE29Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE29Du, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E29D STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E2A0;
L_83E2A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2A0 REP
    cpu.rep(0x20u);
    goto L_83E2A2;
L_83E2A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E2A2u);return;} hw.unresolvedReturn(0x83E2A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E2A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2A3 SBC
    cpu.sbc(0x40u);
    goto L_83E2A5;
L_83E2A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A5u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2A5 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E2A8;
L_83E2A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2A8 REP
    cpu.rep(0x20u);
    goto L_83E2AA;
L_83E2AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2AAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2AAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2AA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E2AAu);return;} hw.unresolvedReturn(0x83E2AAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E2AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ABu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ABu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2AB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E2ABu);return;} hw.unresolvedReturn(0x83E2ABu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E2AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ACu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ACu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2AC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2AF;
L_83E2AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2AFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2AF CMP
    cpu.compareA(0x500u);
    goto L_83E2B2;
L_83E2B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B2u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2B2 BMI -> $83E324
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E324; }
    goto L_83E2B4;
L_83E2B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2B4 SEP
    cpu.sep(0x20u);
    goto L_83E2B6;
L_83E2B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2B6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2B8;
L_83E2B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2B8 AND
    cpu.logicAnd(0xF0u);
    goto L_83E2BA;
L_83E2BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2BA SEC
    cpu.setFlag('C', true);
    goto L_83E2BB;
L_83E2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BBu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BBu, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2BB SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_83E2BE;
L_83E2BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2BE BEQ -> $83E2CD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E2CD; }
    goto L_83E2C0;
L_83E2C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C0 ASL
    cpu.aslA();
    goto L_83E2C1;
L_83E2C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C1 LDA
    cpu.setA(0x82u, 8);
    goto L_83E2C3;
L_83E2C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C3 BCC -> $83E2C7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E2C7; }
    goto L_83E2C5;
L_83E2C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C5 LDA
    cpu.setA(0x81u, 8);
    goto L_83E2C7;
L_83E2C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C7u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C7 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E2CA;
L_83E2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2CA REP
    cpu.rep(0x20u);
    goto L_83E2CC;
L_83E2CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CCu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2CC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E2CCu);return;} hw.unresolvedReturn(0x83E2CCu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E2CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2CD LDA
    cpu.setA(0x80u, 8);
    goto L_83E2CF;
L_83E2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CFu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2CF STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E2D2;
L_83E2D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D2u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2D2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2D5;
L_83E2D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2D5 REP
    cpu.rep(0x20u);
    goto L_83E2D7;
L_83E2D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2D7 BEQ -> $83E323
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E323; }
    goto L_83E2D9;
L_83E2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D9u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2D9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2DC;
L_83E2DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2DC BNE -> $83E303
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E303; }
    goto L_83E2DE;
L_83E2DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DEu, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2DE JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE2E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE2E2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E2DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E2E2;
L_83E2E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2E2u,0x83E2E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E2u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2E2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2E5;
L_83E2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E5u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2E5 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83E2E7;
L_83E2E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E7u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2E7 BMI -> $83E306
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E306; }
    goto L_83E2E9;
L_83E2E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2E9 SEP
    cpu.sep(0x20u);
    goto L_83E2EB;
L_83E2EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2EB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2ED;
L_83E2ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EDu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2ED TAY
    cpu.transfer("TAY");
    goto L_83E2EE;
L_83E2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2EE SEC
    cpu.setFlag('C', true);
    goto L_83E2EF;
L_83E2EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EFu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2EF SBC
    cpu.sbc(0x20u);
    goto L_83E2F1;
L_83E2F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F1 CMP
    cpu.compareA(0x80u);
    goto L_83E2F3;
L_83E2F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F3u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F3 TYA
    cpu.transfer("TYA");
    goto L_83E2F4;
L_83E2F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F4u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F4 BCS -> $83E2FE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E2FE; }
    goto L_83E2F6;
L_83E2F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F6u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F6 SBC
    cpu.sbc(0x3Fu);
    goto L_83E2F8;
L_83E2F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F8u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F8 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E2FB;
L_83E2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2FB REP
    cpu.rep(0x20u);
    goto L_83E2FD;
L_83E2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2FD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E2FDu);return;} hw.unresolvedReturn(0x83E2FDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E2FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FEu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2FE ADC
    cpu.adc(0x3Fu);
    goto L_83E300;
L_83E300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE300u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE300u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E300 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E303;
L_83E303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE303u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE303u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE303u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E303 REP
    cpu.rep(0x20u);
    goto L_83E305;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE303u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE303u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E303 REP
    cpu.rep(0x20u);
    goto L_83E305;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE303u,0x83E303u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE305u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE305u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E305 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E305u);return;} hw.unresolvedReturn(0x83E305u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE306u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE306u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E306 SEP
    cpu.sep(0x20u);
    goto L_83E308;
L_83E308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE308u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE308u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E308 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E30A;
L_83E30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E30A TAY
    cpu.transfer("TAY");
    goto L_83E30B;
L_83E30B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E30B SEC
    cpu.setFlag('C', true);
    goto L_83E30C;
L_83E30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E30C SBC
    cpu.sbc(0x20u);
    goto L_83E30E;
L_83E30E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E30E CMP
    cpu.compareA(0x80u);
    goto L_83E310;
L_83E310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE310u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE310u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E310 TYA
    cpu.transfer("TYA");
    goto L_83E311;
L_83E311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE311u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE311u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E311 BCS -> $83E31B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E31B; }
    goto L_83E313;
L_83E313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE313u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE313u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E313 ADC
    cpu.adc(0x40u);
    goto L_83E315;
L_83E315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE315u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE315u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E315 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E318;
L_83E318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE318u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE318u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E318 REP
    cpu.rep(0x20u);
    goto L_83E31A;
L_83E31A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E31A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E31Au);return;} hw.unresolvedReturn(0x83E31Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E31B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E31B SBC
    cpu.sbc(0x40u);
    goto L_83E31D;
L_83E31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Du, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E31D STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E320;
L_83E320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE320u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE320u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E320 REP
    cpu.rep(0x20u);
    goto L_83E322;
L_83E322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE322u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE322u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E322 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E322u);return;} hw.unresolvedReturn(0x83E322u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE323u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE323u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E323 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E323u);return;} hw.unresolvedReturn(0x83E323u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE324u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE324u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E324 SEP
    cpu.sep(0x20u);
    goto L_83E326;
L_83E326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE326u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE326u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E326 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E328;
L_83E328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE328u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE328u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E328 AND
    cpu.logicAnd(0xF0u);
    goto L_83E32A;
L_83E32A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E32A SEC
    cpu.setFlag('C', true);
    goto L_83E32B;
L_83E32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Bu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Bu, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E32B SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16));
    goto L_83E32E;
L_83E32E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E32E BEQ -> $83E33D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E33D; }
    goto L_83E330;
L_83E330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E330 ASL
    cpu.aslA();
    goto L_83E331;
L_83E331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE331u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE331u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E331 LDA
    cpu.setA(0x82u, 8);
    goto L_83E333;
L_83E333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E333 BCC -> $83E337
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E337; }
    goto L_83E335;
L_83E335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE335u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE335u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E335 LDA
    cpu.setA(0x81u, 8);
    goto L_83E337;
L_83E337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE337u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E337 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E33A;
L_83E33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E33A REP
    cpu.rep(0x20u);
    goto L_83E33C;
L_83E33C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E33C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E33Cu);return;} hw.unresolvedReturn(0x83E33Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E33D LDA
    cpu.setA(0x80u, 8);
    goto L_83E33F;
L_83E33F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Fu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E33F STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E342;
L_83E342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE342u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE342u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E342 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E345;
L_83E345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE345u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE345u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E345 REP
    cpu.rep(0x20u);
    goto L_83E347;
L_83E347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE347u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE347u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E347 BEQ -> $83E393
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E393u,0x83E347u); return; }
    goto L_83E349;
L_83E349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E349 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E34C;
L_83E34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E34C BNE -> $83E373
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E373u,0x83E34Cu); return; }
    goto L_83E34E;
L_83E34E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Eu, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E34E JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE351u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE352u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E34Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E352;
L_83E352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE352u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE352u,0x83E352u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE352u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE352u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E352 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E355;
L_83E355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE355u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE355u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E355 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83E357;
L_83E357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE357u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE357u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E357 BMI -> $83E376
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E376u,0x83E357u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE359u,0x83E357u); return;
}

void sub_83D546_E0M0X0CQ_part4(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83DA43u: goto L_83DA43;
    case 0x83DA45u: goto L_83DA45;
    case 0x83DA48u: goto L_83DA48;
    case 0x83DA4Au: goto L_83DA4A;
    case 0x83E21Eu: goto L_83E21E;
    case 0x83E221u: goto L_83E221;
    case 0x83E222u: goto L_83E222;
    case 0x83E224u: goto L_83E224;
    case 0x83E227u: goto L_83E227;
    case 0x83E228u: goto L_83E228;
    case 0x83E22Au: goto L_83E22A;
    case 0x83E22Du: goto L_83E22D;
    case 0x83E22Fu: goto L_83E22F;
    case 0x83E232u: goto L_83E232;
    case 0x83E235u: goto L_83E235;
    case 0x83E238u: goto L_83E238;
    case 0x83E23Au: goto L_83E23A;
    case 0x83E23Cu: goto L_83E23C;
    case 0x83E23Eu: goto L_83E23E;
    case 0x83E240u: goto L_83E240;
    case 0x83E242u: goto L_83E242;
    case 0x83E243u: goto L_83E243;
    case 0x83E246u: goto L_83E246;
    case 0x83E248u: goto L_83E248;
    case 0x83E249u: goto L_83E249;
    case 0x83E24Bu: goto L_83E24B;
    case 0x83E24Du: goto L_83E24D;
    case 0x83E24Fu: goto L_83E24F;
    case 0x83E252u: goto L_83E252;
    case 0x83E254u: goto L_83E254;
    case 0x83E255u: goto L_83E255;
    case 0x83E257u: goto L_83E257;
    case 0x83E25Au: goto L_83E25A;
    case 0x83E25Du: goto L_83E25D;
    case 0x83E25Fu: goto L_83E25F;
    case 0x83E261u: goto L_83E261;
    case 0x83E264u: goto L_83E264;
    case 0x83E266u: goto L_83E266;
    case 0x83E26Au: goto L_83E26A;
    case 0x83E26Du: goto L_83E26D;
    case 0x83E26Fu: goto L_83E26F;
    case 0x83E271u: goto L_83E271;
    case 0x83E273u: goto L_83E273;
    case 0x83E275u: goto L_83E275;
    case 0x83E276u: goto L_83E276;
    case 0x83E277u: goto L_83E277;
    case 0x83E279u: goto L_83E279;
    case 0x83E27Bu: goto L_83E27B;
    case 0x83E27Cu: goto L_83E27C;
    case 0x83E27Eu: goto L_83E27E;
    case 0x83E280u: goto L_83E280;
    case 0x83E283u: goto L_83E283;
    case 0x83E285u: goto L_83E285;
    case 0x83E286u: goto L_83E286;
    case 0x83E288u: goto L_83E288;
    case 0x83E28Bu: goto L_83E28B;
    case 0x83E28Du: goto L_83E28D;
    case 0x83E28Eu: goto L_83E28E;
    case 0x83E290u: goto L_83E290;
    case 0x83E292u: goto L_83E292;
    case 0x83E293u: goto L_83E293;
    case 0x83E294u: goto L_83E294;
    case 0x83E296u: goto L_83E296;
    case 0x83E298u: goto L_83E298;
    case 0x83E299u: goto L_83E299;
    case 0x83E29Bu: goto L_83E29B;
    case 0x83E29Du: goto L_83E29D;
    case 0x83E2A0u: goto L_83E2A0;
    case 0x83E2A2u: goto L_83E2A2;
    case 0x83E2A3u: goto L_83E2A3;
    case 0x83E2A5u: goto L_83E2A5;
    case 0x83E2A8u: goto L_83E2A8;
    case 0x83E2AAu: goto L_83E2AA;
    case 0x83E2ABu: goto L_83E2AB;
    case 0x83E2ACu: goto L_83E2AC;
    case 0x83E2AFu: goto L_83E2AF;
    case 0x83E2B2u: goto L_83E2B2;
    case 0x83E2B4u: goto L_83E2B4;
    case 0x83E2B6u: goto L_83E2B6;
    case 0x83E2B8u: goto L_83E2B8;
    case 0x83E2BAu: goto L_83E2BA;
    case 0x83E2BBu: goto L_83E2BB;
    case 0x83E2BEu: goto L_83E2BE;
    case 0x83E2C0u: goto L_83E2C0;
    case 0x83E2C1u: goto L_83E2C1;
    case 0x83E2C3u: goto L_83E2C3;
    case 0x83E2C5u: goto L_83E2C5;
    case 0x83E2C7u: goto L_83E2C7;
    case 0x83E2CAu: goto L_83E2CA;
    case 0x83E2CCu: goto L_83E2CC;
    case 0x83E2CDu: goto L_83E2CD;
    case 0x83E2CFu: goto L_83E2CF;
    case 0x83E2D2u: goto L_83E2D2;
    case 0x83E2D5u: goto L_83E2D5;
    case 0x83E2D7u: goto L_83E2D7;
    case 0x83E2D9u: goto L_83E2D9;
    case 0x83E2DCu: goto L_83E2DC;
    case 0x83E2DEu: goto L_83E2DE;
    case 0x83E2E2u: goto L_83E2E2;
    case 0x83E2E5u: goto L_83E2E5;
    case 0x83E2E7u: goto L_83E2E7;
    case 0x83E2E9u: goto L_83E2E9;
    case 0x83E2EBu: goto L_83E2EB;
    case 0x83E2EDu: goto L_83E2ED;
    case 0x83E2EEu: goto L_83E2EE;
    case 0x83E2EFu: goto L_83E2EF;
    case 0x83E2F1u: goto L_83E2F1;
    case 0x83E2F3u: goto L_83E2F3;
    case 0x83E2F4u: goto L_83E2F4;
    case 0x83E2F6u: goto L_83E2F6;
    case 0x83E2F8u: goto L_83E2F8;
    case 0x83E2FBu: goto L_83E2FB;
    case 0x83E2FDu: goto L_83E2FD;
    case 0x83E2FEu: goto L_83E2FE;
    case 0x83E300u: goto L_83E300;
    case 0x83E303u: goto L_83E303;
    case 0x83E305u: goto L_83E305;
    case 0x83E306u: goto L_83E306;
    case 0x83E308u: goto L_83E308;
    case 0x83E30Au: goto L_83E30A;
    case 0x83E30Bu: goto L_83E30B;
    case 0x83E30Cu: goto L_83E30C;
    case 0x83E30Eu: goto L_83E30E;
    case 0x83E310u: goto L_83E310;
    case 0x83E311u: goto L_83E311;
    case 0x83E313u: goto L_83E313;
    case 0x83E315u: goto L_83E315;
    case 0x83E318u: goto L_83E318;
    case 0x83E31Au: goto L_83E31A;
    case 0x83E31Bu: goto L_83E31B;
    case 0x83E31Du: goto L_83E31D;
    case 0x83E320u: goto L_83E320;
    case 0x83E322u: goto L_83E322;
    case 0x83E323u: goto L_83E323;
    case 0x83E324u: goto L_83E324;
    case 0x83E326u: goto L_83E326;
    case 0x83E328u: goto L_83E328;
    case 0x83E32Au: goto L_83E32A;
    case 0x83E32Bu: goto L_83E32B;
    case 0x83E32Eu: goto L_83E32E;
    case 0x83E330u: goto L_83E330;
    case 0x83E331u: goto L_83E331;
    case 0x83E333u: goto L_83E333;
    case 0x83E335u: goto L_83E335;
    case 0x83E337u: goto L_83E337;
    case 0x83E33Au: goto L_83E33A;
    case 0x83E33Cu: goto L_83E33C;
    case 0x83E33Du: goto L_83E33D;
    case 0x83E33Fu: goto L_83E33F;
    case 0x83E342u: goto L_83E342;
    case 0x83E345u: goto L_83E345;
    case 0x83E347u: goto L_83E347;
    case 0x83E349u: goto L_83E349;
    case 0x83E34Cu: goto L_83E34C;
    case 0x83E34Eu: goto L_83E34E;
    case 0x83E352u: goto L_83E352;
    case 0x83E355u: goto L_83E355;
    case 0x83E357u: goto L_83E357;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83DA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83DA43 LDA
    cpu.setA(0x80u, 8);
    goto L_83DA45;
L_83DA45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA45u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA45u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83DA45 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83DA48;
L_83DA48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA48u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA48u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83DA48 REP
    cpu.rep(0x20u);
    goto L_83DA4A;
L_83DA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDA4Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83DA4A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83DA4Au);return;} hw.unresolvedReturn(0x83DA4Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E21E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE21Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE21Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE21Eu, 6u, 3u, cpu.address("absx", 0x10DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E21E STZ
    hw.write(cpu.address("absx", 0x10DAu), 0, cpu.m8?8:16);
    goto L_83E221;
L_83E221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE221u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE221u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E221 LSR
    cpu.lsrA();
    goto L_83E222;
L_83E222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE222u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE222u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E222 BCC -> $83E227
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E227; }
    goto L_83E224;
L_83E224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE224u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE224u, 3u, 3u, cpu.address("abs", 0xE4FBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E224 JMP -> $83E4FB
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xE4FBu),0x83E224u); return;
L_83E227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE227u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE227u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E227 LSR
    cpu.lsrA();
    goto L_83E228;
L_83E228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE228u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE228u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E228 BCS -> $83E22D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E22D; }
    goto L_83E22A;
L_83E22A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE22Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Au, 3u, 3u, cpu.address("abs", 0xE394u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E22A JMP -> $83E394
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xE394u),0x83E22Au); return;
L_83E22D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE22Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E22D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E22F;
L_83E22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Fu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE22Fu, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E22F SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16));
    goto L_83E232;
L_83E232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE232u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE232u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E232 ADC
    cpu.adc(0x14u);
    goto L_83E235;
L_83E235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE235u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE235u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E235 CMP
    cpu.compareA(0x28u);
    goto L_83E238;
L_83E238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE238u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE238u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E238 BCC -> $83E2B4
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E2B4; }
    goto L_83E23A;
L_83E23A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE23Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E23A BPL -> $83E2AC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E2AC; }
    goto L_83E23C;
L_83E23C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE23Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E23C SEP
    cpu.sep(0x20u);
    goto L_83E23E;
L_83E23E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE23Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Eu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E23E LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E240;
L_83E240:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE240u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE240u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE240u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E240 AND
    cpu.logicAnd(0xF0u);
    goto L_83E242;
L_83E242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE242u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE242u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E242 SEC
    cpu.setFlag('C', true);
    goto L_83E243;
L_83E243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE243u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE243u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E243 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83E246;
L_83E246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE246u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE246u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E246 BEQ -> $83E255
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E255; }
    goto L_83E248;
L_83E248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE248u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE248u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E248 ASL
    cpu.aslA();
    goto L_83E249;
L_83E249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE249u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE249u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E249 LDA
    cpu.setA(0x82u, 8);
    goto L_83E24B;
L_83E24B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E24B BCC -> $83E24F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E24F; }
    goto L_83E24D;
L_83E24D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E24D LDA
    cpu.setA(0x81u, 8);
    goto L_83E24F;
L_83E24F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Fu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E24F STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E252;
L_83E252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE252u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE252u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E252 REP
    cpu.rep(0x20u);
    goto L_83E254;
L_83E254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE254u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE254u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E254 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E254u);return;} hw.unresolvedReturn(0x83E254u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE255u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE255u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE255u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E255 LDA
    cpu.setA(0x80u, 8);
    goto L_83E257;
L_83E257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE257u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE257u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E257 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E25A;
L_83E25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE25Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Au, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E25A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E25D;
L_83E25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E25D REP
    cpu.rep(0x20u);
    goto L_83E25F;
L_83E25F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE25Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E25F BEQ -> $83E2AB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E2AB; }
    goto L_83E261;
L_83E261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE261u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE261u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E261 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E264;
L_83E264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE264u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE264u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E264 BNE -> $83E28B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E28B; }
    goto L_83E266;
L_83E266:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE266u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE266u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE266u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E266 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE269u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE26Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E266u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E26A;
L_83E26A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE26Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE26Au,0x83E26Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Au, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E26A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E26D;
L_83E26D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE26Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Du,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E26D CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83E26F;
L_83E26F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE26Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E26F BMI -> $83E28E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E28E; }
    goto L_83E271;
L_83E271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE271u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE271u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E271 SEP
    cpu.sep(0x20u);
    goto L_83E273;
L_83E273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE273u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE273u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E273 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E275;
L_83E275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE275u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE275u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E275 TAY
    cpu.transfer("TAY");
    goto L_83E276;
L_83E276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE276u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE276u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E276 SEC
    cpu.setFlag('C', true);
    goto L_83E277;
L_83E277:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE277u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE277u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE277u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E277 SBC
    cpu.sbc(0x20u);
    goto L_83E279;
L_83E279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE279u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE279u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E279 CMP
    cpu.compareA(0x80u);
    goto L_83E27B;
L_83E27B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E27B TYA
    cpu.transfer("TYA");
    goto L_83E27C;
L_83E27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E27C BCS -> $83E286
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E286; }
    goto L_83E27E;
L_83E27E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E27E SBC
    cpu.sbc(0x3Fu);
    goto L_83E280;
L_83E280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE280u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE280u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE280u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E280 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E283;
L_83E283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE283u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE283u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E283 REP
    cpu.rep(0x20u);
    goto L_83E285;
L_83E285:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE285u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE285u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE285u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E285 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E285u);return;} hw.unresolvedReturn(0x83E285u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E286:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE286u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE286u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE286u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E286 ADC
    cpu.adc(0x3Fu);
    goto L_83E288;
L_83E288:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE288u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE288u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE288u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E288 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E28B;
L_83E28B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE28Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E28B REP
    cpu.rep(0x20u);
    goto L_83E28D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E28B REP
    cpu.rep(0x20u);
    goto L_83E28D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE28Bu,0x83E28Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E28D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE28Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E28D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E28Du);return;} hw.unresolvedReturn(0x83E28Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E28E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE28Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E28E SEP
    cpu.sep(0x20u);
    goto L_83E290;
L_83E290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE290u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE290u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E290 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E292;
L_83E292:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE292u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE292u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE292u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E292 TAY
    cpu.transfer("TAY");
    goto L_83E293;
L_83E293:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE293u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE293u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE293u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E293 SEC
    cpu.setFlag('C', true);
    goto L_83E294;
L_83E294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE294u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE294u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE294u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E294 SBC
    cpu.sbc(0x20u);
    goto L_83E296;
L_83E296:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE296u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE296u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE296u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E296 CMP
    cpu.compareA(0x80u);
    goto L_83E298;
L_83E298:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE298u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE298u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE298u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E298 TYA
    cpu.transfer("TYA");
    goto L_83E299;
L_83E299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE299u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE299u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E299 BCS -> $83E2A3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E2A3; }
    goto L_83E29B;
L_83E29B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE29Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE29Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE29Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E29B ADC
    cpu.adc(0x40u);
    goto L_83E29D;
L_83E29D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE29Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE29Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE29Du, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E29D STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E2A0;
L_83E2A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2A0 REP
    cpu.rep(0x20u);
    goto L_83E2A2;
L_83E2A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2A2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E2A2u);return;} hw.unresolvedReturn(0x83E2A2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E2A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2A3 SBC
    cpu.sbc(0x40u);
    goto L_83E2A5;
L_83E2A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A5u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2A5 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E2A8;
L_83E2A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2A8 REP
    cpu.rep(0x20u);
    goto L_83E2AA;
L_83E2AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2AAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2AAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2AA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E2AAu);return;} hw.unresolvedReturn(0x83E2AAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E2AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ABu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ABu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2AB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E2ABu);return;} hw.unresolvedReturn(0x83E2ABu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E2AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ACu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ACu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2AC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2AF;
L_83E2AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2AFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2AF CMP
    cpu.compareA(0x500u);
    goto L_83E2B2;
L_83E2B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B2u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2B2 BMI -> $83E324
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E324; }
    goto L_83E2B4;
L_83E2B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2B4 SEP
    cpu.sep(0x20u);
    goto L_83E2B6;
L_83E2B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2B6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2B8;
L_83E2B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2B8 AND
    cpu.logicAnd(0xF0u);
    goto L_83E2BA;
L_83E2BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2BA SEC
    cpu.setFlag('C', true);
    goto L_83E2BB;
L_83E2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BBu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BBu, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2BB SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_83E2BE;
L_83E2BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2BE BEQ -> $83E2CD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E2CD; }
    goto L_83E2C0;
L_83E2C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C0 ASL
    cpu.aslA();
    goto L_83E2C1;
L_83E2C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C1 LDA
    cpu.setA(0x82u, 8);
    goto L_83E2C3;
L_83E2C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C3 BCC -> $83E2C7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E2C7; }
    goto L_83E2C5;
L_83E2C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C5 LDA
    cpu.setA(0x81u, 8);
    goto L_83E2C7;
L_83E2C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2C7u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2C7 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E2CA;
L_83E2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2CA REP
    cpu.rep(0x20u);
    goto L_83E2CC;
L_83E2CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CCu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2CC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E2CCu);return;} hw.unresolvedReturn(0x83E2CCu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E2CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2CD LDA
    cpu.setA(0x80u, 8);
    goto L_83E2CF;
L_83E2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2CFu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2CF STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E2D2;
L_83E2D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D2u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2D2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2D5;
L_83E2D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2D5 REP
    cpu.rep(0x20u);
    goto L_83E2D7;
L_83E2D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2D7 BEQ -> $83E323
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E323; }
    goto L_83E2D9;
L_83E2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2D9u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2D9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2DC;
L_83E2DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2DC BNE -> $83E303
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E303; }
    goto L_83E2DE;
L_83E2DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2DEu, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2DE JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE2E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE2E2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E2DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E2E2;
L_83E2E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE2E2u,0x83E2E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E2u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2E2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2E5;
L_83E2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E5u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2E5 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83E2E7;
L_83E2E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E7u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2E7 BMI -> $83E306
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E306; }
    goto L_83E2E9;
L_83E2E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2E9 SEP
    cpu.sep(0x20u);
    goto L_83E2EB;
L_83E2EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2EB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E2ED;
L_83E2ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EDu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2ED TAY
    cpu.transfer("TAY");
    goto L_83E2EE;
L_83E2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2EE SEC
    cpu.setFlag('C', true);
    goto L_83E2EF;
L_83E2EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EFu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2EF SBC
    cpu.sbc(0x20u);
    goto L_83E2F1;
L_83E2F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F1 CMP
    cpu.compareA(0x80u);
    goto L_83E2F3;
L_83E2F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F3u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F3 TYA
    cpu.transfer("TYA");
    goto L_83E2F4;
L_83E2F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F4u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F4 BCS -> $83E2FE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E2FE; }
    goto L_83E2F6;
L_83E2F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F6u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F6 SBC
    cpu.sbc(0x3Fu);
    goto L_83E2F8;
L_83E2F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2F8u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2F8 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E2FB;
L_83E2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2FB REP
    cpu.rep(0x20u);
    goto L_83E2FD;
L_83E2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E2FD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E2FDu);return;} hw.unresolvedReturn(0x83E2FDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E2FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FEu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E2FE ADC
    cpu.adc(0x3Fu);
    goto L_83E300;
L_83E300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE300u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE300u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E300 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E303;
L_83E303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE303u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE303u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE303u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E303 REP
    cpu.rep(0x20u);
    goto L_83E305;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE303u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE303u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E303 REP
    cpu.rep(0x20u);
    goto L_83E305;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE303u,0x83E303u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE305u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE305u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E305 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E305u);return;} hw.unresolvedReturn(0x83E305u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE306u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE306u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E306 SEP
    cpu.sep(0x20u);
    goto L_83E308;
L_83E308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE308u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE308u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E308 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E30A;
L_83E30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E30A TAY
    cpu.transfer("TAY");
    goto L_83E30B;
L_83E30B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E30B SEC
    cpu.setFlag('C', true);
    goto L_83E30C;
L_83E30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E30C SBC
    cpu.sbc(0x20u);
    goto L_83E30E;
L_83E30E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE30Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE30Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E30E CMP
    cpu.compareA(0x80u);
    goto L_83E310;
L_83E310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE310u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE310u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E310 TYA
    cpu.transfer("TYA");
    goto L_83E311;
L_83E311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE311u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE311u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E311 BCS -> $83E31B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E31B; }
    goto L_83E313;
L_83E313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE313u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE313u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E313 ADC
    cpu.adc(0x40u);
    goto L_83E315;
L_83E315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE315u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE315u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E315 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E318;
L_83E318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE318u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE318u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E318 REP
    cpu.rep(0x20u);
    goto L_83E31A;
L_83E31A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E31A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E31Au);return;} hw.unresolvedReturn(0x83E31Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E31B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E31B SBC
    cpu.sbc(0x40u);
    goto L_83E31D;
L_83E31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE31Du, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E31D STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E320;
L_83E320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE320u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE320u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E320 REP
    cpu.rep(0x20u);
    goto L_83E322;
L_83E322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE322u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE322u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E322 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E322u);return;} hw.unresolvedReturn(0x83E322u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE323u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE323u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E323 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E323u);return;} hw.unresolvedReturn(0x83E323u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE324u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE324u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E324 SEP
    cpu.sep(0x20u);
    goto L_83E326;
L_83E326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE326u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE326u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E326 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E328;
L_83E328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE328u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE328u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E328 AND
    cpu.logicAnd(0xF0u);
    goto L_83E32A;
L_83E32A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E32A SEC
    cpu.setFlag('C', true);
    goto L_83E32B;
L_83E32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Bu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Bu, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E32B SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16));
    goto L_83E32E;
L_83E32E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE32Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE32Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E32E BEQ -> $83E33D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E33D; }
    goto L_83E330;
L_83E330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE330u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E330 ASL
    cpu.aslA();
    goto L_83E331;
L_83E331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE331u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE331u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E331 LDA
    cpu.setA(0x82u, 8);
    goto L_83E333;
L_83E333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE333u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E333 BCC -> $83E337
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E337; }
    goto L_83E335;
L_83E335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE335u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE335u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E335 LDA
    cpu.setA(0x81u, 8);
    goto L_83E337;
L_83E337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE337u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE337u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E337 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E33A;
L_83E33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E33A REP
    cpu.rep(0x20u);
    goto L_83E33C;
L_83E33C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E33C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E33Cu);return;} hw.unresolvedReturn(0x83E33Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E33D LDA
    cpu.setA(0x80u, 8);
    goto L_83E33F;
L_83E33F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE33Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE33Fu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E33F STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E342;
L_83E342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE342u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE342u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E342 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E345;
L_83E345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE345u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE345u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E345 REP
    cpu.rep(0x20u);
    goto L_83E347;
L_83E347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE347u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE347u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E347 BEQ -> $83E393
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E393u,0x83E347u); return; }
    goto L_83E349;
L_83E349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE349u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E349 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E34C;
L_83E34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E34C BNE -> $83E373
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E373u,0x83E34Cu); return; }
    goto L_83E34E;
L_83E34E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE34Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE34Eu, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E34E JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE351u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE352u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E34Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E352;
L_83E352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE352u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE352u,0x83E352u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE352u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE352u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E352 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E355;
L_83E355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE355u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE355u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E355 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83E357;
L_83E357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE357u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE357u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E357 BMI -> $83E376
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83E376u,0x83E357u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE359u,0x83E357u); return;
}

void sub_848A76_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848A76u: goto L_848A76;
    case 0x848A79u: goto L_848A79;
    case 0x848A7Bu: goto L_848A7B;
    case 0x848A7Du: goto L_848A7D;
    case 0x848A80u: goto L_848A80;
    case 0x848A82u: goto L_848A82;
    case 0x848A85u: goto L_848A85;
    case 0x848A86u: goto L_848A86;
    case 0x848A89u: goto L_848A89;
    case 0x848A8Du: goto L_848A8D;
    case 0x848A90u: goto L_848A90;
    case 0x848A93u: goto L_848A93;
    case 0x848A96u: goto L_848A96;
    case 0x848A99u: goto L_848A99;
    case 0x848A9Du: goto L_848A9D;
    case 0x848AA0u: goto L_848AA0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848A76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A76u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A76u, 5u, 3u, cpu.address("abs", 0x1FA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A76 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848A79;
L_848A79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A79u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A79 BEQ -> $848A86
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848A86; }
    goto L_848A7B;
L_848A7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A7B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848A7D;
L_848A7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Du,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A7D BIT
    cpu.bit(0x1u, true);
    goto L_848A80;
L_848A80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A80u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A80u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A80 BEQ -> $848A85
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848A85; }
    goto L_848A82;
L_848A82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A82u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A82u, 8u, 3u, cpu.address("abs", 0x1FA0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A82 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1FA0u), cpu.m8?8:16);
    goto L_848A85;
L_848A85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A85u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A85u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A85 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848A85u);return;} hw.unresolvedReturn(0x848A85u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_848A86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A86u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A86u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A86 LDY
    cpu.setY(0x1Eu, 16);
    goto L_848A89;
L_848A89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u, 8u, 4u, 0x809955u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A89 JSL -> $809955 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A8Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A8Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809955u, 0x848A89u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A8D;
L_848A8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A8Du,0x848A8Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Du, 5u, 3u, cpu.address("abs", 0x1FDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A8D STZ
    hw.write(cpu.address("abs", 0x1FDEu), 0, cpu.m8?8:16);
    goto L_848A90;
L_848A90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A90u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A90u, 5u, 3u, cpu.address("abs", 0x1FDCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A90 STZ
    hw.write(cpu.address("abs", 0x1FDCu), 0, cpu.m8?8:16);
    goto L_848A93;
L_848A93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A93u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A93u, 5u, 3u, cpu.address("abs", 0x1FB8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A93 STZ
    hw.write(cpu.address("abs", 0x1FB8u), 0, cpu.m8?8:16);
    goto L_848A96;
L_848A96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A96u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A96u, 5u, 3u, cpu.address("abs", 0x1FE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A96 STZ
    hw.write(cpu.address("abs", 0x1FE0u), 0, cpu.m8?8:16);
    goto L_848A99;
L_848A99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A99u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A99u, 8u, 4u, 0x808C38u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A99 JSL -> $808C38 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A9Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A9Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C38u, 0x848A99u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A9D;
L_848A9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A9Du,0x848A9Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Du, 8u, 3u, cpu.address("abs", 0x05A0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A9D INC
    cpu.incMem(hw, cpu.address("abs", 0x5A0u), cpu.m8?8:16);
    goto L_848AA0;
L_848AA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AA0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848AA0u);return;} hw.unresolvedReturn(0x848AA0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_848A76_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848A76u: goto L_848A76;
    case 0x848A79u: goto L_848A79;
    case 0x848A7Bu: goto L_848A7B;
    case 0x848A7Du: goto L_848A7D;
    case 0x848A80u: goto L_848A80;
    case 0x848A82u: goto L_848A82;
    case 0x848A85u: goto L_848A85;
    case 0x848A86u: goto L_848A86;
    case 0x848A89u: goto L_848A89;
    case 0x848A8Du: goto L_848A8D;
    case 0x848A90u: goto L_848A90;
    case 0x848A93u: goto L_848A93;
    case 0x848A96u: goto L_848A96;
    case 0x848A99u: goto L_848A99;
    case 0x848A9Du: goto L_848A9D;
    case 0x848AA0u: goto L_848AA0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848A76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A76u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A76u, 5u, 3u, cpu.address("abs", 0x1FA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A76 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848A79;
L_848A79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A79u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A79 BEQ -> $848A86
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848A86; }
    goto L_848A7B;
L_848A7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A7B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848A7D;
L_848A7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Du,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A7Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A7D BIT
    cpu.bit(0x1u, true);
    goto L_848A80;
L_848A80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A80u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A80u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A80 BEQ -> $848A85
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848A85; }
    goto L_848A82;
L_848A82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A82u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A82u, 8u, 3u, cpu.address("abs", 0x1FA0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A82 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1FA0u), cpu.m8?8:16);
    goto L_848A85;
L_848A85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A85u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A85u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A85 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848A85u);return;} hw.unresolvedReturn(0x848A85u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_848A86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A86u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A86u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A86 LDY
    cpu.setY(0x1Eu, 16);
    goto L_848A89;
L_848A89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A89u, 8u, 4u, 0x809955u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A89 JSL -> $809955 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A8Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A8Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809955u, 0x848A89u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A8D;
L_848A8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A8Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A8Du,0x848A8Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A8Du, 5u, 3u, cpu.address("abs", 0x1FDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A8D STZ
    hw.write(cpu.address("abs", 0x1FDEu), 0, cpu.m8?8:16);
    goto L_848A90;
L_848A90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A90u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A90u, 5u, 3u, cpu.address("abs", 0x1FDCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A90 STZ
    hw.write(cpu.address("abs", 0x1FDCu), 0, cpu.m8?8:16);
    goto L_848A93;
L_848A93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A93u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A93u, 5u, 3u, cpu.address("abs", 0x1FB8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A93 STZ
    hw.write(cpu.address("abs", 0x1FB8u), 0, cpu.m8?8:16);
    goto L_848A96;
L_848A96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A96u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A96u, 5u, 3u, cpu.address("abs", 0x1FE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A96 STZ
    hw.write(cpu.address("abs", 0x1FE0u), 0, cpu.m8?8:16);
    goto L_848A99;
L_848A99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A99u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A99u, 8u, 4u, 0x808C38u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A99 JSL -> $808C38 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A9Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A9Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C38u, 0x848A99u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A9D;
L_848A9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A9Du,0x848A9Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Du, 8u, 3u, cpu.address("abs", 0x05A0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A9D INC
    cpu.incMem(hw, cpu.address("abs", 0x5A0u), cpu.m8?8:16);
    goto L_848AA0;
L_848AA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AA0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848AA0u);return;} hw.unresolvedReturn(0x848AA0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_848BE8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848BE8u: goto L_848BE8;
    case 0x848BEBu: goto L_848BEB;
    case 0x848BEEu: goto L_848BEE;
    case 0x848BF1u: goto L_848BF1;
    case 0x848BF4u: goto L_848BF4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848BE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE8u, 5u, 3u, cpu.address("abs", 0x1AC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848BE8 STZ
    hw.write(cpu.address("abs", 0x1AC0u), 0, cpu.m8?8:16);
    goto L_848BEB;
L_848BEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEBu, 5u, 3u, cpu.address("abs", 0x1AC2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848BEB STZ
    hw.write(cpu.address("abs", 0x1AC2u), 0, cpu.m8?8:16);
    goto L_848BEE;
L_848BEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848BEE LDA
    cpu.setA(0x1Bu, 16);
    goto L_848BF1;
L_848BF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF1u, 5u, 3u, cpu.address("abs", 0x1AC4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848BF1 STA
    hw.write(cpu.address("abs", 0x1AC4u), cpu.a, cpu.m8?8:16);
    goto L_848BF4;
L_848BF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848BF4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848BF4u);return;} hw.unresolvedReturn(0x848BF4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_848C01_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848C01u: goto L_848C01;
    case 0x848C04u: goto L_848C04;
    case 0x848C07u: goto L_848C07;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848C01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C01u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C01u, 6u, 3u, cpu.address("abs", 0x8C08u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848C01 JSR -> $848C08 stack real
    { cpu.push16Value(hw,0x8C03u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C04u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8C08u), 0x848C01u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848C04;
L_848C04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C04u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u, 6u, 3u, cpu.address("abs", 0x8C1Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848C04 JSR -> $848C1B stack real
    { cpu.push16Value(hw,0x8C06u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C07u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8C1Bu), 0x848C04u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848C07;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C04u, 6u, 3u, cpu.address("abs", 0x8C1Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848C04 JSR -> $848C1B stack real
    { cpu.push16Value(hw,0x8C06u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8C07u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8C1Bu), 0x848C04u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848C07;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C04u,0x848C04u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848C07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C07u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848C07 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848C07u);return;} hw.unresolvedReturn(0x848C07u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C07u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848C07 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848C07u);return;} hw.unresolvedReturn(0x848C07u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8C07u,0x848C07u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

