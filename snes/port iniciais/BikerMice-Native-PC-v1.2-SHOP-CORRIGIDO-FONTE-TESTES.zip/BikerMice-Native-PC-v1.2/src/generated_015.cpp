#include "generated.hpp"
void sub_208800_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x208800u: goto L_208800;
    case 0x208802u: goto L_208802;
    case 0x208804u: goto L_208804;
    case 0x208806u: goto L_208806;
    case 0x208807u: goto L_208807;
    case 0x208809u: goto L_208809;
    case 0x20880Bu: goto L_20880B;
    case 0x20880Cu: goto L_20880C;
    case 0x20880Eu: goto L_20880E;
    case 0x208810u: goto L_208810;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_208800:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8800u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8800u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8800u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208800 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x80u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_208802;
L_208802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8802u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8802u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x79u) & 0xFFFFu), 2u, 0u);
    // $208802 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x79u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_208804;
L_208804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8804u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8804u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8804u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x72u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208804 STA
    hw.write(cpu.address("dp", 0x72u), cpu.a, cpu.m8?8:16);
    goto L_208806;
L_208806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8806u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8806u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208806 INY
    cpu.inc('Y');
    goto L_208807;
L_208807:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8807u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8807u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8807u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x79u) & 0xFFFFu), 2u, 0u);
    // $208807 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x79u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_208809;
L_208809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8809u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8809u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208809 STA
    hw.write(cpu.address("dp", 0x71u), cpu.a, cpu.m8?8:16);
    goto L_20880B;
L_20880B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20880B INY
    cpu.inc('Y');
    goto L_20880C;
L_20880C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Cu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x79u) & 0xFFFFu), 2u, 0u);
    // $20880C LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x79u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_20880E;
L_20880E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x70u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20880E STA
    hw.write(cpu.address("dp", 0x70u), cpu.a, cpu.m8?8:16);
    goto L_208810;
L_208810:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8810u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8810u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8810u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $208810 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x208810u);return;} hw.unresolvedReturn(0x208810u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_808FA5_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808FA5u: goto L_808FA5;
    case 0x808FA8u: goto L_808FA8;
    case 0x808FAAu: goto L_808FAA;
    case 0x808FADu: goto L_808FAD;
    case 0x808FAFu: goto L_808FAF;
    case 0x808FB1u: goto L_808FB1;
    case 0x808FB3u: goto L_808FB3;
    case 0x808FB5u: goto L_808FB5;
    case 0x808FB7u: goto L_808FB7;
    case 0x808FB9u: goto L_808FB9;
    case 0x808FBBu: goto L_808FBB;
    case 0x808FBEu: goto L_808FBE;
    case 0x808FBFu: goto L_808FBF;
    case 0x808FC1u: goto L_808FC1;
    case 0x808FC3u: goto L_808FC3;
    case 0x808FC6u: goto L_808FC6;
    case 0x808FC7u: goto L_808FC7;
    case 0x808FC8u: goto L_808FC8;
    case 0x808FCAu: goto L_808FCA;
    case 0x808FCBu: goto L_808FCB;
    case 0x808FCDu: goto L_808FCD;
    case 0x808FCFu: goto L_808FCF;
    case 0x808FD1u: goto L_808FD1;
    case 0x808FD4u: goto L_808FD4;
    case 0x808FD5u: goto L_808FD5;
    case 0x808FD6u: goto L_808FD6;
    case 0x808FD7u: goto L_808FD7;
    case 0x808FD9u: goto L_808FD9;
    case 0x808FDBu: goto L_808FDB;
    case 0x808FDDu: goto L_808FDD;
    case 0x808FDFu: goto L_808FDF;
    case 0x808FE1u: goto L_808FE1;
    case 0x808FE3u: goto L_808FE3;
    case 0x808FE4u: goto L_808FE4;
    case 0x808FE6u: goto L_808FE6;
    case 0x808FE9u: goto L_808FE9;
    case 0x808FEBu: goto L_808FEB;
    case 0x808FEDu: goto L_808FED;
    case 0x808FEFu: goto L_808FEF;
    case 0x808FF0u: goto L_808FF0;
    case 0x808FF2u: goto L_808FF2;
    case 0x808FF5u: goto L_808FF5;
    case 0x808FF7u: goto L_808FF7;
    case 0x808FF9u: goto L_808FF9;
    case 0x808FFBu: goto L_808FFB;
    case 0x808FFDu: goto L_808FFD;
    case 0x808FFEu: goto L_808FFE;
    case 0x808FFFu: goto L_808FFF;
    case 0x809000u: goto L_809000;
    case 0x809002u: goto L_809002;
    case 0x809003u: goto L_809003;
    case 0x809006u: goto L_809006;
    case 0x809008u: goto L_809008;
    case 0x80900Au: goto L_80900A;
    case 0x80900Bu: goto L_80900B;
    case 0x80900Cu: goto L_80900C;
    case 0x80900Du: goto L_80900D;
    case 0x80900Eu: goto L_80900E;
    case 0x809010u: goto L_809010;
    case 0x809012u: goto L_809012;
    case 0x809014u: goto L_809014;
    case 0x809016u: goto L_809016;
    case 0x809019u: goto L_809019;
    case 0x80901Bu: goto L_80901B;
    case 0x80901Du: goto L_80901D;
    case 0x80901Fu: goto L_80901F;
    case 0x809020u: goto L_809020;
    case 0x809021u: goto L_809021;
    case 0x809022u: goto L_809022;
    case 0x809024u: goto L_809024;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808FA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA5u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FA5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808FA8;
L_808FA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FA8 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_808FAA;
L_808FAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAAu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAAu, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FAA LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808FAD;
L_808FAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FADu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FAD STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_808FAF;
L_808FAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAFu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FAF LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808FB1;
L_808FB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FB1 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_808FB3;
L_808FB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB3u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FB3 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808FB5;
L_808FB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FB5 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_808FB7;
L_808FB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FB7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808FB9;
L_808FB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB9u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FB9 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_808FBB;
L_808FBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FBB LDX
    cpu.setX(0x0u, 16);
    goto L_808FBE;
L_808FBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FBE SEC
    cpu.setFlag('C', true);
    goto L_808FBF;
L_808FBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBFu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FBFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FBF SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_808FC1;
L_808FC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FC1 BPL -> $808FC8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808FC8; }
    goto L_808FC3;
L_808FC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FC3 EOR
    cpu.logicXor(0xFFFFu);
    goto L_808FC6;
L_808FC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC6u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FC6 INC
    cpu.inc('A');
    goto L_808FC7;
L_808FC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC7u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FC7 INX
    cpu.inc('X');
    goto L_808FC8;
L_808FC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FC8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FC8 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_808FCA;
L_808FCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FCA SEC
    cpu.setFlag('C', true);
    goto L_808FCB;
L_808FCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FCB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808FCD;
L_808FCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FCD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    goto L_808FCF;
L_808FCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FCFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FCF BPL -> $808FD7
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808FD7; }
    goto L_808FD1;
L_808FD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD1u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FD1 EOR
    cpu.logicXor(0xFFFFu);
    goto L_808FD4;
L_808FD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD4u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FD4 INC
    cpu.inc('A');
    goto L_808FD5;
L_808FD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FD5 INX
    cpu.inc('X');
    goto L_808FD6;
L_808FD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD6u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FD6 INX
    cpu.inc('X');
    goto L_808FD7;
L_808FD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FD7 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_808FD9;
L_808FD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD9u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FD9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FD9 STX
    hw.write(cpu.address("dp", 0xEu), cpu.x, cpu.x8?8:16);
    goto L_808FDB;
L_808FDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDBu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FDB CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_808FDD;
L_808FDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDDu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FDD BCS -> $808FE6
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_808FE6; }
    goto L_808FDF;
L_808FDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FDF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808FE1;
L_808FE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FE1 BRA -> $808FF2
    goto L_808FF2;
L_808FE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FE3 LSR
    cpu.lsrA();
    goto L_808FE4;
L_808FE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE4u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FE4 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_808FE6;
L_808FE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FE6 CMP
    cpu.compareA(0x8u);
    goto L_808FE9;
L_808FE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE9u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FE9 BCS -> $808FE3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_808FE3; }
    goto L_808FEB;
L_808FEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FEB STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_808FED;
L_808FED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FED BRA -> $808FF9
    goto L_808FF9;
L_808FEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FEF LSR
    cpu.lsrA();
    goto L_808FF0;
L_808FF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF0u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FF0 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_808FF2;
L_808FF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FF2 CMP
    cpu.compareA(0x8u);
    goto L_808FF5;
L_808FF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FF5 BCS -> $808FEF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_808FEF; }
    goto L_808FF7;
L_808FF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FF7 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_808FF9;
L_808FF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FF9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FF9 SEP
    cpu.sep(0x20u);
    goto L_808FFB;
L_808FFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FFB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808FFD;
L_808FFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FFD ASL
    cpu.aslA();
    goto L_808FFE;
L_808FFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FFE ASL
    cpu.aslA();
    goto L_808FFF;
L_808FFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FFFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808FFF ASL
    cpu.aslA();
    goto L_809000;
L_809000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9000u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809000 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_809002;
L_809002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9002u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9002u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809002 TAX
    cpu.transfer("TAX");
    goto L_809003;
L_809003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9003u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9003u, 4u + 1u, 3u, cpu.address("absx", 0x8149u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809003 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8149u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809006;
L_809006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9006u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9006u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809006 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_809008;
L_809008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9008u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9008u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809008 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80900A;
L_80900A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80900A TXA
    cpu.transfer("TXA");
    goto L_80900B;
L_80900B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80900B INC
    cpu.inc('A');
    goto L_80900C;
L_80900C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80900C LSR
    cpu.lsrA();
    goto L_80900D;
L_80900D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80900D LSR
    cpu.lsrA();
    goto L_80900E;
L_80900E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80900E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809010;
L_809010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9010u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9010u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809010 BCC -> $809016
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809016; }
    goto L_809012;
L_809012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809012 ADC
    cpu.adc(0xF6u);
    goto L_809014;
L_809014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9014u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9014u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809014 EOR
    cpu.logicXor(0xFFu);
    goto L_809016;
L_809016:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9016u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9016u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9016u, 4u + 1u, 3u, cpu.address("absx", 0x8145u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809016 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x8145u), cpu.m8?8:16));
    goto L_809019;
L_809019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9019u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9019u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809019 AND
    cpu.logicAnd(0x1Fu);
    goto L_80901B;
L_80901B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80901B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80901D;
L_80901D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80901D REP
    cpu.rep(0x20u);
    goto L_80901F;
L_80901F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80901F ASL
    cpu.aslA();
    goto L_809020;
L_809020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9020u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9020u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809020 ASL
    cpu.aslA();
    goto L_809021;
L_809021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9021u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9021u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809021 ASL
    cpu.aslA();
    goto L_809022;
L_809022:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9022u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9022u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9022u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809022 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_809024;
L_809024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9024u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9024u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809024 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809024u);return;} hw.unresolvedReturn(0x809024u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809DD5_E0M0X0CQ_part5(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E99u: goto L_809E99;
    case 0x809E9Au: goto L_809E9A;
    case 0x809E9Cu: goto L_809E9C;
    case 0x809E9Du: goto L_809E9D;
    case 0x809EA0u: goto L_809EA0;
    case 0x809EA2u: goto L_809EA2;
    case 0x809EA3u: goto L_809EA3;
    case 0x809EA4u: goto L_809EA4;
    case 0x809EA5u: goto L_809EA5;
    case 0x809EA7u: goto L_809EA7;
    case 0x809EA8u: goto L_809EA8;
    case 0x809EA9u: goto L_809EA9;
    case 0x809EABu: goto L_809EAB;
    case 0x809EADu: goto L_809EAD;
    case 0x809EAEu: goto L_809EAE;
    case 0x809EAFu: goto L_809EAF;
    case 0x809EB1u: goto L_809EB1;
    case 0x809EB3u: goto L_809EB3;
    case 0x809EB5u: goto L_809EB5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E99u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E99u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E99u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E99 CLC
    cpu.setFlag('C', false);
    goto L_809E9A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E99u,0x809E99u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Au))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Au,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E9A ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16));
    goto L_809E9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E9Au,0x809E9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Cu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809E9C PHA
    cpu.push("PHA", hw);
    goto L_809E9D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E9Cu,0x809E9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Du))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Du, 4u + 1u, 3u, cpu.address("absy", 0x4801u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E9D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4801u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E9Du,0x809E9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA0u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA0u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA0 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16));
    goto L_809EA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA0u,0x809EA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA2u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA2u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809EA2 PHA
    cpu.push("PHA", hw);
    goto L_809EA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA2u,0x809EA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA3u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA3u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA3 XBA
    cpu.xba();
    goto L_809EA4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA3u,0x809EA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA4u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA4 LSR
    cpu.lsrA();
    goto L_809EA5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA4u,0x809EA4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA5u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EA7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA5u,0x809EA5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA7u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA7u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA7 ROR
    cpu.rorA();
    goto L_809EA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA7u,0x809EA7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA8u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA8 LSR
    cpu.lsrA();
    goto L_809EA9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA8u,0x809EA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA9u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA9u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EA9 BCS -> $809EB8
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809EB8u,0x809EA9u); return; }
    goto L_809EAB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA9u,0x809EA9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EABu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EAB STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_809EAD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EABu,0x809EABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EADu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EADu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EAD INY
    cpu.inc('Y');
    goto L_809EAE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EADu,0x809EADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EAEu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EAE INY
    cpu.inc('Y');
    goto L_809EAF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EAEu,0x809EAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EAFu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAFu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EAF DEC
    cpu.decMem(hw, cpu.address("dp", 0xFAu), cpu.m8?8:16);
    goto L_809EB1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EAFu,0x809EAFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB1u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EB1 BNE -> $809ED2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809ED2u,0x809EB1u); return; }
    goto L_809EB3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB1u,0x809EB1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB3u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EB3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809EB5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB3u,0x809EB3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB5u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB5u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB5u, 3u, 3u, cpu.address("abs", 0x9E3Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EB5 JMP -> $809E3E
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9E3Eu),0x809EB5u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB5u,0x809EB5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80AC95_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AC95u: goto L_80AC95;
    case 0x80AC99u: goto L_80AC99;
    case 0x80AC9Cu: goto L_80AC9C;
    case 0x80AC9Fu: goto L_80AC9F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AC95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC95u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC95u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AC95 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAC98u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAC99u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x80AC95u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AC99;
L_80AC99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC99u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC99u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC99u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC99 LDX
    cpu.setX(0x8000u, 16);
    goto L_80AC9C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC99u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC99u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC99 LDX
    cpu.setX(0x8000u, 16);
    goto L_80AC9C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAC99u,0x80AC99u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AC9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC9Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Cu, 6u, 3u, cpu.address("abs", 0xACA0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AC9C JSR -> $80ACA0 stack real
    { cpu.push16Value(hw,0xAC9Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAC9Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xACA0u), 0x80AC9Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AC9F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Cu, 6u, 3u, cpu.address("abs", 0xACA0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AC9C JSR -> $80ACA0 stack real
    { cpu.push16Value(hw,0xAC9Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAC9Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xACA0u), 0x80AC9Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AC9F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAC9Cu,0x80AC9Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AC9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC9Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAC9Fu,0x80AC9Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AC9F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AC9Fu);return;} hw.unresolvedReturn(0x80AC9Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80C8A8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C8A8u: goto L_80C8A8;
    case 0x80C8ABu: goto L_80C8AB;
    case 0x80C8ADu: goto L_80C8AD;
    case 0x80C8AFu: goto L_80C8AF;
    case 0x80C8B1u: goto L_80C8B1;
    case 0x80C8B3u: goto L_80C8B3;
    case 0x80C8B5u: goto L_80C8B5;
    case 0x80C8B7u: goto L_80C8B7;
    case 0x80C8B9u: goto L_80C8B9;
    case 0x80C8BBu: goto L_80C8BB;
    case 0x80C8BEu: goto L_80C8BE;
    case 0x80C8BFu: goto L_80C8BF;
    case 0x80C8C2u: goto L_80C8C2;
    case 0x80C8C3u: goto L_80C8C3;
    case 0x80C8C4u: goto L_80C8C4;
    case 0x80C8C6u: goto L_80C8C6;
    case 0x80C8C7u: goto L_80C8C7;
    case 0x80C8C9u: goto L_80C8C9;
    case 0x80C8CCu: goto L_80C8CC;
    case 0x80C8CDu: goto L_80C8CD;
    case 0x80C8D0u: goto L_80C8D0;
    case 0x80C8D1u: goto L_80C8D1;
    case 0x80C8D2u: goto L_80C8D2;
    case 0x80C8D4u: goto L_80C8D4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C8A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8A8 CMP
    cpu.compareA(0x100u);
    goto L_80C8AB;
L_80C8AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ABu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8AB BCS -> $80C8D4
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C8D4; }
    goto L_80C8AD;
L_80C8AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ADu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8AD SEP
    cpu.sep(0x20u);
    goto L_80C8AF;
L_80C8AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8AFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8AF CMP
    cpu.compareA(0x0u);
    goto L_80C8B1;
L_80C8B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8B1 BEQ -> $80C8D2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C8D2; }
    goto L_80C8B3;
L_80C8B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8B3 CMP
    cpu.compareA(0x80u);
    goto L_80C8B5;
L_80C8B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B5u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8B5 BCC -> $80C8C9
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C8C9; }
    goto L_80C8B7;
L_80C8B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8B7 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80C8B9;
L_80C8B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8B9 LDA
    cpu.setA(0x7Fu, 8);
    goto L_80C8BB;
L_80C8BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8BBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8BBu, 5u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8BB STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C8BE;
L_80C8BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8BEu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8BE TYA
    cpu.transfer("TYA");
    goto L_80C8BF;
L_80C8BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8BFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8BFu, 5u, 3u, cpu.address("absx", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8BF STA
    hw.write(cpu.address("absx", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_80C8C2;
L_80C8C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8C2 INX
    cpu.inc('X');
    goto L_80C8C3;
L_80C8C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8C3 INX
    cpu.inc('X');
    goto L_80C8C4;
L_80C8C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8C4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C8C6;
L_80C8C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8C6 SEC
    cpu.setFlag('C', true);
    goto L_80C8C7;
L_80C8C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C7u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8C7 SBC
    cpu.sbc(0x7Fu);
    goto L_80C8C9;
L_80C8C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C9u, 5u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8C9 STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C8CC;
L_80C8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CCu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8CC TYA
    cpu.transfer("TYA");
    goto L_80C8CD;
L_80C8CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CDu, 5u, 3u, cpu.address("absx", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8CD STA
    hw.write(cpu.address("absx", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_80C8D0;
L_80C8D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8D0 INX
    cpu.inc('X');
    goto L_80C8D1;
L_80C8D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8D1 INX
    cpu.inc('X');
    goto L_80C8D2;
L_80C8D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8D2 REP
    cpu.rep(0x20u);
    goto L_80C8D4;
L_80C8D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C8D4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C8D4u);return;} hw.unresolvedReturn(0x80C8D4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80D6B8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D6B8u: goto L_80D6B8;
    case 0x80D6BBu: goto L_80D6BB;
    case 0x80D6BEu: goto L_80D6BE;
    case 0x80D6C0u: goto L_80D6C0;
    case 0x80D6C2u: goto L_80D6C2;
    case 0x80D6C5u: goto L_80D6C5;
    case 0x80D6C8u: goto L_80D6C8;
    case 0x80D6CAu: goto L_80D6CA;
    case 0x80D6CCu: goto L_80D6CC;
    case 0x80D6CFu: goto L_80D6CF;
    case 0x80D6D1u: goto L_80D6D1;
    case 0x80D6D3u: goto L_80D6D3;
    case 0x80D6D4u: goto L_80D6D4;
    case 0x80D6D7u: goto L_80D6D7;
    case 0x80D6DAu: goto L_80D6DA;
    case 0x80D6DCu: goto L_80D6DC;
    case 0x80D6DEu: goto L_80D6DE;
    case 0x80D6E2u: goto L_80D6E2;
    case 0x80D6E4u: goto L_80D6E4;
    case 0x80D6E5u: goto L_80D6E5;
    case 0x80D6E7u: goto L_80D6E7;
    case 0x80D6E9u: goto L_80D6E9;
    case 0x80D6EBu: goto L_80D6EB;
    case 0x80D6ECu: goto L_80D6EC;
    case 0x80D6EEu: goto L_80D6EE;
    case 0x80D6F0u: goto L_80D6F0;
    case 0x80D6F2u: goto L_80D6F2;
    case 0x80D6F4u: goto L_80D6F4;
    case 0x80D6F6u: goto L_80D6F6;
    case 0x80D6F8u: goto L_80D6F8;
    case 0x80D6FAu: goto L_80D6FA;
    case 0x80D6FCu: goto L_80D6FC;
    case 0x80D6FDu: goto L_80D6FD;
    case 0x80D6FFu: goto L_80D6FF;
    case 0x80D700u: goto L_80D700;
    case 0x80D701u: goto L_80D701;
    case 0x80D704u: goto L_80D704;
    case 0x80D707u: goto L_80D707;
    case 0x80D709u: goto L_80D709;
    case 0x80D70Au: goto L_80D70A;
    case 0x80D70Du: goto L_80D70D;
    case 0x80D70Eu: goto L_80D70E;
    case 0x80D711u: goto L_80D711;
    case 0x80D714u: goto L_80D714;
    case 0x80D715u: goto L_80D715;
    case 0x80D716u: goto L_80D716;
    case 0x80D717u: goto L_80D717;
    case 0x80D719u: goto L_80D719;
    case 0x80D71Au: goto L_80D71A;
    case 0x80D71Du: goto L_80D71D;
    case 0x80D71Fu: goto L_80D71F;
    case 0x80D721u: goto L_80D721;
    case 0x80D724u: goto L_80D724;
    case 0x80D726u: goto L_80D726;
    case 0x80D728u: goto L_80D728;
    case 0x80D72Cu: goto L_80D72C;
    case 0x80D72Eu: goto L_80D72E;
    case 0x80D730u: goto L_80D730;
    case 0x80D732u: goto L_80D732;
    case 0x80D734u: goto L_80D734;
    case 0x80D736u: goto L_80D736;
    case 0x80D737u: goto L_80D737;
    case 0x80D739u: goto L_80D739;
    case 0x80D73Bu: goto L_80D73B;
    case 0x80D73Du: goto L_80D73D;
    case 0x80D73Fu: goto L_80D73F;
    case 0x80D741u: goto L_80D741;
    case 0x80D742u: goto L_80D742;
    case 0x80D745u: goto L_80D745;
    case 0x80D747u: goto L_80D747;
    case 0x80D749u: goto L_80D749;
    case 0x80D74Bu: goto L_80D74B;
    case 0x80D74Du: goto L_80D74D;
    case 0x80D74Fu: goto L_80D74F;
    case 0x80D752u: goto L_80D752;
    case 0x80D754u: goto L_80D754;
    case 0x80D757u: goto L_80D757;
    case 0x80D759u: goto L_80D759;
    case 0x80D75Cu: goto L_80D75C;
    case 0x80D760u: goto L_80D760;
    case 0x80D762u: goto L_80D762;
    case 0x80D764u: goto L_80D764;
    case 0x80D765u: goto L_80D765;
    case 0x80D768u: goto L_80D768;
    case 0x80D76Au: goto L_80D76A;
    case 0x80D76Cu: goto L_80D76C;
    case 0x80D76Eu: goto L_80D76E;
    case 0x80D770u: goto L_80D770;
    case 0x80D773u: goto L_80D773;
    case 0x80D775u: goto L_80D775;
    case 0x80D779u: goto L_80D779;
    case 0x80D77Bu: goto L_80D77B;
    case 0x80D77Du: goto L_80D77D;
    case 0x80D77Eu: goto L_80D77E;
    case 0x80D781u: goto L_80D781;
    case 0x80D784u: goto L_80D784;
    case 0x80D786u: goto L_80D786;
    case 0x80D788u: goto L_80D788;
    case 0x80D78Au: goto L_80D78A;
    case 0x80D78Bu: goto L_80D78B;
    case 0x80D78Eu: goto L_80D78E;
    case 0x80D791u: goto L_80D791;
    case 0x80D793u: goto L_80D793;
    case 0x80D794u: goto L_80D794;
    case 0x80D795u: goto L_80D795;
    case 0x80D798u: goto L_80D798;
    case 0x80D799u: goto L_80D799;
    case 0x80D79Cu: goto L_80D79C;
    case 0x80D79Eu: goto L_80D79E;
    case 0x80D7A1u: goto L_80D7A1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D6B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6B8 LDX
    cpu.setX(0x1B0u, 16);
    goto L_80D6BB;
L_80D6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6BB LDY
    cpu.setY(0x2D0u, 16);
    goto L_80D6BE;
L_80D6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6BE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6C0;
L_80D6C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6C0 BEQ -> $80D6C8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D6C8; }
    goto L_80D6C2;
L_80D6C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6C2 LDX
    cpu.setX(0x2B0u, 16);
    goto L_80D6C5;
L_80D6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6C5 LDY
    cpu.setY(0x3D0u, 16);
    goto L_80D6C8;
L_80D6C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6C8 STX
    hw.write(cpu.address("dp", 0x24u), cpu.x, cpu.x8?8:16);
    goto L_80D6CA;
L_80D6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CAu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6CA STY
    hw.write(cpu.address("dp", 0x26u), cpu.y, cpu.x8?8:16);
    goto L_80D6CC;
L_80D6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CCu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6CC LDX
    cpu.setX(0x700u, 16);
    goto L_80D6CF;
L_80D6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6CFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CFu,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CFu, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6CF INC
    cpu.incMem(hw, cpu.address("dpx", 0x26u), cpu.m8?8:16);
    goto L_80D6D1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CFu,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CFu, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6CF INC
    cpu.incMem(hw, cpu.address("dpx", 0x26u), cpu.m8?8:16);
    goto L_80D6D1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD6CFu,0x80D6CFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D6D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D1u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6D1 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6D3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D1u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6D1 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6D3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD6D1u,0x80D6D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D3u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6D3 SEC
    cpu.setFlag('C', true);
    goto L_80D6D4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D3u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6D3 SEC
    cpu.setFlag('C', true);
    goto L_80D6D4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD6D3u,0x80D6D3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D6D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D4u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6D4 SBC
    cpu.sbc(0x40u);
    goto L_80D6D7;
L_80D6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6D7 AND
    cpu.logicAnd(0xFFu);
    goto L_80D6DA;
L_80D6DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DAu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6DA LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x36u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D6DC;
L_80D6DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6DC BEQ -> $80D6F4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D6F4; }
    goto L_80D6DE;
L_80D6DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DEu, 8u, 4u, 0x808F43u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D6DE JSL -> $808F43 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD6E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD6E2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808F43u, 0x80D6DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D6E2;
L_80D6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD6E2u,0x80D6E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6E2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6E4;
L_80D6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6E4 CLC
    cpu.setFlag('C', false);
    goto L_80D6E5;
L_80D6E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E5u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6E5 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80D6E7;
L_80D6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6E7 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80D6E9;
L_80D6E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6EB;
L_80D6EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6EB CLC
    cpu.setFlag('C', false);
    goto L_80D6EC;
L_80D6EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6ECu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6EC ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_80D6EE;
L_80D6EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EEu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6EE STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80D6F0;
L_80D6F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6F0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6F2;
L_80D6F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6F2 BNE -> $80D728
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D728; }
    goto L_80D6F4;
L_80D6F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F4u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6F4 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6F6;
L_80D6F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F6u,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6F6 BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0x3Cu), cpu.m8?8:16), false);
    goto L_80D6F8;
L_80D6F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F8u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6F8 BVS -> $80D72C
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80D72C; }
    goto L_80D6FA;
L_80D6FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6FA BMI -> $80D711
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D711; }
    goto L_80D6FC;
L_80D6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6FC CLC
    cpu.setFlag('C', false);
    goto L_80D6FD;
L_80D6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FDu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6FD ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_80D6FF;
L_80D6FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FFu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6FF TAY
    cpu.transfer("TAY");
    goto L_80D700;
L_80D700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD700u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD700u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D700 SEC
    cpu.setFlag('C', true);
    goto L_80D701;
L_80D701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD701u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD701u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D701 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16));
    goto L_80D704;
L_80D704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD704u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD704u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D704 CMP
    cpu.compareA(0x10u);
    goto L_80D707;
L_80D707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD707u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD707u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D707 BCC -> $80D728
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D728; }
    goto L_80D709;
L_80D709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD709u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD709u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D709 TYA
    cpu.transfer("TYA");
    goto L_80D70A;
L_80D70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Au, 6u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D70A STA
    hw.write(cpu.address("absx", 0x1096u), cpu.a, cpu.m8?8:16);
    goto L_80D70D;
L_80D70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D70D CLC
    cpu.setFlag('C', false);
    goto L_80D70E;
L_80D70E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D70E ADC
    cpu.adc(0x12u);
    goto L_80D711;
L_80D711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD711u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD711u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D711 AND
    cpu.logicAnd(0xF0u);
    goto L_80D714;
L_80D714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD714u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD714u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D714 LSR
    cpu.lsrA();
    goto L_80D715;
L_80D715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD715u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD715u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D715 LSR
    cpu.lsrA();
    goto L_80D716;
L_80D716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD716u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD716u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D716 LSR
    cpu.lsrA();
    goto L_80D717;
L_80D717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD717u,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD717u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D717 ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0x2Cu), cpu.m8?8:16));
    goto L_80D719;
L_80D719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD719u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD719u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D719 TAY
    cpu.transfer("TAY");
    goto L_80D71A;
L_80D71A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Au, 5u + 1u, 3u, cpu.address("absy", 0xD909u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D71A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD909u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D71D;
L_80D71D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D71D STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D71F;
L_80D71F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Fu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D71F LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D721;
L_80D721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD721u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD721u, 5u + 1u, 3u, cpu.address("absy", 0xD8FBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D721 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD8FBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D724;
L_80D724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD724u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD724u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D724 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80D726;
L_80D726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD726u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD726u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D726 STA
    hw.write(cpu.address("dpx", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_80D728;
L_80D728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD728u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD728u, 8u, 4u, 0x80D7A2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D728 JSL -> $80D7A2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD72Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD72Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D7A2u, 0x80D728u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D72C;
L_80D72C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD72Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD72Cu,0x80D72Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D72C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D72E;
L_80D72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D72E BEQ -> $80D786
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D786; }
    goto L_80D730;
L_80D730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD730u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD730u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D730 BMI -> $80D736
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D736; }
    goto L_80D732;
L_80D732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD732u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD732u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D732 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D734;
L_80D734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD734u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD734u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D734 BRA -> $80D78A
    goto L_80D78A;
L_80D736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD736u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD736u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D736 ASL
    cpu.aslA();
    goto L_80D737;
L_80D737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD737u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD737u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D737 BMI -> $80D762
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D762; }
    goto L_80D739;
L_80D739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD739u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD739u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D739 INC
    cpu.incMem(hw, cpu.address("dpx", 0x3Cu), cpu.m8?8:16);
    goto L_80D73B;
L_80D73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D73B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D73D;
L_80D73D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D73D BEQ -> $80D762
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D762; }
    goto L_80D73F;
L_80D73F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D73F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D741;
L_80D741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD741u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD741u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D741 CLC
    cpu.setFlag('C', false);
    goto L_80D742;
L_80D742:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD742u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD742u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD742u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D742 ADC
    cpu.adc(0x8u);
    goto L_80D745;
L_80D745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD745u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD745u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D745 STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_80D747;
L_80D747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD747u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD747u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D747 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x36u), cpu.m8?8:16);
    goto L_80D749;
L_80D749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD749u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD749u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD749u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D749 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x36u), cpu.m8?8:16);
    goto L_80D74B;
L_80D74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D74B BNE -> $80D779
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D779; }
    goto L_80D74D;
L_80D74D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D74D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D74F;
L_80D74F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D74F CMP
    cpu.compareA(0xAu);
    goto L_80D752;
L_80D752:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD752u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD752u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD752u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D752 BCS -> $80D759
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D759; }
    goto L_80D754;
L_80D754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD754u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD754u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D754 LDA
    cpu.setA(0x40u, 16);
    goto L_80D757;
L_80D757:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD757u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD757u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD757u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D757 STA
    hw.write(cpu.address("dpx", 0x2Cu), cpu.a, cpu.m8?8:16);
    goto L_80D759;
L_80D759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD759u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD759u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D759 LDA
    cpu.setA(0x1Eu, 16);
    goto L_80D75C;
L_80D75C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD75Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Cu, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D75C JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD75Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD760u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x80D75Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D760;
L_80D760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD760u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD760u,0x80D760u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD760u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD760u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D760 BRA -> $80D779
    goto L_80D779;
L_80D762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD762u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD762u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D762 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D764;
L_80D764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD764u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD764u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D764 CLC
    cpu.setFlag('C', false);
    goto L_80D765;
L_80D765:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD765u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD765u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD765u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D765 ADC
    cpu.adc(0xAu);
    goto L_80D768;
L_80D768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD768u,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD768u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D768 BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0x3Cu), cpu.m8?8:16), false);
    goto L_80D76A;
L_80D76A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Au,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D76A BVS -> $80D779
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80D779; }
    goto L_80D76C;
L_80D76C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D76C STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80D76E;
L_80D76E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D76E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D770;
L_80D770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD770u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD770u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D770 AND
    cpu.logicAnd(0x3u);
    goto L_80D773;
L_80D773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD773u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD773u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD773u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D773 BNE -> $80D779
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D779; }
    goto L_80D775;
L_80D775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD775u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD775u, 8u, 4u, 0x849211u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D775 JSL -> $849211 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD778u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD779u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849211u, 0x80D775u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D779;
L_80D779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD779u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD779u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD779u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D779 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D77B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD779u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD779u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D779 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D77B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD779u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD779u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D779 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D77B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD779u,0x80D779u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D77B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D77B BEQ -> $80D793
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D793; }
    goto L_80D77D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D77B BEQ -> $80D793
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D793; }
    goto L_80D77D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D77B BEQ -> $80D793
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D793; }
    goto L_80D77D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD77Bu,0x80D77Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D77D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D77D CLC
    cpu.setFlag('C', false);
    goto L_80D77E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D77D CLC
    cpu.setFlag('C', false);
    goto L_80D77E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D77D CLC
    cpu.setFlag('C', false);
    goto L_80D77E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD77Du,0x80D77Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D77E ADC
    cpu.adc(0x10u);
    goto L_80D781;
L_80D781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD781u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD781u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D781 AND
    cpu.logicAnd(0xF0u);
    goto L_80D784;
L_80D784:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD784u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD784u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD784u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D784 BRA -> $80D791
    goto L_80D791;
L_80D786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD786u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD786u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D786 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D788;
L_80D788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD788u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD788u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D788 BEQ -> $80D793
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D793; }
    goto L_80D78A;
L_80D78A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D78A CLC
    cpu.setFlag('C', false);
    goto L_80D78B;
L_80D78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D78B ADC
    cpu.adc(0x4u);
    goto L_80D78E;
L_80D78E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D78E AND
    cpu.logicAnd(0xFCu);
    goto L_80D791;
L_80D791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD791u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD791u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D791 STA
    hw.write(cpu.address("dpx", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_80D793;
L_80D793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD793u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD793u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD793u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D793 TXA
    cpu.transfer("TXA");
    goto L_80D794;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD793u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD793u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D793 TXA
    cpu.transfer("TXA");
    goto L_80D794;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD793u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD793u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D793 TXA
    cpu.transfer("TXA");
    goto L_80D794;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD793u,0x80D793u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD794u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D794 CLC
    cpu.setFlag('C', false);
    goto L_80D795;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D794 CLC
    cpu.setFlag('C', false);
    goto L_80D795;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D794 CLC
    cpu.setFlag('C', false);
    goto L_80D795;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD794u,0x80D794u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD795u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD795u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D795 ADC
    cpu.adc(0x50u);
    goto L_80D798;
L_80D798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD798u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD798u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D798 TAX
    cpu.transfer("TAX");
    goto L_80D799;
L_80D799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD799u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD799u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D799 CMP
    cpu.compareA(0x8E0u);
    goto L_80D79C;
L_80D79C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D79C BCS -> $80D7A1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D7A1; }
    goto L_80D79E;
L_80D79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Eu, 3u, 3u, cpu.address("abs", 0xD6CFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D79E JMP -> $80D6CF
    goto L_80D6CF;
L_80D7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D7A1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D7A1u);return;} hw.unresolvedReturn(0x80D7A1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80D6B8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D6B8u: goto L_80D6B8;
    case 0x80D6BBu: goto L_80D6BB;
    case 0x80D6BEu: goto L_80D6BE;
    case 0x80D6C0u: goto L_80D6C0;
    case 0x80D6C2u: goto L_80D6C2;
    case 0x80D6C5u: goto L_80D6C5;
    case 0x80D6C8u: goto L_80D6C8;
    case 0x80D6CAu: goto L_80D6CA;
    case 0x80D6CCu: goto L_80D6CC;
    case 0x80D6CFu: goto L_80D6CF;
    case 0x80D6D1u: goto L_80D6D1;
    case 0x80D6D3u: goto L_80D6D3;
    case 0x80D6D4u: goto L_80D6D4;
    case 0x80D6D7u: goto L_80D6D7;
    case 0x80D6DAu: goto L_80D6DA;
    case 0x80D6DCu: goto L_80D6DC;
    case 0x80D6DEu: goto L_80D6DE;
    case 0x80D6E2u: goto L_80D6E2;
    case 0x80D6E4u: goto L_80D6E4;
    case 0x80D6E5u: goto L_80D6E5;
    case 0x80D6E7u: goto L_80D6E7;
    case 0x80D6E9u: goto L_80D6E9;
    case 0x80D6EBu: goto L_80D6EB;
    case 0x80D6ECu: goto L_80D6EC;
    case 0x80D6EEu: goto L_80D6EE;
    case 0x80D6F0u: goto L_80D6F0;
    case 0x80D6F2u: goto L_80D6F2;
    case 0x80D6F4u: goto L_80D6F4;
    case 0x80D6F6u: goto L_80D6F6;
    case 0x80D6F8u: goto L_80D6F8;
    case 0x80D6FAu: goto L_80D6FA;
    case 0x80D6FCu: goto L_80D6FC;
    case 0x80D6FDu: goto L_80D6FD;
    case 0x80D6FFu: goto L_80D6FF;
    case 0x80D700u: goto L_80D700;
    case 0x80D701u: goto L_80D701;
    case 0x80D704u: goto L_80D704;
    case 0x80D707u: goto L_80D707;
    case 0x80D709u: goto L_80D709;
    case 0x80D70Au: goto L_80D70A;
    case 0x80D70Du: goto L_80D70D;
    case 0x80D70Eu: goto L_80D70E;
    case 0x80D711u: goto L_80D711;
    case 0x80D714u: goto L_80D714;
    case 0x80D715u: goto L_80D715;
    case 0x80D716u: goto L_80D716;
    case 0x80D717u: goto L_80D717;
    case 0x80D719u: goto L_80D719;
    case 0x80D71Au: goto L_80D71A;
    case 0x80D71Du: goto L_80D71D;
    case 0x80D71Fu: goto L_80D71F;
    case 0x80D721u: goto L_80D721;
    case 0x80D724u: goto L_80D724;
    case 0x80D726u: goto L_80D726;
    case 0x80D728u: goto L_80D728;
    case 0x80D72Cu: goto L_80D72C;
    case 0x80D72Eu: goto L_80D72E;
    case 0x80D730u: goto L_80D730;
    case 0x80D732u: goto L_80D732;
    case 0x80D734u: goto L_80D734;
    case 0x80D736u: goto L_80D736;
    case 0x80D737u: goto L_80D737;
    case 0x80D739u: goto L_80D739;
    case 0x80D73Bu: goto L_80D73B;
    case 0x80D73Du: goto L_80D73D;
    case 0x80D73Fu: goto L_80D73F;
    case 0x80D741u: goto L_80D741;
    case 0x80D742u: goto L_80D742;
    case 0x80D745u: goto L_80D745;
    case 0x80D747u: goto L_80D747;
    case 0x80D749u: goto L_80D749;
    case 0x80D74Bu: goto L_80D74B;
    case 0x80D74Du: goto L_80D74D;
    case 0x80D74Fu: goto L_80D74F;
    case 0x80D752u: goto L_80D752;
    case 0x80D754u: goto L_80D754;
    case 0x80D757u: goto L_80D757;
    case 0x80D759u: goto L_80D759;
    case 0x80D75Cu: goto L_80D75C;
    case 0x80D760u: goto L_80D760;
    case 0x80D762u: goto L_80D762;
    case 0x80D764u: goto L_80D764;
    case 0x80D765u: goto L_80D765;
    case 0x80D768u: goto L_80D768;
    case 0x80D76Au: goto L_80D76A;
    case 0x80D76Cu: goto L_80D76C;
    case 0x80D76Eu: goto L_80D76E;
    case 0x80D770u: goto L_80D770;
    case 0x80D773u: goto L_80D773;
    case 0x80D775u: goto L_80D775;
    case 0x80D779u: goto L_80D779;
    case 0x80D77Bu: goto L_80D77B;
    case 0x80D77Du: goto L_80D77D;
    case 0x80D77Eu: goto L_80D77E;
    case 0x80D781u: goto L_80D781;
    case 0x80D784u: goto L_80D784;
    case 0x80D786u: goto L_80D786;
    case 0x80D788u: goto L_80D788;
    case 0x80D78Au: goto L_80D78A;
    case 0x80D78Bu: goto L_80D78B;
    case 0x80D78Eu: goto L_80D78E;
    case 0x80D791u: goto L_80D791;
    case 0x80D793u: goto L_80D793;
    case 0x80D794u: goto L_80D794;
    case 0x80D795u: goto L_80D795;
    case 0x80D798u: goto L_80D798;
    case 0x80D799u: goto L_80D799;
    case 0x80D79Cu: goto L_80D79C;
    case 0x80D79Eu: goto L_80D79E;
    case 0x80D7A1u: goto L_80D7A1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D6B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6B8 LDX
    cpu.setX(0x1B0u, 16);
    goto L_80D6BB;
L_80D6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6BB LDY
    cpu.setY(0x2D0u, 16);
    goto L_80D6BE;
L_80D6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6BE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6C0;
L_80D6C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6C0 BEQ -> $80D6C8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D6C8; }
    goto L_80D6C2;
L_80D6C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6C2 LDX
    cpu.setX(0x2B0u, 16);
    goto L_80D6C5;
L_80D6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6C5 LDY
    cpu.setY(0x3D0u, 16);
    goto L_80D6C8;
L_80D6C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6C8 STX
    hw.write(cpu.address("dp", 0x24u), cpu.x, cpu.x8?8:16);
    goto L_80D6CA;
L_80D6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CAu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6CA STY
    hw.write(cpu.address("dp", 0x26u), cpu.y, cpu.x8?8:16);
    goto L_80D6CC;
L_80D6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CCu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6CC LDX
    cpu.setX(0x700u, 16);
    goto L_80D6CF;
L_80D6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CFu,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CFu, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6CF INC
    cpu.incMem(hw, cpu.address("dpx", 0x26u), cpu.m8?8:16);
    goto L_80D6D1;
L_80D6D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D1u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6D1 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6D3;
L_80D6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D3u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6D3 SEC
    cpu.setFlag('C', true);
    goto L_80D6D4;
L_80D6D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D4u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6D4 SBC
    cpu.sbc(0x40u);
    goto L_80D6D7;
L_80D6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6D7 AND
    cpu.logicAnd(0xFFu);
    goto L_80D6DA;
L_80D6DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DAu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6DA LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x36u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D6DC;
L_80D6DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6DC BEQ -> $80D6F4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D6F4; }
    goto L_80D6DE;
L_80D6DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DEu, 8u, 4u, 0x808F43u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D6DE JSL -> $808F43 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD6E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD6E2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808F43u, 0x80D6DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D6E2;
L_80D6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD6E2u,0x80D6E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6E2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6E4;
L_80D6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6E4 CLC
    cpu.setFlag('C', false);
    goto L_80D6E5;
L_80D6E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E5u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6E5 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80D6E7;
L_80D6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6E7 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80D6E9;
L_80D6E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6EB;
L_80D6EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6EB CLC
    cpu.setFlag('C', false);
    goto L_80D6EC;
L_80D6EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6ECu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6EC ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_80D6EE;
L_80D6EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EEu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6EEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6EE STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80D6F0;
L_80D6F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6F0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6F2;
L_80D6F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6F2 BNE -> $80D728
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D728; }
    goto L_80D6F4;
L_80D6F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F4u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6F4 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6F6;
L_80D6F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F6u,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6F6 BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0x3Cu), cpu.m8?8:16), false);
    goto L_80D6F8;
L_80D6F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F8u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6F8 BVS -> $80D72C
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80D72C; }
    goto L_80D6FA;
L_80D6FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6FA BMI -> $80D711
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D711; }
    goto L_80D6FC;
L_80D6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6FC CLC
    cpu.setFlag('C', false);
    goto L_80D6FD;
L_80D6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FDu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6FD ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_80D6FF;
L_80D6FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FFu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6FF TAY
    cpu.transfer("TAY");
    goto L_80D700;
L_80D700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD700u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD700u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D700 SEC
    cpu.setFlag('C', true);
    goto L_80D701;
L_80D701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD701u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD701u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D701 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16));
    goto L_80D704;
L_80D704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD704u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD704u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D704 CMP
    cpu.compareA(0x10u);
    goto L_80D707;
L_80D707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD707u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD707u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D707 BCC -> $80D728
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D728; }
    goto L_80D709;
L_80D709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD709u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD709u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D709 TYA
    cpu.transfer("TYA");
    goto L_80D70A;
L_80D70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Au, 6u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D70A STA
    hw.write(cpu.address("absx", 0x1096u), cpu.a, cpu.m8?8:16);
    goto L_80D70D;
L_80D70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D70D CLC
    cpu.setFlag('C', false);
    goto L_80D70E;
L_80D70E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D70E ADC
    cpu.adc(0x12u);
    goto L_80D711;
L_80D711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD711u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD711u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D711 AND
    cpu.logicAnd(0xF0u);
    goto L_80D714;
L_80D714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD714u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD714u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D714 LSR
    cpu.lsrA();
    goto L_80D715;
L_80D715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD715u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD715u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D715 LSR
    cpu.lsrA();
    goto L_80D716;
L_80D716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD716u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD716u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D716 LSR
    cpu.lsrA();
    goto L_80D717;
L_80D717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD717u,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD717u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D717 ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0x2Cu), cpu.m8?8:16));
    goto L_80D719;
L_80D719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD719u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD719u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D719 TAY
    cpu.transfer("TAY");
    goto L_80D71A;
L_80D71A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Au, 5u + 1u, 3u, cpu.address("absy", 0xD909u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D71A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD909u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D71D;
L_80D71D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D71D STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D71F;
L_80D71F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD71Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Fu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD71Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D71F LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D721;
L_80D721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD721u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD721u, 5u + 1u, 3u, cpu.address("absy", 0xD8FBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D721 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD8FBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D724;
L_80D724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD724u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD724u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D724 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80D726;
L_80D726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD726u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD726u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D726 STA
    hw.write(cpu.address("dpx", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_80D728;
L_80D728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD728u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD728u, 8u, 4u, 0x80D7A2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D728 JSL -> $80D7A2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD72Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD72Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D7A2u, 0x80D728u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D72C;
L_80D72C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD72Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD72Cu,0x80D72Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D72C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D72E;
L_80D72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD72Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D72E BEQ -> $80D786
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D786; }
    goto L_80D730;
L_80D730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD730u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD730u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D730 BMI -> $80D736
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D736; }
    goto L_80D732;
L_80D732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD732u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD732u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D732 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D734;
L_80D734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD734u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD734u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D734 BRA -> $80D78A
    goto L_80D78A;
L_80D736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD736u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD736u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D736 ASL
    cpu.aslA();
    goto L_80D737;
L_80D737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD737u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD737u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D737 BMI -> $80D762
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D762; }
    goto L_80D739;
L_80D739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD739u,cpu,0xF6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD739u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D739 INC
    cpu.incMem(hw, cpu.address("dpx", 0x3Cu), cpu.m8?8:16);
    goto L_80D73B;
L_80D73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D73B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D73D;
L_80D73D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D73D BEQ -> $80D762
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D762; }
    goto L_80D73F;
L_80D73F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD73Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD73Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D73F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D741;
L_80D741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD741u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD741u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D741 CLC
    cpu.setFlag('C', false);
    goto L_80D742;
L_80D742:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD742u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD742u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD742u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D742 ADC
    cpu.adc(0x8u);
    goto L_80D745;
L_80D745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD745u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD745u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D745 STA
    hw.write(cpu.address("dpx", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_80D747;
L_80D747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD747u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD747u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D747 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x36u), cpu.m8?8:16);
    goto L_80D749;
L_80D749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD749u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD749u,cpu,0xD6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD749u, 8u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D749 DEC
    cpu.decMem(hw, cpu.address("dpx", 0x36u), cpu.m8?8:16);
    goto L_80D74B;
L_80D74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D74B BNE -> $80D779
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D779; }
    goto L_80D74D;
L_80D74D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D74D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D74F;
L_80D74F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD74Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD74Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D74F CMP
    cpu.compareA(0xAu);
    goto L_80D752;
L_80D752:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD752u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD752u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD752u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D752 BCS -> $80D759
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D759; }
    goto L_80D754;
L_80D754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD754u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD754u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D754 LDA
    cpu.setA(0x40u, 16);
    goto L_80D757;
L_80D757:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD757u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD757u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD757u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D757 STA
    hw.write(cpu.address("dpx", 0x2Cu), cpu.a, cpu.m8?8:16);
    goto L_80D759;
L_80D759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD759u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD759u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D759 LDA
    cpu.setA(0x1Eu, 16);
    goto L_80D75C;
L_80D75C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD75Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD75Cu, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D75C JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD75Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD760u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x80D75Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D760;
L_80D760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD760u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD760u,0x80D760u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD760u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD760u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D760 BRA -> $80D779
    goto L_80D779;
L_80D762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD762u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD762u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D762 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D764;
L_80D764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD764u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD764u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D764 CLC
    cpu.setFlag('C', false);
    goto L_80D765;
L_80D765:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD765u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD765u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD765u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D765 ADC
    cpu.adc(0xAu);
    goto L_80D768;
L_80D768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD768u,cpu,0x34u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD768u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D768 BIT
    cpu.bit(hw.readW(cpu.address("dpx", 0x3Cu), cpu.m8?8:16), false);
    goto L_80D76A;
L_80D76A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Au,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D76A BVS -> $80D779
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80D779; }
    goto L_80D76C;
L_80D76C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Cu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D76C STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80D76E;
L_80D76E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD76Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD76Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D76E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D770;
L_80D770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD770u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD770u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D770 AND
    cpu.logicAnd(0x3u);
    goto L_80D773;
L_80D773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD773u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD773u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD773u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D773 BNE -> $80D779
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D779; }
    goto L_80D775;
L_80D775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD775u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD775u, 8u, 4u, 0x849211u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D775 JSL -> $849211 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD778u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD779u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x849211u, 0x80D775u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D779;
L_80D779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD779u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD779u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD779u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D779 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D77B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD779u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD779u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D779 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D77B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD779u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD779u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D779 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D77B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD779u,0x80D779u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D77B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Bu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D77B BEQ -> $80D793
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D793; }
    goto L_80D77D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D77B BEQ -> $80D793
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D793; }
    goto L_80D77D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D77B BEQ -> $80D793
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D793; }
    goto L_80D77D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD77Bu,0x80D77Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D77D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D77D CLC
    cpu.setFlag('C', false);
    goto L_80D77E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D77D CLC
    cpu.setFlag('C', false);
    goto L_80D77E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D77D CLC
    cpu.setFlag('C', false);
    goto L_80D77E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD77Du,0x80D77Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD77Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D77E ADC
    cpu.adc(0x10u);
    goto L_80D781;
L_80D781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD781u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD781u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D781 AND
    cpu.logicAnd(0xF0u);
    goto L_80D784;
L_80D784:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD784u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD784u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD784u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D784 BRA -> $80D791
    goto L_80D791;
L_80D786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD786u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD786u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D786 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D788;
L_80D788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD788u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD788u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D788 BEQ -> $80D793
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D793; }
    goto L_80D78A;
L_80D78A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D78A CLC
    cpu.setFlag('C', false);
    goto L_80D78B;
L_80D78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D78B ADC
    cpu.adc(0x4u);
    goto L_80D78E;
L_80D78E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD78Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD78Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D78E AND
    cpu.logicAnd(0xFCu);
    goto L_80D791;
L_80D791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD791u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD791u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D791 STA
    hw.write(cpu.address("dpx", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_80D793;
L_80D793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD793u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD793u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD793u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D793 TXA
    cpu.transfer("TXA");
    goto L_80D794;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD793u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD793u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D793 TXA
    cpu.transfer("TXA");
    goto L_80D794;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD793u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD793u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D793 TXA
    cpu.transfer("TXA");
    goto L_80D794;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD793u,0x80D793u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD794u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D794 CLC
    cpu.setFlag('C', false);
    goto L_80D795;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D794 CLC
    cpu.setFlag('C', false);
    goto L_80D795;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D794 CLC
    cpu.setFlag('C', false);
    goto L_80D795;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD794u,0x80D794u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD795u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD795u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D795 ADC
    cpu.adc(0x50u);
    goto L_80D798;
L_80D798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD798u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD798u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D798 TAX
    cpu.transfer("TAX");
    goto L_80D799;
L_80D799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD799u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD799u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D799 CMP
    cpu.compareA(0x8E0u);
    goto L_80D79C;
L_80D79C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D79C BCS -> $80D7A1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D7A1; }
    goto L_80D79E;
L_80D79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Eu, 3u, 3u, cpu.address("abs", 0xD6CFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D79E JMP -> $80D6CF
    goto L_80D6CF;
L_80D7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D7A1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D7A1u);return;} hw.unresolvedReturn(0x80D7A1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80DAE7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C38Fu: goto L_80C38F;
    case 0x80C392u: goto L_80C392;
    case 0x80C395u: goto L_80C395;
    case 0x80C399u: goto L_80C399;
    case 0x80C39Cu: goto L_80C39C;
    case 0x80C39Eu: goto L_80C39E;
    case 0x80DAE7u: goto L_80DAE7;
    case 0x80DAEAu: goto L_80DAEA;
    case 0x80DAECu: goto L_80DAEC;
    case 0x80DAEFu: goto L_80DAEF;
    case 0x80DAF2u: goto L_80DAF2;
    case 0x80DAF4u: goto L_80DAF4;
    case 0x80DAF8u: goto L_80DAF8;
    case 0x80DAFCu: goto L_80DAFC;
    case 0x80DB00u: goto L_80DB00;
    case 0x80DB04u: goto L_80DB04;
    case 0x80DB06u: goto L_80DB06;
    case 0x80DB09u: goto L_80DB09;
    case 0x80DB0Au: goto L_80DB0A;
    case 0x80DB0Cu: goto L_80DB0C;
    case 0x80DB0Du: goto L_80DB0D;
    case 0x80DB10u: goto L_80DB10;
    case 0x80DB14u: goto L_80DB14;
    case 0x80DB16u: goto L_80DB16;
    case 0x80DB18u: goto L_80DB18;
    case 0x80DB1Bu: goto L_80DB1B;
    case 0x80DB1Eu: goto L_80DB1E;
    case 0x80DB21u: goto L_80DB21;
    case 0x80DB24u: goto L_80DB24;
    case 0x80DB28u: goto L_80DB28;
    case 0x80DB2Bu: goto L_80DB2B;
    case 0x80DB2Eu: goto L_80DB2E;
    case 0x80DB31u: goto L_80DB31;
    case 0x80DB35u: goto L_80DB35;
    case 0x80DB37u: goto L_80DB37;
    case 0x80DB39u: goto L_80DB39;
    case 0x80DB3Cu: goto L_80DB3C;
    case 0x80DB3Fu: goto L_80DB3F;
    case 0x80DB43u: goto L_80DB43;
    case 0x80DB45u: goto L_80DB45;
    case 0x80DB48u: goto L_80DB48;
    case 0x80DB4Bu: goto L_80DB4B;
    case 0x80DB4Fu: goto L_80DB4F;
    case 0x80DB51u: goto L_80DB51;
    case 0x80DB54u: goto L_80DB54;
    case 0x80DB57u: goto L_80DB57;
    case 0x80DB5Bu: goto L_80DB5B;
    case 0x80DB5Du: goto L_80DB5D;
    case 0x80DB60u: goto L_80DB60;
    case 0x80DB63u: goto L_80DB63;
    case 0x80DB67u: goto L_80DB67;
    case 0x80DB69u: goto L_80DB69;
    case 0x80DB6Bu: goto L_80DB6B;
    case 0x80DB6Eu: goto L_80DB6E;
    case 0x80DB70u: goto L_80DB70;
    case 0x80DB73u: goto L_80DB73;
    case 0x80DB76u: goto L_80DB76;
    case 0x80DB79u: goto L_80DB79;
    case 0x80DB7Cu: goto L_80DB7C;
    case 0x80DB7Fu: goto L_80DB7F;
    case 0x80DB82u: goto L_80DB82;
    case 0x80DB85u: goto L_80DB85;
    case 0x80DB88u: goto L_80DB88;
    case 0x80DB8Bu: goto L_80DB8B;
    case 0x80DB8Eu: goto L_80DB8E;
    case 0x80DB91u: goto L_80DB91;
    case 0x80DB94u: goto L_80DB94;
    case 0x80DB97u: goto L_80DB97;
    case 0x80DB9Au: goto L_80DB9A;
    case 0x80DB9Du: goto L_80DB9D;
    case 0x80DBA0u: goto L_80DBA0;
    case 0x80DBA3u: goto L_80DBA3;
    case 0x80DBA6u: goto L_80DBA6;
    case 0x80DBA9u: goto L_80DBA9;
    case 0x80DBADu: goto L_80DBAD;
    case 0x80DBB0u: goto L_80DBB0;
    case 0x80DBB1u: goto L_80DBB1;
    case 0x80DBB3u: goto L_80DBB3;
    case 0x80DBB6u: goto L_80DBB6;
    case 0x80DBB8u: goto L_80DBB8;
    case 0x80DBBBu: goto L_80DBBB;
    case 0x80DBBDu: goto L_80DBBD;
    case 0x80DBBFu: goto L_80DBBF;
    case 0x80DBC1u: goto L_80DBC1;
    case 0x80DBC3u: goto L_80DBC3;
    case 0x80DBC7u: goto L_80DBC7;
    case 0x80DBCAu: goto L_80DBCA;
    case 0x80DBCBu: goto L_80DBCB;
    case 0x80DBCEu: goto L_80DBCE;
    case 0x80DBD0u: goto L_80DBD0;
    case 0x80DBD4u: goto L_80DBD4;
    case 0x80DBD7u: goto L_80DBD7;
    case 0x80DBDBu: goto L_80DBDB;
    case 0x80DBDDu: goto L_80DBDD;
    case 0x80DBDEu: goto L_80DBDE;
    case 0x80DBDFu: goto L_80DBDF;
    case 0x80DBE0u: goto L_80DBE0;
    case 0x80DBE1u: goto L_80DBE1;
    case 0x80DBE2u: goto L_80DBE2;
    case 0x80DBE5u: goto L_80DBE5;
    case 0x80DBE9u: goto L_80DBE9;
    case 0x80DBEBu: goto L_80DBEB;
    case 0x80DBEFu: goto L_80DBEF;
    case 0x80DBF2u: goto L_80DBF2;
    case 0x80DBF5u: goto L_80DBF5;
    case 0x80DBF8u: goto L_80DBF8;
    case 0x80DBFBu: goto L_80DBFB;
    case 0x80DBFEu: goto L_80DBFE;
    case 0x80DC01u: goto L_80DC01;
    case 0x80DC04u: goto L_80DC04;
    case 0x80DC07u: goto L_80DC07;
    case 0x80DC0Au: goto L_80DC0A;
    case 0x80DC0Du: goto L_80DC0D;
    case 0x80DC10u: goto L_80DC10;
    case 0x80DC13u: goto L_80DC13;
    case 0x80DC15u: goto L_80DC15;
    case 0x80DC16u: goto L_80DC16;
    case 0x80DC1Au: goto L_80DC1A;
    case 0x80DC1Du: goto L_80DC1D;
    case 0x80DC1Fu: goto L_80DC1F;
    case 0x80DC20u: goto L_80DC20;
    case 0x80DC23u: goto L_80DC23;
    case 0x80DC26u: goto L_80DC26;
    case 0x80DC29u: goto L_80DC29;
    case 0x80DC2Cu: goto L_80DC2C;
    case 0x80DC2Du: goto L_80DC2D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C38F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC38Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC38Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC38Fu, 8u, 3u, cpu.address("abs", 0x1FF0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C38F INC
    cpu.incMem(hw, cpu.address("abs", 0x1FF0u), cpu.m8?8:16);
    goto L_80C392;
L_80C392:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC392u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC392u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC392u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C392 LDA
    cpu.setA(0xEDu, 16);
    goto L_80C395;
L_80C395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC395u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC395u, 8u, 4u, 0x809463u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C395 JSL -> $809463 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC398u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC399u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809463u, 0x80C395u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C399;
L_80C399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC399u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC399u,0x80C399u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC399u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC399u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C399 LDA
    cpu.setA(0x1u, 16);
    goto L_80C39C;
L_80C39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC39Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC39Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C39C STA
    hw.write(cpu.address("dp", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_80C39E;
L_80C39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC39Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC39Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC39Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C39E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C39Eu);return;} hw.unresolvedReturn(0x80C39Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80DAE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAE7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAE7u, 5u, 3u, cpu.address("abs", 0x19D2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DAE7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x19D2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DAEA;
L_80DAEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAEAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DAEA BEQ -> $80DAEF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DAEF; }
    goto L_80DAEC;
L_80DAEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAECu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAECu, 3u, 3u, cpu.address("abs", 0xDBB1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DAEC JMP -> $80DBB1
    goto L_80DBB1;
L_80DAEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAEFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAEFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DAEF LDA
    cpu.setA(0x2C00u, 16);
    goto L_80DAF2;
L_80DAF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAF2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAF2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DAF2 STA
    hw.write(cpu.address("dp", 0x4Au), cpu.a, cpu.m8?8:16);
    goto L_80DAF4;
L_80DAF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAF4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAF4u, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DAF4 JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDAF7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDAF8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80DAF4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DAF8;
L_80DAF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAF8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDAF8u,0x80DAF8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAF8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAF8u, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DAF8 JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDAFBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDAFCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x80DAF8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DAFC;
L_80DAFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDAFCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDAFCu,0x80DAFCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDAFCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDAFCu, 8u, 4u, 0x80A8FAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DAFC JSL -> $80A8FA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDAFFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB00u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A8FAu, 0x80DAFCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DB00;
L_80DB00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB00u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB00u,0x80DB00u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB00u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB00u, 8u, 4u, 0x8084E8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DB00 JSL -> $8084E8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDB03u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB04u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084E8u, 0x80DB00u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DB04;
L_80DB04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB04u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB04u,0x80DB04u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB04u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB04u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB04 STZ
    hw.write(cpu.address("dp", 0x46u), 0, cpu.m8?8:16);
    goto L_80DB06;
L_80DB06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB06u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB06u, 5u, 3u, cpu.address("abs", 0x19D0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB06 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x19D0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DB09;
L_80DB09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB09u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB09 ASL
    cpu.aslA();
    goto L_80DB0A;
L_80DB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB0Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB0Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB0A STA
    hw.write(cpu.address("dp", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_80DB0C;
L_80DB0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB0Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB0Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB0C TAY
    cpu.transfer("TAY");
    goto L_80DB0D;
L_80DB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB0Du,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB0Du, 5u + 1u, 3u, cpu.address("absy", 0xA91Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB0D LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xA91Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80DB10;
L_80DB10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB10u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB10u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DB10 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDB13u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB14u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x80DB10u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DB14;
L_80DB14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB14u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB14u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB14u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB14 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x26u), cpu.m8?8:16);
    goto L_80DB16;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB14u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB14u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB14 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x26u), cpu.m8?8:16);
    goto L_80DB16;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB14u,0x80DB14u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DB16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB16u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB16 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DB18;
L_80DB18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB18u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB18 ADC
    cpu.adc(0x8u);
    goto L_80DB1B;
L_80DB1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB1B ORA
    cpu.logicOr(0x20u);
    goto L_80DB1E;
L_80DB1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB1Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB1E LDY
    cpu.setY(0x1u, 16);
    goto L_80DB21;
L_80DB21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB21u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB21 LDX
    cpu.setX(0xA570u, 16);
    goto L_80DB24;
L_80DB24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB24u, 8u, 4u, 0x80D692u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DB24 JSL -> $80D692 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDB27u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB28u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D692u, 0x80DB24u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DB28;
L_80DB28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB28u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB28u,0x80DB28u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB28u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB28u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB28 LDA
    cpu.setA(0x2400u, 16);
    goto L_80DB2B;
L_80DB2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB2B LDX
    cpu.setX(0xA92Bu, 16);
    goto L_80DB2E;
L_80DB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB2Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB2E LDY
    cpu.setY(0x7CACu, 16);
    goto L_80DB31;
L_80DB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB31u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB31u, 8u, 4u, 0x80A9C0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DB31 JSL -> $80A9C0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDB34u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB35u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A9C0u, 0x80DB31u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DB35;
L_80DB35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB35u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB35u,0x80DB35u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB35u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB35u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB35 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x26u), cpu.m8?8:16);
    goto L_80DB37;
L_80DB37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB37u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB37u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB37 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x26u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80DB39;
L_80DB39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB39u, 5u + 1u, 3u, cpu.address("absx", 0xA958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB39 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xA958u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80DB3C;
L_80DB3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB3C LDA
    cpu.setA(0x7CD0u, 16);
    goto L_80DB3F;
L_80DB3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB3Fu, 8u, 4u, 0x82F6C8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DB3F JSL -> $82F6C8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDB42u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB43u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F6C8u, 0x80DB3Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DB43;
L_80DB43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB43u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB43u,0x80DB43u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB43u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB43u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB43 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x26u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80DB45;
L_80DB45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB45u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB45u, 5u + 1u, 3u, cpu.address("absx", 0xA95Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB45 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xA95Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80DB48;
L_80DB48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB48u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB48 LDA
    cpu.setA(0x7D30u, 16);
    goto L_80DB4B;
L_80DB4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Bu, 8u, 4u, 0x82F6C8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DB4B JSL -> $82F6C8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDB4Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB4Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F6C8u, 0x80DB4Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DB4F;
L_80DB4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB4Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB4Fu,0x80DB4Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Fu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB4Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB4F LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x26u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80DB51;
L_80DB51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB51u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB51u, 5u + 1u, 3u, cpu.address("absx", 0xA95Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB51 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xA95Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80DB54;
L_80DB54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB54u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB54u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB54 LDA
    cpu.setA(0x7D90u, 16);
    goto L_80DB57;
L_80DB57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB57u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB57u, 8u, 4u, 0x82F6C8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DB57 JSL -> $82F6C8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDB5Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB5Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F6C8u, 0x80DB57u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DB5B;
L_80DB5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB5Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB5Bu,0x80DB5Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB5B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x26u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80DB5D;
L_80DB5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Du,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB5Du, 5u + 1u, 3u, cpu.address("absx", 0xA95Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB5D LDY
    cpu.setY(hw.readW(cpu.address("absx", 0xA95Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80DB60;
L_80DB60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB60u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB60u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB60 LDA
    cpu.setA(0x7DF0u, 16);
    goto L_80DB63;
L_80DB63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB63u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB63u, 8u, 4u, 0x82F6C8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DB63 JSL -> $82F6C8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDB66u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDB67u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F6C8u, 0x80DB63u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DB67;
L_80DB67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB67u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDB67u,0x80DB67u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB67u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB67u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB67 SEP
    cpu.sep(0x20u);
    goto L_80DB69;
L_80DB69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB69u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB69u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB69 LDA
    cpu.setA(0x27u, 8);
    goto L_80DB6B;
L_80DB6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Bu, 4u, 3u, cpu.address("abs", 0x210Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB6B STA
    hw.write(cpu.address("abs", 0x210Bu), cpu.a, cpu.m8?8:16);
    goto L_80DB6E;
L_80DB6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB6Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB6E REP
    cpu.rep(0x20u);
    goto L_80DB70;
L_80DB70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB70u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB70u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB70 LDA
    cpu.setA(0x78u, 16);
    goto L_80DB73;
L_80DB73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB73u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB73u, 5u, 3u, cpu.address("abs", 0x1FACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB73 STA
    hw.write(cpu.address("abs", 0x1FACu), cpu.a, cpu.m8?8:16);
    goto L_80DB76;
L_80DB76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB76u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB76 LDA
    cpu.setA(0x7Cu, 16);
    goto L_80DB79;
L_80DB79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB79u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB79u, 5u, 3u, cpu.address("abs", 0x1FB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB79 STA
    hw.write(cpu.address("abs", 0x1FB0u), cpu.a, cpu.m8?8:16);
    goto L_80DB7C;
L_80DB7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Cu, 5u, 3u, cpu.address("abs", 0x1FC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB7C STZ
    hw.write(cpu.address("abs", 0x1FC0u), 0, cpu.m8?8:16);
    goto L_80DB7F;
L_80DB7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB7Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB7F LDX
    cpu.setX(0x1C00u, 16);
    goto L_80DB82;
L_80DB82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB82u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB82u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB82 LDY
    cpu.setY(0x19E0u, 16);
    goto L_80DB85;
L_80DB85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB85u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB85u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB85 LDA
    cpu.setA(0xFu, 16);
    goto L_80DB88;
L_80DB88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB88u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xDB88u, (std::uint32_t(cpu.a)+1u), 0x81u, 0x81u);
    // $80DB88 MVN
    cpu.blockMove(hw, 0x81u, 0x81u, false);
    goto L_80DB8B;
L_80DB8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB8B LDX
    cpu.setX(0x700u, 16);
    goto L_80DB8E;
L_80DB8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB8Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB8E LDY
    cpu.setY(0x19F0u, 16);
    goto L_80DB91;
L_80DB91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB91u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB91u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB91 LDA
    cpu.setA(0x4Fu, 16);
    goto L_80DB94;
L_80DB94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB94u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xDB94u, (std::uint32_t(cpu.a)+1u), 0x81u, 0x81u);
    // $80DB94 MVN
    cpu.blockMove(hw, 0x81u, 0x81u, false);
    goto L_80DB97;
L_80DB97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB97u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB97u, 5u, 3u, cpu.address("abs", 0x1C00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB97 STZ
    hw.write(cpu.address("abs", 0x1C00u), 0, cpu.m8?8:16);
    goto L_80DB9A;
L_80DB9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Au, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB9A STZ
    hw.write(cpu.address("abs", 0x1C02u), 0, cpu.m8?8:16);
    goto L_80DB9D;
L_80DB9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDB9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDB9Du, 5u, 3u, cpu.address("abs", 0x1C08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DB9D STZ
    hw.write(cpu.address("abs", 0x1C08u), 0, cpu.m8?8:16);
    goto L_80DBA0;
L_80DBA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA0u, 5u, 3u, cpu.address("abs", 0x1C0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBA0 STZ
    hw.write(cpu.address("abs", 0x1C0Au), 0, cpu.m8?8:16);
    goto L_80DBA3;
L_80DBA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA3u, 6u, 3u, cpu.address("abs", 0xDC31u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DBA3 JSR -> $80DC31 stack real
    { cpu.push16Value(hw,0xDBA5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBA6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDC31u), 0x80DBA3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DBA6;
L_80DBA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBA6u,0x80DBA6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBA6 LDY
    cpu.setY(0x14u, 16);
    goto L_80DBA9;
L_80DBA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBA9u, 8u, 4u, 0x80E227u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DBA9 JSL -> $80E227 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDBACu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBADu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80E227u, 0x80DBA9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DBAD;
L_80DBAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBADu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBADu,0x80DBADu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBADu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBADu, 8u, 3u, cpu.address("abs", 0x19D2u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBAD INC
    cpu.incMem(hw, cpu.address("abs", 0x19D2u), cpu.m8?8:16);
    goto L_80DBB0;
L_80DBB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DBB0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DBB0u);return;} hw.unresolvedReturn(0x80DBB0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80DBB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBB1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DBB3;
L_80DBB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB3u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBB3 BIT
    cpu.bit(0x3000u, true);
    goto L_80DBB6;
L_80DBB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBB6 BNE -> $80DC16
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DC16; }
    goto L_80DBB8;
L_80DBB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB8u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBB8u, 8u, 3u, cpu.address("abs", 0x19D4u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBB8 DEC
    cpu.decMem(hw, cpu.address("abs", 0x19D4u), cpu.m8?8:16);
    goto L_80DBBB;
L_80DBBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBBu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBBB BMI -> $80DBCB
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80DBCB; }
    goto L_80DBBD;
L_80DBBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBBD BNE -> $80DBC7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DBC7; }
    goto L_80DBBF;
L_80DBBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBBFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBBF INC
    cpu.incMem(hw, cpu.address("dp", 0x46u), cpu.m8?8:16);
    goto L_80DBC1;
L_80DBC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBC1u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBC1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBC1 INC
    cpu.incMem(hw, cpu.address("dp", 0x46u), cpu.m8?8:16);
    goto L_80DBC3;
L_80DBC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBC3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBC3u, 8u, 4u, 0x809979u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DBC3 JSL -> $809979 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDBC6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBC7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809979u, 0x80DBC3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DBC7;
L_80DBC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBC7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBC7u,0x80DBC7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBC7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBC7u, 6u, 3u, cpu.address("abs", 0xDC31u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80DBC7 JSR -> $80DC31 stack real
    { cpu.push16Value(hw,0xDBC9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBCAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDC31u), 0x80DBC7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DBCA;
L_80DBCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBCAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBCAu,0x80DBCAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBCAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBCAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DBCA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DBCAu);return;} hw.unresolvedReturn(0x80DBCAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80DBCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBCBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBCBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBCB LDA
    cpu.setA(0x2E00u, 16);
    goto L_80DBCE;
L_80DBCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBCEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBCEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBCE STA
    hw.write(cpu.address("dp", 0x4Au), cpu.a, cpu.m8?8:16);
    goto L_80DBD0;
L_80DBD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBD0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBD0u, 8u, 4u, 0x80B695u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DBD0 JSL -> $80B695 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDBD3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBD4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B695u, 0x80DBD0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DBD4;
L_80DBD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBD4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBD4u,0x80DBD4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBD4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBD4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBD4 LDX
    cpu.setX(0xA815u, 16);
    goto L_80DBD7;
L_80DBD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBD7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBD7u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DBD7 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDBDAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBDBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x80DBD7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DBDB;
L_80DBDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBDBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DBDD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBDB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DBDD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBDBu,0x80DBDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DBDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBDDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBDD ASL
    cpu.aslA();
    goto L_80DBDE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBDD ASL
    cpu.aslA();
    goto L_80DBDE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBDDu,0x80DBDDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DBDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBDE ASL
    cpu.aslA();
    goto L_80DBDF;
L_80DBDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBDFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBDF ASL
    cpu.aslA();
    goto L_80DBE0;
L_80DBE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBE0 ASL
    cpu.aslA();
    goto L_80DBE1;
L_80DBE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE1u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBE1 TAY
    cpu.transfer("TAY");
    goto L_80DBE2;
L_80DBE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE2u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE2u, 5u + 1u, 3u, cpu.address("absy", 0xAB0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBE2 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xAB0Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80DBE5;
L_80DBE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE5u, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DBE5 JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDBE8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBE9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x80DBE5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DBE9;
L_80DBE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBE9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBE9 STZ
    hw.write(cpu.address("dp", 0x46u), 0, cpu.m8?8:16);
    goto L_80DBEB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBE9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBE9 STZ
    hw.write(cpu.address("dp", 0x46u), 0, cpu.m8?8:16);
    goto L_80DBEB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBE9u,0x80DBE9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DBEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBEBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEBu, 8u, 4u, 0x80DC8Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DBEB JSL -> $80DC8F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDBEEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBEFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80DC8Fu, 0x80DBEBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DBEF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEBu, 8u, 4u, 0x80DC8Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DBEB JSL -> $80DC8F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDBEEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDBEFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80DC8Fu, 0x80DBEBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DBEF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBEBu,0x80DBEBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DBEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBEFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBEF LDA
    cpu.setA(0x2u, 16);
    goto L_80DBF2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBEFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBEF LDA
    cpu.setA(0x2u, 16);
    goto L_80DBF2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBEFu,0x80DBEFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DBF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u, 5u, 3u, cpu.address("abs", 0x1FC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBF2 STA
    hw.write(cpu.address("abs", 0x1FC0u), cpu.a, cpu.m8?8:16);
    goto L_80DBF5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF2u, 5u, 3u, cpu.address("abs", 0x1FC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBF2 STA
    hw.write(cpu.address("abs", 0x1FC0u), cpu.a, cpu.m8?8:16);
    goto L_80DBF5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF2u,0x80DBF2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DBF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBF5 LDX
    cpu.setX(0x19E0u, 16);
    goto L_80DBF8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBF5 LDX
    cpu.setX(0x19E0u, 16);
    goto L_80DBF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF5u,0x80DBF5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DBF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBF8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBF8 LDY
    cpu.setY(0x1C00u, 16);
    goto L_80DBFB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBF8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBF8 LDY
    cpu.setY(0x1C00u, 16);
    goto L_80DBFB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBF8u,0x80DBF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DBFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBFBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBFB LDA
    cpu.setA(0xFu, 16);
    goto L_80DBFE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DBFB LDA
    cpu.setA(0xFu, 16);
    goto L_80DBFE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBFBu,0x80DBFBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DBFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDBFEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFEu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xDBFEu, (std::uint32_t(cpu.a)+1u), 0x81u, 0x81u);
    // $80DBFE MVN
    cpu.blockMove(hw, 0x81u, 0x81u, false);
    goto L_80DC01;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDBFEu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xDBFEu, (std::uint32_t(cpu.a)+1u), 0x81u, 0x81u);
    // $80DBFE MVN
    cpu.blockMove(hw, 0x81u, 0x81u, false);
    goto L_80DC01;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDBFEu,0x80DBFEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DC01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC01u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC01u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC01u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC01 LDX
    cpu.setX(0x19F0u, 16);
    goto L_80DC04;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC01u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC01u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC01 LDX
    cpu.setX(0x19F0u, 16);
    goto L_80DC04;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC01u,0x80DC01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DC04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC04u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC04u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC04 LDY
    cpu.setY(0x700u, 16);
    goto L_80DC07;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC04u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC04 LDY
    cpu.setY(0x700u, 16);
    goto L_80DC07;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC04u,0x80DC04u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DC07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC07u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC07u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC07 LDA
    cpu.setA(0x4Fu, 16);
    goto L_80DC0A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC07u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC07 LDA
    cpu.setA(0x4Fu, 16);
    goto L_80DC0A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC07u,0x80DC07u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DC0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC0Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Au,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xDC0Au, (std::uint32_t(cpu.a)+1u), 0x81u, 0x81u);
    // $80DC0A MVN
    cpu.blockMove(hw, 0x81u, 0x81u, false);
    goto L_80DC0D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Au,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xDC0Au, (std::uint32_t(cpu.a)+1u), 0x81u, 0x81u);
    // $80DC0A MVN
    cpu.blockMove(hw, 0x81u, 0x81u, false);
    goto L_80DC0D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC0Au,0x80DC0Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC0Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Du, 8u, 3u, cpu.address("abs", 0x19D0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC0D INC
    cpu.incMem(hw, cpu.address("abs", 0x19D0u), cpu.m8?8:16);
    goto L_80DC10;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Du, 8u, 3u, cpu.address("abs", 0x19D0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC0D INC
    cpu.incMem(hw, cpu.address("abs", 0x19D0u), cpu.m8?8:16);
    goto L_80DC10;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC0Du,0x80DC0Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DC10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC10u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC10u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC10u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC10 LDA
    cpu.setA(0x3u, 16);
    goto L_80DC13;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC10u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC10u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC10 LDA
    cpu.setA(0x3u, 16);
    goto L_80DC13;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC10u,0x80DC10u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DC13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC13u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC13u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC13u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC13 STA
    hw.write(cpu.address("dp", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_80DC15;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC13u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC13u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC13 STA
    hw.write(cpu.address("dp", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_80DC15;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC13u,0x80DC13u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DC15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC15u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC15u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC15u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DC15 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DC15u);return;} hw.unresolvedReturn(0x80DC15u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC15u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC15u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DC15 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DC15u);return;} hw.unresolvedReturn(0x80DC15u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC15u,0x80DC15u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80DC16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC16u, 8u, 4u, 0x809979u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DC16 JSL -> $809979 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDC19u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC1Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809979u, 0x80DC16u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DC1A;
L_80DC1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC1Au,0x80DC1Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC1A LDA
    cpu.setA(0x2E00u, 16);
    goto L_80DC1D;
L_80DC1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC1D STA
    hw.write(cpu.address("dp", 0x4Au), cpu.a, cpu.m8?8:16);
    goto L_80DC1F;
L_80DC1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80DC1F PHB
    cpu.push("PHB", hw);
    goto L_80DC20;
L_80DC20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC20u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC20u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC20 LDX
    cpu.setX(0x2C00u, 16);
    goto L_80DC23;
L_80DC23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC23u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC23u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC23 LDY
    cpu.setY(0x2E00u, 16);
    goto L_80DC26;
L_80DC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC26 LDA
    cpu.setA(0x1FFu, 16);
    goto L_80DC29;
L_80DC29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC29u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xDC29u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80DC29 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80DC2C;
L_80DC2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80DC2C PLB
    cpu.pop("PLB", hw);
    goto L_80DC2D;
L_80DC2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Du,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Du, 4u, 4u, 0x80C38Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC2D JML -> $80C38F
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_80C38F;
}

void sub_8289AF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8289AFu: goto L_8289AF;
    case 0x8289B2u: goto L_8289B2;
    case 0x8289B3u: goto L_8289B3;
    case 0x8289B6u: goto L_8289B6;
    case 0x8289B9u: goto L_8289B9;
    case 0x8289BAu: goto L_8289BA;
    case 0x8289BDu: goto L_8289BD;
    case 0x8289C0u: goto L_8289C0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8289AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89AFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89AFu, 5u, 3u, cpu.address("abs", 0x1C1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289AF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8289B2;
L_8289B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289B2 CLC
    cpu.setFlag('C', false);
    goto L_8289B3;
L_8289B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289B3 ADC
    cpu.adc(0x8u);
    goto L_8289B6;
L_8289B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B6u, 5u, 3u, cpu.address("abs", 0x1C1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289B6 STA
    hw.write(cpu.address("abs", 0x1C1Au), cpu.a, cpu.m8?8:16);
    goto L_8289B9;
L_8289B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89B9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289B9 SEC
    cpu.setFlag('C', true);
    goto L_8289BA;
L_8289BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89BAu,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89BAu, 5u, 3u, cpu.address("abs", 0x1C12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289BA SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x1C12u), cpu.m8?8:16));
    goto L_8289BD;
L_8289BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89BDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89BDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8289BD CMP
    cpu.compareA(0x90u);
    goto L_8289C0;
L_8289C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x89C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x89C0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x89C0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8289C0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8289C0u);return;} hw.unresolvedReturn(0x8289C0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B036_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B036u: goto L_82B036;
    case 0x82B039u: goto L_82B039;
    case 0x82B03Bu: goto L_82B03B;
    case 0x82B03Cu: goto L_82B03C;
    case 0x82B03Fu: goto L_82B03F;
    case 0x82B042u: goto L_82B042;
    case 0x82B046u: goto L_82B046;
    case 0x82B048u: goto L_82B048;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB036u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB036u, 5u, 3u, cpu.address("abs", 0x1F60u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B036 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1F60u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B039;
L_82B039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB039u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB039u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B039 BEQ -> $82B03C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B03C; }
    goto L_82B03B;
L_82B03B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B03B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B03Bu);return;} hw.unresolvedReturn(0x82B03Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82B03C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B03C LDY
    cpu.setY(0x8D7Bu, 16);
    goto L_82B03F;
L_82B03F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B03F LDX
    cpu.setX(0x1F80u, 16);
    goto L_82B042;
L_82B042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB042u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB042u, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B042 JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB045u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB046u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x82B042u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B046;
L_82B046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB046u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB046u,0x82B046u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB046u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB046u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B046 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_82B048;
L_82B048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB048u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB048u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B048 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B048u);return;} hw.unresolvedReturn(0x82B048u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B036_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B036u: goto L_82B036;
    case 0x82B039u: goto L_82B039;
    case 0x82B03Bu: goto L_82B03B;
    case 0x82B03Cu: goto L_82B03C;
    case 0x82B03Fu: goto L_82B03F;
    case 0x82B042u: goto L_82B042;
    case 0x82B046u: goto L_82B046;
    case 0x82B048u: goto L_82B048;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB036u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB036u, 5u, 3u, cpu.address("abs", 0x1F60u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B036 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1F60u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B039;
L_82B039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB039u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB039u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B039 BEQ -> $82B03C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B03C; }
    goto L_82B03B;
L_82B03B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B03B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B03Bu);return;} hw.unresolvedReturn(0x82B03Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82B03C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B03C LDY
    cpu.setY(0x8D7Bu, 16);
    goto L_82B03F;
L_82B03F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B03F LDX
    cpu.setX(0x1F80u, 16);
    goto L_82B042;
L_82B042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB042u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB042u, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B042 JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB045u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB046u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x82B042u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B046;
L_82B046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB046u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB046u,0x82B046u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB046u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB046u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B046 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_82B048;
L_82B048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB048u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB048u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B048 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B048u);return;} hw.unresolvedReturn(0x82B048u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82E3CD_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E3CDu: goto L_82E3CD;
    case 0x82E3D0u: goto L_82E3D0;
    case 0x82E3D2u: goto L_82E3D2;
    case 0x82E3D3u: goto L_82E3D3;
    case 0x82E3D6u: goto L_82E3D6;
    case 0x82E3D9u: goto L_82E3D9;
    case 0x82E3DBu: goto L_82E3DB;
    case 0x82E3DFu: goto L_82E3DF;
    case 0x82E3E2u: goto L_82E3E2;
    case 0x82E3E3u: goto L_82E3E3;
    case 0x82E3E4u: goto L_82E3E4;
    case 0x82E3E5u: goto L_82E3E5;
    case 0x82E3E7u: goto L_82E3E7;
    case 0x82E3EBu: goto L_82E3EB;
    case 0x82E3EEu: goto L_82E3EE;
    case 0x82E3F1u: goto L_82E3F1;
    case 0x82E3F2u: goto L_82E3F2;
    case 0x82E3F5u: goto L_82E3F5;
    case 0x82E3F8u: goto L_82E3F8;
    case 0x82E3FBu: goto L_82E3FB;
    case 0x82E4AFu: goto L_82E4AF;
    case 0x82E4B1u: goto L_82E4B1;
    case 0x82E4B4u: goto L_82E4B4;
    case 0x82E4B6u: goto L_82E4B6;
    case 0x82E4B9u: goto L_82E4B9;
    case 0x82E4BBu: goto L_82E4BB;
    case 0x82E4BEu: goto L_82E4BE;
    case 0x82E4C1u: goto L_82E4C1;
    case 0x82E4C3u: goto L_82E4C3;
    case 0x82E4C4u: goto L_82E4C4;
    case 0x82E4C7u: goto L_82E4C7;
    case 0x82E4C9u: goto L_82E4C9;
    case 0x82E4CBu: goto L_82E4CB;
    case 0x82E4CEu: goto L_82E4CE;
    case 0x82E4D0u: goto L_82E4D0;
    case 0x82E4D3u: goto L_82E4D3;
    case 0x82E4D7u: goto L_82E4D7;
    case 0x82E4DAu: goto L_82E4DA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E3CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CDu, 5u, 3u, cpu.address("abs", 0x05B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3CD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x5B0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E3D0;
L_82E3D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3D0 BEQ -> $82E3DF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E3DF; }
    goto L_82E3D2;
L_82E3D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3D2 SEC
    cpu.setFlag('C', true);
    goto L_82E3D3;
L_82E3D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3D3 SBC
    cpu.sbc(0x421u);
    goto L_82E3D6;
L_82E3D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D6u, 5u, 3u, cpu.address("abs", 0x05B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3D6 STA
    hw.write(cpu.address("abs", 0x5B0u), cpu.a, cpu.m8?8:16);
    goto L_82E3D9;
L_82E3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3D9 BNE -> $82E3DB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E3DB; }
    goto L_82E3DB;
L_82E3DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DBu, 8u, 4u, 0x808C38u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E3DB JSL -> $808C38 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE3DEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3DFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C38u, 0x82E3DBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E3DF;
L_82E3DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3DFu,0x82E3DFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DFu, 5u, 3u, cpu.address("abs", 0x1A6Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3DF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A6Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E3E2;
L_82E3E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E2u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3E2 INC
    cpu.inc('A');
    goto L_82E3E3;
L_82E3E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E3u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3E3 INC
    cpu.inc('A');
    goto L_82E3E4;
L_82E3E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E4u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3E4 INC
    cpu.inc('A');
    goto L_82E3E5;
L_82E3E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E5u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3E5 BMI -> $82E3F5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82E3F5; }
    goto L_82E3E7;
L_82E3E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E7u, 8u, 4u, 0x848BE8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E3E7 JSL -> $848BE8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE3EAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3EBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848BE8u, 0x82E3E7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E3EB;
L_82E3EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3EBu,0x82E3EBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3EB LDA
    cpu.setA(0x3Cu, 16);
    goto L_82E3EE;
L_82E3EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3EEu, 5u, 3u, cpu.address("abs", 0x05B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3EE STA
    hw.write(cpu.address("abs", 0x5B0u), cpu.a, cpu.m8?8:16);
    goto L_82E3F1;
L_82E3F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F1u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3F1 TDC
    cpu.tdc();
    goto L_82E3F2;
L_82E3F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F2u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F2u, 8u, 3u, cpu.address("abs", 0x05A0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3F2 INC
    cpu.incMem(hw, cpu.address("abs", 0x5A0u), cpu.m8?8:16);
    goto L_82E3F5;
L_82E3F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F5u, 5u, 3u, cpu.address("abs", 0x1A6Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3F5 STA
    hw.write(cpu.address("abs", 0x1A6Eu), cpu.a, cpu.m8?8:16);
    goto L_82E3F8;
L_82E3F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3F8u, 5u, 3u, cpu.address("abs", 0x1A70u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3F8 STA
    hw.write(cpu.address("abs", 0x1A70u), cpu.a, cpu.m8?8:16);
    goto L_82E3FB;
L_82E3FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FBu,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3FBu, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3FB BRL -> $82E4C4
    goto L_82E4C4;
L_82E4AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4AF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E4B1;
L_82E4B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B1u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4B1 BIT
    cpu.bit(0x1u, true);
    goto L_82E4B4;
L_82E4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4B4 BNE -> $82E4C3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E4C3; }
    goto L_82E4B6;
L_82E4B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B6u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B6u, 8u, 3u, cpu.address("abs", 0x1FA0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4B6 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1FA0u), cpu.m8?8:16);
    goto L_82E4B9;
L_82E4B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4B9 BNE -> $82E4C3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E4C3; }
    goto L_82E4BB;
L_82E4BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4BB LDA
    cpu.setA(0x9u, 16);
    goto L_82E4BE;
L_82E4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4BEu, 5u, 3u, cpu.address("abs", 0x1FA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4BE STA
    hw.write(cpu.address("abs", 0x1FA4u), cpu.a, cpu.m8?8:16);
    goto L_82E4C1;
L_82E4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C1u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4C1 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_82E4C3;
L_82E4C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E4C3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82E4C3u);return;} hw.unresolvedReturn(0x82E4C3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82E4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C4u, 5u, 3u, cpu.address("abs", 0x19D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4C4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x19D4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E4C7;
L_82E4C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4C7 BNE -> $82E4AF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E4AF; }
    goto L_82E4C9;
L_82E4C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4C9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4C9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E4CB;
L_82E4CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CBu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4CB BIT
    cpu.bit(0x9000u, true);
    goto L_82E4CE;
L_82E4CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4CE BEQ -> $82E4DA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E4DA; }
    goto L_82E4D0;
L_82E4D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4D0 LDA
    cpu.setA(0xECu, 16);
    goto L_82E4D3;
L_82E4D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D3u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E4D3 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE4D6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE4D7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x82E4D3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E4D7;
L_82E4D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4D7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE4D7u,0x82E4D7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D7u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4D7u, 8u, 3u, cpu.address("abs", 0x19D4u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E4D7 INC
    cpu.incMem(hw, cpu.address("abs", 0x19D4u), cpu.m8?8:16);
    goto L_82E4DA;
L_82E4DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE4DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE4DAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E4DA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82E4DAu);return;} hw.unresolvedReturn(0x82E4DAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_83A320_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A320u: goto L_83A320;
    case 0x83A323u: goto L_83A323;
    case 0x83A324u: goto L_83A324;
    case 0x83A327u: goto L_83A327;
    case 0x83A329u: goto L_83A329;
    case 0x83A32Cu: goto L_83A32C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA320u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA320u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A320 LDA
    cpu.setA(0x1000u, 16);
    goto L_83A323;
L_83A323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA323u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA323u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A323 CLC
    cpu.setFlag('C', false);
    goto L_83A324;
L_83A324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA324u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA324u, 5u + 1u, 3u, cpu.address("absx", 0x0210u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A324 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x210u), cpu.m8?8:16));
    goto L_83A327;
L_83A327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA327u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA327u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A327 BCS -> $83A32C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A32C; }
    goto L_83A329;
L_83A329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA329u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA329u, 6u, 3u, cpu.address("absx", 0x0210u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A329 STA
    hw.write(cpu.address("absx", 0x210u), cpu.a, cpu.m8?8:16);
    goto L_83A32C;
L_83A32C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA32Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A32C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A32Cu);return;} hw.unresolvedReturn(0x83A32Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83A320_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A320u: goto L_83A320;
    case 0x83A323u: goto L_83A323;
    case 0x83A324u: goto L_83A324;
    case 0x83A327u: goto L_83A327;
    case 0x83A329u: goto L_83A329;
    case 0x83A32Cu: goto L_83A32C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA320u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA320u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A320 LDA
    cpu.setA(0x1000u, 16);
    goto L_83A323;
L_83A323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA323u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA323u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A323 CLC
    cpu.setFlag('C', false);
    goto L_83A324;
L_83A324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA324u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA324u, 5u + 1u, 3u, cpu.address("absx", 0x0210u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A324 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x210u), cpu.m8?8:16));
    goto L_83A327;
L_83A327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA327u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA327u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A327 BCS -> $83A32C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A32C; }
    goto L_83A329;
L_83A329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA329u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA329u, 6u, 3u, cpu.address("absx", 0x0210u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A329 STA
    hw.write(cpu.address("absx", 0x210u), cpu.a, cpu.m8?8:16);
    goto L_83A32C;
L_83A32C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA32Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A32C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A32Cu);return;} hw.unresolvedReturn(0x83A32Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83A320_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A320u: goto L_83A320;
    case 0x83A323u: goto L_83A323;
    case 0x83A324u: goto L_83A324;
    case 0x83A327u: goto L_83A327;
    case 0x83A329u: goto L_83A329;
    case 0x83A32Cu: goto L_83A32C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA320u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA320u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A320 LDA
    cpu.setA(0x1000u, 16);
    goto L_83A323;
L_83A323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA323u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA323u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A323 CLC
    cpu.setFlag('C', false);
    goto L_83A324;
L_83A324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA324u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA324u, 5u + 1u, 3u, cpu.address("absx", 0x0210u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A324 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x210u), cpu.m8?8:16));
    goto L_83A327;
L_83A327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA327u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA327u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A327 BCS -> $83A32C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A32C; }
    goto L_83A329;
L_83A329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA329u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA329u, 6u, 3u, cpu.address("absx", 0x0210u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A329 STA
    hw.write(cpu.address("absx", 0x210u), cpu.a, cpu.m8?8:16);
    goto L_83A32C;
L_83A32C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA32Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A32C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A32Cu);return;} hw.unresolvedReturn(0x83A32Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83CE72_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83CE72u: goto L_83CE72;
    case 0x83CE74u: goto L_83CE74;
    case 0x83CE76u: goto L_83CE76;
    case 0x83CE78u: goto L_83CE78;
    case 0x83CE79u: goto L_83CE79;
    case 0x83CE7Cu: goto L_83CE7C;
    case 0x83CE7Eu: goto L_83CE7E;
    case 0x83CE81u: goto L_83CE81;
    case 0x83CE83u: goto L_83CE83;
    case 0x83CE85u: goto L_83CE85;
    case 0x83CE88u: goto L_83CE88;
    case 0x83CE8Bu: goto L_83CE8B;
    case 0x83CE8Eu: goto L_83CE8E;
    case 0x83CE90u: goto L_83CE90;
    case 0x83CE93u: goto L_83CE93;
    case 0x83CE94u: goto L_83CE94;
    case 0x83CE97u: goto L_83CE97;
    case 0x83CE99u: goto L_83CE99;
    case 0x83CE9Au: goto L_83CE9A;
    case 0x83CE9Bu: goto L_83CE9B;
    case 0x83CE9Du: goto L_83CE9D;
    case 0x83CE9Eu: goto L_83CE9E;
    case 0x83CEA1u: goto L_83CEA1;
    case 0x83CEA3u: goto L_83CEA3;
    case 0x83CEA6u: goto L_83CEA6;
    case 0x83CEA8u: goto L_83CEA8;
    case 0x83CEAAu: goto L_83CEAA;
    case 0x83CEADu: goto L_83CEAD;
    case 0x83CEB0u: goto L_83CEB0;
    case 0x83CEB3u: goto L_83CEB3;
    case 0x83CEB5u: goto L_83CEB5;
    case 0x83CEB8u: goto L_83CEB8;
    case 0x83CEB9u: goto L_83CEB9;
    case 0x83CEBCu: goto L_83CEBC;
    case 0x83CEBEu: goto L_83CEBE;
    case 0x83CEBFu: goto L_83CEBF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83CE72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE72u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE72u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE72 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CE74;
L_83CE74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE74u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE74 BNE -> $83CE9B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CE9B; }
    goto L_83CE76;
L_83CE76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE76u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE76u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE76 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CE78;
L_83CE78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE78u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE78u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE78 SEC
    cpu.setFlag('C', true);
    goto L_83CE79;
L_83CE79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE79u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE79u, 5u, 3u, cpu.address("abs", 0x070Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE79 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x70Eu), cpu.m8?8:16));
    goto L_83CE7C;
L_83CE7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE7C BMI -> $83CE94
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CE94; }
    goto L_83CE7E;
L_83CE7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE7E CMP
    cpu.compareA(0x40u);
    goto L_83CE81;
L_83CE81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE81u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE81 BPL -> $83CE99
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CE99; }
    goto L_83CE83;
L_83CE83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE83u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE83u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE83 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CE85;
L_83CE85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE85u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE85u, 5u, 3u, cpu.address("abs", 0x070Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE85 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x70Au), cpu.m8?8:16));
    goto L_83CE88;
L_83CE88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE88u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE88u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE88 ADC
    cpu.adc(0x10u);
    goto L_83CE8B;
L_83CE8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE8B CMP
    cpu.compareA(0x20u);
    goto L_83CE8E;
L_83CE8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE8E BCS -> $83CE9A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CE9A; }
    goto L_83CE90;
L_83CE90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE90u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE90 LDA
    cpu.setA(0x700u, 16);
    goto L_83CE93;
L_83CE93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE93u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE93u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CE93 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CE93u);return;} hw.unresolvedReturn(0x83CE93u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83CE94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE94u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE94u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE94 ADC
    cpu.adc(0x40u);
    goto L_83CE97;
L_83CE97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE97u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE97u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE97 BPL -> $83CE83
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CE83; }
    goto L_83CE99;
L_83CE99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE99u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE99u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE99 SEC
    cpu.setFlag('C', true);
    goto L_83CE9A;
L_83CE9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE9Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CE9A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CE9Au);return;} hw.unresolvedReturn(0x83CE9Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CE9A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CE9Au);return;} hw.unresolvedReturn(0x83CE9Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCE9Au,0x83CE9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE9B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CE9D;
L_83CE9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE9D SEC
    cpu.setFlag('C', true);
    goto L_83CE9E;
L_83CE9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Eu,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Eu, 5u, 3u, cpu.address("abs", 0x075Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CE9E SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x75Eu), cpu.m8?8:16));
    goto L_83CEA1;
L_83CEA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA1u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEA1 BMI -> $83CEB9
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CEB9; }
    goto L_83CEA3;
L_83CEA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEA3 CMP
    cpu.compareA(0x40u);
    goto L_83CEA6;
L_83CEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEA6 BPL -> $83CEBE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CEBE; }
    goto L_83CEA8;
L_83CEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA8u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEA8 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CEAA;
L_83CEAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEAAu,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEAAu, 5u, 3u, cpu.address("abs", 0x075Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEAA SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x75Au), cpu.m8?8:16));
    goto L_83CEAD;
L_83CEAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEADu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEAD ADC
    cpu.adc(0x10u);
    goto L_83CEB0;
L_83CEB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEB0 CMP
    cpu.compareA(0x20u);
    goto L_83CEB3;
L_83CEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB3u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEB3 BCS -> $83CEBF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CEBF; }
    goto L_83CEB5;
L_83CEB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEB5 LDA
    cpu.setA(0x750u, 16);
    goto L_83CEB8;
L_83CEB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CEB8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CEB8u);return;} hw.unresolvedReturn(0x83CEB8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83CEB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEB9 ADC
    cpu.adc(0x40u);
    goto L_83CEBC;
L_83CEBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEBC BPL -> $83CEA8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CEA8; }
    goto L_83CEBE;
L_83CEBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEBE SEC
    cpu.setFlag('C', true);
    goto L_83CEBF;
L_83CEBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEBFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CEBF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CEBFu);return;} hw.unresolvedReturn(0x83CEBFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CEBF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CEBFu);return;} hw.unresolvedReturn(0x83CEBFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCEBFu,0x83CEBFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84801D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84801Du: goto L_84801D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84801D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x801Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x801Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x801Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84801D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84801Du);return;} hw.unresolvedReturn(0x84801Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84801D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84801Du: goto L_84801D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84801D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x801Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x801Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x801Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84801D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84801Du);return;} hw.unresolvedReturn(0x84801Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

