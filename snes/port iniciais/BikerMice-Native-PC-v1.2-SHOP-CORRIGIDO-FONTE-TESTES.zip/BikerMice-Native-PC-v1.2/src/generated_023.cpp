#include "generated.hpp"
void sub_20847A_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x20847Au: goto L_20847A;
    case 0x20847Cu: goto L_20847C;
    case 0x20847Fu: goto L_20847F;
    case 0x208482u: goto L_208482;
    case 0x208484u: goto L_208484;
    case 0x208487u: goto L_208487;
    case 0x20848Au: goto L_20848A;
    case 0x20848Du: goto L_20848D;
    case 0x208490u: goto L_208490;
    case 0x208492u: goto L_208492;
    case 0x208495u: goto L_208495;
    case 0x208498u: goto L_208498;
    case 0x20849Bu: goto L_20849B;
    case 0x20849Eu: goto L_20849E;
    case 0x2084A0u: goto L_2084A0;
    case 0x2084A3u: goto L_2084A3;
    case 0x2084A4u: goto L_2084A4;
    case 0x2084A5u: goto L_2084A5;
    case 0x2084A8u: goto L_2084A8;
    case 0x2084AAu: goto L_2084AA;
    case 0x2084ACu: goto L_2084AC;
    case 0x2084ADu: goto L_2084AD;
    case 0x2084AFu: goto L_2084AF;
    case 0x2084B2u: goto L_2084B2;
    case 0x2084B5u: goto L_2084B5;
    case 0x2084B8u: goto L_2084B8;
    case 0x2084BBu: goto L_2084BB;
    case 0x2084BEu: goto L_2084BE;
    case 0x2084C1u: goto L_2084C1;
    case 0x2084C3u: goto L_2084C3;
    case 0x2084C6u: goto L_2084C6;
    case 0x2084C7u: goto L_2084C7;
    case 0x2084C8u: goto L_2084C8;
    case 0x2084CBu: goto L_2084CB;
    case 0x2084CDu: goto L_2084CD;
    case 0x2084CFu: goto L_2084CF;
    case 0x2084D0u: goto L_2084D0;
    case 0x2084D3u: goto L_2084D3;
    case 0x2084D6u: goto L_2084D6;
    case 0x2084D8u: goto L_2084D8;
    case 0x2084DAu: goto L_2084DA;
    case 0x2084DBu: goto L_2084DB;
    case 0x2084DEu: goto L_2084DE;
    case 0x2084DFu: goto L_2084DF;
    case 0x2084E2u: goto L_2084E2;
    case 0x2084E4u: goto L_2084E4;
    case 0x2084E6u: goto L_2084E6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_20847A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20847A REP
    cpu.rep(0x30u);
    goto L_20847C;
L_20847C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Cu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Cu, 5u, 3u, cpu.address("abs", 0x1037u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20847C LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1037u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_20847F;
L_20847F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Fu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20847F CPX
    cpu.compareX(0x2u);
    goto L_208482;
L_208482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8482u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8482u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208482 BNE -> $2084DB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_2084DB; }
    goto L_208484;
L_208484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8484u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8484u, 5u, 3u, cpu.address("abs", 0x1037u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208484 STZ
    hw.write(cpu.address("abs", 0x1037u), 0, cpu.m8?8:16);
    goto L_208487;
L_208487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8487u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8487u, 5u, 3u, cpu.address("abs", 0x1038u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208487 STZ
    hw.write(cpu.address("abs", 0x1038u), 0, cpu.m8?8:16);
    goto L_20848A;
L_20848A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x848Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Au, 5u, 3u, cpu.address("abs", 0x1035u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20848A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1035u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_20848D;
L_20848D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x848Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20848D CMP
    cpu.compareA(0x1u);
    goto L_208490;
L_208490:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8490u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8490u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8490u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208490 BEQ -> $2084AD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_2084AD; }
    goto L_208492;
L_208492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8492u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8492u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8492u, 5u, 3u, cpu.address("abs", 0x1033u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208492 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1033u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_208495;
L_208495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8495u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8495u, 5u + 1u, 3u, cpu.address("absx", 0x949Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208495 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x949Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_208498;
L_208498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8498u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8498u, 5u, 3u, cpu.address("abs", 0x0516u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208498 STA
    hw.write(cpu.address("abs", 0x516u), cpu.a, cpu.m8?8:16);
    goto L_20849B;
L_20849B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Bu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20849B CPX
    cpu.compareX(0x10u);
    goto L_20849E;
L_20849E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20849E BEQ -> $2084AD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_2084AD; }
    goto L_2084A0;
L_2084A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A0u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A0u, 5u, 3u, cpu.address("abs", 0x1033u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084A0 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1033u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_2084A3;
L_2084A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084A3 INX
    cpu.inc('X');
    goto L_2084A4;
L_2084A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084A4 INX
    cpu.inc('X');
    goto L_2084A5;
L_2084A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A5u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A5u, 5u, 3u, cpu.address("abs", 0x1033u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084A5 STX
    hw.write(cpu.address("abs", 0x1033u), cpu.x, cpu.x8?8:16);
    goto L_2084A8;
L_2084A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084A8 REP
    cpu.rep(0x30u);
    goto L_2084AA;
L_2084AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84AAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84AAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084AA SEP
    cpu.sep(0x20u);
    goto L_2084AC;
L_2084AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84ACu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84ACu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2084AC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x2084ACu);return;} hw.unresolvedReturn(0x2084ACu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_2084AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84ADu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084AD REP
    cpu.rep(0x30u);
    goto L_2084AF;
L_2084AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84AFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084AF LDA
    cpu.setA(0x1u, 16);
    goto L_2084B2;
L_2084B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B2u, 5u, 3u, cpu.address("abs", 0x1035u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084B2 STA
    hw.write(cpu.address("abs", 0x1035u), cpu.a, cpu.m8?8:16);
    goto L_2084B5;
L_2084B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B5u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B5u, 5u, 3u, cpu.address("abs", 0x1033u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084B5 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1033u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_2084B8;
L_2084B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u, 5u + 1u, 3u, cpu.address("absx", 0x949Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084B8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x949Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2084BB;
L_2084BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu, 5u, 3u, cpu.address("abs", 0x0516u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084BB STA
    hw.write(cpu.address("abs", 0x516u), cpu.a, cpu.m8?8:16);
    goto L_2084BE;
L_2084BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BEu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084BE CPX
    cpu.compareX(0x0u);
    goto L_2084C1;
L_2084C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084C1 BEQ -> $2084D0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_2084D0; }
    goto L_2084C3;
L_2084C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C3u, 5u, 3u, cpu.address("abs", 0x1033u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084C3 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1033u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_2084C6;
L_2084C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C6u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084C6 DEX
    cpu.decReg('X');
    goto L_2084C7;
L_2084C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084C7 DEX
    cpu.decReg('X');
    goto L_2084C8;
L_2084C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C8u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C8u, 5u, 3u, cpu.address("abs", 0x1033u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084C8 STX
    hw.write(cpu.address("abs", 0x1033u), cpu.x, cpu.x8?8:16);
    goto L_2084CB;
L_2084CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084CB REP
    cpu.rep(0x30u);
    goto L_2084CD;
L_2084CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084CD SEP
    cpu.sep(0x20u);
    goto L_2084CF;
L_2084CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2084CF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x2084CFu);return;} hw.unresolvedReturn(0x2084CFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_2084D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084D0 LDX
    cpu.setX(0x0u, 16);
    goto L_2084D3;
L_2084D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D3u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D3u, 5u, 3u, cpu.address("abs", 0x1035u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084D3 STX
    hw.write(cpu.address("abs", 0x1035u), cpu.x, cpu.x8?8:16);
    goto L_2084D6;
L_2084D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084D6 REP
    cpu.rep(0x30u);
    goto L_2084D8;
L_2084D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084D8 SEP
    cpu.sep(0x20u);
    goto L_2084DA;
L_2084DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84DAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84DAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2084DA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x2084DAu);return;} hw.unresolvedReturn(0x2084DAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_2084DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84DBu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84DBu, 5u, 3u, cpu.address("abs", 0x1037u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084DB LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1037u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_2084DE;
L_2084DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84DEu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084DE INX
    cpu.inc('X');
    goto L_2084DF;
L_2084DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84DFu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84DFu, 5u, 3u, cpu.address("abs", 0x1037u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084DF STX
    hw.write(cpu.address("abs", 0x1037u), cpu.x, cpu.x8?8:16);
    goto L_2084E2;
L_2084E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084E2 REP
    cpu.rep(0x30u);
    goto L_2084E4;
L_2084E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2084E4 SEP
    cpu.sep(0x20u);
    goto L_2084E6;
L_2084E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84E6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84E6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2084E6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x2084E6u);return;} hw.unresolvedReturn(0x2084E6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80AFF3_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AFF3u: goto L_80AFF3;
    case 0x80AFF5u: goto L_80AFF5;
    case 0x80AFF7u: goto L_80AFF7;
    case 0x80AFF9u: goto L_80AFF9;
    case 0x80AFFCu: goto L_80AFFC;
    case 0x80AFFEu: goto L_80AFFE;
    case 0x80B0C4u: goto L_80B0C4;
    case 0x80B0C6u: goto L_80B0C6;
    case 0x80B0C7u: goto L_80B0C7;
    case 0x80B0C8u: goto L_80B0C8;
    case 0x80B0C9u: goto L_80B0C9;
    case 0x80B0CDu: goto L_80B0CD;
    case 0x80B0CFu: goto L_80B0CF;
    case 0x80B0D0u: goto L_80B0D0;
    case 0x80B0D2u: goto L_80B0D2;
    case 0x80B0D3u: goto L_80B0D3;
    case 0x80B0D5u: goto L_80B0D5;
    case 0x80B0D6u: goto L_80B0D6;
    case 0x80B0D9u: goto L_80B0D9;
    case 0x80B0DCu: goto L_80B0DC;
    case 0x80B0DFu: goto L_80B0DF;
    case 0x80B0E2u: goto L_80B0E2;
    case 0x80B0E5u: goto L_80B0E5;
    case 0x80B0E8u: goto L_80B0E8;
    case 0x80B0EAu: goto L_80B0EA;
    case 0x80B0EDu: goto L_80B0ED;
    case 0x80B0EFu: goto L_80B0EF;
    case 0x80B0F1u: goto L_80B0F1;
    case 0x80B0F4u: goto L_80B0F4;
    case 0x80B0F6u: goto L_80B0F6;
    case 0x80B0F9u: goto L_80B0F9;
    case 0x80B0FBu: goto L_80B0FB;
    case 0x80B0FEu: goto L_80B0FE;
    case 0x80B100u: goto L_80B100;
    case 0x80B102u: goto L_80B102;
    case 0x80B103u: goto L_80B103;
    case 0x80B104u: goto L_80B104;
    case 0x80B106u: goto L_80B106;
    case 0x80B108u: goto L_80B108;
    case 0x80B10Au: goto L_80B10A;
    case 0x80B10Cu: goto L_80B10C;
    case 0x80B10Eu: goto L_80B10E;
    case 0x80B111u: goto L_80B111;
    case 0x80B113u: goto L_80B113;
    case 0x80B117u: goto L_80B117;
    case 0x80B118u: goto L_80B118;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AFF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFF3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AFF5;
L_80AFF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF5u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFF5 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16));
    goto L_80AFF7;
L_80AFF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFF7 STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80AFF9;
L_80AFF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFF9 LDA
    cpu.setA(0x7Eu, 16);
    goto L_80AFFC;
L_80AFFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFFC STA
    hw.write(cpu.address("dp", 0x2Cu), cpu.a, cpu.m8?8:16);
    goto L_80AFFE;
L_80AFFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFEu, 3u, 3u, cpu.address("abs", 0xB0C4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFFE JMP -> $80B0C4
    goto L_80B0C4;
L_80B0C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0C4 SEP
    cpu.sep(0x30u);
    goto L_80B0C6;
L_80B0C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C6u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B0C6 PHB
    cpu.push("PHB", hw);
    goto L_80B0C7;
L_80B0C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C7u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B0C7 PHK
    cpu.push("PHK", hw);
    goto L_80B0C8;
L_80B0C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C8u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B0C8 PLB
    cpu.pop("PLB", hw);
    goto L_80B0C9;
L_80B0C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C9u, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B0C9 JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB0CCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0CDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x80B0C9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B0CD;
L_80B0CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0CDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0CDu,0x80B0CDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0CD LDA
    cpu.setA(0x0u, 8);
    goto L_80B0CF;
L_80B0CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CFu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0CF XBA
    cpu.xba();
    goto L_80B0D0;
L_80B0D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0D0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0D2;
L_80B0D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0D2 LSR
    cpu.lsrA();
    goto L_80B0D3;
L_80B0D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0D3 AND
    cpu.logicAnd(0x3u);
    goto L_80B0D5;
L_80B0D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0D5 TAX
    cpu.transfer("TAX");
    goto L_80B0D6;
L_80B0D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D6u, 4u + ((((0xB159u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xB159u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0D6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB159u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0D9;
L_80B0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D9u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0D9 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_80B0DC;
L_80B0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DCu, 4u + ((((0xB15Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xB15Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0DC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB15Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0DF;
L_80B0DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DFu, 4u, 3u, cpu.address("abs", 0x4300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0DF STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80B0E2;
L_80B0E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E2u, 4u + ((((0xB161u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xB161u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0E2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB161u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0E5;
L_80B0E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E5u, 4u, 3u, cpu.address("abs", 0x4301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0E5 STA
    hw.write(cpu.address("abs", 0x4301u), cpu.a, cpu.m8?8:16);
    goto L_80B0E8;
L_80B0E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0E8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0EA;
L_80B0EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EAu, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0EA STA
    hw.write(cpu.address("abs", 0x4304u), cpu.a, cpu.m8?8:16);
    goto L_80B0ED;
L_80B0ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0ED REP
    cpu.rep(0x20u);
    goto L_80B0EF;
L_80B0EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0EF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0F1;
L_80B0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F1u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0F1 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_80B0F4;
L_80B0F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0F4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0F6;
L_80B0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F6u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0F6 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_80B0F9;
L_80B0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0F9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0FB;
L_80B0FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0FBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0FBu, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0FB STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_80B0FE;
L_80B0FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0FEu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0FE CPX
    cpu.compareX(0x1u);
    goto L_80B100;
L_80B100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB100u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB100u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B100 BCS -> $80B103
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B103; }
    goto L_80B102;
L_80B102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB102u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB102u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B102 LSR
    cpu.lsrA();
    goto L_80B103;
L_80B103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB103u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB103u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B103 CLC
    cpu.setFlag('C', false);
    goto L_80B104;
L_80B104:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB104u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB104u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB104u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B104 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16));
    goto L_80B106;
L_80B106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB106u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB106u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B106 STA
    hw.write(cpu.address("dp", 0x15u), cpu.a, cpu.m8?8:16);
    goto L_80B108;
L_80B108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB108u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB108u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B108 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B10A;
L_80B10A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B10A STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_80B10C;
L_80B10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B10C LDY
    cpu.setY(0x1u, 8);
    goto L_80B10E;
L_80B10E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Eu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Eu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B10E STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_80B111;
L_80B111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB111u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB111u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B111 REP
    cpu.rep(0x10u);
    goto L_80B113;
L_80B113:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB113u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB113u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB113u, 8u, 4u, 0x8084E8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B113 JSL -> $8084E8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB116u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB117u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084E8u, 0x80B113u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B117;
L_80B117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB117u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB117u,0x80B117u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB117u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB117u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B117 PLB
    cpu.pop("PLB", hw);
    goto L_80B118;
L_80B118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB118u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB118u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B118 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B118u);return;} hw.unresolvedReturn(0x80B118u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80AFF3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AFF3u: goto L_80AFF3;
    case 0x80AFF5u: goto L_80AFF5;
    case 0x80AFF7u: goto L_80AFF7;
    case 0x80AFF9u: goto L_80AFF9;
    case 0x80AFFCu: goto L_80AFFC;
    case 0x80AFFEu: goto L_80AFFE;
    case 0x80B0C4u: goto L_80B0C4;
    case 0x80B0C6u: goto L_80B0C6;
    case 0x80B0C7u: goto L_80B0C7;
    case 0x80B0C8u: goto L_80B0C8;
    case 0x80B0C9u: goto L_80B0C9;
    case 0x80B0CDu: goto L_80B0CD;
    case 0x80B0CFu: goto L_80B0CF;
    case 0x80B0D0u: goto L_80B0D0;
    case 0x80B0D2u: goto L_80B0D2;
    case 0x80B0D3u: goto L_80B0D3;
    case 0x80B0D5u: goto L_80B0D5;
    case 0x80B0D6u: goto L_80B0D6;
    case 0x80B0D9u: goto L_80B0D9;
    case 0x80B0DCu: goto L_80B0DC;
    case 0x80B0DFu: goto L_80B0DF;
    case 0x80B0E2u: goto L_80B0E2;
    case 0x80B0E5u: goto L_80B0E5;
    case 0x80B0E8u: goto L_80B0E8;
    case 0x80B0EAu: goto L_80B0EA;
    case 0x80B0EDu: goto L_80B0ED;
    case 0x80B0EFu: goto L_80B0EF;
    case 0x80B0F1u: goto L_80B0F1;
    case 0x80B0F4u: goto L_80B0F4;
    case 0x80B0F6u: goto L_80B0F6;
    case 0x80B0F9u: goto L_80B0F9;
    case 0x80B0FBu: goto L_80B0FB;
    case 0x80B0FEu: goto L_80B0FE;
    case 0x80B100u: goto L_80B100;
    case 0x80B102u: goto L_80B102;
    case 0x80B103u: goto L_80B103;
    case 0x80B104u: goto L_80B104;
    case 0x80B106u: goto L_80B106;
    case 0x80B108u: goto L_80B108;
    case 0x80B10Au: goto L_80B10A;
    case 0x80B10Cu: goto L_80B10C;
    case 0x80B10Eu: goto L_80B10E;
    case 0x80B111u: goto L_80B111;
    case 0x80B113u: goto L_80B113;
    case 0x80B117u: goto L_80B117;
    case 0x80B118u: goto L_80B118;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AFF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFF3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AFF5;
L_80AFF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF5u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFF5 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16));
    goto L_80AFF7;
L_80AFF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFF7 STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80AFF9;
L_80AFF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFF9 LDA
    cpu.setA(0x7Eu, 16);
    goto L_80AFFC;
L_80AFFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFFC STA
    hw.write(cpu.address("dp", 0x2Cu), cpu.a, cpu.m8?8:16);
    goto L_80AFFE;
L_80AFFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFEu, 3u, 3u, cpu.address("abs", 0xB0C4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFFE JMP -> $80B0C4
    goto L_80B0C4;
L_80B0C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0C4 SEP
    cpu.sep(0x30u);
    goto L_80B0C6;
L_80B0C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C6u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B0C6 PHB
    cpu.push("PHB", hw);
    goto L_80B0C7;
L_80B0C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C7u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B0C7 PHK
    cpu.push("PHK", hw);
    goto L_80B0C8;
L_80B0C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C8u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B0C8 PLB
    cpu.pop("PLB", hw);
    goto L_80B0C9;
L_80B0C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C9u, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B0C9 JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB0CCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0CDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x80B0C9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B0CD;
L_80B0CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0CDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0CDu,0x80B0CDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0CD LDA
    cpu.setA(0x0u, 8);
    goto L_80B0CF;
L_80B0CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CFu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0CF XBA
    cpu.xba();
    goto L_80B0D0;
L_80B0D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0D0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0D2;
L_80B0D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0D2 LSR
    cpu.lsrA();
    goto L_80B0D3;
L_80B0D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0D3 AND
    cpu.logicAnd(0x3u);
    goto L_80B0D5;
L_80B0D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0D5 TAX
    cpu.transfer("TAX");
    goto L_80B0D6;
L_80B0D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D6u, 4u + ((((0xB159u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xB159u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0D6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB159u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0D9;
L_80B0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D9u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0D9 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_80B0DC;
L_80B0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DCu, 4u + ((((0xB15Du & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xB15Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0DC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB15Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0DF;
L_80B0DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DFu, 4u, 3u, cpu.address("abs", 0x4300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0DF STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80B0E2;
L_80B0E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E2u, 4u + ((((0xB161u & 0xFFu) + (cpu.x & 0xFFu)) > 0xFFu) ? 1u : 0u), 3u, cpu.address("absx", 0xB161u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0E2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xB161u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0E5;
L_80B0E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E5u, 4u, 3u, cpu.address("abs", 0x4301u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0E5 STA
    hw.write(cpu.address("abs", 0x4301u), cpu.a, cpu.m8?8:16);
    goto L_80B0E8;
L_80B0E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0E8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0EA;
L_80B0EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EAu, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0EA STA
    hw.write(cpu.address("abs", 0x4304u), cpu.a, cpu.m8?8:16);
    goto L_80B0ED;
L_80B0ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0ED REP
    cpu.rep(0x20u);
    goto L_80B0EF;
L_80B0EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0EF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0F1;
L_80B0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F1u, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0F1 STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_80B0F4;
L_80B0F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0F4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0F6;
L_80B0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F6u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0F6 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_80B0F9;
L_80B0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0F9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0FB;
L_80B0FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0FBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0FBu, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0FB STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_80B0FE;
L_80B0FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0FEu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0FE CPX
    cpu.compareX(0x1u);
    goto L_80B100;
L_80B100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB100u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB100u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B100 BCS -> $80B103
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B103; }
    goto L_80B102;
L_80B102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB102u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB102u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B102 LSR
    cpu.lsrA();
    goto L_80B103;
L_80B103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB103u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB103u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B103 CLC
    cpu.setFlag('C', false);
    goto L_80B104;
L_80B104:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB104u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB104u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB104u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B104 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16));
    goto L_80B106;
L_80B106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB106u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB106u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B106 STA
    hw.write(cpu.address("dp", 0x15u), cpu.a, cpu.m8?8:16);
    goto L_80B108;
L_80B108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB108u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB108u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B108 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B10A;
L_80B10A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B10A STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_80B10C;
L_80B10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B10C LDY
    cpu.setY(0x1u, 8);
    goto L_80B10E;
L_80B10E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Eu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Eu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B10E STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_80B111;
L_80B111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB111u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB111u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B111 REP
    cpu.rep(0x10u);
    goto L_80B113;
L_80B113:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB113u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB113u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB113u, 8u, 4u, 0x8084E8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B113 JSL -> $8084E8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB116u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB117u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084E8u, 0x80B113u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B117;
L_80B117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB117u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB117u,0x80B117u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB117u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB117u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80B117 PLB
    cpu.pop("PLB", hw);
    goto L_80B118;
L_80B118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB118u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB118u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B118 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B118u);return;} hw.unresolvedReturn(0x80B118u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80BC03_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BC03u: goto L_80BC03;
    case 0x80BC07u: goto L_80BC07;
    case 0x80BC09u: goto L_80BC09;
    case 0x80BC0Bu: goto L_80BC0B;
    case 0x80BC0Du: goto L_80BC0D;
    case 0x80BC10u: goto L_80BC10;
    case 0x80BC12u: goto L_80BC12;
    case 0x80BC14u: goto L_80BC14;
    case 0x80BC16u: goto L_80BC16;
    case 0x80BC17u: goto L_80BC17;
    case 0x80BC19u: goto L_80BC19;
    case 0x80BC1Cu: goto L_80BC1C;
    case 0x80BC1Eu: goto L_80BC1E;
    case 0x80BC20u: goto L_80BC20;
    case 0x80BC22u: goto L_80BC22;
    case 0x80BC24u: goto L_80BC24;
    case 0x80BC26u: goto L_80BC26;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BC03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC03u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC03u, 8u, 4u, 0x8284B8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC03 JSL -> $8284B8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC06u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC07u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8284B8u, 0x80BC03u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BC07;
L_80BC07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC07u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC07u,0x80BC07u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC07u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC07u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC07 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC09;
L_80BC09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC09u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC09 BNE -> $80BC12
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BC12; }
    goto L_80BC0B;
L_80BC0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC0B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC0D;
L_80BC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC0D CMP
    cpu.compareA(0x2u);
    goto L_80BC10;
L_80BC10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC10u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC10u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC10 BCC -> $80BC14
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BC14; }
    goto L_80BC12;
L_80BC12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC12u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC12u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC12u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC12 INC
    cpu.incMem(hw, cpu.address("dp", 0x80u), cpu.m8?8:16);
    goto L_80BC14;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC12u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC12u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC12 INC
    cpu.incMem(hw, cpu.address("dp", 0x80u), cpu.m8?8:16);
    goto L_80BC14;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC12u,0x80BC12u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC14u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC14u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC14u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC14 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC16;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC14u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC14u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC14 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC16;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC14u,0x80BC14u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC16u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC16u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC16 INC
    cpu.inc('A');
    goto L_80BC17;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC16u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC16 INC
    cpu.inc('A');
    goto L_80BC17;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC16u,0x80BC16u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC17u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC17u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC17 STA
    hw.write(cpu.address("dp", 0x80u), cpu.a, cpu.m8?8:16);
    goto L_80BC19;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC17u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC17 STA
    hw.write(cpu.address("dp", 0x80u), cpu.a, cpu.m8?8:16);
    goto L_80BC19;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC17u,0x80BC17u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC19u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC19 LDA
    cpu.setA(0x1u, 16);
    goto L_80BC1C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC19 LDA
    cpu.setA(0x1u, 16);
    goto L_80BC1C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC19u,0x80BC19u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1C STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_80BC1E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1C STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_80BC1E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC1Cu,0x80BC1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1E STZ
    hw.write(cpu.address("dp", 0x82u), 0, cpu.m8?8:16);
    goto L_80BC20;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1E STZ
    hw.write(cpu.address("dp", 0x82u), 0, cpu.m8?8:16);
    goto L_80BC20;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC1Eu,0x80BC1Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC20u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC20 STZ
    hw.write(cpu.address("dp", 0x84u), 0, cpu.m8?8:16);
    goto L_80BC22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC20 STZ
    hw.write(cpu.address("dp", 0x84u), 0, cpu.m8?8:16);
    goto L_80BC22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC20u,0x80BC20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC22u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC22 STZ
    hw.write(cpu.address("dp", 0x88u), 0, cpu.m8?8:16);
    goto L_80BC24;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC22 STZ
    hw.write(cpu.address("dp", 0x88u), 0, cpu.m8?8:16);
    goto L_80BC24;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC22u,0x80BC22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC24u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC24 STZ
    hw.write(cpu.address("dp", 0x86u), 0, cpu.m8?8:16);
    goto L_80BC26;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC24 STZ
    hw.write(cpu.address("dp", 0x86u), 0, cpu.m8?8:16);
    goto L_80BC26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC24u,0x80BC24u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC26u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC26 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BC26u);return;} hw.unresolvedReturn(0x80BC26u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC26 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BC26u);return;} hw.unresolvedReturn(0x80BC26u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC26u,0x80BC26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80BEEB_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BC14u: goto L_80BC14;
    case 0x80BC16u: goto L_80BC16;
    case 0x80BC17u: goto L_80BC17;
    case 0x80BC19u: goto L_80BC19;
    case 0x80BC1Cu: goto L_80BC1C;
    case 0x80BC1Eu: goto L_80BC1E;
    case 0x80BC20u: goto L_80BC20;
    case 0x80BC22u: goto L_80BC22;
    case 0x80BC24u: goto L_80BC24;
    case 0x80BC26u: goto L_80BC26;
    case 0x80BCA6u: goto L_80BCA6;
    case 0x80BCA8u: goto L_80BCA8;
    case 0x80BEEBu: goto L_80BEEB;
    case 0x80BEEDu: goto L_80BEED;
    case 0x80BEEFu: goto L_80BEEF;
    case 0x80BEF3u: goto L_80BEF3;
    case 0x80BEF5u: goto L_80BEF5;
    case 0x80BEF7u: goto L_80BEF7;
    case 0x80BEF8u: goto L_80BEF8;
    case 0x80BEFBu: goto L_80BEFB;
    case 0x80BEFEu: goto L_80BEFE;
    case 0x80BF01u: goto L_80BF01;
    case 0x80BF04u: goto L_80BF04;
    case 0x80BF05u: goto L_80BF05;
    case 0x80BF06u: goto L_80BF06;
    case 0x80BF09u: goto L_80BF09;
    case 0x80BF0Au: goto L_80BF0A;
    case 0x80BF0Bu: goto L_80BF0B;
    case 0x80BF0Cu: goto L_80BF0C;
    case 0x80BF0Fu: goto L_80BF0F;
    case 0x80BF11u: goto L_80BF11;
    case 0x80BF13u: goto L_80BF13;
    case 0x80BF16u: goto L_80BF16;
    case 0x80BF1Au: goto L_80BF1A;
    case 0x80BF1Eu: goto L_80BF1E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BC14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC14u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC14u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC14 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BC16;
L_80BC16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC16u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC16 INC
    cpu.inc('A');
    goto L_80BC17;
L_80BC17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC17u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC17 STA
    hw.write(cpu.address("dp", 0x80u), cpu.a, cpu.m8?8:16);
    goto L_80BC19;
L_80BC19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC19 LDA
    cpu.setA(0x1u, 16);
    goto L_80BC1C;
L_80BC1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1C STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_80BC1E;
L_80BC1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC1E STZ
    hw.write(cpu.address("dp", 0x82u), 0, cpu.m8?8:16);
    goto L_80BC20;
L_80BC20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC20 STZ
    hw.write(cpu.address("dp", 0x84u), 0, cpu.m8?8:16);
    goto L_80BC22;
L_80BC22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC22 STZ
    hw.write(cpu.address("dp", 0x88u), 0, cpu.m8?8:16);
    goto L_80BC24;
L_80BC24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC24u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BC24 STZ
    hw.write(cpu.address("dp", 0x86u), 0, cpu.m8?8:16);
    goto L_80BC26;
L_80BC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BC26 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BC26u);return;} hw.unresolvedReturn(0x80BC26u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80BCA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCA6 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_80BCA8;
L_80BCA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BCA8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BCA8u);return;} hw.unresolvedReturn(0x80BCA8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80BEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEEB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BEED;
L_80BEED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEED BNE -> $80BF16
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BF16; }
    goto L_80BEEF;
L_80BEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEFu, 8u, 4u, 0x80BE7Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BEEF JSL -> $80BE7A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBEF2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEF3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80BE7Au, 0x80BEEFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BEF3;
L_80BEF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEF3u,0x80BEF3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF3u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEF3 DEC
    cpu.decMem(hw, cpu.address("dp", 0x86u), cpu.m8?8:16);
    goto L_80BEF5;
L_80BEF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEF5 BEQ -> $80BEF8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BEF8; }
    goto L_80BEF7;
L_80BEF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BEF7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BEF7u);return;} hw.unresolvedReturn(0x80BEF7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80BEF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEF8 LDY
    cpu.setY(0x0u, 16);
    goto L_80BEFB;
L_80BEFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEFB LDX
    cpu.setX(0x700u, 16);
    goto L_80BEFE;
L_80BEFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFEu, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEFE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BF01;
L_80BF01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF01u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF01u, 6u, 3u, cpu.address("absy", 0x1AF0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF01 STA
    hw.write(cpu.address("absy", 0x1AF0u), cpu.a, cpu.m8?8:16);
    goto L_80BF04;
L_80BF04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF04u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF04 TXA
    cpu.transfer("TXA");
    goto L_80BF05;
L_80BF05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF05u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF05 CLC
    cpu.setFlag('C', false);
    goto L_80BF06;
L_80BF06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF06u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF06u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF06 ADC
    cpu.adc(0x50u);
    goto L_80BF09;
L_80BF09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF09u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF09 TAX
    cpu.transfer("TAX");
    goto L_80BF0A;
L_80BF0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF0A INY
    cpu.inc('Y');
    goto L_80BF0B;
L_80BF0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF0B INY
    cpu.inc('Y');
    goto L_80BF0C;
L_80BF0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Cu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF0C CPX
    cpu.compareX(0x8E0u);
    goto L_80BF0F;
L_80BF0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF0F BCC -> $80BEFE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BEFE; }
    goto L_80BF11;
L_80BF11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF11u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xEAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF11 STZ
    hw.write(cpu.address("dp", 0xEAu), 0, cpu.m8?8:16);
    goto L_80BF13;
L_80BF13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF13u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF13u, 3u, 3u, cpu.address("abs", 0xBCA6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF13 JMP -> $80BCA6
    goto L_80BCA6;
L_80BF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF16u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF16u, 8u, 4u, 0x808A92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BF16 JSL -> $808A92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF19u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF1Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808A92u, 0x80BF16u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BF1A;
L_80BF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF1Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF1Au,0x80BF1Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Au, 8u, 4u, 0x82992Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BF1A JSL -> $82992B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF1Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF1Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82992Bu, 0x80BF1Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BF1E;
L_80BF1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF1Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF1Eu,0x80BF1Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Eu, 3u, 3u, cpu.address("abs", 0xBC14u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF1E JMP -> $80BC14
    goto L_80BC14;
}

void sub_80DC8F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80DC8Fu: goto L_80DC8F;
    case 0x80DC91u: goto L_80DC91;
    case 0x80DC93u: goto L_80DC93;
    case 0x80DC96u: goto L_80DC96;
    case 0x80DC98u: goto L_80DC98;
    case 0x80DC9Bu: goto L_80DC9B;
    case 0x80DC9Eu: goto L_80DC9E;
    case 0x80DCA1u: goto L_80DCA1;
    case 0x80DCA4u: goto L_80DCA4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80DC8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC8Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC8Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC8F SEP
    cpu.sep(0x20u);
    goto L_80DC91;
L_80DC91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC91u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC91 LDA
    cpu.setA(0x22u, 8);
    goto L_80DC93;
L_80DC93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC93u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC93u, 4u, 3u, cpu.address("abs", 0x210Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC93 STA
    hw.write(cpu.address("abs", 0x210Bu), cpu.a, cpu.m8?8:16);
    goto L_80DC96;
L_80DC96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC96u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC96u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC96 REP
    cpu.rep(0x20u);
    goto L_80DC98;
L_80DC98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC98u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC98u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC98 LDA
    cpu.setA(0x3u, 16);
    goto L_80DC9B;
L_80DC9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Bu, 5u, 3u, cpu.address("abs", 0x1FACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC9B STA
    hw.write(cpu.address("abs", 0x1FACu), cpu.a, cpu.m8?8:16);
    goto L_80DC9E;
L_80DC9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC9E LDA
    cpu.setA(0x59u, 16);
    goto L_80DCA1;
L_80DCA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA1u, 5u, 3u, cpu.address("abs", 0x1FB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DCA1 STA
    hw.write(cpu.address("abs", 0x1FB0u), cpu.a, cpu.m8?8:16);
    goto L_80DCA4;
L_80DCA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DCA4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DCA4u);return;} hw.unresolvedReturn(0x80DCA4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80DC8F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80DC8Fu: goto L_80DC8F;
    case 0x80DC91u: goto L_80DC91;
    case 0x80DC93u: goto L_80DC93;
    case 0x80DC96u: goto L_80DC96;
    case 0x80DC98u: goto L_80DC98;
    case 0x80DC9Bu: goto L_80DC9B;
    case 0x80DC9Eu: goto L_80DC9E;
    case 0x80DCA1u: goto L_80DCA1;
    case 0x80DCA4u: goto L_80DCA4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80DC8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC8Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC8Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC8F SEP
    cpu.sep(0x20u);
    goto L_80DC91;
L_80DC91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC91u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC91 LDA
    cpu.setA(0x22u, 8);
    goto L_80DC93;
L_80DC93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC93u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC93u, 4u, 3u, cpu.address("abs", 0x210Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC93 STA
    hw.write(cpu.address("abs", 0x210Bu), cpu.a, cpu.m8?8:16);
    goto L_80DC96;
L_80DC96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC96u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC96u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC96 REP
    cpu.rep(0x20u);
    goto L_80DC98;
L_80DC98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC98u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC98u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC98 LDA
    cpu.setA(0x3u, 16);
    goto L_80DC9B;
L_80DC9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Bu, 5u, 3u, cpu.address("abs", 0x1FACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC9B STA
    hw.write(cpu.address("abs", 0x1FACu), cpu.a, cpu.m8?8:16);
    goto L_80DC9E;
L_80DC9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DC9E LDA
    cpu.setA(0x59u, 16);
    goto L_80DCA1;
L_80DCA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA1u, 5u, 3u, cpu.address("abs", 0x1FB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DCA1 STA
    hw.write(cpu.address("abs", 0x1FB0u), cpu.a, cpu.m8?8:16);
    goto L_80DCA4;
L_80DCA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DCA4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DCA4u);return;} hw.unresolvedReturn(0x80DCA4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B2F4_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B2F4u: goto L_82B2F4;
    case 0x82B2F5u: goto L_82B2F5;
    case 0x82B2F8u: goto L_82B2F8;
    case 0x82B2FBu: goto L_82B2FB;
    case 0x82B2FCu: goto L_82B2FC;
    case 0x82B2FDu: goto L_82B2FD;
    case 0x82B2FEu: goto L_82B2FE;
    case 0x82B2FFu: goto L_82B2FF;
    case 0x82B302u: goto L_82B302;
    case 0x82B303u: goto L_82B303;
    case 0x82B306u: goto L_82B306;
    case 0x82B307u: goto L_82B307;
    case 0x82B30Au: goto L_82B30A;
    case 0x82B30Du: goto L_82B30D;
    case 0x82B310u: goto L_82B310;
    case 0x82B314u: goto L_82B314;
    case 0x82B315u: goto L_82B315;
    case 0x82B316u: goto L_82B316;
    case 0x82B318u: goto L_82B318;
    case 0x82B319u: goto L_82B319;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B2F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F4u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B2F4 PHX
    cpu.push("PHX", hw);
    goto L_82B2F5;
L_82B2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u, 6u, 3u, cpu.address("abs", 0xB411u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B2F5 JSR -> $82B411 stack real
    { cpu.push16Value(hw,0xB2F7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2F8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB411u), 0x82B2F5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B2F8;
L_82B2F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2F8u,0x82B2F8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F8u, 5u + 1u, 3u, cpu.address("absx", 0xBEB6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xBEB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B2FB;
L_82B2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FB ASL
    cpu.aslA();
    goto L_82B2FC;
L_82B2FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FC ASL
    cpu.aslA();
    goto L_82B2FD;
L_82B2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FD ASL
    cpu.aslA();
    goto L_82B2FE;
L_82B2FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FE ASL
    cpu.aslA();
    goto L_82B2FF;
L_82B2FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FF LDY
    cpu.setY(0x5D8Eu, 16);
    goto L_82B302;
L_82B302:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB302u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB302u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB302u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B302 PLX
    cpu.pop("PLX", hw);
    goto L_82B303;
L_82B303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB303u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 6u, 3u, cpu.address("abs", 0xB31Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B303 JSR -> $82B31A stack real
    { cpu.push16Value(hw,0xB305u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB306u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB31Au), 0x82B303u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B306;
L_82B306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB306u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB306u,0x82B306u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B306 PHX
    cpu.push("PHX", hw);
    goto L_82B307;
L_82B307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB307u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B307 LDX
    cpu.setX(0xAu, 16);
    goto L_82B30A;
L_82B30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au, 6u, 3u, cpu.address("abs", 0xB7B5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B30A JSR -> $82B7B5 stack real
    { cpu.push16Value(hw,0xB30Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB30Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB7B5u), 0x82B30Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B30D;
L_82B30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB30Du,0x82B30Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30D LDA
    cpu.setA(0x2001u, 16);
    goto L_82B310;
L_82B310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB310u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB310u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B310 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82B314;
L_82B314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B314 INX
    cpu.inc('X');
    goto L_82B315;
L_82B315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB315u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB315u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B315 INX
    cpu.inc('X');
    goto L_82B316;
L_82B316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB316u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB316u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B316 STX
    hw.write(cpu.address("dp", 0x52u), cpu.x, cpu.x8?8:16);
    goto L_82B318;
L_82B318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB318u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB318u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B318 PLX
    cpu.pop("PLX", hw);
    goto L_82B319;
L_82B319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB319u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB319u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B319 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B319u);return;} hw.unresolvedReturn(0x82B319u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B2F4_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B2F4u: goto L_82B2F4;
    case 0x82B2F5u: goto L_82B2F5;
    case 0x82B2F8u: goto L_82B2F8;
    case 0x82B2FBu: goto L_82B2FB;
    case 0x82B2FCu: goto L_82B2FC;
    case 0x82B2FDu: goto L_82B2FD;
    case 0x82B2FEu: goto L_82B2FE;
    case 0x82B2FFu: goto L_82B2FF;
    case 0x82B302u: goto L_82B302;
    case 0x82B303u: goto L_82B303;
    case 0x82B306u: goto L_82B306;
    case 0x82B307u: goto L_82B307;
    case 0x82B30Au: goto L_82B30A;
    case 0x82B30Du: goto L_82B30D;
    case 0x82B310u: goto L_82B310;
    case 0x82B314u: goto L_82B314;
    case 0x82B315u: goto L_82B315;
    case 0x82B316u: goto L_82B316;
    case 0x82B318u: goto L_82B318;
    case 0x82B319u: goto L_82B319;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B2F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F4u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B2F4 PHX
    cpu.push("PHX", hw);
    goto L_82B2F5;
L_82B2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u, 6u, 3u, cpu.address("abs", 0xB411u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B2F5 JSR -> $82B411 stack real
    { cpu.push16Value(hw,0xB2F7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2F8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB411u), 0x82B2F5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B2F8;
L_82B2F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2F8u,0x82B2F8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F8u, 5u + 1u, 3u, cpu.address("absx", 0xBEB6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xBEB6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B2FB;
L_82B2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FB ASL
    cpu.aslA();
    goto L_82B2FC;
L_82B2FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FC ASL
    cpu.aslA();
    goto L_82B2FD;
L_82B2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FD ASL
    cpu.aslA();
    goto L_82B2FE;
L_82B2FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FE ASL
    cpu.aslA();
    goto L_82B2FF;
L_82B2FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FF LDY
    cpu.setY(0x5D8Eu, 16);
    goto L_82B302;
L_82B302:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB302u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB302u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB302u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B302 PLX
    cpu.pop("PLX", hw);
    goto L_82B303;
L_82B303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB303u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB303u, 6u, 3u, cpu.address("abs", 0xB31Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B303 JSR -> $82B31A stack real
    { cpu.push16Value(hw,0xB305u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB306u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB31Au), 0x82B303u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B306;
L_82B306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB306u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB306u,0x82B306u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B306 PHX
    cpu.push("PHX", hw);
    goto L_82B307;
L_82B307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB307u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB307u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B307 LDX
    cpu.setX(0xAu, 16);
    goto L_82B30A;
L_82B30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au, 6u, 3u, cpu.address("abs", 0xB7B5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B30A JSR -> $82B7B5 stack real
    { cpu.push16Value(hw,0xB30Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB30Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB7B5u), 0x82B30Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B30D;
L_82B30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB30Du,0x82B30Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30D LDA
    cpu.setA(0x2001u, 16);
    goto L_82B310;
L_82B310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB310u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB310u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B310 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82B314;
L_82B314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B314 INX
    cpu.inc('X');
    goto L_82B315;
L_82B315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB315u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB315u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B315 INX
    cpu.inc('X');
    goto L_82B316;
L_82B316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB316u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB316u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B316 STX
    hw.write(cpu.address("dp", 0x52u), cpu.x, cpu.x8?8:16);
    goto L_82B318;
L_82B318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB318u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB318u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B318 PLX
    cpu.pop("PLX", hw);
    goto L_82B319;
L_82B319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB319u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB319u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B319 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B319u);return;} hw.unresolvedReturn(0x82B319u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B6CA_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B4BAu: goto L_82B4BA;
    case 0x82B4BDu: goto L_82B4BD;
    case 0x82B4BEu: goto L_82B4BE;
    case 0x82B4C1u: goto L_82B4C1;
    case 0x82B4C4u: goto L_82B4C4;
    case 0x82B4C7u: goto L_82B4C7;
    case 0x82B6CAu: goto L_82B6CA;
    case 0x82B6CCu: goto L_82B6CC;
    case 0x82B6CEu: goto L_82B6CE;
    case 0x82B6CFu: goto L_82B6CF;
    case 0x82B6D2u: goto L_82B6D2;
    case 0x82B6D5u: goto L_82B6D5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu, 6u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BA STA
    hw.write(cpu.address("absx", 0x1C48u), cpu.a, cpu.m8?8:16);
    goto L_82B4BD;
L_82B4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BD TYA
    cpu.transfer("TYA");
    goto L_82B4BE;
L_82B4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu, 6u, 3u, cpu.address("absx", 0x1C54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BE STA
    hw.write(cpu.address("absx", 0x1C54u), cpu.a, cpu.m8?8:16);
    goto L_82B4C1;
L_82B4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u, 6u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4C1 STA
    hw.write(cpu.address("absx", 0x1C5Cu), cpu.a, cpu.m8?8:16);
    goto L_82B4C4;
L_82B4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u, 9u, 3u, cpu.address("absx", 0x1C24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4C4 INC
    cpu.incMem(hw, cpu.address("absx", 0x1C24u), cpu.m8?8:16);
    goto L_82B4C7;
L_82B4C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B4C7u);return;} hw.unresolvedReturn(0x82B4C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6CA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B6CC;
L_82B6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6CC BNE -> $82B6CF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B6CF; }
    goto L_82B6CE;
L_82B6CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6CE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6CEu);return;} hw.unresolvedReturn(0x82B6CEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6CF LDA
    cpu.setA(0xBD02u, 16);
    goto L_82B6D2;
L_82B6D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6D2 LDY
    cpu.setY(0x1u, 16);
    goto L_82B6D5;
L_82B6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D5u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D5u, 3u, 3u, cpu.address("abs", 0xB4BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6D5 JMP -> $82B4BA
    goto L_82B4BA;
}

void sub_82B6CA_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B4BAu: goto L_82B4BA;
    case 0x82B4BDu: goto L_82B4BD;
    case 0x82B4BEu: goto L_82B4BE;
    case 0x82B4C1u: goto L_82B4C1;
    case 0x82B4C4u: goto L_82B4C4;
    case 0x82B4C7u: goto L_82B4C7;
    case 0x82B6CAu: goto L_82B6CA;
    case 0x82B6CCu: goto L_82B6CC;
    case 0x82B6CEu: goto L_82B6CE;
    case 0x82B6CFu: goto L_82B6CF;
    case 0x82B6D2u: goto L_82B6D2;
    case 0x82B6D5u: goto L_82B6D5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu, 6u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BA STA
    hw.write(cpu.address("absx", 0x1C48u), cpu.a, cpu.m8?8:16);
    goto L_82B4BD;
L_82B4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BD TYA
    cpu.transfer("TYA");
    goto L_82B4BE;
L_82B4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu, 6u, 3u, cpu.address("absx", 0x1C54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BE STA
    hw.write(cpu.address("absx", 0x1C54u), cpu.a, cpu.m8?8:16);
    goto L_82B4C1;
L_82B4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u, 6u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4C1 STA
    hw.write(cpu.address("absx", 0x1C5Cu), cpu.a, cpu.m8?8:16);
    goto L_82B4C4;
L_82B4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u, 9u, 3u, cpu.address("absx", 0x1C24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4C4 INC
    cpu.incMem(hw, cpu.address("absx", 0x1C24u), cpu.m8?8:16);
    goto L_82B4C7;
L_82B4C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B4C7u);return;} hw.unresolvedReturn(0x82B4C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6CA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B6CC;
L_82B6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6CC BNE -> $82B6CF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B6CF; }
    goto L_82B6CE;
L_82B6CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6CE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6CEu);return;} hw.unresolvedReturn(0x82B6CEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6CF LDA
    cpu.setA(0xBD02u, 16);
    goto L_82B6D2;
L_82B6D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6D2 LDY
    cpu.setY(0x1u, 16);
    goto L_82B6D5;
L_82B6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D5u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D5u, 3u, 3u, cpu.address("abs", 0xB4BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6D5 JMP -> $82B4BA
    goto L_82B4BA;
}

void sub_83A181_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A181u: goto L_83A181;
    case 0x83A184u: goto L_83A184;
    case 0x83A186u: goto L_83A186;
    case 0x83A187u: goto L_83A187;
    case 0x83A189u: goto L_83A189;
    case 0x83A18Bu: goto L_83A18B;
    case 0x83A18Eu: goto L_83A18E;
    case 0x83A191u: goto L_83A191;
    case 0x83A194u: goto L_83A194;
    case 0x83A197u: goto L_83A197;
    case 0x83A19Au: goto L_83A19A;
    case 0x83B34Cu: goto L_83B34C;
    case 0x83B34Fu: goto L_83B34F;
    case 0x83B351u: goto L_83B351;
    case 0x83B354u: goto L_83B354;
    case 0x83B356u: goto L_83B356;
    case 0x83B359u: goto L_83B359;
    case 0x83B35Bu: goto L_83B35B;
    case 0x83B35Eu: goto L_83B35E;
    case 0x83B360u: goto L_83B360;
    case 0x83B361u: goto L_83B361;
    case 0x83B363u: goto L_83B363;
    case 0x83B366u: goto L_83B366;
    case 0x83B368u: goto L_83B368;
    case 0x83B36Bu: goto L_83B36B;
    case 0x83B36Du: goto L_83B36D;
    case 0x83B370u: goto L_83B370;
    case 0x83B371u: goto L_83B371;
    case 0x83B374u: goto L_83B374;
    case 0x83B376u: goto L_83B376;
    case 0x83B379u: goto L_83B379;
    case 0x83B37Bu: goto L_83B37B;
    case 0x83B37Eu: goto L_83B37E;
    case 0x83B37Fu: goto L_83B37F;
    case 0x83B382u: goto L_83B382;
    case 0x83B383u: goto L_83B383;
    case 0x83B384u: goto L_83B384;
    case 0x83B387u: goto L_83B387;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA181u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA181u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA181u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A181 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A184;
L_83A184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA184u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA184u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A184 BPL -> $83A18B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A18B; }
    goto L_83A186;
L_83A186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA186u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA186u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A186 LSR
    cpu.lsrA();
    goto L_83A187;
L_83A187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA187u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA187u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A187 BCS -> $83A194
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A194; }
    goto L_83A189;
L_83A189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA189u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA189u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A189 BCC -> $83A18E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A18E; }
    goto L_83A18B;
L_83A18B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Bu, 6u, 3u, cpu.address("abs", 0xA19Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A18B JSR -> $83A19D stack real
    { cpu.push16Value(hw,0xA18Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA18Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA19Du), 0x83A18Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A18E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Bu, 6u, 3u, cpu.address("abs", 0xA19Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A18B JSR -> $83A19D stack real
    { cpu.push16Value(hw,0xA18Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA18Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA19Du), 0x83A18Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A18E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA18Bu,0x83A18Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A18E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Eu, 6u, 3u, cpu.address("abs", 0xA3E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A18E JSR -> $83A3E2 stack real
    { cpu.push16Value(hw,0xA190u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA191u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA3E2u), 0x83A18Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A191;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Eu, 6u, 3u, cpu.address("abs", 0xA3E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A18E JSR -> $83A3E2 stack real
    { cpu.push16Value(hw,0xA190u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA191u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA3E2u), 0x83A18Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A191;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Eu, 6u, 3u, cpu.address("abs", 0xA3E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A18E JSR -> $83A3E2 stack real
    { cpu.push16Value(hw,0xA190u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA191u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA3E2u), 0x83A18Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A191;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA18Eu,0x83A18Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA191u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA191u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA191u, 6u, 3u, cpu.address("abs", 0xB218u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A191 JSR -> $83B218 stack real
    { cpu.push16Value(hw,0xA193u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA194u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB218u), 0x83A191u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A194;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA191u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA191u, 6u, 3u, cpu.address("abs", 0xB218u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A191 JSR -> $83B218 stack real
    { cpu.push16Value(hw,0xA193u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA194u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB218u), 0x83A191u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A194;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA191u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA191u, 6u, 3u, cpu.address("abs", 0xB218u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A191 JSR -> $83B218 stack real
    { cpu.push16Value(hw,0xA193u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA194u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB218u), 0x83A191u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A194;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA191u,0x83A191u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA194u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u, 6u, 3u, cpu.address("abs", 0xB1E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A194 JSR -> $83B1E4 stack real
    { cpu.push16Value(hw,0xA196u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA197u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E4u), 0x83A194u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A197;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u, 6u, 3u, cpu.address("abs", 0xB1E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A194 JSR -> $83B1E4 stack real
    { cpu.push16Value(hw,0xA196u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA197u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E4u), 0x83A194u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A197;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u, 6u, 3u, cpu.address("abs", 0xB1E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A194 JSR -> $83B1E4 stack real
    { cpu.push16Value(hw,0xA196u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA197u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E4u), 0x83A194u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A197;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA194u,0x83A194u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA197u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u, 6u, 3u, cpu.address("abs", 0xA900u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A197 JSR -> $83A900 stack real
    { cpu.push16Value(hw,0xA199u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA19Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA900u), 0x83A197u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A19A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u, 6u, 3u, cpu.address("abs", 0xA900u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A197 JSR -> $83A900 stack real
    { cpu.push16Value(hw,0xA199u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA19Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA900u), 0x83A197u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A19A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u, 6u, 3u, cpu.address("abs", 0xA900u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A197 JSR -> $83A900 stack real
    { cpu.push16Value(hw,0xA199u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA19Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA900u), 0x83A197u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A19A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA197u,0x83A197u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Au, 3u, 3u, cpu.address("abs", 0xB34Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A19A JMP -> $83B34C
    goto L_83B34C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Au, 3u, 3u, cpu.address("abs", 0xB34Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A19A JMP -> $83B34C
    goto L_83B34C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA19Au,0x83A19Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu, 9u, 3u, cpu.address("absx", 0x021Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B34C DEC
    cpu.decMem(hw, cpu.address("absx", 0x21Eu), cpu.m8?8:16);
    goto L_83B34F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu, 9u, 3u, cpu.address("absx", 0x021Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B34C DEC
    cpu.decMem(hw, cpu.address("absx", 0x21Eu), cpu.m8?8:16);
    goto L_83B34F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB34Cu,0x83B34Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B34F BPL -> $83B387
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B387; }
    goto L_83B351;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B34F BPL -> $83B387
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B387; }
    goto L_83B351;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB34Fu,0x83B34Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB351u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B351 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B354;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B351 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B354;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB351u,0x83B351u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB354u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B354 BEQ -> $83B387
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B387; }
    goto L_83B356;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B354 BEQ -> $83B387
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B387; }
    goto L_83B356;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB354u,0x83B354u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB356u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B356 LDA
    cpu.setA(0x1u, 16);
    goto L_83B359;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B356 LDA
    cpu.setA(0x1u, 16);
    goto L_83B359;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB356u,0x83B356u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB359u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B359 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B35B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B359 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B35B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB359u,0x83B359u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B35B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B35B CPY
    cpu.compareY(0xAu);
    goto L_83B35E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B35B CPY
    cpu.compareY(0xAu);
    goto L_83B35E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB35Bu,0x83B35Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B35E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B35E BNE -> $83B361
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B361; }
    goto L_83B360;
L_83B360:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB360u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB360u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB360u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B360 INC
    cpu.inc('A');
    goto L_83B361;
L_83B361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB361u,cpu,0x55u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB361u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B361 EOR
    cpu.logicXor(hw.readW(cpu.address("dpx", 0x4Eu), cpu.m8?8:16));
    goto L_83B363;
L_83B363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB363u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB363u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B363 AND
    cpu.logicAnd(0x3u);
    goto L_83B366;
L_83B366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB366u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB366u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B366 STA
    hw.write(cpu.address("dpx", 0x4Eu), cpu.a, cpu.m8?8:16);
    goto L_83B368;
L_83B368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB368u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB368u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B368 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B36B;
L_83B36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B36B BPL -> $83B371
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B371; }
    goto L_83B36D;
L_83B36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Du,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B36D EOR
    cpu.logicXor(0xFFFFu);
    goto L_83B370;
L_83B370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB370u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB370u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B370 INC
    cpu.inc('A');
    goto L_83B371;
L_83B371:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB371u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB371u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB371u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B371 CMP
    cpu.compareA(0x1000u);
    goto L_83B374;
L_83B374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB374u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB374u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B374 BCC -> $83B37B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B37B; }
    goto L_83B376;
L_83B376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB376u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB376u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B376 LDA
    cpu.setA(0x1u, 16);
    goto L_83B379;
L_83B379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB379u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB379u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B379 BCS -> $83B384
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B384; }
    goto L_83B37B;
L_83B37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B37B EOR
    cpu.logicXor(0xFFFFu);
    goto L_83B37E;
L_83B37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Eu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B37E INC
    cpu.inc('A');
    goto L_83B37F;
L_83B37F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B37F AND
    cpu.logicAnd(0xF00u);
    goto L_83B382;
L_83B382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB382u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB382u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B382 XBA
    cpu.xba();
    goto L_83B383;
L_83B383:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB383u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB383u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB383u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B383 LSR
    cpu.lsrA();
    goto L_83B384;
L_83B384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB384u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB384u, 6u, 3u, cpu.address("absx", 0x021Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B384 STA
    hw.write(cpu.address("absx", 0x21Eu), cpu.a, cpu.m8?8:16);
    goto L_83B387;
L_83B387:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB387u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B387 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B387u);return;} hw.unresolvedReturn(0x83B387u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B387 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B387u);return;} hw.unresolvedReturn(0x83B387u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB387u,0x83B387u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_83A181_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A181u: goto L_83A181;
    case 0x83A184u: goto L_83A184;
    case 0x83A186u: goto L_83A186;
    case 0x83A187u: goto L_83A187;
    case 0x83A189u: goto L_83A189;
    case 0x83A18Bu: goto L_83A18B;
    case 0x83A18Eu: goto L_83A18E;
    case 0x83A191u: goto L_83A191;
    case 0x83A194u: goto L_83A194;
    case 0x83A197u: goto L_83A197;
    case 0x83A19Au: goto L_83A19A;
    case 0x83B34Cu: goto L_83B34C;
    case 0x83B34Fu: goto L_83B34F;
    case 0x83B351u: goto L_83B351;
    case 0x83B354u: goto L_83B354;
    case 0x83B356u: goto L_83B356;
    case 0x83B359u: goto L_83B359;
    case 0x83B35Bu: goto L_83B35B;
    case 0x83B35Eu: goto L_83B35E;
    case 0x83B360u: goto L_83B360;
    case 0x83B361u: goto L_83B361;
    case 0x83B363u: goto L_83B363;
    case 0x83B366u: goto L_83B366;
    case 0x83B368u: goto L_83B368;
    case 0x83B36Bu: goto L_83B36B;
    case 0x83B36Du: goto L_83B36D;
    case 0x83B370u: goto L_83B370;
    case 0x83B371u: goto L_83B371;
    case 0x83B374u: goto L_83B374;
    case 0x83B376u: goto L_83B376;
    case 0x83B379u: goto L_83B379;
    case 0x83B37Bu: goto L_83B37B;
    case 0x83B37Eu: goto L_83B37E;
    case 0x83B37Fu: goto L_83B37F;
    case 0x83B382u: goto L_83B382;
    case 0x83B383u: goto L_83B383;
    case 0x83B384u: goto L_83B384;
    case 0x83B387u: goto L_83B387;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA181u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA181u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA181u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A181 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A184;
L_83A184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA184u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA184u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A184 BPL -> $83A18B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A18B; }
    goto L_83A186;
L_83A186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA186u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA186u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A186 LSR
    cpu.lsrA();
    goto L_83A187;
L_83A187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA187u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA187u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A187 BCS -> $83A194
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A194; }
    goto L_83A189;
L_83A189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA189u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA189u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A189 BCC -> $83A18E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A18E; }
    goto L_83A18B;
L_83A18B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Bu, 6u, 3u, cpu.address("abs", 0xA19Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A18B JSR -> $83A19D stack real
    { cpu.push16Value(hw,0xA18Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA18Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA19Du), 0x83A18Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A18E;
L_83A18E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Eu, 6u, 3u, cpu.address("abs", 0xA3E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A18E JSR -> $83A3E2 stack real
    { cpu.push16Value(hw,0xA190u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA191u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA3E2u), 0x83A18Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A191;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Eu, 6u, 3u, cpu.address("abs", 0xA3E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A18E JSR -> $83A3E2 stack real
    { cpu.push16Value(hw,0xA190u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA191u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA3E2u), 0x83A18Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A191;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Eu, 6u, 3u, cpu.address("abs", 0xA3E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A18E JSR -> $83A3E2 stack real
    { cpu.push16Value(hw,0xA190u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA191u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA3E2u), 0x83A18Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A191;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA18Eu,0x83A18Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA191u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA191u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA191u, 6u, 3u, cpu.address("abs", 0xB218u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A191 JSR -> $83B218 stack real
    { cpu.push16Value(hw,0xA193u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA194u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB218u), 0x83A191u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A194;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA191u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA191u, 6u, 3u, cpu.address("abs", 0xB218u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A191 JSR -> $83B218 stack real
    { cpu.push16Value(hw,0xA193u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA194u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB218u), 0x83A191u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A194;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA191u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA191u, 6u, 3u, cpu.address("abs", 0xB218u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A191 JSR -> $83B218 stack real
    { cpu.push16Value(hw,0xA193u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA194u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB218u), 0x83A191u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A194;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA191u,0x83A191u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA194u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u, 6u, 3u, cpu.address("abs", 0xB1E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A194 JSR -> $83B1E4 stack real
    { cpu.push16Value(hw,0xA196u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA197u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E4u), 0x83A194u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A197;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u, 6u, 3u, cpu.address("abs", 0xB1E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A194 JSR -> $83B1E4 stack real
    { cpu.push16Value(hw,0xA196u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA197u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E4u), 0x83A194u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A197;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u, 6u, 3u, cpu.address("abs", 0xB1E4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A194 JSR -> $83B1E4 stack real
    { cpu.push16Value(hw,0xA196u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA197u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB1E4u), 0x83A194u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A197;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA194u,0x83A194u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA197u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u, 6u, 3u, cpu.address("abs", 0xA900u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A197 JSR -> $83A900 stack real
    { cpu.push16Value(hw,0xA199u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA19Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA900u), 0x83A197u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A19A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u, 6u, 3u, cpu.address("abs", 0xA900u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A197 JSR -> $83A900 stack real
    { cpu.push16Value(hw,0xA199u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA19Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA900u), 0x83A197u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A19A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u, 6u, 3u, cpu.address("abs", 0xA900u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A197 JSR -> $83A900 stack real
    { cpu.push16Value(hw,0xA199u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA19Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA900u), 0x83A197u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A19A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA197u,0x83A197u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Au, 3u, 3u, cpu.address("abs", 0xB34Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A19A JMP -> $83B34C
    goto L_83B34C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Au, 3u, 3u, cpu.address("abs", 0xB34Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A19A JMP -> $83B34C
    goto L_83B34C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA19Au,0x83A19Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu, 9u, 3u, cpu.address("absx", 0x021Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B34C DEC
    cpu.decMem(hw, cpu.address("absx", 0x21Eu), cpu.m8?8:16);
    goto L_83B34F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Cu, 9u, 3u, cpu.address("absx", 0x021Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B34C DEC
    cpu.decMem(hw, cpu.address("absx", 0x21Eu), cpu.m8?8:16);
    goto L_83B34F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB34Cu,0x83B34Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B34F BPL -> $83B387
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B387; }
    goto L_83B351;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B34F BPL -> $83B387
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B387; }
    goto L_83B351;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB34Fu,0x83B34Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB351u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B351 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B354;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB351u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B351 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B354;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB351u,0x83B351u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB354u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B354 BEQ -> $83B387
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B387; }
    goto L_83B356;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB354u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B354 BEQ -> $83B387
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B387; }
    goto L_83B356;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB354u,0x83B354u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB356u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B356 LDA
    cpu.setA(0x1u, 16);
    goto L_83B359;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B356 LDA
    cpu.setA(0x1u, 16);
    goto L_83B359;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB356u,0x83B356u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB359u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B359 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B35B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B359 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B35B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB359u,0x83B359u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B35B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B35B CPY
    cpu.compareY(0xAu);
    goto L_83B35E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B35B CPY
    cpu.compareY(0xAu);
    goto L_83B35E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB35Bu,0x83B35Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B35E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B35E BNE -> $83B361
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B361; }
    goto L_83B360;
L_83B360:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB360u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB360u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB360u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B360 INC
    cpu.inc('A');
    goto L_83B361;
L_83B361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB361u,cpu,0x55u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB361u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B361 EOR
    cpu.logicXor(hw.readW(cpu.address("dpx", 0x4Eu), cpu.m8?8:16));
    goto L_83B363;
L_83B363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB363u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB363u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B363 AND
    cpu.logicAnd(0x3u);
    goto L_83B366;
L_83B366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB366u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB366u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B366 STA
    hw.write(cpu.address("dpx", 0x4Eu), cpu.a, cpu.m8?8:16);
    goto L_83B368;
L_83B368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB368u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB368u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B368 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B36B;
L_83B36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B36B BPL -> $83B371
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B371; }
    goto L_83B36D;
L_83B36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Du,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B36D EOR
    cpu.logicXor(0xFFFFu);
    goto L_83B370;
L_83B370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB370u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB370u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B370 INC
    cpu.inc('A');
    goto L_83B371;
L_83B371:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB371u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB371u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB371u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B371 CMP
    cpu.compareA(0x1000u);
    goto L_83B374;
L_83B374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB374u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB374u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B374 BCC -> $83B37B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B37B; }
    goto L_83B376;
L_83B376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB376u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB376u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B376 LDA
    cpu.setA(0x1u, 16);
    goto L_83B379;
L_83B379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB379u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB379u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B379 BCS -> $83B384
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B384; }
    goto L_83B37B;
L_83B37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B37B EOR
    cpu.logicXor(0xFFFFu);
    goto L_83B37E;
L_83B37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Eu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B37E INC
    cpu.inc('A');
    goto L_83B37F;
L_83B37F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B37F AND
    cpu.logicAnd(0xF00u);
    goto L_83B382;
L_83B382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB382u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB382u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B382 XBA
    cpu.xba();
    goto L_83B383;
L_83B383:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB383u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB383u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB383u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B383 LSR
    cpu.lsrA();
    goto L_83B384;
L_83B384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB384u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB384u, 6u, 3u, cpu.address("absx", 0x021Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B384 STA
    hw.write(cpu.address("absx", 0x21Eu), cpu.a, cpu.m8?8:16);
    goto L_83B387;
L_83B387:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB387u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B387 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B387u);return;} hw.unresolvedReturn(0x83B387u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB387u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B387 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B387u);return;} hw.unresolvedReturn(0x83B387u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB387u,0x83B387u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_83B0AD_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83B0ADu: goto L_83B0AD;
    case 0x83B0AEu: goto L_83B0AE;
    case 0x83B0B1u: goto L_83B0B1;
    case 0x83B0B4u: goto L_83B0B4;
    case 0x83B0B6u: goto L_83B0B6;
    case 0x83B0B7u: goto L_83B0B7;
    case 0x83B0BAu: goto L_83B0BA;
    case 0x83B0BCu: goto L_83B0BC;
    case 0x83B0BFu: goto L_83B0BF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83B0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0AD CLC
    cpu.setFlag('C', false);
    goto L_83B0AE;
L_83B0AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AEu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AEu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0AE ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16));
    goto L_83B0B1;
L_83B0B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B1u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0B1 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83B0B4;
L_83B0B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B4u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0B4 BMI -> $83B0BF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B0BF; }
    goto L_83B0B6;
L_83B0B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0B6 SEC
    cpu.setFlag('C', true);
    goto L_83B0B7;
L_83B0B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B7u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B7u, 5u + 1u, 3u, cpu.address("absx", 0x0214u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0B7 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x214u), cpu.m8?8:16));
    goto L_83B0BA;
L_83B0BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0BA BCC -> $83B0BF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B0BF; }
    goto L_83B0BC;
L_83B0BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu, 6u, 3u, cpu.address("absx", 0x0216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0BC STA
    hw.write(cpu.address("absx", 0x216u), cpu.a, cpu.m8?8:16);
    goto L_83B0BF;
L_83B0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B0BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B0BFu);return;} hw.unresolvedReturn(0x83B0BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83B0AD_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83B0ADu: goto L_83B0AD;
    case 0x83B0AEu: goto L_83B0AE;
    case 0x83B0B1u: goto L_83B0B1;
    case 0x83B0B4u: goto L_83B0B4;
    case 0x83B0B6u: goto L_83B0B6;
    case 0x83B0B7u: goto L_83B0B7;
    case 0x83B0BAu: goto L_83B0BA;
    case 0x83B0BCu: goto L_83B0BC;
    case 0x83B0BFu: goto L_83B0BF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83B0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0AD CLC
    cpu.setFlag('C', false);
    goto L_83B0AE;
L_83B0AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AEu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AEu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0AE ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16));
    goto L_83B0B1;
L_83B0B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B1u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0B1 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83B0B4;
L_83B0B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B4u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0B4 BMI -> $83B0BF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B0BF; }
    goto L_83B0B6;
L_83B0B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0B6 SEC
    cpu.setFlag('C', true);
    goto L_83B0B7;
L_83B0B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B7u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B7u, 5u + 1u, 3u, cpu.address("absx", 0x0214u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0B7 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x214u), cpu.m8?8:16));
    goto L_83B0BA;
L_83B0BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0BA BCC -> $83B0BF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B0BF; }
    goto L_83B0BC;
L_83B0BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu, 6u, 3u, cpu.address("absx", 0x0216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B0BC STA
    hw.write(cpu.address("absx", 0x216u), cpu.a, cpu.m8?8:16);
    goto L_83B0BF;
L_83B0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83B0BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83B0BFu);return;} hw.unresolvedReturn(0x83B0BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848AD0_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848AD0u: goto L_848AD0;
    case 0x848AD2u: goto L_848AD2;
    case 0x848AD5u: goto L_848AD5;
    case 0x848AD7u: goto L_848AD7;
    case 0x848ADAu: goto L_848ADA;
    case 0x848ADDu: goto L_848ADD;
    case 0x848ADFu: goto L_848ADF;
    case 0x848AE2u: goto L_848AE2;
    case 0x848AE5u: goto L_848AE5;
    case 0x848AE6u: goto L_848AE6;
    case 0x848AE7u: goto L_848AE7;
    case 0x848AEAu: goto L_848AEA;
    case 0x848AEDu: goto L_848AED;
    case 0x848AF0u: goto L_848AF0;
    case 0x848AF3u: goto L_848AF3;
    case 0x848AF6u: goto L_848AF6;
    case 0x848AF9u: goto L_848AF9;
    case 0x848AFCu: goto L_848AFC;
    case 0x848AFEu: goto L_848AFE;
    case 0x848B01u: goto L_848B01;
    case 0x848B02u: goto L_848B02;
    case 0x848B05u: goto L_848B05;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848AD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AD0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848AD2;
L_848AD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD2u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AD2 BIT
    cpu.bit(0x1u, true);
    goto L_848AD5;
L_848AD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AD5 BEQ -> $848AE2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848AE2; }
    goto L_848AD7;
L_848AD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD7u, 5u, 3u, cpu.address("abs", 0x1FA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AD7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848ADA;
L_848ADA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ADA CMP
    cpu.compareA(0xFu);
    goto L_848ADD;
L_848ADD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ADD BEQ -> $848AE2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848AE2; }
    goto L_848ADF;
L_848ADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADFu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADFu, 8u, 3u, cpu.address("abs", 0x1FA0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ADF INC
    cpu.incMem(hw, cpu.address("abs", 0x1FA0u), cpu.m8?8:16);
    goto L_848AE2;
L_848AE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE2u, 5u, 3u, cpu.address("abs", 0x05B2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AE2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x5B2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848AE5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE2u, 5u, 3u, cpu.address("abs", 0x05B2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AE2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x5B2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848AE5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AE2u,0x848AE2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848AE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AE5 ASL
    cpu.aslA();
    goto L_848AE6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AE5 ASL
    cpu.aslA();
    goto L_848AE6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AE5u,0x848AE5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848AE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AE6 TAX
    cpu.transfer("TAX");
    goto L_848AE7;
L_848AE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE7u, 5u + 1u, 3u, cpu.address("absx", 0xFB2Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AE7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xFB2Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848AEA;
L_848AEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEAu, 5u, 3u, cpu.address("abs", 0x1A6Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AEA STA
    hw.write(cpu.address("abs", 0x1A6Eu), cpu.a, cpu.m8?8:16);
    goto L_848AED;
L_848AED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEDu, 5u, 3u, cpu.address("abs", 0x1A70u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AED STA
    hw.write(cpu.address("abs", 0x1A70u), cpu.a, cpu.m8?8:16);
    goto L_848AF0;
L_848AF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF0u, 5u + 1u, 3u, cpu.address("absx", 0xFB8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AF0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xFB8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848AF3;
L_848AF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF3u, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AF3 STA
    hw.write(cpu.address("abs", 0x1C02u), cpu.a, cpu.m8?8:16);
    goto L_848AF6;
L_848AF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF6u, 5u, 3u, cpu.address("abs", 0x05B2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AF6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x5B2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848AF9;
L_848AF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AF9 CMP
    cpu.compareA(0x2Fu);
    goto L_848AFC;
L_848AFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AFC BEQ -> $848B02
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B02; }
    goto L_848AFE;
L_848AFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFEu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFEu, 8u, 3u, cpu.address("abs", 0x05B2u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AFE INC
    cpu.incMem(hw, cpu.address("abs", 0x5B2u), cpu.m8?8:16);
    goto L_848B01;
L_848B01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B01u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B01u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B01 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848B01u);return;} hw.unresolvedReturn(0x848B01u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_848B02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B02u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B02u, 8u, 3u, cpu.address("abs", 0x05A0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B02 INC
    cpu.incMem(hw, cpu.address("abs", 0x5A0u), cpu.m8?8:16);
    goto L_848B05;
L_848B05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B05u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B05u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B05 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848B05u);return;} hw.unresolvedReturn(0x848B05u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_848AD0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848AD0u: goto L_848AD0;
    case 0x848AD2u: goto L_848AD2;
    case 0x848AD5u: goto L_848AD5;
    case 0x848AD7u: goto L_848AD7;
    case 0x848ADAu: goto L_848ADA;
    case 0x848ADDu: goto L_848ADD;
    case 0x848ADFu: goto L_848ADF;
    case 0x848AE2u: goto L_848AE2;
    case 0x848AE5u: goto L_848AE5;
    case 0x848AE6u: goto L_848AE6;
    case 0x848AE7u: goto L_848AE7;
    case 0x848AEAu: goto L_848AEA;
    case 0x848AEDu: goto L_848AED;
    case 0x848AF0u: goto L_848AF0;
    case 0x848AF3u: goto L_848AF3;
    case 0x848AF6u: goto L_848AF6;
    case 0x848AF9u: goto L_848AF9;
    case 0x848AFCu: goto L_848AFC;
    case 0x848AFEu: goto L_848AFE;
    case 0x848B01u: goto L_848B01;
    case 0x848B02u: goto L_848B02;
    case 0x848B05u: goto L_848B05;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848AD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AD0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848AD2;
L_848AD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD2u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AD2 BIT
    cpu.bit(0x1u, true);
    goto L_848AD5;
L_848AD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AD5 BEQ -> $848AE2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848AE2; }
    goto L_848AD7;
L_848AD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD7u, 5u, 3u, cpu.address("abs", 0x1FA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AD7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848ADA;
L_848ADA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ADA CMP
    cpu.compareA(0xFu);
    goto L_848ADD;
L_848ADD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ADD BEQ -> $848AE2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848AE2; }
    goto L_848ADF;
L_848ADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADFu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADFu, 8u, 3u, cpu.address("abs", 0x1FA0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ADF INC
    cpu.incMem(hw, cpu.address("abs", 0x1FA0u), cpu.m8?8:16);
    goto L_848AE2;
L_848AE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE2u, 5u, 3u, cpu.address("abs", 0x05B2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AE2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x5B2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848AE5;
L_848AE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AE5 ASL
    cpu.aslA();
    goto L_848AE6;
L_848AE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AE6 TAX
    cpu.transfer("TAX");
    goto L_848AE7;
L_848AE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE7u, 5u + 1u, 3u, cpu.address("absx", 0xFB2Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AE7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xFB2Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848AEA;
L_848AEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEAu, 5u, 3u, cpu.address("abs", 0x1A6Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AEA STA
    hw.write(cpu.address("abs", 0x1A6Eu), cpu.a, cpu.m8?8:16);
    goto L_848AED;
L_848AED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEDu, 5u, 3u, cpu.address("abs", 0x1A70u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AED STA
    hw.write(cpu.address("abs", 0x1A70u), cpu.a, cpu.m8?8:16);
    goto L_848AF0;
L_848AF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF0u, 5u + 1u, 3u, cpu.address("absx", 0xFB8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AF0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xFB8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848AF3;
L_848AF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF3u, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AF3 STA
    hw.write(cpu.address("abs", 0x1C02u), cpu.a, cpu.m8?8:16);
    goto L_848AF6;
L_848AF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF6u, 5u, 3u, cpu.address("abs", 0x05B2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AF6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x5B2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848AF9;
L_848AF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AF9 CMP
    cpu.compareA(0x2Fu);
    goto L_848AFC;
L_848AFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AFC BEQ -> $848B02
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848B02; }
    goto L_848AFE;
L_848AFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFEu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AFEu, 8u, 3u, cpu.address("abs", 0x05B2u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AFE INC
    cpu.incMem(hw, cpu.address("abs", 0x5B2u), cpu.m8?8:16);
    goto L_848B01;
L_848B01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B01u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B01u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B01 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848B01u);return;} hw.unresolvedReturn(0x848B01u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_848B02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B02u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B02u, 8u, 3u, cpu.address("abs", 0x05A0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848B02 INC
    cpu.incMem(hw, cpu.address("abs", 0x5A0u), cpu.m8?8:16);
    goto L_848B05;
L_848B05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B05u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B05u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848B05 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848B05u);return;} hw.unresolvedReturn(0x848B05u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84917C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84917Cu: goto L_84917C;
    case 0x84917Fu: goto L_84917F;
    case 0x849181u: goto L_849181;
    case 0x849182u: goto L_849182;
    case 0x849186u: goto L_849186;
    case 0x849188u: goto L_849188;
    case 0x84918Bu: goto L_84918B;
    case 0x84918Du: goto L_84918D;
    case 0x849190u: goto L_849190;
    case 0x849192u: goto L_849192;
    case 0x849195u: goto L_849195;
    case 0x849197u: goto L_849197;
    case 0x84919Au: goto L_84919A;
    case 0x84919Cu: goto L_84919C;
    case 0x84919Fu: goto L_84919F;
    case 0x8491A2u: goto L_8491A2;
    case 0x8491A4u: goto L_8491A4;
    case 0x8491A6u: goto L_8491A6;
    case 0x8491A9u: goto L_8491A9;
    case 0x8491ACu: goto L_8491AC;
    case 0x8491B0u: goto L_8491B0;
    case 0x8491B2u: goto L_8491B2;
    case 0x8491B3u: goto L_8491B3;
    case 0x8491B4u: goto L_8491B4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84917C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Cu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84917C CPX
    cpu.compareX(0x700u);
    goto L_84917F;
L_84917F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84917F BNE -> $8491B2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8491B2; }
    goto L_849181;
L_849181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9181u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9181u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9181u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849181 TXY
    cpu.transfer("TXY");
    goto L_849182;
L_849182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9182u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9182u, 8u, 4u, 0x848699u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849182 JSL -> $848699 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9185u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9186u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848699u, 0x849182u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849186;
L_849186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9186u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849186 BCS -> $8491B3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8491B3; }
    goto L_849188;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849186 BCS -> $8491B3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8491B3; }
    goto L_849188;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9186u,0x849186u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9188u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849188 LDA
    cpu.setA(0x1Au, 16);
    goto L_84918B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849188 LDA
    cpu.setA(0x1Au, 16);
    goto L_84918B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9188u,0x849188u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84918B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84918B STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_84918D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84918B STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_84918D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x918Bu,0x84918Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84918D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84918D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849190;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84918D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849190;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x918Du,0x84918Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9190u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849190 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849192;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849190 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849192;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9190u,0x849190u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9192u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849192 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849195;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849192 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849195;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9192u,0x849192u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9195u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849195 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_849197;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849195 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_849197;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9195u,0x849195u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9197u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9197u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9197u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849197 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84919A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9197u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9197u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849197 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84919A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9197u,0x849197u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84919A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919A STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84919C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919A STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84919C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x919Au,0x84919Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84919C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84919F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84919F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x919Cu,0x84919Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84919F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919F AND
    cpu.logicAnd(0xF000u);
    goto L_8491A2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919F AND
    cpu.logicAnd(0xF000u);
    goto L_8491A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x919Fu,0x84919Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A2 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_8491A4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A2 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_8491A4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91A2u,0x8491A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A4u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A4 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_8491A6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A4u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A4 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_8491A6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91A4u,0x8491A4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A6 LDY
    cpu.setY(0x8F16u, 16);
    goto L_8491A9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A6 LDY
    cpu.setY(0x8F16u, 16);
    goto L_8491A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91A6u,0x8491A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A9 LDA
    cpu.setA(0x2u, 16);
    goto L_8491AC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A9 LDA
    cpu.setA(0x2u, 16);
    goto L_8491AC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91A9u,0x8491A9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ACu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ACu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ACu, 8u, 4u, 0x80C39Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491AC JSL -> $80C39F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91B0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C39Fu, 0x8491ACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8491B0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ACu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ACu, 8u, 4u, 0x80C39Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491AC JSL -> $80C39F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91B0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C39Fu, 0x8491ACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8491B0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91ACu,0x8491ACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8491B2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8491B2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91B0u,0x8491B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B2u);return;} hw.unresolvedReturn(0x8491B2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B2u);return;} hw.unresolvedReturn(0x8491B2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B2u);return;} hw.unresolvedReturn(0x8491B2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91B2u,0x8491B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B3 TYX
    cpu.transfer("TYX");
    goto L_8491B4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B3 TYX
    cpu.transfer("TYX");
    goto L_8491B4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91B3u,0x8491B3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B4u);return;} hw.unresolvedReturn(0x8491B4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B4u);return;} hw.unresolvedReturn(0x8491B4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91B4u,0x8491B4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84917C_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84917Cu: goto L_84917C;
    case 0x84917Fu: goto L_84917F;
    case 0x849181u: goto L_849181;
    case 0x849182u: goto L_849182;
    case 0x849186u: goto L_849186;
    case 0x849188u: goto L_849188;
    case 0x84918Bu: goto L_84918B;
    case 0x84918Du: goto L_84918D;
    case 0x849190u: goto L_849190;
    case 0x849192u: goto L_849192;
    case 0x849195u: goto L_849195;
    case 0x849197u: goto L_849197;
    case 0x84919Au: goto L_84919A;
    case 0x84919Cu: goto L_84919C;
    case 0x84919Fu: goto L_84919F;
    case 0x8491A2u: goto L_8491A2;
    case 0x8491A4u: goto L_8491A4;
    case 0x8491A6u: goto L_8491A6;
    case 0x8491A9u: goto L_8491A9;
    case 0x8491ACu: goto L_8491AC;
    case 0x8491B0u: goto L_8491B0;
    case 0x8491B2u: goto L_8491B2;
    case 0x8491B3u: goto L_8491B3;
    case 0x8491B4u: goto L_8491B4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84917C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Cu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84917C CPX
    cpu.compareX(0x700u);
    goto L_84917F;
L_84917F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84917F BNE -> $8491B2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8491B2; }
    goto L_849181;
L_849181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9181u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9181u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9181u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849181 TXY
    cpu.transfer("TXY");
    goto L_849182;
L_849182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9182u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9182u, 8u, 4u, 0x848699u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849182 JSL -> $848699 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9185u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9186u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848699u, 0x849182u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849186;
L_849186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9186u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849186 BCS -> $8491B3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8491B3; }
    goto L_849188;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849186 BCS -> $8491B3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8491B3; }
    goto L_849188;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9186u,0x849186u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9188u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849188 LDA
    cpu.setA(0x1Au, 16);
    goto L_84918B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849188 LDA
    cpu.setA(0x1Au, 16);
    goto L_84918B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9188u,0x849188u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84918B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84918B STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_84918D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84918B STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_84918D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x918Bu,0x84918Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84918D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84918D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849190;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84918D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849190;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x918Du,0x84918Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9190u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849190 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849192;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849190 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849192;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9190u,0x849190u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9192u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849192 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849195;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849192 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849195;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9192u,0x849192u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9195u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849195 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_849197;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849195 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_849197;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9195u,0x849195u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9197u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9197u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9197u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849197 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84919A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9197u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9197u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849197 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84919A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9197u,0x849197u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84919A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919A STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84919C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919A STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84919C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x919Au,0x84919Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84919C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84919F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84919F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x919Cu,0x84919Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84919F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919F AND
    cpu.logicAnd(0xF000u);
    goto L_8491A2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919F AND
    cpu.logicAnd(0xF000u);
    goto L_8491A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x919Fu,0x84919Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A2 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_8491A4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A2 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_8491A4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91A2u,0x8491A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A4u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A4 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_8491A6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A4u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A4 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_8491A6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91A4u,0x8491A4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A6 LDY
    cpu.setY(0x8F16u, 16);
    goto L_8491A9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A6 LDY
    cpu.setY(0x8F16u, 16);
    goto L_8491A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91A6u,0x8491A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A9 LDA
    cpu.setA(0x2u, 16);
    goto L_8491AC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A9 LDA
    cpu.setA(0x2u, 16);
    goto L_8491AC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91A9u,0x8491A9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ACu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ACu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ACu, 8u, 4u, 0x80C39Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491AC JSL -> $80C39F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91B0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C39Fu, 0x8491ACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8491B0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ACu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ACu, 8u, 4u, 0x80C39Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491AC JSL -> $80C39F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91B0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C39Fu, 0x8491ACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8491B0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91ACu,0x8491ACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8491B2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8491B2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91B0u,0x8491B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B2u);return;} hw.unresolvedReturn(0x8491B2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B2u);return;} hw.unresolvedReturn(0x8491B2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B2u);return;} hw.unresolvedReturn(0x8491B2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91B2u,0x8491B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B3 TYX
    cpu.transfer("TYX");
    goto L_8491B4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B3 TYX
    cpu.transfer("TYX");
    goto L_8491B4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91B3u,0x8491B3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B4u);return;} hw.unresolvedReturn(0x8491B4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B4u);return;} hw.unresolvedReturn(0x8491B4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91B4u,0x8491B4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84917C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84917Cu: goto L_84917C;
    case 0x84917Fu: goto L_84917F;
    case 0x849181u: goto L_849181;
    case 0x849182u: goto L_849182;
    case 0x849186u: goto L_849186;
    case 0x849188u: goto L_849188;
    case 0x84918Bu: goto L_84918B;
    case 0x84918Du: goto L_84918D;
    case 0x849190u: goto L_849190;
    case 0x849192u: goto L_849192;
    case 0x849195u: goto L_849195;
    case 0x849197u: goto L_849197;
    case 0x84919Au: goto L_84919A;
    case 0x84919Cu: goto L_84919C;
    case 0x84919Fu: goto L_84919F;
    case 0x8491A2u: goto L_8491A2;
    case 0x8491A4u: goto L_8491A4;
    case 0x8491A6u: goto L_8491A6;
    case 0x8491A9u: goto L_8491A9;
    case 0x8491ACu: goto L_8491AC;
    case 0x8491B0u: goto L_8491B0;
    case 0x8491B2u: goto L_8491B2;
    case 0x8491B3u: goto L_8491B3;
    case 0x8491B4u: goto L_8491B4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84917C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Cu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84917C CPX
    cpu.compareX(0x700u);
    goto L_84917F;
L_84917F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84917F BNE -> $8491B2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8491B2; }
    goto L_849181;
L_849181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9181u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9181u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9181u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849181 TXY
    cpu.transfer("TXY");
    goto L_849182;
L_849182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9182u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9182u, 8u, 4u, 0x848699u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849182 JSL -> $848699 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9185u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9186u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848699u, 0x849182u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849186;
L_849186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9186u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849186 BCS -> $8491B3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8491B3; }
    goto L_849188;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9186u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849186 BCS -> $8491B3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8491B3; }
    goto L_849188;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9186u,0x849186u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9188u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849188 LDA
    cpu.setA(0x1Au, 16);
    goto L_84918B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9188u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849188 LDA
    cpu.setA(0x1Au, 16);
    goto L_84918B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9188u,0x849188u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84918B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84918B STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_84918D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84918B STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_84918D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x918Bu,0x84918Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84918D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84918D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849190;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84918D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849190;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x918Du,0x84918Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9190u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849190 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849192;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9190u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849190 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849192;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9190u,0x849190u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9192u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849192 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849195;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849192 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849195;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9192u,0x849192u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9195u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849195 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_849197;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9195u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849195 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_849197;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9195u,0x849195u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9197u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9197u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9197u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849197 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84919A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9197u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9197u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849197 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84919A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9197u,0x849197u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84919A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919A STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84919C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919A STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84919C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x919Au,0x84919Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84919C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84919F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84919F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x919Cu,0x84919Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84919F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919F AND
    cpu.logicAnd(0xF000u);
    goto L_8491A2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84919F AND
    cpu.logicAnd(0xF000u);
    goto L_8491A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x919Fu,0x84919Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A2 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_8491A4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A2 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_8491A4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91A2u,0x8491A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A4u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A4 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_8491A6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A4u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A4 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_8491A6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91A4u,0x8491A4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A6 LDY
    cpu.setY(0x8F16u, 16);
    goto L_8491A9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A6 LDY
    cpu.setY(0x8F16u, 16);
    goto L_8491A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91A6u,0x8491A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A9 LDA
    cpu.setA(0x2u, 16);
    goto L_8491AC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491A9 LDA
    cpu.setA(0x2u, 16);
    goto L_8491AC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91A9u,0x8491A9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ACu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ACu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ACu, 8u, 4u, 0x80C39Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491AC JSL -> $80C39F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91B0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C39Fu, 0x8491ACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8491B0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ACu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ACu, 8u, 4u, 0x80C39Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491AC JSL -> $80C39F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x91AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x91B0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C39Fu, 0x8491ACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8491B0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91ACu,0x8491ACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8491B2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8491B2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91B0u,0x8491B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B2u);return;} hw.unresolvedReturn(0x8491B2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B2u);return;} hw.unresolvedReturn(0x8491B2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B2u);return;} hw.unresolvedReturn(0x8491B2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91B2u,0x8491B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B3 TYX
    cpu.transfer("TYX");
    goto L_8491B4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8491B3 TYX
    cpu.transfer("TYX");
    goto L_8491B4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91B3u,0x8491B3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8491B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B4u);return;} hw.unresolvedReturn(0x8491B4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8491B4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8491B4u);return;} hw.unresolvedReturn(0x8491B4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x91B4u,0x8491B4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849342_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849342u: goto L_849342;
    case 0x849345u: goto L_849345;
    case 0x849347u: goto L_849347;
    case 0x849349u: goto L_849349;
    case 0x84934Bu: goto L_84934B;
    case 0x84934Eu: goto L_84934E;
    case 0x849350u: goto L_849350;
    case 0x849352u: goto L_849352;
    case 0x849356u: goto L_849356;
    case 0x849358u: goto L_849358;
    case 0x84935Au: goto L_84935A;
    case 0x84935Bu: goto L_84935B;
    case 0x84935Eu: goto L_84935E;
    case 0x849360u: goto L_849360;
    case 0x849363u: goto L_849363;
    case 0x849365u: goto L_849365;
    case 0x849367u: goto L_849367;
    case 0x849369u: goto L_849369;
    case 0x84936Au: goto L_84936A;
    case 0x84936Bu: goto L_84936B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9342u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9342u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849342 CPX
    cpu.compareX(0x700u);
    goto L_849345;
L_849345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9345u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9345u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849345 BEQ -> $849350
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849350; }
    goto L_849347;
L_849347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9347u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9347u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849347 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849349;
L_849349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9349u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9349u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849349 BEQ -> $84935A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84935A; }
    goto L_84934B;
L_84934B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Bu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84934B CPX
    cpu.compareX(0x750u);
    goto L_84934E;
L_84934E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84934E BNE -> $84935A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84935A; }
    goto L_849350;
L_849350:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9350u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9350u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9350u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849350 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_849352;
L_849352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9352u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9352u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9352u, 8u, 4u, 0x8486B2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849352 JSL -> $8486B2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9355u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9356u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8486B2u, 0x849352u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849356;
L_849356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9356u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9356u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9356u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849356 BCC -> $84935B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84935B; }
    goto L_849358;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9356u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9356u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849356 BCC -> $84935B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84935B; }
    goto L_849358;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9356u,0x849356u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849358:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9358u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9358u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9358u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849358 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84935A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9358u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9358u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849358 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84935A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9358u,0x849358u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84935A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84935A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84935Au);return;} hw.unresolvedReturn(0x84935Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84935A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84935Au);return;} hw.unresolvedReturn(0x84935Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x935Au,0x84935Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84935B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84935B LDA
    cpu.setA(0x16u, 16);
    goto L_84935E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84935B LDA
    cpu.setA(0x16u, 16);
    goto L_84935E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x935Bu,0x84935Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84935E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84935E STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849360;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84935E STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849360;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x935Eu,0x84935Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849360:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9360u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9360u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9360u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849360 LDA
    cpu.setA(0x2000u, 16);
    goto L_849363;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9360u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9360u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849360 LDA
    cpu.setA(0x2000u, 16);
    goto L_849363;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9360u,0x849360u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9363u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9363u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9363u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849363 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_849365;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9363u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9363u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849363 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_849365;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9363u,0x849363u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9365u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9365u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9365u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849365 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849367;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9365u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9365u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849365 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849367;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9365u,0x849365u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9367u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9367u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9367u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849367 STA
    hw.write(cpu.address("dpx", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_849369;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9367u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9367u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849367 STA
    hw.write(cpu.address("dpx", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_849369;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9367u,0x849367u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849369:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9369u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9369u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9369u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849369 TAX
    cpu.transfer("TAX");
    goto L_84936A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9369u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9369u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849369 TAX
    cpu.transfer("TAX");
    goto L_84936A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9369u,0x849369u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84936A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x936Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x936Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x936Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84936A CLC
    cpu.setFlag('C', false);
    goto L_84936B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x936Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x936Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84936A CLC
    cpu.setFlag('C', false);
    goto L_84936B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x936Au,0x84936Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84936B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x936Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x936Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x936Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84936B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84936Bu);return;} hw.unresolvedReturn(0x84936Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

